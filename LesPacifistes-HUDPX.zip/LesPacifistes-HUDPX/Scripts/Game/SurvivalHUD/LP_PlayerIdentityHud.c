//------------------------------------------------------------------------------------------------
// LP_PlayerIdentityHud.c
//
// Manager client qui alimente le nouveau bloc haut droit du SurvivalHUD :
//  - txt_RpName  : nom + prenom RP (JobIdentityManager.Client_GetDisplayName)
//  - txt_RpId    : ID joueur
//  - txt_Cash    : cash courant (reutilise la valeur deja poussee dans txt_Capsules)
//  - txt_Bank    : solde en banque (RPC vers JobBankManager)
//  - txt_RpJob   : metier (reutilise la valeur de txt_Job)
//
// Pattern : CallLater refresh toutes les 2 secondes.
// Le serveur push automatiquement le cash dans txt_Capsules via CapsulePlayerComponent.
// Le solde banque est demande au serveur via RPC ClientAskPlayerHudBank (JobPlayerComponent).
//
// Preference visibilite : le joueur peut masquer la carte via JobRpFicheMenu. L etat est
// persiste dans $profile:LesPacifistesJobs/hud_prefs.json et appliquee a chaque spawn.
//------------------------------------------------------------------------------------------------

class LP_PlayerIdentityHud
{
	static ref LP_PlayerIdentityHud s_Instance;

	// Widgets
	protected TextWidget m_RpName;
	protected TextWidget m_RpId;
	protected TextWidget m_Cash;
	protected TextWidget m_Bank;
	protected TextWidget m_RpStatus;
	protected TextWidget m_RpJob;
	// Reference au conteneur de la carte joueur (pour toggle visibilite)
	protected Widget m_PlayerCardRoot;

	// Dernier solde banque recu du serveur (met a jour quand RpcDo_PlayerHudBank arrive)
	protected int m_LastKnownBankBalance = 0;

	// Preference visibilite de la carte joueur (persistante)
	// Vrai par defaut. Charge depuis le fichier des la premiere init.
	protected bool m_PlayerCardVisible = true;
	protected bool m_PrefLoaded = false;

	// Intervalle du refresh
	const int REFRESH_INTERVAL_MS = 2000;
	// Intervalle du poll banque (plus lent, pas besoin de spammer)
	const int BANK_POLL_INTERVAL_MS = 5000;

	// Chemin du fichier de preference (local au profil Workbench/jeu de ce client)
	const string PREF_PATH = "$profile:LesPacifistesJobs/hud_prefs.json";

	//------------------------------------------------------------------------------------------------
	static LP_PlayerIdentityHud GetInstance()
	{
		if (!s_Instance)
		{
			s_Instance = new LP_PlayerIdentityHud();
			s_Instance.Init();
		}
		return s_Instance;
	}

	//------------------------------------------------------------------------------------------------
	protected void Init()
	{
		// Charge la preference de visibilite depuis le disque
		LoadPref();

		// Demarre les refresh en boucle (CallLater avec repeat=true)
		GetGame().GetCallqueue().CallLater(TickRefresh, REFRESH_INTERVAL_MS, true);
		GetGame().GetCallqueue().CallLater(TickBankPoll, BANK_POLL_INTERVAL_MS, true);

		// Premier refresh immediat (dans ~500ms pour laisser le HUD charger)
		GetGame().GetCallqueue().CallLater(TickRefresh, 500, false);
		GetGame().GetCallqueue().CallLater(TickBankPoll, 1500, false);

		Print("[LP_PlayerIdentityHud] Manager HUD identite initialise.", LogLevel.NORMAL);
	}

	//------------------------------------------------------------------------------------------------
	// Cache les widgets du HUD (lazy : les widgets n existent qu une fois le SurvivalHUD charge)
	//------------------------------------------------------------------------------------------------
	protected bool EnsureWidgets()
	{
		if (m_RpName && m_Cash && m_Bank)
			return true;

		WorkspaceWidget ws = GetGame().GetWorkspace();
		if (!ws)
			return false;

		m_RpName   = TextWidget.Cast(ws.FindAnyWidget("txt_RpName"));
		m_RpId     = TextWidget.Cast(ws.FindAnyWidget("txt_RpId"));
		m_Cash     = TextWidget.Cast(ws.FindAnyWidget("txt_Cash"));
		m_Bank     = TextWidget.Cast(ws.FindAnyWidget("txt_Bank"));
		m_RpStatus = TextWidget.Cast(ws.FindAnyWidget("txt_RpStatus"));
		m_RpJob    = TextWidget.Cast(ws.FindAnyWidget("txt_RpJob"));
		m_PlayerCardRoot = ws.FindAnyWidget("PlayerCard_Overlay");

		// Applique la preference de visibilite des que le widget racine est trouve
		if (m_PlayerCardRoot)
			m_PlayerCardRoot.SetVisible(m_PlayerCardVisible);

		return (m_RpName != null && m_Cash != null && m_Bank != null);
	}

	//------------------------------------------------------------------------------------------------
	// Refresh principal : nom RP + cash (lu depuis txt_Capsules deja a jour) + ID
	//------------------------------------------------------------------------------------------------
	protected void TickRefresh()
	{
		if (!EnsureWidgets())
			return;

		int localPlayerId = GetGame().GetPlayerController().GetPlayerId();
		if (localPlayerId <= 0)
			return;

		// Nom RP
		string rpName = JobIdentityManager.GetInstance().Client_GetDisplayName(localPlayerId);
		if (rpName == "")
			rpName = "Inconnu";
		m_RpName.SetText(rpName);

		// ID
		if (m_RpId)
			m_RpId.SetText("ID " + localPlayerId.ToString());

		// Cash : lit directement depuis txt_Capsules deja mis a jour par le serveur
		WorkspaceWidget ws = GetGame().GetWorkspace();
		if (ws)
		{
			TextWidget hudCaps = TextWidget.Cast(ws.FindAnyWidget("txt_Capsules"));
			if (hudCaps)
			{
				string capsStr = hudCaps.GetText();
				// capsStr est typiquement "1234 Capsules" -> extrait le nombre
				int cash = ExtractFirstInt(capsStr);
				m_Cash.SetText(FormatThousands(cash));
			}

			// Metier : lit directement depuis txt_Job deja mis a jour par JobPlayerComponent
			if (m_RpJob)
			{
				TextWidget hudJob = TextWidget.Cast(ws.FindAnyWidget("txt_Job"));
				if (hudJob)
					m_RpJob.SetText(hudJob.GetText());
			}
		}

		// Banque : reutilise la derniere valeur recue (RpcDo_PlayerHudBank)
		m_Bank.SetText(FormatThousands(m_LastKnownBankBalance));

		// Statut : si identite RP enregistree -> "ROLEPLAY", sinon "INVITE"
		if (m_RpStatus)
		{
			if (rpName == "Inconnu" || rpName == "")
				m_RpStatus.SetText("INVITE");
			else
				m_RpStatus.SetText("ROLEPLAY");
		}
	}

	//------------------------------------------------------------------------------------------------
	// Demande le solde banque au serveur (polling leger)
	//------------------------------------------------------------------------------------------------
	protected void TickBankPoll()
	{
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc)
			return;

		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc)
			return;

		jpc.ClientAskPlayerHudBank();
	}

	//------------------------------------------------------------------------------------------------
	// Callback appele par JobPlayerComponent.RpcDo_PlayerHudBank : met en cache le solde
	//------------------------------------------------------------------------------------------------
	void OnBankBalanceReceived(int balance)
	{
		m_LastKnownBankBalance = balance;
		// Rafraichit immediatement le widget si deja cache
		if (m_Bank)
			m_Bank.SetText(FormatThousands(balance));
	}

	//------------------------------------------------------------------------------------------------
	// ============================================================
	// PREFERENCE VISIBILITE DE LA CARTE JOUEUR (toggle depuis la fiche RP)
	// ============================================================
	//------------------------------------------------------------------------------------------------
	// Vrai si la carte joueur doit etre visible, faux sinon
	//------------------------------------------------------------------------------------------------
	bool IsPlayerCardVisible()
	{
		return m_PlayerCardVisible;
	}

	//------------------------------------------------------------------------------------------------
	// Force la visibilite de la carte joueur et persiste la preference.
	// Appele depuis JobRpFicheMenu via le bouton Masquer/Afficher.
	//------------------------------------------------------------------------------------------------
	void SetPlayerCardVisible(bool visible)
	{
		m_PlayerCardVisible = visible;

		// Essaie de recuperer le widget si pas encore cache (au cas ou l utilisateur
		// toggle avant le premier TickRefresh ait trouve les widgets)
		if (!m_PlayerCardRoot)
		{
			WorkspaceWidget ws = GetGame().GetWorkspace();
			if (ws)
				m_PlayerCardRoot = ws.FindAnyWidget("PlayerCard_Overlay");
		}

		if (m_PlayerCardRoot)
			m_PlayerCardRoot.SetVisible(visible);

		SavePref();
	}

	//------------------------------------------------------------------------------------------------
	// Toggle (inverse l etat) et retourne le nouvel etat
	//------------------------------------------------------------------------------------------------
	bool TogglePlayerCardVisible()
	{
		SetPlayerCardVisible(!m_PlayerCardVisible);
		return m_PlayerCardVisible;
	}

	//------------------------------------------------------------------------------------------------
	// Sauvegarde la pref dans $profile:LesPacifistesJobs/hud_prefs.json
	//------------------------------------------------------------------------------------------------
	protected void SavePref()
	{
		SCR_JsonSaveContext ctx = new SCR_JsonSaveContext();
		ctx.WriteValue("player_card_visible", m_PlayerCardVisible);
		if (!ctx.SaveToFile(PREF_PATH))
		{
			Print("[LP_PlayerIdentityHud] ERREUR : impossible d ecrire " + PREF_PATH, LogLevel.WARNING);
		}
	}

	//------------------------------------------------------------------------------------------------
	// Charge la pref depuis le fichier. Si le fichier n existe pas (premier lancement),
	// la carte reste visible par defaut.
	//------------------------------------------------------------------------------------------------
	protected void LoadPref()
	{
		m_PrefLoaded = true;

		SCR_JsonLoadContext ctx = new SCR_JsonLoadContext();
		if (!ctx.LoadFromFile(PREF_PATH))
			return;  // Fichier absent -> on garde les defauts (visible = true)

		bool visible = true;
		if (ctx.ReadValue("player_card_visible", visible))
			m_PlayerCardVisible = visible;
	}

	//------------------------------------------------------------------------------------------------
	// Formatage milliers : 12345 -> "12,345"
	//------------------------------------------------------------------------------------------------
	protected string FormatThousands(int value)
	{
		if (value < 0) value = 0;
		string s = value.ToString();
		int len = s.Length();
		if (len <= 3)
			return s;

		string result = "";
		int countFromRight = 0;
		for (int i = len - 1; i >= 0; i--)
		{
			if (countFromRight > 0 && countFromRight % 3 == 0)
				result = "," + result;
			result = s.Get(i) + result;
			countFromRight++;
		}
		return result;
	}

	//------------------------------------------------------------------------------------------------
	// Extrait le premier entier d une chaine : "1234 Capsules" -> 1234
	//------------------------------------------------------------------------------------------------
	protected int ExtractFirstInt(string src)
	{
		if (src == "")
			return 0;
		string digits = "";
		int len = src.Length();
		for (int i = 0; i < len; i++)
		{
			string c = src.Get(i);
			if (c == "0" || c == "1" || c == "2" || c == "3" || c == "4"
			 || c == "5" || c == "6" || c == "7" || c == "8" || c == "9")
			{
				digits = digits + c;
			}
			else if (digits != "")
			{
				break;
			}
		}
		if (digits == "")
			return 0;
		return digits.ToInt();
	}
}
