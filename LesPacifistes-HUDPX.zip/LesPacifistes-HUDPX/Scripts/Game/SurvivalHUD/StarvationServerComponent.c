class StarvationServerComponentClass : ScriptComponentClass {}

class StarvationServerComponent : ScriptComponent
{
    override void OnPostInit(IEntity owner)
    {
        super.OnPostInit(owner);
        if (!GetGame().InPlayMode()) return;
        Print("[Starvation] Composant actif - IsServer=" + Replication.IsServer());
    }

    // Appele depuis SurvivalHUDManager cote client
    void RequestKill()
    {
        Print("[Starvation] RequestKill appele - IsServer=" + Replication.IsServer());
        Rpc(RpcAsk_KillPlayer);
    }

    [RplRpc(RplChannel.Reliable, RplRcver.Server)]
    void RpcAsk_KillPlayer()
    {
        Print("[Starvation] RpcAsk_KillPlayer RECU - IsServer=" + Replication.IsServer());

        if (!Replication.IsServer()) return;

        IEntity ownerEnt = GetOwner();
        if (!ownerEnt)
        {
            Print("[Starvation] Kill - GetOwner() null");
            return;
        }

        PlayerController pc = PlayerController.Cast(ownerEnt);
        if (!pc)
        {
            Print("[Starvation] Kill - Cast PlayerController echoue, type=" + ownerEnt.Type());
            return;
        }

        IEntity character = pc.GetControlledEntity();
        if (!character)
        {
            Print("[Starvation] Kill - character null (joueur deconnecte ?)");
            return;
        }

        SCR_CharacterDamageManagerComponent dmg = SCR_CharacterDamageManagerComponent.Cast(
            character.FindComponent(SCR_CharacterDamageManagerComponent));
        if (!dmg)
        {
            Print("[Starvation] Kill - SCR_CharacterDamageManagerComponent null");
            return;
        }

        dmg.Kill(Instigator.CreateInstigator(character));
        Print("[Starvation] Joueur tue par famine - OK.");
    }

    override void OnDelete(IEntity owner)
    {
        super.OnDelete(owner);
    }
}
