class SurvivalHUDManagerClass : ScriptComponentClass {}

class SurvivalHUDManager : ScriptComponent
{
	protected static SurvivalHUDManager s_Instance;
	static SurvivalHUDManager GetInstance() { return s_Instance; }

	protected float m_fLife       = 100.0;
	protected float m_fBlood      = 100.0;
	protected float m_fEnergy     = 100.0;
	protected float m_fHunger     = 100.0;
	protected float m_fThirst     = 100.0;

	protected float m_fEnergySprintDrain  = 3.0;
	protected float m_fEnergyRegenRate    = 1.5;
	protected float m_fThirstRefillAmount = 30.0;
	protected float m_fHungerDrainPerSec  = 1.0 / 60.0;
	protected float m_fThirstDrainPerSec  = 1.2 / 60.0;
	protected bool  m_bIsSprinting        = false;

	// Systeme de penalite faim/soif
	protected float m_fStarvationTimer    = 0.0;
	protected float m_fStarvationInterval = 60.0;
	protected float m_fStarvationDamage   = 15.0;
	protected float m_fWarningTimer       = 0.0;
	protected float m_fWarningDuration    = 10.0;
	protected bool  m_bStarvingRPCSent    = false;

	protected bool       m_bHUDCreated = false;
	protected Widget     m_wHUDRoot;
	protected TextWidget m_wThirst;
	protected TextWidget m_wHunger;
	protected TextWidget m_wEnergy;
	protected TextWidget m_wBlood;
	protected TextWidget m_wLife;
	protected TextWidget m_wDrinkPrompt;
	protected TextWidget m_wCapsules;
	protected TextWidget m_wWarning;  // widget message d'avertissement

	// Debug : on logge une seule fois les hitzones trouvees pour aider au diagnostic
	protected bool m_bHitZonesDebugged = false;

	override void OnPostInit(IEntity owner)
	{
		super.OnPostInit(owner);
		if (!GetGame().InPlayMode()) return;

		PlayerController pc = PlayerController.Cast(owner);
		if (!pc) { Print("[SurvivalHUD] ERREUR : doit etre sur PlayerController."); return; }

		s_Instance = this;
		GetGame().GetCallqueue().CallLater(CreateHUD, 1000, false);
		Print("[SurvivalHUD] Actif sur PlayerController.");
	}

	protected void CreateHUD()
	{
		WorkspaceWidget workspace = GetGame().GetWorkspace();
		if (!workspace)
		{
			GetGame().GetCallqueue().CallLater(CreateHUD, 1000, false);
			return;
		}

		m_wHUDRoot = workspace.CreateWidgets("{1B16D0ECE2D14272}UI/layouts/SurvivalHUD.layout");
		if (!m_wHUDRoot)
		{
			GetGame().GetCallqueue().CallLater(CreateHUD, 1000, false);
			return;
		}

		m_wThirst      = TextWidget.Cast(m_wHUDRoot.FindAnyWidget("txt_Thirst"));
		m_wHunger      = TextWidget.Cast(m_wHUDRoot.FindAnyWidget("txt_Hunger"));
		m_wEnergy      = TextWidget.Cast(m_wHUDRoot.FindAnyWidget("txt_Energy"));
		m_wBlood       = TextWidget.Cast(m_wHUDRoot.FindAnyWidget("txt_Blood"));
		m_wLife        = TextWidget.Cast(m_wHUDRoot.FindAnyWidget("txt_Life"));
		m_wDrinkPrompt = TextWidget.Cast(m_wHUDRoot.FindAnyWidget("txt_DrinkPrompt"));
		m_wCapsules    = TextWidget.Cast(m_wHUDRoot.FindAnyWidget("txt_Capsules"));

		if (!m_wCapsules)
		{
			WorkspaceWidget ws2 = GetGame().GetWorkspace();
			if (ws2)
			{
				Widget capW = ws2.CreateWidget(WidgetType.TextWidgetTypeID,
					WidgetFlags.VISIBLE | WidgetFlags.NOFOCUS,
					Color.FromRGBA(0, 0, 0, 0), 0);
				if (capW)
				{
					float wsW = ws2.GetWidth();
					FrameSlot.SetPos(capW, wsW - 250, 10);
					FrameSlot.SetSize(capW, 240, 36);
					m_wCapsules = TextWidget.Cast(capW);
				}
			}
		}

		// Cree le widget d'avertissement dynamiquement — centre de l'ecran, 40% de hauteur
		WorkspaceWidget ws3 = GetGame().GetWorkspace();
		if (ws3)
		{
			Widget warnW = ws3.CreateWidget(WidgetType.TextWidgetTypeID,
				WidgetFlags.VISIBLE | WidgetFlags.NOFOCUS,
				Color.FromRGBA(0, 0, 0, 0), 0);
			if (warnW)
			{
				float wsW = ws3.GetWidth();
				float wsH = ws3.GetHeight();
				FrameSlot.SetPos(warnW, wsW * 0.5 - 300, wsH * 0.4);
				FrameSlot.SetSize(warnW, 600, 50);
				m_wWarning = TextWidget.Cast(warnW);
				if (m_wWarning)
				{
					m_wWarning.SetColor(new Color(1.0, 0.2, 0.2, 1.0));
					m_wWarning.SetVisible(false);
				}
			}
		}

		if (m_wDrinkPrompt)
			m_wDrinkPrompt.SetVisible(false);

		m_bHUDCreated = true;
		Print("[SurvivalHUD] HUD OK");

		GetGame().GetCallqueue().CallLater(UpdateLoop, 2000, true);
	}

	protected float m_fSyncTimer = 0.0;
	protected float m_fSyncInterval = 5.0; // sync toutes les 5 secondes

	protected void UpdateLoop()
	{
		if (!m_bHUDCreated) return;

		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return;

		IEntity character = pc.GetControlledEntity();
		if (!character) return;

		ChimeraCharacter chimeraChar = ChimeraCharacter.Cast(character);
		if (!chimeraChar) return;

		float dt = 2.0;
		UpdateLife(chimeraChar);
		UpdateEnergy(chimeraChar, dt);
		UpdateHungerThirst(dt);
		UpdateStarvation(chimeraChar, dt);
		UpdateWarningTimer(dt);
		UpdateHUD();
	}

	protected bool m_bWasDead = false;

	// Vie = minimum des hitzones de parties du corps (on exclut Sang et Resilience).
	// La default hitzone des persos est purement informative et reste a 100%,
	// donc on itere toutes les hitzones et on prend la plus blessee.
	protected void UpdateLife(IEntity character)
	{
		SCR_CharacterDamageManagerComponent dmg = SCR_CharacterDamageManagerComponent.Cast(
			character.FindComponent(SCR_CharacterDamageManagerComponent));
		if (!dmg) return;

		// Sang : hitzone "Blood"
		HitZone bloodHz = dmg.GetBloodHitZone();
		if (bloodHz)
		{
			float maxB = bloodHz.GetMaxHealth();
			float curB = bloodHz.GetHealth();
			if (maxB > 0) m_fBlood = (curB / maxB) * 100.0;
		}

		// On veut aussi exclure la resilience (regenere trop vite, fausse la lecture)
		HitZone resilienceHz = dmg.GetResilienceHitZone();

		// Iteration sur toutes les hitzones, on garde le minimum
		array<HitZone> allHz = new array<HitZone>();
		dmg.GetAllHitZones(allHz);

		float minPct = 100.0;
		bool foundAny = false;

		foreach (HitZone hz : allHz)
		{
			if (!hz) continue;
			if (hz == bloodHz) continue;       // sang gere separement
			if (hz == resilienceHz) continue;  // resilience exclue

			float mx = hz.GetMaxHealth();
			if (mx <= 0) continue;

			float pct = (hz.GetHealth() / mx) * 100.0;
			if (pct < minPct) minPct = pct;
			foundAny = true;
		}

		if (foundAny) m_fLife = minPct;

		// Debug one-shot : aide a verifier les hitzones presentes
		if (!m_bHitZonesDebugged)
		{
			m_bHitZonesDebugged = true;
			Print("[SurvivalHUD] Hitzones detectees : " + allHz.Count().ToString());
			Print("[SurvivalHUD] Blood hz null ? " + (bloodHz == null).ToString());
			Print("[SurvivalHUD] Resilience hz null ? " + (resilienceHz == null).ToString());
		}

		// Detection mort -> reset stats
		if (m_fLife <= 0 && !m_bWasDead)
		{
			m_bWasDead = true;
			OnPlayerDied();
		}
		else if (m_fLife > 0 && m_bWasDead)
		{
			m_bWasDead = false;
		}
	}

	protected void OnPlayerDied()
	{
		m_fThirst          = 100.0;
		m_fHunger          = 100.0;
		m_fBlood           = 100.0;
		m_fEnergy          = 100.0;
		m_bStarvingRPCSent = false;
		m_fStarvationTimer = 0.0;
		Print("[SurvivalHUD] Mort detectee - stats remises a 100%.");
	}

	// Appele par RpcDo_ResetStats depuis StarvationServerComponent
	void ResetStatsOnDeath()
	{
		OnPlayerDied();
	}

	protected void UpdateEnergy(IEntity character, float dt)
	{
		CharacterControllerComponent ctrl = CharacterControllerComponent.Cast(character.FindComponent(CharacterControllerComponent));
		if (ctrl) m_bIsSprinting = ctrl.IsSprinting();
		if (m_bIsSprinting) m_fEnergy = Math.Max(0.0, m_fEnergy - m_fEnergySprintDrain * dt);
		else                m_fEnergy = Math.Min(100.0, m_fEnergy + m_fEnergyRegenRate * dt);
	}

	protected void UpdateHungerThirst(float dt)
	{
		m_fHunger = Math.Max(0.0, m_fHunger - m_fHungerDrainPerSec * dt);
		m_fThirst = Math.Max(0.0, m_fThirst - m_fThirstDrainPerSec * dt);
	}

	protected void UpdateStarvation(IEntity character, float dt)
	{
		bool isStarving = (m_fHunger <= 0.0 || m_fThirst <= 0.0);
		bool isLow      = (m_fHunger <= 5.0 || m_fThirst <= 5.0);

		// Warning a 5%
		if (isLow && !isStarving)
			ShowWarning("Attention, mange ou bois rapidement !");

		if (!isStarving)
		{
			m_bStarvingRPCSent = false;
			m_fStarvationTimer = 0.0;
			return;
		}

		// Premier warning a 0%
		if (!m_bStarvingRPCSent)
		{
			m_bStarvingRPCSent = true;
			ShowWarning("Attention, tu vas mourir, mange ou bois !");
		}

		// Timer famine cote client — apres 60s envoie RPC kill au serveur
		m_fStarvationTimer = m_fStarvationTimer + dt;

		// Rappel warning toutes les 60 secondes
		if (m_fStarvationTimer >= m_fStarvationInterval)
		{
			m_fStarvationTimer = 0.0;
			ShowWarning("Attention, tu vas mourir, mange ou bois !");
			Print("[SurvivalHUD] Timer famine atteint 60s - appel RequestKillFromServer");
			RequestKillFromServer();
		}
	}

	protected void RequestKillFromServer()
	{
		Print("[SurvivalHUD] Famine - demande kill au serveur.");

		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return;

		IEntity character = pc.GetControlledEntity();
		if (!character) { Print("[SurvivalHUD] Kill - character null"); return; }

		StarvationCharacterComponent comp = StarvationCharacterComponent.Cast(
			character.FindComponent(StarvationCharacterComponent));
		if (!comp) { Print("[SurvivalHUD] Kill - comp null sur character"); return; }

		comp.RequestKill();
		Print("[SurvivalHUD] Kill - RequestKill envoye.");
	}

	protected void ShowWarning(string message)
	{
		if (!m_wWarning) return;
		m_wWarning.SetText(message);
		m_wWarning.SetVisible(true);
		m_fWarningTimer = m_fWarningDuration;
	}

	protected void UpdateWarningTimer(float dt)
	{
		if (m_fWarningTimer <= 0.0) return;
		m_fWarningTimer = m_fWarningTimer - dt;
		if (m_fWarningTimer <= 0.0)
		{
			m_fWarningTimer = 0.0;
			if (m_wWarning) m_wWarning.SetVisible(false);
		}
	}

	protected void UpdateHUD()
	{
		if (!m_wHUDRoot) return;
		SetStat(m_wThirst, "",    m_fThirst);
		SetStat(m_wHunger, "",    m_fHunger);
		SetStat(m_wEnergy, "", m_fEnergy);
		SetStat(m_wBlood,  "",    m_fBlood);
		SetStat(m_wLife,   "",     m_fLife);
		UpdateCapsules();
	}

	protected void UpdateCapsules()
	{
		if (!m_wCapsules) return;

		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return;

		CapsulePlayerComponent comp = CapsulePlayerComponent.Cast(pc.FindComponent(CapsulePlayerComponent));
		if (!comp) return;

		int caps = comp.GetLocalCapsules();
		m_wCapsules.SetText(caps.ToString() + " Caps");
		m_wCapsules.SetColor(new Color(1.0, 0.85, 0.0, 1.0));
	}

	protected void SetStat(TextWidget w, string label, float value)
	{
		if (!w) return;
		w.SetText(label + "" + Math.Round(value) + "%");
		w.SetColor(GetColor(value));
	}

	protected Color GetColor(float value)
	{
		if (value > 60.0) return new Color(0.2, 1.0, 0.2, 1.0);
		if (value > 35.0) return new Color(1.0, 0.85, 0.0, 1.0);
		if (value > 15.0) return new Color(1.0, 0.3, 0.3, 1.0);
		return new Color(1.0, 0.0, 0.0, 1.0);
	}

	void ShowDrinkPrompt(bool show)
	{
		if (!m_wDrinkPrompt) return;
		m_wDrinkPrompt.SetVisible(show);
	}

	// GUIDs des sons — remplacer par vos vrais GUIDs
	protected static const ResourceName SOUND_DRINK = "{A77F7860CB34C0B3}Sounds/boire.wav";
	protected static const ResourceName SOUND_EAT   = "{32A29B72056ED7FB}Sounds/manger.wav";

	protected void PlaySound(ResourceName sound)
	{
		if (sound == string.Empty) return;
		AudioSystem.PlaySound(sound);
	}

	void DrinkWater()
	{
		m_fThirst = Math.Min(100.0, m_fThirst + m_fThirstRefillAmount);
		PlaySound(SOUND_DRINK);
	}

	void DrinkItem(float amount)
	{
		m_fThirst = Math.Min(100.0, m_fThirst + amount);
		PlaySound(SOUND_DRINK);
	}

	void EatFood(float amount)
	{
		m_fHunger = Math.Min(100.0, m_fHunger + amount);
		PlaySound(SOUND_EAT);
	}

	override void OnDelete(IEntity owner)
	{
		s_Instance = null;
		GetGame().GetCallqueue().Remove(UpdateLoop);
		GetGame().GetCallqueue().Remove(CreateHUD);
		if (m_wWarning) { m_wWarning.RemoveFromHierarchy(); m_wWarning = null; }
		if (m_wCapsules)
		{
			Widget capParent = m_wCapsules.GetParent();
			if (!capParent) m_wCapsules.RemoveFromHierarchy();
		}
		if (m_wHUDRoot) { m_wHUDRoot.RemoveFromHierarchy(); m_wHUDRoot = null; }
		super.OnDelete(owner);
	}

	void ServerNotifyDrink(float amount)
	{
		Rpc(RpcDo_Drink, amount);
	}

	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_Drink(float amount)
	{
		DrinkItem(amount);
	}

	void ServerNotifyEat(float amount)
	{
		Rpc(RpcDo_Eat, amount);
	}

	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_Eat(float amount)
	{
		EatFood(amount);
	}

	float GetLife()   { return m_fLife;   }
	float GetBlood()  { return m_fBlood;  }
	float GetEnergy() { return m_fEnergy; }
	float GetHunger() { return m_fHunger; }
	float GetThirst() { return m_fThirst; }
}