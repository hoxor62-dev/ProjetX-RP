class DrinkWaterAction : ScriptedUserAction
{
	override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
	{
		if (Replication.IsServer()) return;

		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return;
		IEntity localChar = pc.GetControlledEntity();
		if (!localChar || localChar != pUserEntity) return;

		SurvivalHUDManager hud = SurvivalHUDManager.GetInstance();
		if (hud) hud.DrinkItem(30.0);
	}

	override bool CanBePerformedScript(IEntity user)
	{
		SurvivalHUDManager hud = SurvivalHUDManager.GetInstance();
		if (!hud) return true;
		return hud.GetThirst() < 99.0;
	}

	override bool CanBeShownScript(IEntity user)
	{
		return true;
	}
}
