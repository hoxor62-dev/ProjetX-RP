class DrinkItemAction : ScriptedUserAction
{
    [Attribute("30", UIWidgets.EditBox, "Quantite de soif restauree (%)")]
    protected float m_fThirstAmount;

    override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
    {
        if (!Replication.IsServer()) return;

        int playerId = GetGame().GetPlayerManager().GetPlayerIdFromControlledEntity(pUserEntity);
        PlayerController pc = GetGame().GetPlayerManager().GetPlayerController(playerId);
        if (pc)
        {
            SurvivalHUDManager hud = SurvivalHUDManager.Cast(pc.FindComponent(SurvivalHUDManager));
            if (hud) hud.ServerNotifyDrink(m_fThirstAmount);
        }

        SCR_EntityHelper.DeleteEntityAndChildren(pOwnerEntity);
    }

    override bool CanBePerformedScript(IEntity user)
    {
        SurvivalHUDManager hud = SurvivalHUDManager.GetInstance();
        if (!hud) return true;
        return hud.GetThirst() < 99.0;
    }

    override bool CanBeShownScript(IEntity user) { return true; }
}
