class EatItemAction : ScriptedUserAction
{
    [Attribute("20", UIWidgets.EditBox, "Quantite de faim restauree (%)")]
    protected float m_fHungerAmount;

    override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
    {
        if (!Replication.IsServer()) return;

        int playerId = GetGame().GetPlayerManager().GetPlayerIdFromControlledEntity(pUserEntity);
        PlayerController pc = GetGame().GetPlayerManager().GetPlayerController(playerId);
        if (pc)
        {
            SurvivalHUDManager hud = SurvivalHUDManager.Cast(pc.FindComponent(SurvivalHUDManager));
            if (hud) hud.ServerNotifyEat(m_fHungerAmount);
        }

        SCR_EntityHelper.DeleteEntityAndChildren(pOwnerEntity);
    }

    override bool CanBePerformedScript(IEntity user)
    {
        SurvivalHUDManager hud = SurvivalHUDManager.GetInstance();
        if (!hud) return true;
        return hud.GetHunger() < 99.0;
    }

    override bool CanBeShownScript(IEntity user) { return true; }
}