class StarvationCharacterComponentClass : ScriptComponentClass {}

class StarvationCharacterComponent : ScriptComponent
{
    void RequestKill()
    {
        Print("[Starvation] RequestKill (character) - IsServer=" + Replication.IsServer());
        Rpc(RpcAsk_KillPlayer);
    }

    [RplRpc(RplChannel.Reliable, RplRcver.Server)]
void RpcAsk_KillPlayer()
{
    Print("[Starvation] RpcAsk_KillPlayer RECU (character) - IsServer=" + Replication.IsServer());
    if (!Replication.IsServer()) return;

    IEntity character = GetOwner();
    if (!character) return;

    SCR_CharacterDamageManagerComponent dmg = SCR_CharacterDamageManagerComponent.Cast(
        character.FindComponent(SCR_CharacterDamageManagerComponent));
    if (!dmg) { Print("[Starvation] dmg null"); return; }

    // 1. Reduire le volume sanguin a 10%
    float maxBlood = dmg.GetBloodHitZone().GetMaxHealth();
    dmg.GetBloodHitZone().SetHealth(maxBlood * 0.10);
    Print("[Starvation] Volume sanguin reduit a 10%.");

    // 2. Forcer l'inconscience
    dmg.ForceUnconsciousness();
    Print("[Starvation] Joueur mis inconscient par famine - OK.");
}

}
