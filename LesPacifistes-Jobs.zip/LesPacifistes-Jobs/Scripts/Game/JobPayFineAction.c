//------------------------------------------------------------------------------------------------
// JobPayFineAction.c
// Action "F - Payer l'amende de X capsules"
// Visible quand le joueur local a une amende impayee emise par le joueur cible (flic/militaire)
// A placer sur les joueurs (cibles = flic/militaire, userEntity = victime qui paie)
//------------------------------------------------------------------------------------------------

class JobPayFineAction : ScriptedUserAction
{
	const float MAX_DISTANCE = 2.0;
	
	//------------------------------------------------------------------------------------------------
	override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
	{
		if (!pOwnerEntity || !pUserEntity)
			return;
		
		PlayerController localPC = GetGame().GetPlayerController();
		if (!localPC)
			return;
		IEntity localEntity = localPC.GetControlledEntity();
		if (localEntity != pUserEntity)
			return;
		
		// pOwnerEntity = flic cible, on envoie son playerId au serveur pour le paiement
		int officerPlayerId = GetGame().GetPlayerManager().GetPlayerIdFromControlledEntity(pOwnerEntity);
		if (officerPlayerId <= 0)
			return;
		
		JobPlayerComponent jpc = JobPlayerComponent.Cast(localPC.FindComponent(JobPlayerComponent));
		if (jpc)
			jpc.ClientAskPayFine(officerPlayerId);
	}
	
	//------------------------------------------------------------------------------------------------
	// Visible uniquement si:
	//  - la cible est un flic/militaire
	//  - le joueur local a une amende impayee emise par cette cible
	// Note: on ne peut pas verifier le casier cote client (pas d'acces au manager serveur),
	// donc on se contente de verifier le metier du porteur de l'action (la cible).
	// Le serveur filtrera si aucune amende n'est due.
	//------------------------------------------------------------------------------------------------
	//------------------------------------------------------------------------------------------------
	// L action n est visible que si la cible visee est POLICIER ou MILITAIRE.
	// Grace au RplProp sur JobPlayerComponent, le metier de la cible est accessible
	// cote client a tous les joueurs.
	//
	// IMPORTANT : le porteur de l action (GetOwner) est le CHARACTER de la cible.
	// JobPlayerComponent est attache au PlayerController, pas au character. Il faut donc
	// resoudre le PlayerController de la cible via GetPlayerIdFromControlledEntity.
	//------------------------------------------------------------------------------------------------
	//------------------------------------------------------------------------------------------------
	// L action n est visible que si la cible visee est POLICIER ou MILITAIRE.
	// On lit le metier via JobCharacterJobComponent place sur le character du joueur cible
	// (RplProp visible par tous les clients, contrairement aux components du PlayerController
	// qui ne sont accessibles que par leur owner).
	//------------------------------------------------------------------------------------------------
	override bool CanBeShownScript(IEntity user)
	{
		if (!user)
			return false;
		
		// La cible visee : c est le porteur de l action (GetOwner = character)
		IEntity targetChar = GetOwner();
		if (!targetChar)
			return false;
		
		// Ne pas voir l action sur soi-meme
		if (targetChar == user)
			return false;
		
		// Recupere le metier de la cible directement via le CharacterJobComponent
		// attache au character du joueur cible (synchronise via RplProp a tous les clients)
		JobCharacterJobComponent jobComp = JobCharacterJobComponent.Cast(
			targetChar.FindComponent(JobCharacterJobComponent));
		if (!jobComp)
			return false;
		
		EJobType targetJob = jobComp.GetJob();
		return (targetJob == EJobType.POLICIER || targetJob == EJobType.MILITAIRE);
	}
	
	//------------------------------------------------------------------------------------------------
	override bool CanBePerformedScript(IEntity user)
	{
		if (!user)
			return false;
		
		IEntity owner = GetOwner();
		if (!owner)
			return false;
		
		float dist = vector.Distance(user.GetOrigin(), owner.GetOrigin());
		return dist <= MAX_DISTANCE;
	}
	
	//------------------------------------------------------------------------------------------------
	// Label dynamique (mais on ne peut pas savoir le montant cote client sans replication)
	// On met un label generique - le serveur precisera via notification
	//------------------------------------------------------------------------------------------------
	override bool GetActionNameScript(out string outName)
	{
		outName = "Payer une amende";
		return true;
	}
}
