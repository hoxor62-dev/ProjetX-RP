//------------------------------------------------------------------------------------------------
// JobPoliceDoorComponent.c
// Component a attacher sur chaque porte du batiment Villa_E_2I01_Police.
// Stocke l etat (verrouille / deverrouille) via RplProp pour qu il soit visible
// par tous les clients (pour qu ils voient l action contextuelle correcte).
//
// Logique :
//   - L action serveur "Verrouiller" set m_Locked = true et bloque la porte
//   - L action serveur "Deverrouiller" set m_Locked = false et debloque
//   - L etat est replique a tous les clients via RplProp
//------------------------------------------------------------------------------------------------

class JobPoliceDoorComponentClass : ScriptComponentClass
{
}

class JobPoliceDoorComponent : ScriptComponent
{
	// Etat de verrouillage replique a tous les clients
	[RplProp()]
	bool m_Locked = false;
	
	//------------------------------------------------------------------------------------------------
	bool IsLocked()
	{
		return m_Locked;
	}
	
	//------------------------------------------------------------------------------------------------
	// SERVEUR : verrouille ou deverrouille la porte.
	//
	// Le vrai blocage de l ouverture est fait dans JobModdedDoorUserAction (modded class SCR_DoorUserAction)
	// qui retourne false dans CanBeShownScript/CanBePerformedScript quand cette porte est verrouillee.
	//
	// On se contente ici de :
	//   - Stocker l etat verrouille via RplProp (visible cote client pour les CanBeShown des actions)
	//   - Fermer la porte immediatement quand on verrouille (au cas ou elle etait ouverte)
	//------------------------------------------------------------------------------------------------
	void ServerSetLocked(bool locked)
	{
		if (!Replication.IsServer())
			return;
		m_Locked = locked;
		Replication.BumpMe();
		
		// Si on verrouille : ferme la porte si elle etait ouverte
		if (locked)
		{
			IEntity door = GetOwner();
			if (!door)
				return;
			BaseDoorComponent doorComp = BaseDoorComponent.Cast(door.FindComponent(BaseDoorComponent));
			if (doorComp && (doorComp.IsOpen() || doorComp.IsOpening()))
				doorComp.SetControlValue(0.0, RplId.Invalid());
		}
	}
}
