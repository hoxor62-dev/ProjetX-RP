//------------------------------------------------------------------------------------------------
// JobBlankKeyManager.c
// Manager singleton ISOLE pour la distribution des clefs vierges aux joueurs.
//
// IMPORTANT : ce manager est SEPARE de JobVirtualGarageManager pour eviter tout
// risque de casser le systeme de garage virtuel (qui sauvegarde des donnees critiques).
// Pas de persistance JSON ici - cooldown volatile en memoire (reset au reboot).
//------------------------------------------------------------------------------------------------

class JobBlankKeyManager
{
	static ref JobBlankKeyManager s_Instance;
	
	// Resource a spawn (CarKey)
	const string BLANK_KEY_PREFAB = "{CCFD8AA837B9611A}Prefabs/Items/CarKey/CarKey.et";
	const int COOLDOWN_SECONDS = 1800;  // 30 minutes
	
	// Cle = UID du joueur, Valeur = timestamp Unix de la derniere distribution
	ref map<string, int> m_Cooldowns;
	
	//------------------------------------------------------------------------------------------------
	void JobBlankKeyManager()
	{
		m_Cooldowns = new map<string, int>();
	}
	
	//------------------------------------------------------------------------------------------------
	static JobBlankKeyManager GetInstance()
	{
		if (!s_Instance)
			s_Instance = new JobBlankKeyManager();
		return s_Instance;
	}
	
	//------------------------------------------------------------------------------------------------
	// Verifie le cooldown du joueur.
	// Si le cooldown est ecoule (ou premiere fois), marque le timestamp et retourne 0.
	// Sinon retourne le nombre de secondes restantes.
	//------------------------------------------------------------------------------------------------
	int RequestKey(string playerUID)
	{
		if (playerUID == "")
			return 1;
		
		int now = System.GetUnixTime();
		int lastTime;
		if (m_Cooldowns.Find(playerUID, lastTime))
		{
			int elapsed = now - lastTime;
			if (elapsed < COOLDOWN_SECONDS)
				return COOLDOWN_SECONDS - elapsed;
		}
		
		m_Cooldowns.Set(playerUID, now);
		return 0;
	}
}
