//------------------------------------------------------------------------------------------------
// LP_VendeurVetementsShopAction.c
//
// Action "Ouvrir boutique Vetements" a placer sur une entite dediee via Workbench
// (comptoir / mannequin / portant de boutique).
//
// Visible UNIQUEMENT si le joueur a le metier VENDEUR_VETEMENTS.
// Ouvre JobShopMenu avec la catalog VENDEUR_VETEMENTS (vestes 50 caps + pantalons 45 caps,
// classes en 6 categories : Vestes Gang / Militaire / Style, Pantalons Gang / Militaire / Style).
//------------------------------------------------------------------------------------------------

class LP_VendeurVetementsShopAction : ScriptedUserAction
{
	//------------------------------------------------------------------------------------------------
	// Visible seulement si le joueur a le metier VENDEUR_VETEMENTS
	//------------------------------------------------------------------------------------------------
	override bool CanBeShownScript(IEntity user)
	{
		if (!user) return false;

		JobCharacterJobComponent jcjc = JobCharacterJobComponent.Cast(
			user.FindComponent(JobCharacterJobComponent));
		if (!jcjc) return false;

		return jcjc.GetJob() == EJobType.VENDEUR_VETEMENTS;
	}

	//------------------------------------------------------------------------------------------------
	override bool CanBePerformedScript(IEntity user)
	{
		return CanBeShownScript(user);
	}

	//------------------------------------------------------------------------------------------------
	override bool GetActionNameScript(out string outName)
	{
		outName = "Ouvrir boutique Vetements";
		return true;
	}

	//------------------------------------------------------------------------------------------------
	// Ouvre JobShopMenu avec le catalog VENDEUR_VETEMENTS
	//------------------------------------------------------------------------------------------------
	override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
	{
		// Ne s'execute que pour le joueur local (sinon ouvre le menu chez tout le monde)
		PlayerController localPC = PlayerController.Cast(GetGame().GetPlayerController());
		if (!localPC) return;
		if (pUserEntity != localPC.GetControlledEntity()) return;

		// Re-check metier cote client (CanBeShownScript peut etre contourne)
		JobCharacterJobComponent jcjc = JobCharacterJobComponent.Cast(
			pUserEntity.FindComponent(JobCharacterJobComponent));
		if (!jcjc || jcjc.GetJob() != EJobType.VENDEUR_VETEMENTS)
			return;

		// Recupere le RplId de l entite proprietaire de l action (tracking)
		RplId npcRplId = RplId.Invalid();
		if (pOwnerEntity)
		{
			RplComponent rpl = RplComponent.Cast(pOwnerEntity.FindComponent(RplComponent));
			if (rpl)
				npcRplId = rpl.Id();
		}

		// Ouvre JobShopMenu avec le catalog VENDEUR_VETEMENTS
		JobShopMenu shop = JobShopMenu.Cast(
			GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.JobShopMenu));
		if (shop)
			shop.Initialize(EJobType.VENDEUR_VETEMENTS, npcRplId);
	}
}
