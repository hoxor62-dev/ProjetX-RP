//------------------------------------------------------------------------------------------------
// JobToolCheck.c
// Helper pour verifier qu'un joueur possede un outil specifique (pioche, hache).
// 
// Approche pragmatique : on verifie la presence de l'outil dans l'inventaire du joueur via
// SCR_InventoryStorageManagerComponent et la comparaison du prefab name.
//
// L'outil n'a pas besoin d'etre "en main", mais doit etre present dans l'inventaire.
// Cette approche est plus fiable techniquement que la verification stricte "en main"
// (qui necessite de tracer les slots HandWeapon ou Gadget de Reforger).
//
// Outils:
//  - Pioche standard  : {CFB03731B536D8A4}Prefabs/Items/Equipment/Accessories/ETool_ALICE/Pick2.et
//  - Pioche amelioree : {FDD8619861328520}Prefabs/Items/Equipment/Accessories/ETool_ALICE/Pioche2.et
//    (les 2 sont valides pour miner - la Pioche amelioree double aussi les bonus de drops)
//  - Hache            : {10066BA2DCD677D3}Prefabs/Items/Equipment/Accessories/ETool_ALICE/Hache.et
//  - Hache amelioree  : {D723CC9DC095D176}Prefabs/Items/Equipment/Accessories/ETool_ALICE/Hache2.et
//    (les 2 sont valides pour couper - la Hache amelioree donne aussi +25% de bois bonus)
//------------------------------------------------------------------------------------------------

class JobToolCheck
{
	// Prefab GUIDs des outils requis
	static const string PICKAXE_PREFAB  = "{CFB03731B536D8A4}Prefabs/Items/Equipment/Accessories/ETool_ALICE/Pick2.et";
	static const string PICKAXE2_PREFAB = "{FDD8619861328520}Prefabs/Items/Equipment/Accessories/ETool_ALICE/Pioche2.et";
	static const string AXE_PREFAB      = "{10066BA2DCD677D3}Prefabs/Items/Equipment/Accessories/ETool_ALICE/Hache.et";
	static const string AXE2_PREFAB     = "{D723CC9DC095D176}Prefabs/Items/Equipment/Accessories/ETool_ALICE/Hache2.et";
	static const string PHONE_PREFAB    = "{F01C74E1B289DFF2}Prefabs/Items/InventoryItems/Electronics/Iphone15.et";
	
	//------------------------------------------------------------------------------------------------
	// Verifie si le joueur a un telephone (iPhone) dans son inventaire
	//------------------------------------------------------------------------------------------------
	static bool HasPhone(IEntity character)
	{
		return HasItemWithPrefab(character, PHONE_PREFAB);
	}
	
	//------------------------------------------------------------------------------------------------
	// Verifie si le joueur a une pioche dans son inventaire.
	// Accepte la pioche standard OU la pioche amelioree (Pioche2).
	//------------------------------------------------------------------------------------------------
	static bool HasPickaxe(IEntity character)
	{
		return HasItemWithPrefab(character, PICKAXE_PREFAB)
			|| HasItemWithPrefab(character, PICKAXE2_PREFAB);
	}
	
	//------------------------------------------------------------------------------------------------
	// Verifie si le joueur a une hache dans son inventaire.
	// Accepte la hache standard OU la hache amelioree (Hache2).
	//------------------------------------------------------------------------------------------------
	static bool HasAxe(IEntity character)
	{
		return HasItemWithPrefab(character, AXE_PREFAB)
			|| HasItemWithPrefab(character, AXE2_PREFAB);
	}

	//------------------------------------------------------------------------------------------------
	// Verifie specifiquement si le joueur a la Hache amelioree (Hache2).
	// Utilise pour le bonus +25% de bois lors de l extraction.
	//------------------------------------------------------------------------------------------------
	static bool HasAxe2(IEntity character)
	{
		return HasItemWithPrefab(character, AXE2_PREFAB);
	}
	
	//------------------------------------------------------------------------------------------------
	// Verifie l'outil requis pour un type de minerai donne
	// Renvoie true si pas d outil necessaire OU si outil present
	//------------------------------------------------------------------------------------------------
	static bool HasRequiredToolForMineral(IEntity character, EMineralType type)
	{
		switch (type)
		{
			case EMineralType.ROCK:     return HasPickaxe(character);
			case EMineralType.WOOD:     return HasAxe(character);
			case EMineralType.APPLE:    return true;  // pas d outil
			case EMineralType.CANNABIS: return true;  // pas d outil
			case EMineralType.COCAINE:  return true;  // pas d outil
			case EMineralType.WHEAT:    return true;  // pas d outil
		}
		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	// Renvoie le nom de l'outil requis pour les messages d'erreur
	//------------------------------------------------------------------------------------------------
	static string GetRequiredToolName(EMineralType type)
	{
		switch (type)
		{
			case EMineralType.ROCK:     return "une pioche";
			case EMineralType.WOOD:     return "une hache";
		}
		return "";
	}
	
	//------------------------------------------------------------------------------------------------
	// Verifie la presence d'un item dans l'inventaire du joueur via prefab name
	//------------------------------------------------------------------------------------------------
	static bool HasItemWithPrefab(IEntity character, string prefabName)
	{
		if (!character || prefabName == "")
			return false;
		
		SCR_InventoryStorageManagerComponent inv = SCR_InventoryStorageManagerComponent.Cast(
			character.FindComponent(SCR_InventoryStorageManagerComponent));
		if (!inv)
			return false;
		
		// Recupere tous les items dans l'inventaire (recursif)
		array<IEntity> allItems = new array<IEntity>();
		inv.GetItems(allItems);
		
		foreach (IEntity item : allItems)
		{
			if (!item)
				continue;
			EntityPrefabData prefabData = item.GetPrefabData();
			if (!prefabData)
				continue;
			ResourceName itemPrefab = prefabData.GetPrefabName();
			if (itemPrefab == prefabName)
				return true;
		}
		
		return false;
	}
}
