//------------------------------------------------------------------------------------------------
// JobMedicalData.c
//
// Types utilises par le systeme "Fiche medicale patient" (accessible uniquement Medecins).
// Parallele a la fiche judiciaire, mais focus sur la sante et l historique medical.
//
// Sections gerees :
//   - Identite (nom RP, DDN, sexe, n dossier auto-genere, groupe sanguin)
//   - Etat de sante (Vie, Sang auto-sync + 7 autres champs manuels)
//   - Informations medicales (allergies, maladies, traitements)
//   - Historique des soins (SoinRecord)
//   - Hospitalisations (HospitalizationRecord + comptes rendus + ordonnances)
//   - Journal des actions (JournalEntry - auto)
//------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------------------
// SEXE
//------------------------------------------------------------------------------------------------
enum EPatientSex
{
	UNKNOWN = 0,
	MALE = 1,
	FEMALE = 2,
	OTHER = 3
}

class JobPatientSexHelper
{
	static string GetLabel(EPatientSex s)
	{
		switch (s)
		{
			case EPatientSex.MALE:    return "Masculin";
			case EPatientSex.FEMALE:  return "Feminin";
			case EPatientSex.OTHER:   return "Autre";
		}
		return "Non renseigne";
	}
}

//------------------------------------------------------------------------------------------------
// GROUPE SANGUIN (8 groupes classiques)
//------------------------------------------------------------------------------------------------
enum EBloodType
{
	UNKNOWN = 0,
	A_POS = 1,
	A_NEG = 2,
	B_POS = 3,
	B_NEG = 4,
	AB_POS = 5,
	AB_NEG = 6,
	O_POS = 7,
	O_NEG = 8
}

class JobBloodTypeHelper
{
	static string GetLabel(EBloodType b)
	{
		switch (b)
		{
			case EBloodType.A_POS:  return "A+";
			case EBloodType.A_NEG:  return "A-";
			case EBloodType.B_POS:  return "B+";
			case EBloodType.B_NEG:  return "B-";
			case EBloodType.AB_POS: return "AB+";
			case EBloodType.AB_NEG: return "AB-";
			case EBloodType.O_POS:  return "O+";
			case EBloodType.O_NEG:  return "O-";
		}
		return "Inconnu";
	}
}

//------------------------------------------------------------------------------------------------
// ETAT DE SANTE - toutes les mesures medicales du patient
//------------------------------------------------------------------------------------------------
class HealthState
{
	// Auto-syncable depuis SurvivalHUD
	int m_LifePercent;           // Vie (%) - 0-100
	int m_BloodPercent;          // Sang (%) - 0-100
	int m_LastSyncTimestamp;     // Unix time de la derniere synchro
	
	// Manuels (saisis par le medecin)
	int m_Fractures;             // Nombre de fractures
	int m_Hemorrhages;           // Nombre d hemorragies
	int m_PainLevel;             // Niveau de douleur 0-10
	float m_Temperature;         // Temperature en degres C (ex: 37.5)
	int m_Pulse;                 // Pouls (bpm)
	string m_BloodPressure;      // Tension (texte libre, ex: "120/80")
	int m_OxygenSaturation;      // Saturation O2 (%)
	
	void HealthState()
	{
		m_LifePercent = 100;
		m_BloodPercent = 100;
		m_LastSyncTimestamp = 0;
		m_Fractures = 0;
		m_Hemorrhages = 0;
		m_PainLevel = 0;
		m_Temperature = 37.0;
		m_Pulse = 70;
		m_BloodPressure = "";
		m_OxygenSaturation = 98;
	}
}

//------------------------------------------------------------------------------------------------
// SoinRecord - un acte de soin
//------------------------------------------------------------------------------------------------
class SoinRecord
{
	int m_Timestamp;             // Unix time de l acte
	string m_MedecinName;        // Nom RP du medecin intervenant
	string m_MedecinUID;         // UID persistant du medecin
	string m_Motif;              // Motif de la consultation
	string m_Diagnostic;         // Diagnostic pose
	string m_SoinsRealises;      // Soins realises (texte libre)
	string m_Medicaments;        // Medicaments administres
	int m_Cout;                  // Cout en capsules (0 = gratuit)
	
	void SoinRecord()
	{
		m_Timestamp = 0;
		m_MedecinName = "";
		m_MedecinUID = "";
		m_Motif = "";
		m_Diagnostic = "";
		m_SoinsRealises = "";
		m_Medicaments = "";
		m_Cout = 0;
	}
}

//------------------------------------------------------------------------------------------------
// HospitalizationRecord - une hospitalisation
//------------------------------------------------------------------------------------------------
class HospitalizationRecord
{
	string m_Chambre;            // N chambre (ex: "B-12")
	int m_EntryTimestamp;        // Date d entree
	int m_ExitTimestamp;         // Date de sortie (0 = en cours)
	string m_MedecinName;        // Medecin responsable
	string m_MedecinUID;
	string m_CompteRendu;        // Compte rendu (texte libre)
	string m_Ordonnance;         // Ordonnance a la sortie
	bool m_Active;               // true = hospitalisation en cours
	
	void HospitalizationRecord()
	{
		m_Chambre = "";
		m_EntryTimestamp = 0;
		m_ExitTimestamp = 0;
		m_MedecinName = "";
		m_MedecinUID = "";
		m_CompteRendu = "";
		m_Ordonnance = "";
		m_Active = true;
	}
	
	// True si l hospitalisation est en cours
	bool IsActive()
	{
		return m_Active && m_ExitTimestamp == 0;
	}
}

//------------------------------------------------------------------------------------------------
// JournalEntry - une entree dans le journal des actions (auto)
//------------------------------------------------------------------------------------------------
enum EJournalActionType
{
	CREATION = 0,           // Creation du dossier
	MODIFICATION = 1,       // Modification champ manuel
	CONSULTATION = 2,       // Consultation par un EMS
	PRESCRIPTION = 3,       // Prescription (soin ajoute)
	HOSPITALIZATION = 4,    // Hospitalisation debutee
	EXIT_HOSPITAL = 5,      // Sortie d hospitalisation
	SYNC = 6                // Sync depuis SurvivalHUD
}

class JobJournalActionHelper
{
	static string GetLabel(EJournalActionType t)
	{
		switch (t)
		{
			case EJournalActionType.CREATION:        return "Creation";
			case EJournalActionType.MODIFICATION:    return "Modification";
			case EJournalActionType.CONSULTATION:    return "Consultation";
			case EJournalActionType.PRESCRIPTION:    return "Prescription";
			case EJournalActionType.HOSPITALIZATION: return "Hospitalisation";
			case EJournalActionType.EXIT_HOSPITAL:   return "Sortie hopital";
			case EJournalActionType.SYNC:            return "Sync sante";
		}
		return "?";
	}
}

class JournalEntry
{
	EJournalActionType m_Type;
	int m_Timestamp;
	string m_Description;        // Texte descriptif de l action
	string m_AuthorName;         // Nom RP du medecin auteur (peut etre "SYSTEME")
	string m_AuthorUID;
	
	void JournalEntry()
	{
		m_Type = EJournalActionType.CREATION;
		m_Timestamp = 0;
		m_Description = "";
		m_AuthorName = "";
		m_AuthorUID = "";
	}
}

//------------------------------------------------------------------------------------------------
// MedicalRecord - le dossier medical complet d un patient
//------------------------------------------------------------------------------------------------
class MedicalRecord
{
	// === Identite ===
	string m_PatientUID;              // UID persistant
	string m_PatientName;              // Nom RP
	string m_DateOfBirth;              // Date de naissance (texte libre)
	EPatientSex m_Sex;                 // Sexe
	string m_FileNumber;               // N dossier auto-genere (P-0001, P-0002, ...)
	EBloodType m_BloodType;            // Groupe sanguin
	int m_CreationTimestamp;           // Date de creation du dossier
	
	// === Etat de sante (encapsule dans HealthState) ===
	ref HealthState m_Health;
	
	// === Informations medicales ===
	string m_Allergies;                // Texte libre
	string m_KnownDiseases;            // Maladies connues (texte libre)
	string m_CurrentTreatments;        // Traitements en cours (texte libre)
	
	// === Historique des soins ===
	ref array<ref SoinRecord> m_Soins;
	
	// === Hospitalisations ===
	ref array<ref HospitalizationRecord> m_Hospitalizations;
	
	// === Journal des actions (auto) ===
	ref array<ref JournalEntry> m_Journal;
	
	void MedicalRecord()
	{
		m_PatientUID = "";
		m_PatientName = "";
		m_DateOfBirth = "";
		m_Sex = EPatientSex.UNKNOWN;
		m_FileNumber = "";
		m_BloodType = EBloodType.UNKNOWN;
		m_CreationTimestamp = 0;
		m_Health = new HealthState();
		m_Allergies = "";
		m_KnownDiseases = "";
		m_CurrentTreatments = "";
		m_Soins = new array<ref SoinRecord>();
		m_Hospitalizations = new array<ref HospitalizationRecord>();
		m_Journal = new array<ref JournalEntry>();
	}
	
	//------------------------------------------------------------------------------------------------
	// Helpers d agregation
	//------------------------------------------------------------------------------------------------
	
	// True si le patient a une hospitalisation actuellement en cours
	bool HasActiveHospitalization()
	{
		foreach (HospitalizationRecord h : m_Hospitalizations)
		{
			if (h && h.IsActive())
				return true;
		}
		return false;
	}
	
	// Retourne l hospitalisation active ou null
	HospitalizationRecord GetActiveHospitalization()
	{
		foreach (HospitalizationRecord h : m_Hospitalizations)
		{
			if (h && h.IsActive())
				return h;
		}
		return null;
	}
	
	// Nombre total d actes de soin
	int GetSoinCount()
	{
		return m_Soins.Count();
	}
}
