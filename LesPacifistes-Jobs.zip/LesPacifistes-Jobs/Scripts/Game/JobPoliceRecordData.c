//------------------------------------------------------------------------------------------------
// JobPoliceRecordData.c
//
// Types utilises par le systeme "Fiche judiciaire avancee" du commissariat.
// Ce systeme est PARALLELE a la fiche criminelle existante (CriminalRecord/FineRecord)
// et l enrichit avec :
//   - Statut manuel (Libre / Prison / Cavale / Recherche / Cond.)
//   - Peines en cours (SentenceRecord) : chef d accusation + date fin + officier emetteur
//   - Mandats en cours (WarrantRecord) : type (perquisition/interpellation/arrestation)
//   - Notes officiers (OfficerNote) : observations libres avec auteur/timestamp
//   - Rehabilitation automatique (derniere condamnation + REHAB_YEARS annees)
//
// Note : les INFRACTIONS reutilisent FineRecord + les nouveaux champs m_Gravity et m_Evidence
// qui seront ajoutes en Phase 4.
//------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------------------
// STATUT JUDICIAIRE (manuel, defini par un officier via le menu)
//------------------------------------------------------------------------------------------------
enum EJudicialStatus
{
	FREE = 0,           // Libre (defaut)
	IN_PRISON = 1,      // En prison
	FUGITIVE = 2,       // En cavale
	WANTED = 3,         // Recherche
	PROBATION = 4       // En liberte conditionnelle
}

class JobJudicialStatusHelper
{
	static string GetLabel(EJudicialStatus s)
	{
		switch (s)
		{
			case EJudicialStatus.FREE:       return "Libre";
			case EJudicialStatus.IN_PRISON:  return "En prison";
			case EJudicialStatus.FUGITIVE:   return "En cavale";
			case EJudicialStatus.WANTED:     return "Recherche";
			case EJudicialStatus.PROBATION:  return "Liberte conditionnelle";
		}
		return "Inconnu";
	}
	
	// Couleur suggeree (RGB 0-1) pour affichage UI
	static void GetColor(EJudicialStatus s, out float r, out float g, out float b)
	{
		switch (s)
		{
			case EJudicialStatus.FREE:      { r = 0.50; g = 0.90; b = 0.50; return; }  // vert
			case EJudicialStatus.IN_PRISON: { r = 0.95; g = 0.75; b = 0.20; return; }  // orange
			case EJudicialStatus.FUGITIVE:  { r = 1.00; g = 0.30; b = 0.30; return; }  // rouge vif
			case EJudicialStatus.WANTED:    { r = 0.95; g = 0.40; b = 0.20; return; }  // rouge-orange
			case EJudicialStatus.PROBATION: { r = 0.85; g = 0.85; b = 0.50; return; }  // jaune
		}
		r = 0.7; g = 0.7; b = 0.7;
	}
}

//------------------------------------------------------------------------------------------------
// TYPE DE MANDAT
//------------------------------------------------------------------------------------------------
enum EWarrantType
{
	SEARCH = 0,         // Perquisition
	INTERROGATION = 1,  // Interpellation
	ARREST = 2          // Arrestation
}

class JobWarrantTypeHelper
{
	static string GetLabel(EWarrantType t)
	{
		switch (t)
		{
			case EWarrantType.SEARCH:        return "Perquisition";
			case EWarrantType.INTERROGATION: return "Interpellation";
			case EWarrantType.ARREST:        return "Arrestation";
		}
		return "Inconnu";
	}
}

//------------------------------------------------------------------------------------------------
// GRAVITE d une infraction (utilise avec FineRecord en Phase 4)
//------------------------------------------------------------------------------------------------
enum EInfractionGravity
{
	MINOR = 0,          // Vert - infraction mineure
	MODERATE = 1,       // Jaune - moderee
	SERIOUS = 2,        // Orange - grave
	CRITICAL = 3        // Rouge - criminelle
}

class JobInfractionGravityHelper
{
	static string GetLabel(EInfractionGravity g)
	{
		switch (g)
		{
			case EInfractionGravity.MINOR:    return "Mineure";
			case EInfractionGravity.MODERATE: return "Moderee";
			case EInfractionGravity.SERIOUS:  return "Grave";
			case EInfractionGravity.CRITICAL: return "Criminelle";
		}
		return "Inconnue";
	}
	
	static string GetColorTag(EInfractionGravity g)
	{
		switch (g)
		{
			case EInfractionGravity.MINOR:    return "[V]";  // vert
			case EInfractionGravity.MODERATE: return "[J]";  // jaune
			case EInfractionGravity.SERIOUS:  return "[O]";  // orange
			case EInfractionGravity.CRITICAL: return "[R]";  // rouge
		}
		return "[?]";
	}
}

//------------------------------------------------------------------------------------------------
// SentenceRecord : une condamnation (peine) en cours ou historique
//   - Duree (jours) et timestamp d entree = permet de calculer la date de fin
//   - "chef d accusation" = motif RP en texte libre
//   - IssuerName = nom RP de l officier emetteur
//   - IssuerUID = UID persistant pour audit
//------------------------------------------------------------------------------------------------
class SentenceRecord
{
	string m_Charge;                // Chef d accusation (texte libre)
	int m_IssuedTimestamp;          // Unix time d emission
	int m_DurationDays;             // Duree en JOURS (0 = perpetuite / a vie)
	bool m_Active;                  // true = en cours, false = purgee
	string m_IssuerName;            // Nom RP de l officier
	string m_IssuerUID;             // UID persistant de l officier
	
	void SentenceRecord()
	{
		m_Charge = "";
		m_IssuedTimestamp = 0;
		m_DurationDays = 0;
		m_Active = true;
		m_IssuerName = "";
		m_IssuerUID = "";
	}
	
	// Retourne le timestamp de fin (issued + duree). 0 si a vie.
	int GetEndTimestamp()
	{
		if (m_DurationDays <= 0)
			return 0;  // perpetuite
		return m_IssuedTimestamp + (m_DurationDays * 86400);
	}
	
	// Retourne les jours restants (0 si purgee, -1 si a vie)
	int GetDaysRemaining(int now)
	{
		if (m_DurationDays <= 0)
			return -1;  // perpetuite
		int end = GetEndTimestamp();
		if (now >= end)
			return 0;
		return (end - now) / 86400;
	}
}

//------------------------------------------------------------------------------------------------
// WarrantRecord : un mandat en cours
//   - Type (perquisition/interpellation/arrestation)
//   - Valide jusqu au timestamp m_ExpiresTimestamp (0 = pas d expiration)
//------------------------------------------------------------------------------------------------
class WarrantRecord
{
	EWarrantType m_Type;
	string m_Motive;                // Motif du mandat (texte libre)
	int m_IssuedTimestamp;          // Unix time d emission
	int m_ExpiresTimestamp;         // Unix time d expiration (0 = pas d expiration)
	bool m_Active;                  // true = en cours, false = execute/annule
	string m_IssuerName;            // Nom RP officier
	string m_IssuerUID;             // UID persistant
	
	void WarrantRecord()
	{
		m_Type = EWarrantType.SEARCH;
		m_Motive = "";
		m_IssuedTimestamp = 0;
		m_ExpiresTimestamp = 0;
		m_Active = true;
		m_IssuerName = "";
		m_IssuerUID = "";
	}
	
	// True si le mandat est encore valide (actif ET pas expire)
	bool IsValid(int now)
	{
		if (!m_Active)
			return false;
		if (m_ExpiresTimestamp == 0)
			return true;  // pas d expiration
		return now < m_ExpiresTimestamp;
	}
}

//------------------------------------------------------------------------------------------------
// OfficerNote : une observation libre par un officier
//------------------------------------------------------------------------------------------------
class OfficerNote
{
	string m_Text;                  // Texte de la note
	int m_Timestamp;                // Unix time
	string m_AuthorName;            // Nom RP de l auteur
	string m_AuthorUID;             // UID persistant
	
	void OfficerNote()
	{
		m_Text = "";
		m_Timestamp = 0;
		m_AuthorName = "";
		m_AuthorUID = "";
	}
}

//------------------------------------------------------------------------------------------------
// PoliceRecord : le dossier judiciaire complet d un joueur
// SEPARE du CriminalRecord existant (pas de conflit). Persistance JSON dedie.
//------------------------------------------------------------------------------------------------
class PoliceRecord
{
	string m_PlayerUID;                       // UID persistant du joueur
	string m_PlayerName;                      // Dernier nom RP connu
	EJudicialStatus m_Status;                 // Statut manuel
	string m_StatusDetail;                    // Detail libre (ex: "Prison de Los Santos, cellule B-12")
	int m_LastConvictionTimestamp;            // Timestamp derniere condamnation (pour calcul rehab)
	
	ref array<ref SentenceRecord> m_Sentences; // Peines (actives + historique)
	ref array<ref WarrantRecord> m_Warrants;   // Mandats
	ref array<ref OfficerNote> m_Notes;        // Notes officiers
	
	void PoliceRecord()
	{
		m_PlayerUID = "";
		m_PlayerName = "";
		m_Status = EJudicialStatus.FREE;
		m_StatusDetail = "";
		m_LastConvictionTimestamp = 0;
		m_Sentences = new array<ref SentenceRecord>();
		m_Warrants = new array<ref WarrantRecord>();
		m_Notes = new array<ref OfficerNote>();
	}
	
	//------------------------------------------------------------------------------------------------
	// Helpers d agregation
	//------------------------------------------------------------------------------------------------
	
	// Compte les peines actives (non purgees)
	int GetActiveSentencesCount()
	{
		int c = 0;
		foreach (SentenceRecord s : m_Sentences)
		{
			if (s && s.m_Active)
				c++;
		}
		return c;
	}
	
	// Compte les mandats valides (actifs + non expires)
	int GetValidWarrantsCount(int now)
	{
		int c = 0;
		foreach (WarrantRecord w : m_Warrants)
		{
			if (w && w.IsValid(now))
				c++;
		}
		return c;
	}
}
