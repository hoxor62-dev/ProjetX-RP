//------------------------------------------------------------------------------------------------
// JobPochonBourseManager.c
// Singleton SERVEUR qui gere la BOURSE GLOBALE des pochons.
//
// Fonctionnement :
//   - Chaque pochon vendu au PNJ fait baisser le prix de 0.5% (baisse fixe)
//   - Plancher : 50% (le prix ne descend jamais en dessous de 50% du prix initial)
//   - Reset AUTOMATIQUE toutes les 48h (fenetre glissante depuis le 1er pochon vendu)
//   - Bourse GLOBALE : tous les joueurs partagent le meme pourcentage
//
// Persistance : fichier plat unique $profile:LesPacifistesJobs/pochon_bourse.json
//------------------------------------------------------------------------------------------------

class JobPochonBourseManager
{
	static ref JobPochonBourseManager s_Instance;
	
	// Constantes
	const float BAISSE_PAR_POCHON = 0.005;  // -0.5% par pochon
	const float PLANCHER_RATIO = 0.50;      // 50% minimum
	const int RESET_DELAY_S = 172800;       // 48h en secondes (48 * 3600)
	
	// Etat de la bourse
	int m_TotalPochonsSold = 0;   // pochons vendus dans la fenetre courante
	int m_WindowStartUnix = 0;    // timestamp Unix du 1er pochon vendu (0 = pas de fenetre)
	
	const string SAVE_FILE = "$profile:LesPacifistesJobs/pochon_bourse.json";
	bool m_Loaded = false;
	
	//------------------------------------------------------------------------------------------------
	static JobPochonBourseManager GetInstance()
	{
		if (!s_Instance)
		{
			s_Instance = new JobPochonBourseManager();
			s_Instance.LoadFromDisk();
		}
		return s_Instance;
	}
	
	//------------------------------------------------------------------------------------------------
	// Verifie si la fenetre 48h est ecoulee -> reset
	protected void RefreshWindow()
	{
		if (m_WindowStartUnix == 0) return;
		int now = System.GetUnixTime();
		if (now - m_WindowStartUnix >= RESET_DELAY_S)
		{
			// Reset a 100%
			m_WindowStartUnix = 0;
			m_TotalPochonsSold = 0;
			SaveToDisk();
			Print("[JobPochonBourse] Reset automatique 48h -> bourse remise a 100%", LogLevel.NORMAL);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Retourne le ratio courant de la bourse (0.5 a 1.0)
	// 1.0 = 100% (prix plein) / 0.5 = 50% (plancher)
	float GetCurrentRatio()
	{
		RefreshWindow();
		float ratio = 1.0 - (m_TotalPochonsSold * BAISSE_PAR_POCHON);
		if (ratio < PLANCHER_RATIO) ratio = PLANCHER_RATIO;
		if (ratio > 1.0) ratio = 1.0;
		return ratio;
	}
	
	//------------------------------------------------------------------------------------------------
	// Retourne le ratio en pourcentage entier (50 a 100)
	int GetCurrentPercent()
	{
		return GetCurrentRatio() * 100;
	}
	
	//------------------------------------------------------------------------------------------------
	// Retourne le prix unitaire courant d un pochon apres application du ratio bourse
	int GetCurrentUnitPrice()
	{
		return JobPochonData.PRIX_VENTE_POCHON * GetCurrentRatio();
	}
	
	//------------------------------------------------------------------------------------------------
	// Retourne le timestamp de fin de la fenetre courante (0 si pas de fenetre)
	int GetWindowEndUnix()
	{
		RefreshWindow();
		if (m_WindowStartUnix == 0) return 0;
		return m_WindowStartUnix + RESET_DELAY_S;
	}
	
	//------------------------------------------------------------------------------------------------
	// Enregistre une vente : ajoute au compteur global.
	// La 1re vente demarre la fenetre 48h.
	void RecordSale(int quantity)
	{
		if (quantity <= 0) return;
		RefreshWindow();
		
		if (m_WindowStartUnix == 0)
			m_WindowStartUnix = System.GetUnixTime();
		m_TotalPochonsSold = m_TotalPochonsSold + quantity;
		SaveToDisk();
	}
	
	//------------------------------------------------------------------------------------------------
	// PERSISTANCE - Fichier plat unique
	void SaveToDisk()
	{
		SCR_JsonSaveContext ctx = new SCR_JsonSaveContext();
		ctx.WriteValue("totalSold", m_TotalPochonsSold);
		ctx.WriteValue("windowStart", m_WindowStartUnix);
		ctx.SaveToFile(SAVE_FILE);
	}
	
	//------------------------------------------------------------------------------------------------
	void LoadFromDisk()
	{
		if (m_Loaded) return;
		m_Loaded = true;
		if (!FileIO.FileExists(SAVE_FILE)) return;
		
		SCR_JsonLoadContext ctx = new SCR_JsonLoadContext();
		if (!ctx.LoadFromFile(SAVE_FILE)) return;
		
		ctx.ReadValue("totalSold", m_TotalPochonsSold);
		ctx.ReadValue("windowStart", m_WindowStartUnix);
		
		// Verifie immediatement si la fenetre est deja expiree
		RefreshWindow();
		
		Print(string.Format("[JobPochonBourse] Charge : %1 pochons vendus, ratio actuel : %2%%",
			m_TotalPochonsSold.ToString(), GetCurrentPercent().ToString()), LogLevel.NORMAL);
	}
}
