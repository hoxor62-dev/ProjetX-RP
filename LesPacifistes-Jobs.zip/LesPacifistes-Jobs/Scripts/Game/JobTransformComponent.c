//------------------------------------------------------------------------------------------------
// JobTransformComponent.c
// A attacher sur les prefabs de transformation (table mineur, sechoir cannabis, labo cocaine,
// scierie pour le bois, presse pour la pomme, moulin pour le ble).
// Configure dans Workbench le type via l'attribut m_MineralType.
//
// Comportement :
//  - Le joueur appuie sur F sur le prefab
//  - Toutes les 10s : un item RAW est CONSOMME de l'inventaire et un item PROCESSED y est ajoute
//  - Si le joueur n'a plus d'item RAW, la transformation s'arrete
//  - Si le joueur s'eloigne >10m, la transformation se met en pause (reprise au retour)
//------------------------------------------------------------------------------------------------

[ComponentEditorProps(category: "LesPacifistesJobs", description: "Prefab de transformation des ressources brutes")]
class JobTransformComponentClass : ScriptComponentClass
{
}

class JobTransformComponent : ScriptComponent
{
	[Attribute(defvalue: "1", uiwidget: UIWidgets.ComboBox, desc: "Type de ressource transformee",
		enums: { ParamEnum("Roche", "1"), ParamEnum("Cannabis", "2"), ParamEnum("Cocaine", "3"),
			ParamEnum("Bois", "4"), ParamEnum("Pomme", "5"), ParamEnum("Ble", "6") })]
	int m_MineralType;
	
	//------------------------------------------------------------------------------------------------
	EMineralType GetMineralType()
	{
		return m_MineralType;
	}
}
