//------------------------------------------------------------------------------------------------
// JobCompanyDashboardMenu.c
// Menu Tableau de bord du patron : affiche les stats detaillees de son entreprise.
//
// Sections affichees :
//   - Nom entreprise + metier
//   - Benefices accumules
//   - Nombre total de ventes/bons valides
//   - Nombre de bons en attente
//   - Nombre d employes
//   - Top 3 employes les plus productifs (texte deja formate par le serveur)
//
// Pas d action ici : c est en lecture seule. Pour agir, le patron retourne au menu Acces.
//------------------------------------------------------------------------------------------------

class JobCompanyDashboardMenu : ChimeraMenuBase
{
	Widget m_RootWidget;
	TextWidget m_TitleText;
	TextWidget m_StatsText;
	EditBoxWidget m_InjectInput;
	ButtonWidget m_BtnInject;
	ButtonWidget m_BtnBack;
	
	static ref JobCompanyMenuPayload s_Payload;
	
	//------------------------------------------------------------------------------------------------
	static void SetPendingPayload(JobCompanyMenuPayload p)
	{
		s_Payload = p;
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuOpen()
	{
		super.OnMenuOpen();
		JobFocusHandler.ClearRegistry();
		
		m_RootWidget = GetRootWidget();
		if (!m_RootWidget)
			return;
		
		m_TitleText = TextWidget.Cast(m_RootWidget.FindAnyWidget("TitleText"));
		m_StatsText = TextWidget.Cast(m_RootWidget.FindAnyWidget("StatsText"));
		m_InjectInput = EditBoxWidget.Cast(m_RootWidget.FindAnyWidget("InjectInput"));
		m_BtnInject = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnInject"));
		m_BtnBack = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnBack"));
		
		BuildStatsText();
		
		if (m_BtnInject)
		{
			DashboardInjectHandler ih = new DashboardInjectHandler();
			ih.m_Menu = this;
			m_BtnInject.AddHandler(ih);
			JobFocusHandler.Attach(m_BtnInject);
		}
		
		if (m_BtnBack)
		{
			DashboardBackHandler h = new DashboardBackHandler();
			h.m_Menu = this;
			m_BtnBack.AddHandler(h);
			JobFocusHandler.Attach(m_BtnBack);
			GetGame().GetWorkspace().SetFocusedWidget(m_BtnBack);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuUpdate(float tDelta)
	{
		super.OnMenuUpdate(tDelta);
		if (GetGame().GetInputManager().GetActionValue("MenuBack") > 0.5)
			CloseMenuInternal();
	}
	
	//------------------------------------------------------------------------------------------------
	void OnInjectClicked()
	{
		if (!m_InjectInput) return;
		int amount = m_InjectInput.GetText().ToInt();
		if (amount <= 0)
			return;
		
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		jpc.ClientAskInjectCompanyBenefits(amount);
		// Ferme le menu pour eviter d injecter 2 fois ; le patron reviendra voir la mise a jour
		CloseMenuInternal();
	}
	
	//------------------------------------------------------------------------------------------------
	void BuildStatsText()
	{
		if (!s_Payload || !m_StatsText)
			return;
		
		string jobLabel = JobData.GetJobLabel(s_Payload.m_JobType);
		string s = "";
		s = s + string.Format("Nom               : %1\n", s_Payload.m_CompanyName);
		s = s + string.Format("Metier            : %1\n", jobLabel);
		s = s + "\n";
		s = s + string.Format("Cagnotte          : %1 capsules\n", s_Payload.m_Benefits.ToString());
		s = s + string.Format("Ventes totales    : %1\n", s_Payload.m_TotalSales.ToString());
		s = s + string.Format("Bons en attente   : %1\n", s_Payload.m_PendingOrderCount.ToString());
		s = s + string.Format("Total bons        : %1\n", s_Payload.m_TotalOrderCount.ToString());
		s = s + string.Format("Employes          : %1 / 5\n", s_Payload.m_EmployeeCount.ToString());
		s = s + "\n";
		s = s + "--- Top 3 employes (ventes) ---\n";
		if (s_Payload.m_Top3Text != "")
			s = s + s_Payload.m_Top3Text;
		else
			s = s + "Aucune vente pour l instant.";
		
		if (m_TitleText)
			m_TitleText.SetText(string.Format("Tableau de bord - %1", s_Payload.m_CompanyName));
		m_StatsText.SetText(s);
	}
	
	//------------------------------------------------------------------------------------------------
	void CloseMenuInternal()
	{
		GetGame().GetMenuManager().CloseMenu(this);
	}
}

//------------------------------------------------------------------------------------------------
class DashboardBackHandler : ScriptedWidgetEventHandler
{
	JobCompanyDashboardMenu m_Menu;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.CloseMenuInternal();
		return true;
	}
	override bool OnMouseButtonDown(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.CloseMenuInternal();
		return true;
	}
}

//------------------------------------------------------------------------------------------------
class DashboardInjectHandler : ScriptedWidgetEventHandler
{
	JobCompanyDashboardMenu m_Menu;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.OnInjectClicked();
		return true;
	}
}
