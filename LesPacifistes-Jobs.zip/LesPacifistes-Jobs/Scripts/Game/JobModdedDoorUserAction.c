//------------------------------------------------------------------------------------------------
// JobModdedDoorUserAction.c
// Modded class qui intercepte l action vanilla "Open door" / "Close door" sur les portes
// equipees d un composant de verrouillage (JobPoliceDoorComponent OU JobHospitalDoorComponent).
//
// Comportement :
//   - Si la porte a un de ces composants ET m_Locked = true :
//     -> L action d ouverture est CACHEE pour tous les joueurs
//     -> Resultat : impossible d ouvrir la porte, meme en spammant
//   - Si pas de composant de verrouillage (porte normale) ou non verrouillee :
//     -> Comportement vanilla (action visible et utilisable)
//
// Note : le filtrage metier (qui peut verrouiller/deverrouiller) est gere par les actions
// dediees (JobLockPoliceDoorAction, JobLockHospitalDoorAction, etc.). Ici on s occupe
// uniquement de cacher l action vanilla d ouverture quand la porte est verrouillee,
// peu importe par quel metier elle a ete verrouillee.
//------------------------------------------------------------------------------------------------

modded class SCR_DoorUserAction
{
	//------------------------------------------------------------------------------------------------
	// Retourne true si la porte est verrouillee par un des composants du mod
	// (police OU hopital). Centralise la verification pour eviter la duplication entre
	// CanBeShownScript et CanBePerformedScript.
	//------------------------------------------------------------------------------------------------
	bool IsDoorLockedByMod(IEntity door)
	{
		if (!door)
			return false;
		
		// Police / militaire (caserne et gendarmerie)
		JobPoliceDoorComponent policeDoor = JobPoliceDoorComponent.Cast(
			door.FindComponent(JobPoliceDoorComponent));
		if (policeDoor && policeDoor.IsLocked())
			return true;
		
		// Medecin (hopital)
		JobHospitalDoorComponent hospitalDoor = JobHospitalDoorComponent.Cast(
			door.FindComponent(JobHospitalDoorComponent));
		if (hospitalDoor && hospitalDoor.IsLocked())
			return true;
		
		// === Porte immobiliere (achetee par un joueur) ===
		LP_DoorAccessComponent lpDoor = LP_DoorAccessComponent.Cast(
			door.FindComponent(LP_DoorAccessComponent));
		if (lpDoor && lpDoor.IsLocked())
			return true;
		
		return false;
	}
	
	//------------------------------------------------------------------------------------------------
	override bool CanBeShownScript(IEntity user)
	{
		// Cache l action vanilla si la porte est verrouillee par un composant du mod
		if (IsDoorLockedByMod(GetOwner()))
			return false;
		
		// Comportement vanilla pour toutes les autres situations
		return super.CanBeShownScript(user);
	}
	
	//------------------------------------------------------------------------------------------------
	override bool CanBePerformedScript(IEntity user)
	{
		// Double securite : meme si l action etait quand meme triggerable, on bloque l execution
		if (IsDoorLockedByMod(GetOwner()))
			return false;
		
		return super.CanBePerformedScript(user);
	}
}
