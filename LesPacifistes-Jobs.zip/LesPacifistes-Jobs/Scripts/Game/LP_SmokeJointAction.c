//------------------------------------------------------------------------------------------------
// LP_SmokeJointAction.c
// Action "Fumer" a placer sur les joints via Workbench (ActionsManagerComponent).
// Ajoute du taux de THC au joueur via LP_CannabisManager.
//------------------------------------------------------------------------------------------------

class LP_SmokeJointAction : ScriptedUserAction
{
	[Attribute("25", UIWidgets.EditBox, "Quantite de THC ajoutee (%) - 100% = inconscient")]
	protected float m_fThcAmount;
	
	//------------------------------------------------------------------------------------------------
	override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
	{
		if (!Replication.IsServer()) return;
		
		int playerId = GetGame().GetPlayerManager().GetPlayerIdFromControlledEntity(pUserEntity);
		if (playerId <= 0) return;
		
		// Ajoute au taux de THC du joueur
		LP_CannabisManager.GetInstance().ServerAddThc(playerId, m_fThcAmount);
		
		// Supprime le joint consomme
		SCR_EntityHelper.DeleteEntityAndChildren(pOwnerEntity);
	}
	
	//------------------------------------------------------------------------------------------------
	override bool CanBePerformedScript(IEntity user)
	{
		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	override bool CanBeShownScript(IEntity user) { return true; }
	
	//------------------------------------------------------------------------------------------------
	override bool GetActionNameScript(out string outName)
	{
		outName = "Fumer";
		return true;
	}
}
