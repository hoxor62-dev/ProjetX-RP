//------------------------------------------------------------------------------------------------
// JobManager.c
// Singleton serveur qui gere:
//  - La persistence JSON par joueur ($profile:LesPacifistesJobs/player_<uid>.json)
//  - Le comptage cumule des secondes travaillees (metiers avances)
//  - Le versement automatique des salaires horaires via CapsuleEconomy
//  - Les notifications chat (prochaine paie, paiement recu)
//------------------------------------------------------------------------------------------------

class JobManager
{
	// Singleton
	static ref JobManager s_Instance;
	
	// Chemin de persistence
	const string JSON_FOLDER = "$profile:LesPacifistesJobs/";
	
	// Intervalle de tick serveur (verifie les paies toutes les 30s)
	const int TICK_INTERVAL_MS = 30000;
	
	// Notification "prochaine paie" (60min = 3600s, notif a 45min et 55min par ex.)
	const int SECONDS_PER_HOUR = 3600;
	const int NOTIFY_15MIN = 2700;  // 45 min travaillees = 15 min restantes
	const int NOTIFY_5MIN = 3300;   // 55 min travaillees = 5 min restantes
	
	// Cache runtime: playerId -> JobPlayerData
	ref map<int, ref JobPlayerData> m_PlayerDataCache = new map<int, ref JobPlayerData>();
	
	// Timestamp du dernier tick pour calculer le delta
	int m_LastTickTime = 0;
	
	//------------------------------------------------------------------------------------------------
	static JobManager GetInstance()
	{
		if (!s_Instance)
			s_Instance = new JobManager();
		return s_Instance;
	}
	
	//------------------------------------------------------------------------------------------------
	void JobManager()
	{
		Print("[JobManager] Initialisation du systeme de metiers", LogLevel.NORMAL);
		m_LastTickTime = System.GetTickCount();
		
		// Lance le tick serveur
		GetGame().GetCallqueue().CallLater(Tick, TICK_INTERVAL_MS, true);
		
		// Force l initialisation du JobMarketManager pour que les CallLater
		// (drift horaire + evenements 4h) se lancent des le boot serveur
		// (sinon le manager n est cree qu a la premiere vente, et survit mal aux reboots)
		JobMarketManager.GetInstance();
		Print("[JobManager] JobMarketManager force au boot", LogLevel.NORMAL);
		
		// Force l initialisation du JobRepairKitPurger (tick 10s qui retire les
		// RepairKit des inventaires des non-concessionnaires)
		JobRepairKitPurger.GetInstance();
		Print("[JobManager] JobRepairKitPurger force au boot", LogLevel.NORMAL);
		
		// Force l initialisation du JobVirtualGarageManager (charge le JSON des
		// vehicules stockes des joueurs depuis disque)
		JobVirtualGarageManager.GetInstance();
		Print("[JobManager] JobVirtualGarageManager force au boot", LogLevel.NORMAL);
		
		// Force l initialisation du JobCompanyManager (charge le JSON des entreprises)
		JobCompanyManager.GetInstance();
		Print("[JobManager] JobCompanyManager force au boot", LogLevel.NORMAL);
		
		// Force l initialisation du JobWhitelistManager (charge le JSON de whitelist).
		// Si le fichier n existe pas, un fichier exemple est cree.
		JobWhitelistManager.GetInstance().CreateExampleFileIfMissing();
		Print("[JobManager] JobWhitelistManager force au boot", LogLevel.NORMAL);
		
		// Force l initialisation du JobBonPointManager (charge annonces + achats + cagnotte + blacklist)
		JobBonPointManager.GetInstance();
		Print("[JobManager] JobBonPointManager force au boot", LogLevel.NORMAL);
		
		// Force l initialisation du JobInsuranceManager (cooldowns + tracking destruction)
		JobInsuranceManager.GetInstance();
		Print("[JobManager] JobInsuranceManager force au boot", LogLevel.NORMAL);
		
		// Force l initialisation du JobBraquageManager (braquage bijouterie)
		JobBraquageManager.GetInstance();
		Print("[JobManager] JobBraquageManager force au boot", LogLevel.NORMAL);
		
		// Force l initialisation du JobFonteManager (fonte en or)
		JobFonteManager.GetInstance();
		Print("[JobManager] JobFonteManager force au boot", LogLevel.NORMAL);
		
		// Force l initialisation du JobTresorManager (coffre au tresor sous-marin)
		JobTresorManager.GetInstance();
		Print("[JobManager] JobTresorManager force au boot", LogLevel.NORMAL);
	}
	
	//------------------------------------------------------------------------------------------------
	// Tick serveur: incremente les secondes travaillees et declenche les paies
	//------------------------------------------------------------------------------------------------
	void Tick()
	{
		int now = System.GetTickCount();
		int deltaMs = now - m_LastTickTime;
		m_LastTickTime = now;
		
		// Securite: si le delta est aberrant (lag, debug), on skip
		if (deltaMs < 0 || deltaMs > 120000)
			return;
		
		int deltaSeconds = deltaMs / 1000;
		if (deltaSeconds <= 0)
			return;
		
		// Parcourt tous les joueurs connectes ayant un metier avance
		PlayerManager pm = GetGame().GetPlayerManager();
		if (!pm)
			return;
		
		array<int> playerIds = new array<int>();
		pm.GetPlayers(playerIds);
		
		foreach (int playerId : playerIds)
		{
			JobPlayerData data = GetPlayerData(playerId);
			if (!data)
				continue;
			
			if (!JobData.HasHourlySalary(data.m_Job))
				continue;
			
			// Increment des secondes travaillees
			int oldSeconds = data.m_TotalWorkedSeconds;
			data.m_TotalWorkedSeconds = oldSeconds + deltaSeconds;
			
			// Position dans l'heure courante
			int secondsInCurrentHour = data.m_TotalWorkedSeconds % SECONDS_PER_HOUR;
			int oldSecondsInCurrentHour = oldSeconds % SECONDS_PER_HOUR;
			
			// Notification 15min restantes
			if (oldSecondsInCurrentHour < NOTIFY_15MIN && secondsInCurrentHour >= NOTIFY_15MIN)
				NotifyPayCountdown(playerId, data.m_Job, 15);
			
			// Notification 5min restantes
			if (oldSecondsInCurrentHour < NOTIFY_5MIN && secondsInCurrentHour >= NOTIFY_5MIN)
				NotifyPayCountdown(playerId, data.m_Job, 5);
			
			// Paiement si on a franchi l'heure
			int hoursCompleted = data.m_TotalWorkedSeconds / SECONDS_PER_HOUR;
			int oldHoursCompleted = oldSeconds / SECONDS_PER_HOUR;
			
			if (hoursCompleted > oldHoursCompleted)
			{
				int hoursToPay = hoursCompleted - oldHoursCompleted;
				PayPlayer(playerId, data.m_Job, hoursToPay);
				data.m_LastPaymentTime = System.GetUnixTime();
			}
			
			// Sauvegarde periodique (toutes les 10min de jeu travaille)
			if (secondsInCurrentHour % 600 < deltaSeconds)
				SavePlayerData(playerId);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Verse le salaire via CapsuleEconomy et notifie le joueur
	//------------------------------------------------------------------------------------------------
	void PayPlayer(int playerId, EJobType job, int hoursToPay)
	{
		int salary = JobData.GetHourlySalary(job) * hoursToPay;
		if (salary <= 0)
			return;
		
		// Recupere le VRAI UID Bohemia via BackendApi (meme approche que CapsuleEconomy)
		string uid = GetPersistentUID(playerId);
		if (uid == "")
		{
			Print(string.Format("[JobManager] Paie annulee: UID vide pour player=%1", playerId),
				LogLevel.WARNING);
			return;
		}
		
		// Ajoute les capsules cote serveur
		CapsuleEconomyManager eco = CapsuleEconomyManager.GetInstance();
		if (!eco)
		{
			Print("[JobManager] CapsuleEconomyManager introuvable", LogLevel.WARNING);
			return;
		}
		
		eco.AddCapsules(uid, salary);
		int newTotal = eco.GetCapsules(uid);
		
		// Notifie le HUD client (txt_Capsules) via CapsulePlayerComponent.Svr_SendCapsules
		PlayerController pc = GetGame().GetPlayerManager().GetPlayerController(playerId);
		if (pc)
		{
			CapsulePlayerComponent capsComp = CapsulePlayerComponent.Cast(
				pc.FindComponent(CapsulePlayerComponent));
			if (capsComp)
				capsComp.Svr_SendCapsules(newTotal);
		}
		
		string msg = string.Format("[PAIE] %1 capsules versees pour 1h de travail en tant que %2. Solde: %3",
			salary, JobData.GetJobLabel(job), newTotal);
		NotifyPlayerChat(playerId, msg);
		
		Print(string.Format("[JobManager] Paie: player=%1 uid=%2 job=%3 montant=%4 solde=%5",
			playerId, uid, JobData.JobToString(job), salary, newTotal), LogLevel.NORMAL);
	}
	
	//------------------------------------------------------------------------------------------------
	// UID STABLE : uniquement le GUID Bohemia, AUCUN fallback.
	// Retourne "" si le backend n a pas encore resolu l identite du joueur.
	//
	// POURQUOI (correctif 11 nov 2026 - perte de metier au reboot) :
	// GetPersistentUID ne renvoie JAMAIS "" : il retombe sur "name_<pseudo>" puis sur
	// playerId.ToString(). Juste apres une connexion, le backend n a pas encore repondu, donc
	// GetJsonPath pointait vers un fichier qui n existe pas ("player_name_Bob.json" ou
	// "player_3.json"). Le chargement echouait, un JobPlayerData neuf avec m_Job=NONE etait
	// cree et MIS EN CACHE, puis la premiere sauvegarde venue (SetPlayerJob, save periodique
	// 10 min, ou deconnexion) ecrivait ce metier vide par-dessus le VRAI fichier
	// "player_<guid>.json". Le metier du joueur etait detruit definitivement.
	//
	// Toute la persistance passe desormais par cet UID strict. Sans lui, on ne lit rien et
	// surtout on n ecrit rien.
	//------------------------------------------------------------------------------------------------
	string GetStableUID(int playerId)
	{
		if (playerId <= 0)
			return "";
		BackendApi backend = GetGame().GetBackendApi();
		if (!backend)
			return "";
		string guid = backend.GetPlayerIdentityId(playerId);
		if (guid == string.Empty)
			return "";
		return guid;
	}

	//------------------------------------------------------------------------------------------------
	// Retourne le UID persistant Bohemia (GUID identity) avec fallback.
	// ATTENTION : conserve pour les usages NON persistants (logs, affichage, paie).
	// NE PLUS UTILISER pour construire un chemin de sauvegarde : utiliser GetStableUID.
	//------------------------------------------------------------------------------------------------
	string GetPersistentUID(int playerId)
	{
		BackendApi backend = GetGame().GetBackendApi();
		if (backend)
		{
			string guid = backend.GetPlayerIdentityId(playerId);
			if (guid != string.Empty)
				return guid;
		}
		
		// Fallback: nom du joueur (moins fiable mais evite les crashs si BackendApi indispo)
		PlayerManager pm = GetGame().GetPlayerManager();
		if (pm)
		{
			string name = pm.GetPlayerName(playerId);
			if (name != string.Empty)
			{
				Print(string.Format("[JobManager] WARN: GUID indispo pour playerId=%1, fallback sur nom=%2",
					playerId, name), LogLevel.WARNING);
				return "name_" + name;
			}
		}
		
		return playerId.ToString();
	}
	
	//------------------------------------------------------------------------------------------------
	// Notification chat: il reste X minutes avant la prochaine paie
	//------------------------------------------------------------------------------------------------
	void NotifyPayCountdown(int playerId, EJobType job, int minutesRemaining)
	{
		string msg = string.Format("[PAIE] Prochaine paie dans %1 minutes (%2).",
			minutesRemaining, JobData.GetJobLabel(job));
		NotifyPlayerChat(playerId, msg);
	}
	
	//------------------------------------------------------------------------------------------------
	// Envoie un message dans le hint du joueur (cote client via RPC)
	//------------------------------------------------------------------------------------------------
	void NotifyPlayerChat(int playerId, string message)
	{
		PlayerController pc = GetGame().GetPlayerManager().GetPlayerController(playerId);
		if (!pc)
			return;
		
		// Route vers le client via le JobPlayerComponent du joueur.
		// L affichage se fait cote CLIENT uniquement, par LP_NotificationManager
		// (panneau HUD centre ecran). Voir JobPlayerComponent.RpcDo_ShowHint.
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (jpc)
			jpc.ServerShowHint(message);
	}
	
	//------------------------------------------------------------------------------------------------
	// Retourne les donnees du joueur (les charge depuis JSON si pas en cache)
	//------------------------------------------------------------------------------------------------
	JobPlayerData GetPlayerData(int playerId)
	{
		if (playerId <= 0)
			return null;
		
		string stableUid = GetStableUID(playerId);

		JobPlayerData data;
		if (m_PlayerDataCache.Find(playerId, data))
		{
			// CORRECTIF 11 nov 2026 : si l entree en cache a ete fabriquee alors que l UID
			// n etait pas encore resolu, elle contient potentiellement un metier NONE bidon.
			// Des que le backend repond, on la jette et on recharge le vrai fichier.
			if (!data.m_UidResolved && stableUid != "")
			{
				Print(string.Format("[JobManager] UID enfin resolu pour playerId=%1 : rechargement des donnees reelles.",
					playerId), LogLevel.NORMAL);
				m_PlayerDataCache.Remove(playerId);
			}
			else
			{
				return data;
			}
		}

		// Charge depuis JSON
		data = LoadPlayerData(playerId);
		if (!data)
		{
			// Premier login: creation avec NONE
			data = new JobPlayerData();
			data.m_Job = EJobType.NONE;
			data.m_PlayerId = playerId;
			data.m_FirstSeenUnix = System.GetUnixTime();
		}
		else if (data.m_FirstSeenUnix == 0)
		{
			// Joueur existant qui n'a pas encore eu son timestamp de creation
			// (ancien fichier JSON sans le champ) -> on le marque maintenant
			data.m_FirstSeenUnix = System.GetUnixTime();
		}

		// Marque si ces donnees reposent sur un UID fiable. Si non, SavePlayerData
		// refusera d ecrire et cette entree sera rechargee des que le backend repondra.
		data.m_UidResolved = (stableUid != "");
		if (!data.m_UidResolved)
		{
			Print(string.Format("[JobManager] ATTENTION: donnees provisoires pour playerId=%1 (UID non resolu). Aucune sauvegarde ne sera faite tant que le GUID n est pas disponible.",
				playerId), LogLevel.WARNING);
		}

		m_PlayerDataCache.Set(playerId, data);
		return data;
	}
	
	//------------------------------------------------------------------------------------------------
	// Change le metier d'un joueur (appelee depuis JobRpcHandler via les menus)
	//------------------------------------------------------------------------------------------------
	void SetPlayerJob(int playerId, EJobType newJob)
	{
		JobPlayerData data = GetPlayerData(playerId);
		if (!data)
			return;
		
		EJobType oldJob = data.m_Job;
		
		// Changement = reset du compteur d'heures (on ne veut pas mixer heures policier + heures medecin)
		if (oldJob != newJob)
		{
			data.m_TotalWorkedSeconds = 0;
			data.m_JobStartTime = System.GetUnixTime();
			data.m_QuestsCompleted = 0;
		}
		
		data.m_Job = newJob;
		SavePlayerData(playerId);
		
		// Notifie le client pour mise a jour du HUD txt_Job
		JobPlayerComponent comp = GetJobComponentForPlayer(playerId);
		if (comp)
			comp.ServerSetJob(newJob);
		
		string msg = string.Format("[EMPLOI] Nouveau metier: %1", JobData.GetJobLabel(newJob));
		NotifyPlayerChat(playerId, msg);
		
		Print(string.Format("[JobManager] SetPlayerJob: player=%1 %2 -> %3",
			playerId, JobData.JobToString(oldJob), JobData.JobToString(newJob)), LogLevel.NORMAL);
	}
	
	//------------------------------------------------------------------------------------------------
	// Incremente le compteur de quetes reussies (pour interim)
	//------------------------------------------------------------------------------------------------
	void IncrementQuestsCompleted(int playerId)
	{
		JobPlayerData data = GetPlayerData(playerId);
		if (!data)
			return;
		data.m_QuestsCompleted = data.m_QuestsCompleted + 1;
		SavePlayerData(playerId);
	}
	
	//------------------------------------------------------------------------------------------------
	// Recupere le JobPlayerComponent d'un joueur via son PlayerController
	// (le composant est attache au PlayerController, pas au character)
	//------------------------------------------------------------------------------------------------
	JobPlayerComponent GetJobComponentForPlayer(int playerId)
	{
		PlayerController pc = GetGame().GetPlayerManager().GetPlayerController(playerId);
		if (!pc)
			return null;
		
		return JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
	}
	
	//------------------------------------------------------------------------------------------------
	// ================== PERSISTENCE JSON ==================
	//------------------------------------------------------------------------------------------------
	// Le path utilise le UID Bohemia persistant (GUID identity) pour que les donnees
	// survivent aux restarts du serveur. Le playerId change a chaque session donc il
	// ne doit JAMAIS etre utilise comme cle de persistance.
	// CORRECTIF 11 nov 2026 : plus aucun fallback de chemin.
	// Retourne "" si l UID stable n est pas disponible. Les appelants DOIVENT traiter
	// ce cas : ne rien lire, et surtout ne rien ecrire.
	string GetJsonPath(int playerId)
	{
		string uid = GetStableUID(playerId);
		if (uid == "")
			return "";
		return JSON_FOLDER + "player_" + uid + ".json";
	}
	
	//------------------------------------------------------------------------------------------------
	JobPlayerData LoadPlayerData(int playerId)
	{
		string path = GetJsonPath(playerId);

		// SECURITE : sans UID stable on ne lit RIEN. Lire au mauvais endroit (ou echouer)
		// conduirait a fabriquer un metier NONE qui ecraserait ensuite le vrai fichier.
		if (path == "")
		{
			Print(string.Format("[JobManager] UID backend pas encore resolu pour playerId=%1 : chargement differe.",
				playerId), LogLevel.WARNING);
			return null;
		}

		SCR_JsonLoadContext ctx = new SCR_JsonLoadContext();
		bool loaded = ctx.LoadFromFile(path);

		// MIGRATION : recupere les fichiers ecrits AVANT ce correctif sous le fallback
		// "player_name_<pseudo>.json". Une fois charges, ils seront reecrits sous le bon
		// chemin "player_<guid>.json" a la prochaine sauvegarde.
		if (!loaded)
		{
			PlayerManager pmMig = GetGame().GetPlayerManager();
			if (pmMig)
			{
				string pname = pmMig.GetPlayerName(playerId);
				if (pname != string.Empty)
				{
					string legacyPath = JSON_FOLDER + "player_name_" + pname + ".json";
					loaded = ctx.LoadFromFile(legacyPath);
					if (loaded)
					{
						Print(string.Format("[JobManager] MIGRATION: donnees recuperees depuis %1 pour playerId=%2, seront reecrites sous le GUID.",
							legacyPath, playerId), LogLevel.NORMAL);
					}
				}
			}
		}

		if (!loaded)
			return null;

		string jobStr;
		int jobStartTime, totalWorkedSeconds, questsCompleted, lastPaymentTime;
		int lastJobChangeUnix = 0;  // Defaut 0 si fichier ancien sans ce champ : pas de cooldown
		// --- STATS RP cumulees (defaut 0 si fichier ancien sans ces champs) ---
		int firstSeenUnix = 0;
		int planksSold = 0;
		int juiceSold = 0;
		int rocksSold = 0;
		int drugsSold = 0;
		int timesJailed = 0;
		int totalInfractions = 0;

		ctx.ReadValue("job", jobStr);
		ctx.ReadValue("jobStartTime", jobStartTime);
		ctx.ReadValue("totalWorkedSeconds", totalWorkedSeconds);
		ctx.ReadValue("questsCompleted", questsCompleted);
		ctx.ReadValue("lastPaymentTime", lastPaymentTime);
		ctx.ReadValue("lastJobChangeUnix", lastJobChangeUnix);
		ctx.ReadValue("firstSeenUnix", firstSeenUnix);
		ctx.ReadValue("planksSold", planksSold);
		ctx.ReadValue("juiceSold", juiceSold);
		ctx.ReadValue("rocksSold", rocksSold);
		ctx.ReadValue("drugsSold", drugsSold);
		ctx.ReadValue("timesJailed", timesJailed);
		ctx.ReadValue("totalInfractions", totalInfractions);
		
		JobPlayerData data = new JobPlayerData();
		data.m_PlayerId = playerId;
		data.m_Job = JobData.StringToJob(jobStr);
		data.m_JobStartTime = jobStartTime;
		data.m_TotalWorkedSeconds = totalWorkedSeconds;
		data.m_QuestsCompleted = questsCompleted;
		data.m_LastPaymentTime = lastPaymentTime;
		data.m_LastJobChangeUnix = lastJobChangeUnix;
		data.m_FirstSeenUnix = firstSeenUnix;
		data.m_PlanksSold = planksSold;
		data.m_JuiceSold = juiceSold;
		data.m_RocksSold = rocksSold;
		data.m_DrugsSold = drugsSold;
		data.m_TimesJailed = timesJailed;
		data.m_TotalInfractions = totalInfractions;
		
		Print(string.Format("[JobManager] Chargement JSON: player=%1 job=%2 seconds=%3",
			playerId, jobStr, totalWorkedSeconds), LogLevel.NORMAL);
		return data;
	}
	
	//------------------------------------------------------------------------------------------------
	void SavePlayerData(int playerId)
	{
		JobPlayerData data;
		if (!m_PlayerDataCache.Find(playerId, data))
			return;

		string path = GetJsonPath(playerId);

		// CORRECTIF 11 nov 2026 - GARDE ANTI-DESTRUCTION
		// Sans UID stable, on refuse d ecrire. C est precisement cette ecriture aveugle qui
		// detruisait le metier des joueurs : un JobPlayerData provisoire (m_Job=NONE, cree
		// parce que le backend n avait pas encore repondu a la connexion) finissait ecrit
		// par-dessus le vrai fichier des que le GUID devenait disponible.
		if (path == "")
		{
			Print(string.Format("[JobManager] SAUVEGARDE ANNULEE pour playerId=%1 : UID backend indisponible. Donnees existantes preservees.",
				playerId), LogLevel.WARNING);
			return;
		}

		if (!data.m_UidResolved)
		{
			Print(string.Format("[JobManager] SAUVEGARDE ANNULEE pour playerId=%1 : donnees provisoires (chargees sans UID). Donnees existantes preservees.",
				playerId), LogLevel.WARNING);
			return;
		}

		SCR_JsonSaveContext ctx = new SCR_JsonSaveContext();
		ctx.WriteValue("job", JobData.JobToString(data.m_Job));
		ctx.WriteValue("jobStartTime", data.m_JobStartTime);
		ctx.WriteValue("totalWorkedSeconds", data.m_TotalWorkedSeconds);
		ctx.WriteValue("questsCompleted", data.m_QuestsCompleted);
		ctx.WriteValue("lastPaymentTime", data.m_LastPaymentTime);
		ctx.WriteValue("lastJobChangeUnix", data.m_LastJobChangeUnix);
		// --- STATS RP cumulees ---
		ctx.WriteValue("firstSeenUnix", data.m_FirstSeenUnix);
		ctx.WriteValue("planksSold", data.m_PlanksSold);
		ctx.WriteValue("juiceSold", data.m_JuiceSold);
		ctx.WriteValue("rocksSold", data.m_RocksSold);
		ctx.WriteValue("drugsSold", data.m_DrugsSold);
		ctx.WriteValue("timesJailed", data.m_TimesJailed);
		ctx.WriteValue("totalInfractions", data.m_TotalInfractions);
		ctx.SaveToFile(path);
	}
	
	//------------------------------------------------------------------------------------------------
	// Appelee au logout du joueur (via event dans JobPlayerComponent)
	//------------------------------------------------------------------------------------------------
	void OnPlayerDisconnected(int playerId)
	{
		SavePlayerData(playerId);
		m_PlayerDataCache.Remove(playerId);
		JobDrugSystem.OnPlayerDisconnected(playerId);
		JobQuestManager.GetInstance().OnPlayerDisconnected(playerId);
		JobBraquageManager.GetInstance().OnPlayerDisconnected(playerId);
		JobFonteManager.GetInstance().OnPlayerDisconnected(playerId);
		JobTresorManager.GetInstance().OnPlayerDisconnected(playerId);
	}
}

//------------------------------------------------------------------------------------------------
// Structure de donnees par joueur (image du JSON)
//------------------------------------------------------------------------------------------------
class JobPlayerData
{
	int m_PlayerId;
	EJobType m_Job;
	int m_JobStartTime;        // Unix timestamp du choix du metier actuel
	int m_TotalWorkedSeconds;  // Cumule depuis le choix du metier
	int m_QuestsCompleted;     // Nb de quetes reussies pour ce metier
	int m_LastPaymentTime;     // Unix timestamp du dernier versement
	int m_LastJobChangeUnix;   // Unix timestamp du DERNIER changement de metier via PNJ public.
	                           // Sert au cooldown anti-switch rapide (24h entre deux changements).
	                           // 0 = jamais change via PNJ (premier choix autorise sans cooldown).
	                           // Non impacte par les changements admin (ClientAskAdminSetJob).

	// --- STATS RP cumulees vie du personnage (fiche RP) ---
	int m_FirstSeenUnix;       // Premier login (pour anciennete RP)
	int m_PlanksSold;          // Nb planches vendues
	int m_JuiceSold;            // Nb bouteilles jus de pomme vendues
	int m_RocksSold;            // Nb roches transformees vendues
	int m_DrugsSold;            // Nb items drogues vendus (cannabis + cocaine cumules)
	int m_TimesJailed;          // Nb de fois envoye en prison
	int m_TotalInfractions;     // Total infractions cumulees (toutes amendes recues)

	// --- GARDE DE PERSISTANCE (correctif 11 nov 2026) ---
	// true  : ces donnees ont ete chargees (ou creees) avec un GUID backend valide.
	//         La sauvegarde sur disque est autorisee.
	// false : donnees provisoires fabriquees avant que le backend ait resolu l identite.
	//         SavePlayerData refuse d ecrire, et GetPlayerData rechargera le vrai fichier
	//         des que le GUID sera disponible. Evite d ecraser le metier du joueur.
	bool m_UidResolved;
}
