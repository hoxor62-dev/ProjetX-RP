//------------------------------------------------------------------------------------------------
// JobPochonData.c
// Constantes du systeme Pochon (marchandise a effet stimulant).
//------------------------------------------------------------------------------------------------

class JobPochonData
{
	// ===== PRIX / QUANTITES =====
	
	// Prix du sac a pochon (marchandises) chez le PNJ
	const int PRIX_SAC_POCHON = 5000;
	
	// ===== VENTE DES POCHONS =====
	
	// Prix de vente d un pochon au PNJ acheteur
	const int PRIX_VENTE_POCHON = 400;
	
	// Nombre maximum de pochons vendables par fenetre glissante
	const int MAX_VENTES_PAR_FENETRE = 5;
	
	// Duree de la fenetre glissante (10 minutes = 600 secondes)
	// A partir de la 1re vente, toutes les ventes dans les 600s comptent
	const int FENETRE_VENTE_S = 600;
	
	// Nombre de pochons produits par un sac
	const int POCHONS_PAR_SAC = 30;
	
	// Duree totale de transformation (5 minutes = 300 secondes)
	const int DUREE_TRANSFORMATION_S = 300;
	
	// Intervalle entre chaque pochon produit (10 secondes)
	const int INTERVALLE_POCHON_S = 10;
	
	// Distance maximale entre le joueur et la table pendant la transformation (10 metres)
	const float MAX_DISTANCE_FROM_TABLE = 10.0;
	
	// ===== PREFABS =====
	
	// Prefab du sac a pochon
	static const string PREFAB_SAC_POCHON = "{2EF2371E8D8DAC8E}Prefabs/sacxpochon/sacpochon.et";
	
	// Prefab du pochon
	static const string PREFAB_POCHON = "{AA5E6B20EEA7261D}Prefabs/pochon/pochonhash.et";
	
	// ===== EFFETS DU POCHON UTILISE =====
	
	// Duree des effets (3 minutes = 180 secondes)
	const int EFFET_DUREE_S = 180;
	
	// Multiplicateur de vitesse (+50%)
	const float EFFET_VITESSE_MULT = 1.5;
	
	// Multiplicateur de degats recus (-50%)
	const float EFFET_DEGATS_RECUS_MULT = 0.5;
	
	// Nom du GUID pour l identification de la classe (utile pour matcher les items dans l inventaire)
	static const string GUID_SAC_POCHON = "{2EF2371E8D8DAC8E}";
	static const string GUID_POCHON = "{AA5E6B20EEA7261D}";
}
