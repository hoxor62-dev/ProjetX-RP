//------------------------------------------------------------------------------------------------
// JobQuestData.c
// Definitions des quetes par metier:
//  - MINEUR: grue -> minerais -> retour PNJ (reward 45-80 caps)
//  - UBER: bar -> livraison (2 routes A ou B)
//  - CUISINIER: TODO Phase 2
//------------------------------------------------------------------------------------------------

enum EQuestType
{
	NONE = 0,
	MINEUR_MINERAIS = 1,         // Grue + minerais
	UBER_LIVRAISON_A = 2,        // Bar -> Point A
	UBER_LIVRAISON_B = 3,        // Bar alternatif -> Point alternatif
	UBER_VISITE_MAIRE = 4,       // Aller voir le Maire (5 min)
	UBER_VISITE_MINEUR = 5,      // Aller voir le Mineur (5 min)
	DETECTIVE_DOSSIER = 10,      // Livraison dossier confidentiel au commissariat (auto, 75 caps)
	DETECTIVE_PREUVES = 11,      // Recuperation de preuves sur scene de crime (2 etapes, 90 caps)
	DETECTIVE_VEHICULE = 12,     // Inspection d un vehicule abandonne (50 caps)
	DETECTIVE_ADRESSE = 13,      // Verification d adresse (70 caps)
	UBER_PIZZAS = 20,            // Livraison de pizzas (2 livraisons, 75 caps, 5 min)
	UBER_MATERIEL_MEDICAL = 21   // Livraison materiel medical hopital (50 caps, 5 min)
}

enum EQuestState
{
	INACTIVE = 0,
	STEP_1 = 1,                // Premiere etape (aller a A)
	STEP_2 = 2,                // Deuxieme etape (aller a B)
	READY_TO_TURN_IN = 3       // Retour au PNJ pour validation
}

//------------------------------------------------------------------------------------------------
// Structure d'une etape de quete
//------------------------------------------------------------------------------------------------
class JobQuestStep
{
	vector m_Position;
	float m_ValidationRadius;  // En metres
	string m_Description;
	string m_MarkerLabel;
	
	void JobQuestStep(vector pos, float radius, string desc, string markerLabel)
	{
		m_Position = pos;
		m_ValidationRadius = radius;
		m_Description = desc;
		m_MarkerLabel = markerLabel;
	}
}

//------------------------------------------------------------------------------------------------
// Structure complete d'une quete
//------------------------------------------------------------------------------------------------
class JobQuest
{
	EQuestType m_Type;
	string m_Label;
	string m_Description;
	EJobType m_ForJob;
	int m_RewardMin;
	int m_RewardMax;
	int m_TimeLimit;           // En secondes - 0 = pas de limite
	bool m_AutoComplete;       // Si true : la derniere etape valide et paye automatiquement
	                           // sans besoin de retour au PNJ (utile pour livraisons rapides).
	ref array<ref JobQuestStep> m_Steps;
	
	void JobQuest()
	{
		m_Steps = new array<ref JobQuestStep>();
		m_TimeLimit = 0;
		m_AutoComplete = false;
	}
}

//------------------------------------------------------------------------------------------------
// Catalogue statique des quetes disponibles
//------------------------------------------------------------------------------------------------
class JobQuestData
{
	//------------------------------------------------------------------------------------------------
	// Retourne la quete correspondant au type
	//------------------------------------------------------------------------------------------------
	static JobQuest GetQuest(EQuestType type)
	{
		JobQuest q = new JobQuest();
		q.m_Type = type;
		
		switch (type)
		{
			case EQuestType.MINEUR_MINERAIS:
			{
				q.m_Label = "Extraction de minerais";
				q.m_Description = "Activez la grue puis recuperez les minerais.";
				q.m_ForJob = EJobType.MINEUR;
				q.m_RewardMin = 45;
				q.m_RewardMax = 80;
				q.m_Steps.Insert(new JobQuestStep(
					Vector(5602.725, 52.302, 2835.352),
					5.0,
					"Montez en haut de la grue pour l'activer",
					"Grue - activation"));
				q.m_Steps.Insert(new JobQuestStep(
					Vector(5457.1, 16.701, 2738.925),
					5.0,
					"Recuperez les minerais",
					"Minerais"));
				break;
			}
			
			// Quetes UBER supprimees (UBER_LIVRAISON_A, UBER_LIVRAISON_B, UBER_VISITE_MAIRE,
			// UBER_VISITE_MINEUR, UBER_PIZZAS, UBER_MATERIEL_MEDICAL).
			// Le metier Uber fonctionne maintenant via le bouton "Appeler Uber" du telephone.
			
			{
				q.m_Label = "Livraison - Route A";
				q.m_Description = "Recuperez les bouteilles au bar et livrez-les.";
				q.m_ForJob = EJobType.UBER;
				q.m_RewardMin = 45;
				q.m_RewardMax = 80;
				q.m_Steps.Insert(new JobQuestStep(
					Vector(2805.236, 11.448, 3372.317),
					5.0,
					"Recuperez les bouteilles au bar",
					"Recuperation - Bar"));
				q.m_Steps.Insert(new JobQuestStep(
					Vector(3850.459, 2.356, 5740.849),
					5.0,
					"Livrez les bouteilles a destination",
					"Livraison"));
				break;
			}
			
			case EQuestType.DETECTIVE_DOSSIER:
			{
				q.m_Label = "Livraison d'un dossier confidentiel";
				q.m_Description = "Livrez le dossier confidentiel au commissariat.";
				q.m_ForJob = EJobType.CUISINIER;  // Detective utilise l enum CUISINIER (rename label uniquement)
				q.m_RewardMin = 65;
				q.m_RewardMax = 75;
				q.m_AutoComplete = true;  // Validation automatique a l arrivee, pas de retour PNJ
				q.m_Steps.Insert(new JobQuestStep(
					Vector(3960.44, 1.958, 6064.016),
					5.0,
					"Rendez-vous au commissariat de police pour livrer le dossier",
					"Commissariat - Livraison"));
				break;
			}
			
			case EQuestType.DETECTIVE_PREUVES:
			{
				q.m_Label = "Recuperation de preuves";
				q.m_Description = "Des preuves ont ete oubliees sur une ancienne scene de crime.";
				q.m_ForJob = EJobType.CUISINIER;
				q.m_RewardMin = 80;
				q.m_RewardMax = 90;
				q.m_Steps.Insert(new JobQuestStep(
					Vector(3718.283, 3.868, 5868.434),
					5.0,
					"Rendez-vous sur l ancienne scene de crime",
					"Scene de crime"));
				q.m_Steps.Insert(new JobQuestStep(
					Vector(3714.157, 0.427, 5796.452),
					5.0,
					"Une autre preuve est dans la zone. Recuperez-la puis retournez voir le detective",
					"Preuve supplementaire"));
				break;
			}
			
			case EQuestType.DETECTIVE_VEHICULE:
			{
				q.m_Label = "Inspection d'un vehicule";
				q.m_Description = "Un vehicule abandonne a ete signale. Rendez-vous sur place pour l inspecter.";
				q.m_ForJob = EJobType.CUISINIER;
				q.m_RewardMin = 15;
				q.m_RewardMax = 25;
				q.m_AutoComplete = true;  // Validation automatique a l arrivee, pas de retour PNJ
				q.m_Steps.Insert(new JobQuestStep(
					Vector(2992.064, 1.517, 4349.869),
					5.0,
					"Rendez-vous sur la zone du vehicule abandonne",
					"Vehicule abandonne"));
				break;
			}
			
			case EQuestType.DETECTIVE_ADRESSE:
			{
				q.m_Label = "Verification d'adresse";
				q.m_Description = "Verifiez si la personne vit toujours a ce domicile.";
				q.m_ForJob = EJobType.CUISINIER;
				q.m_RewardMin = 65;
				q.m_RewardMax = 70;
				q.m_Steps.Insert(new JobQuestStep(
					Vector(5936.257, 11.683, 6530.743),
					5.0,
					"Rendez-vous au domicile pour verifier la presence de la personne (detritus, bouteilles...)",
					"Domicile a verifier"));
				break;
			}
		}
		
		return q;
	}
	
	//------------------------------------------------------------------------------------------------
	// Retourne la liste des quetes disponibles pour un metier
	//------------------------------------------------------------------------------------------------
	static array<EQuestType> GetQuestsForJob(EJobType job)
	{
		array<EQuestType> quests = new array<EQuestType>();
		
		switch (job)
		{
			case EJobType.MINEUR:
				// Les quetes Mineur ont ete retirees - le metier vit uniquement de la vente
				// de minerais transformes
				break;
			
			case EJobType.UBER:
				// Les quetes UBER ont ete completement retirees - le metier vit uniquement
				// via les appels Uber au telephone (clients qui demandent un transport)
				break;
			
			case EJobType.CUISINIER:
				// Detective (label) - utilise enum CUISINIER pour compat saves existants
				quests.Insert(EQuestType.DETECTIVE_DOSSIER);
				quests.Insert(EQuestType.DETECTIVE_PREUVES);
				quests.Insert(EQuestType.DETECTIVE_VEHICULE);
				quests.Insert(EQuestType.DETECTIVE_ADRESSE);
				break;
		}
		
		return quests;
	}
}

//------------------------------------------------------------------------------------------------
// Etat de la quete active d'un joueur (cote serveur)
//------------------------------------------------------------------------------------------------
class JobActiveQuest
{
	int m_PlayerId;
	EQuestType m_QuestType;
	EQuestState m_State;
	int m_StartTime;
}
