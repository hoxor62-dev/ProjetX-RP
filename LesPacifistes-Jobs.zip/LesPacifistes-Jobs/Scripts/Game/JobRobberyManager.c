//------------------------------------------------------------------------------------------------
// JobRobberyManager.c
// Singleton serveur gerant les braquages de distributeurs.
//
// Mecanique :
//  - Voyou lance un braquage sur un ATM
//  - Gain : +10 capsules toutes les 10 secondes
//  - Duree max : 5 minutes (30 ticks de 10s = 300 capsules max)
//  - Si le voyou s eloigne de >10m de l ATM : annulation
//  - Si le voyou se deconnecte : annulation
//  - Cooldown de 60 minutes par joueur (UID, persiste si ils reconnectent)
//
// La position du braquage est partagee aux policiers/militaires via une RPC chat + map.
//------------------------------------------------------------------------------------------------

class JobActiveRobbery
{
	int m_PlayerId;            // playerId du voyou actuel
	string m_PlayerUID;        // UID du voyou (pour cooldown)
	string m_VoyouDisplayName; // Nom RP ou playername (pour notifs)
	RplId m_AtmRplId;          // ATM cible (pour distance check)
	vector m_AtmPosition;      // Position de l ATM (pour notif police)
	int m_StartUnix;           // Unix timestamp du debut
	int m_LastTickUnix;        // Dernier tick paye (pour gain toutes 10s)
	bool m_GainPhaseStarted;   // True une fois passe la phase de preparation 2min (notif unique)
}

class JobRobberyManager
{
	static ref JobRobberyManager s_Instance;
	
	const int TICK_INTERVAL_SECONDS = 10;     // gain toutes les 10s
	const int CAPSULES_PER_TICK = 300;         // 10 capsules par tick
	const int PREPARATION_SECONDS = 120;      // 2 minutes de preparation sans gains (laisse le temps a la police)
	const int GAIN_DURATION_SECONDS = 300;    // 5 minutes de gains apres la preparation
	const int MAX_DURATION_SECONDS = PREPARATION_SECONDS + GAIN_DURATION_SECONDS; // 7 min total
	const float MAX_DISTANCE_METERS = 20.0;   // si > 10m de l ATM : annulation (mais seulement APRES la preparation)
	const int COOLDOWN_SECONDS = 3600;        // 60 minutes de cooldown par joueur
	const int MIN_LAW_ENFORCEMENT = 2;        // Minimum joueurs POLICIER/MILITAIRE connectes pour lancer
	
	// Braquages actifs : 1 par joueur (cle = playerId courant)
	ref map<int, ref JobActiveRobbery> m_ActiveRobberies;
	
	// Cooldowns par UID joueur : UID -> timestamp Unix de fin de cooldown
	ref map<string, int> m_PlayerCooldowns;
	
	const string SAVE_PATH = "$profile:LesPacifistesJobs/robbery_cooldowns.json";
	
	//------------------------------------------------------------------------------------------------
	void JobRobberyManager()
	{
		m_ActiveRobberies = new map<int, ref JobActiveRobbery>();
		m_PlayerCooldowns = new map<string, int>();
	}
	
	//------------------------------------------------------------------------------------------------
	static JobRobberyManager GetInstance()
	{
		if (!s_Instance)
		{
			s_Instance = new JobRobberyManager();
			s_Instance.LoadFromDisk();
			// Tick recurrent : check toutes les 1s pour distance + tick gains
			GetGame().GetCallqueue().CallLater(s_Instance.Tick, 1000, true);
		}
		return s_Instance;
	}
	
	//------------------------------------------------------------------------------------------------
	// Demarre un braquage. Renvoie 0 si OK, code d erreur sinon :
	//   1 = pas voyou (verifie cote action mais redondant cote serveur)
	//   2 = braquage deja en cours pour ce joueur
	//   3 = cooldown actif
	//   4 = ATM introuvable
	//   5 = trop loin de l ATM
	//   6 = pas assez de forces de l ordre connectees (Police + Militaire, minimum 2)
	//------------------------------------------------------------------------------------------------
	int StartRobbery(int playerId, string uid, string displayName, RplId atmRplId)
	{
		// Verifie metier voyou cote serveur (securite)
		JobPlayerData data = JobManager.GetInstance().GetPlayerData(playerId);
		if (!data || data.m_Job != EJobType.VOYOU)
			return 1;
		
		// Deja un braquage en cours ?
		if (m_ActiveRobberies.Get(playerId))
			return 2;
		
		// Cooldown ?
		int cdEnd;
		if (m_PlayerCooldowns.Find(uid, cdEnd))
		{
			int now = System.GetUnixTime();
			if (now < cdEnd)
			{
				int remainMin = (cdEnd - now) / 60;
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					string.Format("[BRAQUAGE] Cooldown actif - revenez dans %1 minutes", remainMin));
				return 3;
			}
		}
		
		// Resoud l ATM
		RplComponent rpl = RplComponent.Cast(Replication.FindItem(atmRplId));
		if (!rpl)
			return 4;
		IEntity atm = rpl.GetEntity();
		if (!atm)
			return 4;
		
		// Distance check
		PlayerManager pm = GetGame().GetPlayerManager();
		if (!pm)
			return 4;
		PlayerController pc = pm.GetPlayerController(playerId);
		if (!pc)
			return 4;
		IEntity playerChar = pc.GetControlledEntity();
		if (!playerChar)
			return 4;
		
		float dist = vector.Distance(atm.GetOrigin(), playerChar.GetOrigin());
		if (dist > MAX_DISTANCE_METERS)
			return 5;
		
		// Verification : minimum 2 forces de l ordre connectees (POLICIER + MILITAIRE)
		int lawCount = CountLawEnforcementConnected();
		if (lawCount < MIN_LAW_ENFORCEMENT)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				string.Format("[BRAQUAGE] Forces de l ordre insuffisantes : %1/2 connectees",
					lawCount.ToString()));
			return 6;
		}
		
		// Cree le braquage actif
		JobActiveRobbery rb = new JobActiveRobbery();
		rb.m_PlayerId = playerId;
		rb.m_PlayerUID = uid;
		rb.m_VoyouDisplayName = displayName;
		rb.m_AtmRplId = atmRplId;
		rb.m_AtmPosition = atm.GetOrigin();
		rb.m_StartUnix = System.GetUnixTime();
		rb.m_LastTickUnix = rb.m_StartUnix;
		m_ActiveRobberies.Set(playerId, rb);
		
		// Notif au voyou
		JobManager.GetInstance().NotifyPlayerChat(playerId,
			"[BRAQUAGE] Phase de preparation : 2 minutes - vous pouvez vous deplacer librement.");
		JobManager.GetInstance().NotifyPlayerChat(playerId,
			"[BRAQUAGE] Apres les 2min, vous devrez rester a moins de 20m du distributeur pendant 5 minutes pour gagner les capsules.");
		
		// Alerte police + map marker
		AlertPolice(rb);
		AddMapMarkerForRobbery(rb);
		
		return 0;
	}
	
	//------------------------------------------------------------------------------------------------
	// Tick recurrent : verifie toutes les conditions des braquages actifs
	//------------------------------------------------------------------------------------------------
	void Tick()
	{
		if (m_ActiveRobberies.Count() == 0)
			return;
		
		int now = System.GetUnixTime();
		array<int> toCancel = new array<int>();
		array<int> toComplete = new array<int>();
		
		foreach (int pid, JobActiveRobbery rb : m_ActiveRobberies)
		{
			if (!rb)
				continue;
			
			int elapsed = now - rb.m_StartUnix;
			
			// Check duree max (preparation + gains = 7min)
			if (elapsed >= MAX_DURATION_SECONDS)
			{
				toComplete.Insert(pid);
				continue;
			}
			
			// Check deconnexion (toujours, meme pendant la preparation)
			PlayerManager pm = GetGame().GetPlayerManager();
			if (!pm)
				continue;
			PlayerController pc = pm.GetPlayerController(pid);
			if (!pc)
			{
				toCancel.Insert(pid);
				continue;
			}
			IEntity playerChar = pc.GetControlledEntity();
			if (!playerChar)
			{
				toCancel.Insert(pid);
				continue;
			}
			
			// === PHASE PREPARATION (0 -> 2min) ===
			// Le voyou peut bouger librement, pas de check distance, pas de gains
			if (elapsed < PREPARATION_SECONDS)
			{
				// Pas grand chose a faire pendant la preparation, juste laisser le timer tourner
				continue;
			}
			
			// === TRANSITION : phase preparation -> phase gains ===
			// Notifie une seule fois que la phase de gains demarre
			if (!rb.m_GainPhaseStarted)
			{
				rb.m_GainPhaseStarted = true;
				JobManager.GetInstance().NotifyPlayerChat(pid,
					"[BRAQUAGE] Phase de gains active ! Restez a moins de 20m pendant 5 minutes.");
				// On reset le LastTickUnix au moment ou les gains demarrent
				rb.m_LastTickUnix = now;
			}
			
			// === PHASE GAINS (2min -> 7min) ===
			// Check distance strict : sortie = annulation + cooldown
			float dist = vector.Distance(rb.m_AtmPosition, playerChar.GetOrigin());
			if (dist > MAX_DISTANCE_METERS)
			{
				toCancel.Insert(pid);
				continue;
			}
			
			// Tick payment toutes les 10s
			if (now - rb.m_LastTickUnix >= TICK_INTERVAL_SECONDS)
			{
				// Ajoute capsules
				CapsuleEconomyManager eco = CapsuleEconomyManager.GetInstance();
				if (eco)
					eco.AddCapsules(rb.m_PlayerUID, CAPSULES_PER_TICK);
				rb.m_LastTickUnix = now;
				
				// Notif progres : temps restant en phase gains
				int gainsElapsed = elapsed - PREPARATION_SECONDS;
				int gainsRemaining = GAIN_DURATION_SECONDS - gainsElapsed;
				JobManager.GetInstance().NotifyPlayerChat(pid,
					string.Format("[BRAQUAGE] +%1 capsules - encore %2 secondes",
						CAPSULES_PER_TICK, gainsRemaining));
			}
		}
		
		// Process des annulations (= cooldown active)
		foreach (int pidCancel : toCancel)
		{
			CancelRobbery(pidCancel, "Braquage annule (eloignement ou deconnexion) - cooldown 60min active");
		}
		
		// Process des completions
		foreach (int pidComplete : toComplete)
		{
			CompleteRobbery(pidComplete);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void CancelRobbery(int playerId, string reason)
	{
		JobActiveRobbery rb = m_ActiveRobberies.Get(playerId);
		if (!rb)
			return;
		
		// Active le cooldown 60min pour ce joueur (anti-cheese)
		// Toute sortie de la zone OU deconnexion declenche le cooldown,
		// sauf pendant la phase de preparation 2min ou le voyou peut bouger.
		// Comme on n appelle CancelRobbery qu apres la phase de preparation pour
		// l eloignement, c est sain. La deconnexion peut survenir pendant la prep
		// mais c est volontaire (le voyou perd quand meme s il deconnecte).
		int cdEnd = System.GetUnixTime() + COOLDOWN_SECONDS;
		m_PlayerCooldowns.Set(rb.m_PlayerUID, cdEnd);
		SaveToDisk();
		
		// Supprime le marker map
		RemoveMapMarkerForRobbery(rb);
		
		m_ActiveRobberies.Remove(playerId);
		
		// Notif au voyou si encore connecte
		JobManager.GetInstance().NotifyPlayerChat(playerId,
			string.Format("[BRAQUAGE] %1", reason));
	}
	
	//------------------------------------------------------------------------------------------------
	void CompleteRobbery(int playerId)
	{
		JobActiveRobbery rb = m_ActiveRobberies.Get(playerId);
		if (!rb)
			return;
		
		// Active le cooldown 60min pour ce joueur
		int cdEnd = System.GetUnixTime() + COOLDOWN_SECONDS;
		m_PlayerCooldowns.Set(rb.m_PlayerUID, cdEnd);
		SaveToDisk();
		
		// Supprime le marker map
		RemoveMapMarkerForRobbery(rb);
		
		m_ActiveRobberies.Remove(playerId);
		
		// Notif fin
		JobManager.GetInstance().NotifyPlayerChat(playerId,
			"[BRAQUAGE] Termine ! Vous avez gagne 300 capsules. Cooldown 60min.");
	}
	
	//------------------------------------------------------------------------------------------------
	// Alerte les policiers/militaires connectes via chat
	//------------------------------------------------------------------------------------------------
	//------------------------------------------------------------------------------------------------
	// Compte les joueurs connectes avec un metier de force de l ordre
	// (POLICIER ou MILITAIRE). Utilise pour verifier le minimum requis avant de lancer un braquage.
	//------------------------------------------------------------------------------------------------
	int CountLawEnforcementConnected()
	{
		int count = 0;
		array<int> playerIds = new array<int>();
		GetGame().GetPlayerManager().GetPlayers(playerIds);
		foreach (int pid : playerIds)
		{
			JobPlayerData d = JobManager.GetInstance().GetPlayerData(pid);
			if (d && (d.m_Job == EJobType.POLICIER || d.m_Job == EJobType.MILITAIRE))
				count++;
		}
		return count;
	}
	
	void AlertPolice(JobActiveRobbery rb)
	{
		PlayerManager pm = GetGame().GetPlayerManager();
		if (!pm)
			return;
		
		array<int> allPlayers = new array<int>();
		pm.GetPlayers(allPlayers);
		
		string alertMsg = string.Format(
			"[ALERTE POLICE] Braquage de distributeur en cours par %1 - Position : %2,%3",
			rb.m_VoyouDisplayName,
			Math.Floor(rb.m_AtmPosition[0]),
			Math.Floor(rb.m_AtmPosition[2]));
		
		foreach (int pid : allPlayers)
		{
			JobPlayerData pd = JobManager.GetInstance().GetPlayerData(pid);
			if (!pd)
				continue;
			if (pd.m_Job != EJobType.POLICIER && pd.m_Job != EJobType.MILITAIRE)
				continue;
			
			// Notif chat
			JobManager.GetInstance().NotifyPlayerChat(pid, alertMsg);
			
			// Notif hint via RPC sur leur JobPlayerComponent
			PlayerController pc = pm.GetPlayerController(pid);
			if (!pc)
				continue;
			JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
			if (jpc)
				jpc.NotifyRobberyHint(rb.m_VoyouDisplayName);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Demande aux clients police/militaire de creer un marker LOCAL sur leur carte
	// (les markers serveur ne se propagent pas aux clients dans Reforger - il faut
	// passer par RPC pour creer le marker localement chez chaque policier).
	//------------------------------------------------------------------------------------------------
	void AddMapMarkerForRobbery(JobActiveRobbery rb)
	{
		PlayerManager pm = GetGame().GetPlayerManager();
		if (!pm)
			return;
		
		array<int> allPlayers = new array<int>();
		pm.GetPlayers(allPlayers);
		
		foreach (int pid : allPlayers)
		{
			JobPlayerData pd = JobManager.GetInstance().GetPlayerData(pid);
			if (!pd)
				continue;
			if (pd.m_Job != EJobType.POLICIER && pd.m_Job != EJobType.MILITAIRE)
				continue;
			
			PlayerController pc = pm.GetPlayerController(pid);
			if (!pc)
				continue;
			JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
			if (jpc)
				jpc.NotifyRobberyMarkerAdd(rb.m_AtmPosition[0], rb.m_AtmPosition[2],
					rb.m_VoyouDisplayName);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void RemoveMapMarkerForRobbery(JobActiveRobbery rb)
	{
		PlayerManager pm = GetGame().GetPlayerManager();
		if (!pm)
			return;
		
		array<int> allPlayers = new array<int>();
		pm.GetPlayers(allPlayers);
		
		foreach (int pid : allPlayers)
		{
			JobPlayerData pd = JobManager.GetInstance().GetPlayerData(pid);
			if (!pd)
				continue;
			if (pd.m_Job != EJobType.POLICIER && pd.m_Job != EJobType.MILITAIRE)
				continue;
			
			PlayerController pc = pm.GetPlayerController(pid);
			if (!pc)
				continue;
			JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
			if (jpc)
				jpc.NotifyRobberyMarkerRemove();
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Sauve les cooldowns sur disque (resiste au reboot)
	//------------------------------------------------------------------------------------------------
	void SaveToDisk()
	{
		SCR_JsonSaveContext ctx = new SCR_JsonSaveContext();
		ctx.WriteValue("count", m_PlayerCooldowns.Count());
		int idx = 0;
		foreach (string uid, int cdEnd : m_PlayerCooldowns)
		{
			ctx.WriteValue("uid_" + idx.ToString(), uid);
			ctx.WriteValue("end_" + idx.ToString(), cdEnd);
			idx++;
		}
		ctx.SaveToFile(SAVE_PATH);
	}
	
	//------------------------------------------------------------------------------------------------
	void LoadFromDisk()
	{
		SCR_JsonLoadContext ctx = new SCR_JsonLoadContext();
		if (!ctx.LoadFromFile(SAVE_PATH))
			return;
		int count = 0;
		ctx.ReadValue("count", count);
		int now = System.GetUnixTime();
		for (int i = 0; i < count; i++)
		{
			string uid = "";
			int cdEnd = 0;
			ctx.ReadValue("uid_" + i.ToString(), uid);
			ctx.ReadValue("end_" + i.ToString(), cdEnd);
			// On ne reload que les cooldowns encore actifs
			if (uid != "" && cdEnd > now)
				m_PlayerCooldowns.Set(uid, cdEnd);
		}
		Print(string.Format("[JobRobberyManager] %1 cooldowns charges", m_PlayerCooldowns.Count()),
			LogLevel.NORMAL);
	}
}
