//------------------------------------------------------------------------------------------------
// JobFonteData.c
// Constantes et donnees du systeme de fonte.
// Supporte 3 recettes (priorite : chaines > pepites fer > pepites or) :
//   - 5 chaines en or   -> 1 lingot d or   (60s)
//   - 5 pepites de fer  -> 1 lingot de fer (60s)
//   - 5 pepites d or    -> 1 lingot d or   (60s)
//------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------------------
// Type de recette de fonte
//------------------------------------------------------------------------------------------------
enum EFonteRecipeType
{
	NONE = 0,
	CHAINS_TO_GOLD_INGOT = 1,   // 5 chaines -> 1 lingot d or
	IRON_NUGGETS_TO_INGOT = 2,  // 5 pepites de fer -> 1 lingot de fer
	GOLD_NUGGETS_TO_INGOT = 3,  // 5 pepites d or -> 1 lingot d or
}

class JobFonteData
{
	// ===== CONSTANTES =====
	
	// Nombre d items sources requis pour produire 1 lingot (identique pour toutes les recettes)
	const int CHAINS_PER_INGOT = 5;
	
	// Duree de fonte par lingot (en secondes, identique pour toutes les recettes)
	const int SECONDS_PER_INGOT = 30;
	
	// Distance maximale entre le joueur et le four pendant la fonte (en metres)
	const float MAX_DISTANCE_FROM_FOUR = 5.0;
	
	// ===== PREFABS RESULTATS =====
	
	// Lingot d or (issue de chaines OU de pepites d or)
	static const string LINGOT_OR_PREFAB   = "{CD7E4794F5D40A0B}Prefabs/Items/Equipment/bargold/bargold.et";
	
	// Lingot de fer (issu de pepites de fer)
	static const string LINGOT_FER_PREFAB  = "{BFAB2077C1F962CB}Prefabs/Items/Equipment/bargold/bariron.et";
	
	// ===== PREFABS INGREDIENTS =====
	
	// Pepite de fer
	static const string PEPITE_FER_PREFAB  = "{B5C7F29EAB4BE9A7}Prefabs/Weapons/Grenades/pepitefer.et";
	
	// Pepite d or
	static const string PEPITE_OR_PREFAB   = "{C6D29778D28BA23A}Prefabs/Weapons/Grenades/pepiteor.et";
	
	//------------------------------------------------------------------------------------------------
	// Retourne la liste des prefabs de chaines en or acceptees pour la fonte.
	//------------------------------------------------------------------------------------------------
	static array<string> GetAcceptedChainPrefabs()
	{
		array<string> prefabs = new array<string>();
		prefabs.Insert("{4BD92C5231A3940D}Prefabs/Cordao/GoldChain2.et");
		prefabs.Insert("{E25E88CA0B28A408}Prefabs/Clothing/Chain.et");
		prefabs.Insert("{1CD36D3E3CDA7ADB}Prefabs/Clothing/BME_Scapulario.et");
		prefabs.Insert("{B660612952B6B5D8}Prefabs/Clothing/Chucky_Chain.et");
		prefabs.Insert("{61E261CDE10A07BD}Prefabs/Clothing/Cuban_Cross_Chain.et");
		prefabs.Insert("{C95ADA51AB7B9644}Prefabs/Clothing/Demon_Time_Chain.et");
		prefabs.Insert("{D2DAF01768448970}Prefabs/Clothing/Jesus_Chain.et");
		prefabs.Insert("{11C09AB21D527236}Prefabs/Clothing/Trap_Queen.et");
		prefabs.Insert("{20DC0843CA50A484}Prefabs/Bracelet/GoldBraceletLeft.et");
		return prefabs;
	}
	
	//------------------------------------------------------------------------------------------------
	// Verifie si un ResourceName correspond a une chaine acceptee
	//------------------------------------------------------------------------------------------------
	static bool IsAcceptedChain(string prefabName)
	{
		array<string> accepted = GetAcceptedChainPrefabs();
		foreach (string p : accepted)
		{
			if (p == prefabName)
				return true;
		}
		return false;
	}
	
	//------------------------------------------------------------------------------------------------
	// Verifie si un ResourceName correspond a une pepite de fer
	//------------------------------------------------------------------------------------------------
	static bool IsIronNugget(string prefabName)
	{
		return prefabName == PEPITE_FER_PREFAB;
	}
	
	//------------------------------------------------------------------------------------------------
	// Verifie si un ResourceName correspond a une pepite d or
	//------------------------------------------------------------------------------------------------
	static bool IsGoldNugget(string prefabName)
	{
		return prefabName == PEPITE_OR_PREFAB;
	}
	
	//------------------------------------------------------------------------------------------------
	// Retourne le prefab du lingot produit par une recette
	//------------------------------------------------------------------------------------------------
	static string GetIngotPrefabForRecipe(EFonteRecipeType recipe)
	{
		switch (recipe)
		{
			case EFonteRecipeType.CHAINS_TO_GOLD_INGOT:   return LINGOT_OR_PREFAB;
			case EFonteRecipeType.IRON_NUGGETS_TO_INGOT:  return LINGOT_FER_PREFAB;
			case EFonteRecipeType.GOLD_NUGGETS_TO_INGOT:  return LINGOT_OR_PREFAB;
		}
		return "";
	}
	
	//------------------------------------------------------------------------------------------------
	// Retourne un nom lisible du produit d une recette (pour messages chat)
	//------------------------------------------------------------------------------------------------
	static string GetRecipeIngotLabel(EFonteRecipeType recipe)
	{
		switch (recipe)
		{
			case EFonteRecipeType.CHAINS_TO_GOLD_INGOT:   return "lingot d or";
			case EFonteRecipeType.IRON_NUGGETS_TO_INGOT:  return "lingot de fer";
			case EFonteRecipeType.GOLD_NUGGETS_TO_INGOT:  return "lingot d or";
		}
		return "lingot";
	}
	
	//------------------------------------------------------------------------------------------------
	// Retourne un nom lisible de la source d une recette (pour messages chat)
	//------------------------------------------------------------------------------------------------
	static string GetRecipeSourceLabel(EFonteRecipeType recipe)
	{
		switch (recipe)
		{
			case EFonteRecipeType.CHAINS_TO_GOLD_INGOT:   return "chaines";
			case EFonteRecipeType.IRON_NUGGETS_TO_INGOT:  return "pepites de fer";
			case EFonteRecipeType.GOLD_NUGGETS_TO_INGOT:  return "pepites d or";
		}
		return "items";
	}
}
