//------------------------------------------------------------------------------------------------
// JobFonteManager.c
// Manager singleton SERVEUR du systeme de fonte en or.
//
// Flux :
//  1. Joueur clique 'Fondre en Or' devant le four
//  2. Serveur compte les chaines acceptees dans son inventaire
//  3. Calcul du nombre de lingots = nb_chaines / 5 (entier)
//  4. Pour chaque lingot :
//     - Attend 60 secondes
//     - Consomme 5 chaines de l inventaire
//     - Spawn un lingot d or dans l inventaire
//  5. Annulation possible si :
//     - Joueur s eloigne > 5m du four
//     - Joueur meurt / inconscient
//     - Joueur deconnecte
//     -> dans ce cas, le palier en cours est perdu (chaines non consommees) mais
//        les lingots deja crees restent
//------------------------------------------------------------------------------------------------

class JobFonteActiveSession
{
	int m_PlayerId;
	string m_PlayerUID;
	int m_FourEntityId;             // EntityID du four pour distance check
	vector m_FourOrigin;            // position du four
	int m_StartTime;                // timestamp unix global
	int m_CurrentIngotEndTime;      // timestamp fin du palier courant
	int m_TotalIngotsTarget;        // nombre total de lingots a produire
	int m_IngotsCompleted;          // nombre deja produit
	int m_ChainsConsumed;           // total des items sources consommes (compte generique)
	EFonteRecipeType m_RecipeType;  // type de recette en cours (chaines/pepites fer/pepites or)
}

class JobFonteManager
{
	static ref JobFonteManager s_Instance;
	
	// Sessions actives : cle = playerId
	ref map<int, ref JobFonteActiveSession> m_ActiveSessions;
	
	const int TICK_INTERVAL_MS = 1000;
	
	//------------------------------------------------------------------------------------------------
	void JobFonteManager()
	{
		m_ActiveSessions = new map<int, ref JobFonteActiveSession>();
	}
	
	//------------------------------------------------------------------------------------------------
	static JobFonteManager GetInstance()
	{
		if (!s_Instance)
		{
			s_Instance = new JobFonteManager();
			s_Instance.Init();
		}
		return s_Instance;
	}
	
	//------------------------------------------------------------------------------------------------
	void Init()
	{
		Print("[JobFonteManager] Initialisation", LogLevel.NORMAL);
		if (Replication.IsServer())
			GetGame().GetCallqueue().CallLater(Tick, TICK_INTERVAL_MS, true);
	}
	
	//------------------------------------------------------------------------------------------------
	bool HasActiveFonte(int playerId)
	{
		return m_ActiveSessions.Contains(playerId);
	}
	
	//------------------------------------------------------------------------------------------------
	// Compte les chaines acceptees dans l inventaire du joueur
	//------------------------------------------------------------------------------------------------
	int CountAcceptedChains(int playerId)
	{
		PlayerController pc = GetGame().GetPlayerManager().GetPlayerController(playerId);
		if (!pc) return 0;
		IEntity playerEntity = pc.GetControlledEntity();
		if (!playerEntity) return 0;
		
		SCR_InventoryStorageManagerComponent invMgr = SCR_InventoryStorageManagerComponent.Cast(
			playerEntity.FindComponent(SCR_InventoryStorageManagerComponent));
		if (!invMgr) return 0;
		
		array<IEntity> items = new array<IEntity>();
		invMgr.GetItems(items);
		
		int count = 0;
		foreach (IEntity item : items)
		{
			if (!item) continue;
			EntityPrefabData pd = item.GetPrefabData();
			if (!pd) continue;
			string rn = pd.GetPrefabName();
			if (JobFonteData.IsAcceptedChain(rn))
				count++;
		}
		return count;
	}
	
	//------------------------------------------------------------------------------------------------
	// Retire N chaines de l inventaire du joueur (peu importe le type).
	// Retourne le nombre reellement retire.
	//------------------------------------------------------------------------------------------------
	int RemoveChainsFromInventory(int playerId, int count)
	{
		if (count <= 0) return 0;
		PlayerController pc = GetGame().GetPlayerManager().GetPlayerController(playerId);
		if (!pc) return 0;
		IEntity playerEntity = pc.GetControlledEntity();
		if (!playerEntity) return 0;
		
		SCR_InventoryStorageManagerComponent invMgr = SCR_InventoryStorageManagerComponent.Cast(
			playerEntity.FindComponent(SCR_InventoryStorageManagerComponent));
		if (!invMgr) return 0;
		
		array<IEntity> items = new array<IEntity>();
		invMgr.GetItems(items);
		
		// Collecte d abord les entites a supprimer (ne pas modifier en iterant)
		array<IEntity> toRemove = new array<IEntity>();
		foreach (IEntity item : items)
		{
			if (toRemove.Count() >= count)
				break;
			if (!item) continue;
			EntityPrefabData pd = item.GetPrefabData();
			if (!pd) continue;
			string rn = pd.GetPrefabName();
			if (JobFonteData.IsAcceptedChain(rn))
				toRemove.Insert(item);
		}
		
		// Supprime les entites collectees
		int removed = 0;
		foreach (IEntity item : toRemove)
		{
			if (!item) continue;
			SCR_EntityHelper.DeleteEntityAndChildren(item);
			removed++;
		}
		return removed;
	}
	
	//------------------------------------------------------------------------------------------------
	// Compte les items d un prefab specifique dans l inventaire du joueur.
	// Utilise pour compter les pepites de fer / pepites d or.
	//------------------------------------------------------------------------------------------------
	int CountItemsByPrefab(int playerId, string prefabName)
	{
		PlayerController pc = GetGame().GetPlayerManager().GetPlayerController(playerId);
		if (!pc) return 0;
		IEntity playerEntity = pc.GetControlledEntity();
		if (!playerEntity) return 0;
		
		SCR_InventoryStorageManagerComponent invMgr = SCR_InventoryStorageManagerComponent.Cast(
			playerEntity.FindComponent(SCR_InventoryStorageManagerComponent));
		if (!invMgr) return 0;
		
		array<IEntity> items = new array<IEntity>();
		invMgr.GetItems(items);
		
		int count = 0;
		foreach (IEntity item : items)
		{
			if (!item) continue;
			EntityPrefabData pd = item.GetPrefabData();
			if (!pd) continue;
			if (pd.GetPrefabName() == prefabName)
				count++;
		}
		return count;
	}
	
	//------------------------------------------------------------------------------------------------
	// Retire N items d un prefab specifique dans l inventaire du joueur.
	// Retourne le nombre reellement retire.
	//------------------------------------------------------------------------------------------------
	int RemoveItemsByPrefab(int playerId, string prefabName, int count)
	{
		if (count <= 0) return 0;
		PlayerController pc = GetGame().GetPlayerManager().GetPlayerController(playerId);
		if (!pc) return 0;
		IEntity playerEntity = pc.GetControlledEntity();
		if (!playerEntity) return 0;
		
		SCR_InventoryStorageManagerComponent invMgr = SCR_InventoryStorageManagerComponent.Cast(
			playerEntity.FindComponent(SCR_InventoryStorageManagerComponent));
		if (!invMgr) return 0;
		
		array<IEntity> items = new array<IEntity>();
		invMgr.GetItems(items);
		
		array<IEntity> toRemove = new array<IEntity>();
		foreach (IEntity item : items)
		{
			if (toRemove.Count() >= count) break;
			if (!item) continue;
			EntityPrefabData pd = item.GetPrefabData();
			if (!pd) continue;
			if (pd.GetPrefabName() == prefabName)
				toRemove.Insert(item);
		}
		
		int removed = 0;
		foreach (IEntity item : toRemove)
		{
			if (!item) continue;
			SCR_EntityHelper.DeleteEntityAndChildren(item);
			removed++;
		}
		return removed;
	}
	
	//------------------------------------------------------------------------------------------------
	// Compte le nombre d items sources disponibles pour une recette donnee
	//------------------------------------------------------------------------------------------------
	int CountSourceItemsForRecipe(int playerId, EFonteRecipeType recipe)
	{
		switch (recipe)
		{
			case EFonteRecipeType.CHAINS_TO_GOLD_INGOT:
				return CountAcceptedChains(playerId);
			case EFonteRecipeType.IRON_NUGGETS_TO_INGOT:
				return CountItemsByPrefab(playerId, JobFonteData.PEPITE_FER_PREFAB);
			case EFonteRecipeType.GOLD_NUGGETS_TO_INGOT:
				return CountItemsByPrefab(playerId, JobFonteData.PEPITE_OR_PREFAB);
		}
		return 0;
	}
	
	//------------------------------------------------------------------------------------------------
	// Retire N items sources pour une recette donnee. Retourne le nombre reellement retire.
	//------------------------------------------------------------------------------------------------
	int RemoveSourceItemsForRecipe(int playerId, EFonteRecipeType recipe, int count)
	{
		switch (recipe)
		{
			case EFonteRecipeType.CHAINS_TO_GOLD_INGOT:
				return RemoveChainsFromInventory(playerId, count);
			case EFonteRecipeType.IRON_NUGGETS_TO_INGOT:
				return RemoveItemsByPrefab(playerId, JobFonteData.PEPITE_FER_PREFAB, count);
			case EFonteRecipeType.GOLD_NUGGETS_TO_INGOT:
				return RemoveItemsByPrefab(playerId, JobFonteData.PEPITE_OR_PREFAB, count);
		}
		return 0;
	}
	
	//------------------------------------------------------------------------------------------------
	// Spawn le lingot approprie (or ou fer selon la recette) dans l inventaire du joueur
	//------------------------------------------------------------------------------------------------
	bool GiveLingotToPlayer(int playerId, EFonteRecipeType recipe)
	{
		PlayerController pc = GetGame().GetPlayerManager().GetPlayerController(playerId);
		if (!pc) return false;
		IEntity playerEntity = pc.GetControlledEntity();
		if (!playerEntity) return false;
		
		SCR_InventoryStorageManagerComponent invMgr = SCR_InventoryStorageManagerComponent.Cast(
			playerEntity.FindComponent(SCR_InventoryStorageManagerComponent));
		if (!invMgr) return false;
		
		ResourceName rn = JobFonteData.GetIngotPrefabForRecipe(recipe);
		if (rn == "") return false;
		
		bool ok = invMgr.TrySpawnPrefabToStorage(rn);
		return ok;
	}
	
	//------------------------------------------------------------------------------------------------
	// Tente de demarrer une fonte. AUTO-DETECT prioritaire :
	//   1. Chaines en or (si >= 5)                 -> lingot d or
	//   2. Sinon, pepites de fer (si >= 5)         -> lingot de fer
	//   3. Sinon, pepites d or (si >= 5)           -> lingot d or
	//
	// Retourne :
	//   0 = OK demarre
	//   1 = deja une fonte en cours
	//   2 = aucun item eligible en quantite suffisante dans l inventaire
	//   3 = erreur (joueur introuvable)
	//------------------------------------------------------------------------------------------------
	int StartFonte(int playerId, IEntity fourEntity, out int outTotalChains, out int outTotalIngots)
	{
		outTotalChains = 0;
		outTotalIngots = 0;
		if (!Replication.IsServer())
			return 3;
		
		if (HasActiveFonte(playerId))
			return 1;
		
		// Priorite 1 : chaines
		EFonteRecipeType recipe = EFonteRecipeType.NONE;
		int totalSources = CountAcceptedChains(playerId);
		int totalIngots = totalSources / JobFonteData.CHAINS_PER_INGOT;
		if (totalIngots > 0)
		{
			recipe = EFonteRecipeType.CHAINS_TO_GOLD_INGOT;
		}
		else
		{
			// Priorite 2 : pepites de fer
			totalSources = CountItemsByPrefab(playerId, JobFonteData.PEPITE_FER_PREFAB);
			totalIngots = totalSources / JobFonteData.CHAINS_PER_INGOT;
			if (totalIngots > 0)
			{
				recipe = EFonteRecipeType.IRON_NUGGETS_TO_INGOT;
			}
			else
			{
				// Priorite 3 : pepites d or
				totalSources = CountItemsByPrefab(playerId, JobFonteData.PEPITE_OR_PREFAB);
				totalIngots = totalSources / JobFonteData.CHAINS_PER_INGOT;
				if (totalIngots > 0)
					recipe = EFonteRecipeType.GOLD_NUGGETS_TO_INGOT;
			}
		}
		
		if (recipe == EFonteRecipeType.NONE || totalIngots <= 0)
			return 2;
		
		outTotalChains = totalSources;
		outTotalIngots = totalIngots;
		
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "")
			return 3;
		
		int now = System.GetUnixTime();
		JobFonteActiveSession session = new JobFonteActiveSession();
		session.m_PlayerId = playerId;
		session.m_PlayerUID = uid;
		session.m_FourEntityId = fourEntity.GetID();
		session.m_FourOrigin = fourEntity.GetOrigin();
		session.m_StartTime = now;
		session.m_CurrentIngotEndTime = now + JobFonteData.SECONDS_PER_INGOT;
		session.m_TotalIngotsTarget = totalIngots;
		session.m_IngotsCompleted = 0;
		session.m_ChainsConsumed = 0;
		session.m_RecipeType = recipe;
		m_ActiveSessions.Set(playerId, session);
		
		// Envoie au client : HUD progression
		PlayerController pc = GetGame().GetPlayerManager().GetPlayerController(playerId);
		if (pc)
		{
			JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
			if (jpc)
				jpc.ServerStartFonteHud(totalIngots, session.m_FourOrigin);
		}
		
		// Notif chat : indique la recette detectee
		JobManager.GetInstance().NotifyPlayerChat(playerId,
			string.Format("[FONTE] Detecte : %1 %2 -> %3 %4",
				totalSources.ToString(), JobFonteData.GetRecipeSourceLabel(recipe),
				totalIngots.ToString(), JobFonteData.GetRecipeIngotLabel(recipe)));
		
		Print(string.Format("[JobFonteManager] Fonte demarree : player=%1 recipe=%2 sources=%3 lingots=%4",
			playerId, recipe, totalSources, totalIngots), LogLevel.NORMAL);
		return 0;
	}
	
	//------------------------------------------------------------------------------------------------
	// Tick serveur : pour chaque session, verifie distance/vie, et avance la fonte
	//------------------------------------------------------------------------------------------------
	void Tick()
	{
		if (!Replication.IsServer())
			return;
		if (m_ActiveSessions.Count() == 0)
			return;
		
		int now = System.GetUnixTime();
		array<int> toEnd = new array<int>();
		
		foreach (int playerId, JobFonteActiveSession session : m_ActiveSessions)
		{
			if (!session)
			{
				toEnd.Insert(playerId);
				continue;
			}
			
			// Verif joueur connecte
			PlayerController pc = GetGame().GetPlayerManager().GetPlayerController(playerId);
			if (!pc)
			{
				toEnd.Insert(playerId);
				continue;
			}
			IEntity playerEntity = pc.GetControlledEntity();
			if (!playerEntity)
			{
				toEnd.Insert(playerId);
				continue;
			}
			
			// Verif vie / inconscience
			ChimeraCharacter ch = ChimeraCharacter.Cast(playerEntity);
			if (ch)
			{
				CharacterControllerComponent ccc = ch.GetCharacterController();
				if (ccc)
				{
					ECharacterLifeState ls = ccc.GetLifeState();
					if (ls == ECharacterLifeState.DEAD || ls == ECharacterLifeState.INCAPACITATED)
					{
						JobManager.GetInstance().NotifyPlayerChat(playerId,
							"[FONTE] Vous etes hors-jeu : la fonte est interrompue.");
						toEnd.Insert(playerId);
						continue;
					}
				}
			}
			
			// Verif distance au four
			float dist = vector.Distance(playerEntity.GetOrigin(), session.m_FourOrigin);
			if (dist > JobFonteData.MAX_DISTANCE_FROM_FOUR)
			{
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					string.Format("[FONTE] Vous etes trop eloigne du four (%1m) : la fonte est annulee.",
						Math.Floor(dist).ToString()));
				toEnd.Insert(playerId);
				continue;
			}
			
			// Verif fin de palier (1 minute par lingot)
			if (now >= session.m_CurrentIngotEndTime)
			{
				string sourceLabel = JobFonteData.GetRecipeSourceLabel(session.m_RecipeType);
				string ingotLabel = JobFonteData.GetRecipeIngotLabel(session.m_RecipeType);
				
				// Palier termine : consomme 5 items sources + donne 1 lingot
				int removed = RemoveSourceItemsForRecipe(playerId, session.m_RecipeType, JobFonteData.CHAINS_PER_INGOT);
				if (removed < JobFonteData.CHAINS_PER_INGOT)
				{
					// Le joueur n a plus assez d items sources (a peut-etre balance certains)
					JobManager.GetInstance().NotifyPlayerChat(playerId,
						string.Format("[FONTE] Plus assez de %1 dans l inventaire (manque %2). Fonte arretee.",
							sourceLabel, (JobFonteData.CHAINS_PER_INGOT - removed).ToString()));
					toEnd.Insert(playerId);
					continue;
				}
				session.m_ChainsConsumed += removed;
				
				bool given = GiveLingotToPlayer(playerId, session.m_RecipeType);
				if (!given)
				{
					JobManager.GetInstance().NotifyPlayerChat(playerId,
						"[FONTE] Impossible de placer le lingot dans votre inventaire (plein ?). Fonte arretee.");
					toEnd.Insert(playerId);
					continue;
				}
				session.m_IngotsCompleted++;
				
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					string.Format("[FONTE] +1 %1 (%2/%3)",
						ingotLabel,
						session.m_IngotsCompleted.ToString(), session.m_TotalIngotsTarget.ToString()));
				
				// Sync stats au HUD client
				JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
				if (jpc)
					jpc.ServerSyncFonteStats(session.m_IngotsCompleted, session.m_ChainsConsumed);
				
				// Tous les lingots produits ?
				if (session.m_IngotsCompleted >= session.m_TotalIngotsTarget)
				{
					JobManager.GetInstance().NotifyPlayerChat(playerId,
						string.Format("[FONTE] Fonte terminee ! %1 %2(s) produit(s).",
							session.m_IngotsCompleted.ToString(), ingotLabel));
					toEnd.Insert(playerId);
					continue;
				}
				
				// Sinon demarre le palier suivant
				session.m_CurrentIngotEndTime = now + JobFonteData.SECONDS_PER_INGOT;
			}
		}
		
		foreach (int pid : toEnd)
			EndFonte(pid);
	}
	
	//------------------------------------------------------------------------------------------------
	// Termine une session de fonte
	//------------------------------------------------------------------------------------------------
	void EndFonte(int playerId)
	{
		if (!HasActiveFonte(playerId))
			return;
		
		// Stoppe le HUD chez le client
		PlayerController pc = GetGame().GetPlayerManager().GetPlayerController(playerId);
		if (pc)
		{
			JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
			if (jpc)
				jpc.ServerEndFonteHud();
		}
		
		m_ActiveSessions.Remove(playerId);
		Print(string.Format("[JobFonteManager] Fonte terminee : player=%1", playerId),
			LogLevel.NORMAL);
	}
	
	//------------------------------------------------------------------------------------------------
	void OnPlayerDisconnected(int playerId)
	{
		if (HasActiveFonte(playerId))
			EndFonte(playerId);
	}
}
