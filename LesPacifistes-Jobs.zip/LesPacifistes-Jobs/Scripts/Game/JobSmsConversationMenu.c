//------------------------------------------------------------------------------------------------
// JobSmsConversationMenu.c
// Affiche l'historique d'une conversation avec un autre joueur. Permet de repondre.
//------------------------------------------------------------------------------------------------

class JobSmsConversationMenu : ChimeraMenuBase
{
	Widget m_RootWidget;
	TextWidget m_TitleText;
	TextWidget m_HistoryText;
	ScrollLayoutWidget m_HistoryScroll;
	EditBoxWidget m_ReplyInput;
	ButtonWidget m_BtnReply;
	ButtonWidget m_BtnClose;
	
	// === Pagination des messages ===
	ButtonWidget m_BtnPrevMsgPage;
	ButtonWidget m_BtnNextMsgPage;
	TextWidget m_MsgPageLabel;
	int m_CurrentPage = 0;
	int m_TotalPages = 0;
	
	// Etat
	string m_OtherUID = "";
	string m_OtherDisplayName = "";
	int m_OtherPlayerId = 0; // resolu par le serveur si possible (pour le SMS)
	
	// Singleton temporaire pour permettre au RPC de mettre a jour
	static JobSmsConversationMenu s_Instance;
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuOpen()
	{
		super.OnMenuOpen();
		s_Instance = this;
		JobFocusHandler.ClearRegistry();
		m_RootWidget = GetRootWidget();
		if (!m_RootWidget)
			return;
		
		m_TitleText = TextWidget.Cast(m_RootWidget.FindAnyWidget("TitleText"));
		m_HistoryText = TextWidget.Cast(m_RootWidget.FindAnyWidget("HistoryText"));
		m_HistoryScroll = ScrollLayoutWidget.Cast(m_RootWidget.FindAnyWidget("HistoryScroll"));
		m_ReplyInput = EditBoxWidget.Cast(m_RootWidget.FindAnyWidget("ReplyInput"));
		m_BtnReply = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnReply"));
		m_BtnClose = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnClose"));
		
		// Widgets pagination messages
		m_BtnPrevMsgPage = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnPrevMsgPage"));
		m_BtnNextMsgPage = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnNextMsgPage"));
		m_MsgPageLabel = TextWidget.Cast(m_RootWidget.FindAnyWidget("MsgPageLabel"));
		
		if (m_BtnReply)
		{
			SmsConvButtonHandler hReply = new SmsConvButtonHandler();
			hReply.m_Menu = this;
			hReply.m_Action = "reply";
			m_BtnReply.AddHandler(hReply);
			JobFocusHandler.Attach(m_BtnReply);
		}
		if (m_BtnClose)
		{
			SmsConvButtonHandler hClose = new SmsConvButtonHandler();
			hClose.m_Menu = this;
			hClose.m_Action = "close";
			m_BtnClose.AddHandler(hClose);
			JobFocusHandler.Attach(m_BtnClose);
		}
		if (m_BtnPrevMsgPage)
		{
			SmsConvButtonHandler hPrev = new SmsConvButtonHandler();
			hPrev.m_Menu = this;
			hPrev.m_Action = "page_prev";
			m_BtnPrevMsgPage.AddHandler(hPrev);
			JobFocusHandler.Attach(m_BtnPrevMsgPage);
		}
		if (m_BtnNextMsgPage)
		{
			SmsConvButtonHandler hNext = new SmsConvButtonHandler();
			hNext.m_Menu = this;
			hNext.m_Action = "page_next";
			m_BtnNextMsgPage.AddHandler(hNext);
			JobFocusHandler.Attach(m_BtnNextMsgPage);
		}
		
		// Masque la pagination par defaut (sera revele si totalPages > 1)
		HidePaginationWidgets();
		
		if (m_HistoryText)
			m_HistoryText.SetText("Chargement...");
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuClose()
	{
		if (s_Instance == this)
			s_Instance = null;
		super.OnMenuClose();
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuUpdate(float tDelta)
	{
		super.OnMenuUpdate(tDelta);
		if (GetGame().GetInputManager().GetActionValue("MenuBack") > 0.5)
			CloseMenuInternal();
	}
	
	//------------------------------------------------------------------------------------------------
	void Initialize(string otherUID, string displayName)
	{
		m_OtherUID = otherUID;
		m_OtherDisplayName = displayName;
		m_CurrentPage = 0;
		m_TotalPages = 0;
		
		if (m_TitleText)
			m_TitleText.SetText(displayName);
		
		// Demande au serveur l historique de cette conversation (page 0 = plus recents)
		PlayerController pc = GetGame().GetPlayerController();
		if (pc)
		{
			JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
			if (jpc)
				jpc.ClientAskSmsConversation(otherUID, 0);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Recoit l historique formate du serveur.
	// Format serveur : "currentPage|totalPages|historyText"
	//------------------------------------------------------------------------------------------------
	void DisplayHistory(string encoded, int otherPlayerId)
	{
		m_OtherPlayerId = otherPlayerId;
		
		// Parse le format encode : trouve les 2 premiers pipes '|'
		string history = "";
		int firstPipe = FindChar(encoded, "|", 0);
		if (firstPipe > 0)
		{
			string pageStr = encoded.Substring(0, firstPipe);
			m_CurrentPage = pageStr.ToInt();
			int secondPipe = FindChar(encoded, "|", firstPipe + 1);
			if (secondPipe > firstPipe)
			{
				string totalStr = encoded.Substring(firstPipe + 1, secondPipe - firstPipe - 1);
				m_TotalPages = totalStr.ToInt();
				int histStart = secondPipe + 1;
				int histLen = encoded.Length() - histStart;
				if (histLen > 0)
					history = encoded.Substring(histStart, histLen);
			}
		}
		else
		{
			// Format inattendu (fallback : traite comme historique brut)
			history = encoded;
			m_CurrentPage = 0;
			m_TotalPages = 1;
		}
		
		if (m_HistoryText)
		{
			if (history == "")
				m_HistoryText.SetText("Aucun message pour l'instant.");
			else
				m_HistoryText.SetText(WrapLongLines(history, 76));
		}

		UpdatePagination();

		// Scrolle automatiquement en bas apres un petit delai pour laisser le widget
		// recalculer sa hauteur de contenu. Les messages les plus recents sont en bas.
		GetGame().GetCallqueue().CallLater(ScrollToBottom, 50, false);
	}

	//------------------------------------------------------------------------------------------------
	// Positionne le scroll de l historique en bas (= messages les plus recents visibles).
	// On applique sur les 2 indices possibles (0 = horizontal, 1 = vertical selon l API) pour
	// couvrir les 2 conventions. L index invalide est simplement ignore par l engine.
	//------------------------------------------------------------------------------------------------
	void ScrollToBottom()
	{
		if (!m_HistoryScroll)
			return;
		// 1.0 = position maximale (bas de la liste pour un slider vertical)
		m_HistoryScroll.SetSliderPos(1, 1.0);
	}
	
	//------------------------------------------------------------------------------------------------
	// Retourne l index de la premiere occurrence de "needle" dans "s" a partir de "start".
	// -1 si non trouve.
	//------------------------------------------------------------------------------------------------
	int FindChar(string s, string needle, int start)
	{
		int slen = s.Length();
		for (int i = start; i < slen; i++)
		{
			if (s.Substring(i, 1) == needle)
				return i;
		}
		return -1;
	}
	
	//------------------------------------------------------------------------------------------------
	// Met a jour l affichage des boutons pagination messages
	//------------------------------------------------------------------------------------------------
	void UpdatePagination()
	{
		bool needPagination = m_TotalPages > 1;
		
		if (m_BtnPrevMsgPage)
		{
			m_BtnPrevMsgPage.SetVisible(needPagination);
			// Attention : page 0 = derniers messages, page N-1 = plus anciens
			// "Precedent" = messages PLUS ANCIENS (page superieure), "Suivant" = messages PLUS RECENTS
			m_BtnPrevMsgPage.SetEnabled(m_CurrentPage < m_TotalPages - 1);
			if (m_CurrentPage < m_TotalPages - 1)
				m_BtnPrevMsgPage.SetColor(Color.FromRGBA(46, 128, 56, 255));
			else
				m_BtnPrevMsgPage.SetColor(Color.FromRGBA(89, 89, 102, 255));
		}
		if (m_BtnNextMsgPage)
		{
			m_BtnNextMsgPage.SetVisible(needPagination);
			m_BtnNextMsgPage.SetEnabled(m_CurrentPage > 0);
			if (m_CurrentPage > 0)
				m_BtnNextMsgPage.SetColor(Color.FromRGBA(46, 128, 56, 255));
			else
				m_BtnNextMsgPage.SetColor(Color.FromRGBA(89, 89, 102, 255));
		}
		if (m_MsgPageLabel)
		{
			m_MsgPageLabel.SetVisible(needPagination);
			if (needPagination)
			{
				// Affiche en ordre inverse pour l utilisateur (Page 1/N = plus recents)
				int displayPage = m_CurrentPage + 1;
				m_MsgPageLabel.SetText(string.Format("Page %1 / %2", displayPage, m_TotalPages));
			}
			else
				m_MsgPageLabel.SetText("");
		}
	}
	
	void HidePaginationWidgets()
	{
		if (m_BtnPrevMsgPage) m_BtnPrevMsgPage.SetVisible(false);
		if (m_BtnNextMsgPage) m_BtnNextMsgPage.SetVisible(false);
		if (m_MsgPageLabel) m_MsgPageLabel.SetVisible(false);
	}
	
	//------------------------------------------------------------------------------------------------
	// Charge une autre page de messages
	//------------------------------------------------------------------------------------------------
	void GoToPage(int newPage)
	{
		if (newPage < 0) return;
		if (m_TotalPages > 0 && newPage >= m_TotalPages) return;
		m_CurrentPage = newPage;
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		jpc.ClientAskSmsConversation(m_OtherUID, newPage);
	}
	
	//------------------------------------------------------------------------------------------------
	// Ajoute des retours a la ligne dans les longues lignes pour eviter que le texte
	// deborde de la zone d affichage. Coupe aux limites de mots quand possible.
	// - maxWidth = nombre max de caracteres par ligne (80 pour une largeur 640px, Font 13)
	//------------------------------------------------------------------------------------------------
	string WrapLongLines(string text, int maxWidth)
	{
		if (text == "" || maxWidth < 20)
			return text;
		
		string result = "";
		int textLen = text.Length();
		int lineStart = 0;
		
		// Parcourt chaque ligne existante (delimiteur \n)
		for (int i = 0; i <= textLen; i++)
		{
			bool isEnd = (i == textLen);
			bool isNewline = false;
			if (!isEnd)
			{
				string c = text.Substring(i, 1);
				if (c == "\n")
					isNewline = true;
			}
			
			if (isNewline || isEnd)
			{
				int lineLen = i - lineStart;
				if (lineLen <= 0)
				{
					if (isNewline)
						result = result + "\n";
					lineStart = i + 1;
					continue;
				}
				string line = text.Substring(lineStart, lineLen);
				result = result + WrapSingleLine(line, maxWidth);
				if (isNewline)
					result = result + "\n";
				lineStart = i + 1;
			}
		}
		return result;
	}
	
	//------------------------------------------------------------------------------------------------
	// Wrap une ligne unique en respectant les limites de mots quand possible.
	//------------------------------------------------------------------------------------------------
	string WrapSingleLine(string line, int maxWidth)
	{
		int len = line.Length();
		if (len <= maxWidth)
			return line;
		
		string result = "";
		int pos = 0;
		while (pos < len)
		{
			int remaining = len - pos;
			if (remaining <= maxWidth)
			{
				// La fin de ligne rentre
				result = result + line.Substring(pos, remaining);
				break;
			}
			// On doit couper : cherche l espace le plus proche avant pos+maxWidth (recul max 20 chars)
			int cutAt = pos + maxWidth;
			int bestCut = -1;
			int minSearch = cutAt - 20;
			if (minSearch < pos + 20)
				minSearch = pos + 20;  // ne coupe pas trop tot
			for (int j = cutAt; j >= minSearch; j--)
			{
				if (j >= len) continue;
				string c = line.Substring(j, 1);
				if (c == " ")
				{
					bestCut = j;
					break;
				}
			}
			int chunkLen;
			int nextPos;
			if (bestCut >= 0)
			{
				chunkLen = bestCut - pos;
				nextPos = bestCut + 1;  // saute l espace
			}
			else
			{
				// Pas d espace trouve : coupe brute
				chunkLen = maxWidth;
				nextPos = pos + maxWidth;
			}
			result = result + line.Substring(pos, chunkLen) + "\n";
			pos = nextPos;
		}
		return result;
	}
	
	//------------------------------------------------------------------------------------------------
	void OnButtonClicked(string action)
	{
		if (action == "close")
		{
			CloseMenuInternal();
			return;
		}
		if (action == "reply")
		{
			DoReply();
			return;
		}
		if (action == "page_prev")
		{
			// "Precedent" affiche des messages PLUS ANCIENS => page suivante en interne
			GoToPage(m_CurrentPage + 1);
			return;
		}
		if (action == "page_next")
		{
			// "Suivant" affiche des messages PLUS RECENTS => page precedente en interne
			GoToPage(m_CurrentPage - 1);
			return;
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void DoReply()
	{
		if (!m_ReplyInput)
			return;
		string content = m_ReplyInput.GetText();
		if (content == "")
			return;
		if (content.Length() > 150)
			return;
		if (m_OtherPlayerId <= 0)
			return;  // destinataire pas online
		
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc)
			return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc)
			return;
		jpc.ClientAskSendSms(m_OtherPlayerId, content);
		
		// Vide le champ et recharge l historique
		m_ReplyInput.SetText("");
		GetGame().GetCallqueue().CallLater(ReloadHistory, 500, false);
	}
	
	//------------------------------------------------------------------------------------------------
	void ReloadHistory()
	{
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc)
			return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc)
			return;
		// Apres envoi d un message, on retourne toujours a la page 0 (plus recents)
		m_CurrentPage = 0;
		jpc.ClientAskSmsConversation(m_OtherUID, 0);
	}
	
	//------------------------------------------------------------------------------------------------
	void CloseMenuInternal()
	{
		GetGame().GetMenuManager().CloseMenu(this);
	}
	
	//------------------------------------------------------------------------------------------------
	static JobSmsConversationMenu GetOpenMenu()
	{
		return s_Instance;
	}
	
	//------------------------------------------------------------------------------------------------
	string GetOtherUID()
	{
		return m_OtherUID;
	}
}

//------------------------------------------------------------------------------------------------
class SmsConvButtonHandler : ScriptedWidgetEventHandler
{
	JobSmsConversationMenu m_Menu;
	string m_Action;
	
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu)
			m_Menu.OnButtonClicked(m_Action);
		return true;
	}
}
