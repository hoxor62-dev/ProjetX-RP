//------------------------------------------------------------------------------------------------
// JobDrugDealerMenu.c
// Menu du PNJ dealer - permet de vendre tout son stock de drogue en un clic
//------------------------------------------------------------------------------------------------

class JobDrugDealerMenu : ChimeraMenuBase
{
	const string LAYOUT_PATH = "{3CFBEB7640A94D7B}UI/layouts/JobDrugDealerMenu.layout";
	
	// Singleton runtime : instance actuellement ouverte (null si ferme)
	static JobDrugDealerMenu s_Instance;
	static JobDrugDealerMenu GetOpenMenu() { return s_Instance; }
	
	Widget m_RootWidget;
	ButtonWidget m_SellWeedButton;
	ButtonWidget m_SellCocaineButton;
	ButtonWidget m_CloseButton;
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuOpen()
	{
		super.OnMenuOpen();
		s_Instance = this;
		m_RootWidget = GetRootWidget();
		if (!m_RootWidget)
			return;
		
		m_SellWeedButton = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("SellWeedButton"));
		m_SellCocaineButton = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("SellCocaineButton"));
		m_CloseButton = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("CloseButton"));
		
		if (m_SellWeedButton)
		{
			DealerClickHandler ch = new DealerClickHandler();
			ch.m_Menu = this;
			ch.m_Action = "sell_weed";
			m_SellWeedButton.AddHandler(ch);
			JobFocusHandler.Attach(m_SellWeedButton);
		}
		
		if (m_SellCocaineButton)
		{
			DealerClickHandler ch = new DealerClickHandler();
			ch.m_Menu = this;
			ch.m_Action = "sell_cocaine";
			m_SellCocaineButton.AddHandler(ch);
			JobFocusHandler.Attach(m_SellCocaineButton);
		}
		
		if (m_CloseButton)
		{
			DealerClickHandler ch = new DealerClickHandler();
			ch.m_Menu = this;
			ch.m_Action = "close";
			m_CloseButton.AddHandler(ch);
			JobFocusHandler.Attach(m_CloseButton);
		}
		
		// Focus initial sur le premier bouton disponible pour la navigation manette
		if (m_SellWeedButton)
			GetGame().GetWorkspace().SetFocusedWidget(m_SellWeedButton);
		else if (m_CloseButton)
			GetGame().GetWorkspace().SetFocusedWidget(m_CloseButton);
		
		// Met a jour les labels des boutons avec le prix unitaire courant (avec cours applique)
		UpdateButtonLabels();
	}
	
	//------------------------------------------------------------------------------------------------
	// Met a jour le texte des boutons vendre avec le prix unitaire effectif et le cours
	//------------------------------------------------------------------------------------------------
	void UpdateButtonLabels()
	{
		// Cannabis
		int weedBase = JobDrugSystem.GetDrugPrice(EDrugType.WEED);
		int weedEffective = JobMarketManager.GetInstance().GetEffectivePrice(EMarketItem.CANNABIS, weedBase);
		int weedCours = JobMarketManager.GetInstance().GetCours(EMarketItem.CANNABIS);
		SetButtonText(m_SellWeedButton,
			string.Format("Vendre tout Weed (%1c/u %2)", weedEffective, FormatCours(weedCours)));
		
		// Cocaine
		int cocaineBase = JobDrugSystem.GetDrugPrice(EDrugType.COCAINE);
		int cocaineEffective = JobMarketManager.GetInstance().GetEffectivePrice(EMarketItem.COCAINE, cocaineBase);
		int cocaineCours = JobMarketManager.GetInstance().GetCours(EMarketItem.COCAINE);
		SetButtonText(m_SellCocaineButton,
			string.Format("Vendre tout Cocaine (%1c/u %2)", cocaineEffective, FormatCours(cocaineCours)));
	}
	
	//------------------------------------------------------------------------------------------------
	// Helper : trouve le 1er TextWidget enfant d un bouton et change son texte
	//------------------------------------------------------------------------------------------------
	void SetButtonText(ButtonWidget btn, string text)
	{
		if (!btn)
			return;
		Widget c = btn.GetChildren();
		while (c)
		{
			TextWidget tw = TextWidget.Cast(c);
			if (tw)
			{
				tw.SetText(text);
				return;
			}
			c = c.GetSibling();
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Formate le cours en %, avec signe
	//------------------------------------------------------------------------------------------------
	string FormatCours(int cours)
	{
		if (cours == 0)
			return "(stable)";
		if (cours > 0)
			return string.Format("(+%1%%)", cours);
		return string.Format("(%1%%)", cours);
	}
	
	//------------------------------------------------------------------------------------------------
	void Initialize()
	{
		// Rien de special pour l'instant
	}
	
	//------------------------------------------------------------------------------------------------
	void OnSellWeed()
	{
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc)
			return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc)
			return;
		jpc.ClientAskSellDrug(EDrugType.WEED);
	}
	
	//------------------------------------------------------------------------------------------------
	void OnSellCocaine()
	{
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc)
			return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc)
			return;
		jpc.ClientAskSellDrug(EDrugType.COCAINE);
	}
	
	//------------------------------------------------------------------------------------------------
	void CloseMenuInternal()
	{
		GetGame().GetMenuManager().CloseMenu(this);
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuClose()
	{
		s_Instance = null;
		super.OnMenuClose();
	}
}

//------------------------------------------------------------------------------------------------
class DealerClickHandler : ScriptedWidgetEventHandler
{
	JobDrugDealerMenu m_Menu;
	string m_Action;
	
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (!m_Menu)
			return false;
		
		if (m_Action == "close")
		{
			m_Menu.CloseMenuInternal();
			return true;
		}
		
		if (m_Action == "sell_weed")
		{
			m_Menu.OnSellWeed();
			return true;
		}
		
		if (m_Action == "sell_cocaine")
		{
			m_Menu.OnSellCocaine();
			return true;
		}
		
		return false;
	}
}
