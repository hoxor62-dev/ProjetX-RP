//------------------------------------------------------------------------------------------------
// JobPoliceTerminalAction.c
//
// UserAction "Fiche judiciaire" pour les forces de l ordre (Police + Militaire).
// A attacher via ActionsManagerComponent sur un prefab ordinateur/tablette dans le commissariat.
//
// L action n est VISIBLE que pour Police/Militaire (client-side check via CanBeShownScript).
// Le check UID/metier est aussi refait cote serveur dans chaque RPC (IsCallerOfficer),
// donc meme si un cheater force l ouverture du menu, aucune donnee ne remonte / ne se modifie.
//------------------------------------------------------------------------------------------------

class JobPoliceTerminalAction : ScriptedUserAction
{
	//------------------------------------------------------------------------------------------------
	// Verifie que le joueur local a le metier Police ou Militaire (via le composant local)
	//------------------------------------------------------------------------------------------------
	private bool IsLocalPlayerOfficer()
	{
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc)
			return false;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc)
			return false;
		int job = jpc.GetJob();
		return (job == EJobType.POLICIER || job == EJobType.MILITAIRE);
	}
	
	//------------------------------------------------------------------------------------------------
	override bool CanBeShownScript(IEntity user)
	{
		return IsLocalPlayerOfficer();
	}
	
	//------------------------------------------------------------------------------------------------
	override bool CanBePerformedScript(IEntity user)
	{
		return IsLocalPlayerOfficer();
	}
	
	//------------------------------------------------------------------------------------------------
	override bool GetActionNameScript(out string outName)
	{
		outName = "Fiche judiciaire";
		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
	{
		// Garde multijoueur : seul le joueur local execute
		IEntity localPlayer = SCR_PlayerController.GetLocalControlledEntity();
		if (!localPlayer || pUserEntity != localPlayer)
			return;
		if (!IsLocalPlayerOfficer())
			return;
		
		// IMPORTANT : ChimeraMenuPreset.JobPoliceRecordMenu doit etre enregistre
		// dans la config Workbench (comme les autres menus custom du mod).
		GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.JobPoliceRecordMenu);
	}
}
