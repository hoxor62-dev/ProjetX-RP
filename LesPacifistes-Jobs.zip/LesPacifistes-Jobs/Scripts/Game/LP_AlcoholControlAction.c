//------------------------------------------------------------------------------------------------
// LP_AlcoholControlAction.c
// Action "Controle alcool" a placer sur le prefab PlayerController / personnage joueur.
// Visible UNIQUEMENT pour les metiers POLICIER et MILITAIRE.
// Ouvre un menu affichant le taux d alcool de la cible.
//------------------------------------------------------------------------------------------------

class LP_AlcoholControlAction : ScriptedUserAction
{
	//------------------------------------------------------------------------------------------------
	override bool CanBeShownScript(IEntity user)
	{
		if (!user) return false;
		
		JobCharacterJobComponent jcjc = JobCharacterJobComponent.Cast(
			user.FindComponent(JobCharacterJobComponent));
		if (!jcjc) return false;
		
		EJobType job = jcjc.GetJob();
		return (job == EJobType.POLICIER || job == EJobType.MILITAIRE);
	}
	
	//------------------------------------------------------------------------------------------------
	override bool CanBePerformedScript(IEntity user)
	{
		return CanBeShownScript(user);
	}
	
	//------------------------------------------------------------------------------------------------
	override bool GetActionNameScript(out string outName)
	{
		outName = "Controle alcool";
		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
	{
		PlayerController pc = PlayerController.Cast(GetGame().GetPlayerController());
		if (!pc) return;
		if (pUserEntity != pc.GetControlledEntity()) return;
		
		// Anti-cheat serveur : re-verifie le metier
		JobCharacterJobComponent jcjc = JobCharacterJobComponent.Cast(
			pUserEntity.FindComponent(JobCharacterJobComponent));
		if (!jcjc) return;
		EJobType job = jcjc.GetJob();
		if (job != EJobType.POLICIER && job != EJobType.MILITAIRE) return;
		
		// Recupere le playerId de la CIBLE (le joueur controle)
		int targetPlayerId = GetGame().GetPlayerManager().GetPlayerIdFromControlledEntity(pOwnerEntity);
		if (targetPlayerId <= 0) return;
		
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		
		jpc.ClientAskAlcoholControl(targetPlayerId);
	}
}
