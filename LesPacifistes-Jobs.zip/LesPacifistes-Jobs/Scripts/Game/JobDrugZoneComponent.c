//------------------------------------------------------------------------------------------------
// JobDrugZoneComponent.c
// Component a ajouter sur le MEME prefab que le component d extraction de drogue.
// Definit quelle drogue cette zone represente (cannabis / cocaine) pour lier la taxation
// au bon gang, et gere la logique de capture de zone.
//
// CONFIGURATION WORKBENCH :
//   - Ajouter ce component au prefab d extraction
//   - Regler m_DrugType : 1 = CANNABIS, 2 = COCAINE (= valeurs EMarketItem)
//   - Le prefab doit avoir un RplComponent pour les actions reseau
//------------------------------------------------------------------------------------------------

class JobDrugZoneComponentClass : ScriptComponentClass
{
}

class JobDrugZoneComponent : ScriptComponent
{
	[Attribute("1", UIWidgets.ComboBox, "Type de drogue de cette zone", "", ParamEnumArray.FromEnum(EMarketItem))]
	int m_DrugType;  // EMarketItem : CANNABIS=4, COCAINE=5
	
	[Attribute("30.0", UIWidgets.EditBox, "Rayon de la zone de capture (metres)")]
	float m_CaptureRadius;
	
	// === Etat de capture en cours (serveur uniquement) ===
	bool m_CaptureInProgress = false;
	string m_CapturingGangName = "";  // Gang qui tente la capture
	int m_CaptureSecondsElapsed = 0;  // Secondes accumulees (pause si conteste)
	int m_CapturingPlayerId = -1;     // Joueur qui a lance la capture
	
	const int CAPTURE_DURATION_SECONDS = 1800;  // 30 minutes
	
	//------------------------------------------------------------------------------------------------
	int GetDrugType()
	{
		return m_DrugType;
	}
	
	float GetCaptureRadius()
	{
		return m_CaptureRadius;
	}
	
	//------------------------------------------------------------------------------------------------
	// Retourne le label lisible de la drogue
	//------------------------------------------------------------------------------------------------
	string GetDrugLabel()
	{
		if (m_DrugType == EMarketItem.CANNABIS)
			return "Cannabis";
		if (m_DrugType == EMarketItem.COCAINE)
			return "Cocaine";
		return "Inconnu";
	}
	
	//------------------------------------------------------------------------------------------------
	bool IsCaptureInProgress()
	{
		return m_CaptureInProgress;
	}
	
	string GetCapturingGang()
	{
		return m_CapturingGangName;
	}
}
