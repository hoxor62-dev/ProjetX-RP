//------------------------------------------------------------------------------------------------
// JobCompanyManager.c
// Singleton serveur qui gere les entreprises (companies) des joueurs.
//
// Fonctionnalites V1 (Session 1) :
//   - Creation d entreprise (cout 30000 capsules)
//   - 1 entreprise max par joueur (un joueur ne peut etre patron que d UNE entreprise)
//   - 1 employe ne peut etre employe que d UNE entreprise a la fois
//   - Persistance JSON ($profile:LesPacifistesJobs/companies.json)
//
// Architecture preparee pour les blocs suivants :
//   - JobCompanyEmployee : structure employe (m_UID, m_DisplayName, m_HiredAt)
//   - JobCompanyOrder : bons de commande (statut, items, prix, employe)
//   - JobCompanyChatMsg : messages du chat interne
//   - JobCompany : structure principale (patron, employes, ordres, chat, benefices)
//
// Codes retour des operations (utiliser pour notif chat) :
//   CreateCompany : 0 OK / 1 nom vide / 2 nom deja pris / 3 joueur deja patron /
//                   4 solde insuffisant / 5 joueur deja employe ailleurs / 6 metier invalide
//   DissolveCompany : 0 OK / 1 pas patron / 2 entreprise introuvable
//------------------------------------------------------------------------------------------------

// ===== STRUCTURES DE DONNEES =====

// Employe d une entreprise
class JobCompanyEmployee
{
	string m_UID;
	string m_DisplayName;
	int m_HiredAt;       // timestamp d embauche (System.GetUnixTime ou equivalent)
}

// Item depose dans un bon de commande
class JobCompanyOrderItem
{
	string m_PrefabName;
	int m_Quantity = 1;
}

// Bon de commande (cree par un employe ou par le patron lui-meme)
class JobCompanyOrder
{
	int m_OrderId;                  // identifiant local (auto-incrementant dans l entreprise)
	string m_AuthorUID;             // employe (ou patron) qui a cree le bon
	string m_AuthorDisplayName;
	int m_Status = 0;               // 0 = en attente, 1 = valide, 2 = refuse
	int m_ProposedPrice = 0;        // capsules demandees par l auteur
	int m_FinalPrice = 0;           // capsules effectivement payees (si valide)
	int m_CreatedAt;                // timestamp creation
	int m_ResolvedAt;               // timestamp validation/refus (0 si en attente)
	bool m_ItemsRecovered = false;  // true si l auteur a recupere ses items apres refus
	ref array<ref JobCompanyOrderItem> m_Items = new array<ref JobCompanyOrderItem>();
}

// Message du chat interne entreprise
class JobCompanyChatMsg
{
	int m_Timestamp;
	string m_AuthorUID;
	string m_AuthorDisplayName;
	string m_Text;
}

// Invitation en attente : un patron invite un joueur a rejoindre son entreprise.
// Le joueur cible va chez le Maire pour accepter/refuser. Volatile (perdue au reboot).
// Une seule invitation en attente par joueur cible.
class JobCompanyInvitation
{
	string m_TargetUID;          // UID du joueur invite
	string m_CompanyName;        // Nom de l entreprise
	int m_JobType;               // Metier de l entreprise (pour assignation a l acceptation)
	string m_OwnerUID;           // UID du patron qui invite
	string m_OwnerDisplayName;   // Nom RP/affichage du patron
	int m_CreatedAt;             // Timestamp creation (pour expiration 24h)
}

// Une entreprise complete
class JobCompany
{
	string m_Name;                  // nom unique de l entreprise
	EJobType m_JobType;             // metier de l entreprise (MINEUR, AGRICULTEUR, BUCHERON, CONCESSIONNAIRE, VENDEUR_IMMOBILIER)
	string m_OwnerUID;              // UID du patron
	string m_OwnerDisplayName;
	int m_CreatedAt;                // timestamp creation
	int m_Benefits = 0;             // cagnotte entreprise (capsules)
	int m_TotalSales = 0;           // nombre total de ventes/bons valides (stats)
	int m_NextOrderId = 1;          // pour generer les m_OrderId uniques
	
	ref array<ref JobCompanyEmployee> m_Employees = new array<ref JobCompanyEmployee>();
	ref array<ref JobCompanyOrder> m_Orders = new array<ref JobCompanyOrder>();   // en attente + historique
	ref array<ref JobCompanyChatMsg> m_ChatMessages = new array<ref JobCompanyChatMsg>();  // limite a 100
	
	//------------------------------------------------------------------------------------------------
	bool IsOwner(string uid)
	{
		return uid != "" && uid == m_OwnerUID;
	}
	
	bool IsEmployee(string uid)
	{
		foreach (JobCompanyEmployee e : m_Employees)
		{
			if (e && e.m_UID == uid)
				return true;
		}
		return false;
	}
	
	bool IsMember(string uid)
	{
		return IsOwner(uid) || IsEmployee(uid);
	}
}

// ===== LE MANAGER =====

class JobCompanyManager
{
	static ref JobCompanyManager s_Instance;
	
	const string SAVE_PATH = "$profile:LesPacifistesJobs/companies.json";
	const int CREATION_COST = 30000;
	const int MAX_EMPLOYEES = 5;
	const int MAX_CHAT_MESSAGES = 100;
	
	// Toutes les entreprises (cle = nom unique)
	ref map<string, ref JobCompany> m_Companies;
	
	// Invitations en attente (cle = UID joueur invite). Une seule invit/joueur.
	// Volatile : reset au reboot (cf. ton choix).
	ref map<string, ref JobCompanyInvitation> m_Invitations;
	
	// Constantes invitations
	const int INVITATION_EXPIRY_SECONDS = 86400;  // 24h
	const int INVITATION_CLEANUP_INTERVAL_MS = 60000;  // verif expiration toutes les 60s
	
	// === TAXE ENTREPRISE (modifiable par le President) ===
	// Prelevee a chaque InjectBenefits : un % du montant va a la cagnotte municipale (BonPoint Treasury).
	const int DEFAULT_COMPANY_TAX_PERCENT = 10;
	const int MIN_COMPANY_TAX_PERCENT = 0;
	const int MAX_COMPANY_TAX_PERCENT = 50;
	int m_CompanyTaxPercent = DEFAULT_COMPANY_TAX_PERCENT;
	const string TAX_PATH = "$profile:LesPacifistesJobs/company_tax.json";
	
	//------------------------------------------------------------------------------------------------
	void JobCompanyManager()
	{
		m_Companies = new map<string, ref JobCompany>();
		m_Invitations = new map<string, ref JobCompanyInvitation>();
	}
	
	//------------------------------------------------------------------------------------------------
	static JobCompanyManager GetInstance()
	{
		if (!s_Instance)
		{
			s_Instance = new JobCompanyManager();
			s_Instance.Init();
		}
		return s_Instance;
	}
	
	//------------------------------------------------------------------------------------------------
	void Init()
	{
		Print("[JobCompanyManager] Initialisation", LogLevel.NORMAL);
		LoadFromDisk();
		LoadTaxRate();
		
		// Demarre la boucle de cleanup des invitations expirees (volatile, pas de persistance)
		GetGame().GetCallqueue().CallLater(CleanupExpiredInvitations, INVITATION_CLEANUP_INTERVAL_MS, true);
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== RECHERCHE =====
	//------------------------------------------------------------------------------------------------
	
	// Retourne l entreprise dont uid est le patron, ou null
	JobCompany GetCompanyOwnedBy(string uid)
	{
		if (uid == "")
			return null;
		foreach (string name, JobCompany c : m_Companies)
		{
			if (c && c.m_OwnerUID == uid)
				return c;
		}
		return null;
	}
	
	// Retourne l entreprise ou uid est employe (PAS patron), ou null
	JobCompany GetCompanyEmployedBy(string uid)
	{
		if (uid == "")
			return null;
		foreach (string name, JobCompany c : m_Companies)
		{
			if (c && c.IsEmployee(uid))
				return c;
		}
		return null;
	}
	
	// Retourne l entreprise ou uid est membre (patron OU employe), ou null
	JobCompany GetCompanyOfPlayer(string uid)
	{
		JobCompany c = GetCompanyOwnedBy(uid);
		if (c)
			return c;
		return GetCompanyEmployedBy(uid);
	}
	
	JobCompany GetCompanyByName(string name)
	{
		return m_Companies.Get(name);
	}
	
	bool CompanyNameExists(string name)
	{
		return m_Companies.Contains(name);
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== METIERS AUTORISES =====
	// Pour la creation d entreprise, seuls certains metiers sont disponibles.
	//------------------------------------------------------------------------------------------------
	static bool IsJobTypeAllowedForCompany(EJobType job)
	{
		return job == EJobType.MINEUR
			|| job == EJobType.AGRICULTEUR
			|| job == EJobType.BUCHERON
			|| job == EJobType.CONCESSIONNAIRE
			|| job == EJobType.VENDEUR_IMMOBILIER;
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== CREATION =====
	// Cree une entreprise et debite 30000 capsules au patron.
	//
	// Retourne :
	//   0 = OK
	//   1 = nom vide
	//   2 = nom deja pris
	//   3 = joueur deja patron d une autre entreprise
	//   4 = solde insuffisant
	//   5 = joueur deja employe ailleurs
	//   6 = metier invalide (pas dans la liste autorisee)
	//------------------------------------------------------------------------------------------------
	int CreateCompany(string ownerUID, string ownerDisplayName, string companyName, EJobType jobType)
	{
		// 1. Nettoyage du nom
		string trimmed = TrimString(companyName);
		if (trimmed == "")
			return 1;
		
		// 2. Metier valide ?
		if (!IsJobTypeAllowedForCompany(jobType))
			return 6;
		
		// 3. Nom deja pris ?
		if (CompanyNameExists(trimmed))
			return 2;
		
		// 4. Le joueur est-il deja patron ?
		if (GetCompanyOwnedBy(ownerUID))
			return 3;
		
		// 5. Le joueur est-il deja employe ailleurs ?
		if (GetCompanyEmployedBy(ownerUID))
			return 5;
		
		// 6. Solde suffisant ?
		CapsuleEconomyManager eco = CapsuleEconomyManager.GetInstance();
		if (!eco)
			return 4;
		int balance = eco.GetCapsules(ownerUID);
		if (balance < CREATION_COST)
			return 4;
		
		// 7. Debite le cout
		eco.AddCapsules(ownerUID, -CREATION_COST);
		
		// 8. Cree l entreprise
		JobCompany c = new JobCompany();
		c.m_Name = trimmed;
		c.m_JobType = jobType;
		c.m_OwnerUID = ownerUID;
		c.m_OwnerDisplayName = ownerDisplayName;
		c.m_CreatedAt = System.GetUnixTime();
		c.m_Benefits = 0;
		c.m_TotalSales = 0;
		c.m_NextOrderId = 1;
		m_Companies.Set(trimmed, c);
		
		SaveToDisk();
		
		Print(string.Format("[JobCompanyManager] Creation entreprise : '%1' (metier=%2, owner=%3)",
			trimmed, JobData.GetJobLabel(jobType), ownerUID), LogLevel.NORMAL);
		return 0;
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== DISSOLUTION =====
	// Le patron dissout son entreprise. Pas de remboursement.
	// (Plus tard : restituer les items en attente aux employes, mais V1 = pas d ordres)
	//
	// Retourne :
	//   0 = OK
	//   1 = pas patron de cette entreprise
	//   2 = entreprise introuvable
	//------------------------------------------------------------------------------------------------
	int DissolveCompany(string ownerUID, string companyName, out array<string> outEmployeeUIDs)
	{
		JobCompany c = GetCompanyByName(companyName);
		if (!c)
			return 2;
		if (!c.IsOwner(ownerUID))
			return 1;
		
		// Collecte les UIDs des employes pour notification
		if (outEmployeeUIDs)
		{
			foreach (JobCompanyEmployee e : c.m_Employees)
			{
				if (e && e.m_UID != "")
					outEmployeeUIDs.Insert(e.m_UID);
			}
		}
		
		// TODO V2 : restituer les items des bons en attente aux employes
		
		m_Companies.Remove(companyName);
		SaveToDisk();
		
		Print(string.Format("[JobCompanyManager] Dissolution entreprise : '%1' (owner=%2)",
			companyName, ownerUID), LogLevel.NORMAL);
		return 0;
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== BONS DE COMMANDE =====
	//------------------------------------------------------------------------------------------------
	
	// Cree un bon de commande (l auteur peut etre employe OU patron).
	// items : liste { prefab, quantite } deja "preleves" cote serveur (deja retires du joueur).
	// Retourne :
	//   0 = OK (outOrderId rempli avec l id du bon cree)
	//   1 = l auteur n est pas membre d une entreprise
	//   2 = prix propose invalide (<= 0)
	//   3 = liste d items vide
	int CreateOrder(string authorUID, string authorDisplayName, int proposedPrice,
		array<ref JobCompanyOrderItem> items, out int outOrderId, out string outCompanyName)
	{
		outOrderId = 0;
		outCompanyName = "";
		
		JobCompany c = GetCompanyOfPlayer(authorUID);
		if (!c)
			return 1;
		if (proposedPrice <= 0)
			return 2;
		if (!items || items.Count() == 0)
			return 3;
		
		JobCompanyOrder order = new JobCompanyOrder();
		order.m_OrderId = c.m_NextOrderId;
		c.m_NextOrderId = c.m_NextOrderId + 1;
		order.m_AuthorUID = authorUID;
		order.m_AuthorDisplayName = authorDisplayName;
		order.m_Status = 0;  // en attente
		order.m_ProposedPrice = proposedPrice;
		order.m_FinalPrice = 0;
		order.m_CreatedAt = System.GetUnixTime();
		order.m_ResolvedAt = 0;
		foreach (JobCompanyOrderItem it : items)
		{
			if (it)
				order.m_Items.Insert(it);
		}
		c.m_Orders.Insert(order);
		SaveToDisk();
		
		outOrderId = order.m_OrderId;
		outCompanyName = c.m_Name;
		Print(string.Format("[JobCompanyManager] Bon cree : entreprise=%1 id=%2 auteur=%3 prix=%4 items=%5",
			c.m_Name, order.m_OrderId, authorUID, proposedPrice, items.Count()), LogLevel.NORMAL);
		return 0;
	}
	
	//------------------------------------------------------------------------------------------------
	// Patron accepte un bon : credit l employe + debit la cagnotte + bon valide.
	// finalPrice : peut differer du prix propose (negociation possible).
	// Retourne :
	//   0 = OK (outAuthorUID + outItems remplis pour livrer les items au patron)
	//   1 = pas patron
	//   2 = bon introuvable
	//   3 = bon deja resolu (pas en attente)
	//   4 = cagnotte entreprise insuffisante
	//   5 = prix final invalide (<= 0)
	int AcceptOrder(string ownerUID, string companyName, int orderId, int finalPrice,
		out string outAuthorUID, out array<ref JobCompanyOrderItem> outItems)
	{
		outAuthorUID = "";
		outItems = null;
		
		JobCompany c = GetCompanyByName(companyName);
		if (!c)
			return 2;
		if (!c.IsOwner(ownerUID))
			return 1;
		if (finalPrice <= 0)
			return 5;
		
		JobCompanyOrder order = FindOrder(c, orderId);
		if (!order)
			return 2;
		if (order.m_Status != 0)
			return 3;
		if (c.m_Benefits < finalPrice)
			return 4;
		
		// Debite la cagnotte entreprise
		c.m_Benefits = c.m_Benefits - finalPrice;
		c.m_TotalSales = c.m_TotalSales + 1;
		
		// Met a jour le bon
		order.m_Status = 1;  // valide
		order.m_FinalPrice = finalPrice;
		order.m_ResolvedAt = System.GetUnixTime();
		
		outAuthorUID = order.m_AuthorUID;
		outItems = order.m_Items;
		
		// Credite l employe (capsules sur son compte)
		CapsuleEconomyManager eco = CapsuleEconomyManager.GetInstance();
		if (eco)
			eco.AddCapsules(order.m_AuthorUID, finalPrice);
		
		SaveToDisk();
		Print(string.Format("[JobCompanyManager] Bon accepte : entreprise=%1 id=%2 prix=%3",
			c.m_Name, orderId, finalPrice), LogLevel.NORMAL);
		return 0;
	}
	
	//------------------------------------------------------------------------------------------------
	// Patron refuse un bon : items doivent etre restitues a l auteur (le caller fait spawn).
	// Retourne :
	//   0 = OK (outAuthorUID + outItems remplis pour restitution)
	//   1 = pas patron
	//   2 = bon introuvable
	//   3 = bon deja resolu
	int RefuseOrder(string ownerUID, string companyName, int orderId,
		out string outAuthorUID, out array<ref JobCompanyOrderItem> outItems)
	{
		outAuthorUID = "";
		outItems = null;
		
		JobCompany c = GetCompanyByName(companyName);
		if (!c)
			return 2;
		if (!c.IsOwner(ownerUID))
			return 1;
		
		JobCompanyOrder order = FindOrder(c, orderId);
		if (!order)
			return 2;
		if (order.m_Status != 0)
			return 3;
		
		order.m_Status = 2;  // refuse
		order.m_FinalPrice = 0;
		order.m_ResolvedAt = System.GetUnixTime();
		
		outAuthorUID = order.m_AuthorUID;
		outItems = order.m_Items;
		
		SaveToDisk();
		Print(string.Format("[JobCompanyManager] Bon refuse : entreprise=%1 id=%2",
			c.m_Name, orderId), LogLevel.NORMAL);
		return 0;
	}
	
	//------------------------------------------------------------------------------------------------
	// L auteur d un bon REFUSE recupere ses items.
	// Verifications : c est bien l auteur, le bon est REFUSE, items pas deja recuperes.
	// Sortie : outItems pour livraison cote caller (le spawn dans l inventaire est fait
	// par JobPlayerComponent qui a access au PlayerController).
	//
	// Retourne :
	//   0 = OK (outItems rempli pour livraison)
	//   1 = bon introuvable
	//   2 = vous n etes pas l auteur du bon
	//   3 = le bon n a pas le statut REFUSE
	//   4 = items deja recuperes
	//   5 = entreprise introuvable
	int RecoverRefusedOrderItems(string authorUID, string companyName, int orderId,
		out array<ref JobCompanyOrderItem> outItems)
	{
		outItems = null;
		JobCompany c = GetCompanyByName(companyName);
		if (!c)
			return 5;
		JobCompanyOrder o = FindOrder(c, orderId);
		if (!o)
			return 1;
		if (o.m_AuthorUID != authorUID)
			return 2;
		if (o.m_Status != 2)  // doit etre REFUSE
			return 3;
		if (o.m_ItemsRecovered)
			return 4;
		
		// Marque comme recupere ET vide les items (pour ne pas duplique si on re-clique)
		o.m_ItemsRecovered = true;
		outItems = o.m_Items;
		// On garde le bon dans l historique (statut REFUSE + recovered=true)
		SaveToDisk();
		
		Print(string.Format("[JobCompanyManager] Items recuperes : entreprise=%1 id=%2 auteur=%3",
			c.m_Name, orderId, authorUID), LogLevel.NORMAL);
		return 0;
	}
	
	//------------------------------------------------------------------------------------------------
	// Retire les benefices de l entreprise vers le compte du patron.
	// Retourne le montant retire (0 si rien ou pas patron).
	//------------------------------------------------------------------------------------------------
	int WithdrawBenefits(string ownerUID, string companyName)
	{
		JobCompany c = GetCompanyByName(companyName);
		if (!c || !c.IsOwner(ownerUID))
			return 0;
		
		int amount = c.m_Benefits;
		if (amount <= 0)
			return 0;
		
		CapsuleEconomyManager eco = CapsuleEconomyManager.GetInstance();
		if (!eco)
			return 0;
		
		eco.AddCapsules(ownerUID, amount);
		c.m_Benefits = 0;
		SaveToDisk();
		
		Print(string.Format("[JobCompanyManager] Benefices retires : entreprise=%1 montant=%2",
			c.m_Name, amount), LogLevel.NORMAL);
		return amount;
	}
	
	//------------------------------------------------------------------------------------------------
	// Le patron injecte de ses capsules personnelles dans la cagnotte de l entreprise.
	// Verifie qu il a bien le solde + debite + credite la cagnotte.
	// 
	// Taxe entreprise (m_CompanyTaxPercent, defaut 10%) :
	//   - Patron debite : montant total (amount)
	//   - Cagnotte entreprise gagne : amount - taxe
	//   - Cagnotte municipale gagne : taxe
	//
	// Retourne :
	//   0 = OK
	//   1 = pas patron
	//   2 = montant invalide (<= 0)
	//   3 = solde personnel insuffisant
	//   4 = entreprise introuvable
	//------------------------------------------------------------------------------------------------
	int InjectBenefits(string ownerUID, string companyName, int amount)
	{
		JobCompany c = GetCompanyByName(companyName);
		if (!c)
			return 4;
		if (!c.IsOwner(ownerUID))
			return 1;
		if (amount <= 0)
			return 2;
		
		CapsuleEconomyManager eco = CapsuleEconomyManager.GetInstance();
		if (!eco)
			return 4;
		int balance = eco.GetCapsules(ownerUID);
		if (balance < amount)
			return 3;
		
		// Calcule la taxe + montant net pour l entreprise
		int tax = amount * m_CompanyTaxPercent / 100;
		int forCompany = amount - tax;
		
		// Debite le patron du montant total
		eco.AddCapsules(ownerUID, -amount);
		
		// Credite la cagnotte entreprise (net) + cagnotte ville (taxe)
		c.m_Benefits = c.m_Benefits + forCompany;
		if (tax > 0)
		{
			JobBonPointManager bpm = JobBonPointManager.GetInstance();
			if (bpm)
				bpm.AddToTreasury(tax);
		}
		SaveToDisk();
		
		Print(string.Format("[JobCompanyManager] Injection : entreprise=%1 montant=%2 (taxe=%3, net=%4) par %5",
			c.m_Name, amount, tax, forCompany, ownerUID), LogLevel.NORMAL);
		return 0;
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== GESTION EMPLOYES =====
	//------------------------------------------------------------------------------------------------
	
	// Invite un joueur a rejoindre l entreprise. Le joueur recevra une notif chat
	// et devra aller chez le Maire pour accepter/refuser.
	// Retourne :
	//   0 = OK invitation envoyee
	//   1 = pas patron
	//   2 = entreprise pleine (5 employes max)
	//   3 = cible deja patron d une autre entreprise
	//   4 = cible deja employe (ailleurs OU dans la meme company)
	//   5 = entreprise introuvable
	//   6 = cible a deja une invitation en attente d un autre patron
	int InviteEmployee(string ownerUID, string ownerDisplayName, string companyName,
		string targetUID)
	{
		JobCompany c = GetCompanyByName(companyName);
		if (!c)
			return 5;
		if (!c.IsOwner(ownerUID))
			return 1;
		if (c.m_Employees.Count() >= MAX_EMPLOYEES)
			return 2;
		if (GetCompanyOwnedBy(targetUID))
			return 3;
		if (GetCompanyEmployedBy(targetUID))
			return 4;
		// Verifie qu il n y a pas deja une invitation pour ce joueur
		if (m_Invitations.Contains(targetUID))
			return 6;
		
		JobCompanyInvitation invit = new JobCompanyInvitation();
		invit.m_TargetUID = targetUID;
		invit.m_CompanyName = c.m_Name;
		invit.m_JobType = c.m_JobType;
		invit.m_OwnerUID = ownerUID;
		invit.m_OwnerDisplayName = ownerDisplayName;
		invit.m_CreatedAt = System.GetUnixTime();
		m_Invitations.Set(targetUID, invit);
		
		Print(string.Format("[JobCompanyManager] Invitation envoyee : entreprise=%1 cible=%2",
			c.m_Name, targetUID), LogLevel.NORMAL);
		return 0;
	}
	
	//------------------------------------------------------------------------------------------------
	// Le joueur cible accepte son invitation. Devient employe + recupere les infos pour
	// l assignation du metier cote caller (outJobType + outCompanyName + outOwnerUID).
	// Retourne :
	//   0 = OK
	//   1 = pas d invitation en attente
	//   2 = entreprise dissoute entre temps (invitation orpheline -> on la nettoie)
	//   3 = entreprise est maintenant pleine
	//   4 = le joueur est devenu patron ou employe d une autre entre temps
	int AcceptInvitation(string targetUID, string targetDisplayName,
		out int outJobType, out string outCompanyName, out string outOwnerUID)
	{
		outJobType = 0;
		outCompanyName = "";
		outOwnerUID = "";
		
		JobCompanyInvitation invit = m_Invitations.Get(targetUID);
		if (!invit)
			return 1;
		
		JobCompany c = GetCompanyByName(invit.m_CompanyName);
		if (!c)
		{
			// Entreprise dissoute entre temps : nettoie
			m_Invitations.Remove(targetUID);
			return 2;
		}
		if (c.m_Employees.Count() >= MAX_EMPLOYEES)
			return 3;
		// Securise : le joueur a peut-etre cree une entreprise ou ete recrute ailleurs
		if (GetCompanyOfPlayer(targetUID))
		{
			m_Invitations.Remove(targetUID);
			return 4;
		}
		
		// Recrutement effectif
		JobCompanyEmployee e = new JobCompanyEmployee();
		e.m_UID = targetUID;
		e.m_DisplayName = targetDisplayName;
		e.m_HiredAt = System.GetUnixTime();
		c.m_Employees.Insert(e);
		
		// Output pour assignation du metier cote caller
		outJobType = c.m_JobType;
		outCompanyName = c.m_Name;
		outOwnerUID = c.m_OwnerUID;
		
		// Supprime l invitation
		m_Invitations.Remove(targetUID);
		SaveToDisk();
		
		Print(string.Format("[JobCompanyManager] Invitation acceptee : entreprise=%1 employe=%2",
			c.m_Name, targetUID), LogLevel.NORMAL);
		return 0;
	}
	
	//------------------------------------------------------------------------------------------------
	// Le joueur cible refuse son invitation. outCompanyName + outOwnerUID remplis pour
	// notification chat au patron.
	// Retourne :
	//   0 = OK
	//   1 = pas d invitation
	int RefuseInvitation(string targetUID, out string outCompanyName, out string outOwnerUID)
	{
		outCompanyName = "";
		outOwnerUID = "";
		JobCompanyInvitation invit = m_Invitations.Get(targetUID);
		if (!invit)
			return 1;
		outCompanyName = invit.m_CompanyName;
		outOwnerUID = invit.m_OwnerUID;
		m_Invitations.Remove(targetUID);
		Print(string.Format("[JobCompanyManager] Invitation refusee : entreprise=%1 cible=%2",
			outCompanyName, targetUID), LogLevel.NORMAL);
		return 0;
	}
	
	//------------------------------------------------------------------------------------------------
	// Retourne l invitation en attente d un joueur (null si aucune)
	JobCompanyInvitation GetInvitationFor(string targetUID)
	{
		return m_Invitations.Get(targetUID);
	}
	
	//------------------------------------------------------------------------------------------------
	// Nettoie les invitations expirees (appele toutes les 60 secondes via CallLater).
	// Une invitation expire apres 24h.
	void CleanupExpiredInvitations()
	{
		int now = System.GetUnixTime();
		array<string> toRemove = new array<string>();
		foreach (string targetUID, JobCompanyInvitation invit : m_Invitations)
		{
			if (!invit) continue;
			if (now - invit.m_CreatedAt >= INVITATION_EXPIRY_SECONDS)
				toRemove.Insert(targetUID);
		}
		foreach (string uid : toRemove)
		{
			m_Invitations.Remove(uid);
			Print(string.Format("[JobCompanyManager] Invitation expiree (24h) : cible=%1", uid),
				LogLevel.NORMAL);
		}
	}
	
	// Licencie un employe.
	// Retourne :
	//   0 = OK (outEmployeeName rempli)
	//   1 = pas patron
	//   2 = employe introuvable dans cette entreprise
	//   5 = entreprise introuvable
	int FireEmployee(string ownerUID, string companyName, string targetUID, out string outEmployeeName)
	{
		outEmployeeName = "";
		JobCompany c = GetCompanyByName(companyName);
		if (!c)
			return 5;
		if (!c.IsOwner(ownerUID))
			return 1;
		
		for (int i = c.m_Employees.Count() - 1; i >= 0; i--)
		{
			JobCompanyEmployee e = c.m_Employees.Get(i);
			if (e && e.m_UID == targetUID)
			{
				outEmployeeName = e.m_DisplayName;
				c.m_Employees.Remove(i);
				SaveToDisk();
				Print(string.Format("[JobCompanyManager] Licenciement : entreprise=%1 employe=%2",
					c.m_Name, targetUID), LogLevel.NORMAL);
				return 0;
			}
		}
		return 2;
	}
	
	// Paye un salaire ponctuel a un employe (depuis la cagnotte vers son compte perso).
	// Retourne :
	//   0 = OK
	//   1 = pas patron
	//   2 = employe introuvable
	//   3 = montant invalide
	//   4 = cagnotte insuffisante
	//   5 = entreprise introuvable
	int PaySalary(string ownerUID, string companyName, string targetUID, int amount)
	{
		JobCompany c = GetCompanyByName(companyName);
		if (!c)
			return 5;
		if (!c.IsOwner(ownerUID))
			return 1;
		if (amount <= 0)
			return 3;
		if (!c.IsEmployee(targetUID))
			return 2;
		if (c.m_Benefits < amount)
			return 4;
		
		CapsuleEconomyManager eco = CapsuleEconomyManager.GetInstance();
		if (!eco)
			return 4;
		
		c.m_Benefits = c.m_Benefits - amount;
		eco.AddCapsules(targetUID, amount);
		SaveToDisk();
		
		Print(string.Format("[JobCompanyManager] Salaire : entreprise=%1 employe=%2 montant=%3",
			c.m_Name, targetUID, amount), LogLevel.NORMAL);
		return 0;
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== CHAT INTERNE =====
	//------------------------------------------------------------------------------------------------
	
	// Ajoute un message au chat de l entreprise.
	// L auteur doit etre membre. Le chat est plafonne a MAX_CHAT_MESSAGES (les plus anciens
	// sont retires en FIFO).
	// Retourne :
	//   0 = OK
	//   1 = pas membre
	//   2 = message vide
	//   3 = entreprise introuvable
	int AddChatMessage(string authorUID, string authorDisplayName, string companyName, string text)
	{
		JobCompany c = GetCompanyByName(companyName);
		if (!c)
			return 3;
		if (!c.IsMember(authorUID))
			return 1;
		string trimmed = TrimString(text);
		if (trimmed == "")
			return 2;
		
		JobCompanyChatMsg msg = new JobCompanyChatMsg();
		msg.m_Timestamp = System.GetUnixTime();
		msg.m_AuthorUID = authorUID;
		msg.m_AuthorDisplayName = authorDisplayName;
		msg.m_Text = trimmed;
		c.m_ChatMessages.Insert(msg);
		
		// Plafonne : retire les plus anciens si depassement
		while (c.m_ChatMessages.Count() > MAX_CHAT_MESSAGES)
			c.m_ChatMessages.Remove(0);
		
		SaveToDisk();
		return 0;
	}
	
	//------------------------------------------------------------------------------------------------
	// Helper interne : trouve un bon par son ID dans l entreprise
	//------------------------------------------------------------------------------------------------
	JobCompanyOrder FindOrder(JobCompany c, int orderId)
	{
		if (!c)
			return null;
		foreach (JobCompanyOrder o : c.m_Orders)
		{
			if (o && o.m_OrderId == orderId)
				return o;
		}
		return null;
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== ALIMENTATION DES BENEFICES =====
	// Methode appelable par d autres systemes (ex: ventes de drogue, livraisons, etc.)
	// pour ajouter des capsules a la cagnotte entreprise.
	// Pour V2 : si patron + employes ont une activite generant des benefices automatiques.
	//------------------------------------------------------------------------------------------------
	void AddBenefits(string companyName, int amount)
	{
		JobCompany c = GetCompanyByName(companyName);
		if (!c || amount <= 0)
			return;
		c.m_Benefits = c.m_Benefits + amount;
		SaveToDisk();
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== METHODES POUR LE MENU PRESIDENT =====
	//------------------------------------------------------------------------------------------------
	
	// Retourne le taux de taxe entreprise actuel (en %)
	int GetCompanyTaxPercent() { return m_CompanyTaxPercent; }
	
	//------------------------------------------------------------------------------------------------
	// Modifie le taux de taxe entreprise. Borne entre MIN et MAX.
	// Retourne le nouveau taux applique.
	//------------------------------------------------------------------------------------------------
	int SetCompanyTaxPercent(int newRate)
	{
		if (newRate < MIN_COMPANY_TAX_PERCENT)
			newRate = MIN_COMPANY_TAX_PERCENT;
		if (newRate > MAX_COMPANY_TAX_PERCENT)
			newRate = MAX_COMPANY_TAX_PERCENT;
		m_CompanyTaxPercent = newRate;
		SaveTaxRate();
		Print(string.Format("[JobCompanyManager] Taux de taxe entreprise modifie : %1%%",
			m_CompanyTaxPercent), LogLevel.NORMAL);
		return m_CompanyTaxPercent;
	}
	
	//------------------------------------------------------------------------------------------------
	// Persistance simple du taux de taxe entreprise (fichier dedie pour ne pas toucher companies.json)
	//------------------------------------------------------------------------------------------------
	void SaveTaxRate()
	{
		SCR_JsonSaveContext ctx = new SCR_JsonSaveContext();
		ctx.WriteValue("company_tax", m_CompanyTaxPercent);
		ctx.SaveToFile(TAX_PATH);
	}
	
	void LoadTaxRate()
	{
		SCR_JsonLoadContext ctx = new SCR_JsonLoadContext();
		if (ctx.LoadFromFile(TAX_PATH))
		{
			int loaded = -1;
			ctx.ReadValue("company_tax", loaded);
			if (loaded >= MIN_COMPANY_TAX_PERCENT && loaded <= MAX_COMPANY_TAX_PERCENT)
			{
				m_CompanyTaxPercent = loaded;
				Print(string.Format("[JobCompanyManager] Taux de taxe entreprise charge : %1%%",
					m_CompanyTaxPercent), LogLevel.NORMAL);
			}
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== HELPERS =====
	//------------------------------------------------------------------------------------------------
	
	// Trim simple (retire espaces debut/fin). Enforce n a pas string.Trim().
	static string TrimString(string s)
	{
		int len = s.Length();
		int start = 0;
		int end = len - 1;
		while (start < len && s.Get(start) == " ")
			start++;
		while (end >= start && s.Get(end) == " ")
			end--;
		if (end < start)
			return "";
		return s.Substring(start, end - start + 1);
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== PERSISTANCE JSON =====
	//------------------------------------------------------------------------------------------------
	void SaveToDisk()
	{
		SCR_JsonSaveContext ctx = new SCR_JsonSaveContext();
		
		ctx.WriteValue("company_count", m_Companies.Count());
		int cIdx = 0;
		foreach (string name, JobCompany c : m_Companies)
		{
			if (!c) continue;
			string cp = "company_" + cIdx.ToString() + "_";
			ctx.WriteValue(cp + "name", c.m_Name);
			ctx.WriteValue(cp + "jobType", c.m_JobType);
			ctx.WriteValue(cp + "owner", c.m_OwnerUID);
			ctx.WriteValue(cp + "ownerName", c.m_OwnerDisplayName);
			ctx.WriteValue(cp + "createdAt", c.m_CreatedAt);
			ctx.WriteValue(cp + "benefits", c.m_Benefits);
			ctx.WriteValue(cp + "totalSales", c.m_TotalSales);
			ctx.WriteValue(cp + "nextOrderId", c.m_NextOrderId);
			
			// Employes
			ctx.WriteValue(cp + "employeeCount", c.m_Employees.Count());
			for (int i = 0; i < c.m_Employees.Count(); i++)
			{
				JobCompanyEmployee e = c.m_Employees.Get(i);
				if (!e) continue;
				string ep = cp + "employee_" + i.ToString() + "_";
				ctx.WriteValue(ep + "uid", e.m_UID);
				ctx.WriteValue(ep + "name", e.m_DisplayName);
				ctx.WriteValue(ep + "hiredAt", e.m_HiredAt);
			}
			
			// Bons de commande
			ctx.WriteValue(cp + "orderCount", c.m_Orders.Count());
			for (int j = 0; j < c.m_Orders.Count(); j++)
			{
				JobCompanyOrder o = c.m_Orders.Get(j);
				if (!o) continue;
				string op = cp + "order_" + j.ToString() + "_";
				ctx.WriteValue(op + "id", o.m_OrderId);
				ctx.WriteValue(op + "authorUid", o.m_AuthorUID);
				ctx.WriteValue(op + "authorName", o.m_AuthorDisplayName);
				ctx.WriteValue(op + "status", o.m_Status);
				ctx.WriteValue(op + "proposedPrice", o.m_ProposedPrice);
				ctx.WriteValue(op + "finalPrice", o.m_FinalPrice);
				ctx.WriteValue(op + "createdAt", o.m_CreatedAt);
				ctx.WriteValue(op + "resolvedAt", o.m_ResolvedAt);
				ctx.WriteValue(op + "itemsRecovered", o.m_ItemsRecovered);
				ctx.WriteValue(op + "itemCount", o.m_Items.Count());
				for (int k = 0; k < o.m_Items.Count(); k++)
				{
					JobCompanyOrderItem it = o.m_Items.Get(k);
					if (!it) continue;
					string ip = op + "item_" + k.ToString() + "_";
					ctx.WriteValue(ip + "prefab", it.m_PrefabName);
					ctx.WriteValue(ip + "quantity", it.m_Quantity);
				}
			}
			
			// Chat
			ctx.WriteValue(cp + "chatCount", c.m_ChatMessages.Count());
			for (int m = 0; m < c.m_ChatMessages.Count(); m++)
			{
				JobCompanyChatMsg msg = c.m_ChatMessages.Get(m);
				if (!msg) continue;
				string mp = cp + "chat_" + m.ToString() + "_";
				ctx.WriteValue(mp + "ts", msg.m_Timestamp);
				ctx.WriteValue(mp + "uid", msg.m_AuthorUID);
				ctx.WriteValue(mp + "name", msg.m_AuthorDisplayName);
				ctx.WriteValue(mp + "text", msg.m_Text);
			}
			
			cIdx++;
		}
		
		ctx.SaveToFile(SAVE_PATH);
	}
	
	void LoadFromDisk()
	{
		SCR_JsonLoadContext ctx = new SCR_JsonLoadContext();
		if (!ctx.LoadFromFile(SAVE_PATH))
			return;
		
		int count = 0;
		ctx.ReadValue("company_count", count);
		for (int i = 0; i < count; i++)
		{
			string cp = "company_" + i.ToString() + "_";
			JobCompany c = new JobCompany();
			ctx.ReadValue(cp + "name", c.m_Name);
			int jobTypeInt = 0;
			ctx.ReadValue(cp + "jobType", jobTypeInt);
			c.m_JobType = jobTypeInt;
			ctx.ReadValue(cp + "owner", c.m_OwnerUID);
			ctx.ReadValue(cp + "ownerName", c.m_OwnerDisplayName);
			ctx.ReadValue(cp + "createdAt", c.m_CreatedAt);
			ctx.ReadValue(cp + "benefits", c.m_Benefits);
			ctx.ReadValue(cp + "totalSales", c.m_TotalSales);
			ctx.ReadValue(cp + "nextOrderId", c.m_NextOrderId);
			if (c.m_NextOrderId < 1) c.m_NextOrderId = 1;
			
			// Employes
			int employeeCount = 0;
			ctx.ReadValue(cp + "employeeCount", employeeCount);
			for (int e = 0; e < employeeCount; e++)
			{
				JobCompanyEmployee emp = new JobCompanyEmployee();
				string ep = cp + "employee_" + e.ToString() + "_";
				ctx.ReadValue(ep + "uid", emp.m_UID);
				ctx.ReadValue(ep + "name", emp.m_DisplayName);
				ctx.ReadValue(ep + "hiredAt", emp.m_HiredAt);
				if (emp.m_UID != "")
					c.m_Employees.Insert(emp);
			}
			
			// Bons de commande
			int orderCount = 0;
			ctx.ReadValue(cp + "orderCount", orderCount);
			for (int o = 0; o < orderCount; o++)
			{
				JobCompanyOrder ord = new JobCompanyOrder();
				string op = cp + "order_" + o.ToString() + "_";
				ctx.ReadValue(op + "id", ord.m_OrderId);
				ctx.ReadValue(op + "authorUid", ord.m_AuthorUID);
				ctx.ReadValue(op + "authorName", ord.m_AuthorDisplayName);
				ctx.ReadValue(op + "status", ord.m_Status);
				ctx.ReadValue(op + "proposedPrice", ord.m_ProposedPrice);
				ctx.ReadValue(op + "finalPrice", ord.m_FinalPrice);
				ctx.ReadValue(op + "createdAt", ord.m_CreatedAt);
				ctx.ReadValue(op + "resolvedAt", ord.m_ResolvedAt);
				// Backward compat : false par defaut si champ absent (ancien JSON)
				ord.m_ItemsRecovered = false;
				ctx.ReadValue(op + "itemsRecovered", ord.m_ItemsRecovered);
				int itemCount = 0;
				ctx.ReadValue(op + "itemCount", itemCount);
				for (int k = 0; k < itemCount; k++)
				{
					JobCompanyOrderItem it = new JobCompanyOrderItem();
					string ip = op + "item_" + k.ToString() + "_";
					ctx.ReadValue(ip + "prefab", it.m_PrefabName);
					ctx.ReadValue(ip + "quantity", it.m_Quantity);
					if (it.m_PrefabName != "")
						ord.m_Items.Insert(it);
				}
				c.m_Orders.Insert(ord);
			}
			
			// Chat
			int chatCount = 0;
			ctx.ReadValue(cp + "chatCount", chatCount);
			for (int m = 0; m < chatCount; m++)
			{
				JobCompanyChatMsg msg = new JobCompanyChatMsg();
				string mp = cp + "chat_" + m.ToString() + "_";
				ctx.ReadValue(mp + "ts", msg.m_Timestamp);
				ctx.ReadValue(mp + "uid", msg.m_AuthorUID);
				ctx.ReadValue(mp + "name", msg.m_AuthorDisplayName);
				ctx.ReadValue(mp + "text", msg.m_Text);
				c.m_ChatMessages.Insert(msg);
			}
			
			if (c.m_Name != "" && c.m_OwnerUID != "")
				m_Companies.Set(c.m_Name, c);
		}
		
		Print(string.Format("[JobCompanyManager] %1 entreprises chargees depuis disque",
			m_Companies.Count()), LogLevel.NORMAL);
	}
}
