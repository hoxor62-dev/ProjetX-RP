//------------------------------------------------------------------------------------------------
// JobData.c
// Definitions centralisees de tous les metiers du serveur Les Pacifistes
// Les GUIDs des vetements/armes/vehicules sont a remplir par le boss dans Workbench
//------------------------------------------------------------------------------------------------

// Types de metiers
enum EJobType
{
	NONE = 0,           // Aucun metier (etat par defaut a la premiere connexion)
	CHOMEUR = 1,        // Chomeur (metier "vide" selectionne, pas de salaire ni de PNJ)
	// --- Metiers Interim (accessibles a tous via JobInterim NPC) ---
	MINEUR = 10,
	UBER = 11,
	CUISINIER = 12,
	BUCHERON = 13,
	AGRICULTEUR = 14,
	// --- Metiers Avances (PNJ cache, salaire horaire) ---
	MEDECIN = 20,
	POLICIER = 21,
	CONCESSIONNAIRE = 22,
	MILITAIRE = 23,
	VOYOU = 24,
	VENDEUR_IMMOBILIER = 25,
	MECANICIEN = 26,
	JOURNALISTE = 27,
	PRESIDENT = 28,
	// --- Metiers Prives (Admin only, pas accessible via PNJ) ---
	AVOCAT = 50,
	FERMIER = 51,
	PROCUREUR = 52,
	EPICIER = 53,
	VENDEUR_VETEMENTS = 54,     // Metier prive, boutique de vetements KZS (jackets + pants)
	FONDEUR = 55,               // Metier prive, acces exclusif au four de fonte (chaines en or)
	FOURRIERE = 56,             // Metier prive, acces au garage virtuel partage de la fourriere
	POMPISTE = 57,              // Metier prive, remplit les stations essence contre 400c par refill
	// --- Shops generiques publics (ce ne sont pas des metiers selectionnables) ---
	// Utilises uniquement comme cles par JobShopCatalog pour ces PNJ publics
	SHOP_VETEMENTS = 30,
	SHOP_NOURRITURE = 31,
	SHOP_LOCATION = 32,
	SHOP_COIFFURE = 33,
	SHOP_DROGERIE = 34,
	SHOP_BIJOUTERIE = 35,            // Shop public : bijoux et chaines en or
	// --- Shops VOYOU specialises (acces metier VOYOU uniquement, paiement en lingots d or) ---
	SHOP_VOYOU_CAC = 40,             // Armes de corps a corps
	SHOP_VOYOU_POINT = 41,           // Armes de point (pistolets)
	SHOP_VOYOU_FUSIL = 42,           // Fusils
	SHOP_VOYOU_MITRAILLETTE = 43     // Mitraillettes
}

//------------------------------------------------------------------------------------------------
// Classe statique de reference pour tout ce qui concerne les metiers
//------------------------------------------------------------------------------------------------
class JobData
{
	// ==========================================================================
	// LABELS (affichage UI/HUD)
	// ==========================================================================
	static string GetJobLabel(EJobType job)
	{
		switch (job)
		{
			case EJobType.NONE:            return "Aucun Job";
			case EJobType.CHOMEUR:         return "Chomeur";
			case EJobType.MINEUR:          return "Mineur";
			case EJobType.UBER:            return "Conducteur Uber";
			case EJobType.CUISINIER:       return "Detective";
			case EJobType.BUCHERON:        return "Bucheron";
			case EJobType.AGRICULTEUR:     return "Agriculteur";
			case EJobType.MEDECIN:         return "Medecin";
			case EJobType.POLICIER:        return "Policier";
			case EJobType.CONCESSIONNAIRE: return "Concessionnaire";
			case EJobType.MILITAIRE:       return "Militaire";
			case EJobType.VOYOU:           return "Voyou";
			case EJobType.VENDEUR_IMMOBILIER: return "Vendeur Immobilier";
			case EJobType.MECANICIEN:      return "Mecanicien";
			case EJobType.JOURNALISTE:     return "Journaliste";
			case EJobType.PRESIDENT:       return "President";
			case EJobType.AVOCAT:          return "Avocat";
			case EJobType.FERMIER:         return "Fermier";
			case EJobType.PROCUREUR:       return "Procureur";
			case EJobType.EPICIER:         return "Epicier";
			case EJobType.VENDEUR_VETEMENTS: return "Vendeur Vetements RP";
			case EJobType.FONDEUR:         return "Fondeur";
			case EJobType.FOURRIERE:       return "Fourriere";
			case EJobType.POMPISTE:        return "Pompiste";
			case EJobType.SHOP_VETEMENTS:  return "Vendeur Vetements";
			case EJobType.SHOP_NOURRITURE: return "Vendeur Nourriture";
			case EJobType.SHOP_LOCATION:   return "Loueur Vehicules";
			case EJobType.SHOP_COIFFURE:   return "Coiffeur";
			case EJobType.SHOP_DROGERIE:   return "Drogerie";
			case EJobType.SHOP_BIJOUTERIE: return "Bijouterie";
			case EJobType.SHOP_VOYOU_CAC:           return "Marche noir - Corps a corps";
			case EJobType.SHOP_VOYOU_POINT:         return "Marche noir - Armes de point";
			case EJobType.SHOP_VOYOU_FUSIL:         return "Marche noir - Fusils";
			case EJobType.SHOP_VOYOU_MITRAILLETTE:  return "Marche noir - Mitraillettes";
		}
		return "Aucun Job";
	}

	// ==========================================================================
	// SALAIRE HORAIRE (metiers avances uniquement)
	// Retourne 0 pour les chomeurs uniquement.
	// Les metiers interim ont un salaire fixe de 65/h.
	// Les metiers avances ont un salaire eleve specifique.
	// ==========================================================================
	static int GetHourlySalary(EJobType job)
	{
		switch (job)
		{
			// Metiers Interim : 65 caps/h
			case EJobType.MINEUR:          return 600;
			case EJobType.UBER:            return 600;
			case EJobType.CUISINIER:       return 600;
			case EJobType.BUCHERON:        return 600;
			case EJobType.AGRICULTEUR:     return 600;
			// Metiers Avances : salaires specifiques
			case EJobType.MEDECIN:         return 1300;
			case EJobType.POLICIER:        return 1300;
			case EJobType.CONCESSIONNAIRE: return 275;
			case EJobType.MILITAIRE:       return 1300;
			case EJobType.VOYOU:           return 600;
			case EJobType.VENDEUR_IMMOBILIER: return 400;
			case EJobType.MECANICIEN:      return 600;
			case EJobType.JOURNALISTE:     return 600;
			case EJobType.PRESIDENT:       return 0;
			// Metiers Prives : 600 caps/h
			case EJobType.AVOCAT:          return 600;
			case EJobType.FERMIER:         return 600;
			case EJobType.PROCUREUR:       return 1100;
			case EJobType.EPICIER:         return 600;
			case EJobType.VENDEUR_VETEMENTS: return 600;
			case EJobType.FONDEUR:         return 600;
			case EJobType.FOURRIERE:       return 600;
			case EJobType.POMPISTE:        return 300;
		}
		return 0;
	}

	// ==========================================================================
	// TYPE DE METIER
	// ==========================================================================
	static bool IsInterimJob(EJobType job)
	{
		return (job == EJobType.MINEUR || job == EJobType.UBER || job == EJobType.CUISINIER
			|| job == EJobType.BUCHERON || job == EJobType.AGRICULTEUR);
	}

	static bool IsAdvancedJob(EJobType job)
	{
		return (job == EJobType.MEDECIN || job == EJobType.POLICIER
			|| job == EJobType.CONCESSIONNAIRE || job == EJobType.MILITAIRE
			|| job == EJobType.VOYOU || job == EJobType.VENDEUR_IMMOBILIER
			|| job == EJobType.MECANICIEN || job == EJobType.JOURNALISTE
			|| job == EJobType.PRESIDENT);
	}

	//------------------------------------------------------------------------------------------------
	// Metiers PRIVES : accessibles uniquement via l admin (pas via PNJ metiers avances).
	// Ces metiers ont un salaire horaire et fonctionnent comme des metiers avances pour le reste
	// (equipement, quetes, etc.), mais ne sont pas listes dans GetAdvancedMenuJobs.
	//------------------------------------------------------------------------------------------------
	static bool IsPrivateJob(EJobType job)
	{
		return (job == EJobType.AVOCAT || job == EJobType.FERMIER
			|| job == EJobType.PROCUREUR || job == EJobType.EPICIER
			|| job == EJobType.VENDEUR_VETEMENTS
			|| job == EJobType.FONDEUR
			|| job == EJobType.FOURRIERE
			|| job == EJobType.POMPISTE);
	}

	//------------------------------------------------------------------------------------------------
	// Retourne true si ce metier peut spawn un vehicule de service chez son PNJ
	//------------------------------------------------------------------------------------------------
	static bool HasServiceVehicle(EJobType job)
	{
		return (job == EJobType.POLICIER || job == EJobType.MILITAIRE || job == EJobType.MEDECIN);
	}

	//------------------------------------------------------------------------------------------------
	// GUID du prefab vehicule de service selon le metier
	//------------------------------------------------------------------------------------------------
	static ResourceName GetServiceVehiclePrefab(EJobType job)
	{
		switch (job)
		{
			case EJobType.POLICIER:
				return "{6A292C298585BBC9}Prefabs/Vehicles/Wheeled/5008/5008.et";
			case EJobType.MILITAIRE:
				return "{4BCA032A9D4D0E09}Prefabs/Vehicles/Wheeled/SampleCar_01/5008_GENDARMERIE.et";
			case EJobType.MEDECIN:
				return "{A18C3A6B44DE8A56}Prefabs/Vehicles/Wheeled/SampleCar_01/5008_SMUR.et";
		}
		return "";
	}

	//------------------------------------------------------------------------------------------------
	// Retourne true si ce metier peut recevoir des munitions supplementaires chez son PNJ
	//------------------------------------------------------------------------------------------------
	static bool HasAmmoResupply(EJobType job)
	{
		return (job == EJobType.POLICIER || job == EJobType.MILITAIRE);
	}

	//------------------------------------------------------------------------------------------------
	// Retourne la liste des prefabs de munitions a donner selon le metier.
	// Le tableau parallele GetAmmoResupplyQuantities donne la quantite de chaque item.
	//
	// POLICIER : 2 chargeurs pistolet M9 + 4 cartouches tazer + 2 zipcuffs
	// MILITAIRE : 2 chargeurs de chaque type de son arme (fusil) - GUIDs a remplir par le boss
	//------------------------------------------------------------------------------------------------
	static array<ResourceName> GetAmmoResupplyItems(EJobType job)
	{
		array<ResourceName> items = new array<ResourceName>();
		if (job == EJobType.POLICIER)
		{
			items.Insert("{C0E94CEC912C674B}Prefabs/Weapons/Magazines/MP5 Mag.et");
			items.Insert("{2476B3A801103E68}Prefabs/Weapons/Magazines/Magazine_Glock18C.et");
				items.Insert("{FFDAD1F2B025C17D}Prefabs/Weapons/Magazines/taser mag.et");
				items.Insert("{FFDAD1F2B025C17D}Prefabs/Weapons/Magazines/taser mag.et");
			    items.Insert("{FFDAD1F2B025C17D}Prefabs/Weapons/Magazines/taser mag.et");
				items.Insert("{FFDAD1F2B025C17D}Prefabs/Weapons/Magazines/taser mag.et");
							items.Insert("{200873F3186B0923}Prefabs/Items/ZipTieItem.et");
				items.Insert("{200873F3186B0923}Prefabs/Items/ZipTieItem.et");
				items.Insert("{200873F3186B0923}Prefabs/Items/ZipTieItem.et");
				items.Insert("{200873F3186B0923}Prefabs/Items/ZipTieItem.et");
			items.Insert("{CBF9B9942E07B6B8}Prefabs/Items/Equipment/Accessories/ZipCuffs/ACE_Captives_ZipCuffs.et"); // zipcuff
		}
		else if (job == EJobType.MILITAIRE)
		{
			// GUIDs des chargeurs du fusil militaire - A REMPLIR PAR LE BOSS
			items.Insert("{C0E94CEC912C674B}Prefabs/Weapons/Magazines/MP5 Mag.et");
							items.Insert("{FFDAD1F2B025C17D}Prefabs/Weapons/Magazines/taser mag.et");
				items.Insert("{FFDAD1F2B025C17D}Prefabs/Weapons/Magazines/taser mag.et");
			    items.Insert("{FFDAD1F2B025C17D}Prefabs/Weapons/Magazines/taser mag.et");
				items.Insert("{FFDAD1F2B025C17D}Prefabs/Weapons/Magazines/taser mag.et");
							items.Insert("{200873F3186B0923}Prefabs/Items/ZipTieItem.et");
				items.Insert("{200873F3186B0923}Prefabs/Items/ZipTieItem.et");
				items.Insert("{200873F3186B0923}Prefabs/Items/ZipTieItem.et");
				items.Insert("{200873F3186B0923}Prefabs/Items/ZipTieItem.et");
			items.Insert("{2476B3A801103E68}Prefabs/Weapons/Magazines/Magazine_Glock18C.et");
			items.Insert("{CBF9B9942E07B6B8}Prefabs/Items/Equipment/Accessories/ZipCuffs/ACE_Captives_ZipCuffs.et");  // chargeur fusil type 2 (si differente munition)
		}
		return items;
	}

	//------------------------------------------------------------------------------------------------
	// Quantites paralleles a GetAmmoResupplyItems (meme ordre)
	//------------------------------------------------------------------------------------------------
	static array<int> GetAmmoResupplyQuantities(EJobType job)
	{
		array<int> qty = new array<int>();
		if (job == EJobType.POLICIER)
		{
			qty.Insert(2);  // 2 chargeurs pistolet
			qty.Insert(2);  // 4 cartouches tazer
			qty.Insert(4);  // 2 zipcuffs
			qty.Insert(2);  // 2 zipcuffs
		}
		else if (job == EJobType.MILITAIRE)
		{
			qty.Insert(2);  // 2 chargeurs type 1
			qty.Insert(2);  // 2 chargeurs type 2
			qty.Insert(4);
			qty.Insert(2);
		}
		return qty;
	}

	static bool HasQuests(EJobType job)
	{
		// Seuls les metiers interim ont des quetes (reponse boss: B pour les avances)
		return IsInterimJob(job);
	}

	static bool HasHourlySalary(EJobType job)
	{
		// Tout metier ayant un salaire horaire > 0 (interim ET avances).
		// AVANT : retournait IsAdvancedJob(job) -> les metiers interim n etaient JAMAIS payes
		// alors que GetHourlySalary leur attribue 175 caps/h. C etait le bug.
		return (GetHourlySalary(job) > 0);
	}

	static bool HasEquipment(EJobType job)
	{
		// Tous les metiers (sauf chomeur et none) ont de l'equipement
		return (job != EJobType.NONE && job != EJobType.CHOMEUR);
	}

	// ==========================================================================
	// CONVERSION STRING <-> EJobType (pour JSON persistence)
	// ==========================================================================
	static string JobToString(EJobType job)
	{
		switch (job)
		{
			case EJobType.NONE:            return "NONE";
			case EJobType.CHOMEUR:         return "CHOMEUR";
			case EJobType.MINEUR:          return "MINEUR";
			case EJobType.UBER:            return "UBER";
			case EJobType.CUISINIER:       return "CUISINIER";
			case EJobType.BUCHERON:        return "BUCHERON";
			case EJobType.AGRICULTEUR:     return "AGRICULTEUR";
			case EJobType.MEDECIN:         return "MEDECIN";
			case EJobType.POLICIER:        return "POLICIER";
			case EJobType.CONCESSIONNAIRE: return "CONCESSIONNAIRE";
			case EJobType.MILITAIRE:       return "MILITAIRE";
			case EJobType.VOYOU:           return "VOYOU";
			case EJobType.VENDEUR_IMMOBILIER: return "VENDEUR_IMMOBILIER";
			case EJobType.MECANICIEN:      return "MECANICIEN";
			case EJobType.JOURNALISTE:     return "JOURNALISTE";
			case EJobType.PRESIDENT:       return "PRESIDENT";
			case EJobType.AVOCAT:          return "AVOCAT";
			case EJobType.FERMIER:         return "FERMIER";
			case EJobType.PROCUREUR:       return "PROCUREUR";
			case EJobType.EPICIER:         return "EPICIER";
			case EJobType.VENDEUR_VETEMENTS: return "VENDEUR_VETEMENTS";
			case EJobType.FONDEUR:         return "FONDEUR";
			case EJobType.FOURRIERE:       return "FOURRIERE";
			case EJobType.POMPISTE:        return "POMPISTE";
		}
		return "NONE";
	}

	static EJobType StringToJob(string str)
	{
		if (str == "CHOMEUR")         return EJobType.CHOMEUR;
		if (str == "MINEUR")          return EJobType.MINEUR;
		if (str == "UBER")            return EJobType.UBER;
		if (str == "CUISINIER")       return EJobType.CUISINIER;
		if (str == "BUCHERON")        return EJobType.BUCHERON;
		if (str == "AGRICULTEUR")     return EJobType.AGRICULTEUR;
		if (str == "MEDECIN")         return EJobType.MEDECIN;
		if (str == "POLICIER")        return EJobType.POLICIER;
		if (str == "CONCESSIONNAIRE") return EJobType.CONCESSIONNAIRE;
		if (str == "MILITAIRE")       return EJobType.MILITAIRE;
		if (str == "VOYOU")           return EJobType.VOYOU;
		if (str == "VENDEUR_IMMOBILIER") return EJobType.VENDEUR_IMMOBILIER;
		if (str == "MECANICIEN")      return EJobType.MECANICIEN;
		if (str == "JOURNALISTE")     return EJobType.JOURNALISTE;
		if (str == "PRESIDENT")       return EJobType.PRESIDENT;
		if (str == "AVOCAT")          return EJobType.AVOCAT;
		if (str == "FERMIER")         return EJobType.FERMIER;
		if (str == "PROCUREUR")       return EJobType.PROCUREUR;
		if (str == "EPICIER")         return EJobType.EPICIER;
		if (str == "VENDEUR_VETEMENTS") return EJobType.VENDEUR_VETEMENTS;
		if (str == "FONDEUR")         return EJobType.FONDEUR;
		if (str == "FOURRIERE")       return EJobType.FOURRIERE;
		if (str == "POMPISTE")        return EJobType.POMPISTE;
		return EJobType.NONE;
	}

	// ==========================================================================
	// LISTE DES METIERS PROPOSES PAR LE PNJ JOB INTERIM
	// ==========================================================================
	static array<EJobType> GetInterimMenuJobs()
	{
		array<EJobType> jobs = new array<EJobType>();
		jobs.Insert(EJobType.MINEUR);
		jobs.Insert(EJobType.UBER);
		jobs.Insert(EJobType.CUISINIER);
		jobs.Insert(EJobType.BUCHERON);
		jobs.Insert(EJobType.AGRICULTEUR);
		jobs.Insert(EJobType.CHOMEUR);
		return jobs;
	}

	// ==========================================================================
	// LISTE DES METIERS PROPOSES PAR LE PNJ AVANCE (CACHE)
	// ==========================================================================
	static array<EJobType> GetAdvancedMenuJobs()
	{
		array<EJobType> jobs = new array<EJobType>();
		jobs.Insert(EJobType.MEDECIN);
		jobs.Insert(EJobType.POLICIER);
		jobs.Insert(EJobType.CONCESSIONNAIRE);
		jobs.Insert(EJobType.MILITAIRE);
		jobs.Insert(EJobType.VOYOU);
		jobs.Insert(EJobType.VENDEUR_IMMOBILIER);
		return jobs;
	}

	// ==========================================================================
	// DESCRIPTIONS (pour le menu de selection)
	// ==========================================================================
	static string GetJobDescription(EJobType job)
	{
		switch (job)
		{
			case EJobType.MINEUR:
				return "Salaire: 400 caps/h. Extraction de minerais a la pioche, transformation et revente.";
			case EJobType.UBER:
				return "Salaire: 400 caps/h. Transport de passagers et missions de visite.";
			case EJobType.CUISINIER:
				return "Salaire: 175 caps/h. Detective: enquetes urbaines et investigations.";
			case EJobType.BUCHERON:
				return "Salaire: 400 caps/h. Coupez du bois en foret avec votre hache, transformez les rondins en planches a la scierie, puis vendez les planches au PNJ Bucheron.";
			case EJobType.AGRICULTEUR:
				return "Salaire: 400 caps/h. Cueillez des pommes dans les vergers (aucun outil necessaire), pressez-les en jus a la presse, puis vendez les bouteilles au PNJ Agriculteur.";
			case EJobType.CHOMEUR:
				return "Aucun salaire. Aucun equipement. Aucune quete.";
			case EJobType.MEDECIN:
				return "Salaire: 1300 caps/h. Trousse medicale fournie.";
			case EJobType.POLICIER:
				return "Salaire: 1300 caps/h. Uniforme + arme de service.";
			case EJobType.CONCESSIONNAIRE:
				return "Salaire: 175 caps/h. Achat et revente de vehicules.";
			case EJobType.MILITAIRE:
				return "Salaire: 400 caps/h. Uniforme + armement militaire.";
			case EJobType.VOYOU:
				return "Salaire: 150 caps/h. Acces au marche noir (armes illegales).";
			case EJobType.VENDEUR_IMMOBILIER:
				return "Salaire: 200 caps/h. Acces aux materiaux de construction.";
			case EJobType.MECANICIEN:
				return "Salaire: 275 caps/h. Specialiste de la mecanique et de la reparation de vehicules.";
			case EJobType.JOURNALISTE:
				return "Salaire: 600 caps/h. Couverture des evenements RP, reportages et photos.";
			case EJobType.PRESIDENT:
				return "Aucun salaire fixe. Controle des taxes (LeBonPoint + entreprises) et acces a la cagnotte municipale.";
			case EJobType.AVOCAT:
				return "Salaire: 600 caps/h. Defense juridique des joueurs devant le tribunal RP.";
			case EJobType.FERMIER:
				return "Salaire: 600 caps/h. Culture et elevage a grande echelle, gestion de la ferme.";
			case EJobType.PROCUREUR:
				return "Salaire: 1200 caps/h. Represente le Ministere Public devant le tribunal RP.";
			case EJobType.EPICIER:
				return "Salaire: 600 caps/h. Gestion d une epicerie de quartier, vente au detail.";
			case EJobType.VENDEUR_VETEMENTS:
				return "Salaire: 600 caps/h. Boutique de vetements RP (vestes et pantalons customises). Acces au shop reserve au porteur du metier.";
			case EJobType.FONDEUR:
				return "Salaire: 600 caps/h. Specialiste de la fonte : seul metier autorise a utiliser le four de fonte pour transformer les chaines en lingots d or.";
			case EJobType.FOURRIERE:
				return "Salaire: 600 caps/h. Gestion de la fourriere : acces au garage virtuel partage avec tous les autres employes de la fourriere.";
			case EJobType.POMPISTE:
				return "Salaire: 300 caps/h + 400 caps par station essence remplie. Gere l approvisionnement en carburant des stations service.";
		}
		return "";
	}
}
