//------------------------------------------------------------------------------------------------
// JobDrugDealerComponent.c
// Composant a ajouter sur le PNJ public qui rachete la drogue des joueurs.
//
// Workbench setup:
// - Placer ce composant sur un PNJ
// - Ajouter ActionsManagerComponent
// - Ajouter l'action JobDrugDealerAction (UserActions)
// - RplComponent obligatoire
//------------------------------------------------------------------------------------------------

[ComponentEditorProps(category: "LesPacifistesJobs", description: "PNJ acheteur de drogue (public)")]
class JobDrugDealerComponentClass : ScriptComponentClass
{
}

//------------------------------------------------------------------------------------------------
class JobDrugDealerComponent : ScriptComponent
{
	// Composant marqueur. Toute la logique est dans l'action + JobDrugDealerMenu + JobPlayerComponent
}
