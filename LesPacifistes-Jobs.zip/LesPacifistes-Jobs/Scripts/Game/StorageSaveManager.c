//------------------------------------------------------------------------------------------------
// StorageSaveManager.c
// Singleton SERVEUR qui sauvegarde periodiquement l inventaire des coffres StorageBox et
// Base_Safe, et restaure au boot serveur les items disparus (comparaison intelligente).
//
// CLE STABLE : prefab + XZ arrondi, AVEC lookup tolerant par proximite en secours
// STOCKAGE : $profile:LesPacifistesJobs/storages.json
// COMPARAISON : match par prefab + count runtime, spawn les manquants uniquement
//
//==================================================================================================
// CORRECTIFS DU 10 NOV 2026 - PERTES D ITEMS APRES REBOOT
//==================================================================================================
//
// BUG 1 (CRITIQUE) : le restore au boot ne spawnait RIEN.
//   RestoreAll() est appele 7s apres le boot (LP_DoorSyncHandler), moment ou AUCUN joueur
//   n est connecte. SpawnItemInStorage passait par FindAnyPlayerInventoryManager() qui itere
//   les joueurs connectes : retour null, log "MGR FAIL", zero item restaure.
//   Le systeme de rattrapage n a donc jamais fonctionne depuis sa mise en place.
//   FIX : spawn direct de l entite dans le monde + insertion via le wrapper
//   LP_StorageInsertItemForRestore (LP_UniversalStorageModded.c), qui ne depend d aucun
//   joueur. L ancienne route par manager joueur reste en fallback.
//
// BUG 2 (CRITIQUE) : cle de coffre instable -> snapshot orphelin -> perte totale.
//   BuildKey fait "int x = pos[0]" qui TRONQUE. Un coffre a X=4102.98 qui derive a 4103.02
//   apres un reboot (physics settle, floor snap sur les Base_Safe poses par joueurs) change
//   de cle. Le snapshot devient orphelin, le coffre est vu comme neuf, aucun restore, et le
//   contenu sauvegarde est perdu definitivement.
//   FIX : lookup en deux temps. Cle exacte d abord, puis recherche tolerante par prefab +
//   distance XZ (KEY_TOLERANCE_M). Si trouve par tolerance, le snapshot est re-cle sur la
//   nouvelle position pour que les lookups suivants soient directs.
//
// BUG 3 (CRITIQUE) : un restore rate detruisait le snapshot.
//   Si le restore echoue (bug 1) ou si le coffre n est pas encore charge au moment du scan,
//   le tick suivant le voit vide, incremente le compteur, et apres EMPTY_SCANS_BEFORE_ACCEPT
//   ecrase le snapshot avec du vide. Contenu perdu de maniere permanente.
//   FIX : etat "pending restore". Tout coffre dont le restore n a pas abouti est marque et
//   EXCLU du snapshot tant qu il n est pas restaure. Des retries sont programmes.
//
// BUG 4 (MAJEUR) : contenu des conteneurs imbriques jamais sauvegarde.
//   Un sac a dos dans un coffre etait snapshot comme un simple item. Au restore, le sac
//   revenait VIDE : tout ce qu il contenait etait perdu.
//   FIX : snapshot recursif a profondeur 1 (conteneurs poses directement dans le coffre),
//   avec restauration en deux phases (top-level, puis remplissage des conteneurs).
//
// BUG 5 (MODERE) : intervalle de 5 min trop long.
//   Tout depot fait dans les 5 minutes precedant un reboot n etait jamais snapshot.
//   Le commentaire de LP_DoorSyncHandler annoncait deja "auto-save 60s" alors que la
//   constante etait a 300000.
//   FIX : SAVE_INTERVAL_MS passe a 60s. Fenetre de perte divisee par 5.
//
// BUG 6 (MODERE) : un seul scan vide transitoire bloquait le restore.
//   La garde anti-duplication refusait le restore des que m_ConsecutiveEmptyScans > 0.
//   Un seul scan vide parasite (replication tardive, coffre pas encore initialise) juste
//   avant un reboot suffisait donc a condamner tout le contenu du coffre.
//   FIX : double lecture. Un scan vide n est comptabilise qu apres confirmation par une
//   seconde lecture EMPTY_CONFIRM_DELAY_MS plus tard. La garde anti-duplication se base
//   desormais sur m_EmptyConfirmed, qui ne passe a true que sur un vide confirme.
//
//==================================================================================================
//
// PREFABS TRACKES :
//   - {B1429602172906BC}Prefabs/Props/Civilian/StorageBox.et
//   - {2BF070D6B6BD7558}Prefabs/BaseBuilding/Storage/Safe/Base_Safe.et
//------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------------------
// Contenu d un conteneur pose DANS un coffre (sac a dos, caisse, vest...).
// Permet de ne pas perdre les items imbriques au restore.
//------------------------------------------------------------------------------------------------
class LP_NestedContainer
{
	string m_ContainerPrefab;
	ref map<string, int> m_ItemCounts = new map<string, int>();

	int TotalItems()
	{
		int total = 0;
		foreach (string p, int c : m_ItemCounts)
			total = total + c;
		return total;
	}
}

//------------------------------------------------------------------------------------------------
class LP_StorageSnapshot
{
	string m_StorageKey;          // cle stable (prefab + xz)
	string m_PrefabName;          // prefab du coffre
	vector m_Position;
	ref map<string, int> m_ItemCounts = new map<string, int>(); // top-level : prefab -> count

	// Contenu des conteneurs poses dans le coffre (profondeur 1).
	// Plusieurs conteneurs du meme prefab sont stockes dans l ordre de leurs slots.
	ref array<ref LP_NestedContainer> m_Nested = new array<ref LP_NestedContainer>();

	int m_ConsecutiveEmptyScans = 0; // nb de scans vides CONFIRMES consecutifs

	// Vrai uniquement si un scan vide a ete CONFIRME par une seconde lecture.
	// C est ce flag, et non le compteur, qui autorise la garde anti-duplication au restore.
	// Remis a false des qu un item est detecte.
	bool m_EmptyConfirmed = false;

	int TotalItems()
	{
		int total = 0;
		foreach (string p, int c : m_ItemCounts)
			total = total + c;
		return total;
	}

	//------------------------------------------------------------------------------------------------
	// Construit la cle stable prefab + XZ tronque (au metre pres).
	// On IGNORE l axe Y volontairement : les coffres (surtout Base_Safe poses par joueurs)
	// se stabilisent physiquement entre reboots.
	//
	// ATTENTION : cette cle reste fragile sur les frontieres entieres (4102.98 -> 4103.02).
	// Elle est conservee pour la compatibilite des saves existantes, mais le lookup passe
	// desormais par FindSnapshotForStorage qui retombe sur une recherche par proximite.
	//------------------------------------------------------------------------------------------------
	static string BuildKey(string prefabName, vector pos)
	{
		int x = pos[0];
		int z = pos[2];
		return prefabName + "@" + x.ToString() + "_" + z.ToString();
	}

	//------------------------------------------------------------------------------------------------
	// Distance horizontale (XZ) entre deux positions, Y ignore.
	//------------------------------------------------------------------------------------------------
	static float DistXZ(vector a, vector b)
	{
		float dx = a[0] - b[0];
		float dz = a[2] - b[2];
		return Math.Sqrt(dx * dx + dz * dz);
	}
}

//------------------------------------------------------------------------------------------------
class StorageSaveManager
{
	static ref StorageSaveManager s_Instance;

	// BUG 5 : 60s au lieu de 300s. Reduit la fenetre de depots non sauvegardes.
	const int SAVE_INTERVAL_MS = 60000;
	const string SAVE_FILE = "$profile:LesPacifistesJobs/storages.json";

	// Seuil : apres combien de scans vides CONFIRMES consecutifs on accepte que le coffre est
	// vraiment vide et on ecrase le snapshot. Avec SAVE_INTERVAL_MS=60s et seuil=2, il faut
	// environ 2 minutes de vide continu confirme pour que le snapshot bascule a vide.
	const int EMPTY_SCANS_BEFORE_ACCEPT = 2;

	// BUG 6 : delai avant la seconde lecture qui confirme (ou infirme) un scan vide.
	const int EMPTY_CONFIRM_DELAY_MS = 5000;

	// BUG 2 : rayon de tolerance pour retrouver un snapshot dont le coffre a derive.
	// Volontairement petit : deux coffres distincts sont presque toujours a plus d un metre.
	const float KEY_TOLERANCE_M = 1.5;

	// BUG 3 : retries du restore pour les coffres pas encore charges ou dont le spawn a echoue.
	const int RESTORE_RETRY_DELAY_MS = 15000;
	const int RESTORE_MAX_RETRIES = 6;   // 6 x 15s = 90s de rattrapage apres le boot

	// BUG 4 : delai avant le remplissage des conteneurs imbriques (l insertion est async,
	// il faut laisser les conteneurs top-level s attacher au coffre avant de les remplir).
	const int NESTED_FILL_DELAY_MS = 4000;

	// Prefabs de coffres a tracker
	static string PREFAB_STORAGEBOX = "{B1429602172906BC}Prefabs/Props/Civilian/StorageBox.et";
	static string PREFAB_SAFE = "{2BF070D6B6BD7558}Prefabs/BaseBuilding/Storage/Safe/Base_Safe.et";

	// Snapshots persistants : cle stable -> snapshot
	ref map<string, ref LP_StorageSnapshot> m_Snapshots = new map<string, ref LP_StorageSnapshot>();
	bool m_Loaded = false;
	bool m_TickerStarted = false;
	bool m_Dirty = false;

	// Collecteur pour QueryEntitiesByAABB
	ref array<IEntity> m_TmpFoundStorages = new array<IEntity>();

	// Cache runtime cle -> entite, reconstruit a chaque tick.
	// Sert aux confirmations de scan vide et au remplissage differe des conteneurs,
	// sans avoir a re-scanner le monde entier.
	ref map<string, IEntity> m_RuntimeEntities = new map<string, IEntity>();

	// BUG 3 : coffres dont le restore n a pas abouti. Tant qu une cle est la-dedans,
	// le tick NE SNAPSHOT PAS ce coffre (sinon on ecraserait le snapshot avec du vide).
	ref map<string, bool> m_PendingRestore = new map<string, bool>();
	int m_RestoreRetryCount = 0;

	//------------------------------------------------------------------------------------------------
	static StorageSaveManager GetInstance()
	{
		if (!s_Instance)
		{
			s_Instance = new StorageSaveManager();
			s_Instance.LoadFromDisk();
		}
		return s_Instance;
	}

	//------------------------------------------------------------------------------------------------
	// Demarre le ticker (a appeler une fois cote serveur au boot)
	void StartAutoSave()
	{
		if (m_TickerStarted) return;
		m_TickerStarted = true;
		GetGame().GetCallqueue().CallLater(TickSaveAll, SAVE_INTERVAL_MS, true);
		Print("[StorageSaveManager] Auto-save demarree (" + (SAVE_INTERVAL_MS / 1000).ToString() + "s).", LogLevel.NORMAL);
	}

	//------------------------------------------------------------------------------------------------
	// ===== SNAPSHOT =====
	//------------------------------------------------------------------------------------------------

	//------------------------------------------------------------------------------------------------
	// Tick : parcourt tous les coffres du monde et snapshot leur inventaire.
	//------------------------------------------------------------------------------------------------
	void TickSaveAll()
	{
		if (!Replication.IsServer()) return;

		array<IEntity> storages = new array<IEntity>();
		CollectAllStorages(storages);

		// Reconstruit le cache runtime cle -> entite
		m_RuntimeEntities.Clear();

		int savedCount = 0;
		int skippedPending = 0;
		foreach (IEntity storageEntity : storages)
		{
			if (!storageEntity) continue;

			EntityPrefabData pd = storageEntity.GetPrefabData();
			if (!pd) continue;
			string prefabName = pd.GetPrefabName();
			if (prefabName != PREFAB_STORAGEBOX && prefabName != PREFAB_SAFE) continue;

			vector pos = storageEntity.GetOrigin();

			// Resout le snapshot (cle exacte puis proximite) pour obtenir la cle REELLE
			LP_StorageSnapshot existing = FindSnapshotForStorage(prefabName, pos);
			string key;
			if (existing)
				key = existing.m_StorageKey;
			else
				key = LP_StorageSnapshot.BuildKey(prefabName, pos);

			m_RuntimeEntities.Set(key, storageEntity);

			// BUG 3 : un coffre en attente de restore ne doit JAMAIS etre snapshot,
			// sinon on ecrase son snapshot avec l etat vide d avant restauration.
			if (m_PendingRestore.Contains(key))
			{
				skippedPending = skippedPending + 1;
				continue;
			}

			if (SnapshotStorage(storageEntity, key, existing))
				savedCount = savedCount + 1;
		}

		if (skippedPending > 0)
		{
			Print(string.Format("[StorageSaveManager] Tick : %1 coffre(s) ignore(s) car restore en attente.",
				skippedPending.ToString()), LogLevel.NORMAL);
		}

		// On sauvegarde si quelque chose a bouge (contenu ou compteurs).
		if (m_Dirty)
		{
			SaveToDisk();
			m_Dirty = false;
		}
	}

	//------------------------------------------------------------------------------------------------
	// Snapshot d un coffre. Retourne true si le snapshot a ete cree ou remplace.
	//
	// LOGIQUE ANTI-DUPLICATION (BUG 6) :
	//   Un scan vide alors que l ancien snapshot avait des items n est PAS comptabilise
	//   immediatement. On programme une seconde lecture EMPTY_CONFIRM_DELAY_MS plus tard.
	//   Seule cette seconde lecture, si elle trouve toujours le coffre vide, incremente le
	//   compteur et pose m_EmptyConfirmed. Les scans vides parasites sont donc filtres.
	//------------------------------------------------------------------------------------------------
	protected bool SnapshotStorage(IEntity storageEntity, string key, LP_StorageSnapshot existing)
	{
		if (!storageEntity) return false;

		EntityPrefabData pd = storageEntity.GetPrefabData();
		if (!pd) return false;
		string prefabName = pd.GetPrefabName();

		vector pos = storageEntity.GetOrigin();

		BaseInventoryStorageComponent storage = BaseInventoryStorageComponent.Cast(
			storageEntity.FindComponent(SCR_UniversalInventoryStorageComponent));
		if (!storage)
			storage = BaseInventoryStorageComponent.Cast(
				storageEntity.FindComponent(BaseInventoryStorageComponent));
		if (!storage) return false;

		LP_StorageSnapshot snap = new LP_StorageSnapshot();
		snap.m_StorageKey = key;
		snap.m_PrefabName = prefabName;
		snap.m_Position = pos;

		int totalItemsFound = ReadStorageContents(storage, snap.m_ItemCounts, snap.m_Nested);

		// CAS 1 : scan non vide. On ecrit directement et on reset l etat "vide".
		if (totalItemsFound > 0)
		{
			snap.m_ConsecutiveEmptyScans = 0;
			snap.m_EmptyConfirmed = false;
			m_Snapshots.Set(key, snap);
			m_Dirty = true;
			return true;
		}

		// CAS 2 : scan vide et aucun snapshot existant. Entree vide propre.
		if (!existing)
		{
			snap.m_ConsecutiveEmptyScans = 0;
			snap.m_EmptyConfirmed = false;
			m_Snapshots.Set(key, snap);
			m_Dirty = true;
			return true;
		}

		// CAS 3 : scan vide et existant deja vide. Rien a sauvegarder de nouveau.
		if (existing.TotalItems() == 0)
			return false;

		// CAS 4 : scan vide mais l existant avait des items.
		// BUG 6 : on ne tranche PAS tout de suite, on programme une confirmation.
		Print(string.Format("[StorageSaveManager] Coffre %1 vu vide (ancien avait %2 items) - verification dans %3s",
			key, existing.TotalItems().ToString(), (EMPTY_CONFIRM_DELAY_MS / 1000).ToString()), LogLevel.NORMAL);

		GetGame().GetCallqueue().CallLater(ConfirmEmptyScan, EMPTY_CONFIRM_DELAY_MS, false, key);
		return false;
	}

	//------------------------------------------------------------------------------------------------
	// BUG 6 : seconde lecture d un coffre vu vide. C est ici, et seulement ici, que l on
	// comptabilise un scan vide et que l on pose m_EmptyConfirmed.
	// Si la seconde lecture trouve des items, le premier scan etait parasite : on ne touche a rien.
	//------------------------------------------------------------------------------------------------
	void ConfirmEmptyScan(string key)
	{
		LP_StorageSnapshot existing = m_Snapshots.Get(key);
		if (!existing) return;

		IEntity storageEntity = m_RuntimeEntities.Get(key);
		if (!storageEntity)
		{
			// Coffre disparu du cache (detruit, ou deplace). On ne touche pas au snapshot :
			// mieux vaut garder un contenu potentiellement obsolete que risquer une perte.
			Print(string.Format("[StorageSaveManager] Confirmation vide %1 : entite introuvable, snapshot conserve.",
				key), LogLevel.WARNING);
			return;
		}

		BaseInventoryStorageComponent storage = BaseInventoryStorageComponent.Cast(
			storageEntity.FindComponent(SCR_UniversalInventoryStorageComponent));
		if (!storage)
			storage = BaseInventoryStorageComponent.Cast(
				storageEntity.FindComponent(BaseInventoryStorageComponent));
		if (!storage) return;

		ref map<string, int> recheckCounts = new map<string, int>();
		ref array<ref LP_NestedContainer> recheckNested = new array<ref LP_NestedContainer>();
		int found = ReadStorageContents(storage, recheckCounts, recheckNested);

		if (found > 0)
		{
			// Faux positif : le premier scan etait parasite. On remet le snapshot a jour
			// avec ce qu on vient de lire, et on annule l etat "vide".
			LP_StorageSnapshot snap = new LP_StorageSnapshot();
			snap.m_StorageKey = key;
			snap.m_PrefabName = existing.m_PrefabName;
			snap.m_Position = storageEntity.GetOrigin();
			snap.m_ItemCounts = recheckCounts;
			snap.m_Nested = recheckNested;
			snap.m_ConsecutiveEmptyScans = 0;
			snap.m_EmptyConfirmed = false;
			m_Snapshots.Set(key, snap);
			m_Dirty = true;

			Print(string.Format("[StorageSaveManager] Confirmation vide %1 : FAUX POSITIF, %2 items retrouves. Snapshot mis a jour.",
				key, found.ToString()), LogLevel.NORMAL);
			return;
		}

		// Vide confirme par deux lectures. Maintenant seulement on comptabilise.
		existing.m_ConsecutiveEmptyScans = existing.m_ConsecutiveEmptyScans + 1;
		existing.m_EmptyConfirmed = true;
		m_Dirty = true;

		if (existing.m_ConsecutiveEmptyScans < EMPTY_SCANS_BEFORE_ACCEPT)
		{
			Print(string.Format("[StorageSaveManager] Vide confirme %1/%2 pour %3 (ancien avait %4 items), contenu conserve",
				existing.m_ConsecutiveEmptyScans.ToString(),
				EMPTY_SCANS_BEFORE_ACCEPT.ToString(),
				key, existing.TotalItems().ToString()), LogLevel.NORMAL);
			return;
		}

		// Seuil atteint : le joueur a bien vide le coffre, on accepte le vide reel.
		Print(string.Format("[StorageSaveManager] Coffre %1 vide confirme apres %2 verifications, snapshot vide (ancien avait %3 items)",
			key, EMPTY_SCANS_BEFORE_ACCEPT.ToString(), existing.TotalItems().ToString()), LogLevel.NORMAL);

		existing.m_ItemCounts.Clear();
		existing.m_Nested.Clear();
		existing.m_ConsecutiveEmptyScans = 0;
		existing.m_EmptyConfirmed = true;  // reste true : le coffre est vide intentionnellement
		m_Dirty = true;
	}

	//------------------------------------------------------------------------------------------------
	// Lit le contenu d un storage : items top-level + contenu des conteneurs imbriques.
	// Retourne le nombre total d items top-level trouves.
	// BUG 4 : c est ici qu on descend d un niveau dans les sacs a dos / caisses.
	//------------------------------------------------------------------------------------------------
	protected int ReadStorageContents(BaseInventoryStorageComponent storage, map<string, int> outCounts, array<ref LP_NestedContainer> outNested)
	{
		// NOTE : pas de modificateur "out" volontairement. Les maps et arrays Enforce sont
		// passes par reference, et on MUTE les instances fournies (Clear puis Set/Insert)
		// sans jamais les reassigner. Utiliser "out" ici poserait probleme quand l appelant
		// passe directement un champ "ref" d un snapshot.
		outCounts.Clear();
		outNested.Clear();
		if (!storage) return 0;

		int slotCount = storage.GetSlotsCount();
		int totalItemsFound = 0;

		for (int i = 0; i < slotCount; i++)
		{
			InventoryStorageSlot slot = storage.GetSlot(i);
			if (!slot) continue;
			IEntity itemEnt = slot.GetAttachedEntity();
			if (!itemEnt) continue;
			EntityPrefabData itemPd = itemEnt.GetPrefabData();
			if (!itemPd) continue;
			string itemPrefab = itemPd.GetPrefabName();
			if (itemPrefab == "" || itemPrefab == ResourceName.Empty) continue;

			int prevCount = outCounts.Get(itemPrefab);
			outCounts.Set(itemPrefab, prevCount + 1);
			totalItemsFound = totalItemsFound + 1;

			// BUG 4 : si cet item est lui-meme un conteneur, on enregistre son contenu.
			BaseInventoryStorageComponent childStorage = BaseInventoryStorageComponent.Cast(
				itemEnt.FindComponent(SCR_UniversalInventoryStorageComponent));
			if (!childStorage)
				childStorage = BaseInventoryStorageComponent.Cast(
					itemEnt.FindComponent(BaseInventoryStorageComponent));
			if (!childStorage) continue;

			LP_NestedContainer nested = new LP_NestedContainer();
			nested.m_ContainerPrefab = itemPrefab;

			int childSlots = childStorage.GetSlotsCount();
			for (int j = 0; j < childSlots; j++)
			{
				InventoryStorageSlot childSlot = childStorage.GetSlot(j);
				if (!childSlot) continue;
				IEntity childEnt = childSlot.GetAttachedEntity();
				if (!childEnt) continue;
				EntityPrefabData childPd = childEnt.GetPrefabData();
				if (!childPd) continue;
				string childPrefab = childPd.GetPrefabName();
				if (childPrefab == "" || childPrefab == ResourceName.Empty) continue;

				int prevChild = nested.m_ItemCounts.Get(childPrefab);
				nested.m_ItemCounts.Set(childPrefab, prevChild + 1);
			}

			// On n enregistre que les conteneurs non vides (inutile d alourdir le JSON)
			if (nested.TotalItems() > 0)
				outNested.Insert(nested);
		}

		return totalItemsFound;
	}

	//------------------------------------------------------------------------------------------------
	// ===== RESTORE =====
	//------------------------------------------------------------------------------------------------

	//------------------------------------------------------------------------------------------------
	// RESTORE au boot serveur : parcourt tous les coffres du monde, compare avec snapshot,
	// spawn UNIQUEMENT les items manquants.
	//
	// BUG 3 : tout coffre qui a un snapshot non vide mais qui n est PAS trouve dans le monde
	// (pas encore charge) est marque pending, et des retries sont programmes.
	//------------------------------------------------------------------------------------------------
	void RestoreAll()
	{
		if (!Replication.IsServer()) return;
		LoadFromDisk();

		array<IEntity> storages = new array<IEntity>();
		CollectAllStorages(storages);

		// Marque d abord TOUS les snapshots non vides comme pending.
		// Chaque coffre effectivement restaure sera retire de la liste au fur et a mesure.
		m_PendingRestore.Clear();
		foreach (string snapKey, LP_StorageSnapshot s : m_Snapshots)
		{
			if (!s) continue;
			if (s.TotalItems() > 0)
				m_PendingRestore.Set(snapKey, true);
		}

		int restoredCount = 0;
		int checkedCount = 0;
		foreach (IEntity storageEntity : storages)
		{
			checkedCount = checkedCount + 1;
			int spawned = RestoreStorage(storageEntity);
			if (spawned > 0) restoredCount = restoredCount + spawned;
		}

		Print(string.Format("[StorageSaveManager] Restore boot : %1 coffres verifies, %2 item(s) restaure(s), %3 coffre(s) encore en attente.",
			checkedCount.ToString(), restoredCount.ToString(), m_PendingRestore.Count().ToString()), LogLevel.NORMAL);

		if (m_PendingRestore.Count() > 0)
			ScheduleRestoreRetry();
	}

	//------------------------------------------------------------------------------------------------
	// BUG 3 : retente le restore des coffres encore en attente (pas encore charges au boot,
	// ou dont le spawn avait echoue).
	//------------------------------------------------------------------------------------------------
	protected void ScheduleRestoreRetry()
	{
		if (m_RestoreRetryCount >= RESTORE_MAX_RETRIES)
		{
			Print(string.Format("[StorageSaveManager] Restore : abandon apres %1 retries, %2 coffre(s) jamais retrouve(s). Leurs snapshots sont CONSERVES.",
				RESTORE_MAX_RETRIES.ToString(), m_PendingRestore.Count().ToString()), LogLevel.WARNING);
			// On vide la liste pending pour que le tick reprenne son travail normal,
			// mais les snapshots restent intacts : aucun contenu n est perdu.
			m_PendingRestore.Clear();
			return;
		}

		m_RestoreRetryCount = m_RestoreRetryCount + 1;
		GetGame().GetCallqueue().CallLater(RetryPendingRestores, RESTORE_RETRY_DELAY_MS, false);
	}

	//------------------------------------------------------------------------------------------------
	void RetryPendingRestores()
	{
		if (!Replication.IsServer()) return;
		if (m_PendingRestore.Count() == 0) return;

		array<IEntity> storages = new array<IEntity>();
		CollectAllStorages(storages);

		int restoredCount = 0;
		foreach (IEntity storageEntity : storages)
		{
			int spawned = RestoreStorage(storageEntity);
			if (spawned > 0) restoredCount = restoredCount + spawned;
		}

		Print(string.Format("[StorageSaveManager] Retry restore %1/%2 : %3 item(s) restaure(s), %4 coffre(s) encore en attente.",
			m_RestoreRetryCount.ToString(), RESTORE_MAX_RETRIES.ToString(),
			restoredCount.ToString(), m_PendingRestore.Count().ToString()), LogLevel.NORMAL);

		if (m_PendingRestore.Count() > 0)
			ScheduleRestoreRetry();
	}

	//------------------------------------------------------------------------------------------------
	// Restore un coffre : compare snapshot vs runtime, spawn les items manquants uniquement.
	// Retourne le nombre d items spawnes.
	//
	// GARDE ANTI-DUPLICATION (BUG 6) :
	//   On ne refuse le restore QUE si m_EmptyConfirmed est vrai, c est a dire si le coffre
	//   a ete vu vide par DEUX lectures successives avant le reboot. Un seul scan vide
	//   parasite ne condamne plus le contenu.
	//------------------------------------------------------------------------------------------------
	protected int RestoreStorage(IEntity storageEntity)
	{
		if (!storageEntity) return 0;

		EntityPrefabData pd = storageEntity.GetPrefabData();
		if (!pd) return 0;
		string prefabName = pd.GetPrefabName();
		if (prefabName != PREFAB_STORAGEBOX && prefabName != PREFAB_SAFE) return 0;

		vector pos = storageEntity.GetOrigin();

		// BUG 2 : lookup tolerant (cle exacte puis proximite)
		LP_StorageSnapshot snap = FindSnapshotForStorage(prefabName, pos);
		if (!snap)
		{
			// Coffre inconnu : c est un coffre neuf, rien a restaurer. Pas un probleme.
			return 0;
		}

		string key = snap.m_StorageKey;

		// Rien a restaurer : on sort du pending immediatement.
		if (snap.TotalItems() == 0)
		{
			m_PendingRestore.Remove(key);
			return 0;
		}

		BaseInventoryStorageComponent storage = BaseInventoryStorageComponent.Cast(
			storageEntity.FindComponent(SCR_UniversalInventoryStorageComponent));
		if (!storage)
			storage = BaseInventoryStorageComponent.Cast(
				storageEntity.FindComponent(BaseInventoryStorageComponent));
		if (!storage)
		{
			// Composant pas encore pret : on laisse en pending pour un retry.
			return 0;
		}

		// Lit l etat actuel du coffre
		ref map<string, int> currentCounts = new map<string, int>();
		ref array<ref LP_NestedContainer> currentNested = new array<ref LP_NestedContainer>();
		ReadStorageContents(storage, currentCounts, currentNested);

		// === GARDE ANTI-DUPLICATION ===
		// Uniquement si le vide avait ete CONFIRME par double lecture avant le reboot.
		if (snap.m_EmptyConfirmed && currentCounts.Count() == 0)
		{
			Print(string.Format("[StorageSaveManager] Coffre %1 : snapshot avait %2 items mais vide CONFIRME avant reboot. Pas de restore (duplication evitee).",
				key, snap.TotalItems().ToString()), LogLevel.NORMAL);
			snap.m_ItemCounts.Clear();
			snap.m_Nested.Clear();
			snap.m_ConsecutiveEmptyScans = 0;
			m_Dirty = true;
			m_PendingRestore.Remove(key);
			return 0;
		}

		// Spawn des items top-level manquants
		int spawned = 0;
		int totalMissing = 0;
		int failed = 0;

		foreach (string itemPrefab, int savedCount : snap.m_ItemCounts)
		{
			int currentCount = currentCounts.Get(itemPrefab);
			int missing = savedCount - currentCount;
			if (missing <= 0) continue;
			totalMissing = totalMissing + missing;

			for (int j = 0; j < missing; j++)
			{
				if (SpawnItemInStorage(itemPrefab, storage, storageEntity))
					spawned = spawned + 1;
				else
					failed = failed + 1;
			}
		}

		if (totalMissing > 0)
		{
			Print(string.Format("[StorageSaveManager] Coffre %1 : %2 item(s) manquant(s), %3 restaure(s), %4 echec(s)",
				key, totalMissing.ToString(), spawned.ToString(), failed.ToString()), LogLevel.NORMAL);
		}

		// BUG 3 : on ne sort du pending que si tout a reussi.
		// Si des spawns ont echoue, on laisse le coffre en pending pour un retry, et surtout
		// le tick ne viendra pas ecraser le snapshot entre-temps.
		if (failed == 0)
			m_PendingRestore.Remove(key);

		// BUG 4 : remplissage differe des conteneurs imbriques (l insertion est async,
		// il faut laisser les conteneurs top-level s attacher avant de les remplir).
		if (snap.m_Nested.Count() > 0)
		{
			m_RuntimeEntities.Set(key, storageEntity);
			GetGame().GetCallqueue().CallLater(FillNestedContainers, NESTED_FILL_DELAY_MS, false, key);
		}

		return spawned;
	}

	//------------------------------------------------------------------------------------------------
	// BUG 4 : remplit les conteneurs imbriques d un coffre a partir du snapshot.
	// Appele NESTED_FILL_DELAY_MS apres le restore top-level pour laisser le temps aux
	// conteneurs fraichement spawnes de s attacher au coffre.
	//
	// APPARIEMENT : les conteneurs du monde sont apparies aux specs du snapshot par prefab
	// puis par ordre d apparition. Deux sacs identiques peuvent voir leur contenu echange,
	// mais le total est conserve, ce qui est le seul point qui compte pour eviter une perte.
	//------------------------------------------------------------------------------------------------
	void FillNestedContainers(string key)
	{
		LP_StorageSnapshot snap = m_Snapshots.Get(key);
		if (!snap) return;
		if (snap.m_Nested.Count() == 0) return;

		IEntity storageEntity = m_RuntimeEntities.Get(key);
		if (!storageEntity) return;

		BaseInventoryStorageComponent storage = BaseInventoryStorageComponent.Cast(
			storageEntity.FindComponent(SCR_UniversalInventoryStorageComponent));
		if (!storage)
			storage = BaseInventoryStorageComponent.Cast(
				storageEntity.FindComponent(BaseInventoryStorageComponent));
		if (!storage) return;

		// Combien de specs par prefab de conteneur a-t-on deja consommees ?
		map<string, int> specUsed = new map<string, int>();
		int totalSpawned = 0;

		int slotCount = storage.GetSlotsCount();
		for (int i = 0; i < slotCount; i++)
		{
			InventoryStorageSlot slot = storage.GetSlot(i);
			if (!slot) continue;
			IEntity itemEnt = slot.GetAttachedEntity();
			if (!itemEnt) continue;
			EntityPrefabData itemPd = itemEnt.GetPrefabData();
			if (!itemPd) continue;
			string itemPrefab = itemPd.GetPrefabName();
			if (itemPrefab == "") continue;

			BaseInventoryStorageComponent childStorage = BaseInventoryStorageComponent.Cast(
				itemEnt.FindComponent(SCR_UniversalInventoryStorageComponent));
			if (!childStorage) continue;  // insertion impossible sans le wrapper modde

			// Trouve la Nieme spec correspondant a ce prefab de conteneur
			int alreadyUsed = specUsed.Get(itemPrefab);
			LP_NestedContainer spec = null;
			int seen = 0;
			foreach (LP_NestedContainer candidate : snap.m_Nested)
			{
				if (!candidate) continue;
				if (candidate.m_ContainerPrefab != itemPrefab) continue;
				if (seen == alreadyUsed)
				{
					spec = candidate;
					break;
				}
				seen = seen + 1;
			}

			if (!spec) continue;
			specUsed.Set(itemPrefab, alreadyUsed + 1);

			// Compte le contenu actuel du conteneur
			map<string, int> childCurrent = new map<string, int>();
			int childSlots = childStorage.GetSlotsCount();
			for (int j = 0; j < childSlots; j++)
			{
				InventoryStorageSlot cs = childStorage.GetSlot(j);
				if (!cs) continue;
				IEntity ce = cs.GetAttachedEntity();
				if (!ce) continue;
				EntityPrefabData cpd = ce.GetPrefabData();
				if (!cpd) continue;
				string cp = cpd.GetPrefabName();
				if (cp == "") continue;
				int prev = childCurrent.Get(cp);
				childCurrent.Set(cp, prev + 1);
			}

			// Spawn uniquement les manquants
			foreach (string wantPrefab, int wantCount : spec.m_ItemCounts)
			{
				int have = childCurrent.Get(wantPrefab);
				int missing = wantCount - have;
				if (missing <= 0) continue;

				for (int k = 0; k < missing; k++)
				{
					if (SpawnItemInStorage(wantPrefab, childStorage, itemEnt))
						totalSpawned = totalSpawned + 1;
				}
			}
		}

		if (totalSpawned > 0)
		{
			Print(string.Format("[StorageSaveManager] Coffre %1 : %2 item(s) restaure(s) dans les conteneurs imbriques.",
				key, totalSpawned.ToString()), LogLevel.NORMAL);
		}
	}

	//------------------------------------------------------------------------------------------------
	// ===== SPAWN =====
	//------------------------------------------------------------------------------------------------

	//------------------------------------------------------------------------------------------------
	// BUG 1 (LE CORRECTIF PRINCIPAL) : spawn un item et l insere dans le storage cible.
	//
	// ANCIENNE METHODE (cassee au boot) : passait par un SCR_InventoryStorageManagerComponent
	// emprunte a un joueur connecte. Au boot, aucun joueur n est connecte, donc retour null
	// et aucun item n etait jamais restaure.
	//
	// NOUVELLE METHODE : on spawn l entite directement dans le monde juste au-dessus du
	// conteneur, puis on l insere via LP_StorageInsertItemForRestore (wrapper modde dans
	// LP_UniversalStorageModded.c). Aucune dependance a un joueur connecte.
	//
	// FALLBACK : si le storage cible n est pas un SCR_UniversalInventoryStorageComponent
	// (donc pas de wrapper disponible), on retente l ancienne route par manager joueur,
	// qui fonctionne quand au moins un joueur est connecte.
	//------------------------------------------------------------------------------------------------
	protected bool SpawnItemInStorage(string prefabName, BaseInventoryStorageComponent storage, IEntity anchorEntity)
	{
		if (!storage) return false;
		if (prefabName == "") return false;

		// --- Route principale : spawn monde + wrapper modde ---
		SCR_UniversalInventoryStorageComponent universal = SCR_UniversalInventoryStorageComponent.Cast(storage);
		if (universal)
		{
			Resource res = Resource.Load(prefabName);
			if (!res || !res.IsValid())
			{
				Print(string.Format("[StorageSaveManager] SPAWN FAIL : prefab invalide %1", prefabName), LogLevel.WARNING);
				return false;
			}

			vector spawnPos = "0 0 0";
			if (anchorEntity)
				spawnPos = anchorEntity.GetOrigin();
			// Legerement au-dessus : si l insertion echoue (coffre plein), l item tombe
			// a cote du coffre au lieu de se retrouver dans le sol.
			spawnPos[1] = spawnPos[1] + 0.5;

			EntitySpawnParams params = new EntitySpawnParams();
			params.TransformMode = ETransformMode.WORLD;
			params.Transform[3] = spawnPos;

			IEntity item = GetGame().SpawnEntityPrefab(res, GetGame().GetWorld(), params);
			if (!item)
			{
				Print(string.Format("[StorageSaveManager] SPAWN FAIL : SpawnEntityPrefab null pour %1", prefabName), LogLevel.WARNING);
				return false;
			}

			// L insertion est async : le wrapper retourne toujours true. Si elle echoue
			// reellement (coffre plein), l item reste au sol pres du coffre, ce qui reste
			// preferable a une perte seche.
			universal.LP_StorageInsertItemForRestore(item);
			return true;
		}

		// --- Fallback : ancienne route par manager joueur ---
		SCR_InventoryStorageManagerComponent mgr = FindAnyPlayerInventoryManager();
		if (!mgr)
		{
			Print(string.Format("[StorageSaveManager] SPAWN FAIL : storage non universal et aucun joueur connecte, %1 non restaure",
				prefabName), LogLevel.WARNING);
			return false;
		}

		ResourceName rn = prefabName;
		bool ok = mgr.TrySpawnPrefabToStorage(rn, storage);
		if (!ok)
		{
			Print(string.Format("[StorageSaveManager] SPAWN FAIL : TrySpawnPrefabToStorage=false pour %1", prefabName), LogLevel.WARNING);
			return false;
		}
		return true;
	}

	//------------------------------------------------------------------------------------------------
	// Fallback uniquement. Retourne null au boot (aucun joueur connecte), ce qui est normal :
	// la route principale de SpawnItemInStorage n en a pas besoin.
	//------------------------------------------------------------------------------------------------
	protected SCR_InventoryStorageManagerComponent FindAnyPlayerInventoryManager()
	{
		PlayerManager pm = GetGame().GetPlayerManager();
		if (!pm) return null;

		array<int> playerIds = new array<int>();
		pm.GetPlayers(playerIds);

		foreach (int pid : playerIds)
		{
			IEntity playerEnt = pm.GetPlayerControlledEntity(pid);
			if (!playerEnt) continue;
			SCR_InventoryStorageManagerComponent mgr = SCR_InventoryStorageManagerComponent.Cast(
				playerEnt.FindComponent(SCR_InventoryStorageManagerComponent));
			if (mgr) return mgr;
		}
		return null;
	}

	//------------------------------------------------------------------------------------------------
	// ===== LOOKUP TOLERANT =====
	//------------------------------------------------------------------------------------------------

	//------------------------------------------------------------------------------------------------
	// BUG 2 : retrouve le snapshot d un coffre meme si sa position a legerement derive.
	//   1. Cle exacte (chemin rapide, compatible avec toutes les saves existantes)
	//   2. Sinon : meme prefab, distance XZ la plus courte sous KEY_TOLERANCE_M
	// Si trouve par tolerance, le snapshot est RE-CLE sur la nouvelle position pour que les
	// lookups suivants soient directs et que la derive ne s accumule pas.
	//------------------------------------------------------------------------------------------------
	protected LP_StorageSnapshot FindSnapshotForStorage(string prefabName, vector pos)
	{
		string exactKey = LP_StorageSnapshot.BuildKey(prefabName, pos);
		LP_StorageSnapshot snap = m_Snapshots.Get(exactKey);
		if (snap) return snap;

		LP_StorageSnapshot best = null;
		float bestDist = KEY_TOLERANCE_M;

		foreach (string k, LP_StorageSnapshot candidate : m_Snapshots)
		{
			if (!candidate) continue;
			if (candidate.m_PrefabName != prefabName) continue;

			float d = LP_StorageSnapshot.DistXZ(candidate.m_Position, pos);
			if (d < bestDist)
			{
				bestDist = d;
				best = candidate;
			}
		}

		if (!best) return null;

		// Re-cle le snapshot sur la position actuelle
		string oldKey = best.m_StorageKey;
		m_Snapshots.Remove(oldKey);
		best.m_StorageKey = exactKey;
		best.m_Position = pos;
		m_Snapshots.Set(exactKey, best);
		m_Dirty = true;

		// Reporte l etat pending sur la nouvelle cle
		if (m_PendingRestore.Contains(oldKey))
		{
			m_PendingRestore.Remove(oldKey);
			m_PendingRestore.Set(exactKey, true);
		}

		Print(string.Format("[StorageSaveManager] Coffre retrouve par proximite (%1m) : %2 -> %3, %4 items preserves",
			bestDist.ToString(), oldKey, exactKey, best.TotalItems().ToString()), LogLevel.NORMAL);

		return best;
	}

	//------------------------------------------------------------------------------------------------
	// Collecte toutes les entites coffres du monde (StorageBox + Base_Safe)
	//------------------------------------------------------------------------------------------------
	protected void CollectAllStorages(out array<IEntity> outStorages)
	{
		BaseWorld world = GetGame().GetWorld();
		if (!world) return;

		m_TmpFoundStorages.Clear();
		world.QueryEntitiesByAABB("-99999 -99999 -99999", "99999 99999 99999", OnStorageEntityFilter, null, EQueryEntitiesFlags.ALL);
		foreach (IEntity ent : m_TmpFoundStorages)
			outStorages.Insert(ent);
	}

	bool OnStorageEntityFilter(IEntity entity)
	{
		if (!entity) return true;
		EntityPrefabData pd = entity.GetPrefabData();
		if (!pd) return true;
		string rn = pd.GetPrefabName();
		if (rn == PREFAB_STORAGEBOX || rn == PREFAB_SAFE)
			m_TmpFoundStorages.Insert(entity);
		return true;
	}

	//------------------------------------------------------------------------------------------------
	// ===== PERSISTANCE JSON =====
	//------------------------------------------------------------------------------------------------

	void SaveToDisk()
	{
		SCR_JsonSaveContext ctx = new SCR_JsonSaveContext();
		ctx.WriteValue("count", m_Snapshots.Count());

		int idx = 0;
		foreach (string key, LP_StorageSnapshot snap : m_Snapshots)
		{
			if (!snap) continue;
			string prefix = "storages/" + idx.ToString() + "/";
			ctx.WriteValue(prefix + "key", snap.m_StorageKey);
			ctx.WriteValue(prefix + "prefab", snap.m_PrefabName);
			ctx.WriteValue(prefix + "posX", snap.m_Position[0]);
			ctx.WriteValue(prefix + "posY", snap.m_Position[1]);
			ctx.WriteValue(prefix + "posZ", snap.m_Position[2]);
			ctx.WriteValue(prefix + "emptyScans", snap.m_ConsecutiveEmptyScans);
			ctx.WriteValue(prefix + "emptyConfirmed", snap.m_EmptyConfirmed);
			ctx.WriteValue(prefix + "itemTypes", snap.m_ItemCounts.Count());

			int j = 0;
			foreach (string itemPrefab, int cnt : snap.m_ItemCounts)
			{
				ctx.WriteValue(prefix + "items/" + j.ToString() + "/prefab", itemPrefab);
				ctx.WriteValue(prefix + "items/" + j.ToString() + "/count", cnt);
				j = j + 1;
			}

			// BUG 4 : conteneurs imbriques
			ctx.WriteValue(prefix + "nestedCount", snap.m_Nested.Count());
			int n = 0;
			foreach (LP_NestedContainer nested : snap.m_Nested)
			{
				if (!nested) continue;
				string nprefix = prefix + "nested/" + n.ToString() + "/";
				ctx.WriteValue(nprefix + "container", nested.m_ContainerPrefab);
				ctx.WriteValue(nprefix + "itemTypes", nested.m_ItemCounts.Count());

				int m = 0;
				foreach (string nItemPrefab, int nCnt : nested.m_ItemCounts)
				{
					ctx.WriteValue(nprefix + "items/" + m.ToString() + "/prefab", nItemPrefab);
					ctx.WriteValue(nprefix + "items/" + m.ToString() + "/count", nCnt);
					m = m + 1;
				}
				n = n + 1;
			}

			idx = idx + 1;
		}
		ctx.SaveToFile(SAVE_FILE);
	}

	//------------------------------------------------------------------------------------------------
	void LoadFromDisk()
	{
		if (m_Loaded) return;
		m_Loaded = true;
		if (!FileIO.FileExists(SAVE_FILE)) return;

		SCR_JsonLoadContext ctx = new SCR_JsonLoadContext();
		if (!ctx.LoadFromFile(SAVE_FILE)) return;

		int count = 0;
		ctx.ReadValue("count", count);

		for (int i = 0; i < count; i++)
		{
			string prefix = "storages/" + i.ToString() + "/";
			LP_StorageSnapshot snap = new LP_StorageSnapshot();

			float px = 0; float py = 0; float pz = 0;
			ctx.ReadValue(prefix + "key", snap.m_StorageKey);
			ctx.ReadValue(prefix + "prefab", snap.m_PrefabName);
			ctx.ReadValue(prefix + "posX", px);
			ctx.ReadValue(prefix + "posY", py);
			ctx.ReadValue(prefix + "posZ", pz);
			snap.m_Position = Vector(px, py, pz);
			ctx.ReadValue(prefix + "emptyScans", snap.m_ConsecutiveEmptyScans);
			ctx.ReadValue(prefix + "emptyConfirmed", snap.m_EmptyConfirmed); // false si vieux save

			int itemTypes = 0;
			ctx.ReadValue(prefix + "itemTypes", itemTypes);
			for (int j = 0; j < itemTypes; j++)
			{
				string itemPrefab = "";
				int cnt = 0;
				ctx.ReadValue(prefix + "items/" + j.ToString() + "/prefab", itemPrefab);
				ctx.ReadValue(prefix + "items/" + j.ToString() + "/count", cnt);
				if (itemPrefab != "" && cnt > 0)
					snap.m_ItemCounts.Set(itemPrefab, cnt);
			}

			// BUG 4 : conteneurs imbriques (0 si vieux save sans ce champ)
			int nestedCount = 0;
			ctx.ReadValue(prefix + "nestedCount", nestedCount);
			for (int n = 0; n < nestedCount; n++)
			{
				string nprefix = prefix + "nested/" + n.ToString() + "/";
				LP_NestedContainer nested = new LP_NestedContainer();
				ctx.ReadValue(nprefix + "container", nested.m_ContainerPrefab);

				int nItemTypes = 0;
				ctx.ReadValue(nprefix + "itemTypes", nItemTypes);
				for (int m = 0; m < nItemTypes; m++)
				{
					string nItemPrefab = "";
					int nCnt = 0;
					ctx.ReadValue(nprefix + "items/" + m.ToString() + "/prefab", nItemPrefab);
					ctx.ReadValue(nprefix + "items/" + m.ToString() + "/count", nCnt);
					if (nItemPrefab != "" && nCnt > 0)
						nested.m_ItemCounts.Set(nItemPrefab, nCnt);
				}

				if (nested.m_ContainerPrefab != "" && nested.TotalItems() > 0)
					snap.m_Nested.Insert(nested);
			}

			if (snap.m_StorageKey != "")
				m_Snapshots.Set(snap.m_StorageKey, snap);
		}

		Print(string.Format("[StorageSaveManager] Charge %1 snapshots de coffres.",
			count.ToString()), LogLevel.NORMAL);
	}
}
