//------------------------------------------------------------------------------------------------
// LP_CannabisManager.c
// Singleton SERVEUR qui gere le taux de THC par joueur (0 - 100 %).
// Miroir de LP_AlcoholManager.
//
// COMPORTEMENT :
//  - Fume un joint -> ServerAddThc(playerId, amount) ajoute au taux (max 100)
//  - Toutes les 500ms, degrisement naturel de 0.05 pt (~17 min pour redescendre de 100)
//  - Push vers le client via LP_CannabisPlayerComponent
//  - Au niveau 100% : chute du sang -> unconscious
//  - Au-dessus de 25% : ralentissement progressif (via sang progressif)
//------------------------------------------------------------------------------------------------

class LP_CannabisManager
{
	static ref LP_CannabisManager s_Instance;
	
	// Map playerId -> thc level (0 - 100)
	ref map<int, float> m_ThcLevels = new map<int, float>();
	
	const float MAX_THC = 100.0;
	const float SOBER_RATE_PER_TICK = 0.05;
	const float UNCONSCIOUS_THRESHOLD = 100.0;
	const int TICK_INTERVAL_MS = 500;
	
	bool m_TickerStarted = false;
	
	//------------------------------------------------------------------------------------------------
	static LP_CannabisManager GetInstance()
	{
		if (!s_Instance) s_Instance = new LP_CannabisManager();
		return s_Instance;
	}
	
	//------------------------------------------------------------------------------------------------
	void EnsureTicker()
	{
		if (m_TickerStarted) return;
		m_TickerStarted = true;
		GetGame().GetCallqueue().CallLater(TickAll, TICK_INTERVAL_MS, true);
		Print("[LP_CannabisManager] Ticker degrisement demarre.", LogLevel.NORMAL);
	}
	
	//------------------------------------------------------------------------------------------------
	void ServerAddThc(int playerId, float amount)
	{
		if (!Replication.IsServer()) return;
		if (playerId <= 0) return;
		
		float current = 0;
		if (m_ThcLevels.Contains(playerId))
			current = m_ThcLevels.Get(playerId);
		
		current = current + amount;
		if (current > MAX_THC) current = MAX_THC;
		if (current < 0) current = 0;
		
		m_ThcLevels.Set(playerId, current);
		
		Print(string.Format("[LP_CannabisManager] Player %1 : niveau THC %2%% (+%3)",
			playerId.ToString(), current.ToString(), amount.ToString()), LogLevel.NORMAL);
		
		PushToClient(playerId, current);
		EnsureTicker();
		
		// Trigger immediat si 100%
		if (current >= UNCONSCIOUS_THRESHOLD)
			ForceUnconscious(playerId);
	}
	
	//------------------------------------------------------------------------------------------------
	void SetThc(int playerId, float value)
	{
		if (!Replication.IsServer()) return;
		if (playerId <= 0) return;
		if (value < 0) value = 0;
		if (value > MAX_THC) value = MAX_THC;
		m_ThcLevels.Set(playerId, value);
		PushToClient(playerId, value);
		if (value > 0) EnsureTicker();
	}
	
	//------------------------------------------------------------------------------------------------
	float GetThc(int playerId)
	{
		if (!m_ThcLevels.Contains(playerId)) return 0;
		return m_ThcLevels.Get(playerId);
	}
	
	//------------------------------------------------------------------------------------------------
	protected void PushToClient(int playerId, float level)
	{
		PlayerController pc = GetGame().GetPlayerManager().GetPlayerController(playerId);
		if (!pc) return;
		LP_CannabisPlayerComponent cpc = LP_CannabisPlayerComponent.Cast(
			pc.FindComponent(LP_CannabisPlayerComponent));
		if (cpc) cpc.ServerPushLevel(level);
	}
	
	//------------------------------------------------------------------------------------------------
	void TickAll()
	{
		if (!Replication.IsServer()) return;
		if (m_ThcLevels.Count() == 0) return;
		
		array<int> toRemove = new array<int>();
		array<int> playerIds = new array<int>();
		foreach (int pid, float lvl : m_ThcLevels) playerIds.Insert(pid);
		
		foreach (int playerId : playerIds)
		{
			float level = m_ThcLevels.Get(playerId);
			
			if (level >= UNCONSCIOUS_THRESHOLD)
			{
				ForceUnconscious(playerId);
				continue;
			}
			
			// Applique l effet sang (ralentissement progressif)
			ApplyBloodEffect(playerId, level);
			
			// Degrisement naturel
			level = level - SOBER_RATE_PER_TICK;
			if (level <= 0)
			{
				toRemove.Insert(playerId);
				continue;
			}
			m_ThcLevels.Set(playerId, level);
			PushToClient(playerId, level);
		}
		
		foreach (int rid : toRemove)
		{
			m_ThcLevels.Remove(rid);
			PushToClient(rid, 0);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Descend progressivement le sang pour ralentir le joueur sans trigger unconscious involontaire
	//------------------------------------------------------------------------------------------------
	protected void ApplyBloodEffect(int playerId, float thcLevel)
	{
		if (thcLevel < 25.0) return;
		
		PlayerController pc = GetGame().GetPlayerManager().GetPlayerController(playerId);
		if (!pc) return;
		IEntity character = pc.GetControlledEntity();
		if (!character) return;
		
		SCR_CharacterDamageManagerComponent dmg = SCR_CharacterDamageManagerComponent.Cast(
			character.FindComponent(SCR_CharacterDamageManagerComponent));
		if (!dmg) return;
		
		HitZone bloodHZ = dmg.GetBloodHitZone();
		if (!bloodHZ) return;
		
		float bloodMax = bloodHZ.GetMaxHealth();
		if (bloodMax <= 0) return;
		
		// Seuils safe (sang >= 40% sauf a 100% THC)
		float targetPct = 1.0;
		if (thcLevel >= 90.0) targetPct = 0.42;
		else if (thcLevel >= 70.0) targetPct = 0.48;
		else if (thcLevel >= 50.0) targetPct = 0.55;
		else if (thcLevel >= 25.0) targetPct = 0.70;
		
		float targetBlood = bloodMax * targetPct;
		float currentBlood = bloodHZ.GetHealth();
		
		// Descente PROGRESSIVE (max 3% par tick) pour eviter hemorragie detectee
		if (currentBlood > targetBlood)
		{
			float maxDropPerTick = bloodMax * 0.03;
			float newBlood = currentBlood - maxDropPerTick;
			if (newBlood < targetBlood) newBlood = targetBlood;
			bloodHZ.SetHealth(newBlood);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Force unconscious a 100% THC via chute du sang a 30%
	//------------------------------------------------------------------------------------------------
	protected void ForceUnconscious(int playerId)
	{
		PlayerController pc = GetGame().GetPlayerManager().GetPlayerController(playerId);
		if (!pc) return;
		IEntity character = pc.GetControlledEntity();
		if (!character) return;
		
		SCR_CharacterDamageManagerComponent dmg = SCR_CharacterDamageManagerComponent.Cast(
			character.FindComponent(SCR_CharacterDamageManagerComponent));
		if (!dmg) return;
		
		HitZone bloodHZ = dmg.GetBloodHitZone();
		if (!bloodHZ) return;
		
		float bloodMax = bloodHZ.GetMaxHealth();
		float targetBlood = bloodMax * 0.30;
		bloodHZ.SetHealth(targetBlood);
		
		Print(string.Format("[LP_CannabisManager] Player %1 : THC 100%% - inconscient force !",
			playerId.ToString()), LogLevel.WARNING);
		
		SetThc(playerId, 0);
	}
	
	//------------------------------------------------------------------------------------------------
	void OnPlayerDisconnect(int playerId)
	{
		if (m_ThcLevels.Contains(playerId))
			m_ThcLevels.Remove(playerId);
	}
}
