//------------------------------------------------------------------------------------------------
// JobBankManager.c
//
// Systeme bancaire pour Les Pacifistes.
// 
// Regles :
//   - Depot / retrait a l ATM
//   - Frais 1% sur depot ET retrait (redirige a la cagnotte municipale)
//   - Interet quotidien +0.1% (calcul horaire = +0.00417%/h)
//   - Aucune limite de transaction
//   - 100% securise : l argent en banque n est jamais perdu (mort, vol, etc.)
//
// Persistance : $profile:LesPacifistesJobs/bank_accounts.json
//------------------------------------------------------------------------------------------------

class BankAccount
{
	string m_UID;                    // UID persistant du joueur
	int m_Balance;                   // Solde actuel (capsules)
	int m_LastInterestTimestamp;     // Unix time du dernier tick d interet applique
	int m_TotalDeposited;            // Statistique : total historique depose
	int m_TotalWithdrawn;            // Statistique : total historique retire
	int m_TotalInterest;             // Statistique : total historique interets recus
	
	void BankAccount()
	{
		m_UID = "";
		m_Balance = 0;
		m_LastInterestTimestamp = 0;
		m_TotalDeposited = 0;
		m_TotalWithdrawn = 0;
		m_TotalInterest = 0;
	}
}

class JobBankManager
{
	static ref JobBankManager s_Instance;
	
	// Constantes economiques
	const int DEPOSIT_FEE_PERCENT = 1;      // 1% frais depot
	const int WITHDRAW_FEE_PERCENT = 1;     // 1% frais retrait
	// Interet : 0.1% par jour = 0.1/24 = 0.00417% par heure.
	// Comme on ne peut pas travailler en fractions de %, on utilise le facteur 1/100000
	// Formule tick horaire : balance = balance * (100000 + INTEREST_RATE_100K) / 100000
	// 0.00417% -> 4.17 pour 100000 -> arrondi a 4 (approx bonne, ~0.096%/jour)
	// Alternative plus precise : accumuler la fraction et l appliquer quand elle depasse 1 caps.
	// On choisit la 2e (voir ApplyInterestTick).
	const int INTEREST_TICK_INTERVAL_MS = 3600000;  // 1 heure
	const int INTEREST_BPS_PER_DAY = 10;    // Basis points : 10bp = 0.1%
	const int INTEREST_HOURS_PER_DAY = 24;
	
	const string SAVE_PATH = "$profile:LesPacifistesJobs/bank_accounts.json";
	
	// Map UID -> compte
	ref map<string, ref BankAccount> m_Accounts;
	
	//------------------------------------------------------------------------------------------------
	void JobBankManager()
	{
		m_Accounts = new map<string, ref BankAccount>();
	}
	
	//------------------------------------------------------------------------------------------------
	static JobBankManager GetInstance()
	{
		if (!s_Instance)
		{
			s_Instance = new JobBankManager();
			s_Instance.LoadFromDisk();
			// Demarre le tick horaire des interets (server-only, safe check dans le callback)
			GetGame().GetCallqueue().CallLater(InterestTickCallback, s_Instance.INTEREST_TICK_INTERVAL_MS, true);
		}
		return s_Instance;
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== ACCES COMPTES =====
	//------------------------------------------------------------------------------------------------
	
	// Recupere ou cree le compte du joueur
	BankAccount GetOrCreateAccount(string uid)
	{
		if (uid == "")
			return null;
		BankAccount acc = m_Accounts.Get(uid);
		if (!acc)
		{
			acc = new BankAccount();
			acc.m_UID = uid;
			acc.m_LastInterestTimestamp = System.GetUnixTime();
			m_Accounts.Set(uid, acc);
			SaveToDisk();
		}
		return acc;
	}
	
	int GetBalance(string uid)
	{
		if (uid == "")
			return 0;
		BankAccount acc = m_Accounts.Get(uid);
		if (!acc)
			return 0;
		return acc.m_Balance;
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== ADMIN =====
	// Modification directe du solde par un admin (pas de frais, pas de check cash).
	// delta peut etre negatif pour retirer. Le solde ne peut pas descendre sous 0.
	//------------------------------------------------------------------------------------------------
	void AdminAddToBalance(string uid, int delta)
	{
		if (uid == "" || delta == 0)
			return;
		BankAccount acc = GetOrCreateAccount(uid);
		if (!acc)
			return;
		int newBalance = acc.m_Balance + delta;
		if (newBalance < 0)
			newBalance = 0;
		acc.m_Balance = newBalance;
		SaveToDisk();
		Print(string.Format("[JobBankManager] Admin modif : uid=%1 delta=%2 nouveau_solde=%3",
			uid, delta, newBalance), LogLevel.NORMAL);
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== DEPOT =====
	//
	// Le joueur depose `amount` capsules depuis son cash vers son compte.
	// Frais : 1% preleve sur le montant depose (redirige vers cagnotte municipale).
	//   Ex: depot 100 -> 99 credites, 1 va a la mairie
	// 
	// Retourne un code + rempli outNetDeposited :
	//   0 = OK (outNetDeposited = montant net credite au compte)
	//   1 = montant invalide (<= 0)
	//   2 = solde cash insuffisant
	//------------------------------------------------------------------------------------------------
	int Deposit(string uid, int amount, out int outNetDeposited, out int outFee)
	{
		outNetDeposited = 0;
		outFee = 0;
		if (uid == "" || amount <= 0)
			return 1;
		
		CapsuleEconomyManager eco = CapsuleEconomyManager.GetInstance();
		if (!eco)
			return 1;
		
		int cash = eco.GetCapsules(uid);
		if (cash < amount)
			return 2;
		
		int fee = amount * DEPOSIT_FEE_PERCENT / 100;
		int netAmount = amount - fee;
		
		BankAccount acc = GetOrCreateAccount(uid);
		if (!acc)
			return 1;
		
		// Debit cash total (fee + net)
		eco.AddCapsules(uid, -amount);
		// Credit compte bancaire
		acc.m_Balance = acc.m_Balance + netAmount;
		acc.m_TotalDeposited = acc.m_TotalDeposited + netAmount;
		
		// Frais -> cagnotte municipale
		if (fee > 0)
		{
			JobBonPointManager bpm = JobBonPointManager.GetInstance();
			if (bpm)
				bpm.AddToTreasury(fee);
		}
		
		SaveToDisk();
		outNetDeposited = netAmount;
		outFee = fee;
		
		Print(string.Format("[JobBankManager] Depot : uid=%1 amount=%2 fee=%3 net=%4",
			uid, amount, fee, netAmount), LogLevel.NORMAL);
		return 0;
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== RETRAIT =====
	//
	// Le joueur retire `amount` capsules de son compte vers son cash.
	// Frais : 1% preleve sur le montant retire (redirige vers cagnotte municipale).
	//   Ex: retrait 100 -> 99 credites en cash, 1 va a la mairie
	//
	// Retourne code + rempli outNetReceived :
	//   0 = OK (outNetReceived = montant net recu en cash)
	//   1 = montant invalide (<= 0)
	//   2 = solde banque insuffisant
	//------------------------------------------------------------------------------------------------
	int Withdraw(string uid, int amount, out int outNetReceived, out int outFee)
	{
		outNetReceived = 0;
		outFee = 0;
		if (uid == "" || amount <= 0)
			return 1;
		
		BankAccount acc = GetOrCreateAccount(uid);
		if (!acc)
			return 1;
		
		if (acc.m_Balance < amount)
			return 2;
		
		int fee = amount * WITHDRAW_FEE_PERCENT / 100;
		int netAmount = amount - fee;
		
		CapsuleEconomyManager eco = CapsuleEconomyManager.GetInstance();
		if (!eco)
			return 1;
		
		// Debit compte bancaire (fee + net)
		acc.m_Balance = acc.m_Balance - amount;
		acc.m_TotalWithdrawn = acc.m_TotalWithdrawn + amount;
		// Credit cash net
		eco.AddCapsules(uid, netAmount);
		
		// Frais -> cagnotte municipale
		if (fee > 0)
		{
			JobBonPointManager bpm = JobBonPointManager.GetInstance();
			if (bpm)
				bpm.AddToTreasury(fee);
		}
		
		SaveToDisk();
		outNetReceived = netAmount;
		outFee = fee;
		
		Print(string.Format("[JobBankManager] Retrait : uid=%1 amount=%2 fee=%3 net=%4",
			uid, amount, fee, netAmount), LogLevel.NORMAL);
		return 0;
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== INTERETS =====
	//
	// Tick global appele toutes les heures (server uniquement).
	// Pour chaque compte : applique l interet horaire = +0.00417% du solde.
	// Comme les capsules sont des ints, on applique la formule (balance * 10) / (24 * 10000)
	// puis on arrondit ; si le montant arrondi est 0 on ne fait rien (attend le tick suivant).
	//------------------------------------------------------------------------------------------------
	static void InterestTickCallback()
	{
		if (!Replication.IsServer())
			return;
		if (!s_Instance)
			return;
		s_Instance.ApplyInterestTick();
	}
	
	void ApplyInterestTick()
	{
		if (!m_Accounts || m_Accounts.Count() == 0)
			return;
		
		int now = System.GetUnixTime();
		bool dirty = false;
		int touched = 0;
		
		// Iteration par index (Enforce)
		int count = m_Accounts.Count();
		for (int i = 0; i < count; i++)
		{
			BankAccount acc = m_Accounts.GetElement(i);
			if (!acc || acc.m_Balance <= 0)
				continue;
			
			// Calcule les heures ecoulees depuis le dernier tick
			int last = acc.m_LastInterestTimestamp;
			if (last <= 0)
			{
				acc.m_LastInterestTimestamp = now;
				continue;
			}
			int elapsedSec = now - last;
			if (elapsedSec < 3600)
				continue;  // moins d une heure : rien a faire
			int hours = elapsedSec / 3600;
			
			// Formule : interest = balance * INTEREST_BPS_PER_DAY * hours / (24 * 10000)
			// Avec INTEREST_BPS_PER_DAY = 10 (0.1%), 24h -> balance * 10 * 24 / 240000 = balance * 0.001
			int interest = (acc.m_Balance * INTEREST_BPS_PER_DAY * hours) / (INTEREST_HOURS_PER_DAY * 10000);
			if (interest > 0)
			{
				acc.m_Balance = acc.m_Balance + interest;
				acc.m_TotalInterest = acc.m_TotalInterest + interest;
				acc.m_LastInterestTimestamp = last + (hours * 3600);
				dirty = true;
				touched++;
			}
			else
			{
				// Trop peu pour generer 1 capsule d interet a ce solde : on decale le
				// timestamp d une heure quand meme pour ne pas re-scanner en boucle,
				// mais on garde de la marge en n avancant que d une heure (pas hours)
				acc.m_LastInterestTimestamp = last + 3600;
				dirty = true;
			}
		}
		
		if (dirty)
			SaveToDisk();
		
		if (touched > 0)
			Print(string.Format("[JobBankManager] ApplyInterestTick : %1 comptes ont recu des interets",
				touched), LogLevel.NORMAL);
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== PERSISTANCE =====
	//------------------------------------------------------------------------------------------------
	
	void SaveToDisk()
	{
		if (!m_Accounts)
			return;
		SCR_JsonSaveContext ctx = new SCR_JsonSaveContext();
		int count = m_Accounts.Count();
		ctx.WriteValue("account_count", count);
		for (int i = 0; i < count; i++)
		{
			BankAccount acc = m_Accounts.GetElement(i);
			if (!acc) continue;
			string ep = "acc_" + i.ToString() + "_";
			ctx.WriteValue(ep + "uid", acc.m_UID);
			ctx.WriteValue(ep + "balance", acc.m_Balance);
			ctx.WriteValue(ep + "lastInt", acc.m_LastInterestTimestamp);
			ctx.WriteValue(ep + "totalDep", acc.m_TotalDeposited);
			ctx.WriteValue(ep + "totalWith", acc.m_TotalWithdrawn);
			ctx.WriteValue(ep + "totalInt", acc.m_TotalInterest);
		}
		ctx.SaveToFile(SAVE_PATH);
	}
	
	void LoadFromDisk()
	{
		SCR_JsonLoadContext ctx = new SCR_JsonLoadContext();
		if (!ctx.LoadFromFile(SAVE_PATH))
			return;
		int count = 0;
		ctx.ReadValue("account_count", count);
		for (int i = 0; i < count; i++)
		{
			string ep = "acc_" + i.ToString() + "_";
			BankAccount acc = new BankAccount();
			ctx.ReadValue(ep + "uid", acc.m_UID);
			ctx.ReadValue(ep + "balance", acc.m_Balance);
			ctx.ReadValue(ep + "lastInt", acc.m_LastInterestTimestamp);
			ctx.ReadValue(ep + "totalDep", acc.m_TotalDeposited);
			ctx.ReadValue(ep + "totalWith", acc.m_TotalWithdrawn);
			ctx.ReadValue(ep + "totalInt", acc.m_TotalInterest);
			if (acc.m_UID != "")
				m_Accounts.Set(acc.m_UID, acc);
		}
		Print(string.Format("[JobBankManager] Loaded %1 accounts", count), LogLevel.NORMAL);
	}
}
