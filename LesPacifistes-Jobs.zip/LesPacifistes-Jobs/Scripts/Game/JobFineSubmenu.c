//------------------------------------------------------------------------------------------------
// JobFineSubmenu.c
// Sous-menu pour choisir le niveau d'amende (1/2/3) a emettre
//------------------------------------------------------------------------------------------------

class JobFineSubmenu : ChimeraMenuBase
{
	Widget m_RootWidget;
	int m_TargetPlayerId;
	string m_TargetName;
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuOpen()
	{
		super.OnMenuOpen();
		m_RootWidget = GetRootWidget();
		if (!m_RootWidget)
			return;
		
		AttachButton("Fine1Button", 1);
		AttachButton("Fine2Button", 2);
		AttachButton("Fine3Button", 3);
		AttachButton("CloseButton", 0); // 0 = annuler
		
		ButtonWidget firstBtn = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("Fine1Button"));
		if (firstBtn)
			GetGame().GetWorkspace().SetFocusedWidget(firstBtn);
	}
	
	//------------------------------------------------------------------------------------------------
	void AttachButton(string name, int level)
	{
		ButtonWidget btn = ButtonWidget.Cast(m_RootWidget.FindAnyWidget(name));
		if (!btn)
			return;
		FineSubmenuClickHandler h = new FineSubmenuClickHandler();
		h.m_Menu = this;
		h.m_Level = level;
		btn.AddHandler(h);
		JobFocusHandler.Attach(btn);
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuUpdate(float tDelta)
	{
		super.OnMenuUpdate(tDelta);
		if (GetGame().GetInputManager().GetActionValue("MenuBack") > 0.5)
		{
			CloseMenuInternal();
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void Initialize(int targetPlayerId, string targetName)
	{
		m_TargetPlayerId = targetPlayerId;
		m_TargetName = targetName;
	}
	
	//------------------------------------------------------------------------------------------------
	void OnLevelClicked(int level)
	{
		if (level <= 0)
		{
			CloseMenuInternal();
			return;
		}
		
		PlayerController pc = GetGame().GetPlayerController();
		if (pc)
		{
			JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
			if (jpc)
				jpc.ClientAskIssueFine(m_TargetPlayerId, level);
		}
		CloseMenuInternal();
	}
	
	//------------------------------------------------------------------------------------------------
	void CloseMenuInternal()
	{
		GetGame().GetMenuManager().CloseMenu(this);
	}
}

class FineSubmenuClickHandler : ScriptedWidgetEventHandler
{
	JobFineSubmenu m_Menu;
	int m_Level;
	
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu)
			m_Menu.OnLevelClicked(m_Level);
		return true;
	}
}
