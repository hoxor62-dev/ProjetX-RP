//------------------------------------------------------------------------------------------------
// JobImpoundVehicleAction.c
// Action F sur un vehicule "Mettre en fourriere".
// Visible uniquement pour les joueurs metier POLICIER ou MILITAIRE (gendarme).
// Le vehicule est teleporte a la zone fourriere avec un decalage aleatoire de 5-10m
// pour eviter qu ils s empilent.
//
// A attacher via l'ActionsManagerComponent du prefab vehicule (ou par un mod global).
// Le pOwnerEntity = le vehicule, le pUserEntity = le joueur qui interagit.
//------------------------------------------------------------------------------------------------

class JobImpoundVehicleAction : ScriptedUserAction
{
	//------------------------------------------------------------------------------------------------
	override bool CanBeShownScript(IEntity user)
	{
		// Verifie cote client que le joueur local est POLICIER ou MILITAIRE.
		// IMPORTANT : JobPlayerComponent est attache au PlayerController, pas au character.
		// On recupere donc le PlayerController local et on y cherche le component.
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc)
			return false;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc)
			return false;
		EJobType job = jpc.GetJob();
		return (job == EJobType.POLICIER || job == EJobType.MILITAIRE);
	}
	
	//------------------------------------------------------------------------------------------------
	override bool CanBePerformedScript(IEntity user)
	{
		return CanBeShownScript(user);
	}
	
	//------------------------------------------------------------------------------------------------
	override bool GetActionNameScript(out string outName)
	{
		outName = "Mettre en fourriere";
		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
	{
		if (!pOwnerEntity || !pUserEntity)
			return;
		
		// Garde multijoueur : seul le joueur local execute la suite
		PlayerController localPC = GetGame().GetPlayerController();
		if (!localPC)
			return;
		IEntity localEntity = localPC.GetControlledEntity();
		if (localEntity != pUserEntity)
			return;
		
		// Recupere le RplId du vehicule (necessaire pour le serveur)
		RplComponent rpl = RplComponent.Cast(pOwnerEntity.FindComponent(RplComponent));
		if (!rpl)
			return;
		RplId vehicleRplId = rpl.Id();
		
		JobPlayerComponent jpc = JobPlayerComponent.Cast(localPC.FindComponent(JobPlayerComponent));
		if (!jpc)
			return;
		jpc.ClientAskImpoundVehicle(vehicleRplId);
	}
}
