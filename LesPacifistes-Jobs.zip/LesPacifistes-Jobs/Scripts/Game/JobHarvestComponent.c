//------------------------------------------------------------------------------------------------
// JobHarvestComponent.c
// Composant a ajouter sur un prefab de plante (ex: E_Cannabis.et) pour le rendre
// recoltable via l'action F.
//
// Workbench setup:
// - Placer ce composant sur le prefab plante
// - Definir m_DrugType dans l'editeur (WEED ou COCAINE)
// - Ajouter ActionsManagerComponent
// - Ajouter l'action JobHarvestAction (UserActions)
// - RplComponent obligatoire
//------------------------------------------------------------------------------------------------

[ComponentEditorProps(category: "LesPacifistesJobs", description: "Plante recoltable (drogue)")]
class JobHarvestComponentClass : ScriptComponentClass
{
}

//------------------------------------------------------------------------------------------------
class JobHarvestComponent : ScriptComponent
{
	[Attribute("1", UIWidgets.ComboBox, "Type de drogue a recolter", "", ParamEnumArray.FromEnum(EDrugType))]
	int m_DrugType;
	
	//------------------------------------------------------------------------------------------------
	override void OnPostInit(IEntity owner)
	{
		super.OnPostInit(owner);
		
		// Au demarrage serveur: verifie si cette plante a deja ete recoltee/detruite
		// avant un restart. Si oui, on l'auto-detruit apres un delai (pour laisser
		// le RplId se stabiliser).
		if (Replication.IsServer())
		{
			GetGame().GetCallqueue().CallLater(CheckIfDestroyed, 3000, false);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void CheckIfDestroyed()
	{
		IEntity owner = GetOwner();
		if (!owner)
			return;
		
		RplComponent rpl = RplComponent.Cast(owner.FindComponent(RplComponent));
		if (!rpl)
			return;
		
		if (JobDrugSystem.IsPlantDestroyed(rpl.Id()))
		{
			Print(string.Format("[JobHarvestComponent] Plante RplId=%1 deja detruite, auto-suppression",
				rpl.Id()), LogLevel.NORMAL);
			SCR_EntityHelper.DeleteEntityAndChildren(owner);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	EDrugType GetDrugType()
	{
		return m_DrugType;
	}
}
