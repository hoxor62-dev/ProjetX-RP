//------------------------------------------------------------------------------------------------
// JobNPCComponent.c
// Composant a coller sur les PNJ via Workbench.
// Le boss configure le type de PNJ dans l'inspecteur:
//  - INTERIM_RECRUITER: propose Mineur/Uber/Cuisinier/Chomeur
//  - ADVANCED_RECRUITER: propose Medecin/Policier/Concessionnaire/Militaire (PNJ cache)
//  - JOB_SPECIFIC: PNJ de metier (ex: PNJ Mineur, PNJ Policier...) avec son EJobType
//------------------------------------------------------------------------------------------------

enum ENPCType
{
	INTERIM_RECRUITER = 0,   // PNJ Job Interim (recrute pour metiers interim + chomeur)
	ADVANCED_RECRUITER = 1,  // PNJ cache pour metiers avances (admin only)
	JOB_SPECIFIC = 2         // PNJ specialise (Mineur, Policier...) qui propose quetes/equipement
}

[ComponentEditorProps(category: "LesPacifistesJobs", description: "PNJ metier - interactif")]
class JobNPCComponentClass : ScriptComponentClass
{
}

//------------------------------------------------------------------------------------------------
class JobNPCComponent : ScriptComponent
{
	[Attribute("0", UIWidgets.ComboBox, "Type de PNJ", "", ParamEnumArray.FromEnum(ENPCType))]
	ENPCType m_NPCType;
	
	[Attribute("0", UIWidgets.ComboBox, "Metier du PNJ (si JOB_SPECIFIC)", "", ParamEnumArray.FromEnum(EJobType))]
	EJobType m_JobType;
	
	[Attribute("PNJ Emploi", UIWidgets.EditBox, "Nom affiche sur l'action")]
	string m_DisplayName;
	
	//------------------------------------------------------------------------------------------------
	ENPCType GetNPCType()
	{
		return m_NPCType;
	}
	
	//------------------------------------------------------------------------------------------------
	EJobType GetJobType()
	{
		return m_JobType;
	}
	
	//------------------------------------------------------------------------------------------------
	string GetDisplayName()
	{
		return m_DisplayName;
	}
	
	//------------------------------------------------------------------------------------------------
	// Indique si le joueur peut interagir avec ce PNJ etant donne son metier actuel
	//------------------------------------------------------------------------------------------------
	bool CanInteract(EJobType playerJob)
	{
		switch (m_NPCType)
		{
			case ENPCType.INTERIM_RECRUITER:
				// Tout le monde peut parler au recruteur interim
				return true;
			
			case ENPCType.ADVANCED_RECRUITER:
				// Tout le monde peut parler au recruteur avance (PNJ cache, acces admin)
				return true;
			
			case ENPCType.JOB_SPECIFIC:
				// Seul le joueur ayant CE metier peut parler a CE PNJ de metier
				return (playerJob == m_JobType);
		}
		return false;
	}
	
	//------------------------------------------------------------------------------------------------
	// Texte affiche sur l'action F selon le type et le metier du joueur
	//------------------------------------------------------------------------------------------------
	string GetActionLabel(EJobType playerJob)
	{
		switch (m_NPCType)
		{
			case ENPCType.INTERIM_RECRUITER:
				return "Parler au recruteur emploi";
			
			case ENPCType.ADVANCED_RECRUITER:
				return "Parler au recruteur [Prive]";
			
			case ENPCType.JOB_SPECIFIC:
				if (playerJob == m_JobType)
					return string.Format("Parler au PNJ %1", JobData.GetJobLabel(m_JobType));
				else
					return string.Format("[Reserve: %1]", JobData.GetJobLabel(m_JobType));
		}
		return "Interagir";
	}
}
