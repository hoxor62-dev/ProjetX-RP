//------------------------------------------------------------------------------------------------
// JobCompanyPaySalaryMenu.c
// Menu de paiement de salaire ponctuel a UN employe specifique.
// Pre-charge : UID + nom d affichage de l employe cible.
// Patron tape un montant, clique Confirmer -> RPC ClientAskPaySalary(uid, amount).
//------------------------------------------------------------------------------------------------

class JobCompanyPaySalaryMenu : ChimeraMenuBase
{
	Widget m_RootWidget;
	TextWidget m_TitleText;
	TextWidget m_InfoText;
	EditBoxWidget m_AmountInput;
	ButtonWidget m_BtnConfirm;
	ButtonWidget m_BtnCancel;
	
	static string s_TargetUID;
	static string s_TargetName;
	
	static JobCompanyPaySalaryMenu s_Instance;
	
	//------------------------------------------------------------------------------------------------
	static void SetPendingData(string uid, string name)
	{
		s_TargetUID = uid;
		s_TargetName = name;
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuOpen()
	{
		super.OnMenuOpen();
		s_Instance = this;
		JobFocusHandler.ClearRegistry();
		
		m_RootWidget = GetRootWidget();
		if (!m_RootWidget) return;
		
		m_TitleText = TextWidget.Cast(m_RootWidget.FindAnyWidget("TitleText"));
		m_InfoText = TextWidget.Cast(m_RootWidget.FindAnyWidget("InfoText"));
		m_AmountInput = EditBoxWidget.Cast(m_RootWidget.FindAnyWidget("AmountInput"));
		m_BtnConfirm = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnConfirm"));
		m_BtnCancel = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnCancel"));
		
		if (m_TitleText)
			m_TitleText.SetText("Payer un salaire");
		if (m_InfoText)
			m_InfoText.SetText(string.Format("Employe : %1\nMontant a verser depuis la cagnotte de l entreprise :", s_TargetName));
		
		if (m_BtnConfirm)
		{
			PaySalaryConfirmHandler ch = new PaySalaryConfirmHandler();
			ch.m_Menu = this;
			m_BtnConfirm.AddHandler(ch);
			JobFocusHandler.Attach(m_BtnConfirm);
		}
		if (m_BtnCancel)
		{
			PaySalaryCancelHandler ch = new PaySalaryCancelHandler();
			ch.m_Menu = this;
			m_BtnCancel.AddHandler(ch);
			JobFocusHandler.Attach(m_BtnCancel);
			GetGame().GetWorkspace().SetFocusedWidget(m_BtnCancel);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuClose()
	{
		if (s_Instance == this)
			s_Instance = null;
		super.OnMenuClose();
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuUpdate(float tDelta)
	{
		super.OnMenuUpdate(tDelta);
		if (GetGame().GetInputManager().GetActionValue("MenuBack") > 0.5)
			CloseMenuInternal();
	}
	
	//------------------------------------------------------------------------------------------------
	void OnConfirmClicked()
	{
		if (!m_AmountInput) return;
		int amount = m_AmountInput.GetText().ToInt();
		if (amount <= 0)
		{
			if (m_InfoText)
				m_InfoText.SetText("Veuillez entrer un montant valide (> 0).");
			return;
		}
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		jpc.ClientAskPaySalary(s_TargetUID, amount);
		CloseMenuInternal();
	}
	
	void CloseMenuInternal()
	{
		GetGame().GetMenuManager().CloseMenu(this);
	}
	
	static JobCompanyPaySalaryMenu GetOpenMenu() { return s_Instance; }
}

//------------------------------------------------------------------------------------------------
class PaySalaryConfirmHandler : ScriptedWidgetEventHandler
{
	JobCompanyPaySalaryMenu m_Menu;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.OnConfirmClicked();
		return true;
	}
}

//------------------------------------------------------------------------------------------------
class PaySalaryCancelHandler : ScriptedWidgetEventHandler
{
	JobCompanyPaySalaryMenu m_Menu;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.CloseMenuInternal();
		return true;
	}
}
