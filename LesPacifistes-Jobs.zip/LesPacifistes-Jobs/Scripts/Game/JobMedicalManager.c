//------------------------------------------------------------------------------------------------
// JobMedicalManager.c
//
// Singleton serveur qui gere les dossiers medicaux des joueurs.
// Persistance : 1 fichier JSON par patient.
//   - Repertoire : $profile:LesPacifistesJobs/medical/
//   - Fichier index : medical_index.json (n dossier auto-genere)
//   - Fichier patient : patient_<UID>.json
//
// N dossier auto-genere sous forme "P-XXXX" (compteur incremental).
//
// L access est restreint aux medecins (check IsCallerMedecin cote serveur dans les RPCs
// de JobPlayerComponent).
//------------------------------------------------------------------------------------------------

class JobMedicalManager
{
	static ref JobMedicalManager s_Instance;
	
	const string INDEX_PATH = "$profile:LesPacifistesJobs/medical_index.json";
	const string PATIENT_PATH_PREFIX = "$profile:LesPacifistesJobs/medical_patient_";
	
	// Cache en RAM : UID -> record charge
	ref map<string, ref MedicalRecord> m_LoadedRecords;
	
	// Index leger : UID -> N dossier + Nom (utilise pour la recherche sans tout charger)
	ref map<string, string> m_IndexFileNumbers;
	ref map<string, string> m_IndexNames;
	ref array<string> m_IndexOrder;   // ordre d insertion des UIDs
	int m_NextFileNumberCounter;      // compteur pour generer P-XXXX
	
	//------------------------------------------------------------------------------------------------
	void JobMedicalManager()
	{
		m_LoadedRecords = new map<string, ref MedicalRecord>();
		m_IndexFileNumbers = new map<string, string>();
		m_IndexNames = new map<string, string>();
		m_IndexOrder = new array<string>();
		m_NextFileNumberCounter = 1;
	}
	
	//------------------------------------------------------------------------------------------------
	static JobMedicalManager GetInstance()
	{
		if (!s_Instance)
		{
			s_Instance = new JobMedicalManager();
			s_Instance.LoadIndexFromDisk();
		}
		return s_Instance;
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== ACCES DOSSIERS =====
	//------------------------------------------------------------------------------------------------
	
	MedicalRecord GetOrCreateRecord(string uid, string patientName, string authorName, string authorUID)
	{
		if (uid == "")
			return null;
		
		// Cache
		MedicalRecord rec = m_LoadedRecords.Get(uid);
		if (rec)
		{
			if (patientName != "" && patientName != rec.m_PatientName)
			{
				rec.m_PatientName = patientName;
				SavePatientToDisk(uid);
			}
			return rec;
		}
		
		// Deja indexe -> charger depuis disque
		if (m_IndexFileNumbers.Contains(uid))
		{
			rec = LoadPatientFromDisk(uid);
			if (rec)
			{
				m_LoadedRecords.Set(uid, rec);
				return rec;
			}
		}
		
		// Sinon, creation
		rec = new MedicalRecord();
		rec.m_PatientUID = uid;
		rec.m_PatientName = patientName;
		rec.m_CreationTimestamp = System.GetUnixTime();
		rec.m_FileNumber = GenerateNextFileNumber();
		
		// Ajoute entree de creation au journal
		JournalEntry je = new JournalEntry();
		je.m_Type = EJournalActionType.CREATION;
		je.m_Timestamp = rec.m_CreationTimestamp;
		je.m_Description = string.Format("Dossier medical %1 cree", rec.m_FileNumber);
		je.m_AuthorName = authorName;
		je.m_AuthorUID = authorUID;
		rec.m_Journal.Insert(je);
		
		m_LoadedRecords.Set(uid, rec);
		m_IndexFileNumbers.Set(uid, rec.m_FileNumber);
		m_IndexNames.Set(uid, rec.m_PatientName);
		m_IndexOrder.Insert(uid);
		
		SavePatientToDisk(uid);
		SaveIndexToDisk();
		
		Print(string.Format("[JobMedicalManager] Nouveau dossier %1 cree pour %2",
			rec.m_FileNumber, patientName), LogLevel.NORMAL);
		return rec;
	}
	
	//------------------------------------------------------------------------------------------------
	// Recupere un record sans le creer si absent (retourne null)
	//------------------------------------------------------------------------------------------------
	MedicalRecord GetRecord(string uid)
	{
		if (uid == "")
			return null;
		MedicalRecord rec = m_LoadedRecords.Get(uid);
		if (rec)
			return rec;
		if (m_IndexFileNumbers.Contains(uid))
		{
			rec = LoadPatientFromDisk(uid);
			if (rec)
				m_LoadedRecords.Set(uid, rec);
			return rec;
		}
		return null;
	}
	
	//------------------------------------------------------------------------------------------------
	// Generation du prochain N dossier auto (P-0001, P-0002, ...)
	//------------------------------------------------------------------------------------------------
	string GenerateNextFileNumber()
	{
		string num = m_NextFileNumberCounter.ToString();
		// Zero-pad a 4 chiffres
		while (num.Length() < 4)
			num = "0" + num;
		m_NextFileNumberCounter = m_NextFileNumberCounter + 1;
		return "P-" + num;
	}
	
	//------------------------------------------------------------------------------------------------
	// Recherche par nom RP ou UID ou N dossier
	//------------------------------------------------------------------------------------------------
	void SearchRecords(string query, int maxResults, out array<string> outUIDs, out array<string> outNames, out array<string> outFileNumbers)
	{
		string queryLower = query;
		queryLower.ToLower();
		int total = m_IndexOrder.Count();
		for (int i = 0; i < total && outUIDs.Count() < maxResults; i++)
		{
			string uid = m_IndexOrder.Get(i);
			string name = m_IndexNames.Get(uid);
			string fileNum = m_IndexFileNumbers.Get(uid);
			
			string nameLower = name;
			nameLower.ToLower();
			
			bool matches = (query == "")
				|| nameLower.Contains(queryLower)
				|| uid.Contains(query)
				|| fileNum.Contains(query);
			if (!matches)
				continue;
			
			outUIDs.Insert(uid);
			outNames.Insert(name);
			outFileNumbers.Insert(fileNum);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== JOURNAL =====
	// Log automatique d une action - a appeler depuis toutes les methodes de modification
	//------------------------------------------------------------------------------------------------
	void LogAction(string uid, EJournalActionType actionType, string description,
		string authorName, string authorUID)
	{
		MedicalRecord rec = GetRecord(uid);
		if (!rec)
			return;
		JournalEntry je = new JournalEntry();
		je.m_Type = actionType;
		je.m_Timestamp = System.GetUnixTime();
		je.m_Description = description;
		je.m_AuthorName = authorName;
		je.m_AuthorUID = authorUID;
		rec.m_Journal.Insert(je);
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== IDENTITE (modification) =====
	//------------------------------------------------------------------------------------------------
	void SetIdentity(string uid, string dateOfBirth, int sexVal, int bloodTypeVal,
		string authorName, string authorUID)
	{
		MedicalRecord rec = GetRecord(uid);
		if (!rec)
			return;
		rec.m_DateOfBirth = dateOfBirth;
		rec.m_Sex = sexVal;
		rec.m_BloodType = bloodTypeVal;
		LogAction(uid, EJournalActionType.MODIFICATION,
			string.Format("Identite modifiee (DDN: %1, Sexe: %2, Groupe: %3)",
				dateOfBirth, JobPatientSexHelper.GetLabel(sexVal), JobBloodTypeHelper.GetLabel(bloodTypeVal)),
			authorName, authorUID);
		SavePatientToDisk(uid);
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== INFOS MEDICALES (allergies / maladies / traitements) =====
	//------------------------------------------------------------------------------------------------
	void SetMedicalInfo(string uid, string allergies, string diseases, string treatments,
		string authorName, string authorUID)
	{
		MedicalRecord rec = GetRecord(uid);
		if (!rec)
			return;
		rec.m_Allergies = allergies;
		rec.m_KnownDiseases = diseases;
		rec.m_CurrentTreatments = treatments;
		LogAction(uid, EJournalActionType.MODIFICATION,
			"Informations medicales mises a jour",
			authorName, authorUID);
		SavePatientToDisk(uid);
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== ETAT DE SANTE =====
	//------------------------------------------------------------------------------------------------
	
	// Synchro auto depuis SurvivalHUD (Vie et Sang uniquement)
	void SyncHealthFromSurvival(string uid, int lifePercent, int bloodPercent,
		string authorName, string authorUID)
	{
		MedicalRecord rec = GetRecord(uid);
		if (!rec || !rec.m_Health)
			return;
		rec.m_Health.m_LifePercent = lifePercent;
		rec.m_Health.m_BloodPercent = bloodPercent;
		rec.m_Health.m_LastSyncTimestamp = System.GetUnixTime();
		LogAction(uid, EJournalActionType.SYNC,
			string.Format("Sync sante : Vie=%1%%, Sang=%2%%",
				lifePercent.ToString(), bloodPercent.ToString()),
			authorName, authorUID);
		SavePatientToDisk(uid);
	}
	
	// Set manuel des mesures medicales
	void SetHealthManual(string uid, int fractures, int hemorrhages, int painLevel,
		float temperature, int pulse, string bloodPressure, int oxygen,
		string authorName, string authorUID)
	{
		MedicalRecord rec = GetRecord(uid);
		if (!rec || !rec.m_Health)
			return;
		rec.m_Health.m_Fractures = fractures;
		rec.m_Health.m_Hemorrhages = hemorrhages;
		rec.m_Health.m_PainLevel = painLevel;
		rec.m_Health.m_Temperature = temperature;
		rec.m_Health.m_Pulse = pulse;
		rec.m_Health.m_BloodPressure = bloodPressure;
		rec.m_Health.m_OxygenSaturation = oxygen;
		LogAction(uid, EJournalActionType.MODIFICATION,
			string.Format("Constantes : Fract=%1, Hemor=%2, Pain=%3, T=%4, Pouls=%5, Tens=%6, SpO2=%7",
				fractures.ToString(), hemorrhages.ToString(), painLevel.ToString(),
				temperature.ToString(), pulse.ToString(), bloodPressure, oxygen.ToString()),
			authorName, authorUID);
		SavePatientToDisk(uid);
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== SOINS =====
	//------------------------------------------------------------------------------------------------
	int AddSoin(string uid, string motif, string diagnostic, string soinsRealises,
		string medicaments, string authorName, string authorUID)
	{
		MedicalRecord rec = GetRecord(uid);
		if (!rec)
			return -1;
		
		SoinRecord s = new SoinRecord();
		s.m_Timestamp = System.GetUnixTime();
		s.m_MedecinName = authorName;
		s.m_MedecinUID = authorUID;
		s.m_Motif = motif;
		s.m_Diagnostic = diagnostic;
		s.m_SoinsRealises = soinsRealises;
		s.m_Medicaments = medicaments;
		s.m_Cout = 0;
		rec.m_Soins.Insert(s);
		
		// Log automatique
		LogAction(uid, EJournalActionType.PRESCRIPTION,
			string.Format("Soin ajoute : %1", motif),
			authorName, authorUID);
		
		SavePatientToDisk(uid);
		return rec.m_Soins.Count() - 1;
	}
	
	bool RemoveSoin(string uid, int index, string authorName, string authorUID)
	{
		MedicalRecord rec = GetRecord(uid);
		if (!rec || index < 0 || index >= rec.m_Soins.Count())
			return false;
		rec.m_Soins.Remove(index);
		LogAction(uid, EJournalActionType.MODIFICATION,
			string.Format("Soin #%1 supprime", index.ToString()),
			authorName, authorUID);
		SavePatientToDisk(uid);
		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== HOSPITALISATIONS =====
	//------------------------------------------------------------------------------------------------
	int AddHospitalization(string uid, string chambre, string compteRendu,
		string authorName, string authorUID)
	{
		MedicalRecord rec = GetRecord(uid);
		if (!rec)
			return -1;
		
		HospitalizationRecord h = new HospitalizationRecord();
		h.m_Chambre = chambre;
		h.m_EntryTimestamp = System.GetUnixTime();
		h.m_ExitTimestamp = 0;
		h.m_MedecinName = authorName;
		h.m_MedecinUID = authorUID;
		h.m_CompteRendu = compteRendu;
		h.m_Active = true;
		rec.m_Hospitalizations.Insert(h);
		
		LogAction(uid, EJournalActionType.HOSPITALIZATION,
			string.Format("Hospitalisation en chambre %1", chambre),
			authorName, authorUID);
		SavePatientToDisk(uid);
		return rec.m_Hospitalizations.Count() - 1;
	}
	
	// Termine une hospitalisation (sortie) + ordonnance eventuelle
	bool CloseHospitalization(string uid, int index, string ordonnance,
		string authorName, string authorUID)
	{
		MedicalRecord rec = GetRecord(uid);
		if (!rec || index < 0 || index >= rec.m_Hospitalizations.Count())
			return false;
		HospitalizationRecord h = rec.m_Hospitalizations.Get(index);
		if (!h)
			return false;
		h.m_ExitTimestamp = System.GetUnixTime();
		h.m_Active = false;
		h.m_Ordonnance = ordonnance;
		
		LogAction(uid, EJournalActionType.EXIT_HOSPITAL,
			string.Format("Sortie hospitalisation chambre %1", h.m_Chambre),
			authorName, authorUID);
		SavePatientToDisk(uid);
		return true;
	}
	
	bool RemoveHospitalization(string uid, int index, string authorName, string authorUID)
	{
		MedicalRecord rec = GetRecord(uid);
		if (!rec || index < 0 || index >= rec.m_Hospitalizations.Count())
			return false;
		rec.m_Hospitalizations.Remove(index);
		LogAction(uid, EJournalActionType.MODIFICATION,
			string.Format("Hospitalisation #%1 supprimee", index.ToString()),
			authorName, authorUID);
		SavePatientToDisk(uid);
		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== PERSISTANCE JSON =====
	//------------------------------------------------------------------------------------------------
	
	// Index leger (uid, name, filenumber, counter) partage entre tous les patients
	void SaveIndexToDisk()
	{
		SCR_JsonSaveContext ctx = new SCR_JsonSaveContext();
		int cnt = m_IndexOrder.Count();
		ctx.WriteValue("counter", m_NextFileNumberCounter);
		ctx.WriteValue("count", cnt);
		for (int i = 0; i < cnt; i++)
		{
			string uid = m_IndexOrder.Get(i);
			string prefix = "e_" + i.ToString() + "_";
			ctx.WriteValue(prefix + "uid", uid);
			ctx.WriteValue(prefix + "name", m_IndexNames.Get(uid));
			ctx.WriteValue(prefix + "fnum", m_IndexFileNumbers.Get(uid));
		}
		ctx.SaveToFile(INDEX_PATH);
	}
	
	void LoadIndexFromDisk()
	{
		SCR_JsonLoadContext ctx = new SCR_JsonLoadContext();
		if (!ctx.LoadFromFile(INDEX_PATH))
		{
			Print("[JobMedicalManager] Aucun index existant, demarrage propre",
				LogLevel.NORMAL);
			return;
		}
		ctx.ReadValue("counter", m_NextFileNumberCounter);
		if (m_NextFileNumberCounter <= 0)
			m_NextFileNumberCounter = 1;
		int cnt = 0;
		ctx.ReadValue("count", cnt);
		for (int i = 0; i < cnt; i++)
		{
			string prefix = "e_" + i.ToString() + "_";
			string uid; string name; string fnum;
			ctx.ReadValue(prefix + "uid", uid);
			ctx.ReadValue(prefix + "name", name);
			ctx.ReadValue(prefix + "fnum", fnum);
			if (uid != "")
			{
				m_IndexOrder.Insert(uid);
				m_IndexNames.Set(uid, name);
				m_IndexFileNumbers.Set(uid, fnum);
			}
		}
		Print(string.Format("[JobMedicalManager] Index charge : %1 dossiers, prochain n=%2",
			cnt.ToString(), m_NextFileNumberCounter.ToString()), LogLevel.NORMAL);
	}
	
	// Fichier patient dedie
	string GetPatientPath(string uid)
	{
		return PATIENT_PATH_PREFIX + uid + ".json";
	}
	
	void SavePatientToDisk(string uid)
	{
		MedicalRecord rec = m_LoadedRecords.Get(uid);
		if (!rec)
			return;
		SCR_JsonSaveContext ctx = new SCR_JsonSaveContext();
		
		// Identite
		ctx.WriteValue("uid", rec.m_PatientUID);
		ctx.WriteValue("name", rec.m_PatientName);
		ctx.WriteValue("dob", rec.m_DateOfBirth);
		ctx.WriteValue("sex", rec.m_Sex);
		ctx.WriteValue("fnum", rec.m_FileNumber);
		ctx.WriteValue("blood", rec.m_BloodType);
		ctx.WriteValue("created", rec.m_CreationTimestamp);
		
		// Sante
		if (rec.m_Health)
		{
			ctx.WriteValue("h_life", rec.m_Health.m_LifePercent);
			ctx.WriteValue("h_blood", rec.m_Health.m_BloodPercent);
			ctx.WriteValue("h_sync", rec.m_Health.m_LastSyncTimestamp);
			ctx.WriteValue("h_fract", rec.m_Health.m_Fractures);
			ctx.WriteValue("h_hemor", rec.m_Health.m_Hemorrhages);
			ctx.WriteValue("h_pain", rec.m_Health.m_PainLevel);
			ctx.WriteValue("h_temp", rec.m_Health.m_Temperature);
			ctx.WriteValue("h_pulse", rec.m_Health.m_Pulse);
			ctx.WriteValue("h_press", rec.m_Health.m_BloodPressure);
			ctx.WriteValue("h_o2", rec.m_Health.m_OxygenSaturation);
		}
		
		// Infos medicales
		ctx.WriteValue("allergies", rec.m_Allergies);
		ctx.WriteValue("diseases", rec.m_KnownDiseases);
		ctx.WriteValue("treatments", rec.m_CurrentTreatments);
		
		// Soins
		int sCnt = rec.m_Soins.Count();
		ctx.WriteValue("soin_count", sCnt);
		for (int i = 0; i < sCnt; i++)
		{
			SoinRecord s = rec.m_Soins.Get(i);
			if (!s) continue;
			string sp = "s_" + i.ToString() + "_";
			ctx.WriteValue(sp + "ts", s.m_Timestamp);
			ctx.WriteValue(sp + "med_name", s.m_MedecinName);
			ctx.WriteValue(sp + "med_uid", s.m_MedecinUID);
			ctx.WriteValue(sp + "motif", s.m_Motif);
			ctx.WriteValue(sp + "diag", s.m_Diagnostic);
			ctx.WriteValue(sp + "soins", s.m_SoinsRealises);
			ctx.WriteValue(sp + "meds", s.m_Medicaments);
			ctx.WriteValue(sp + "cout", s.m_Cout);
		}
		
		// Hospitalisations
		int hCnt = rec.m_Hospitalizations.Count();
		ctx.WriteValue("hosp_count", hCnt);
		for (int i = 0; i < hCnt; i++)
		{
			HospitalizationRecord h = rec.m_Hospitalizations.Get(i);
			if (!h) continue;
			string hp = "h_" + i.ToString() + "_";
			ctx.WriteValue(hp + "chambre", h.m_Chambre);
			ctx.WriteValue(hp + "entry", h.m_EntryTimestamp);
			ctx.WriteValue(hp + "exit", h.m_ExitTimestamp);
			ctx.WriteValue(hp + "med_name", h.m_MedecinName);
			ctx.WriteValue(hp + "med_uid", h.m_MedecinUID);
			ctx.WriteValue(hp + "cr", h.m_CompteRendu);
			ctx.WriteValue(hp + "ordo", h.m_Ordonnance);
			ctx.WriteValue(hp + "active", h.m_Active);
		}
		
		// Journal
		int jCnt = rec.m_Journal.Count();
		ctx.WriteValue("journal_count", jCnt);
		for (int i = 0; i < jCnt; i++)
		{
			JournalEntry j = rec.m_Journal.Get(i);
			if (!j) continue;
			string jp = "j_" + i.ToString() + "_";
			ctx.WriteValue(jp + "type", j.m_Type);
			ctx.WriteValue(jp + "ts", j.m_Timestamp);
			ctx.WriteValue(jp + "desc", j.m_Description);
			ctx.WriteValue(jp + "author_name", j.m_AuthorName);
			ctx.WriteValue(jp + "author_uid", j.m_AuthorUID);
		}
		
		ctx.SaveToFile(GetPatientPath(uid));
	}
	
	MedicalRecord LoadPatientFromDisk(string uid)
	{
		SCR_JsonLoadContext ctx = new SCR_JsonLoadContext();
		if (!ctx.LoadFromFile(GetPatientPath(uid)))
			return null;
		
		MedicalRecord rec = new MedicalRecord();
		ctx.ReadValue("uid", rec.m_PatientUID);
		ctx.ReadValue("name", rec.m_PatientName);
		ctx.ReadValue("dob", rec.m_DateOfBirth);
		int sexVal = 0;
		ctx.ReadValue("sex", sexVal);
		rec.m_Sex = sexVal;
		ctx.ReadValue("fnum", rec.m_FileNumber);
		int bloodVal = 0;
		ctx.ReadValue("blood", bloodVal);
		rec.m_BloodType = bloodVal;
		ctx.ReadValue("created", rec.m_CreationTimestamp);
		
		// Sante
		if (rec.m_Health)
		{
			ctx.ReadValue("h_life", rec.m_Health.m_LifePercent);
			ctx.ReadValue("h_blood", rec.m_Health.m_BloodPercent);
			ctx.ReadValue("h_sync", rec.m_Health.m_LastSyncTimestamp);
			ctx.ReadValue("h_fract", rec.m_Health.m_Fractures);
			ctx.ReadValue("h_hemor", rec.m_Health.m_Hemorrhages);
			ctx.ReadValue("h_pain", rec.m_Health.m_PainLevel);
			ctx.ReadValue("h_temp", rec.m_Health.m_Temperature);
			ctx.ReadValue("h_pulse", rec.m_Health.m_Pulse);
			ctx.ReadValue("h_press", rec.m_Health.m_BloodPressure);
			ctx.ReadValue("h_o2", rec.m_Health.m_OxygenSaturation);
		}
		
		ctx.ReadValue("allergies", rec.m_Allergies);
		ctx.ReadValue("diseases", rec.m_KnownDiseases);
		ctx.ReadValue("treatments", rec.m_CurrentTreatments);
		
		int sCnt = 0;
		ctx.ReadValue("soin_count", sCnt);
		for (int i = 0; i < sCnt; i++)
		{
			SoinRecord s = new SoinRecord();
			string sp = "s_" + i.ToString() + "_";
			ctx.ReadValue(sp + "ts", s.m_Timestamp);
			ctx.ReadValue(sp + "med_name", s.m_MedecinName);
			ctx.ReadValue(sp + "med_uid", s.m_MedecinUID);
			ctx.ReadValue(sp + "motif", s.m_Motif);
			ctx.ReadValue(sp + "diag", s.m_Diagnostic);
			ctx.ReadValue(sp + "soins", s.m_SoinsRealises);
			ctx.ReadValue(sp + "meds", s.m_Medicaments);
			ctx.ReadValue(sp + "cout", s.m_Cout);
			rec.m_Soins.Insert(s);
		}
		
		int hCnt = 0;
		ctx.ReadValue("hosp_count", hCnt);
		for (int i = 0; i < hCnt; i++)
		{
			HospitalizationRecord h = new HospitalizationRecord();
			string hp = "h_" + i.ToString() + "_";
			ctx.ReadValue(hp + "chambre", h.m_Chambre);
			ctx.ReadValue(hp + "entry", h.m_EntryTimestamp);
			ctx.ReadValue(hp + "exit", h.m_ExitTimestamp);
			ctx.ReadValue(hp + "med_name", h.m_MedecinName);
			ctx.ReadValue(hp + "med_uid", h.m_MedecinUID);
			ctx.ReadValue(hp + "cr", h.m_CompteRendu);
			ctx.ReadValue(hp + "ordo", h.m_Ordonnance);
			ctx.ReadValue(hp + "active", h.m_Active);
			rec.m_Hospitalizations.Insert(h);
		}
		
		int jCnt = 0;
		ctx.ReadValue("journal_count", jCnt);
		for (int i = 0; i < jCnt; i++)
		{
			JournalEntry j = new JournalEntry();
			string jp = "j_" + i.ToString() + "_";
			int typeVal = 0;
			ctx.ReadValue(jp + "type", typeVal);
			j.m_Type = typeVal;
			ctx.ReadValue(jp + "ts", j.m_Timestamp);
			ctx.ReadValue(jp + "desc", j.m_Description);
			ctx.ReadValue(jp + "author_name", j.m_AuthorName);
			ctx.ReadValue(jp + "author_uid", j.m_AuthorUID);
			rec.m_Journal.Insert(j);
		}
		
		return rec;
	}
}
