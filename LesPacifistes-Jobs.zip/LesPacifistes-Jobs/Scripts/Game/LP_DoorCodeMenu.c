//------------------------------------------------------------------------------------------------
// LP_DoorCodeMenu.c
// Menu proprio : voir/definir/changer/retirer le code 4 chiffres.
//------------------------------------------------------------------------------------------------

class LP_DoorCodeMenu : ChimeraMenuBase
{
	Widget m_Root;
	TextWidget m_CurrentCodeText;
	EditBoxWidget m_CodeInput;
	TextWidget m_StatusText;
	ButtonWidget m_BtnApply;
	ButtonWidget m_BtnRemove;
	ButtonWidget m_BtnClose;
	
	RplId m_DoorRplId = RplId.Invalid();
	
	static LP_DoorCodeMenu s_Instance;
	
	static RplId s_PendingRplId = RplId.Invalid();
	static void SetPendingTarget(RplId rplId) { s_PendingRplId = rplId; }
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuOpen()
	{
		super.OnMenuOpen();
		s_Instance = this;
		JobFocusHandler.ClearRegistry();
		
		if (s_PendingRplId.IsValid())
		{
			m_DoorRplId = s_PendingRplId;
			s_PendingRplId = RplId.Invalid();
		}
		
		m_Root = GetRootWidget();
		if (!m_Root) return;
		
		m_CurrentCodeText = TextWidget.Cast(m_Root.FindAnyWidget("CurrentCodeText"));
		m_CodeInput = EditBoxWidget.Cast(m_Root.FindAnyWidget("CodeInput"));
		m_StatusText = TextWidget.Cast(m_Root.FindAnyWidget("StatusText"));
		m_BtnApply = ButtonWidget.Cast(m_Root.FindAnyWidget("BtnApply"));
		m_BtnRemove = ButtonWidget.Cast(m_Root.FindAnyWidget("BtnRemove"));
		m_BtnClose = ButtonWidget.Cast(m_Root.FindAnyWidget("BtnClose"));
		
		AttachBtn(m_BtnApply, "apply");
		AttachBtn(m_BtnRemove, "remove");
		AttachBtn(m_BtnClose, "close");
		
		PlayerController pc = GetGame().GetPlayerController();
		if (pc)
		{
			JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
			if (jpc) jpc.ClientAskLpDoorCodeInfo(m_DoorRplId);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuClose()
	{
		if (s_Instance == this) s_Instance = null;
		super.OnMenuClose();
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuUpdate(float tDelta)
	{
		super.OnMenuUpdate(tDelta);
		if (GetGame().GetInputManager().GetActionValue("MenuBack") > 0.5)
			CloseMenuInternal();
	}
	
	//------------------------------------------------------------------------------------------------
	void AttachBtn(ButtonWidget btn, string action)
	{
		if (!btn) return;
		LP_DoorCodeBtnHandler h = new LP_DoorCodeBtnHandler();
		h.m_Menu = this;
		h.m_Action = action;
		btn.AddHandler(h);
		JobFocusHandler.Attach(btn);
	}
	
	//------------------------------------------------------------------------------------------------
	void DisplayCurrentCode(string code)
	{
		if (m_CurrentCodeText)
		{
			if (code == "")
				m_CurrentCodeText.SetText("Code actuel : aucun");
			else
				m_CurrentCodeText.SetText(string.Format("Code actuel : %1", code));
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void ShowStatus(string msg) { if (m_StatusText) m_StatusText.SetText(msg); }
	
	//------------------------------------------------------------------------------------------------
	void OnButtonClicked(string action)
	{
		if (action == "close") { CloseMenuInternal(); return; }
		
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		
		if (action == "remove")
		{
			jpc.ClientAskSetLpDoorCode(m_DoorRplId, "");
			ShowStatus("Code retire.");
			GetGame().GetCallqueue().CallLater(RefreshInfo, 300, false);
			return;
		}
		if (action == "apply")
		{
			string code = "";
			if (m_CodeInput) code = m_CodeInput.GetText();
			if (code.Length() != 4)
			{
				ShowStatus("Le code doit contenir 4 chiffres.");
				return;
			}
			if (!IsAllDigits(code))
			{
				ShowStatus("Le code doit etre numerique.");
				return;
			}
			jpc.ClientAskSetLpDoorCode(m_DoorRplId, code);
			ShowStatus("Code applique !");
			GetGame().GetCallqueue().CallLater(RefreshInfo, 300, false);
			return;
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void RefreshInfo()
	{
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (jpc) jpc.ClientAskLpDoorCodeInfo(m_DoorRplId);
	}
	
	//------------------------------------------------------------------------------------------------
	bool IsAllDigits(string s)
	{
		for (int i = 0; i < s.Length(); i++)
		{
			string ch = s.Substring(i, 1);
			if (ch != "0" && ch != "1" && ch != "2" && ch != "3" && ch != "4"
			 && ch != "5" && ch != "6" && ch != "7" && ch != "8" && ch != "9")
				return false;
		}
		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	void CloseMenuInternal() { GetGame().GetMenuManager().CloseMenu(this); }
	static LP_DoorCodeMenu GetOpenMenu() { return s_Instance; }
}

class LP_DoorCodeBtnHandler : ScriptedWidgetEventHandler
{
	LP_DoorCodeMenu m_Menu;
	string m_Action;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.OnButtonClicked(m_Action);
		return true;
	}
}
