//------------------------------------------------------------------------------------------------
// LP_FishingManager.c
// Singleton SERVEUR qui gere les sessions de peche actives.
//
// FONCTIONNEMENT :
//   - StartSession(playerId, playerEnt) : demarre une session de peche 5 minutes
//   - Timer 500ms verifie chaque session :
//     * Duree ecoulee ? -> EndSession
//     * Joueur bouge trop (>3m depuis la position de depart) ? -> EndSession
//     * Poisson en attente de ferrage ? Timeout 3s -> reset (rate)
//     * Sinon : timer aleatoire 1-30s avant prochain poisson qui mord
//   - Quand un poisson mord : notif client + ouvre fenetre 3s de ferrage
//   - Ferrage reussi : 70% chance succes -> spawn poisson1 ou poisson2 (50/50) dans inventaire
//     ET consomme 1 asticot ; si plus d asticot -> EndSession
//   - Ferrage rate ou expire : reset timer prochain poisson, PAS de conso asticot
//------------------------------------------------------------------------------------------------

class LP_FishingSession
{
	int m_PlayerId;
	IEntity m_PlayerEnt;
	vector m_StartPos;
	int m_StartTimeUnix;
	int m_NextBiteAtUnix;    // timestamp du prochain poisson qui mord
	int m_BitingSinceUnix;   // != 0 quand un poisson mord (fenetre 3s)
	int m_FishCaught;
}

class LP_FishingManager
{
	static ref LP_FishingManager s_Instance;
	
	// Prefabs
	static string CANNE_PREFAB    = "{FDA3BBA905DF892C}Prefabs/Items/Equipment/Accessories/ETool_ALICE/canneapeche1.et";
	static string CANNE2_PREFAB   = "{0BD39A4AC4DB73B8}Prefabs/Items/Equipment/Accessories/ETool_ALICE/canneapeche2.et";
	static string ASTICOT_PREFAB  = "{BF6465CFC1FBEDC4}Prefabs/Weapons/Grenades/asticot.et";
	static string POISSON1_PREFAB = "{6C9D10B121D0B61E}Prefabs/Weapons/Grenades/poisson1.et";
	static string POISSON2_PREFAB = "{00C924519D143930}Prefabs/Weapons/Grenades/poisson2.et";
	
	// Duree session peche : 5 minutes
	const int SESSION_DURATION_S = 300;
	// Cooldown entre 2 sessions par joueur : 10 minutes
	const int COOLDOWN_S = 600;
	// Distance max joueur / position depart (metres)
	const float MAX_DISTANCE = 3.0;
	// Fenetre pour ferrer un poisson (3s)
	const int BITE_WINDOW_S = 1;
	// Cooldown min/max entre les poissons qui mordent (secondes)
	const int MIN_COOLDOWN_S = 1;
	const int MAX_COOLDOWN_S = 30;
	// Chance de succes ferrage (0-100)
	const int HOOK_SUCCESS_CHANCE = 50;
	// Nb max poissons par session (au-dela session ferme meme si asticot dispo)
	const int MAX_FISH_PER_SESSION = 5;
	// Tick verif sessions (ms)
	const int TICK_MS = 500;
	
	ref map<int, ref LP_FishingSession> m_Sessions = new map<int, ref LP_FishingSession>();
	// Cooldown : playerId -> timestamp Unix de la derniere fin de session
	ref map<int, int> m_LastSessionEndUnix = new map<int, int>();
	bool m_TickerStarted = false;
	
	//------------------------------------------------------------------------------------------------
	static LP_FishingManager GetInstance()
	{
		if (!s_Instance)
			s_Instance = new LP_FishingManager();
		return s_Instance;
	}
	
	//------------------------------------------------------------------------------------------------
	protected void EnsureTicker()
	{
		if (m_TickerStarted) return;
		m_TickerStarted = true;
		GetGame().GetCallqueue().CallLater(TickAllSessions, TICK_MS, true);
	}
	
	//------------------------------------------------------------------------------------------------
	// Demarre une session de peche pour le joueur donne. Verifie tous les prerequis.
	// Retourne 0=OK, 1=deja en peche, 2=pas de canne equipee, 3=pas d asticot, 4=erreur inventaire,
	//          5=cooldown 10min actif
	//------------------------------------------------------------------------------------------------
	int StartSession(int playerId, IEntity playerEnt)
	{
		if (!Replication.IsServer()) return 4;
		if (!playerEnt) return 4;
		if (m_Sessions.Contains(playerId)) return 1;
		
		// COOLDOWN 10min : verifie temps ecoule depuis derniere fin de session
		int now = System.GetUnixTime();
		int lastEnd = m_LastSessionEndUnix.Get(playerId);
		if (lastEnd > 0)
		{
			int elapsed = now - lastEnd;
			if (elapsed < COOLDOWN_S) return 5;
		}
		
		// Verifie canne equipee dans les mains
		if (!IsCanneEquipped(playerEnt)) return 2;
		
		// Verifie asticot dans inventaire
		if (CountItemInInventory(playerEnt, ASTICOT_PREFAB) <= 0) return 3;
		
		// Crea la session
		LP_FishingSession session = new LP_FishingSession();
		session.m_PlayerId = playerId;
		session.m_PlayerEnt = playerEnt;
		session.m_StartPos = playerEnt.GetOrigin();
		session.m_StartTimeUnix = now;
		session.m_NextBiteAtUnix = session.m_StartTimeUnix + Math.RandomInt(MIN_COOLDOWN_S, MAX_COOLDOWN_S + 1);
		session.m_BitingSinceUnix = 0;
		session.m_FishCaught = 0;
		m_Sessions.Set(playerId, session);
		
		EnsureTicker();
		
		// Notif client : affiche HUD
		JobPlayerComponent jpc = JobPlayerComponent.Cast(playerEnt.FindComponent(JobPlayerComponent));
		if (jpc)
		{
			jpc.ServerFishingSetState(true, false);
			jpc.ServerFishingSendHudUpdate(SESSION_DURATION_S, 0, false);
		}
		
		Print(string.Format("[LP_Fishing] Session demarree pour joueur %1", playerId.ToString()),
			LogLevel.NORMAL);
		return 0;
	}
	
	//------------------------------------------------------------------------------------------------
	// Retourne les secondes restantes de cooldown pour un joueur (0 si dispo)
	//------------------------------------------------------------------------------------------------
	int GetCooldownRemaining(int playerId)
	{
		int lastEnd = m_LastSessionEndUnix.Get(playerId);
		if (lastEnd <= 0) return 0;
		int elapsed = System.GetUnixTime() - lastEnd;
		int remaining = COOLDOWN_S - elapsed;
		if (remaining < 0) return 0;
		return remaining;
	}
	
	//------------------------------------------------------------------------------------------------
	// Ferrage du joueur : verifie que la session est en biting, roll 70/30
	//------------------------------------------------------------------------------------------------
	void ServerHookAttempt(int playerId)
	{
		if (!Replication.IsServer()) return;
		LP_FishingSession session = m_Sessions.Get(playerId);
		if (!session) return;
		if (session.m_BitingSinceUnix == 0) return; // pas de poisson qui mord
		
		int now = System.GetUnixTime();
		if (now - session.m_BitingSinceUnix > BITE_WINDOW_S) 
		{
			// Trop tard, la fenetre est deja fermee (le tick va le detecter)
			return;
		}
		
		// Reset biting
		session.m_BitingSinceUnix = 0;
		
		int roll = Math.RandomInt(0, 100);
		if (roll < HOOK_SUCCESS_CHANCE)
		{
			// SUCCES : spawn 1 poisson dans inventaire + consomme 1 asticot
			bool consumed = ConsumeAsticot(session.m_PlayerEnt);
			if (!consumed)
			{
				EndSessionInternal(session, "Plus d asticot dans l inventaire.");
				return;
			}
			
			// Choix poisson1/poisson2 (50/50)
			string fishPrefab = POISSON1_PREFAB;
			if (Math.RandomInt(0, 100) < 50) fishPrefab = POISSON2_PREFAB;
			
			SpawnFishInPlayerInventory(session.m_PlayerEnt, fishPrefab);
			session.m_FishCaught = session.m_FishCaught + 1;
			
			JobPlayerComponent jpc = JobPlayerComponent.Cast(
				session.m_PlayerEnt.FindComponent(JobPlayerComponent));
			if (jpc)
			{
				jpc.ServerFishingSetState(true, false);
				jpc.ServerFishingSendHudUpdate(
					SecondsRemaining(session), session.m_FishCaught, false);
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					string.Format("[Peche] Poisson attrape ! (%1)", session.m_FishCaught.ToString()));
			}
			
			// Fin de session si max atteint
			if (session.m_FishCaught >= MAX_FISH_PER_SESSION)
			{
				EndSessionInternal(session, "Vous avez atteint le maximum de poissons.");
				return;
			}
			
			// Prochain poisson qui mord
			session.m_NextBiteAtUnix = now + Math.RandomInt(MIN_COOLDOWN_S, MAX_COOLDOWN_S + 1);
		}
		else
		{
			// ECHEC : pas de conso asticot, reset timer prochain poisson
			session.m_NextBiteAtUnix = now + Math.RandomInt(MIN_COOLDOWN_S, MAX_COOLDOWN_S + 1);
			JobPlayerComponent jpc = JobPlayerComponent.Cast(
				session.m_PlayerEnt.FindComponent(JobPlayerComponent));
			if (jpc)
			{
				jpc.ServerFishingSetState(true, false);
				jpc.ServerFishingSendHudUpdate(
					SecondsRemaining(session), session.m_FishCaught, false);
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[Peche] Le poisson s est echappe...");
			}
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Force la fin d une session (appelle depuis un RPC "annuler" ou disconnect)
	//------------------------------------------------------------------------------------------------
	void ServerStopSession(int playerId, string reason)
	{
		LP_FishingSession session = m_Sessions.Get(playerId);
		if (!session) return;
		EndSessionInternal(session, reason);
	}
	
	//------------------------------------------------------------------------------------------------
	// Tick 500ms : verifie chaque session (timeout, mouvement, biting expired, next bite)
	//------------------------------------------------------------------------------------------------
	void TickAllSessions()
	{
		if (m_Sessions.Count() == 0) return;
		
		int now = System.GetUnixTime();
		array<int> toEnd = new array<int>();
		
		foreach (int pid, LP_FishingSession session : m_Sessions)
		{
			if (!session) { toEnd.Insert(pid); continue; }
			
			// Timeout session
			if (now - session.m_StartTimeUnix >= SESSION_DURATION_S)
			{
				EndSessionInternal(session, "Fin de la session de peche.");
				toEnd.Insert(pid);
				continue;
			}
			
			// Joueur toujours la ?
			if (!session.m_PlayerEnt)
			{
				toEnd.Insert(pid);
				continue;
			}
			
			// Bouge trop ?
			float dist = vector.Distance(session.m_PlayerEnt.GetOrigin(), session.m_StartPos);
			if (dist > MAX_DISTANCE)
			{
				EndSessionInternal(session, "Vous avez trop bouge, la peche s arrete.");
				toEnd.Insert(pid);
				continue;
			}
			
			// Poisson mord actuellement ? Verifie si la fenetre 3s est expiree
			if (session.m_BitingSinceUnix > 0)
			{
				if (now - session.m_BitingSinceUnix > BITE_WINDOW_S)
				{
					// Fenetre expiree, reset - poisson parti
					session.m_BitingSinceUnix = 0;
					session.m_NextBiteAtUnix = now + Math.RandomInt(MIN_COOLDOWN_S, MAX_COOLDOWN_S + 1);
					JobPlayerComponent jpc = JobPlayerComponent.Cast(
						session.m_PlayerEnt.FindComponent(JobPlayerComponent));
					if (jpc)
					{
						jpc.ServerFishingSetState(true, false);
						jpc.ServerFishingSendHudUpdate(
							SecondsRemaining(session), session.m_FishCaught, false);
					}
				}
				continue;
			}
			
			// Prochain poisson qui mord ?
			if (now >= session.m_NextBiteAtUnix)
			{
				session.m_BitingSinceUnix = now;
				JobPlayerComponent jpc = JobPlayerComponent.Cast(
					session.m_PlayerEnt.FindComponent(JobPlayerComponent));
				if (jpc)
				{
					jpc.ServerFishingSetState(true, true);
					jpc.ServerFishingSendHudUpdate(
						SecondsRemaining(session), session.m_FishCaught, true);
				}
			}
		}
		
		// Cleanup sessions terminees
		foreach (int pid : toEnd)
			m_Sessions.Remove(pid);
	}
	
	//------------------------------------------------------------------------------------------------
	// Termine proprement une session : notif chat + hide HUD + retire de la map
	//------------------------------------------------------------------------------------------------
	protected void EndSessionInternal(LP_FishingSession session, string reason)
	{
		if (!session) return;
		
		// Enregistre le timestamp de fin pour le cooldown 10min
		m_LastSessionEndUnix.Set(session.m_PlayerId, System.GetUnixTime());
		
		JobPlayerComponent jpc = null;
		if (session.m_PlayerEnt)
			jpc = JobPlayerComponent.Cast(session.m_PlayerEnt.FindComponent(JobPlayerComponent));
		if (jpc)
		{
			jpc.ServerFishingSetState(false, false);
			jpc.ServerFishingHideHud();
			JobManager.GetInstance().NotifyPlayerChat(session.m_PlayerId,
				"[Peche] " + reason);
		}
		Print(string.Format("[LP_Fishing] Session terminee pour %1 : %2 (poissons: %3)",
			session.m_PlayerId.ToString(), reason, session.m_FishCaught.ToString()),
			LogLevel.NORMAL);
	}
	
	//------------------------------------------------------------------------------------------------
	// Compte les items d un prefab donne dans l inventaire du joueur (mains + slots)
	//------------------------------------------------------------------------------------------------
	protected int CountItemInInventory(IEntity playerEnt, string prefabName)
	{
		if (!playerEnt) return 0;
		SCR_InventoryStorageManagerComponent inv = SCR_InventoryStorageManagerComponent.Cast(
			playerEnt.FindComponent(SCR_InventoryStorageManagerComponent));
		if (!inv) return 0;
		
		array<IEntity> items = new array<IEntity>();
		inv.GetItems(items);
		
		int count = 0;
		foreach (IEntity item : items)
		{
			if (!item) continue;
			EntityPrefabData pd = item.GetPrefabData();
			if (!pd) continue;
			if (pd.GetPrefabName() == prefabName)
				count = count + 1;
		}
		return count;
	}
	
	//------------------------------------------------------------------------------------------------
	// Verifie que le joueur possede une canne a peche (canne1 OU canne2) dans son inventaire.
	// Le mod utilise un pattern base sur l inventaire complet (mains + slots).
	//------------------------------------------------------------------------------------------------
	protected bool IsCanneEquipped(IEntity playerEnt)
	{
		if (CountItemInInventory(playerEnt, CANNE_PREFAB) > 0) return true;
		if (CountItemInInventory(playerEnt, CANNE2_PREFAB) > 0) return true;
		return false;
	}
	
	//------------------------------------------------------------------------------------------------
	// Consomme 1 asticot de l inventaire du joueur. Retourne false si plus aucun.
	//------------------------------------------------------------------------------------------------
	protected bool ConsumeAsticot(IEntity playerEnt)
	{
		if (!playerEnt) return false;
		SCR_InventoryStorageManagerComponent inv = SCR_InventoryStorageManagerComponent.Cast(
			playerEnt.FindComponent(SCR_InventoryStorageManagerComponent));
		if (!inv) return false;
		
		array<IEntity> items = new array<IEntity>();
		inv.GetItems(items);
		
		IEntity toRemove = null;
		foreach (IEntity item : items)
		{
			if (!item) continue;
			EntityPrefabData pd = item.GetPrefabData();
			if (!pd) continue;
			if (pd.GetPrefabName() == ASTICOT_PREFAB)
			{
				toRemove = item;
				break;
			}
		}
		
		if (!toRemove) return false;
		SCR_EntityHelper.DeleteEntityAndChildren(toRemove);
		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	// Spawn un poisson dans l inventaire du joueur (pattern eprouve du mod)
	//------------------------------------------------------------------------------------------------
	protected void SpawnFishInPlayerInventory(IEntity playerEnt, string fishPrefab)
	{
		if (!playerEnt) return;
		SCR_InventoryStorageManagerComponent inv = SCR_InventoryStorageManagerComponent.Cast(
			playerEnt.FindComponent(SCR_InventoryStorageManagerComponent));
		if (!inv) return;
		ResourceName rn = fishPrefab;
		inv.TrySpawnPrefabToStorage(rn);
	}
	
	//------------------------------------------------------------------------------------------------
	protected int SecondsRemaining(LP_FishingSession session)
	{
		if (!session) return 0;
		int elapsed = System.GetUnixTime() - session.m_StartTimeUnix;
		int remaining = SESSION_DURATION_S - elapsed;
		if (remaining < 0) remaining = 0;
		return remaining;
	}
	
	//------------------------------------------------------------------------------------------------
	bool IsFishingActive(int playerId)
	{
		return m_Sessions.Contains(playerId);
	}
	
	//------------------------------------------------------------------------------------------------
	bool IsFishingBiting(int playerId)
	{
		LP_FishingSession session = m_Sessions.Get(playerId);
		if (!session) return false;
		return session.m_BitingSinceUnix > 0;
	}
}
