//------------------------------------------------------------------------------------------------
// JobGangMenu.c
// Menu affiche quand un voyou AVEC gang clique sur "Gerer mon Gang".
// Affiche :
//   - Le nom du gang + benefices accumules
//   - Les zones controlees
//   - La liste des membres (chef + membres) avec bouton Ejecter (chef uniquement)
//   - Bouton "Recruter un membre" (ouvre liste joueurs) - chef uniquement
//   - Bouton "Retirer les benefices" - chef uniquement
//------------------------------------------------------------------------------------------------

class JobGangMenu : ChimeraMenuBase
{
	const string LAYOUT_PATH = "{0894A8432EA53D29}UI/layouts/JobGangMenu.layout";
	const string ENTRY_LAYOUT_PATH = "{8C2C1F9003637B2B}UI/layouts/JobGangMemberEntry.layout";
	
	Widget m_RootWidget;
	Widget m_MembersContainer;
	TextWidget m_TitleText;
	TextWidget m_BenefitsText;
	TextWidget m_ZonesText;
	ButtonWidget m_RecruitButton;
	ButtonWidget m_WithdrawButton;
	ButtonWidget m_CloseButton;
	
	string m_GangName;
	int m_Benefits;
	bool m_IsChef;
	
	// Cache des boutons ejecter -> UID du membre
	ref map<ButtonWidget, string> m_EjectButtonToUID = new map<ButtonWidget, string>();
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuOpen()
	{
		super.OnMenuOpen();
		m_RootWidget = GetRootWidget();
		if (!m_RootWidget)
			return;
		
		m_MembersContainer = m_RootWidget.FindAnyWidget("MembersContainer");
		m_TitleText = TextWidget.Cast(m_RootWidget.FindAnyWidget("TitleText"));
		m_BenefitsText = TextWidget.Cast(m_RootWidget.FindAnyWidget("BenefitsText"));
		m_ZonesText = TextWidget.Cast(m_RootWidget.FindAnyWidget("ZonesText"));
		m_RecruitButton = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("RecruitButton"));
		m_WithdrawButton = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("WithdrawButton"));
		m_CloseButton = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("CloseButton"));
		
		if (m_RecruitButton)
		{
			GangMenuClickHandler ch = new GangMenuClickHandler();
			ch.m_Menu = this;
			ch.m_Action = "recruit";
			m_RecruitButton.AddHandler(ch);
			JobFocusHandler.Attach(m_RecruitButton);
		}
		if (m_WithdrawButton)
		{
			GangMenuClickHandler ch = new GangMenuClickHandler();
			ch.m_Menu = this;
			ch.m_Action = "withdraw";
			m_WithdrawButton.AddHandler(ch);
			JobFocusHandler.Attach(m_WithdrawButton);
		}
		if (m_CloseButton)
		{
			GangMenuClickHandler ch = new GangMenuClickHandler();
			ch.m_Menu = this;
			ch.m_Action = "close";
			m_CloseButton.AddHandler(ch);
			JobFocusHandler.Attach(m_CloseButton);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuUpdate(float tDelta)
	{
		super.OnMenuUpdate(tDelta);
		if (GetGame().GetInputManager().GetActionValue("MenuBack") > 0.5)
			CloseMenuInternal();
	}
	
	//------------------------------------------------------------------------------------------------
	// membersData format : "MEMBRES\nCHEF|uid|nom\nMEMBRE|uid|nom\n...###ZONES\nCannabis\nCocaine\n"
	//------------------------------------------------------------------------------------------------
	void Initialize(string gangName, int benefits, bool isChef, string membersData)
	{
		m_GangName = gangName;
		m_Benefits = benefits;
		m_IsChef = isChef;
		
		if (m_TitleText)
			m_TitleText.SetText("Gang : " + gangName);
		if (m_BenefitsText)
			m_BenefitsText.SetText(string.Format("Benefices : %1 capsules", benefits));
		
		// Boutons chef uniquement
		if (m_RecruitButton)
		{
			m_RecruitButton.SetVisible(isChef);
			m_RecruitButton.SetEnabled(isChef);
		}
		if (m_WithdrawButton)
		{
			m_WithdrawButton.SetVisible(isChef);
			m_WithdrawButton.SetEnabled(isChef);
		}
		
		ParseAndDisplay(membersData);
	}
	
	//------------------------------------------------------------------------------------------------
	// Parse les donnees et construit la liste membres + texte zones
	//------------------------------------------------------------------------------------------------
	void ParseAndDisplay(string data)
	{
		// Separe la partie MEMBRES de la partie ZONES via le marqueur "###ZONES"
		string membersPart = data;
		string zonesPart = "";
		int sepIdx = data.IndexOf("###ZONES");
		if (sepIdx >= 0)
		{
			membersPart = data.Substring(0, sepIdx);
			int zonesStart = sepIdx + 8; // longueur de "###ZONES"
			if (zonesStart < data.Length())
				zonesPart = data.Substring(zonesStart, data.Length() - zonesStart);
		}
		
		// Affiche les zones controlees
		BuildZonesText(zonesPart);
		
		// Parse et affiche les membres
		BuildMembersList(membersPart);
	}
	
	//------------------------------------------------------------------------------------------------
	void BuildZonesText(string zonesPart)
	{
		if (!m_ZonesText)
			return;
		
		// Compte les lignes non vides (chaque ligne = un nom de zone)
		array<string> zones = SplitLines(zonesPart);
		string display = "Zones controlees : ";
		int count = 0;
		foreach (string z : zones)
		{
			if (z == "" || z == "ZONES")
				continue;
			if (count > 0)
				display = display + ", ";
			display = display + z;
			count++;
		}
		if (count == 0)
			display = "Zones controlees : aucune";
		m_ZonesText.SetText(display);
	}
	
	//------------------------------------------------------------------------------------------------
	void BuildMembersList(string membersPart)
	{
		if (!m_MembersContainer)
			return;
		
		array<string> lines = SplitLines(membersPart);
		
		WorkspaceWidget ws = GetGame().GetWorkspace();
		const int ENTRY_HEIGHT = 44;
		const int ENTRY_PADDING = 4;
		int yPos = 0;
		
		foreach (string line : lines)
		{
			if (line == "" || line == "MEMBRES")
				continue;
			
			// Format ligne : "CHEF|uid|nom" ou "MEMBRE|uid|nom"
			array<string> parts = SplitPipe(line);
			if (parts.Count() < 3)
				continue;
			
			string role = parts.Get(0);    // CHEF ou MEMBRE
			string uid = parts.Get(1);
			string name = parts.Get(2);
			bool isChefEntry = (role == "CHEF");
			
			Widget entry = ws.CreateWidgets(ENTRY_LAYOUT_PATH, m_MembersContainer);
			if (!entry)
				continue;
			
			FrameSlot.SetPos(entry, 0, yPos);
			FrameSlot.SetSize(entry, 560, ENTRY_HEIGHT);
			yPos += ENTRY_HEIGHT + ENTRY_PADDING;
			
			// Nom + role
			TextWidget nameW = TextWidget.Cast(entry.FindAnyWidget("MemberName"));
			if (nameW)
			{
				if (isChefEntry)
					nameW.SetText(name + " (Chef)");
				else
					nameW.SetText(name);
			}
			
			// Bouton ejecter : visible uniquement si JE suis chef ET que ce n est pas le chef lui-meme
			ButtonWidget ejectBtn = ButtonWidget.Cast(entry.FindAnyWidget("EjectButton"));
			if (ejectBtn)
			{
				bool canEject = (m_IsChef && !isChefEntry);
				ejectBtn.SetVisible(canEject);
				ejectBtn.SetEnabled(canEject);
				if (canEject)
				{
					m_EjectButtonToUID.Set(ejectBtn, uid);
					GangMenuClickHandler ch = new GangMenuClickHandler();
					ch.m_Menu = this;
					ch.m_Action = "eject";
					ejectBtn.AddHandler(ch);
					JobFocusHandler.Attach(ejectBtn);
				}
			}
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Helpers de parsing (string.Split n existe pas en Enforce, parsing manuel)
	//------------------------------------------------------------------------------------------------
	array<string> SplitLines(string s)
	{
		array<string> result = new array<string>();
		int start = 0;
		int len = s.Length();
		for (int i = 0; i <= len; i++)
		{
			if (i == len || s.Get(i) == "\n")
			{
				int segLen = i - start;
				if (segLen > 0)
					result.Insert(s.Substring(start, segLen));
				start = i + 1;
			}
		}
		return result;
	}
	
	array<string> SplitPipe(string s)
	{
		array<string> result = new array<string>();
		int start = 0;
		int len = s.Length();
		for (int i = 0; i <= len; i++)
		{
			if (i == len || s.Get(i) == "|")
			{
				int segLen = i - start;
				if (segLen > 0)
					result.Insert(s.Substring(start, segLen));
				else
					result.Insert("");
				start = i + 1;
			}
		}
		return result;
	}
	
	//------------------------------------------------------------------------------------------------
	void OnRecruitClicked()
	{
		// Ouvre le menu de selection de joueur
		GetGame().GetMenuManager().CloseMenu(this);
		JobGangRecruitMenu menu = JobGangRecruitMenu.Cast(
			GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.JobGangRecruitMenu));
		if (menu)
			menu.Initialize();
	}
	
	//------------------------------------------------------------------------------------------------
	void OnWithdrawClicked()
	{
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		jpc.ClientAskWithdrawGangBenefits();
		CloseMenuInternal();
	}
	
	//------------------------------------------------------------------------------------------------
	void OnEjectClicked(ButtonWidget btn)
	{
		string uid;
		if (!m_EjectButtonToUID.Find(btn, uid))
			return;
		
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		jpc.ClientAskEjectMember(uid);
		CloseMenuInternal();
	}
	
	//------------------------------------------------------------------------------------------------
	void CloseMenuInternal()
	{
		GetGame().GetMenuManager().CloseMenu(this);
	}
}

//------------------------------------------------------------------------------------------------
class GangMenuClickHandler : ScriptedWidgetEventHandler
{
	JobGangMenu m_Menu;
	string m_Action;
	
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (!m_Menu)
			return false;
		if (m_Action == "close")
		{
			m_Menu.CloseMenuInternal();
			return true;
		}
		if (m_Action == "recruit")
		{
			m_Menu.OnRecruitClicked();
			return true;
		}
		if (m_Action == "withdraw")
		{
			m_Menu.OnWithdrawClicked();
			return true;
		}
		if (m_Action == "eject")
		{
			ButtonWidget btn = ButtonWidget.Cast(w);
			if (btn)
				m_Menu.OnEjectClicked(btn);
			return true;
		}
		return false;
	}
}
