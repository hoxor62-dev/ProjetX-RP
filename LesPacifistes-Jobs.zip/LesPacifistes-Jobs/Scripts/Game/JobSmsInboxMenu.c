//------------------------------------------------------------------------------------------------
// JobSmsInboxMenu.c
// Affiche la liste des conversations du joueur (groupees par UID de l'autre).
// Cliquer sur une conversation ouvre JobSmsConversationMenu pour voir les messages
// et repondre.
// Cliquer sur "Supprimer" ouvre une popup de confirmation puis supprime la
// conversation (localement pour le joueur, l autre voit toujours ses messages).
//
// Pagination : 8 entrees par page. La barre de navigation (Precedent / Page X-Y / Suivant)
// n est visible que lorsqu il y a plus d une page. ScrollLayoutWidget n accepte pas d enfants
// crees dynamiquement en Enfusion, d ou le choix de la pagination.
//------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------------------
// Petite classe de donnees pour cacher une entree parsee entre deux rebuilds de page
//------------------------------------------------------------------------------------------------
class SmsInboxEntryData
{
	string m_OtherUID;
	string m_DisplayName;
	int m_Unread;
	int m_LastTs;
	string m_Preview;
}

class JobSmsInboxMenu : ChimeraMenuBase
{
	// Layout dedie a l inbox SMS (avec bouton Supprimer, contrairement au JobSmsEntry.layout
	// partage utilise par d autres menus comme le panneau admin et les contacts telephone).
	// Path relatif : Workbench le resoudra automatiquement.
	const string ENTRY_LAYOUT_PATH = "UI/layouts/JobSmsInboxEntry.layout";

	// Nombre d entrees affichees par page (la zone liste fait 320px, chaque entree ~35px avec padding)
	const int ENTRIES_PER_PAGE = 8;

	Widget m_RootWidget;
	Widget m_ConversationsContainer;
	ButtonWidget m_BtnClose;

	// === Pagination ===
	Widget m_PaginationRow;
	ButtonWidget m_BtnPrevPage;
	ButtonWidget m_BtnNextPage;
	TextWidget m_LabelPageInfo;

	// Cache de toutes les conversations parsees (persisté entre les changements de page)
	ref array<ref SmsInboxEntryData> m_AllEntries = new array<ref SmsInboxEntryData>();
	int m_CurrentPage = 0; // 0-based

	// === Popup de confirmation suppression ===
	Widget m_ConfirmDeletePopup;
	TextWidget m_ConfirmDeleteText;
	ButtonWidget m_BtnConfirmDeleteYes;
	ButtonWidget m_BtnConfirmDeleteNo;
	// UID de la conversation dont on doit valider la suppression
	string m_PendingDeleteUID = "";
	string m_PendingDeleteDisplayName = "";

	// Singleton temporaire pour permettre au RPC de mettre a jour
	static JobSmsInboxMenu s_Instance;

	//------------------------------------------------------------------------------------------------
	override void OnMenuOpen()
	{
		super.OnMenuOpen();
		s_Instance = this;
		JobFocusHandler.ClearRegistry();
		m_RootWidget = GetRootWidget();
		if (!m_RootWidget)
			return;

		m_ConversationsContainer = m_RootWidget.FindAnyWidget("ConversationsContainer");
		m_BtnClose = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnClose"));

		// Pagination
		m_PaginationRow = m_RootWidget.FindAnyWidget("PaginationRow");
		m_BtnPrevPage = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnPrevPage"));
		m_BtnNextPage = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnNextPage"));
		m_LabelPageInfo = TextWidget.Cast(m_RootWidget.FindAnyWidget("LabelPageInfo"));

		if (m_BtnPrevPage)
		{
			SmsInboxPageNavHandler h = new SmsInboxPageNavHandler();
			h.m_Menu = this;
			h.m_IsNext = false;
			m_BtnPrevPage.AddHandler(h);
			JobFocusHandler.Attach(m_BtnPrevPage);
		}
		if (m_BtnNextPage)
		{
			SmsInboxPageNavHandler h = new SmsInboxPageNavHandler();
			h.m_Menu = this;
			h.m_IsNext = true;
			m_BtnNextPage.AddHandler(h);
			JobFocusHandler.Attach(m_BtnNextPage);
		}

		// Popup de confirmation suppression
		m_ConfirmDeletePopup = m_RootWidget.FindAnyWidget("ConfirmDeletePopup");
		m_ConfirmDeleteText = TextWidget.Cast(m_RootWidget.FindAnyWidget("ConfirmDeleteText"));
		m_BtnConfirmDeleteYes = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnConfirmDeleteYes"));
		m_BtnConfirmDeleteNo = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnConfirmDeleteNo"));

		// Assure que la popup est masquee au demarrage
		if (m_ConfirmDeletePopup)
			m_ConfirmDeletePopup.SetVisible(false);

		if (m_BtnClose)
		{
			SmsInboxCloseHandler h = new SmsInboxCloseHandler();
			h.m_Menu = this;
			m_BtnClose.AddHandler(h);
			JobFocusHandler.Attach(m_BtnClose);
		}

		if (m_BtnConfirmDeleteYes)
		{
			SmsInboxConfirmDeleteHandler h = new SmsInboxConfirmDeleteHandler();
			h.m_Menu = this;
			h.m_IsYes = true;
			m_BtnConfirmDeleteYes.AddHandler(h);
			JobFocusHandler.Attach(m_BtnConfirmDeleteYes);
		}
		if (m_BtnConfirmDeleteNo)
		{
			SmsInboxConfirmDeleteHandler h = new SmsInboxConfirmDeleteHandler();
			h.m_Menu = this;
			h.m_IsYes = false;
			m_BtnConfirmDeleteNo.AddHandler(h);
			JobFocusHandler.Attach(m_BtnConfirmDeleteNo);
		}

		// Demande la liste des conversations au serveur
		PlayerController pc = GetGame().GetPlayerController();
		if (pc)
		{
			JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
			if (jpc)
				jpc.ClientAskSmsList();
		}
	}

	//------------------------------------------------------------------------------------------------
	override void OnMenuClose()
	{
		if (s_Instance == this)
			s_Instance = null;
		super.OnMenuClose();
	}

	//------------------------------------------------------------------------------------------------
	override void OnMenuUpdate(float tDelta)
	{
		super.OnMenuUpdate(tDelta);
		if (GetGame().GetInputManager().GetActionValue("MenuBack") > 0.5)
		{
			// Si la popup de confirmation est ouverte, la fermer plutot que fermer le menu
			if (m_ConfirmDeletePopup && m_ConfirmDeletePopup.IsVisible())
			{
				HideConfirmDelete();
				return;
			}
			CloseMenuInternal();
		}
	}

	//------------------------------------------------------------------------------------------------
	// Recoit la liste des conversations depuis le serveur (format encode)
	// Format : "uid1|displayname1|unreadCount1|lastTs1|lastContent1\n..."
	// Parse tout en cache puis rebuild la page courante.
	//------------------------------------------------------------------------------------------------
	void DisplayConversations(string encoded)
	{
		if (!m_ConversationsContainer)
			return;

		// Vide le cache et reparse tout
		m_AllEntries.Clear();

		if (encoded != "")
		{
			array<string> lines = SplitByNewline(encoded);
			foreach (string line : lines)
			{
				if (line == "")
					continue;
				array<string> fields = SplitByPipe(line);
				if (fields.Count() < 5)
					continue;

				SmsInboxEntryData e = new SmsInboxEntryData();
				e.m_OtherUID = fields.Get(0);
				e.m_DisplayName = fields.Get(1);
				e.m_Unread = fields.Get(2).ToInt();
				e.m_LastTs = fields.Get(3).ToInt();
				e.m_Preview = fields.Get(4);
				m_AllEntries.Insert(e);
			}
		}

		// Clamp la page courante si on en a plus assez (ex : apres une suppression)
		int pageCount = GetPageCount();
		if (m_CurrentPage >= pageCount)
			m_CurrentPage = pageCount - 1;
		if (m_CurrentPage < 0)
			m_CurrentPage = 0;

		RebuildCurrentPage();
	}

	//------------------------------------------------------------------------------------------------
	// Retourne le nombre de pages (minimum 1 pour le cas vide "Aucune conversation")
	//------------------------------------------------------------------------------------------------
	int GetPageCount()
	{
		int total = m_AllEntries.Count();
		if (total == 0)
			return 1;
		return (total + ENTRIES_PER_PAGE - 1) / ENTRIES_PER_PAGE;
	}

	//------------------------------------------------------------------------------------------------
	// Reconstruit uniquement la slice visible correspondant a m_CurrentPage
	//------------------------------------------------------------------------------------------------
	void RebuildCurrentPage()
	{
		if (!m_ConversationsContainer)
			return;

		// Reset
		Widget child = m_ConversationsContainer.GetChildren();
		while (child)
		{
			Widget next = child.GetSibling();
			child.RemoveFromHierarchy();
			child = next;
		}

		WorkspaceWidget ws = GetGame().GetWorkspace();
		int total = m_AllEntries.Count();

		// Cas vide : on cree une entree avec texte "Aucune conversation" (sans bouton Supprimer)
		if (total == 0)
		{
			Widget entry = ws.CreateWidgets(ENTRY_LAYOUT_PATH, m_ConversationsContainer);
			if (entry)
			{
				TextWidget nameW = TextWidget.Cast(entry.FindAnyWidget("PlayerName"));
				if (nameW)
				{
					nameW.SetText("Aucune conversation");
					nameW.SetColor(Color.FromRGBA(180, 180, 200, 255));
				}
				ButtonWidget delBtn = ButtonWidget.Cast(entry.FindAnyWidget("DeleteButton"));
				if (delBtn)
					delBtn.SetVisible(false);
			}
			UpdatePaginationUI();
			return;
		}

		int startIdx = m_CurrentPage * ENTRIES_PER_PAGE;
		int endIdx = startIdx + ENTRIES_PER_PAGE;
		if (endIdx > total)
			endIdx = total;

		for (int i = startIdx; i < endIdx; i++)
		{
			SmsInboxEntryData e = m_AllEntries.Get(i);
			if (!e)
				continue;

			string otherUID = e.m_OtherUID;
			string displayName = e.m_DisplayName;
			int unread = e.m_Unread;
			string preview = e.m_Preview;

			// 1er filet : tronque le preview individuel (anti-preview exagerement longs)
			const int PREVIEW_MAX = 40;
			if (preview.Length() > PREVIEW_MAX)
				preview = preview.Substring(0, PREVIEW_MAX - 3) + "...";

			// Cree l entree depuis le layout
			Widget entry = ws.CreateWidgets(ENTRY_LAYOUT_PATH, m_ConversationsContainer);
			if (!entry)
				continue;

			// Highlight visuel si non lu : background bleute
			if (unread > 0)
			{
				ImageWidget bg = ImageWidget.Cast(entry.FindAnyWidget("EntryBackground"));
				if (bg)
					bg.SetColor(Color.FromRGBA(60, 90, 130, 230));
			}

			TextWidget nameW = TextWidget.Cast(entry.FindAnyWidget("PlayerName"));
			if (nameW)
			{
				string label;
				if (unread > 0)
					label = string.Format("%1 (%2 non lu)  -  %3", displayName, unread, preview);
				else
					label = string.Format("%1  -  %2", displayName, preview);

				// 2eme filet : hard cap sur le label FINAL complet.
				// Garantit que le bouton Supprimer reste visible meme si le nom RP est long.
				const int LABEL_MAX = 50;
				if (label.Length() > LABEL_MAX)
					label = label.Substring(0, LABEL_MAX - 3) + "...";

				nameW.SetText(label);
			}

			ButtonWidget btn = ButtonWidget.Cast(entry.FindAnyWidget("SelectButton"));
			if (btn)
			{
				SmsInboxEntryHandler entryH = new SmsInboxEntryHandler();
				entryH.m_OtherUID = otherUID;
				entryH.m_DisplayName = displayName;
				btn.AddHandler(entryH);
				JobFocusHandler.Attach(btn);
			}

			// Bouton supprimer : declenche la popup de confirmation
			ButtonWidget delBtn = ButtonWidget.Cast(entry.FindAnyWidget("DeleteButton"));
			if (delBtn)
			{
				SmsInboxDeleteEntryHandler delH = new SmsInboxDeleteEntryHandler();
				delH.m_Menu = this;
				delH.m_OtherUID = otherUID;
				delH.m_DisplayName = displayName;
				delBtn.AddHandler(delH);
				JobFocusHandler.Attach(delBtn);
			}
		}

		UpdatePaginationUI();
	}

	//------------------------------------------------------------------------------------------------
	// Met a jour l affichage de la barre de pagination (label + visibilite boutons).
	// Masque toute la rangee si il n y a qu une seule page.
	//------------------------------------------------------------------------------------------------
	void UpdatePaginationUI()
	{
		int pageCount = GetPageCount();
		int total = m_AllEntries.Count();

		// Masque la barre si une seule page (ou vide)
		bool showPagination = (total > ENTRIES_PER_PAGE);
		if (m_PaginationRow)
			m_PaginationRow.SetVisible(showPagination);

		if (!showPagination)
			return;

		if (m_LabelPageInfo)
			m_LabelPageInfo.SetText(string.Format("Page %1 / %2", m_CurrentPage + 1, pageCount));

		// Grise les boutons aux bords (reste cliquable mais visuellement different)
		if (m_BtnPrevPage)
		{
			if (m_CurrentPage <= 0)
				m_BtnPrevPage.SetColor(Color.FromRGBA(60, 60, 70, 200));
			else
				m_BtnPrevPage.SetColor(Color.FromRGBA(64, 90, 153, 255));
		}
		if (m_BtnNextPage)
		{
			if (m_CurrentPage >= pageCount - 1)
				m_BtnNextPage.SetColor(Color.FromRGBA(60, 60, 70, 200));
			else
				m_BtnNextPage.SetColor(Color.FromRGBA(64, 90, 153, 255));
		}
	}

	//------------------------------------------------------------------------------------------------
	// Navigation : appele par SmsInboxPageNavHandler
	//------------------------------------------------------------------------------------------------
	void GoToNextPage()
	{
		int pageCount = GetPageCount();
		if (m_CurrentPage >= pageCount - 1)
			return;
		m_CurrentPage++;
		RebuildCurrentPage();
	}

	void GoToPrevPage()
	{
		if (m_CurrentPage <= 0)
			return;
		m_CurrentPage--;
		RebuildCurrentPage();
	}

	//------------------------------------------------------------------------------------------------
	// Affiche la popup de confirmation pour supprimer la conversation avec otherUID.
	//------------------------------------------------------------------------------------------------
	void ShowConfirmDelete(string otherUID, string displayName)
	{
		if (!m_ConfirmDeletePopup)
			return;
		m_PendingDeleteUID = otherUID;
		m_PendingDeleteDisplayName = displayName;
		if (m_ConfirmDeleteText)
			m_ConfirmDeleteText.SetText(string.Format("Supprimer la conversation avec %1 ?", displayName));
		m_ConfirmDeletePopup.SetVisible(true);
		// Met le focus sur "Annuler" par defaut (safety)
		if (m_BtnConfirmDeleteNo)
			GetGame().GetWorkspace().SetFocusedWidget(m_BtnConfirmDeleteNo);
	}

	//------------------------------------------------------------------------------------------------
	void HideConfirmDelete()
	{
		if (m_ConfirmDeletePopup)
			m_ConfirmDeletePopup.SetVisible(false);
		m_PendingDeleteUID = "";
		m_PendingDeleteDisplayName = "";
	}

	//------------------------------------------------------------------------------------------------
	// Appele quand le joueur clique "Oui" dans la popup : envoie le RPC de suppression
	//------------------------------------------------------------------------------------------------
	void ConfirmDeleteYes()
	{
		if (m_PendingDeleteUID == "")
		{
			HideConfirmDelete();
			return;
		}
		string uidToDelete = m_PendingDeleteUID;
		HideConfirmDelete();

		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		jpc.ClientAskDeleteSmsConversation(uidToDelete);

		// Recharge la liste apres un court delai (le serveur a besoin d un tick)
		GetGame().GetCallqueue().CallLater(ReloadList, 400, false);
	}

	//------------------------------------------------------------------------------------------------
	void ReloadList()
	{
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		jpc.ClientAskSmsList();
	}

	//------------------------------------------------------------------------------------------------
	// Helpers : Enforce Script n'a pas de string.Split() natif
	//------------------------------------------------------------------------------------------------
	array<string> SplitByNewline(string s)
	{
		array<string> result = new array<string>();
		string current = "";
		int len = s.Length();
		for (int i = 0; i < len; i++)
		{
			string c = s.Substring(i, 1);
			if (c == "\n")
			{
				result.Insert(current);
				current = "";
			}
			else
			{
				current = current + c;
			}
		}
		if (current != "")
			result.Insert(current);
		return result;
	}

	array<string> SplitByPipe(string s)
	{
		array<string> result = new array<string>();
		string current = "";
		int len = s.Length();
		for (int i = 0; i < len; i++)
		{
			string c = s.Substring(i, 1);
			if (c == "|")
			{
				result.Insert(current);
				current = "";
			}
			else
			{
				current = current + c;
			}
		}
		result.Insert(current);
		return result;
	}

	//------------------------------------------------------------------------------------------------
	void CloseMenuInternal()
	{
		GetGame().GetMenuManager().CloseMenu(this);
	}

	//------------------------------------------------------------------------------------------------
	static JobSmsInboxMenu GetOpenMenu()
	{
		return s_Instance;
	}
}

//------------------------------------------------------------------------------------------------
class SmsInboxCloseHandler : ScriptedWidgetEventHandler
{
	JobSmsInboxMenu m_Menu;

	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu)
			m_Menu.CloseMenuInternal();
		return true;
	}
}

//------------------------------------------------------------------------------------------------
// Handler pour ouvrir une conversation precise
//------------------------------------------------------------------------------------------------
class SmsInboxEntryHandler : ScriptedWidgetEventHandler
{
	string m_OtherUID;
	string m_DisplayName;

	override bool OnClick(Widget w, int x, int y, int button)
	{
		// Stocke les params dans le menu Conversation puis l'ouvre
		JobSmsConversationMenu conv = JobSmsConversationMenu.Cast(
			GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.JobSmsConversationMenu));
		if (conv)
			conv.Initialize(m_OtherUID, m_DisplayName);
		return true;
	}
}

//------------------------------------------------------------------------------------------------
// Handler pour supprimer une conversation (affiche la popup de confirmation)
//------------------------------------------------------------------------------------------------
class SmsInboxDeleteEntryHandler : ScriptedWidgetEventHandler
{
	JobSmsInboxMenu m_Menu;
	string m_OtherUID;
	string m_DisplayName;

	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu)
			m_Menu.ShowConfirmDelete(m_OtherUID, m_DisplayName);
		return true;
	}
}

//------------------------------------------------------------------------------------------------
// Handler pour les boutons "Oui" / "Annuler" de la popup de confirmation suppression
//------------------------------------------------------------------------------------------------
class SmsInboxConfirmDeleteHandler : ScriptedWidgetEventHandler
{
	JobSmsInboxMenu m_Menu;
	bool m_IsYes;

	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (!m_Menu)
			return true;
		if (m_IsYes)
			m_Menu.ConfirmDeleteYes();
		else
			m_Menu.HideConfirmDelete();
		return true;
	}
}

//------------------------------------------------------------------------------------------------
// Handler pour les boutons de pagination Precedent / Suivant
//------------------------------------------------------------------------------------------------
class SmsInboxPageNavHandler : ScriptedWidgetEventHandler
{
	JobSmsInboxMenu m_Menu;
	bool m_IsNext;

	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (!m_Menu)
			return true;
		if (m_IsNext)
			m_Menu.GoToNextPage();
		else
			m_Menu.GoToPrevPage();
		return true;
	}
}
