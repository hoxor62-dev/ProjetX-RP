//------------------------------------------------------------------------------------------------
// LP_DrinkAlcoholAction.c
// Action "Boire de l alcool" - a placer sur les bouteilles / cannettes alcoolisees via Workbench
// (ActionsManagerComponent).
//
// A la difference de DrinkItemAction, cette action :
//  1) Restaure la soif (comme boire de l eau) via SurvivalHUDManager
//  2) AJOUTE un taux d alcool au joueur via LP_AlcoholManager
//
// Les 2 quantites sont configurables par bouteille (biere = 20% alcool, whisky = 40%, etc.)
//------------------------------------------------------------------------------------------------

class LP_DrinkAlcoholAction : ScriptedUserAction
{
	[Attribute("15", UIWidgets.EditBox, "Quantite de soif restauree (%)")]
	protected float m_fThirstAmount;
	
	[Attribute("25", UIWidgets.EditBox, "Quantite d alcool ajoutee (%) - 100% = inconscient")]
	protected float m_fAlcoholAmount;
	
	//------------------------------------------------------------------------------------------------
	override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
	{
		if (!Replication.IsServer()) return;
		
		int playerId = GetGame().GetPlayerManager().GetPlayerIdFromControlledEntity(pUserEntity);
		if (playerId <= 0) return;
		
		PlayerController pc = GetGame().GetPlayerManager().GetPlayerController(playerId);
		if (pc)
		{
			// Soif : reutilise le SurvivalHUDManager existant (comme DrinkItemAction)
			SurvivalHUDManager hud = SurvivalHUDManager.Cast(pc.FindComponent(SurvivalHUDManager));
			if (hud) hud.ServerNotifyDrink(m_fThirstAmount);
		}
		
		// Alcool : ajoute au taux du joueur (independamment de la soif)
		LP_AlcoholManager.GetInstance().ServerAddAlcohol(playerId, m_fAlcoholAmount);
		
		// Supprime la bouteille consommee
		SCR_EntityHelper.DeleteEntityAndChildren(pOwnerEntity);
	}
	
	//------------------------------------------------------------------------------------------------
	override bool CanBePerformedScript(IEntity user)
	{
		// Le joueur peut toujours boire de l alcool sauf s il est deja inconscient
		SurvivalHUDManager hud = SurvivalHUDManager.GetInstance();
		if (hud && hud.GetThirst() >= 99.0)
		{
			// Optionnel : bloquer si soif deja pleine (comme DrinkItemAction)
			// Ici on laisse boire pour l effet alcool meme si soif pleine
		}
		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	override bool CanBeShownScript(IEntity user) { return true; }
	
	//------------------------------------------------------------------------------------------------
	override bool GetActionNameScript(out string outName)
	{
		outName = "Boire";
		return true;
	}
}
