//------------------------------------------------------------------------------------------------
// JobMedicalTerminalAction.c
//
// UserAction "Fiche medicale" pour les medecins (EMS) uniquement.
// A attacher via ActionsManagerComponent sur un prefab ordinateur/tablette d hopital.
//
// L action n est VISIBLE que pour les EJobType.MEDECIN (client-side check via CanBeShownScript).
// Le check est aussi refait cote serveur dans chaque RPC (IsCallerMedecin),
// donc meme si un cheater force l ouverture du menu, aucune donnee ne remonte / ne se modifie.
//
// A distinguer de JobPoliceTerminalAction : cette action va sur un ordinateur d hopital,
// tandis que la fiche judiciaire va sur un ordinateur de commissariat.
//------------------------------------------------------------------------------------------------

class JobMedicalTerminalAction : ScriptedUserAction
{
	//------------------------------------------------------------------------------------------------
	// Verifie que le joueur local a le metier Medecin (via le composant local)
	//------------------------------------------------------------------------------------------------
	private bool IsLocalPlayerMedecin()
	{
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc)
			return false;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc)
			return false;
		int job = jpc.GetJob();
		return (job == EJobType.MEDECIN);
	}
	
	//------------------------------------------------------------------------------------------------
	override bool CanBeShownScript(IEntity user)
	{
		return IsLocalPlayerMedecin();
	}
	
	//------------------------------------------------------------------------------------------------
	override bool CanBePerformedScript(IEntity user)
	{
		return IsLocalPlayerMedecin();
	}
	
	//------------------------------------------------------------------------------------------------
	override bool GetActionNameScript(out string outName)
	{
		outName = "Fiche medicale";
		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
	{
		// Garde multijoueur : seul le joueur local execute
		IEntity localPlayer = SCR_PlayerController.GetLocalControlledEntity();
		if (!localPlayer || pUserEntity != localPlayer)
			return;
		if (!IsLocalPlayerMedecin())
			return;
		
		// IMPORTANT : ChimeraMenuPreset.JobMedicalMenu doit etre enregistre
		// dans la config Workbench (comme les autres menus custom du mod).
		GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.JobMedicalMenu);
	}
}
