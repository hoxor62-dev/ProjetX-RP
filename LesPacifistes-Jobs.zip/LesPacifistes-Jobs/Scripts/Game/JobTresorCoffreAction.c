//------------------------------------------------------------------------------------------------
// JobTresorCoffreAction.c
// UserAction a placer sur l entity coffre au tresor sous-marin.
// Au clic : envoie une RPC au serveur pour demarrer la recherche.
//------------------------------------------------------------------------------------------------

class JobTresorCoffreAction : ScriptedUserAction
{
	override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
	{
		PlayerController pc = PlayerController.Cast(GetGame().GetPlayerController());
		if (!pc) return;
		if (pUserEntity != pc.GetControlledEntity()) return;
		
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		
		// Envoie la RplId du coffre au serveur pour resolution + check distance
		RplComponent rpl = RplComponent.Cast(pOwnerEntity.FindComponent(RplComponent));
		if (!rpl) return;
		jpc.ClientAskStartTresor(rpl.Id());
	}
	
	override bool CanBePerformedScript(IEntity user)
	{
		return true;
	}
	
	override bool CanBeShownScript(IEntity user)
	{
		return true;
	}
}
