//------------------------------------------------------------------------------------------------
//! Bouton qui ouvre le menu JobRpFicheMenu au clic
class JobRpFicheMenuButtonComponent : SCR_ButtonBaseComponent
{
    //------------------------------------------------------------------------------------------------
    override void HandlerAttached(Widget w)
    {
        super.HandlerAttached(w);

        // Connecte l'évènement de clic du bouton
        m_OnClicked.Insert(OnButtonClicked);
    }

    //------------------------------------------------------------------------------------------------
    override void HandlerDeattached(Widget w)
    {
        if (m_OnClicked)
            m_OnClicked.Remove(OnButtonClicked);

        super.HandlerDeattached(w);
    }

    //------------------------------------------------------------------------------------------------
    protected void OnButtonClicked()
    {
        MenuManager mm = GetGame().GetMenuManager();
        if (!mm)
        {
            Print("[JobRpFicheMenuButtonComponent] MenuManager introuvable", LogLevel.ERROR);
            return;
        }

        mm.OpenMenu(ChimeraMenuPreset.JobRpFicheMenu);
    }
};
