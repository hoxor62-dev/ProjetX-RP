//------------------------------------------------------------------------------------------------
// JobAtmMenu.c
// Menu ATM - permet d'envoyer des capsules a un autre joueur connecte
//------------------------------------------------------------------------------------------------

class JobAtmMenu : ChimeraMenuBase
{
	const string LAYOUT_PATH = "{7773A2CCEA898D2A}UI/layouts/JobAtmMenu.layout";
	const string ENTRY_LAYOUT_PATH = "{38EB876AF9C737C8}UI/layouts/JobAtmPlayerEntry.layout";
	
	// === PAGINATION ===
	const int PLAYERS_PER_PAGE = 10;
	int m_CurrentPage = 0;
	ref array<int> m_AllPlayerIds = new array<int>();   // cache complet
	ref array<string> m_AllPlayerNames = new array<string>();
	float m_TabPressCooldown = 0;  // anti-rebound LB/RB manette
	
	Widget m_RootWidget;
	Widget m_PlayersContainer;
	TextWidget m_TitleText;
	TextWidget m_BalanceText;
	EditBoxWidget m_AmountInput;
	ButtonWidget m_SendButton;
	ButtonWidget m_CloseButton;
	ButtonWidget m_BankButton;   // Ouvre le menu banque (depot/retrait)
	ButtonWidget m_PrevPageButton;
	ButtonWidget m_NextPageButton;
	TextWidget m_PageLabel;
	
	// Joueur destinataire selectionne
	int m_SelectedPlayerId = -1;
	string m_SelectedPlayerName = "";
	
	// Cache des boutons joueurs (pour le click handler)
	ref map<ButtonWidget, int> m_ButtonToPlayerId = new map<ButtonWidget, int>();
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuOpen()
	{
		super.OnMenuOpen();
		m_RootWidget = GetRootWidget();
		if (!m_RootWidget)
			return;
		
		m_PlayersContainer = m_RootWidget.FindAnyWidget("PlayersContainer");
		m_TitleText = TextWidget.Cast(m_RootWidget.FindAnyWidget("TitleText"));
		m_BalanceText = TextWidget.Cast(m_RootWidget.FindAnyWidget("BalanceText"));
		m_AmountInput = EditBoxWidget.Cast(m_RootWidget.FindAnyWidget("AmountInput"));
		m_SendButton = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("SendButton"));
		m_CloseButton = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("CloseButton"));
		m_BankButton = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BankButton"));
		m_PrevPageButton = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("PrevPageButton"));
		m_NextPageButton = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("NextPageButton"));
		m_PageLabel = TextWidget.Cast(m_RootWidget.FindAnyWidget("PageLabel"));
		
		// Attache les boutons de pagination
		if (m_PrevPageButton)
		{
			AtmClickHandler prevCh = new AtmClickHandler();
			prevCh.m_Menu = this;
			prevCh.m_Action = "prev_page";
			m_PrevPageButton.AddHandler(prevCh);
			JobFocusHandler.Attach(m_PrevPageButton);
		}
		if (m_NextPageButton)
		{
			AtmClickHandler nextCh = new AtmClickHandler();
			nextCh.m_Menu = this;
			nextCh.m_Action = "next_page";
			m_NextPageButton.AddHandler(nextCh);
			JobFocusHandler.Attach(m_NextPageButton);
		}
		
		if (m_SendButton)
		{
			AtmClickHandler sendCh = new AtmClickHandler();
			sendCh.m_Menu = this;
			sendCh.m_Action = "send";
			m_SendButton.AddHandler(sendCh);
			JobFocusHandler.Attach(m_SendButton);
		}
		
		if (m_CloseButton)
		{
			AtmClickHandler closeCh = new AtmClickHandler();
			closeCh.m_Menu = this;
			closeCh.m_Action = "close";
			m_CloseButton.AddHandler(closeCh);
			JobFocusHandler.Attach(m_CloseButton);
		}
		
		// Bouton "Banque" -> ouvre le menu banque
		if (m_BankButton)
		{
			AtmClickHandler bankCh = new AtmClickHandler();
			bankCh.m_Menu = this;
			bankCh.m_Action = "bank";
			m_BankButton.AddHandler(bankCh);
			JobFocusHandler.Attach(m_BankButton);
		}
		
		// Bouton flottant "X" en haut a droite
		ButtonWidget floatingClose = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("FloatingCloseButton"));
		if (floatingClose)
		{
			AtmClickHandler floatCh = new AtmClickHandler();
			floatCh.m_Menu = this;
			floatCh.m_Action = "close";
			floatingClose.AddHandler(floatCh);
			JobFocusHandler.Attach(floatingClose);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Support touche Echap
	//------------------------------------------------------------------------------------------------
	override void OnMenuUpdate(float tDelta)
	{
		super.OnMenuUpdate(tDelta);
		if (GetGame().GetInputManager().GetActionValue("MenuBack") > 0.5)
		{
			CloseMenuInternal();
			return;
		}
		
		// Navigation pagination manette (LB/RB) avec cooldown anti-rebound
		if (m_TabPressCooldown > 0)
			m_TabPressCooldown = m_TabPressCooldown - tDelta;
		else
		{
			if (GetGame().GetInputManager().GetActionValue("MenuTabLeft") > 0.5)
			{
				PrevPage();
				m_TabPressCooldown = 0.30;
			}
			else if (GetGame().GetInputManager().GetActionValue("MenuTabRight") > 0.5)
			{
				NextPage();
				m_TabPressCooldown = 0.30;
			}
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void Initialize()
	{
		UpdateBalance();
		BuildPlayerList();
	}
	
	//------------------------------------------------------------------------------------------------
	void UpdateBalance()
	{
		if (!m_BalanceText)
			return;
		
		// Lit directement le solde depuis le widget txt_Capsules du HUD
		// (il est toujours a jour via le systeme CapsuleEconomy)
		WorkspaceWidget ws = GetGame().GetWorkspace();
		if (!ws)
			return;
		
		TextWidget hudCaps = TextWidget.Cast(ws.FindAnyWidget("txt_Capsules"));
		if (!hudCaps)
		{
			m_BalanceText.SetText("Votre solde: ? capsules");
			return;
		}
		
		string hudText = hudCaps.GetText();
		m_BalanceText.SetText(string.Format("Votre solde: %1", hudText));
	}
	
	//------------------------------------------------------------------------------------------------
	void BuildPlayerList()
	{
		if (!m_PlayersContainer)
			return;
		
		// === PHASE 1 : cache la liste complete des joueurs (a chaque ouverture du menu) ===
		m_AllPlayerIds.Clear();
		m_AllPlayerNames.Clear();
		m_CurrentPage = 0;
		
		PlayerManager pm = GetGame().GetPlayerManager();
		if (!pm)
			return;
		
		// Recupere mon propre playerId pour m'exclure de la liste
		int myPlayerId = -1;
		PlayerController myPc = GetGame().GetPlayerController();
		if (myPc)
			myPlayerId = myPc.GetPlayerId();
		
		array<int> playerIds = new array<int>();
		pm.GetPlayers(playerIds);
		
		foreach (int pid : playerIds)
		{
			if (pid == myPlayerId)
				continue;
			string playerName = JobIdentityManager.GetInstance().Client_GetDisplayName(pid);
			if (playerName == "")
				continue;
			m_AllPlayerIds.Insert(pid);
			m_AllPlayerNames.Insert(playerName);
		}
		
		// === PHASE 2 : affiche la page courante ===
		RenderCurrentPage();
	}
	
	//------------------------------------------------------------------------------------------------
	// Affiche uniquement les joueurs de la page courante (10 max)
	//------------------------------------------------------------------------------------------------
	void RenderCurrentPage()
	{
		if (!m_PlayersContainer)
			return;
		
		// Nettoie les entrees existantes + reset le cache des boutons
		Widget child = m_PlayersContainer.GetChildren();
		while (child)
		{
			Widget next = child.GetSibling();
			child.RemoveFromHierarchy();
			child = next;
		}
		m_ButtonToPlayerId.Clear();
		
		int totalPages = GetTotalPages();
		if (m_CurrentPage >= totalPages && totalPages > 0)
			m_CurrentPage = totalPages - 1;
		if (m_CurrentPage < 0)
			m_CurrentPage = 0;
		
		int startIdx = m_CurrentPage * PLAYERS_PER_PAGE;
		int endIdx = startIdx + PLAYERS_PER_PAGE;
		if (endIdx > m_AllPlayerIds.Count())
			endIdx = m_AllPlayerIds.Count();
		
		WorkspaceWidget ws = GetGame().GetWorkspace();
		const int ENTRY_HEIGHT = 40;
		const int ENTRY_PADDING = 5;
		int yPos = 0;
		ButtonWidget firstButton = null;
		
		for (int i = startIdx; i < endIdx; i++)
		{
			int pid = m_AllPlayerIds.Get(i);
			string playerName = m_AllPlayerNames.Get(i);
			
			Widget entry = ws.CreateWidgets(ENTRY_LAYOUT_PATH, m_PlayersContainer);
			if (!entry)
				continue;
			
			FrameSlot.SetPos(entry, 0, yPos);
			FrameSlot.SetSize(entry, 660, ENTRY_HEIGHT);
			yPos += ENTRY_HEIGHT + ENTRY_PADDING;
			
			TextWidget nameW = TextWidget.Cast(entry.FindAnyWidget("PlayerName"));
			if (nameW)
				nameW.SetText(playerName);
			
			ButtonWidget btn = ButtonWidget.Cast(entry.FindAnyWidget("SelectButton"));
			if (btn)
			{
				m_ButtonToPlayerId.Set(btn, pid);
				AtmClickHandler ch = new AtmClickHandler();
				ch.m_Menu = this;
				ch.m_Action = "select";
				btn.AddHandler(ch);
				JobFocusHandler.Attach(btn);
				if (!firstButton)
					firstButton = btn;
				
				// Re-applique la couleur selectionnee si on revient sur la page contenant le joueur selectionne
				if (pid == m_SelectedPlayerId)
				{
					Widget parent = btn.GetParent();
					if (parent)
					{
						ImageWidget bg = ImageWidget.Cast(parent.FindAnyWidget("EntryBackground"));
						if (bg)
							bg.SetColor(Color.FromRGBA(46, 128, 46, 230));
					}
				}
			}
		}
		
		UpdatePaginationUI();
		
		// Focus initial manette : 1er joueur de la page ou bouton Fermer si vide
		if (firstButton)
			GetGame().GetWorkspace().SetFocusedWidget(firstButton);
		else if (m_CloseButton)
			GetGame().GetWorkspace().SetFocusedWidget(m_CloseButton);
	}
	
	//------------------------------------------------------------------------------------------------
	int GetTotalPages()
	{
		int total = m_AllPlayerIds.Count();
		if (total == 0)
			return 1;  // 1 page vide
		return (total + PLAYERS_PER_PAGE - 1) / PLAYERS_PER_PAGE;  // arrondi sup
	}
	
	//------------------------------------------------------------------------------------------------
	void UpdatePaginationUI()
	{
		int totalPages = GetTotalPages();
		
		if (m_PageLabel)
			m_PageLabel.SetText(string.Format("Page %1 / %2", m_CurrentPage + 1, totalPages));
		
		// Boutons grises aux extremites
		if (m_PrevPageButton)
			m_PrevPageButton.SetEnabled(m_CurrentPage > 0);
		if (m_NextPageButton)
			m_NextPageButton.SetEnabled(m_CurrentPage < totalPages - 1);
	}
	
	//------------------------------------------------------------------------------------------------
	void PrevPage()
	{
		if (m_CurrentPage <= 0)
			return;
		m_CurrentPage--;
		RenderCurrentPage();
	}
	
	//------------------------------------------------------------------------------------------------
	void NextPage()
	{
		if (m_CurrentPage >= GetTotalPages() - 1)
			return;
		m_CurrentPage++;
		RenderCurrentPage();
	}
	
	//------------------------------------------------------------------------------------------------
	void OnPlayerSelected(ButtonWidget btn)
	{
		int pid;
		if (!m_ButtonToPlayerId.Find(btn, pid))
			return;
		
		m_SelectedPlayerId = pid;
		
		// Recupere le nom RP si dispo, sinon playername
		m_SelectedPlayerName = JobIdentityManager.GetInstance().Client_GetDisplayName(pid);
		
		// Mise en evidence visuelle: reset toutes les couleurs, highlight la selectionnee
		foreach (ButtonWidget b, int id : m_ButtonToPlayerId)
		{
			Widget parent = b.GetParent();
			if (!parent)
				continue;
			ImageWidget bg = ImageWidget.Cast(parent.FindAnyWidget("EntryBackground"));
			if (!bg)
				continue;
			if (id == pid)
				bg.SetColor(Color.FromRGBA(46, 128, 46, 230));  // vert selectionne
			else
				bg.SetColor(Color.FromRGBA(30, 30, 38, 230));   // defaut
		}
		
		Print(string.Format("[JobAtmMenu] Destinataire selectionne: %1 (id=%2)",
			m_SelectedPlayerName, m_SelectedPlayerId), LogLevel.NORMAL);
	}
	
	//------------------------------------------------------------------------------------------------
	void OnSendClicked()
	{
		if (m_SelectedPlayerId <= 0)
		{
			Print("[JobAtmMenu] Aucun destinataire selectionne", LogLevel.WARNING);
			return;
		}
		
		if (!m_AmountInput)
			return;
		
		string amountStr = m_AmountInput.GetText();
		int amount = amountStr.ToInt();
		
		if (amount <= 0)
		{
			Print("[JobAtmMenu] Montant invalide", LogLevel.WARNING);
			return;
		}
		
		// Envoie la RPC via le JobPlayerComponent local
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc)
			return;
		
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc)
		{
			Print("[JobAtmMenu] JobPlayerComponent manquant", LogLevel.WARNING);
			return;
		}
		
		jpc.ClientAskAtmTransfer(m_SelectedPlayerId, amount);
		
		// Ferme le menu apres envoi
		CloseMenuInternal();
	}
	
	//------------------------------------------------------------------------------------------------
	// Clic sur le bouton "Banque" -> ouvre le menu banque puis ferme l ATM
	// Le menu banque demande son solde au serveur des l ouverture.
	//------------------------------------------------------------------------------------------------
	void OnBankClicked()
	{
		GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.JobBankMenu);
		CloseMenuInternal();
	}
	
	//------------------------------------------------------------------------------------------------
	void CloseMenuInternal()
	{
		GetGame().GetMenuManager().CloseMenu(this);
	}
}

//------------------------------------------------------------------------------------------------
class AtmClickHandler : ScriptedWidgetEventHandler
{
	JobAtmMenu m_Menu;
	string m_Action;
	
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (!m_Menu)
			return false;
		
		if (m_Action == "close")
		{
			m_Menu.CloseMenuInternal();
			return true;
		}
		
		if (m_Action == "send")
		{
			m_Menu.OnSendClicked();
			return true;
		}
		
		if (m_Action == "bank")
		{
			m_Menu.OnBankClicked();
			return true;
		}
		
		if (m_Action == "select")
		{
			ButtonWidget btn = ButtonWidget.Cast(w);
			if (btn)
				m_Menu.OnPlayerSelected(btn);
			return true;
		}
		
		if (m_Action == "prev_page")
		{
			m_Menu.PrevPage();
			return true;
		}
		
		if (m_Action == "next_page")
		{
			m_Menu.NextPage();
			return true;
		}
		
		return false;
	}
}
