//------------------------------------------------------------------------------------------------
// JobMayorTalkAction.c
// Action F sur le PNJ Maire. Ouvre le JobMayorMenu avec ses 3 options.
// A attacher via l'ActionsManagerComponent du PNJ Maire.
//
// Accessible a tout les joueurs (pas de restriction de metier).
//------------------------------------------------------------------------------------------------

class JobMayorTalkAction : ScriptedUserAction
{
	//------------------------------------------------------------------------------------------------
	override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
	{
		if (!pUserEntity)
			return;
		
		PlayerController localPC = GetGame().GetPlayerController();
		if (!localPC)
			return;
		IEntity localEntity = localPC.GetControlledEntity();
		if (localEntity != pUserEntity)
			return;
		
		GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.JobMayorMenu);
	}
	
	//------------------------------------------------------------------------------------------------
	override bool CanBeShownScript(IEntity user)
	{
		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	override bool CanBePerformedScript(IEntity user)
	{
		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	override bool GetActionNameScript(out string outName)
	{
		outName = "Parler au Maire";
		return true;
	}
}
