//------------------------------------------------------------------------------------------------
// JobMayorManager.c
// Manager singleton server-side du PNJ Maire.
// Gere uniquement la persistance des UID ayant deja recu la recompense de debut (250c).
// Un joueur ne peut jamais re-recevoir la recompense (one-shot definitif).
//
// Persistance : $profile:LesPacifistesJobs/mayor_rewards.json
//------------------------------------------------------------------------------------------------

class JobMayorManager
{
	static ref JobMayorManager s_Instance;
	
	// Liste des UID ayant deja recu la recompense
	ref array<string> m_RewardedUIDs;
	
	// Constantes
	const int START_REWARD_AMOUNT = 1200;
	const string SAVE_PATH = "$profile:LesPacifistesJobs/mayor_rewards.json";
	
	//------------------------------------------------------------------------------------------------
	void JobMayorManager()
	{
		m_RewardedUIDs = new array<string>();
	}
	
	//------------------------------------------------------------------------------------------------
	static JobMayorManager GetInstance()
	{
		if (!s_Instance)
		{
			s_Instance = new JobMayorManager();
			s_Instance.LoadFromDisk();
		}
		return s_Instance;
	}
	
	//------------------------------------------------------------------------------------------------
	bool HasReceivedReward(string uid)
	{
		if (uid == "")
			return false;
		return (m_RewardedUIDs.Find(uid) != -1);
	}
	
	//------------------------------------------------------------------------------------------------
	void MarkRewardReceived(string uid)
	{
		if (uid == "")
			return;
		if (m_RewardedUIDs.Find(uid) != -1)
			return; // deja la
		m_RewardedUIDs.Insert(uid);
		SaveToDisk();
	}
	
	//------------------------------------------------------------------------------------------------
	void SaveToDisk()
	{
		SCR_JsonSaveContext ctx = new SCR_JsonSaveContext();
		ctx.WriteValue("count", m_RewardedUIDs.Count());
		for (int i = 0; i < m_RewardedUIDs.Count(); i++)
		{
			ctx.WriteValue("uid_" + i.ToString(), m_RewardedUIDs.Get(i));
		}
		ctx.SaveToFile(SAVE_PATH);
	}
	
	//------------------------------------------------------------------------------------------------
	void LoadFromDisk()
	{
		SCR_JsonLoadContext ctx = new SCR_JsonLoadContext();
		if (!ctx.LoadFromFile(SAVE_PATH))
			return;
		
		int count = 0;
		ctx.ReadValue("count", count);
		for (int i = 0; i < count; i++)
		{
			string uid = "";
			ctx.ReadValue("uid_" + i.ToString(), uid);
			if (uid != "")
				m_RewardedUIDs.Insert(uid);
		}
		
		Print(string.Format("[JobMayorManager] Charge %1 UIDs ayant recu la recompense", count));
	}
}
