//------------------------------------------------------------------------------------------------
// LP_EpicerieCraftManager.c
// Singleton SERVEUR qui gere les files de craft par joueur.
// Chaque joueur a sa propre file d attente sequentielle (les items se craftent 1 par 1).
//
// FONCTIONNEMENT :
//   - Player clique "Craft" pour une recette :
//     * Serveur verifie job=EPICIER + ingredients presents
//     * Consomme ingredients IMMEDIATEMENT
//     * Ajoute a la file avec timestamp de fin = now + 30s
//   - Tick 1s : verifie chaque file et notifie le client des progressions
//   - Player clique "Recuperer" sur un item termine :
//     * Serveur spawn le prefab resultat dans l inventaire
//     * Retire l entree de la file
//------------------------------------------------------------------------------------------------

class LP_CraftQueueEntry
{
	int m_EntryId;         // id unique dans la file (incremental)
	int m_RecipeId;
	int m_ReadyAtUnix;     // timestamp Unix quand le craft sera pret
	
	void LP_CraftQueueEntry(int entryId, int recipeId, int readyAt)
	{
		m_EntryId = entryId;
		m_RecipeId = recipeId;
		m_ReadyAtUnix = readyAt;
	}
	
	bool IsReady()
	{
		return System.GetUnixTime() >= m_ReadyAtUnix;
	}
	
	int SecondsRemaining()
	{
		int rem = m_ReadyAtUnix - System.GetUnixTime();
		if (rem < 0) return 0;
		return rem;
	}
}

class LP_CraftPlayerQueue
{
	int m_PlayerId;
	int m_NextEntryId = 1;
	ref array<ref LP_CraftQueueEntry> m_Entries = new array<ref LP_CraftQueueEntry>();
}

class LP_EpicerieCraftManager
{
	static ref LP_EpicerieCraftManager s_Instance;
	
	ref map<int, ref LP_CraftPlayerQueue> m_Queues = new map<int, ref LP_CraftPlayerQueue>();
	bool m_TickerStarted = false;
	
	//------------------------------------------------------------------------------------------------
	static LP_EpicerieCraftManager GetInstance()
	{
		if (!s_Instance) s_Instance = new LP_EpicerieCraftManager();
		return s_Instance;
	}
	
	//------------------------------------------------------------------------------------------------
	protected void EnsureTicker()
	{
		if (m_TickerStarted) return;
		m_TickerStarted = true;
		GetGame().GetCallqueue().CallLater(TickAllQueues, 1000, true);
	}
	
	//------------------------------------------------------------------------------------------------
	// Recupere ou cree la file d attente d un joueur
	//------------------------------------------------------------------------------------------------
	protected LP_CraftPlayerQueue GetOrCreateQueue(int playerId)
	{
		LP_CraftPlayerQueue q = m_Queues.Get(playerId);
		if (!q)
		{
			q = new LP_CraftPlayerQueue();
			q.m_PlayerId = playerId;
			m_Queues.Set(playerId, q);
		}
		return q;
	}
	
	//------------------------------------------------------------------------------------------------
	// Ajoute un item a la file. Retourne 0=OK, 1=metier invalide, 2=recette invalide,
	// 3=ingredients manquants, 4=erreur inventaire
	//
	// SEQUENTIEL : le nouveau craft ne commence pas avant que le dernier de la file soit termine.
	//------------------------------------------------------------------------------------------------
	int AddToQueue(int playerId, IEntity playerEnt, int recipeId)
	{
		if (!Replication.IsServer()) return 4;
		if (!playerEnt) return 4;
		
		// Verifie metier EPICIER
		JobCharacterJobComponent jcjc = JobCharacterJobComponent.Cast(
			playerEnt.FindComponent(JobCharacterJobComponent));
		if (!jcjc || jcjc.GetJob() != EJobType.EPICIER) return 1;
		
		// Trouve la recette
		LP_CraftRecipe recipe = LP_EpicerieCraftData.GetRecipeById(recipeId);
		if (!recipe) return 2;
		
		// Verifie ingredients
		if (!HasAllIngredients(playerEnt, recipe)) return 3;
		
		// Consomme les ingredients
		if (!ConsumeIngredients(playerEnt, recipe)) return 4;
		
		// Ajoute a la file (sequentiel : ReadyAt = fin du dernier + 30s)
		LP_CraftPlayerQueue q = GetOrCreateQueue(playerId);
		int now = System.GetUnixTime();
		int startTime = now;
		
		// Si file non vide et dernier item pas encore termine, commence apres lui
		if (q.m_Entries.Count() > 0)
		{
			LP_CraftQueueEntry lastEntry = q.m_Entries[q.m_Entries.Count() - 1];
			if (lastEntry && lastEntry.m_ReadyAtUnix > now)
				startTime = lastEntry.m_ReadyAtUnix;
		}
		
		int readyAt = startTime + LP_EpicerieCraftData.CRAFT_DURATION_S;
		LP_CraftQueueEntry entry = new LP_CraftQueueEntry(q.m_NextEntryId, recipeId, readyAt);
		q.m_NextEntryId = q.m_NextEntryId + 1;
		q.m_Entries.Insert(entry);
		
		EnsureTicker();
		PushQueueUpdate(playerId, playerEnt);
		
		Print(string.Format("[LP_EpicerieCraft] Joueur %1 ajoute recette %2 (entryId=%3, readyAt=%4)",
			playerId.ToString(), recipeId.ToString(), entry.m_EntryId.ToString(),
			readyAt.ToString()), LogLevel.NORMAL);
		
		return 0;
	}
	
	//------------------------------------------------------------------------------------------------
	// Recupere un item termine de la file. Retourne 0=OK, 1=entree introuvable, 2=pas encore prete,
	// 3=erreur spawn
	//------------------------------------------------------------------------------------------------
	int CollectFromQueue(int playerId, IEntity playerEnt, int entryId)
	{
		if (!Replication.IsServer()) return 3;
		if (!playerEnt) return 3;
		
		LP_CraftPlayerQueue q = m_Queues.Get(playerId);
		if (!q) return 1;
		
		int idx = -1;
		for (int i = 0; i < q.m_Entries.Count(); i++)
		{
			if (q.m_Entries[i] && q.m_Entries[i].m_EntryId == entryId)
			{
				idx = i;
				break;
			}
		}
		if (idx < 0) return 1;
		
		LP_CraftQueueEntry entry = q.m_Entries[idx];
		if (!entry.IsReady()) return 2;
		
		LP_CraftRecipe recipe = LP_EpicerieCraftData.GetRecipeById(entry.m_RecipeId);
		if (!recipe) return 3;
		
		// Spawn item dans l inventaire du joueur (pattern eprouve du mod)
		SCR_InventoryStorageManagerComponent inv = SCR_InventoryStorageManagerComponent.Cast(
			playerEnt.FindComponent(SCR_InventoryStorageManagerComponent));
		if (!inv) return 3;
		
		ResourceName rn = recipe.m_ResultPrefab;
		bool ok = inv.TrySpawnPrefabToStorage(rn);
		if (!ok) return 3;
		
		// Retire de la file
		q.m_Entries.Remove(idx);
		PushQueueUpdate(playerId, playerEnt);
		
		Print(string.Format("[LP_EpicerieCraft] Joueur %1 recupere entry %2 (recette %3)",
			playerId.ToString(), entryId.ToString(), entry.m_RecipeId.ToString()),
			LogLevel.NORMAL);
		return 0;
	}
	
	//------------------------------------------------------------------------------------------------
	// Retourne l etat de la file d un joueur pour l UI :
	// arrays paralleles : entryIds, recipeIds, secondsRemaining
	//------------------------------------------------------------------------------------------------
	void GetQueueSnapshot(int playerId, out array<int> outEntryIds, out array<int> outRecipeIds,
		out array<int> outSecondsRemaining)
	{
		LP_CraftPlayerQueue q = m_Queues.Get(playerId);
		if (!q) return;
		foreach (LP_CraftQueueEntry e : q.m_Entries)
		{
			if (!e) continue;
			outEntryIds.Insert(e.m_EntryId);
			outRecipeIds.Insert(e.m_RecipeId);
			outSecondsRemaining.Insert(e.SecondsRemaining());
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Tick 1s : push l etat de chaque file a son joueur
	//------------------------------------------------------------------------------------------------
	void TickAllQueues()
	{
		foreach (int pid, LP_CraftPlayerQueue q : m_Queues)
		{
			if (!q || q.m_Entries.Count() == 0) continue;
			
			IEntity playerEnt = GetGame().GetPlayerManager().GetPlayerControlledEntity(pid);
			if (!playerEnt) continue;
			
			PushQueueUpdate(pid, playerEnt);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Push l etat de la file a un joueur specifique via son JobPlayerComponent
	//------------------------------------------------------------------------------------------------
	protected void PushQueueUpdate(int playerId, IEntity playerEnt)
	{
		if (!playerEnt) return;
		
		PlayerController pc = GetGame().GetPlayerManager().GetPlayerController(playerId);
		if (!pc) return;
		
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		
		array<int> entryIds = new array<int>();
		array<int> recipeIds = new array<int>();
		array<int> secondsRem = new array<int>();
		GetQueueSnapshot(playerId, entryIds, recipeIds, secondsRem);
		
		jpc.ServerEpicerieCraftPushQueue(entryIds, recipeIds, secondsRem);
	}
	
	//------------------------------------------------------------------------------------------------
	// Compte les items d un prefab dans l inventaire du joueur
	//------------------------------------------------------------------------------------------------
	protected int CountItemInInventory(IEntity playerEnt, string prefabName)
	{
		SCR_InventoryStorageManagerComponent inv = SCR_InventoryStorageManagerComponent.Cast(
			playerEnt.FindComponent(SCR_InventoryStorageManagerComponent));
		if (!inv) return 0;
		
		array<IEntity> items = new array<IEntity>();
		inv.GetItems(items);
		
		int count = 0;
		foreach (IEntity item : items)
		{
			if (!item) continue;
			EntityPrefabData pd = item.GetPrefabData();
			if (!pd) continue;
			if (pd.GetPrefabName() == prefabName)
				count = count + 1;
		}
		return count;
	}
	
	//------------------------------------------------------------------------------------------------
	// Verifie que le joueur a TOUS les ingredients d une recette
	//------------------------------------------------------------------------------------------------
	protected bool HasAllIngredients(IEntity playerEnt, LP_CraftRecipe recipe)
	{
		foreach (LP_CraftIngredient ing : recipe.m_Ingredients)
		{
			if (!ing) continue;
			if (CountItemInInventory(playerEnt, ing.m_Prefab) < ing.m_Quantity)
				return false;
		}
		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	// Consomme les ingredients d une recette (delete les N premiers items de chaque type)
	//------------------------------------------------------------------------------------------------
	protected bool ConsumeIngredients(IEntity playerEnt, LP_CraftRecipe recipe)
	{
		SCR_InventoryStorageManagerComponent inv = SCR_InventoryStorageManagerComponent.Cast(
			playerEnt.FindComponent(SCR_InventoryStorageManagerComponent));
		if (!inv) return false;
		
		foreach (LP_CraftIngredient ing : recipe.m_Ingredients)
		{
			if (!ing) continue;
			int toRemove = ing.m_Quantity;
			array<IEntity> items = new array<IEntity>();
			inv.GetItems(items);
			
			foreach (IEntity item : items)
			{
				if (toRemove <= 0) break;
				if (!item) continue;
				EntityPrefabData pd = item.GetPrefabData();
				if (!pd) continue;
				if (pd.GetPrefabName() == ing.m_Prefab)
				{
					SCR_EntityHelper.DeleteEntityAndChildren(item);
					toRemove = toRemove - 1;
				}
			}
			if (toRemove > 0)
			{
				Print(string.Format("[LP_EpicerieCraft] ATTENTION : conso incomplete %1 manquant(s) pour %2",
					toRemove.ToString(), ing.m_Prefab), LogLevel.WARNING);
			}
		}
		return true;
	}
}
