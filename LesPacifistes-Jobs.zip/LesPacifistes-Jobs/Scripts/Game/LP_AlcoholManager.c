//------------------------------------------------------------------------------------------------
// LP_AlcoholManager.c
// Singleton SERVEUR qui gere le taux d alcool par joueur (0 - 100 %).
//
// COMPORTEMENT :
//  - Le joueur boit -> ServerAddAlcohol(playerId, amount) ajoute au taux (max 100)
//  - Toutes les 500ms, degrisement naturel de 0.05 pt (soit 6 pts/min = ~17 min pour cuver de 100)
//  - Le taux est pushe au client concerne via LP_AlcoholPlayerComponent (RPC Owner)
//  - Au niveau 100% : le joueur devient inconscient (via SCR_CharacterDamageManagerComponent)
//  - Le taux est reset apres inconscience pour eviter la boucle
//
// PERSISTANCE : aucune (au reboot, tout le monde est sobre)
//------------------------------------------------------------------------------------------------

class LP_AlcoholManager
{
	static ref LP_AlcoholManager s_Instance;
	
	// Map playerId -> alcohol level (0 - 100)
	ref map<int, float> m_AlcoholLevels = new map<int, float>();
	
	// Constantes reglables
	const float MAX_ALCOHOL = 100.0;
	const float SOBER_RATE_PER_TICK = 0.05;      // par tick 500ms = 6 pts / min
	const float UNCONSCIOUS_THRESHOLD = 100.0;   // niveau qui declenche l inconscience
	const float SLOWDOWN_THRESHOLD = 40.0;       // niveau au dela duquel le joueur ralentit
	const int TICK_INTERVAL_MS = 500;
	
	bool m_TickerStarted = false;
	
	//------------------------------------------------------------------------------------------------
	static LP_AlcoholManager GetInstance()
	{
		if (!s_Instance) s_Instance = new LP_AlcoholManager();
		return s_Instance;
	}
	
	//------------------------------------------------------------------------------------------------
	void EnsureTicker()
	{
		if (m_TickerStarted) return;
		m_TickerStarted = true;
		GetGame().GetCallqueue().CallLater(TickAll, TICK_INTERVAL_MS, true);
		Print("[LP_AlcoholManager] Ticker degrisement demarre.", LogLevel.NORMAL);
	}
	
	//------------------------------------------------------------------------------------------------
	// Ajoute du taux d alcool a un joueur (appele par LP_DrinkAlcoholAction)
	//------------------------------------------------------------------------------------------------
	void ServerAddAlcohol(int playerId, float amount)
	{
		if (!Replication.IsServer()) return;
		if (playerId <= 0) return;
		
		float current = 0;
		if (m_AlcoholLevels.Contains(playerId))
			current = m_AlcoholLevels.Get(playerId);
		
		current = current + amount;
		if (current > MAX_ALCOHOL) current = MAX_ALCOHOL;
		if (current < 0) current = 0;
		
		m_AlcoholLevels.Set(playerId, current);

		Print(string.Format("[LP_AlcoholManager] Player %1 : niveau alcool %2%% (+%3)",
			playerId.ToString(), current.ToString(), amount.ToString()), LogLevel.NORMAL);

		PushToClient(playerId, current);
		EnsureTicker();

		// FIX : declenchement IMMEDIAT de l inconscience si on atteint le seuil
		// (sans attendre le prochain tick, sinon le degrisement passe le niveau sous 100)
		if (current >= UNCONSCIOUS_THRESHOLD)
			ForceUnconscious(playerId);
	}
	
	//------------------------------------------------------------------------------------------------
	// Force un taux d alcool (admin ou reset apres inconscience)
	//------------------------------------------------------------------------------------------------
	void SetAlcohol(int playerId, float value)
	{
		if (!Replication.IsServer()) return;
		if (playerId <= 0) return;
		if (value < 0) value = 0;
		if (value > MAX_ALCOHOL) value = MAX_ALCOHOL;
		m_AlcoholLevels.Set(playerId, value);
		PushToClient(playerId, value);
		if (value > 0) EnsureTicker();
	}
	
	//------------------------------------------------------------------------------------------------
	float GetAlcohol(int playerId)
	{
		if (!m_AlcoholLevels.Contains(playerId)) return 0;
		return m_AlcoholLevels.Get(playerId);
	}
	
	//------------------------------------------------------------------------------------------------
	// Envoi du niveau au client concerne via RPC Owner
	//------------------------------------------------------------------------------------------------
	protected void PushToClient(int playerId, float level)
	{
		PlayerController pc = GetGame().GetPlayerManager().GetPlayerController(playerId);
		if (!pc) return;
		LP_AlcoholPlayerComponent apc = LP_AlcoholPlayerComponent.Cast(
			pc.FindComponent(LP_AlcoholPlayerComponent));
		if (apc) apc.ServerPushLevel(level);
	}
	
	//------------------------------------------------------------------------------------------------
	// Tick 500ms : degrisement + effets par joueur
	//------------------------------------------------------------------------------------------------
	void TickAll()
	{
		if (!Replication.IsServer()) return;
		if (m_AlcoholLevels.Count() == 0) return;
		
		array<int> toRemove = new array<int>();
		array<int> playerIds = new array<int>();
		foreach (int pid, float lvl : m_AlcoholLevels) playerIds.Insert(pid);
		
		foreach (int playerId : playerIds)
		{
			float level = m_AlcoholLevels.Get(playerId);

			// FIX : verifie le seuil unconscious AVANT le degrisement
			// (sinon le level tombe a 99.95 juste avant le check et rate le trigger)
			if (level >= UNCONSCIOUS_THRESHOLD)
			{
				ForceUnconscious(playerId);
				continue;
			}

			// Applique l effet sang selon le niveau (ralentissement progressif du joueur)
			// Reforger ralentit naturellement les personnages avec peu de sang
			ApplyBloodEffect(playerId, level);

			// Degrisement naturel
			level = level - SOBER_RATE_PER_TICK;
			if (level <= 0)
			{
				toRemove.Insert(playerId);
				continue;
			}
			m_AlcoholLevels.Set(playerId, level);

			// Push le nouveau niveau au client (HUD update)
			PushToClient(playerId, level);
		}
		
		// Cleanup joueurs revenus a 0 (sobres)
		foreach (int rid : toRemove)
		{
			m_AlcoholLevels.Remove(rid);
			PushToClient(rid, 0);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Applique un effet de ralentissement en abaissant artificiellement le sang du joueur.
	// Reforger ralentit naturellement les personnages avec peu de sang :
	//  -  25-49% alcool : sang cap a 75% (leger ralentissement)
	//  -  50-69% alcool : sang cap a 50% (plus de course - marche seulement)
	//  -  70-89% alcool : sang cap a 30% (tres lent, titube)
	//  -  90-99% alcool : sang cap a 18% (quasi immobile)
	// Le sang n est baisse que si le joueur en a PLUS que le target (pas de "soin" involontaire).
	//------------------------------------------------------------------------------------------------
	protected void ApplyBloodEffect(int playerId, float alcoholLevel)
	{
		if (alcoholLevel < 25.0) return;  // pas d effet en dessous de 25%
		
		PlayerController pc = GetGame().GetPlayerManager().GetPlayerController(playerId);
		if (!pc) return;
		IEntity character = pc.GetControlledEntity();
		if (!character) return;
		
		SCR_CharacterDamageManagerComponent dmg = SCR_CharacterDamageManagerComponent.Cast(
			character.FindComponent(SCR_CharacterDamageManagerComponent));
		if (!dmg) return;
		
		HitZone bloodHZ = dmg.GetBloodHitZone();
		if (!bloodHZ) return;
		
		float bloodMax = bloodHZ.GetMaxHealth();
		if (bloodMax <= 0) return;
		
		// Calcule le cap de sang selon le niveau d alcool
		// SANG >= 40% en permanence pour eviter unconscious involontaire.
		// Seul 100% d alcool est autorise a descendre le sang plus bas (via ForceUnconscious).
		float targetPct = 1.0;
		if (alcoholLevel >= 90.0) targetPct = 0.42;      // proche du minimum safe
		else if (alcoholLevel >= 70.0) targetPct = 0.48;
		else if (alcoholLevel >= 50.0) targetPct = 0.55;
		else if (alcoholLevel >= 25.0) targetPct = 0.70;

		float targetBlood = bloodMax * targetPct;
		float currentBlood = bloodHZ.GetHealth();

		// Ne descend le sang QUE s il est au dessus du target (pas de "soin" involontaire)
		// IMPORTANT : descend PROGRESSIVEMENT (max 3% du max par tick de 500ms).
		// Une chute brutale (ex: 100% -> 50% d un coup) est interpretee par Reforger
		// comme une hemorragie soudaine et declenche unconscious involontaire.
		// Avec 3% par tick, passer de 100% a 50% prend ~8 secondes = pas de trigger.
		if (currentBlood > targetBlood)
		{
			float maxDropPerTick = bloodMax * 0.03;  // 3% du max par tick
			float newBlood = currentBlood - maxDropPerTick;
			if (newBlood < targetBlood) newBlood = targetBlood;
			bloodHZ.SetHealth(newBlood);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Force le joueur en etat inconscient via chute du SANG a 10 %.
	// En Reforger, l inconscient se declenche via le sang (pas la vie) : quand le sang tombe
	// tres bas, le personnage perd connaissance automatiquement.
	// API : dmg.GetBloodHitZone().SetHealth(maxBlood * 0.10)
	//------------------------------------------------------------------------------------------------
	protected void ForceUnconscious(int playerId)
	{
		PlayerController pc = GetGame().GetPlayerManager().GetPlayerController(playerId);
		if (!pc) return;
		IEntity character = pc.GetControlledEntity();
		if (!character) return;

		SCR_CharacterDamageManagerComponent dmg = SCR_CharacterDamageManagerComponent.Cast(
			character.FindComponent(SCR_CharacterDamageManagerComponent));
		if (!dmg)
		{
			Print(string.Format("[LP_AlcoholManager] Player %1 : SCR_CharacterDamageManagerComponent introuvable !",
				playerId.ToString()), LogLevel.ERROR);
			return;
		}
		
		// Recupere la hitzone du sang et descend son niveau a 10%
		HitZone bloodHZ = dmg.GetBloodHitZone();
		if (!bloodHZ)
		{
			Print(string.Format("[LP_AlcoholManager] Player %1 : BloodHitZone introuvable !",
				playerId.ToString()), LogLevel.ERROR);
			return;
		}
		
		float bloodMax = bloodHZ.GetMaxHealth();
		float targetBlood = bloodMax * 0.30;  // 30% du sang max = declenche unconscious sur ce serveur
		bloodHZ.SetHealth(targetBlood);

		Print(string.Format("[LP_AlcoholManager] Player %1 : ALCOOL 100%% - sang %2/%3 (30%%) - inconscient force !",
			playerId.ToString(), targetBlood.ToString(), bloodMax.ToString()), LogLevel.WARNING);

		// Reset alcohol pour eviter re-declenchement au tick suivant
		SetAlcohol(playerId, 0);
	}
	
	//------------------------------------------------------------------------------------------------
	// A appeler quand un joueur se deconnecte (cleanup)
	//------------------------------------------------------------------------------------------------
	void OnPlayerDisconnect(int playerId)
	{
		if (m_AlcoholLevels.Contains(playerId))
			m_AlcoholLevels.Remove(playerId);
	}
}