//------------------------------------------------------------------------------------------------
// JobCompanyAccessAction.c
// Action UserAction "Acces entreprise" sur les PNJ metiers (Mineur, Agriculteur, Bucheron,
// Concessionnaire, Vendeur Immobilier). Placee identiquement sur les 5 PNJ.
//
// Le filtrage (l joueur est-il patron ou employe d une entreprise de CE metier ?) est
// fait cote serveur dans RpcAsk_OpenCompanyAccess via le JobCompanyManager.
//
// Le metier du PNJ est determine cote serveur via le JobPlayerComponent du joueur (le
// player vient au bon PNJ : si on est mineur on va chez PNJ Mineur).
//------------------------------------------------------------------------------------------------

class JobCompanyAccessAction : ScriptedUserAction
{
	// Le boss peut soit hardcoder un metier dans le prefab via attribut, soit faire l action
	// generique cote serveur (la V1 le fait generique : verification via metier du joueur).
	[Attribute(defvalue: "0", desc: "Type de metier de ce PNJ (0=MINEUR, 1=AGRICULTEUR, ...) - si on veut filtrer cote action")]
	int m_PNJJobType;
	
	//------------------------------------------------------------------------------------------------
	override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
	{
		if (!pOwnerEntity)
			return;
		
		// IMPORTANT (dedicated server) : filtrer pour que seul le joueur local agisse
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc)
			return;
		if (pUserEntity != pc.GetControlledEntity())
			return;
		
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc)
			return;
		
		jpc.ClientAskOpenCompanyAccess();
	}
	
	//------------------------------------------------------------------------------------------------
	override bool GetActionNameScript(out string outName)
	{
		outName = "Acces entreprise";
		return true;
	}
}
