//------------------------------------------------------------------------------------------------
// JobLockHospitalDoorAction.c
// Action UserAction "Verrouiller" sur les portes de l hopital.
// Visible uniquement si :
//   - Le joueur local est MEDECIN (via JobCharacterJobComponent)
//   - La porte est actuellement DEVERROUILLEE (via JobHospitalDoorComponent.m_Locked)
//
// Le verrouillage se fait cote serveur via JobHospitalDoorComponent.ServerSetLocked(true).
//------------------------------------------------------------------------------------------------

class JobLockHospitalDoorAction : ScriptedUserAction
{
	//------------------------------------------------------------------------------------------------
	override bool CanBeShownScript(IEntity user)
	{
		if (!user)
			return false;
		
		// Verifie le metier du joueur LOCAL via JobCharacterJobComponent (sur son character)
		JobCharacterJobComponent localJobComp = JobCharacterJobComponent.Cast(
			user.FindComponent(JobCharacterJobComponent));
		if (!localJobComp)
			return false;
		EJobType localJob = localJobComp.GetJob();
		if (localJob != EJobType.MEDECIN)
			return false;
		
		// Verifie l etat de la porte : visible UNIQUEMENT si deverrouillee
		IEntity door = GetOwner();
		if (!door)
			return false;
		JobHospitalDoorComponent doorComp = JobHospitalDoorComponent.Cast(
			door.FindComponent(JobHospitalDoorComponent));
		if (!doorComp)
			return false;
		return !doorComp.IsLocked();
	}
	
	//------------------------------------------------------------------------------------------------
	override bool CanBePerformedScript(IEntity user)
	{
		return CanBeShownScript(user);
	}
	
	//------------------------------------------------------------------------------------------------
	override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
	{
		if (!pOwnerEntity)
			return;
		
		// IMPORTANT (dedicated server) : PerformAction s execute sur TOUS les clients qui
		// voient l action localement, pas uniquement sur celui qui a clique. On filtre pour
		// que seul le joueur local qui controle pUserEntity envoie effectivement la RPC.
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc)
			return;
		if (pUserEntity != pc.GetControlledEntity())
			return;
		
		// La logique de verrouillage tourne cote serveur. Sur dedicated server, PerformAction
		// s execute cote client donc on doit envoyer une RPC au serveur via le JobPlayerComponent.
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc)
			return;
		
		RplComponent rpl = RplComponent.Cast(pOwnerEntity.FindComponent(RplComponent));
		if (!rpl)
			return;
		jpc.ClientAskToggleHospitalDoor(rpl.Id(), true);  // true = lock
	}
	
	//------------------------------------------------------------------------------------------------
	override bool GetActionNameScript(out string outName)
	{
		outName = "Verrouiller la porte";
		return true;
	}
}
