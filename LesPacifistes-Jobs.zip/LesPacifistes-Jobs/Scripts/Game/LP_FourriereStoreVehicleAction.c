//------------------------------------------------------------------------------------------------
// LP_FourriereStoreVehicleAction.c
// Action F sur un vehicule : "Deposer a la fourriere".
//
// Visible UNIQUEMENT pour les joueurs metier FOURRIERE. A placer sur l ActionsManagerComponent
// du PNJ Fourriere (ou separement). Le vehicule le plus proche du PNJ est stocke dans le
// garage virtuel partage Fourriere.
//
// Techniquement : le serveur appelle JobVirtualGarageManager.StoreVehicleNearPos avec le
// owner UID special "FOURRIERE_SHARED". Tous les joueurs Fourriere y ont acces.
//------------------------------------------------------------------------------------------------

class LP_FourriereStoreVehicleAction : ScriptedUserAction
{
	//------------------------------------------------------------------------------------------------
	override bool CanBeShownScript(IEntity user)
	{
		if (!user) return false;

		PlayerController pc = GetGame().GetPlayerController();
		if (!pc)
			return false;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc)
			return false;
		return jpc.GetJob() == EJobType.FOURRIERE;
	}

	//------------------------------------------------------------------------------------------------
	override bool CanBePerformedScript(IEntity user)
	{
		return CanBeShownScript(user);
	}

	//------------------------------------------------------------------------------------------------
	override bool GetActionNameScript(out string outName)
	{
		outName = "Deposer un vehicule a la fourriere";
		return true;
	}

	//------------------------------------------------------------------------------------------------
	override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
	{
		if (!pOwnerEntity || !pUserEntity)
			return;

		PlayerController localPC = GetGame().GetPlayerController();
		if (!localPC)
			return;
		IEntity localEntity = localPC.GetControlledEntity();
		if (localEntity != pUserEntity)
			return;

		RplComponent rpl = RplComponent.Cast(pOwnerEntity.FindComponent(RplComponent));
		if (!rpl)
			return;
		RplId npcRplId = rpl.Id();

		JobPlayerComponent jpc = JobPlayerComponent.Cast(localPC.FindComponent(JobPlayerComponent));
		if (!jpc)
			return;

		jpc.ClientAskFourriereStoreVehicle(npcRplId);
	}
}
