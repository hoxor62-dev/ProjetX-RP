//------------------------------------------------------------------------------------------------
// JobAtmAction.c
// UserAction "Utiliser l'ATM" - ouvre le JobAtmMenu pour transferer des capsules
//------------------------------------------------------------------------------------------------

class JobAtmAction : ScriptedUserAction
{
	//------------------------------------------------------------------------------------------------
	override bool CanBeShownScript(IEntity user)
	{
		JobAtmComponent atm = JobAtmComponent.Cast(GetOwner().FindComponent(JobAtmComponent));
		return (atm != null);
	}
	
	//------------------------------------------------------------------------------------------------
	override bool CanBePerformedScript(IEntity user)
	{
		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	override bool GetActionNameScript(out string outName)
	{
		outName = "Utiliser l'ATM";
		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
	{
		// GARDE MULTIJOUEUR: n'ouvre le menu que pour le joueur local
		IEntity localPlayer = SCR_PlayerController.GetLocalControlledEntity();
		if (!localPlayer || pUserEntity != localPlayer)
			return;
		
		// Ouvre le menu ATM
		JobAtmMenu menu = JobAtmMenu.Cast(GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.JobAtmMenu));
		if (menu)
			menu.Initialize();
	}
}
