//------------------------------------------------------------------------------------------------
// LP_VehicleRentalHudComponent.c
// Composant client-side attache au SCR_PlayerController.
// Detecte quand le joueur local est CONDUCTEUR d un vehicule de LOCATION et affiche
// un HUD centre en haut (sous le HUD Assurance) avec le compte a rebours de la location.
// Le HUD est persistent tant que le joueur reste au volant, et disparait a la sortie.
//
// Optimisation : le client demande UNE FOIS le m_EndUnix au serveur quand il entre dans
// un vehicule de location, puis calcule localement le temps restant chaque seconde.
// Recheck serveur toutes les 30s au cas ou une prolongation aurait eu lieu.
//------------------------------------------------------------------------------------------------

[ComponentEditorProps(category: "LesPacifistes", description: "HUD compte a rebours vehicule de location (conducteur)")]
class LP_VehicleRentalHudComponentClass : ScriptComponentClass
{
}

class LP_VehicleRentalHudComponent : ScriptComponent
{
	const string HUD_LAYOUT_PATH = "UI/layouts/LP_VehicleRentalHud.layout";
	
	// Frequence detection de vehicule (ms)
	const int CHECK_INTERVAL_MS = 1000;
	
	// Frequence de recheck serveur (au cas ou prolongation)
	const int SERVER_RECHECK_INTERVAL_S = 30;
	
	// Widget HUD
	Widget m_HudRoot;
	TextWidget m_RentalText;
	ImageWidget m_BorderTop;
	ImageWidget m_BorderBottom;
	
	// Etat courant
	IEntity m_CurrentVehicle;         // vehicule dans lequel on est conducteur (null sinon)
	int m_LastQueryVehicleRplId = 0;  // pour eviter les queries redondantes
	int m_CachedEndUnix = 0;          // 0 = pas une location, sinon timestamp de fin
	int m_LastServerRecheckUnix = 0;  // timestamp du dernier recheck serveur
	string m_LastDisplayed = "";      // pour eviter les SetText redondants
	
	// Instance locale (accessible depuis JobPlayerComponent pour router RPC)
	static LP_VehicleRentalHudComponent s_LocalInstance;
	
	//------------------------------------------------------------------------------------------------
	override void OnPostInit(IEntity owner)
	{
		super.OnPostInit(owner);
		if (Replication.IsServer() && !Replication.IsClient())
			return;
		
		GetGame().GetCallqueue().CallLater(SetupLocalHud, 3000, false);
	}
	
	//------------------------------------------------------------------------------------------------
	void SetupLocalHud()
	{
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		
		// Uniquement sur le PlayerController LOCAL
		if (pc.GetPlayerId() != GetGame().GetPlayerController().GetPlayerId())
			return;
		
		s_LocalInstance = this;
		
		CreateHudWidget();
		GetGame().GetCallqueue().CallLater(CheckLoop, CHECK_INTERVAL_MS, true);
	}
	
	//------------------------------------------------------------------------------------------------
	void CreateHudWidget()
	{
		WorkspaceWidget ws = GetGame().GetWorkspace();
		if (!ws) return;
		
		m_HudRoot = ws.CreateWidgets(HUD_LAYOUT_PATH);
		if (!m_HudRoot) return;
		
		m_RentalText = TextWidget.Cast(m_HudRoot.FindAnyWidget("RentalText"));
		m_BorderTop = ImageWidget.Cast(m_HudRoot.FindAnyWidget("RentalBorderTop"));
		m_BorderBottom = ImageWidget.Cast(m_HudRoot.FindAnyWidget("RentalBorderBottom"));
		
		m_HudRoot.SetVisible(false);
	}
	
	//------------------------------------------------------------------------------------------------
	// Boucle appelee toutes les CHECK_INTERVAL_MS
	//------------------------------------------------------------------------------------------------
	void CheckLoop()
	{
		IEntity vehicle = GetVehicleAsDriver();
		
		// Cas 1 : pas au volant -> reset et masquer HUD
		if (!vehicle)
		{
			if (m_CurrentVehicle)
			{
				m_CurrentVehicle = null;
				m_LastQueryVehicleRplId = 0;
				m_CachedEndUnix = 0;
				m_LastDisplayed = "";
				if (m_HudRoot) m_HudRoot.SetVisible(false);
			}
			return;
		}
		
		// Cas 2 : nouveau vehicule -> reset + demande serveur
		if (vehicle != m_CurrentVehicle)
		{
			m_CurrentVehicle = vehicle;
			m_CachedEndUnix = 0;
			m_LastDisplayed = "";
			if (m_HudRoot) m_HudRoot.SetVisible(false);
			QueryServerForRentalInfo(vehicle);
			return;
		}
		
		// Cas 3 : meme vehicule que precedemment
		// - Si connu comme non-location -> rien a faire
		// - Si location -> tick local + eventuellement recheck serveur
		if (m_CachedEndUnix > 0)
		{
			int nowUnix = System.GetUnixTime();
			
			// Recheck serveur periodique (en cas de prolongation)
			if (nowUnix - m_LastServerRecheckUnix >= SERVER_RECHECK_INTERVAL_S)
				QueryServerForRentalInfo(vehicle);
			
			// Tick local : rafraichit le texte du compte a rebours
			UpdateCountdownDisplay(nowUnix);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Envoie un RPC au serveur pour connaitre le m_EndUnix du vehicule.
	//------------------------------------------------------------------------------------------------
	void QueryServerForRentalInfo(IEntity vehicle)
	{
		if (!vehicle) return;
		
		RplComponent rpl = RplComponent.Cast(vehicle.FindComponent(RplComponent));
		if (!rpl)
		{
			return;
		}
		int rplIdInt = Replication.FindId(rpl);
		if (rplIdInt == 0)
		{
			return;
		}
		
		
		m_LastQueryVehicleRplId = rplIdInt;
		m_LastServerRecheckUnix = System.GetUnixTime();
		
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		jpc.ClientAskVehicleRental(rplIdInt);
	}
	
	//------------------------------------------------------------------------------------------------
	// Retourne le vehicule dont le joueur local est CONDUCTEUR, ou null.
	//------------------------------------------------------------------------------------------------
	IEntity GetVehicleAsDriver()
	{
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return null;
		IEntity character = pc.GetControlledEntity();
		if (!character) return null;
		
		CompartmentAccessComponent cac = CompartmentAccessComponent.Cast(
			character.FindComponent(CompartmentAccessComponent));
		if (!cac) return null;
		
		BaseCompartmentSlot slot = cac.GetCompartment();
		if (!slot) return null;
		
		PilotCompartmentSlot pilotSlot = PilotCompartmentSlot.Cast(slot);
		if (!pilotSlot) return null;
		
		return slot.GetOwner();
	}
	
	//------------------------------------------------------------------------------------------------
	// Appele par JobPlayerComponent quand la reponse du serveur arrive.
	// endUnix = 0 si le vehicule n est PAS une location (aucun HUD affiche)
	// endUnix > 0 = timestamp Unix de fin de location
	//------------------------------------------------------------------------------------------------
	void OnRentalInfoReceived(int vehicleRplId, int endUnix)
	{
		
		// Verifie que la reponse concerne le vehicule qu on regarde encore
		if (vehicleRplId != m_LastQueryVehicleRplId)
		{
			return;
		}
		if (!m_CurrentVehicle)
		{
			return;
		}
		
		m_CachedEndUnix = endUnix;
		
		if (endUnix <= 0)
		{
			if (m_HudRoot) m_HudRoot.SetVisible(false);
			return;
		}
		
		UpdateCountdownDisplay(System.GetUnixTime());
	}
	
	//------------------------------------------------------------------------------------------------
	// Met a jour le texte du HUD selon le temps restant.
	// Format : "Location : MM:SS" ou "Location : Hh MMm" au-dela d 1h
	// Couleur : bleu clair par defaut, orange < 10 min, rouge < 5 min
	//------------------------------------------------------------------------------------------------
	void UpdateCountdownDisplay(int nowUnix)
	{
		if (!m_HudRoot || !m_RentalText) return;
		if (m_CachedEndUnix <= 0) return;
		
		int remaining = m_CachedEndUnix - nowUnix;
		if (remaining < 0) remaining = 0;
		
		string label = FormatRemaining(remaining);
		
		// Evite les SetText redondants
		if (label != m_LastDisplayed)
		{
			m_RentalText.SetText(label);
			m_LastDisplayed = label;
		}
		
		// Couleur adaptative selon le temps restant
		Color textColor;
		Color borderColor;
		if (remaining <= 0)
		{
			textColor = Color.FromRGBA(230, 70, 70, 255);   // rouge
			borderColor = Color.FromRGBA(230, 70, 70, 255);
		}
		else if (remaining < 300)  // < 5 min
		{
			textColor = Color.FromRGBA(255, 100, 100, 255); // rouge clair
			borderColor = Color.FromRGBA(255, 100, 100, 255);
		}
		else if (remaining < 600)  // < 10 min
		{
			textColor = Color.FromRGBA(255, 170, 70, 255);  // orange
			borderColor = Color.FromRGBA(255, 170, 70, 255);
		}
		else
		{
			textColor = Color.FromRGBA(230, 240, 255, 255); // bleu tres clair
			borderColor = Color.FromRGBA(75, 190, 255, 255); // bleu
		}
		m_RentalText.SetColor(textColor);
		if (m_BorderTop) m_BorderTop.SetColor(borderColor);
		if (m_BorderBottom) m_BorderBottom.SetColor(borderColor);
		
		m_HudRoot.SetVisible(true);
	}
	
	//------------------------------------------------------------------------------------------------
	// Formatte un nombre de secondes en label FR.
	// < 60 min : "Location : MM:SS"
	// >= 60 min : "Location : Xh MMm"
	// Expire : "Location EXPIREE"
	//------------------------------------------------------------------------------------------------
	string FormatRemaining(int seconds)
	{
		if (seconds <= 0)
			return "Location EXPIREE";
		
		if (seconds < 3600)
		{
			int m = seconds / 60;
			int s = seconds - m * 60;
			string mStr = m.ToString();
			string sStr = s.ToString();
			if (m < 10) mStr = "0" + mStr;
			if (s < 10) sStr = "0" + sStr;
			return "Location : " + mStr + ":" + sStr;
		}
		
		int h = seconds / 3600;
		int rem = seconds - h * 3600;
		int mm = rem / 60;
		string mmStr = mm.ToString();
		if (mm < 10) mmStr = "0" + mmStr;
		return string.Format("Location : %1h %2m", h, mmStr);
	}
	
	//------------------------------------------------------------------------------------------------
	static LP_VehicleRentalHudComponent GetLocalInstance()
	{
		return s_LocalInstance;
	}
}
