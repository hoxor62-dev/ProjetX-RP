//------------------------------------------------------------------------------------------------
// LP_AlcoholPlayerComponent.c
// Component a placer sur le prefab PlayerController (Chimera / SCR).
// Sert de passerelle RPC : le serveur push le niveau d alcool au client owner uniquement,
// et le client relaie au HUD LP_AlcoholHUD.
//
// EFFET RALENTISSEMENT :
//  - Cote client : SetDynamicSpeed cap la vitesse de walk (jog).
//    Note : SetDynamicSpeed ne bloque PAS le sprint - il ne fait que capper le walk.
//    Semantique verifiee empiriquement : valeur PLUS BASSE = plus LENT.
//------------------------------------------------------------------------------------------------

class LP_AlcoholPlayerComponentClass : ScriptComponentClass
{
}

class LP_AlcoholPlayerComponent : ScriptComponent
{
	// Cache client : niveau actuel connu localement
	protected float m_ClientAlcoholLevel = 0;
	
	//------------------------------------------------------------------------------------------------
	static LP_AlcoholPlayerComponent GetLocal()
	{
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return null;
		return LP_AlcoholPlayerComponent.Cast(pc.FindComponent(LP_AlcoholPlayerComponent));
	}
	
	//------------------------------------------------------------------------------------------------
	float GetLocalLevel() { return m_ClientAlcoholLevel; }
	
	//------------------------------------------------------------------------------------------------
	// Serveur -> pousse le niveau au client owner
	//------------------------------------------------------------------------------------------------
	void ServerPushLevel(float level)
	{
		if (!Replication.IsServer()) return;
		Rpc(RpcDo_PushLevel, level);
	}
	
	//------------------------------------------------------------------------------------------------
	// Cote client : recoit le niveau et notifie le HUD + applique ralentissement walk
	//------------------------------------------------------------------------------------------------
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	protected void RpcDo_PushLevel(float level)
	{
		m_ClientAlcoholLevel = level;
		
		LP_AlcoholHUD hud = LP_AlcoholHUD.GetInstance();
		if (hud) hud.UpdateLevel(level);
		
		// Ralentit le walk cote client via SCR_CharacterControllerComponent.SetDynamicSpeed()
		ApplyMovementSpeedEffect(level);
	}
	
	//------------------------------------------------------------------------------------------------
	// Cote client : cap la vitesse de walk (pas le sprint).
	// Semantique testee : valeur plus BASSE = walk plus LENT.
	//  - 0    : pas de cap (walk normal)
	//  - 0.85 : leger ralentissement
	//  - 0.65 : marche plus lente
	//  - 0.45 : marche lente
	//  - 0.25 : marche tres lente (titubante)
	//------------------------------------------------------------------------------------------------
	protected void ApplyMovementSpeedEffect(float alcoholLevel)
	{
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return;
		IEntity character = pc.GetControlledEntity();
		if (!character) return;
		
		SCR_CharacterControllerComponent ccc = SCR_CharacterControllerComponent.Cast(
			character.FindComponent(SCR_CharacterControllerComponent));
		if (!ccc) return;
		
		float dynamicSpeed = 0;  // 0 = pas de cap (walk normal)
		
		if (alcoholLevel >= 90.0)
			dynamicSpeed = 0.25;  // walk tres lent (titube)
		else if (alcoholLevel >= 70.0)
			dynamicSpeed = 0.45;  // walk lent
		else if (alcoholLevel >= 50.0)
			dynamicSpeed = 0.65;  // walk plus lent
		else if (alcoholLevel >= 25.0)
			dynamicSpeed = 0.85;  // leger ralentissement
		
		ccc.SetDynamicSpeed(dynamicSpeed);
	}
}
