//------------------------------------------------------------------------------------------------
// JobBonPointBuyMenu.c
// Onglet 'Acheter' : liste paginee des annonces actives (10/page).
// Clic sur une annonce -> ouvre la fiche produit (JobBonPointAdDetailMenu).
//------------------------------------------------------------------------------------------------

class JobBonPointBuyMenu : ChimeraMenuBase
{
	const string ENTRY_LAYOUT_PATH = "{DF8689A8A8CEA807}UI/layouts/JobBonPointAdEntry.layout";
	const int ITEMS_PER_PAGE = 10;
	const int PAGE_COOLDOWN_MS = 300;
	
	Widget m_RootWidget;
	TextWidget m_TitleText;
	TextWidget m_EmptyText;
	TextWidget m_PageLabel;
	Widget m_ListContainer;
	ButtonWidget m_BtnPrev;
	ButtonWidget m_BtnNext;
	ButtonWidget m_BtnBack;
	
	// Donnees pre-chargees par RpcDo_ReceiveBonPointAdsList
	// Format compact : pour chaque annonce, on a (adId, prix, vendeurName, titre)
	static ref array<int> s_PendingAdIds = new array<int>();
	static ref array<int> s_PendingPrices = new array<int>();
	static ref array<string> s_PendingSellerNames = new array<string>();
	static ref array<string> s_PendingTitles = new array<string>();
	
	int m_CurrentPage = 0;
	int m_LastPageChangeTime = 0;
	
	static JobBonPointBuyMenu s_Instance;
	
	//------------------------------------------------------------------------------------------------
	static void SetPendingData(array<int> adIds, array<int> prices,
		array<string> sellerNames, array<string> titles)
	{
		s_PendingAdIds.Clear();
		s_PendingPrices.Clear();
		s_PendingSellerNames.Clear();
		s_PendingTitles.Clear();
		foreach (int id : adIds) s_PendingAdIds.Insert(id);
		foreach (int p : prices) s_PendingPrices.Insert(p);
		foreach (string s : sellerNames) s_PendingSellerNames.Insert(s);
		foreach (string t : titles) s_PendingTitles.Insert(t);
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuOpen()
	{
		super.OnMenuOpen();
		s_Instance = this;
		JobFocusHandler.ClearRegistry();
		
		m_RootWidget = GetRootWidget();
		if (!m_RootWidget) return;
		
		m_TitleText = TextWidget.Cast(m_RootWidget.FindAnyWidget("TitleText"));
		m_EmptyText = TextWidget.Cast(m_RootWidget.FindAnyWidget("EmptyText"));
		m_PageLabel = TextWidget.Cast(m_RootWidget.FindAnyWidget("PageLabel"));
		m_ListContainer = m_RootWidget.FindAnyWidget("ListContainer");
		m_BtnPrev = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnPrev"));
		m_BtnNext = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnNext"));
		m_BtnBack = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnBack"));
		
		if (m_TitleText)
			m_TitleText.SetText("Annonces a vendre");
		
		BindBtn(m_BtnPrev, "prev");
		BindBtn(m_BtnNext, "next");
		BindBtn(m_BtnBack, "back");
		
		m_CurrentPage = 0;
		BuildList();
		
		// Focus initial intelligent (probleme manette console) :
		//   - S il y a au moins une annonce, focus sur le 1er bouton "Voir"
		//   - Sinon focus sur "Retour"
		Widget targetFocus = null;
		if (m_ListContainer && s_PendingAdIds.Count() > 0)
		{
			Widget firstEntry = m_ListContainer.GetChildren();
			if (firstEntry)
				targetFocus = firstEntry.FindAnyWidget("BtnView");
		}
		if (!targetFocus)
			targetFocus = m_BtnBack;
		if (targetFocus)
			GetGame().GetWorkspace().SetFocusedWidget(targetFocus);
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuClose()
	{
		if (s_Instance == this) s_Instance = null;
		super.OnMenuClose();
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuUpdate(float tDelta)
	{
		super.OnMenuUpdate(tDelta);
		if (GetGame().GetInputManager().GetActionValue("MenuBack") > 0.5)
			CloseMenuInternal();
		if (GetGame().GetInputManager().GetActionValue("MenuTabLeft") > 0.5)
			OnPrev();
		if (GetGame().GetInputManager().GetActionValue("MenuTabRight") > 0.5)
			OnNext();
	}
	
	//------------------------------------------------------------------------------------------------
	void BindBtn(ButtonWidget btn, string action)
	{
		if (!btn) return;
		BonPointBuyHandler h = new BonPointBuyHandler();
		h.m_Menu = this;
		h.m_Action = action;
		btn.AddHandler(h);
		JobFocusHandler.Attach(btn);
	}
	
	//------------------------------------------------------------------------------------------------
	int GetTotalPages()
	{
		int total = (s_PendingAdIds.Count() + ITEMS_PER_PAGE - 1) / ITEMS_PER_PAGE;
		if (total < 1) total = 1;
		return total;
	}
	
	//------------------------------------------------------------------------------------------------
	void BuildList()
	{
		if (!m_ListContainer) return;
		
		JobFocusHandler.ClearRegistry();
		if (m_BtnPrev) JobFocusHandler.Attach(m_BtnPrev);
		if (m_BtnNext) JobFocusHandler.Attach(m_BtnNext);
		if (m_BtnBack) JobFocusHandler.Attach(m_BtnBack);
		
		Widget child = m_ListContainer.GetChildren();
		while (child)
		{
			Widget next = child.GetSibling();
			child.RemoveFromHierarchy();
			child = next;
		}
		
		int totalPages = GetTotalPages();
		if (m_CurrentPage < 0) m_CurrentPage = 0;
		if (m_CurrentPage >= totalPages) m_CurrentPage = totalPages - 1;
		
		if (s_PendingAdIds.Count() == 0)
		{
			if (m_EmptyText)
			{
				m_EmptyText.SetText("Aucune annonce disponible pour le moment.");
				m_EmptyText.SetVisible(true);
			}
			UpdatePagination(totalPages);
			return;
		}
		if (m_EmptyText) m_EmptyText.SetVisible(false);
		
		WorkspaceWidget ws = GetGame().GetWorkspace();
		int start = m_CurrentPage * ITEMS_PER_PAGE;
		int end = start + ITEMS_PER_PAGE;
		if (end > s_PendingAdIds.Count()) end = s_PendingAdIds.Count();
		
		for (int i = start; i < end; i++)
		{
			int adId = s_PendingAdIds.Get(i);
			int price = s_PendingPrices.Get(i);
			string sellerName = s_PendingSellerNames.Get(i);
			string title = s_PendingTitles.Get(i);
			
			Widget entry = ws.CreateWidgets(ENTRY_LAYOUT_PATH, m_ListContainer);
			if (!entry) continue;
			
			TextWidget titleW = TextWidget.Cast(entry.FindAnyWidget("AdTitle"));
			if (titleW) titleW.SetText(title);
			
			TextWidget priceW = TextWidget.Cast(entry.FindAnyWidget("AdPrice"));
			if (priceW) priceW.SetText(string.Format("%1 capsules", price.ToString()));
			
			TextWidget sellerW = TextWidget.Cast(entry.FindAnyWidget("AdSeller"));
			if (sellerW) sellerW.SetText(string.Format("par %1", sellerName));
			
			ButtonWidget btn = ButtonWidget.Cast(entry.FindAnyWidget("BtnView"));
			if (btn)
			{
				BonPointAdSelectHandler h = new BonPointAdSelectHandler();
				h.m_Menu = this;
				h.m_AdId = adId;
				btn.AddHandler(h);
				JobFocusHandler.Attach(btn);
			}
		}
		
		UpdatePagination(totalPages);
	}
	
	//------------------------------------------------------------------------------------------------
	void UpdatePagination(int totalPages)
	{
		if (m_PageLabel)
			m_PageLabel.SetText(string.Format("Page %1 / %2", (m_CurrentPage + 1).ToString(), totalPages.ToString()));
		if (m_BtnPrev) m_BtnPrev.SetEnabled(m_CurrentPage > 0);
		if (m_BtnNext) m_BtnNext.SetEnabled(m_CurrentPage < totalPages - 1);
	}
	
	//------------------------------------------------------------------------------------------------
	void OnPrev()
	{
		int now = System.GetTickCount();
		if (now - m_LastPageChangeTime < PAGE_COOLDOWN_MS) return;
		m_LastPageChangeTime = now;
		if (m_CurrentPage <= 0) return;
		m_CurrentPage--;
		BuildList();
	}
	
	void OnNext()
	{
		int now = System.GetTickCount();
		if (now - m_LastPageChangeTime < PAGE_COOLDOWN_MS) return;
		m_LastPageChangeTime = now;
		if (m_CurrentPage >= GetTotalPages() - 1) return;
		m_CurrentPage++;
		BuildList();
	}
	
	//------------------------------------------------------------------------------------------------
	void OnAdSelected(int adId)
	{
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		jpc.ClientAskBonPointAdDetail(adId);
		CloseMenuInternal();
	}
	
	//------------------------------------------------------------------------------------------------
	void OnAction(string action)
	{
		if (action == "back") { CloseMenuInternal(); return; }
		if (action == "prev") { OnPrev(); return; }
		if (action == "next") { OnNext(); return; }
	}
	
	//------------------------------------------------------------------------------------------------
	void CloseMenuInternal()
	{
		GetGame().GetMenuManager().CloseMenu(this);
	}
	
	static JobBonPointBuyMenu GetOpenMenu() { return s_Instance; }
}

//------------------------------------------------------------------------------------------------
class BonPointBuyHandler : ScriptedWidgetEventHandler
{
	JobBonPointBuyMenu m_Menu;
	string m_Action;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.OnAction(m_Action);
		return true;
	}
}

//------------------------------------------------------------------------------------------------
class BonPointAdSelectHandler : ScriptedWidgetEventHandler
{
	JobBonPointBuyMenu m_Menu;
	int m_AdId;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.OnAdSelected(m_AdId);
		return true;
	}
}