//------------------------------------------------------------------------------------------------
// JobGangMenuPresets.c
// Declaration des nouveaux presets de menu pour le systeme de gang.
//
// IMPORTANT : si tu as DEJA un fichier "modded enum ChimeraMenuPreset" ailleurs dans le mod
// (avec JobShopMenu, JobQuestMenu, etc.), AJOUTE simplement les 3 lignes ci-dessous a CE fichier
// existant et SUPPRIME ce fichier-ci pour eviter une double declaration de l enum.
//
// Si tu n as PAS encore d enum modded ailleurs, ce fichier suffit.
//------------------------------------------------------------------------------------------------

modded enum ChimeraMenuPreset
{
	JobGangCreateMenu,
	JobGangMenu,
	JobGangRecruitMenu
}
