//------------------------------------------------------------------------------------------------
// JobCriminalData.c
// Structures de donnees du systeme Police/Justice:
//  - Amendes (3 niveaux, horodatage, etat paye/impaye)
//  - Mentions manuelles au casier
//  - Dossier complet (permis, casier, prison)
//------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------------------
// Enum des niveaux d'amende (montant fixe)
//------------------------------------------------------------------------------------------------
enum EFineLevel
{
	NONE = 0,
	LEVEL_1 = 1,  // 35 capsules
	LEVEL_2 = 2,  // 135 capsules
	LEVEL_3 = 3,  // 465 capsules
}

//------------------------------------------------------------------------------------------------
// Montants fixes par niveau
//------------------------------------------------------------------------------------------------
class JobFineAmounts
{
	static int GetAmount(EFineLevel level)
	{
		switch (level)
		{
			case EFineLevel.LEVEL_1: return 300;
			case EFineLevel.LEVEL_2: return 1000;
			case EFineLevel.LEVEL_3: return 5000;
		}
		return 0;
	}
	
	static string GetLabel(EFineLevel level)
	{
		switch (level)
		{
			case EFineLevel.LEVEL_1: return "Amende de niveau 1 (300 capsules)";
			case EFineLevel.LEVEL_2: return "Amende de niveau 2 (1000 capsules)";
			case EFineLevel.LEVEL_3: return "Amende de niveau 3 (5000 capsules)";
		}
		return "Amende inconnue";
	}
}

//------------------------------------------------------------------------------------------------
// Enregistrement d'une amende individuelle
//------------------------------------------------------------------------------------------------
class FineRecord
{
	int m_Level;            // niveau 1/2/3
	int m_Amount;           // capsules - montant courant (mis a jour si majore)
	int m_OriginalAmount;   // capsules - montant initial (avant majorations)
	int m_IssuedTimestamp;  // world time de l'emission (secondes)
	int m_IssuerPlayerId;   // playerId du flic qui a emis (sert pour "payer F sur le flic")
	string m_IssuerName;    // nom du flic (conserve meme s'il deco)
	bool m_Paid;            // payee ou non
	int m_PaidTimestamp;    // si payee, quand
	bool m_PrisonTriggered; // legacy : si la prison auto a ete declenchee (n'est plus utilise mais conserve pour compat saves)
	int m_MajorationsApplied;  // 0=pas majore, 1=majore une fois, 2=majore deux fois (prelevement au prochain tick)
	bool m_AutoCollected;   // true si payee par prelevement automatique (vs paiement manuel)
	int m_Gravity;          // Gravite (EInfractionGravity : 0=Mineure, 1=Moderee, 2=Grave, 3=Criminelle)
	string m_Evidence;      // Preuves libres (URL video, texte descriptif, temoins...)
	
	void FineRecord()
	{
		m_Paid = false;
		m_IssuedTimestamp = 0;
		m_PaidTimestamp = 0;
		m_PrisonTriggered = false;
		m_MajorationsApplied = 0;
		m_AutoCollected = false;
		m_Gravity = 0;
		m_Evidence = "";
	}
}

//------------------------------------------------------------------------------------------------
// Mention manuelle ajoutee au casier par un flic/militaire
//------------------------------------------------------------------------------------------------
class MentionRecord
{
	string m_Text;            // texte libre
	int m_Timestamp;          // quand
	string m_IssuerName;      // nom du flic (pour l'affichage)
	
	void MentionRecord()
	{
		m_Timestamp = 0;
	}
}

//------------------------------------------------------------------------------------------------
// Dossier complet d'un joueur (casier + permis + prison)
//------------------------------------------------------------------------------------------------
class CriminalRecord
{
	string m_PlayerUID;                       // UID persistant Bohemia
	string m_PlayerName;                      // dernier nom connu
	bool m_HasDrivingLicense;                 // permis OK ou non
	
	ref array<ref FineRecord> m_Fines;        // TOUTES les amendes (payees + non)
	ref array<ref MentionRecord> m_Mentions;  // mentions manuelles
	
	// Prison
	bool m_InPrison;                          // actuellement incarcere
	int m_PrisonEntryTime;                    // timestamp d'entree (pour auto-liberation)
	int m_PrisonDurationSeconds;              // duree specifique de la peine en secondes (0 = defaut 15 min)
	bool m_IsLongPrison;                      // true = prison longue (libere a LONG_PRISON_RELEASE), false = prison courte (gendarmerie)

	// Vol - cooldowns globaux 30 min
	int m_LastTimeIRobbed;        // dernier timestamp ou j'ai vole quelqu'un (cooldown comme voleur)
	int m_LastTimeIWasRobbed;     // dernier timestamp ou j'ai ete vole (cooldown comme victime)

	void CriminalRecord()
	{
		m_HasDrivingLicense = false;
		m_InPrison = false;
		m_PrisonEntryTime = 0;
		m_PrisonDurationSeconds = 0;
		m_IsLongPrison = false;
		m_LastTimeIRobbed = 0;
		m_LastTimeIWasRobbed = 0;
		m_Fines = new array<ref FineRecord>();
		m_Mentions = new array<ref MentionRecord>();
	}
	
	//------------------------------------------------------------------------------------------------
	// Renvoie l'amende impayee la plus ancienne emise par un flic donne (pour le F Payer l'amende)
	// Si issuerPlayerId = -1, renvoie n'importe quelle amende impayee
	//------------------------------------------------------------------------------------------------
	FineRecord GetOldestUnpaidFine(int issuerPlayerId)
	{
		FineRecord oldest = null;
		foreach (FineRecord f : m_Fines)
		{
			if (!f || f.m_Paid)
				continue;
			if (issuerPlayerId != -1 && f.m_IssuerPlayerId != issuerPlayerId)
				continue;
			if (!oldest || f.m_IssuedTimestamp < oldest.m_IssuedTimestamp)
				oldest = f;
		}
		return oldest;
	}
	
	//------------------------------------------------------------------------------------------------
	// Renvoie le montant total des amendes impayees
	//------------------------------------------------------------------------------------------------
	int GetTotalUnpaidAmount()
	{
		int total = 0;
		foreach (FineRecord f : m_Fines)
		{
			if (f && !f.m_Paid)
				total += f.m_Amount;
		}
		return total;
	}
	
	//------------------------------------------------------------------------------------------------
	// Compte les amendes impayees
	//------------------------------------------------------------------------------------------------
	int GetUnpaidFineCount()
	{
		int c = 0;
		foreach (FineRecord f : m_Fines)
		{
			if (f && !f.m_Paid)
				c++;
		}
		return c;
	}
	
	//------------------------------------------------------------------------------------------------
	// Verifie si une amende impayee a depasse la deadline de paiement (10 minutes)
	// Retourne la premiere amende en retard pour declencher la prison auto
	//------------------------------------------------------------------------------------------------
	// Recherche une amende dont la deadline est depassee.
	// Robuste au reboot serveur : si m_IssuedTimestamp > currentTime, l'amende est consideree
	// "fraichement emise" (pas overdue) - le tick suivant remettra a jour les timestamps si besoin.
	//------------------------------------------------------------------------------------------------
	FineRecord GetOverdueFine(int currentTime, int deadlineSeconds)
	{
		foreach (FineRecord f : m_Fines)
		{
			if (!f || f.m_Paid || f.m_PrisonTriggered)
				continue;
			// Reboot detecte : l'amende n'est pas encore overdue
			if (f.m_IssuedTimestamp > currentTime)
				continue;
			if (currentTime - f.m_IssuedTimestamp >= deadlineSeconds)
				return f;
		}
		return null;
	}
}

