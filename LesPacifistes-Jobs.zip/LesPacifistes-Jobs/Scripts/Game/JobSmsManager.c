//------------------------------------------------------------------------------------------------
// JobSmsManager.c
// Singleton serveur gerant le systeme SMS.
//
// Persistance : 1 fichier par joueur dans $profile:LesPacifistesJobs/sms/UID.json
// contenant TOUS les SMS du joueur (envoyes + recus).
// 
// Limite : 200 messages max par joueur. Rotation FIFO.
//------------------------------------------------------------------------------------------------

class JobSmsManager
{
	static ref JobSmsManager s_Instance;
	
	// Cache memoire : UID -> Inbox
	ref map<string, ref JobSmsInbox> m_Cache;
	
	const string SMS_DIR = "$profile:LesPacifistesJobs/sms";
	
	//------------------------------------------------------------------------------------------------
	void JobSmsManager()
	{
		m_Cache = new map<string, ref JobSmsInbox>();
	}
	
	//------------------------------------------------------------------------------------------------
	static JobSmsManager GetInstance()
	{
		if (!s_Instance)
			s_Instance = new JobSmsManager();
		return s_Instance;
	}
	
	//------------------------------------------------------------------------------------------------
	string BuildPath(string uid)
	{
		return SMS_DIR + "/" + uid + ".json";
	}
	
	//------------------------------------------------------------------------------------------------
	// Recupere l inbox d un joueur (charge depuis disk si pas en cache)
	//------------------------------------------------------------------------------------------------
	JobSmsInbox GetInbox(string uid)
	{
		if (uid == "")
			return null;
		
		JobSmsInbox cached = m_Cache.Get(uid);
		if (cached)
			return cached;
		
		JobSmsInbox loaded = LoadFromDisk(uid);
		if (!loaded)
			loaded = new JobSmsInbox();
		
		m_Cache.Set(uid, loaded);
		return loaded;
	}
	
	//------------------------------------------------------------------------------------------------
	// Envoi d un SMS : ajoute le message a l inbox de l expediteur ET du destinataire,
	// avec rotation FIFO si > 200.
	//
	// Retourne 0 = OK, code erreur sinon :
	//   1 = message vide
	//   2 = message trop long
	//   3 = destinataire identique (anti self-sms)
	//------------------------------------------------------------------------------------------------
	int SendSms(string fromUID, string fromDisplayName, string toUID, string toDisplayName, string content)
	{
		if (content == "")
			return 1;
		if (content.Length() > JobSmsData.MAX_MESSAGE_LENGTH)
			return 2;
		if (fromUID == toUID)
			return 3;
		
		JobSmsMessage msg = new JobSmsMessage();
		msg.m_Timestamp = System.GetUnixTime();
		msg.m_FromUID = fromUID;
		msg.m_FromDisplayName = fromDisplayName;
		msg.m_ToUID = toUID;
		msg.m_ToDisplayName = toDisplayName;
		msg.m_Content = content;
		msg.m_Read = false;
		
		// Ajout dans l inbox de l expediteur (deja lu pour lui)
		JobSmsInbox senderInbox = GetInbox(fromUID);
		JobSmsMessage senderCopy = CloneMessage(msg);
		senderCopy.m_Read = true; // l expediteur n a pas de notif sur ses propres envois
		senderInbox.m_Messages.Insert(senderCopy);
		EnforceLimit(senderInbox);
		SaveToDisk(fromUID, senderInbox);
		
		// Ajout dans l inbox du destinataire (non lu)
		JobSmsInbox recipientInbox = GetInbox(toUID);
		JobSmsMessage recipientCopy = CloneMessage(msg);
		recipientCopy.m_Read = false;
		recipientInbox.m_Messages.Insert(recipientCopy);
		EnforceLimit(recipientInbox);
		SaveToDisk(toUID, recipientInbox);
		
		return 0;
	}
	
	//------------------------------------------------------------------------------------------------
	// Marque tous les messages provenant d un UID specifique comme lus dans l inbox d un joueur
	//------------------------------------------------------------------------------------------------
	void MarkConversationAsRead(string ownerUID, string otherUID)
	{
		JobSmsInbox inbox = GetInbox(ownerUID);
		if (!inbox)
			return;
		bool changed = false;
		foreach (JobSmsMessage m : inbox.m_Messages)
		{
			if (!m) continue;
			// Messages recus de cet autre (donc m_FromUID == otherUID et m_ToUID == ownerUID)
			if (m.m_FromUID == otherUID && m.m_ToUID == ownerUID && !m.m_Read)
			{
				m.m_Read = true;
				changed = true;
			}
		}
		if (changed)
			SaveToDisk(ownerUID, inbox);
	}
	
	//------------------------------------------------------------------------------------------------
	// Compte le nb de messages non lus dans l inbox d un joueur
	//------------------------------------------------------------------------------------------------
	int GetUnreadCount(string uid)
	{
		JobSmsInbox inbox = GetInbox(uid);
		if (!inbox)
			return 0;
		int count = 0;
		foreach (JobSmsMessage m : inbox.m_Messages)
		{
			if (m && !m.m_Read && m.m_ToUID == uid)
				count++;
		}
		return count;
	}
	
	//------------------------------------------------------------------------------------------------
	// Supprime LOCALEMENT tous les messages d une conversation entre ownerUID et otherUID
	// (dans l inbox du ownerUID uniquement). L autre joueur voit toujours ses messages.
	// - Iterer a rebours pour supprimer safely
	// - Sauvegarde immediatement le fichier
	// Retourne le nombre de messages supprimes.
	//------------------------------------------------------------------------------------------------
	int DeleteConversationForPlayer(string ownerUID, string otherUID)
	{
		if (ownerUID == "" || otherUID == "")
			return 0;
		JobSmsInbox inbox = GetInbox(ownerUID);
		if (!inbox || !inbox.m_Messages)
			return 0;
		
		int removed = 0;
		int i = inbox.m_Messages.Count() - 1;
		while (i >= 0)
		{
			JobSmsMessage m = inbox.m_Messages.Get(i);
			if (m)
			{
				// Match si le message est ENVOYE a otherUID OU RECU de otherUID
				bool match = false;
				if (m.m_FromUID == ownerUID && m.m_ToUID == otherUID)
					match = true;
				if (m.m_FromUID == otherUID && m.m_ToUID == ownerUID)
					match = true;
				if (match)
				{
					inbox.m_Messages.Remove(i);
					removed = removed + 1;
				}
			}
			i = i - 1;
		}
		
		if (removed > 0)
			SaveToDisk(ownerUID, inbox);
		
		return removed;
	}
	
	//------------------------------------------------------------------------------------------------
	// Garde uniquement les MAX_TOTAL_MESSAGES plus recents
	//------------------------------------------------------------------------------------------------
	void EnforceLimit(JobSmsInbox inbox)
	{
		while (inbox.m_Messages.Count() > JobSmsData.MAX_TOTAL_MESSAGES)
			inbox.m_Messages.Remove(0); // supprime le plus ancien (index 0)
	}
	
	//------------------------------------------------------------------------------------------------
	JobSmsMessage CloneMessage(JobSmsMessage src)
	{
		JobSmsMessage c = new JobSmsMessage();
		c.m_Timestamp = src.m_Timestamp;
		c.m_FromUID = src.m_FromUID;
		c.m_FromDisplayName = src.m_FromDisplayName;
		c.m_ToUID = src.m_ToUID;
		c.m_ToDisplayName = src.m_ToDisplayName;
		c.m_Content = src.m_Content;
		c.m_Read = src.m_Read;
		return c;
	}
	
	//------------------------------------------------------------------------------------------------
	void SaveToDisk(string uid, JobSmsInbox inbox)
	{
		if (uid == "" || !inbox)
			return;
		
		SCR_JsonSaveContext ctx = new SCR_JsonSaveContext();
		int count = inbox.m_Messages.Count();
		ctx.WriteValue("count", count);
		for (int i = 0; i < count; i++)
		{
			JobSmsMessage m = inbox.m_Messages.Get(i);
			if (!m) continue;
			string prefix = "msg_" + i.ToString() + "_";
			ctx.WriteValue(prefix + "ts", m.m_Timestamp);
			ctx.WriteValue(prefix + "from", m.m_FromUID);
			ctx.WriteValue(prefix + "fromName", m.m_FromDisplayName);
			ctx.WriteValue(prefix + "to", m.m_ToUID);
			ctx.WriteValue(prefix + "toName", m.m_ToDisplayName);
			ctx.WriteValue(prefix + "content", m.m_Content);
			ctx.WriteValue(prefix + "read", m.m_Read);
		}
		ctx.SaveToFile(BuildPath(uid));
	}
	
	//------------------------------------------------------------------------------------------------
	JobSmsInbox LoadFromDisk(string uid)
	{
		SCR_JsonLoadContext ctx = new SCR_JsonLoadContext();
		if (!ctx.LoadFromFile(BuildPath(uid)))
			return null;
		
		JobSmsInbox inbox = new JobSmsInbox();
		int count = 0;
		ctx.ReadValue("count", count);
		for (int i = 0; i < count; i++)
		{
			string prefix = "msg_" + i.ToString() + "_";
			JobSmsMessage m = new JobSmsMessage();
			ctx.ReadValue(prefix + "ts", m.m_Timestamp);
			ctx.ReadValue(prefix + "from", m.m_FromUID);
			ctx.ReadValue(prefix + "fromName", m.m_FromDisplayName);
			ctx.ReadValue(prefix + "to", m.m_ToUID);
			ctx.ReadValue(prefix + "toName", m.m_ToDisplayName);
			ctx.ReadValue(prefix + "content", m.m_Content);
			ctx.ReadValue(prefix + "read", m.m_Read);
			inbox.m_Messages.Insert(m);
		}
		return inbox;
	}
}
