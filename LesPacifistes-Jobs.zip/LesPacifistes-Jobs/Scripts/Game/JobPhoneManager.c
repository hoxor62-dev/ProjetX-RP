//------------------------------------------------------------------------------------------------
// JobPhoneManager.c
// Manager server-side du systeme telephone.
// Gere le cooldown anti-spam de 5 minutes par joueur entre 2 appels.
// Pas de persistance sur disque (les cooldowns sont volatiles).
//------------------------------------------------------------------------------------------------

class JobPhoneManager
{
	static ref JobPhoneManager s_Instance;
	
	// Map UID -> timestamp (secondes) du dernier appel
	ref map<string, int> m_LastCallTimestamps;
	
	// Constantes
	const int CALL_COOLDOWN_SECONDS = 300;    // 5 minutes entre 2 appels
	const int MARKER_LIFETIME_SECONDS = 600;  // 10 minutes marker auto-remove
	const int HINT_DURATION_SECONDS = 15;     // duree du hint cote agent
	
	//------------------------------------------------------------------------------------------------
	void JobPhoneManager()
	{
		m_LastCallTimestamps = new map<string, int>();
	}
	
	//------------------------------------------------------------------------------------------------
	static JobPhoneManager GetInstance()
	{
		if (!s_Instance)
			s_Instance = new JobPhoneManager();
		return s_Instance;
	}
	
	//------------------------------------------------------------------------------------------------
	// Retourne true si le joueur peut passer un appel (cooldown respecte)
	// Robuste au reboot serveur via JobTimeUtils.
	//------------------------------------------------------------------------------------------------
	bool CanCall(string callerUID)
	{
		if (callerUID == "")
			return false;
		int last;
		if (!m_LastCallTimestamps.Find(callerUID, last))
			return true;
		return !JobTimeUtils.IsInCooldown(last, CALL_COOLDOWN_SECONDS);
	}
	
	//------------------------------------------------------------------------------------------------
	// Retourne le temps restant en secondes avant le prochain appel possible
	//------------------------------------------------------------------------------------------------
	int GetRemainingCooldown(string callerUID)
	{
		if (callerUID == "")
			return 0;
		int last;
		if (!m_LastCallTimestamps.Find(callerUID, last))
			return 0;
		return JobTimeUtils.CooldownRemaining(last, CALL_COOLDOWN_SECONDS);
	}
	
	//------------------------------------------------------------------------------------------------
	// Enregistre un appel pour demarrer le cooldown
	//------------------------------------------------------------------------------------------------
	void RecordCall(string callerUID)
	{
		if (callerUID == "")
			return;
		m_LastCallTimestamps.Set(callerUID, JobTimeUtils.GetNow());
	}
}
