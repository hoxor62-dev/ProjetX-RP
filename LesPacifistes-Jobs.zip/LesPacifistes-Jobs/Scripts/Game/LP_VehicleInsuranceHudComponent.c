//------------------------------------------------------------------------------------------------
// LP_VehicleInsuranceHudComponent.c
// Composant client-side attache au SCR_PlayerController.
// Detecte quand le joueur local est CONDUCTEUR d un vehicule et affiche un HUD
// centre en haut de l ecran indiquant si le vehicule est assure (vert) ou non (rouge).
// Le HUD est persistent tant que le joueur reste au volant, et disparait a la sortie.
//------------------------------------------------------------------------------------------------

[ComponentEditorProps(category: "LesPacifistes", description: "HUD assurance vehicule (conducteur uniquement)")]
class LP_VehicleInsuranceHudComponentClass : ScriptComponentClass
{
}

class LP_VehicleInsuranceHudComponent : ScriptComponent
{
	// Chemin du layout (path relatif, resolu par Workbench)
	const string HUD_LAYOUT_PATH = "UI/layouts/LP_VehicleInsuranceHud.layout";
	
	// Frequence de check (ms) - equilibre reactivite / cout CPU
	const int CHECK_INTERVAL_MS = 1000;
	
	// Widget racine du HUD (creee a la 1ere entree, cachee/reveilee dynamiquement)
	Widget m_HudRoot;
	TextWidget m_InsuranceText;
	ImageWidget m_BorderTop;
	ImageWidget m_BorderBottom;
	
	// Etat courant
	IEntity m_CurrentVehicle;   // vehicule dans lequel on est actuellement conducteur (null sinon)
	int m_LastKnownStatus = -1; // -1 = inconnu, 0 = non assure, 1 = assure
	int m_LastQueryVehicleRplId = 0; // pour eviter les queries redondantes
	
	// Instance client-side (permet a JobPlayerComponent d appeler DisplayInsurance depuis RPC)
	static LP_VehicleInsuranceHudComponent s_LocalInstance;
	
	//------------------------------------------------------------------------------------------------
	override void OnPostInit(IEntity owner)
	{
		super.OnPostInit(owner);
		// Ne pas s installer cote serveur (uniquement HUD client)
		if (Replication.IsServer() && !Replication.IsClient())
			return;
		
		// Delai pour laisser le UI charger completement
		GetGame().GetCallqueue().CallLater(SetupLocalHud, 3000, false);
	}
	
	//------------------------------------------------------------------------------------------------
	void SetupLocalHud()
	{
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		
		// Uniquement sur le PlayerController LOCAL (pas les replicas des autres joueurs)
		if (pc.GetPlayerId() != GetGame().GetPlayerController().GetPlayerId())
			return;
		
		s_LocalInstance = this;
		
		// Cree le widget HUD immediatement (sera masque tant qu on n est pas au volant)
		CreateHudWidget();
		
		// Demarre le polling
		GetGame().GetCallqueue().CallLater(CheckLoop, CHECK_INTERVAL_MS, true);
	}
	
	//------------------------------------------------------------------------------------------------
	void CreateHudWidget()
	{
		WorkspaceWidget ws = GetGame().GetWorkspace();
		if (!ws) return;
		
		m_HudRoot = ws.CreateWidgets(HUD_LAYOUT_PATH);
		if (!m_HudRoot) return;
		
		m_InsuranceText = TextWidget.Cast(m_HudRoot.FindAnyWidget("InsuranceText"));
		m_BorderTop = ImageWidget.Cast(m_HudRoot.FindAnyWidget("InsuranceBorderTop"));
		m_BorderBottom = ImageWidget.Cast(m_HudRoot.FindAnyWidget("InsuranceBorderBottom"));
		
		m_HudRoot.SetVisible(false);
	}
	
	//------------------------------------------------------------------------------------------------
	// Boucle appelee toutes les CHECK_INTERVAL_MS
	//------------------------------------------------------------------------------------------------
	void CheckLoop()
	{
		IEntity vehicle = GetVehicleAsDriver();
		
		// Cas 1 : on n est pas conducteur -> masquer HUD
		if (!vehicle)
		{
			if (m_CurrentVehicle)
			{
				m_CurrentVehicle = null;
				m_LastKnownStatus = -1;
				m_LastQueryVehicleRplId = 0;
				if (m_HudRoot) m_HudRoot.SetVisible(false);
			}
			return;
		}
		
		// Cas 2 : on est conducteur du meme vehicule qu avant -> rien a faire
		if (vehicle == m_CurrentVehicle)
			return;
		
		// Cas 3 : nouveau vehicule -> demander au serveur son statut d assurance
		m_CurrentVehicle = vehicle;
		m_LastKnownStatus = -1;
		
		// Recupere le RplId du vehicule
		RplComponent rpl = RplComponent.Cast(vehicle.FindComponent(RplComponent));
		if (!rpl)
		{
			// Impossible de sync sans RplComponent - on affiche "non assure" par defaut
			DisplayHud(false);
			return;
		}
		int rplIdInt = Replication.FindId(rpl);
		if (rplIdInt == 0)
		{
			DisplayHud(false);
			return;
		}
		if (rplIdInt == m_LastQueryVehicleRplId)
			return;
		m_LastQueryVehicleRplId = rplIdInt;
		
		// Envoi RPC au serveur pour connaitre le statut
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		jpc.ClientAskVehicleInsurance(rplIdInt);
	}
	
	//------------------------------------------------------------------------------------------------
	// Retourne le vehicule dont le joueur local est CONDUCTEUR, ou null.
	//------------------------------------------------------------------------------------------------
	IEntity GetVehicleAsDriver()
	{
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return null;
		IEntity character = pc.GetControlledEntity();
		if (!character) return null;
		
		// Recupere le compartment component du personnage
		CompartmentAccessComponent cac = CompartmentAccessComponent.Cast(
			character.FindComponent(CompartmentAccessComponent));
		if (!cac) return null;
		
		BaseCompartmentSlot slot = cac.GetCompartment();
		if (!slot) return null;
		
		// Verifie que c est un slot PILOTE
		PilotCompartmentSlot pilotSlot = PilotCompartmentSlot.Cast(slot);
		if (!pilotSlot) return null;
		
		// Recupere le vehicule (owner du slot)
		return slot.GetOwner();
	}
	
	//------------------------------------------------------------------------------------------------
	// Appele par JobPlayerComponent quand la reponse du serveur arrive.
	// - insured : true si le vehicule est assure
	// - isRental : true si c est un vehicule de location (dans ce cas, on n affiche PAS le HUD
	//              car le HUD Location gere lui-meme son affichage)
	//------------------------------------------------------------------------------------------------
	void OnInsuranceStatusReceived(int vehicleRplId, bool insured, bool isRental)
	{
		// Verifie que la reponse concerne le vehicule qu on regarde encore
		if (vehicleRplId != m_LastQueryVehicleRplId)
			return;
		if (!m_CurrentVehicle)
			return;
		
		// Cas particulier : vehicule de location -> pas d assurance a afficher
		// (le HUD Location prend le relais)
		if (isRental)
		{
			if (m_HudRoot) m_HudRoot.SetVisible(false);
			m_LastKnownStatus = -1;
			return;
		}
		
		DisplayHud(insured);
	}
	
	//------------------------------------------------------------------------------------------------
	// Affiche le HUD avec le texte + la couleur adaptee au statut
	//------------------------------------------------------------------------------------------------
	void DisplayHud(bool insured)
	{
		if (!m_HudRoot) return;
		
		int statusFlag;
		if (insured) statusFlag = 1;
		else statusFlag = 0;
		
		// Evite les updates redondantes
		if (m_LastKnownStatus == statusFlag)
		{
			m_HudRoot.SetVisible(true);
			return;
		}
		m_LastKnownStatus = statusFlag;
		
		if (m_InsuranceText)
		{
			if (insured)
			{
				m_InsuranceText.SetText("Vehicule assure");
				m_InsuranceText.SetColor(Color.FromRGBA(70, 220, 90, 255)); // vert
			}
			else
			{
				m_InsuranceText.SetText("Vehicule NON assure");
				m_InsuranceText.SetColor(Color.FromRGBA(230, 70, 70, 255)); // rouge
			}
		}
		
		// Bordures colorees pour renforcer le signal visuel
		Color borderColor;
		if (insured)
			borderColor = Color.FromRGBA(70, 220, 90, 255);
		else
			borderColor = Color.FromRGBA(230, 70, 70, 255);
		if (m_BorderTop) m_BorderTop.SetColor(borderColor);
		if (m_BorderBottom) m_BorderBottom.SetColor(borderColor);
		
		m_HudRoot.SetVisible(true);
	}
	
	//------------------------------------------------------------------------------------------------
	// Accessible depuis JobPlayerComponent pour router le retour serveur
	//------------------------------------------------------------------------------------------------
	static LP_VehicleInsuranceHudComponent GetLocalInstance()
	{
		return s_LocalInstance;
	}
}
