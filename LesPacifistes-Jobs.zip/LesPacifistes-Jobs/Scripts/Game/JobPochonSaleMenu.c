//------------------------------------------------------------------------------------------------
// JobPochonSaleMenu.c
// Menu de vente de pochons au PNJ acheteur avec selecteur de quantite (+/-).
// La quantite max vendable est le min de :
//  - JobPochonData.MAX_VENTES_PAR_FENETRE
//  - quota restant dans la fenetre glissante
//  - nombre de pochons dans l inventaire
//------------------------------------------------------------------------------------------------

class JobPochonSaleMenu : ChimeraMenuBase
{
	Widget m_RootWidget;
	TextWidget m_InfoText;
	TextWidget m_InventoryText;
	TextWidget m_QuotaText;
	TextWidget m_BourseText;
	TextWidget m_QuantityText;
	TextWidget m_TotalText;
	ButtonWidget m_BtnMinus;
	ButtonWidget m_BtnPlus;
	ButtonWidget m_BtnSell;
	ButtonWidget m_BtnClose;
	
	int m_Quantity = 1;
	int m_MaxAllowed = 0;      // cap dynamique = min(inventaire, quota, MAX_PAR_FENETRE)
	int m_InventoryCount = 0;
	int m_QuotaRemaining = 0;
	int m_WindowEndUnix = 0;
	int m_BoursePercent = 100;    // 50 a 100
	int m_UnitPrice = 400;        // prix unitaire courant apres bourse
	
	static JobPochonSaleMenu s_Instance;
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuOpen()
	{
		super.OnMenuOpen();
		s_Instance = this;
		JobFocusHandler.ClearRegistry();
		
		m_RootWidget = GetRootWidget();
		if (!m_RootWidget) return;
		
		m_InfoText = TextWidget.Cast(m_RootWidget.FindAnyWidget("InfoText"));
		m_InventoryText = TextWidget.Cast(m_RootWidget.FindAnyWidget("InventoryText"));
		m_QuotaText = TextWidget.Cast(m_RootWidget.FindAnyWidget("QuotaText"));
		m_BourseText = TextWidget.Cast(m_RootWidget.FindAnyWidget("BourseText"));
		m_QuantityText = TextWidget.Cast(m_RootWidget.FindAnyWidget("QuantityText"));
		m_TotalText = TextWidget.Cast(m_RootWidget.FindAnyWidget("TotalText"));
		m_BtnMinus = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnMinus"));
		m_BtnPlus = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnPlus"));
		m_BtnSell = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnSell"));
		m_BtnClose = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnClose"));
		
		AttachHandler(m_BtnMinus, "minus");
		AttachHandler(m_BtnPlus, "plus");
		AttachHandler(m_BtnSell, "sell");
		AttachHandler(m_BtnClose, "close");
		
		m_Quantity = 1;
		UpdateQuantityDisplay();
		
		// Demande les infos au serveur
		AskServerRefresh();
	}
	
	//------------------------------------------------------------------------------------------------
	void AttachHandler(ButtonWidget btn, string action)
	{
		if (!btn) return;
		PochonSaleBtnHandler h = new PochonSaleBtnHandler();
		h.m_Menu = this;
		h.m_Action = action;
		btn.AddHandler(h);
		JobFocusHandler.Attach(btn);
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuClose()
	{
		if (s_Instance == this) s_Instance = null;
		super.OnMenuClose();
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuUpdate(float tDelta)
	{
		super.OnMenuUpdate(tDelta);
		if (GetGame().GetInputManager().GetActionValue("MenuBack") > 0.5)
			CloseMenuInternal();
	}
	
	//------------------------------------------------------------------------------------------------
	void AskServerRefresh()
	{
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (jpc) jpc.ClientAskPochonSaleInfo();
	}
	
	//------------------------------------------------------------------------------------------------
	// Appele par RPC serveur avec toutes les infos
	//------------------------------------------------------------------------------------------------
	void DisplayInfo(int inventoryCount, int quotaRemaining, int windowEndUnix, int boursePercent, int unitPrice)
	{
		m_InventoryCount = inventoryCount;
		m_QuotaRemaining = quotaRemaining;
		m_WindowEndUnix = windowEndUnix;
		m_BoursePercent = boursePercent;
		m_UnitPrice = unitPrice;
		
		// Cap max autorise
		m_MaxAllowed = quotaRemaining;
		if (inventoryCount < m_MaxAllowed) m_MaxAllowed = inventoryCount;
		if (m_MaxAllowed > JobPochonData.MAX_VENTES_PAR_FENETRE)
			m_MaxAllowed = JobPochonData.MAX_VENTES_PAR_FENETRE;
		
		if (m_Quantity > m_MaxAllowed) m_Quantity = m_MaxAllowed;
		if (m_Quantity < 1) m_Quantity = 1;
		
		if (m_InventoryText)
			m_InventoryText.SetText(string.Format("Pochons dans votre inventaire : %1",
				inventoryCount.ToString()));
		
		if (m_QuotaText)
		{
			string windowLabel = "-";
			if (windowEndUnix > 0)
			{
				int nowUnix = System.GetUnixTime();
				int remainingSec = windowEndUnix - nowUnix;
				if (remainingSec < 0) remainingSec = 0;
				int mm = remainingSec / 60;
				int ss = remainingSec - mm * 60;
				string ssStr = ss.ToString();
				if (ss < 10) ssStr = "0" + ssStr;
				windowLabel = string.Format("reset dans %1:%2", mm.ToString(), ssStr);
			}
			m_QuotaText.SetText(string.Format("Quota restant : %1 / %2 - %3",
				quotaRemaining.ToString(),
				JobPochonData.MAX_VENTES_PAR_FENETRE.ToString(),
				windowLabel));
		}
		
		// Affichage bourse
		if (m_BourseText)
		{
			m_BourseText.SetText(string.Format("Bourse : %1%% (prix : %2 capsules/pochon)",
				boursePercent.ToString(), unitPrice.ToString()));
		}
		
		UpdateQuantityDisplay();
	}
	
	//------------------------------------------------------------------------------------------------
	void UpdateQuantityDisplay()
	{
		if (m_QuantityText)
			m_QuantityText.SetText(m_Quantity.ToString());
		if (m_TotalText)
		{
			int total = m_Quantity * m_UnitPrice;
			m_TotalText.SetText(string.Format("Total : %1 capsules", total.ToString()));
		}
		if (m_BtnSell)
			m_BtnSell.SetEnabled(m_MaxAllowed > 0);
	}
	
	//------------------------------------------------------------------------------------------------
	void OnButtonClicked(string action)
	{
		if (action == "close")
		{
			CloseMenuInternal();
			return;
		}
		if (action == "minus")
		{
			if (m_Quantity > 1) m_Quantity = m_Quantity - 1;
			UpdateQuantityDisplay();
			return;
		}
		if (action == "plus")
		{
			int cap = m_MaxAllowed;
			if (cap < 1) cap = 1;
			if (m_Quantity < cap) m_Quantity = m_Quantity + 1;
			UpdateQuantityDisplay();
			return;
		}
		if (action == "sell")
		{
			if (m_Quantity < 1 || m_MaxAllowed < 1) return;
			PlayerController pc = GetGame().GetPlayerController();
			if (!pc) return;
			JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
			if (!jpc) return;
			jpc.ClientAskSellPochons(m_Quantity);
			// Rafraichir apres traitement serveur
			GetGame().GetCallqueue().CallLater(AskServerRefresh, 400, false);
			return;
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void CloseMenuInternal()
	{
		GetGame().GetMenuManager().CloseMenu(this);
	}
	
	//------------------------------------------------------------------------------------------------
	static JobPochonSaleMenu GetOpenMenu() { return s_Instance; }
}

//------------------------------------------------------------------------------------------------
class PochonSaleBtnHandler : ScriptedWidgetEventHandler
{
	JobPochonSaleMenu m_Menu;
	string m_Action;
	
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.OnButtonClicked(m_Action);
		return true;
	}
}
