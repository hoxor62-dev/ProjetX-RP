//------------------------------------------------------------------------------------------------
// JobMiningManager.c
// Manager singleton server-side gerant les sessions actives de mining et transformation.
//
// Une session = un joueur en train de miner ou transformer une ressource sur un prefab donne.
// Plusieurs sessions simultanees possibles (chaque joueur a la sienne sur un prefab donne).
//
// Tick a 1Hz qui fait progresser tous les joueurs.
// Chaque 10 secondes : produit un item ou consomme/produit pour transformation.
//------------------------------------------------------------------------------------------------

class JobMiningSession
{
	int m_PlayerId;             // joueur en session
	RplId m_PrefabRplId;        // RplId du prefab (source ou transformation)
	bool m_IsTransform;         // false = extraction, true = transformation
	int m_MineralType;          // EMineralType
	int m_Count;                // progression actuelle (0 - m_MaxCycles)
	int m_MaxCycles;            // total items pour cette session (30 normal, 60 sous effet pochon)
	int m_CycleDuration;        // secondes par item (10 normal, 5 sous effet pochon)
	int m_LastProductionTime;   // timestamp derniere production reussie
	int m_StartTime;            // timestamp de demarrage
	bool m_Paused;              // true si en pause (joueur eloigne)
	
	void JobMiningSession()
	{
		m_PlayerId = 0;
		m_Count = 0;
		m_MaxCycles = 30;
		m_CycleDuration = 10;
		m_LastProductionTime = 0;
		m_StartTime = 0;
		m_Paused = false;
	}
}

class JobMiningManager
{
	static ref JobMiningManager s_Instance;
	
	// Sessions actives - clef = playerId, value = session
	ref map<int, ref JobMiningSession> m_Sessions;
	
	// Cooldowns post-30/30 - clef = "playerId_prefabRplId", value = timestamp d'expiration
	ref map<string, int> m_PostCompletionCooldowns;
	
	//------------------------------------------------------------------------------------------------
	void JobMiningManager()
	{
		m_Sessions = new map<int, ref JobMiningSession>();
		m_PostCompletionCooldowns = new map<string, int>();
	}
	
	//------------------------------------------------------------------------------------------------
	static JobMiningManager GetInstance()
	{
		if (!s_Instance)
		{
			s_Instance = new JobMiningManager();
			GetGame().GetCallqueue().CallLater(TickCallback, 1000, true);
		}
		return s_Instance;
	}
	
	//------------------------------------------------------------------------------------------------
	static void TickCallback()
	{
		if (!Replication.IsServer())
			return;
		if (!s_Instance)
			return;
		s_Instance.Tick();
	}
	
	//------------------------------------------------------------------------------------------------
	// Demarre ou reprend une session pour un joueur sur un prefab donne
	// Retourne 0 si OK, code d'erreur sinon (1=metier, 2=cooldown, 3=session deja active ailleurs)
	//------------------------------------------------------------------------------------------------
	int StartSession(int playerId, RplId prefabRplId, int mineralType, bool isTransform)
	{
		// Verif metier requis (ROCK -> MINEUR, WOOD -> BUCHERON, APPLE -> AGRICULTEUR)
		EJobType requiredJob = JobMiningData.GetRequiredJob(mineralType);
		if (requiredJob != EJobType.NONE)
		{
			JobPlayerData pd = JobManager.GetInstance().GetPlayerData(playerId);
			if (!pd || pd.m_Job != requiredJob)
				return 1; // pas le bon metier
		}
		
		// Verif outil requis pour ROCK (pioche) et WOOD (hache)
		// Uniquement pour l extraction (pas la transformation, qui se fait sur une machine)
		if (!isTransform)
		{
			PlayerController pc = GetGame().GetPlayerManager().GetPlayerController(playerId);
			if (pc)
			{
				IEntity character = pc.GetControlledEntity();
				if (character && !JobToolCheck.HasRequiredToolForMineral(character, mineralType))
					return 4; // outil manquant
			}
		}
		
		// Verif cooldown post-30 sur cette source pour ce joueur (extraction uniquement)
		if (!isTransform)
		{
			string cooldownKey = playerId.ToString() + "_" + prefabRplId.ToString();
			int expiry;
			if (m_PostCompletionCooldowns.Find(cooldownKey, expiry))
			{
				int now = JobTimeUtils.GetNow();
				if (now < expiry)
					return 2; // cooldown 5 min apres 30/30
			}
		}
		
		// Si une session existe deja pour ce joueur sur ce prefab : on la reprend (depause)
		JobMiningSession existing = m_Sessions.Get(playerId);
		if (existing)
		{
			if (existing.m_PrefabRplId == prefabRplId && existing.m_IsTransform == isTransform)
			{
				// Reprise de la session existante
				existing.m_Paused = false;
				existing.m_LastProductionTime = JobTimeUtils.GetNow();
				return 0;
			}
			else
			{
				// Le joueur etait sur autre chose : on annule l'ancienne et on demarre une nouvelle
				m_Sessions.Remove(playerId);
				HideActivityProgressForPlayer(playerId);
			}
		}
		
		// Nouvelle session
		JobMiningSession s = new JobMiningSession();
		s.m_PlayerId = playerId;
		s.m_PrefabRplId = prefabRplId;
		s.m_MineralType = mineralType;
		s.m_IsTransform = isTransform;
		s.m_Count = 0;
		// Bonus pochon : le joueur peut extraire 2x plus d items en 2x moins de temps par item
		// -> 60 items en 5 minutes au lieu de 30 items en 5 minutes
		if (JobPochonEffectManager.GetInstance().HasActiveEffect(playerId))
		{
			s.m_MaxCycles = JobMiningData.CYCLE_COUNT_MAX * 2;
			s.m_CycleDuration = JobMiningData.CYCLE_DURATION_SECONDS / 2;
		}
		else
		{
			s.m_MaxCycles = JobMiningData.CYCLE_COUNT_MAX;
			s.m_CycleDuration = JobMiningData.CYCLE_DURATION_SECONDS;
		}
		s.m_StartTime = JobTimeUtils.GetNow();
		s.m_LastProductionTime = s.m_StartTime;
		s.m_Paused = false;
		m_Sessions.Insert(playerId, s);
		return 0;
	}
	
	//------------------------------------------------------------------------------------------------
	void StopSession(int playerId)
	{
		m_Sessions.Remove(playerId);
		HideActivityProgressForPlayer(playerId);
	}
	
	//------------------------------------------------------------------------------------------------
	JobMiningSession GetSession(int playerId)
	{
		return m_Sessions.Get(playerId);
	}
	
	//------------------------------------------------------------------------------------------------
	// Tick principal - fait progresser toutes les sessions actives
	//------------------------------------------------------------------------------------------------
	void Tick()
	{
		int now = JobTimeUtils.GetNow();
		
		array<int> playerIdsToCheck = new array<int>();
		foreach (int pid, JobMiningSession s : m_Sessions)
		{
			if (s) playerIdsToCheck.Insert(pid);
		}
		
		foreach (int pid : playerIdsToCheck)
		{
			JobMiningSession s = m_Sessions.Get(pid);
			if (!s)
				continue;
			
			// Verifier que le joueur existe encore
			PlayerController pc = GetGame().GetPlayerManager().GetPlayerController(pid);
			if (!pc)
			{
				m_Sessions.Remove(pid);
				HideActivityProgressForPlayer(pid);
				continue;
			}
			IEntity character = pc.GetControlledEntity();
			if (!character)
				continue;
			
			// Verifier la distance au prefab
			RplComponent prefabRpl = RplComponent.Cast(Replication.FindItem(s.m_PrefabRplId));
			if (!prefabRpl)
			{
				NotifyPlayer(pid, "[MINING] Source introuvable - extraction interrompue");
				m_Sessions.Remove(pid);
				HideActivityProgressForPlayer(pid);
				continue;
			}
			IEntity prefab = prefabRpl.GetEntity();
			if (!prefab)
			{
				// prefab disparu : on stop la session
				NotifyPlayer(pid, "[MINING] Source introuvable - extraction interrompue");
				m_Sessions.Remove(pid);
				HideActivityProgressForPlayer(pid);
				continue;
			}
			
			float dist = vector.Distance(character.GetOrigin(), prefab.GetOrigin());
			if (dist > JobMiningData.MAX_DISTANCE_METERS)
			{
				// Joueur trop loin : pause si pas deja en pause
				if (!s.m_Paused)
				{
					s.m_Paused = true;
					NotifyPlayer(pid, "[MINING] Trop loin - extraction en pause. Revenez pres de la zone pour continuer.");
					// Cache la barre HUD pendant la pause (elle sera recreee automatiquement
					// au retour du joueur via SendActivityProgressToPlayer)
					HideActivityProgressForPlayer(pid);
				}
				continue;
			}
			else
			{
				// Joueur proche : reprend si etait en pause
				if (s.m_Paused)
				{
					s.m_Paused = false;
					s.m_LastProductionTime = now;
					NotifyPlayer(pid, "[MINING] Extraction reprise");
					// La barre HUD sera recreee au prochain SendActivityProgressToPlayer
					// (juste en dessous, dans le meme tick)
				}
			}
			
			// Si en pause, on ne fait pas progresser
			if (s.m_Paused)
				continue;
			
			// Met a jour la barre HUD a chaque tick (1Hz) pour un affichage continu
			SendActivityProgressToPlayer(s);
			
			// Production toutes les X secondes (10 normal, 5 sous effet pochon)
			if (now - s.m_LastProductionTime >= s.m_CycleDuration)
			{
				ProcessOneCycle(s);
				s.m_LastProductionTime = now;
				
				// Fin de session a max/max
				if (s.m_Count >= s.m_MaxCycles)
				{
					EMineralType type = s.m_MineralType;
					string finalMsg;
					if (s.m_IsTransform)
					{
						finalMsg = string.Format("[MINING] Transformation terminee ! %1 produits. Allez vendre votre cargaison au PNJ.",
							JobMiningData.GetMineralLabel(type, EMineralState.PROCESSED));
					}
					else
					{
						finalMsg = string.Format("[MINING] Extraction terminee ! %1 obtenus. Allez transformer votre cargaison.",
							JobMiningData.GetMineralLabel(type, EMineralState.RAW));
					}
					NotifyPlayer(pid, finalMsg);
					
					// Cooldown 5 min sur cette source/transformation pour ce joueur
					if (!s.m_IsTransform)
					{
						string cooldownKey = pid.ToString() + "_" + s.m_PrefabRplId.ToString();
						m_PostCompletionCooldowns.Set(cooldownKey, now + JobMiningData.RESPAWN_COOLDOWN_SECONDS);
					}
					
					m_Sessions.Remove(pid);
					HideActivityProgressForPlayer(pid);
				}
			}
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Execute un cycle de 10s : pour extraction = produit 1 RAW, pour transformation = consomme 1 RAW + produit 1 PROCESSED
	//------------------------------------------------------------------------------------------------
	void ProcessOneCycle(JobMiningSession s)
	{
		PlayerController pc = GetGame().GetPlayerManager().GetPlayerController(s.m_PlayerId);
		if (!pc)
			return;
		IEntity character = pc.GetControlledEntity();
		if (!character)
			return;
		
		EMineralType type = s.m_MineralType;
		
		if (s.m_IsTransform)
		{
			// TRANSFORMATION : consommer 1 RAW puis produire 1 PROCESSED
			ResourceName rawPrefab = JobMiningData.GetItemPrefab(type, EMineralState.RAW);
			ResourceName processedPrefab = JobMiningData.GetItemPrefab(type, EMineralState.PROCESSED);
			
			if (!RemoveOneItemFromInventory(character, rawPrefab))
			{
				// Plus d'item brut : stop la session
				NotifyPlayer(s.m_PlayerId, "[MINING] Plus de matiere brute a transformer - transformation terminee");
				m_Sessions.Remove(s.m_PlayerId);
				HideActivityProgressForPlayer(s.m_PlayerId);
				return;
			}
			
			// Spawn et insert l'item transforme
			GiveItemToPlayer(character, processedPrefab);
			
			s.m_Count++;
			// Plus de NotifyPlayer X/30 ici : la barre HUD est mise a jour par le Tick principal
		}
		else
		{
			// EXTRACTION : produit 1 RAW
			ResourceName rawPrefab = JobMiningData.GetItemPrefab(type, EMineralState.RAW);
			GiveItemToPlayer(character, rawPrefab);
			
			s.m_Count++;
			// Plus de NotifyPlayer X/30 ici : la barre HUD est mise a jour par le Tick principal
			
			// BONUS DROPS aleatoires selon le type de ressource extraite :
			// - POMME (Agriculteur) : 1/5 chance de recuperer un asticot
			// - ROCHE (Mineur) : 1/10 pepite fer + 1/30 pepite or (doubles avec Pioche2)
			// - BOIS (Bucheron), CANNABIS, COCAINE : aucun bonus (chacun son metier)
			if (type == EMineralType.APPLE)
			{
				int rollAsticot = Math.RandomInt(0, 5);
				if (rollAsticot == 0)
				{
					ResourceName asticot = "{BF6465CFC1FBEDC4}Prefabs/Weapons/Grenades/asticot.et";
					GiveItemToPlayer(character, asticot);
					NotifyPlayer(s.m_PlayerId, "[RECOLTE] Bonus : +1 asticot pour la peche !");
				}
			}
			else if (type == EMineralType.ROCK)
			{
				// Bonus double si le joueur possede la Pioche amelioree (Pioche2) dans son inventaire
				// - Pioche standard : 1/10 fer, 1/30 or
				// - Pioche amelioree : 1/5 fer, 1/15 or (chances doublees)
				bool hasPioche2 = PlayerHasPioche2(character);
				int ferChance = 10;
				int orChance = 30;
				if (hasPioche2)
				{
					ferChance = 5;
					orChance = 15;
				}

				int rollFer = Math.RandomInt(0, ferChance);
				if (rollFer == 0)
				{
					ResourceName pepiteFer = "{B5C7F29EAB4BE9A7}Prefabs/Weapons/Grenades/pepitefer.et";
					GiveItemToPlayer(character, pepiteFer);
					if (hasPioche2)
						NotifyPlayer(s.m_PlayerId, "[MINING] Bonus (Pioche+) : +1 pepite de fer !");
					else
						NotifyPlayer(s.m_PlayerId, "[MINING] Bonus : +1 pepite de fer !");
				}
				int rollOr = Math.RandomInt(0, orChance);
				if (rollOr == 0)
				{
					ResourceName pepiteOr = "{C6D29778D28BA23A}Prefabs/Weapons/Grenades/pepiteor.et";
					GiveItemToPlayer(character, pepiteOr);
					if (hasPioche2)
						NotifyPlayer(s.m_PlayerId, "[MINING] Bonus RARE (Pioche+) : +1 pepite d or !");
					else
						NotifyPlayer(s.m_PlayerId, "[MINING] Bonus RARE : +1 pepite d or !");
				}
			}
			else if (type == EMineralType.WOOD)
			{
				// Bonus Hache amelioree : +25% de bois (1 chance sur 4 par cycle de recevoir +1 bois bonus).
				// Sur un run complet, le bucheron recolte en moyenne 1.25 bois par cycle (vs 1 sans la hache+).
				bool hasHache2 = PlayerHasHache2(character);
				if (hasHache2)
				{
					int rollBoisBonus = Math.RandomInt(0, 4);  // 0..3 -> 25% de chance (0)
					if (rollBoisBonus == 0)
					{
						ResourceName woodRaw = JobMiningData.GetItemPrefab(EMineralType.WOOD, EMineralState.RAW);
						GiveItemToPlayer(character, woodRaw);
						NotifyPlayer(s.m_PlayerId, "[MINING] Bonus (Hache+) : +1 bois !");
					}
				}
			}
			// CANNABIS, COCAINE : aucun bonus (extraction pure)
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Spawn un item du prefab et tente de l'inserer dans l'inventaire du joueur.
	// Si l'inventaire est plein : drop l'item au sol pres du joueur.
	//------------------------------------------------------------------------------------------------
	void GiveItemToPlayer(IEntity character, ResourceName itemPrefab)
	{
		Resource res = Resource.Load(itemPrefab);
		if (!res || !res.IsValid())
		{
			Print(string.Format("[JobMiningManager] Prefab item invalide : %1", itemPrefab), LogLevel.WARNING);
			return;
		}
		
		EntitySpawnParams p = new EntitySpawnParams();
		p.TransformMode = ETransformMode.WORLD;
		Math3D.MatrixIdentity4(p.Transform);
		p.Transform[3] = character.GetOrigin() + Vector(0, 0.5, 0);
		
		IEntity item = GetGame().SpawnEntityPrefab(res, GetGame().GetWorld(), p);
		if (!item)
			return;
		
		SCR_InventoryStorageManagerComponent inv = SCR_InventoryStorageManagerComponent.Cast(
			character.FindComponent(SCR_InventoryStorageManagerComponent));
		
		bool inserted = false;
		if (inv)
		{
			inserted = inv.TryInsertItem(item, EStoragePurpose.PURPOSE_DEPOSIT);
		}
		
		if (inserted)
		{
			// Insertion reussie
			return;
		}
		
		// Inventaire plein : drop au sol pres du joueur
		vector dropPos = character.GetOrigin() + Vector(0.5, 0.2, 0.5);
		item.SetOrigin(dropPos);
		Print(string.Format("[JobMiningManager] Inventaire plein - drop au sol pour playerId=%1",
			GetGame().GetPlayerManager().GetPlayerIdFromControlledEntity(character)),
			LogLevel.NORMAL);
	}
	
	//------------------------------------------------------------------------------------------------
	// Cherche et retire un item correspondant au prefab donne dans l'inventaire du joueur.
	// Retourne true si retrait reussi.
	//------------------------------------------------------------------------------------------------
	bool RemoveOneItemFromInventory(IEntity character, ResourceName itemPrefab)
	{
		SCR_InventoryStorageManagerComponent inv = SCR_InventoryStorageManagerComponent.Cast(
			character.FindComponent(SCR_InventoryStorageManagerComponent));
		if (!inv)
			return false;
		
		array<IEntity> items = new array<IEntity>();
		inv.GetItems(items);
		
		string targetName = itemPrefab;
		targetName.ToLower();
		
		foreach (IEntity item : items)
		{
			if (!item)
				continue;
			EntityPrefabData pd = item.GetPrefabData();
			if (!pd)
				continue;
			string name = pd.GetPrefabName();
			name.ToLower();
			if (name.IndexOf(targetName) != -1 || targetName.IndexOf(name) != -1)
			{
				inv.TryRemoveItemFromInventory(item);
				SCR_EntityHelper.DeleteEntityAndChildren(item);
				return true;
			}
		}
		return false;
	}
	
	//------------------------------------------------------------------------------------------------
	// Verifie si le joueur possede la Pioche amelioree (Pioche2) dans son inventaire.
	// Utilise pour doubler les chances de drop bonus (fer/or) lors de l extraction.
	//------------------------------------------------------------------------------------------------
	protected bool PlayerHasPioche2(IEntity character)
	{
		if (!character) return false;
		SCR_InventoryStorageManagerComponent inv = SCR_InventoryStorageManagerComponent.Cast(
			character.FindComponent(SCR_InventoryStorageManagerComponent));
		if (!inv) return false;

		string target = "{FDD8619861328520}Prefabs/Items/Equipment/Accessories/ETool_ALICE/Pioche2.et";

		array<IEntity> items = new array<IEntity>();
		inv.GetItems(items);
		foreach (IEntity item : items)
		{
			if (!item) continue;
			EntityPrefabData pd = item.GetPrefabData();
			if (!pd) continue;
			if (pd.GetPrefabName() == target)
				return true;
		}
		return false;
	}

	//------------------------------------------------------------------------------------------------
	// Verifie si le joueur possede la Hache amelioree (Hache2) dans son inventaire.
	// Utilise pour donner +25% de bois lors de l extraction (1 chance sur 4 par cycle).
	//------------------------------------------------------------------------------------------------
	protected bool PlayerHasHache2(IEntity character)
	{
		if (!character) return false;
		SCR_InventoryStorageManagerComponent inv = SCR_InventoryStorageManagerComponent.Cast(
			character.FindComponent(SCR_InventoryStorageManagerComponent));
		if (!inv) return false;

		string target = "{D723CC9DC095D176}Prefabs/Items/Equipment/Accessories/ETool_ALICE/Hache2.et";

		array<IEntity> items = new array<IEntity>();
		inv.GetItems(items);
		foreach (IEntity item : items)
		{
			if (!item) continue;
			EntityPrefabData pd = item.GetPrefabData();
			if (!pd) continue;
			if (pd.GetPrefabName() == target)
				return true;
		}
		return false;
	}
	
	//------------------------------------------------------------------------------------------------
	// Compte les items d'un type/etat donne dans l'inventaire du joueur
	//------------------------------------------------------------------------------------------------
	static int CountItemsInInventory(IEntity character, ResourceName itemPrefab)
	{
		SCR_InventoryStorageManagerComponent inv = SCR_InventoryStorageManagerComponent.Cast(
			character.FindComponent(SCR_InventoryStorageManagerComponent));
		if (!inv)
			return 0;
		
		array<IEntity> items = new array<IEntity>();
		inv.GetItems(items);
		
		string targetName = itemPrefab;
		targetName.ToLower();
		
		int count = 0;
		foreach (IEntity item : items)
		{
			if (!item)
				continue;
			EntityPrefabData pd = item.GetPrefabData();
			if (!pd)
				continue;
			string name = pd.GetPrefabName();
			name.ToLower();
			if (name.IndexOf(targetName) != -1 || targetName.IndexOf(name) != -1)
				count++;
		}
		return count;
	}
	
	//------------------------------------------------------------------------------------------------
	// Retire N items donnes de l'inventaire (pour la vente). Retourne le nombre reellement retire.
	//------------------------------------------------------------------------------------------------
	static int RemoveItemsFromInventory(IEntity character, ResourceName itemPrefab, int maxCount)
	{
		SCR_InventoryStorageManagerComponent inv = SCR_InventoryStorageManagerComponent.Cast(
			character.FindComponent(SCR_InventoryStorageManagerComponent));
		if (!inv)
			return 0;
		
		array<IEntity> items = new array<IEntity>();
		inv.GetItems(items);
		
		string targetName = itemPrefab;
		targetName.ToLower();
		
		int removed = 0;
		foreach (IEntity item : items)
		{
			if (removed >= maxCount)
				break;
			if (!item)
				continue;
			EntityPrefabData pd = item.GetPrefabData();
			if (!pd)
				continue;
			string name = pd.GetPrefabName();
			name.ToLower();
			if (name.IndexOf(targetName) != -1 || targetName.IndexOf(name) != -1)
			{
				inv.TryRemoveItemFromInventory(item);
				SCR_EntityHelper.DeleteEntityAndChildren(item);
				removed++;
			}
		}
		return removed;
	}
	
	//------------------------------------------------------------------------------------------------
	void NotifyPlayer(int playerId, string msg)
	{
		if (JobManager.GetInstance())
			JobManager.GetInstance().NotifyPlayerChat(playerId, msg);
	}
	
	//------------------------------------------------------------------------------------------------
	// Pousse la barre de progression HUD au joueur. Appele a chaque tick (1Hz).
	//------------------------------------------------------------------------------------------------
	void SendActivityProgressToPlayer(JobMiningSession s)
	{
		if (!s) return;
		PlayerController pc = GetGame().GetPlayerManager().GetPlayerController(s.m_PlayerId);
		if (!pc) return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		
		string title;
		if (s.m_IsTransform)
			title = "TRANSFORMATION";
		else
			title = "EXTRACTION";
		
		jpc.ServerSendActivityProgress(title, s.m_Count, s.m_MaxCycles);
	}
	
	//------------------------------------------------------------------------------------------------
	// Cache la barre HUD du joueur (fin de session, interruption, etc.)
	//------------------------------------------------------------------------------------------------
	void HideActivityProgressForPlayer(int playerId)
	{
		PlayerManager pm = GetGame().GetPlayerManager();
		if (!pm) return;
		PlayerController pc = pm.GetPlayerController(playerId);
		if (!pc) return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (jpc)
			jpc.ServerHideActivityProgress();
	}
}
