//------------------------------------------------------------------------------------------------
// LP_CannabisHUD.c
// HUD client pour l effet cannabis.
//
// EFFETS :
//  - Overlay teinte vert plein ecran, opacite progresse avec le niveau
//  - 4 logos cannabis (feuilles) qui apparaissent / disparaissent a des positions aleatoires
//    (plus le taux est haut, plus ils apparaissent souvent et vite)
//  - Texte niveau en pourcentage
//------------------------------------------------------------------------------------------------

class LP_CannabisHUD
{
	static ref LP_CannabisHUD s_Instance;
	
	// A remplacer par le vrai GUID du layout une fois cree dans Workbench
	const string LAYOUT_PATH = "{D35A3FCC967B0888}UI/layouts/LP_CannabisHUD.layout";
	
	Widget m_Root;
	ImageWidget m_BlurOverlay;
	TextWidget m_LevelText;

	// 4 logos cannabis flottants
	ref array<ImageWidget> m_FloatingLogos = new array<ImageWidget>();

	// 4 bordures sombres pour l effet vignette (tunnel vision pulsant)
	ImageWidget m_VignetteTop;
	ImageWidget m_VignetteBottom;
	ImageWidget m_VignetteLeft;
	ImageWidget m_VignetteRight;
	float m_VignettePulseTime = 0;  // temps accumule pour le sinus de pulse

	float m_CurrentLevel = 0;
	float m_NextLogoFlashTimer = 0;

	const int NUM_LOGOS = 4;
	
	//------------------------------------------------------------------------------------------------
	static LP_CannabisHUD GetInstance()
	{
		if (!s_Instance)
		{
			s_Instance = new LP_CannabisHUD();
			s_Instance.Init();
		}
		return s_Instance;
	}
	
	//------------------------------------------------------------------------------------------------
	protected void Init()
	{
		WorkspaceWidget ws = GetGame().GetWorkspace();
		if (!ws) return;
		
		m_Root = ws.CreateWidgets(LAYOUT_PATH);
		if (!m_Root)
		{
			Print("[LP_CannabisHUD] ERREUR : layout introuvable a " + LAYOUT_PATH, LogLevel.ERROR);
			return;
		}
		
		m_BlurOverlay = ImageWidget.Cast(m_Root.FindAnyWidget("BlurOverlay"));
		m_LevelText   = TextWidget.Cast(m_Root.FindAnyWidget("LevelText"));

		// Vignette (4 bordures sombres pulsantes)
		m_VignetteTop    = ImageWidget.Cast(m_Root.FindAnyWidget("VignetteTop"));
		m_VignetteBottom = ImageWidget.Cast(m_Root.FindAnyWidget("VignetteBottom"));
		m_VignetteLeft   = ImageWidget.Cast(m_Root.FindAnyWidget("VignetteLeft"));
		m_VignetteRight  = ImageWidget.Cast(m_Root.FindAnyWidget("VignetteRight"));

		// Recupere les 4 logos
		for (int i = 0; i < NUM_LOGOS; i++)
		{
			ImageWidget logo = ImageWidget.Cast(m_Root.FindAnyWidget("CannabisLogo" + i.ToString()));
			if (logo) m_FloatingLogos.Insert(logo);
		}

		Hide();

		// Ticker 100ms pour animer les logos + vignette pulsante
		GetGame().GetCallqueue().CallLater(TickFloatingLogos, 100, true);
		GetGame().GetCallqueue().CallLater(TickVignettePulse, 100, true);
		
		Print("[LP_CannabisHUD] HUD cannabis initialise.", LogLevel.NORMAL);
	}
	
	//------------------------------------------------------------------------------------------------
	void UpdateLevel(float level)
	{
		m_CurrentLevel = level;
		
		if (level < 1)
		{
			Hide();
			return;
		}
		
		Show();
		
		// Overlay teinte verte : opacite progresse rapidement
		//  1%   -> 0.05
		//  25%  -> 0.23
		//  50%  -> 0.45
		//  75%  -> 0.67
		//  100% -> 0.85
		float overlayAlpha = (level / 100.0) * 0.80 + 0.05;
		if (overlayAlpha > 0.85) overlayAlpha = 0.85;
		if (m_BlurOverlay) m_BlurOverlay.SetOpacity(overlayAlpha);
		
		// Texte niveau
		if (m_LevelText)
		{
			int rounded = level;
			m_LevelText.SetText(rounded.ToString() + "% THC");
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Anime les logos cannabis : apparition / disparition a des positions aleatoires
	// Plus le taux est haut, plus la frequence d apparition est elevee.
	//------------------------------------------------------------------------------------------------
	protected void TickFloatingLogos()
	{
		if (m_CurrentLevel < 1) return;
		if (m_FloatingLogos.Count() == 0) return;
		
		m_NextLogoFlashTimer = m_NextLogoFlashTimer - 0.1;  // tick 100ms
		
		if (m_NextLogoFlashTimer <= 0)
		{
			// Flash d un logo aleatoire a une position aleatoire
			FlashRandomLogo();
			
			// Reinitialise le timer selon le niveau
			// 25% THC = flash toutes les ~2.5s
			// 50% THC = flash toutes les ~1.5s
			// 75% THC = flash toutes les ~0.8s
			// 100% THC = flash toutes les ~0.3s
			float baseInterval = 3.5 - (m_CurrentLevel / 100.0) * 3.2;
			if (baseInterval < 0.3) baseInterval = 0.3;
			// Ajoute un peu de randomness (+/- 30%)
			float jitter = Math.RandomFloat(0.7, 1.3);
			m_NextLogoFlashTimer = baseInterval * jitter;
		}
		
		// Fade progressif de tous les logos visibles
		foreach (ImageWidget logo : m_FloatingLogos)
		{
			if (!logo) continue;
			float op = logo.GetOpacity();
			if (op > 0)
			{
				op = op - 0.02;  // fade de 20% / sec
				if (op < 0) op = 0;
				logo.SetOpacity(op);
			}
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Vignette pulsante : les 4 bordures sombres respirent a ~0.5Hz (cycle 2 secondes).
	// Simule la dilatation des pupilles et le "focus centre d ecran".
	// Opacite max selon niveau : 25% THC -> 0.20 max, 100% THC -> 0.75 max.
	//------------------------------------------------------------------------------------------------
	protected void TickVignettePulse()
	{
		if (m_CurrentLevel < 1) return;

		m_VignettePulseTime = m_VignettePulseTime + 0.1;  // tick 100ms

		// Opacite de base selon niveau (0.05 a 0.75)
		float baseOpacity = (m_CurrentLevel / 100.0) * 0.70 + 0.05;
		if (baseOpacity > 0.75) baseOpacity = 0.75;

		// Pulse sinusoidal (0.5Hz = cycle de 2 secondes)
		// Formule : sin(temps * 2*PI * 0.5) donne un cycle complet toutes les 2s
		// Varie entre -1 et +1, qu on remappe a 0.65 - 1.0 (pour que la pulse soit visible mais pas disparaitre)
		float sinValue = Math.Sin(m_VignettePulseTime * 3.14159);  // 2*PI*0.5 = PI
		float pulseFactor = 0.65 + 0.35 * ((sinValue + 1.0) * 0.5);  // 0.65 -> 1.00

		float finalOpacity = baseOpacity * pulseFactor;

		if (m_VignetteTop)    m_VignetteTop.SetOpacity(finalOpacity);
		if (m_VignetteBottom) m_VignetteBottom.SetOpacity(finalOpacity);
		if (m_VignetteLeft)   m_VignetteLeft.SetOpacity(finalOpacity);
		if (m_VignetteRight)  m_VignetteRight.SetOpacity(finalOpacity);
	}

	//------------------------------------------------------------------------------------------------
	protected void FlashRandomLogo()
	{
		if (m_FloatingLogos.Count() == 0) return;
		
		int idx = Math.RandomInt(0, m_FloatingLogos.Count());
		ImageWidget logo = m_FloatingLogos[idx];
		if (!logo) return;
		
		// Position aleatoire a l ecran (0-1800 en X, 0-900 en Y, en gros)
		float randX = Math.RandomFloat(100, 1700);
		float randY = Math.RandomFloat(100, 850);
		
		// FrameSlot : position absolue dans le FrameWidget racine
		FrameSlot.SetPos(logo, randX, randY);
		
		// Flash en pleine opacite (va fade au tick suivant)
		logo.SetOpacity(0.85);
	}
	
	//------------------------------------------------------------------------------------------------
	protected void Show()
	{
		if (m_Root) m_Root.SetVisible(true);
	}
	
	//------------------------------------------------------------------------------------------------
	protected void Hide()
	{
		if (m_Root) m_Root.SetVisible(false);
		if (m_BlurOverlay) m_BlurOverlay.SetOpacity(0);
		foreach (ImageWidget logo : m_FloatingLogos)
		{
			if (logo) logo.SetOpacity(0);
		}
		// Reset vignette
		if (m_VignetteTop)    m_VignetteTop.SetOpacity(0);
		if (m_VignetteBottom) m_VignetteBottom.SetOpacity(0);
		if (m_VignetteLeft)   m_VignetteLeft.SetOpacity(0);
		if (m_VignetteRight)  m_VignetteRight.SetOpacity(0);
		m_VignettePulseTime = 0;
	}
}
