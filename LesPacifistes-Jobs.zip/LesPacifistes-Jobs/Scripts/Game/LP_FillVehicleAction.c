//------------------------------------------------------------------------------------------------
// LP_FillVehicleAction.c
// Action F sur un vehicule : "Mettre de l essence". A placer dans l ActionsManagerComponent
// de tous les vehicules essence (via Workbench, ou mieux : un mod global qui ajoute l action
// a tous les vehicules).
//
// VISIBILITE : TOUJOURS visible sur le vehicule (pas de check de distance cote client).
// Le serveur fait toute la validation : si aucune station n est a portee, il renvoie
// l erreur "Aucune station a proximite." et le menu l affiche en rouge.
//
// Comportement : ouvre un menu avec animation de remplissage + prix 3c/litre.
// La station proche est consommee, le reservoir du vehicule rempli selon sa capacite.
//
// Note : le calcul exact (quelle station, combien de litres possibles, prix total) est
// fait SERVEUR. L action locale sert juste de point d entree au RPC.
//------------------------------------------------------------------------------------------------

class LP_FillVehicleAction : ScriptedUserAction
{
	//------------------------------------------------------------------------------------------------
	override bool CanBeShownScript(IEntity user)
	{
		// Toujours visible : la validation (presence de station a portee, carburant disponible,
		// capsules suffisantes) est faite cote serveur dans le RPC et renvoyee au menu.
		if (!user) return false;
		if (!GetOwner()) return false;
		return true;
	}

	//------------------------------------------------------------------------------------------------
	override bool CanBePerformedScript(IEntity user)
	{
		return CanBeShownScript(user);
	}

	//------------------------------------------------------------------------------------------------
	override bool GetActionNameScript(out string outName)
	{
		outName = "Mettre de l essence";
		return true;
	}

	//------------------------------------------------------------------------------------------------
	override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
	{
		PlayerController localPC = GetGame().GetPlayerController();
		if (!localPC) return;
		if (localPC.GetControlledEntity() != pUserEntity) return;

		if (!pOwnerEntity) return;

		RplComponent rpl = RplComponent.Cast(pOwnerEntity.FindComponent(RplComponent));
		if (!rpl) return;
		RplId vehicleRplId = rpl.Id();

		JobPlayerComponent jpc = JobPlayerComponent.Cast(localPC.FindComponent(JobPlayerComponent));
		if (!jpc) return;

		// Le serveur se chargera de tout : trouver la station, calculer le remplissage,
		// debiter les capsules, remplir le reservoir, et renvoyer le resultat pour l animation.
		// Si aucune station n est a portee, le menu affichera l erreur en rouge.
		jpc.ClientAskFuelVehicle(vehicleRplId);
	}
}
