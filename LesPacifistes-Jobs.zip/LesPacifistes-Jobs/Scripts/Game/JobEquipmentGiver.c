//------------------------------------------------------------------------------------------------
// JobEquipmentGiver.c
// Distribue l'equipement (vetements + outils + armes) aux joueurs selon leur metier.
// Les prefabs sont references par GUID (ResourceName).
//
// Approche: spawn du prefab, puis insertion dans l'inventaire du joueur.
// Pour les armes: ajout d'une magazine separement.
//------------------------------------------------------------------------------------------------

class JobEquipmentGiver
{
	//------------------------------------------------------------------------------------------------
	// Point d'entree principal - appele par JobRpcHandler.Rpc_RequestEquipment (serveur)
	// Note : le cooldown de 30min est gere cote JobRpcHandler (verifie AVANT d appeler cette fonction).
	//------------------------------------------------------------------------------------------------
	static void GiveEquipment(IEntity player, EJobType job)
	{
		if (!player)
			return;
		
		array<ResourceName> prefabs = GetEquipmentPrefabs(job);
		if (!prefabs || prefabs.IsEmpty())
		{
			Print(string.Format("[JobEquipmentGiver] Aucun equipement defini pour %1",
				JobData.JobToString(job)), LogLevel.WARNING);
			return;
		}
		
		int givenCount = 0;
		foreach (ResourceName prefab : prefabs)
		{
			if (prefab == ResourceName.Empty || prefab == "")
				continue;
			if (SpawnAndGiveItem(player, prefab))
				givenCount++;
		}
		
		Print(string.Format("[JobEquipmentGiver] Equipement %1: %2/%3 items donnes",
			JobData.JobToString(job), givenCount, prefabs.Count()), LogLevel.NORMAL);
	}
	
	//------------------------------------------------------------------------------------------------
	// Retourne la liste des prefabs a donner pour un metier
	//------------------------------------------------------------------------------------------------
	static array<ResourceName> GetEquipmentPrefabs(EJobType job)
	{
		array<ResourceName> list = new array<ResourceName>();
		
		switch (job)
		{
			case EJobType.MINEUR:
				// Tenue mineur (bottes, gants, casque de chantier, veste, pantalon, col roule)
				list.Insert("{F05A35BCC44BE9FC}Prefabs/Characters/Footwear/TankerBoots_US_01/TankerBoots_US_01.et");
				list.Insert("{8266820FFDE17477}Prefabs/Characters/Handwear/Gloves_Wool_01/Gloves_Wool_01.et");
				list.Insert("{112EF132833109C8}Prefabs/Characters/HeadGear/Hat_Hard_01/Hat_Hard_01_green.et");
				list.Insert("{C472D4DFBF3652EB}Prefabs/Characters/Uniforms/Jacket_Raincoat_01/Jacket_Raincoat_01_base.et");
				list.Insert("{CF185061C5C13DBF}Prefabs/Characters/Uniforms/Pants_Fisherman_01/Pants_Fisherman_01_yellow.et");
				list.Insert("{50F8B1F928F93ABD}Prefabs/Characters/Uniforms/Shirt_Turtleneck_01/Shirt_Turtleneck_01_beige.et");
				break;
			
			case EJobType.UBER:
				// Tenue chauffeur (gants cuir, bottes, casquette plate, veste denim, pantalon costume)
				list.Insert("{4F71E7468E78DDD2}Prefabs/Characters/Handwear/Gloves_Leather_01/Gloves_Leather_01.et");
				list.Insert("{F05A35BCC44BE9FC}Prefabs/Characters/Footwear/TankerBoots_US_01/TankerBoots_US_01.et");
				list.Insert("{702F013CB1492541}Prefabs/Characters/Uniforms/Jacket_Suit_01/Jacket_Suit_01_base.et");
				list.Insert("{D8BD52A3138A0E62}Prefabs/Characters/Uniforms/Pants_Suit_01/Pants_Suit_01_base.et");
				break;
			
			case EJobType.BUCHERON:
				// Tenue bucheron (casquette truckerregina, ciree orange, pantalon cargo, jungle boots)
				list.Insert("{554D761A11D3D7EC}Prefabs/Characters/HeadGear/Hat_TruckerCap_01/Hat_TruckerCap_01_sawmillregina.et");
				list.Insert("{690819A92A3A8D14}Prefabs/Characters/Uniforms/Jacket_Raincoat_01/Jacket_Raincoat_01_orange.et");
				list.Insert("{21DC09217E13C1C7}Prefabs/Characters/Uniforms/Pants_Cargo/Pants_Cargo_Black.et");
				list.Insert("{203EEA924B049EF1}Prefabs/Characters/Footwear/JungleBoots_01/JungleBoots_01.et");
				break;
			
			case EJobType.AGRICULTEUR:
				// Tenue agriculteur (chapeau cowboy, col roule beige, pantalon marron, bottes soviet sale)
				list.Insert("{C1AF56DD77A1C6B6}Prefabs/Characters/HeadGear/Hat_Panama_Soviet/Cowboy Hat.et");
				list.Insert("{50F8B1F928F93ABD}Prefabs/Characters/Uniforms/Shirt_Turtleneck_01/Shirt_Turtleneck_01_beige.et");
				list.Insert("{6925E6C63EBCF623}Prefabs/Characters/Uniforms/Pants_Trousers_01/Pants_Trousers_01_DarkBrown.et");
				list.Insert("{4C6029AB8BF5C044}Prefabs/Characters/Footwear/CombatBoots_Soviet_01_Dirty.et");
				break;
			
			case EJobType.CUISINIER:
				// TODO boss: tenue cuisinier (a fournir quand dispo)
				break;
			



			
			case EJobType.MEDECIN:
				// Tenue medicale complete (nouveau set boss)
			list.Insert("{AA2B0708E63168E0}Prefabs/Characters/HeadGear/Hat_TruckerCap_01/CASQUETTE_SAMU.et");
list.Insert("{E1A5D4B878AA8980}Prefabs/Items/Equipment/Radios/Radio_R148.et");
				list.Insert("{D8326FEE52670D2A}Prefabs/Characters/Handwear/Gloves_Blue/Medical_Gloves_Blue_Base.et");
				list.Insert("{C07A52D13353AB2F}Prefabs/Clothing/ZEL_FaceClothing_Base.et");
				list.Insert("{DAD4DC8DC9888004}Prefabs/Characters/Uniforms/Suit_Pilot_US_01/TENUSAMU.et");
				list.Insert("{42B8B837A04DC1E6}Prefabs/Items/Equipment/Backpacks/SAC_SAMU.et");
			list.Insert("{58CF3AB87C441295}Prefabs/Items/Medicine/AmmoniumCarbonatePackage/ACE_Medical_AmmoniumCarbonatePackage.et");
list.Insert("{58CF3AB87C441295}Prefabs/Items/Medicine/AmmoniumCarbonatePackage/ACE_Medical_AmmoniumCarbonatePackage.et");
list.Insert("{58CF3AB87C441295}Prefabs/Items/Medicine/AmmoniumCarbonatePackage/ACE_Medical_AmmoniumCarbonatePackage.et");
list.Insert("{58CF3AB87C441295}Prefabs/Items/Medicine/AmmoniumCarbonatePackage/ACE_Medical_AmmoniumCarbonatePackage.et");
list.Insert("{58CF3AB87C441295}Prefabs/Items/Medicine/AmmoniumCarbonatePackage/ACE_Medical_AmmoniumCarbonatePackage.et");
list.Insert("{58CF3AB87C441295}Prefabs/Items/Medicine/AmmoniumCarbonatePackage/ACE_Medical_AmmoniumCarbonatePackage.et");
list.Insert("{58CF3AB87C441295}Prefabs/Items/Medicine/AmmoniumCarbonatePackage/ACE_Medical_AmmoniumCarbonatePackage.et");
list.Insert("{58CF3AB87C441295}Prefabs/Items/Medicine/AmmoniumCarbonatePackage/ACE_Medical_AmmoniumCarbonatePackage.et");
list.Insert("{58CF3AB87C441295}Prefabs/Items/Medicine/AmmoniumCarbonatePackage/ACE_Medical_AmmoniumCarbonatePackage.et");
list.Insert("{58CF3AB87C441295}Prefabs/Items/Medicine/AmmoniumCarbonatePackage/ACE_Medical_AmmoniumCarbonatePackage.et");
			
			
list.Insert("{A81F501D3EF6F38E}Prefabs/Items/Medicine/FieldDressing_01/FieldDressing_US_01.et");
list.Insert("{A81F501D3EF6F38E}Prefabs/Items/Medicine/FieldDressing_01/FieldDressing_US_01.et");						
list.Insert("{A81F501D3EF6F38E}Prefabs/Items/Medicine/FieldDressing_01/FieldDressing_US_01.et");
list.Insert("{A81F501D3EF6F38E}Prefabs/Items/Medicine/FieldDressing_01/FieldDressing_US_01.et");
list.Insert("{A81F501D3EF6F38E}Prefabs/Items/Medicine/FieldDressing_01/FieldDressing_US_01.et");						
list.Insert("{A81F501D3EF6F38E}Prefabs/Items/Medicine/FieldDressing_01/FieldDressing_US_01.et");
list.Insert("{A81F501D3EF6F38E}Prefabs/Items/Medicine/FieldDressing_01/FieldDressing_US_01.et");
list.Insert("{A81F501D3EF6F38E}Prefabs/Items/Medicine/FieldDressing_01/FieldDressing_US_01.et");						
list.Insert("{A81F501D3EF6F38E}Prefabs/Items/Medicine/FieldDressing_01/FieldDressing_US_01.et");
list.Insert("{A81F501D3EF6F38E}Prefabs/Items/Medicine/FieldDressing_01/FieldDressing_US_01.et");
list.Insert("{A81F501D3EF6F38E}Prefabs/Items/Medicine/FieldDressing_01/FieldDressing_US_01.et");						
list.Insert("{A81F501D3EF6F38E}Prefabs/Items/Medicine/FieldDressing_01/FieldDressing_US_01.et");	

list.Insert("{80E75A71C29190DB}Prefabs/Items/Medicine/Tourniquet_01/Tourniquet_USSR_01.et");
list.Insert("{80E75A71C29190DB}Prefabs/Items/Medicine/Tourniquet_01/Tourniquet_USSR_01.et");
list.Insert("{80E75A71C29190DB}Prefabs/Items/Medicine/Tourniquet_01/Tourniquet_USSR_01.et");
list.Insert("{80E75A71C29190DB}Prefabs/Items/Medicine/Tourniquet_01/Tourniquet_USSR_01.et");
list.Insert("{80E75A71C29190DB}Prefabs/Items/Medicine/Tourniquet_01/Tourniquet_USSR_01.et");
list.Insert("{80E75A71C29190DB}Prefabs/Items/Medicine/Tourniquet_01/Tourniquet_USSR_01.et");						
							
	
			
					
list.Insert("{5B2FD067D70C1E8F}Prefabs/Items/Medicine/EpinephrineInjection/ACE_Medical_EpinephrineInjection.et");
list.Insert("{5B2FD067D70C1E8F}Prefabs/Items/Medicine/EpinephrineInjection/ACE_Medical_EpinephrineInjection.et");
list.Insert("{5B2FD067D70C1E8F}Prefabs/Items/Medicine/EpinephrineInjection/ACE_Medical_EpinephrineInjection.et");
list.Insert("{5B2FD067D70C1E8F}Prefabs/Items/Medicine/EpinephrineInjection/ACE_Medical_EpinephrineInjection.et");
list.Insert("{5B2FD067D70C1E8F}Prefabs/Items/Medicine/EpinephrineInjection/ACE_Medical_EpinephrineInjection.et");
list.Insert("{5B2FD067D70C1E8F}Prefabs/Items/Medicine/EpinephrineInjection/ACE_Medical_EpinephrineInjection.et");
list.Insert("{5B2FD067D70C1E8F}Prefabs/Items/Medicine/EpinephrineInjection/ACE_Medical_EpinephrineInjection.et");
list.Insert("{5B2FD067D70C1E8F}Prefabs/Items/Medicine/EpinephrineInjection/ACE_Medical_EpinephrineInjection.et");
list.Insert("{5B2FD067D70C1E8F}Prefabs/Items/Medicine/EpinephrineInjection/ACE_Medical_EpinephrineInjection.et");
list.Insert("{5B2FD067D70C1E8F}Prefabs/Items/Medicine/EpinephrineInjection/ACE_Medical_EpinephrineInjection.et");

list.Insert("{D0434D5215B54181}Prefabs/Items/Medicine/MetoprololInjection/ACE_Medical_MetoprololInjection.et");
list.Insert("{D0434D5215B54181}Prefabs/Items/Medicine/MetoprololInjection/ACE_Medical_MetoprololInjection.et");
list.Insert("{D0434D5215B54181}Prefabs/Items/Medicine/MetoprololInjection/ACE_Medical_MetoprololInjection.et");
list.Insert("{D0434D5215B54181}Prefabs/Items/Medicine/MetoprololInjection/ACE_Medical_MetoprololInjection.et");
list.Insert("{D0434D5215B54181}Prefabs/Items/Medicine/MetoprololInjection/ACE_Medical_MetoprololInjection.et");
list.Insert("{D0434D5215B54181}Prefabs/Items/Medicine/MetoprololInjection/ACE_Medical_MetoprololInjection.et");
list.Insert("{D0434D5215B54181}Prefabs/Items/Medicine/MetoprololInjection/ACE_Medical_MetoprololInjection.et");
list.Insert("{D0434D5215B54181}Prefabs/Items/Medicine/MetoprololInjection/ACE_Medical_MetoprololInjection.et");
list.Insert("{D0434D5215B54181}Prefabs/Items/Medicine/MetoprololInjection/ACE_Medical_MetoprololInjection.et");
list.Insert("{D0434D5215B54181}Prefabs/Items/Medicine/MetoprololInjection/ACE_Medical_MetoprololInjection.et");

list.Insert("{02DD34077F51F65E}Prefabs/Items/Medicine/NaloxoneInjection/ACE_Medical_NaloxoneInjection.et");
list.Insert("{02DD34077F51F65E}Prefabs/Items/Medicine/NaloxoneInjection/ACE_Medical_NaloxoneInjection.et");
list.Insert("{02DD34077F51F65E}Prefabs/Items/Medicine/NaloxoneInjection/ACE_Medical_NaloxoneInjection.et");
list.Insert("{02DD34077F51F65E}Prefabs/Items/Medicine/NaloxoneInjection/ACE_Medical_NaloxoneInjection.et");
list.Insert("{02DD34077F51F65E}Prefabs/Items/Medicine/NaloxoneInjection/ACE_Medical_NaloxoneInjection.et");
list.Insert("{02DD34077F51F65E}Prefabs/Items/Medicine/NaloxoneInjection/ACE_Medical_NaloxoneInjection.et");
list.Insert("{02DD34077F51F65E}Prefabs/Items/Medicine/NaloxoneInjection/ACE_Medical_NaloxoneInjection.et");
list.Insert("{02DD34077F51F65E}Prefabs/Items/Medicine/NaloxoneInjection/ACE_Medical_NaloxoneInjection.et");
list.Insert("{02DD34077F51F65E}Prefabs/Items/Medicine/NaloxoneInjection/ACE_Medical_NaloxoneInjection.et");
list.Insert("{02DD34077F51F65E}Prefabs/Items/Medicine/NaloxoneInjection/ACE_Medical_NaloxoneInjection.et");

list.Insert("{9BBA766CD869002C}Prefabs/Items/Medicine/PhenylephrineInjection/ACE_Medical_PhenylephrineInjection.et");
list.Insert("{9BBA766CD869002C}Prefabs/Items/Medicine/PhenylephrineInjection/ACE_Medical_PhenylephrineInjection.et");
list.Insert("{9BBA766CD869002C}Prefabs/Items/Medicine/PhenylephrineInjection/ACE_Medical_PhenylephrineInjection.et");
list.Insert("{9BBA766CD869002C}Prefabs/Items/Medicine/PhenylephrineInjection/ACE_Medical_PhenylephrineInjection.et");
list.Insert("{9BBA766CD869002C}Prefabs/Items/Medicine/PhenylephrineInjection/ACE_Medical_PhenylephrineInjection.et");
list.Insert("{9BBA766CD869002C}Prefabs/Items/Medicine/PhenylephrineInjection/ACE_Medical_PhenylephrineInjection.et");
list.Insert("{9BBA766CD869002C}Prefabs/Items/Medicine/PhenylephrineInjection/ACE_Medical_PhenylephrineInjection.et");
list.Insert("{9BBA766CD869002C}Prefabs/Items/Medicine/PhenylephrineInjection/ACE_Medical_PhenylephrineInjection.et");
list.Insert("{9BBA766CD869002C}Prefabs/Items/Medicine/PhenylephrineInjection/ACE_Medical_PhenylephrineInjection.et");
list.Insert("{9BBA766CD869002C}Prefabs/Items/Medicine/PhenylephrineInjection/ACE_Medical_PhenylephrineInjection.et");

list.Insert("{0D9A5DCF89AE7AA9}Prefabs/Items/Medicine/MorphineInjection_01/MorphineInjection_01.et");
list.Insert("{0D9A5DCF89AE7AA9}Prefabs/Items/Medicine/MorphineInjection_01/MorphineInjection_01.et");
list.Insert("{0D9A5DCF89AE7AA9}Prefabs/Items/Medicine/MorphineInjection_01/MorphineInjection_01.et");
list.Insert("{0D9A5DCF89AE7AA9}Prefabs/Items/Medicine/MorphineInjection_01/MorphineInjection_01.et");
list.Insert("{0D9A5DCF89AE7AA9}Prefabs/Items/Medicine/MorphineInjection_01/MorphineInjection_01.et");
list.Insert("{0D9A5DCF89AE7AA9}Prefabs/Items/Medicine/MorphineInjection_01/MorphineInjection_01.et");
list.Insert("{0D9A5DCF89AE7AA9}Prefabs/Items/Medicine/MorphineInjection_01/MorphineInjection_01.et");
list.Insert("{0D9A5DCF89AE7AA9}Prefabs/Items/Medicine/MorphineInjection_01/MorphineInjection_01.et");
list.Insert("{0D9A5DCF89AE7AA9}Prefabs/Items/Medicine/MorphineInjection_01/MorphineInjection_01.et");
list.Insert("{0D9A5DCF89AE7AA9}Prefabs/Items/Medicine/MorphineInjection_01/MorphineInjection_01.et");

list.Insert("{8435F7561C0FBB44}Prefabs/Items/Medicine/SalineBag_01/SalineBag_01_base.et");
list.Insert("{8435F7561C0FBB44}Prefabs/Items/Medicine/SalineBag_01/SalineBag_01_base.et");
list.Insert("{8435F7561C0FBB44}Prefabs/Items/Medicine/SalineBag_01/SalineBag_01_base.et");
list.Insert("{8435F7561C0FBB44}Prefabs/Items/Medicine/SalineBag_01/SalineBag_01_base.et");
list.Insert("{8435F7561C0FBB44}Prefabs/Items/Medicine/SalineBag_01/SalineBag_01_base.et");
list.Insert("{8435F7561C0FBB44}Prefabs/Items/Medicine/SalineBag_01/SalineBag_01_base.et");
list.Insert("{8435F7561C0FBB44}Prefabs/Items/Medicine/SalineBag_01/SalineBag_01_base.et");
list.Insert("{8435F7561C0FBB44}Prefabs/Items/Medicine/SalineBag_01/SalineBag_01_base.et");
list.Insert("{8435F7561C0FBB44}Prefabs/Items/Medicine/SalineBag_01/SalineBag_01_base.et");
list.Insert("{8435F7561C0FBB44}Prefabs/Items/Medicine/SalineBag_01/SalineBag_01_base.et");
			
		
			
				break;
			
			case EJobType.POLICIER:
				// Uniforme police complet + M9 + magazines 9x19 + Taser + Matraque
			

			
				list.Insert("{2CA3E625A4409DE3}Prefabs/Clothing/HOLSTER.et");
				list.Insert("{06727B763B3A793F}Prefabs/Clothing/CACHECOU_GENDARMERIE.et");
				list.Insert("{25620A1EFBFE15E8}Prefabs/Characters/Headgear/Hat_M70/Hat_frbi_Black_Police.et");
				list.Insert("{A4A99396151F3594}Prefabs/Characters/Uniforms/Chemise_F1/Chemise_F1_Police_Noire.et");
				list.Insert("{76D6BDBFCEBC65BD}Prefabs/Characters/Uniforms/Pantalon_F1/Pantalon_F1_Secu_Black.et");
				list.Insert("{4D4AAC887A605678}Prefabs/Characters/Footwear/Boots_Rangers/Footwear_Rangers_FRBI.et");
				list.Insert("{F843BEAE5B06A614}Prefabs/Items/Backpacks/Backpack_FRBI/Backpack_FRBI_BLACK.et");
				list.Insert("{7EAF5CA342E1127F}Prefabs/Items/Equipment/Accessories/Holster_PM/Holster_PM__F1.et");
				list.Insert("{A81F501D3EF6F38E}Prefabs/Items/Medicine/FieldDressing_01/FieldDressing_US_01.et");
				list.Insert("{A81F501D3EF6F38E}Prefabs/Items/Medicine/FieldDressing_01/FieldDressing_US_01.et");
				list.Insert("{0D9A5DCF89AE7AA9}Prefabs/Items/Medicine/MorphineInjection_01/MorphineInjection_01.et");
				list.Insert("{0D9A5DCF89AE7AA9}Prefabs/Items/Medicine/MorphineInjection_01/MorphineInjection_01.et");
				list.Insert("{E1A5D4B878AA8980}Prefabs/Items/Equipment/Radios/Radio_R148.et");
				// Arme de service M9 + 3 magazines 9x19 15rnd
				list.Insert("{DCB6FDCC7ECD9F38}Prefabs/Weapons/Handguns/Glock18C/Handgun_Glock18C_01.et");
				list.Insert("{2476B3A801103E68}Prefabs/Weapons/Magazines/Magazine_Glock18C.et");
				list.Insert("{2476B3A801103E68}Prefabs/Weapons/Magazines/Magazine_Glock18C.et");
			
				// Taser + 2 cartouches + Matraque
				list.Insert("{04A1E119415742F4}Prefabs/Weapons/Handguns/M9/TASER.et");
				list.Insert("{FFDAD1F2B025C17D}Prefabs/Weapons/Magazines/taser mag.et");
				list.Insert("{FFDAD1F2B025C17D}Prefabs/Weapons/Magazines/taser mag.et");
			    list.Insert("{FFDAD1F2B025C17D}Prefabs/Weapons/Magazines/taser mag.et");
				list.Insert("{FFDAD1F2B025C17D}Prefabs/Weapons/Magazines/taser mag.et");
				list.Insert("{200873F3186B0923}Prefabs/Items/ZipTieItem.et");
				list.Insert("{200873F3186B0923}Prefabs/Items/ZipTieItem.et");
				list.Insert("{200873F3186B0923}Prefabs/Items/ZipTieItem.et");
				list.Insert("{200873F3186B0923}Prefabs/Items/ZipTieItem.et");
			    list.Insert("{CBF9B9942E07B6B8}Prefabs/Items/Equipment/Accessories/ZipCuffs/ACE_Captives_ZipCuffs.et");
			    list.Insert("{FFDAD1F2B025C17D}Prefabs/Weapons/Magazines/taser mag.et");
				break;
			
			case EJobType.CONCESSIONNAIRE:
				// Tenue concessionnaire (bottes, casquette plate gris clair, veste denim rayée, pantalon noir)
				list.Insert("{72FC15E92093C1B5}Prefabs/Footwear/AF1/Forceshoesblack.et");
				list.Insert("{27162F1F6EE6581A}Prefabs/Characters/Uniforms/Jacket_Denim_01/Jacket_Denim_01_brownShirt.et");
				list.Insert("{E3ABB650A6058174}Prefabs/Uniforms/Pants/Slim_pants2/Slim_Pants2.et");
				break;
			
			case EJobType.MILITAIRE:
				// Uniforme militaire complet + M21 ARTII + M16A2 + magazines 5.56
				list.Insert("{2CA3E625A4409DE3}Prefabs/Clothing/HOLSTER.et");
				list.Insert("{06727B763B3A793F}Prefabs/Clothing/CACHECOU_GENDARMERIE.et");
				list.Insert("{4D4AAC887A605678}Prefabs/Characters/Footwear/Boots_Rangers/Footwear_Rangers_FRBI.et");
				list.Insert("{9DC9C8310EC1FF10}Prefabs/Characters/Uniforms/Chemise_F1/Chemise_F1_Base.et");
				list.Insert("{369DB679FE06AF8F}Prefabs/Characters/Uniforms/Pantalon_F1/Pantalon_F1_Black.et");
			    list.Insert("{EEECE7676BC61023}Prefabs/Characters/Vests/Gilet_F1/Gilet_F1_Gendarmerie.et");
				list.Insert("{1C764F39C5108A15}Prefabs/Items/Equipment/Backpacks/SAC_GENDARMERIE.et");
				list.Insert("{A81F501D3EF6F38E}Prefabs/Items/Medicine/FieldDressing_01/FieldDressing_US_01.et");
				list.Insert("{A81F501D3EF6F38E}Prefabs/Items/Medicine/FieldDressing_01/FieldDressing_US_01.et");
				list.Insert("{0D9A5DCF89AE7AA9}Prefabs/Items/Medicine/MorphineInjection_01/MorphineInjection_01.et");
				list.Insert("{0D9A5DCF89AE7AA9}Prefabs/Items/Medicine/MorphineInjection_01/MorphineInjection_01.et");
				list.Insert("{DCB6FDCC7ECD9F38}Prefabs/Weapons/Handguns/Glock18C/Handgun_Glock18C_01.et");
				list.Insert("{2476B3A801103E68}Prefabs/Weapons/Magazines/Magazine_Glock18C.et");
				list.Insert("{2476B3A801103E68}Prefabs/Weapons/Magazines/Magazine_Glock18C.et");
				list.Insert("{E1A5D4B878AA8980}Prefabs/Items/Equipment/Radios/Radio_R148.et");
				list.Insert("{E44FEA37D1702CD8}Prefabs/Characters/Handwear/Gloves_Leather_01/BRASSARD.et");
			
			
				// Magazines 5.56 STANAG 30rnd (4 exemplaires)
				list.Insert("{200873F3186B0923}Prefabs/Items/ZipTieItem.et");
				list.Insert("{200873F3186B0923}Prefabs/Items/ZipTieItem.et");
				list.Insert("{200873F3186B0923}Prefabs/Items/ZipTieItem.et");
				list.Insert("{200873F3186B0923}Prefabs/Items/ZipTieItem.et");
			    list.Insert("{CBF9B9942E07B6B8}Prefabs/Items/Equipment/Accessories/ZipCuffs/ACE_Captives_ZipCuffs.et");
				list.Insert("{04A1E119415742F4}Prefabs/Weapons/Handguns/M9/TASER.et");
				list.Insert("{FFDAD1F2B025C17D}Prefabs/Weapons/Magazines/taser mag.et");
				list.Insert("{FFDAD1F2B025C17D}Prefabs/Weapons/Magazines/taser mag.et");
			    list.Insert("{CBF9B9942E07B6B8}Prefabs/Items/Equipment/Accessories/ZipCuffs/ACE_Captives_ZipCuffs.et");
			    list.Insert("{FFDAD1F2B025C17D}Prefabs/Weapons/Magazines/taser mag.et");
				break;
			
			case EJobType.VOYOU:
				// Tenue Voyou/Bandit complete (look street/bandit)
				list.Insert("{CABF701DF5212647}Prefabs/Characters/Footwear/Sneakers/Sneakers_Dirty.et");
				list.Insert("{7A32D0C6743CCEBE}Prefabs/Characters/Handwear/Gloves_Wool_Skeleton/Gloves_Wool_Skeleton.et");
				list.Insert("{4E872D34D13AB8B6}Prefabs/Characters/HeadGear/Hood/Hood_Black.et");
				list.Insert("{C500301CF7AE1ACB}Prefabs/Characters/HeadGear/Balaclava/Balaclava_Wool_Black.et");
				list.Insert("{DB053443800A3FCB}Prefabs/Characters/Uniforms/Jacket_Bandit/Jacket_Bandit.et");
				list.Insert("{21DC09217E13C1C7}Prefabs/Characters/Uniforms/Pants_Cargo/Pants_Cargo_Black.et");
				list.Insert("{FF742375E12302B4}Prefabs/Characters/Misc/Cigarette.et");
				// Bonus style: 2 bouteilles de vodka
				list.Insert("{DCDF534783F9C73D}Prefabs/Items/Medicine/Vodka_Bottle/Vodka_Bottle.et");
				list.Insert("{DCDF534783F9C73D}Prefabs/Items/Medicine/Vodka_Bottle/Vodka_Bottle.et");
				// Le Voyou achete ses armes via le menu "Marche noir" (pas d'arme gratuite)
				break;
			
			case EJobType.VENDEUR_IMMOBILIER:
				// Tenue agent immobilier (col roule classique, pantalon costume gris, baskets noires)
				list.Insert("{00ECD7EB467C97D7}Prefabs/Characters/Uniforms/Shirt_CottonShirt_01/Shirt_CottonShirt_01_V3_Dirty.et");
				list.Insert("{E3ABB650A6058174}Prefabs/Uniforms/Pants/Slim_pants2/Slim_Pants2.et");
				list.Insert("{BF5959308824880F}Prefabs/Footwear/basket shoes/basket_Black.et");
				break;
		}
		
		return list;
	}
	
	//------------------------------------------------------------------------------------------------
	// Spawn un prefab et l'ajoute a l'inventaire du joueur.
	// Retourne true si succes, false sinon.
	//------------------------------------------------------------------------------------------------
	static bool SpawnAndGiveItem(IEntity player, ResourceName prefabName)
	{
		Resource res = Resource.Load(prefabName);
		if (!res || !res.IsValid())
		{
			Print(string.Format("[JobEquipmentGiver] Prefab invalide: %1", prefabName), LogLevel.WARNING);
			return false;
		}
		
		// Spawn a la position du joueur
		EntitySpawnParams params = new EntitySpawnParams();
		params.TransformMode = ETransformMode.WORLD;
		player.GetWorldTransform(params.Transform);
		
		IEntity item = GetGame().SpawnEntityPrefab(res, player.GetWorld(), params);
		if (!item)
		{
			Print(string.Format("[JobEquipmentGiver] Spawn echoue: %1", prefabName), LogLevel.WARNING);
			return false;
		}
		
		// Ajout a l'inventaire via SCR_InventoryStorageManagerComponent
		SCR_InventoryStorageManagerComponent inv = SCR_InventoryStorageManagerComponent.Cast(
			player.FindComponent(SCR_InventoryStorageManagerComponent));
		
		if (!inv)
		{
			Print("[JobEquipmentGiver] InventoryStorageManager introuvable, suppression item",
				LogLevel.WARNING);
			SCR_EntityHelper.DeleteEntityAndChildren(item);
			return false;
		}
		
		bool added = inv.TryInsertItem(item);
		if (!added)
		{
			// Inventaire plein: on laisse l'item au sol a la position du joueur (pas de delete)
			Print(string.Format("[JobEquipmentGiver] Inventaire plein, item pose au sol: %1", prefabName),
				LogLevel.NORMAL);
		}
		
		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	// Helper: spawn et donne plusieurs exemplaires du meme item au joueur
	// Retourne true si au moins un item a ete donne avec succes
	//------------------------------------------------------------------------------------------------
	static bool SpawnAndGiveItemQuantity(IEntity player, ResourceName prefabName, int quantity)
	{
		bool atLeastOne = false;
		for (int i = 0; i < quantity; i++)
		{
			if (SpawnAndGiveItem(player, prefabName))
				atLeastOne = true;
		}
		return atLeastOne;
	}
}
