//------------------------------------------------------------------------------------------------
// JobPochonSaleManager.c
// Singleton serveur qui gere les ventes de pochons au PNJ acheteur.
// - Fenetre glissante 10 min : le joueur peut vendre max 5 pochons dans la fenetre
// - La fenetre demarre a la 1re vente ; apres expiration -> reset a 0
// - Persistance JSON par joueur ($profile:LesPacifistesJobs/pochonsales/UID.json)
//------------------------------------------------------------------------------------------------

class JobPochonSaleRecord
{
	int m_WindowStartUnix = 0;  // timestamp Unix de la 1re vente de la fenetre courante
	int m_CountInWindow = 0;    // nombre de pochons vendus dans la fenetre
	
	void JobPochonSaleRecord()
	{
		m_WindowStartUnix = 0;
		m_CountInWindow = 0;
	}
}

class JobPochonSaleManager
{
	static ref JobPochonSaleManager s_Instance;
	
	// Map UID -> record de vente
	ref map<string, ref JobPochonSaleRecord> m_Records = new map<string, ref JobPochonSaleRecord>();
	
	const string SAVE_FILE = "$profile:LesPacifistesJobs/pochon_sales.json";
	bool m_Loaded = false;
	
	//------------------------------------------------------------------------------------------------
	static JobPochonSaleManager GetInstance()
	{
		if (!s_Instance)
		{
			s_Instance = new JobPochonSaleManager();
			s_Instance.LoadAllFromDisk();
		}
		return s_Instance;
	}
	
	//------------------------------------------------------------------------------------------------
	// Recupere le record pour un joueur (cree si absent)
	//------------------------------------------------------------------------------------------------
	JobPochonSaleRecord GetOrCreateRecord(string uid)
	{
		if (uid == "") return null;
		
		JobPochonSaleRecord existing = m_Records.Get(uid);
		if (existing) return existing;
		
		JobPochonSaleRecord fresh = new JobPochonSaleRecord();
		m_Records.Set(uid, fresh);
		return fresh;
	}
	
	//------------------------------------------------------------------------------------------------
	// Verifie et rafraichit la fenetre glissante :
	// si la fenetre courante est expiree, reset a 0.
	// Retourne le nombre de pochons ENCORE VENDABLES dans la fenetre.
	//------------------------------------------------------------------------------------------------
	int GetRemainingQuota(string uid)
	{
		JobPochonSaleRecord rec = GetOrCreateRecord(uid);
		if (!rec) return 0;
		
		RefreshWindow(rec);
		int remaining = JobPochonData.MAX_VENTES_PAR_FENETRE - rec.m_CountInWindow;
		if (remaining < 0) remaining = 0;
		return remaining;
	}
	
	//------------------------------------------------------------------------------------------------
	// Retourne le timestamp Unix a partir duquel le joueur pourra a nouveau vendre au max
	// (0 si aucune fenetre en cours, sinon m_WindowStartUnix + FENETRE_VENTE_S)
	//------------------------------------------------------------------------------------------------
	int GetWindowEndUnix(string uid)
	{
		JobPochonSaleRecord rec = GetOrCreateRecord(uid);
		if (!rec) return 0;
		RefreshWindow(rec);
		if (rec.m_CountInWindow == 0) return 0;
		return rec.m_WindowStartUnix + JobPochonData.FENETRE_VENTE_S;
	}
	
	//------------------------------------------------------------------------------------------------
	// Si la fenetre est expiree, reset le record a 0.
	//------------------------------------------------------------------------------------------------
	void RefreshWindow(JobPochonSaleRecord rec)
	{
		if (!rec) return;
		if (rec.m_WindowStartUnix == 0) return;
		int now = System.GetUnixTime();
		if (now - rec.m_WindowStartUnix >= JobPochonData.FENETRE_VENTE_S)
		{
			// Fenetre expiree -> reset
			rec.m_WindowStartUnix = 0;
			rec.m_CountInWindow = 0;
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Enregistre une vente de N pochons (a appeler APRES avoir valide la vente).
	// Si aucune fenetre en cours, on demarre a maintenant.
	//------------------------------------------------------------------------------------------------
	void RecordSale(string uid, int quantity)
	{
		if (uid == "" || quantity <= 0) return;
		JobPochonSaleRecord rec = GetOrCreateRecord(uid);
		if (!rec) return;
		
		RefreshWindow(rec);
		
		if (rec.m_WindowStartUnix == 0)
			rec.m_WindowStartUnix = System.GetUnixTime();
		rec.m_CountInWindow = rec.m_CountInWindow + quantity;
		
		SaveAllToDisk();
	}
	
	//------------------------------------------------------------------------------------------------
	// Charge toutes les records depuis un fichier plat unique
	//------------------------------------------------------------------------------------------------
	void LoadAllFromDisk()
	{
		if (m_Loaded) return;
		m_Loaded = true;
		
		if (!FileIO.FileExists(SAVE_FILE)) return;
		
		SCR_JsonLoadContext ctx = new SCR_JsonLoadContext();
		if (!ctx.LoadFromFile(SAVE_FILE)) return;
		
		int count = 0;
		ctx.ReadValue("count", count);
		
		for (int i = 0; i < count; i++)
		{
			string prefix = "records/" + i.ToString() + "/";
			string uid = "";
			int windowStart = 0;
			int countInWindow = 0;
			ctx.ReadValue(prefix + "uid", uid);
			ctx.ReadValue(prefix + "windowStart", windowStart);
			ctx.ReadValue(prefix + "countInWindow", countInWindow);
			if (uid == "") continue;
			JobPochonSaleRecord rec = new JobPochonSaleRecord();
			rec.m_WindowStartUnix = windowStart;
			rec.m_CountInWindow = countInWindow;
			m_Records.Set(uid, rec);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Sauvegarde toutes les records dans un fichier plat unique
	//------------------------------------------------------------------------------------------------
	void SaveAllToDisk()
	{
		SCR_JsonSaveContext ctx = new SCR_JsonSaveContext();
		ctx.WriteValue("count", m_Records.Count());
		
		int i = 0;
		foreach (string uid, JobPochonSaleRecord rec : m_Records)
		{
			if (!rec) continue;
			string prefix = "records/" + i.ToString() + "/";
			ctx.WriteValue(prefix + "uid", uid);
			ctx.WriteValue(prefix + "windowStart", rec.m_WindowStartUnix);
			ctx.WriteValue(prefix + "countInWindow", rec.m_CountInWindow);
			i = i + 1;
		}
		ctx.SaveToFile(SAVE_FILE);
	}
}
