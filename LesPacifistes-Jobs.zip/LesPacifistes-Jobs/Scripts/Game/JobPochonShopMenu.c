//------------------------------------------------------------------------------------------------
// JobPochonShopMenu.c
// Menu shop dedie aux marchandises (achat sac a pochon).
//------------------------------------------------------------------------------------------------

class JobPochonShopMenu : ChimeraMenuBase
{
	Widget m_RootWidget;
	TextWidget m_TitleText;
	TextWidget m_DescriptionText;
	TextWidget m_CapsulesText;
	ButtonWidget m_BtnBuy;
	ButtonWidget m_BtnClose;
	
	// Singleton pour reception RPC de rafraichissement capsules
	static JobPochonShopMenu s_Instance;
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuOpen()
	{
		super.OnMenuOpen();
		s_Instance = this;
		JobFocusHandler.ClearRegistry();
		
		m_RootWidget = GetRootWidget();
		if (!m_RootWidget) return;
		
		m_TitleText = TextWidget.Cast(m_RootWidget.FindAnyWidget("TitleText"));
		m_DescriptionText = TextWidget.Cast(m_RootWidget.FindAnyWidget("DescriptionText"));
		m_CapsulesText = TextWidget.Cast(m_RootWidget.FindAnyWidget("CapsulesText"));
		m_BtnBuy = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnBuy"));
		m_BtnClose = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnClose"));
		
		if (m_BtnBuy)
		{
			PochonShopBtnHandler h = new PochonShopBtnHandler();
			h.m_Menu = this;
			h.m_Action = "buy";
			m_BtnBuy.AddHandler(h);
			JobFocusHandler.Attach(m_BtnBuy);
		}
		if (m_BtnClose)
		{
			PochonShopBtnHandler h = new PochonShopBtnHandler();
			h.m_Menu = this;
			h.m_Action = "close";
			m_BtnClose.AddHandler(h);
			JobFocusHandler.Attach(m_BtnClose);
		}
		
		// Demande le solde de capsules au serveur
		PlayerController pc = GetGame().GetPlayerController();
		if (pc)
		{
			JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
			if (jpc) jpc.ClientAskCapsulesForPochonShop();
		}
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuClose()
	{
		if (s_Instance == this) s_Instance = null;
		super.OnMenuClose();
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuUpdate(float tDelta)
	{
		super.OnMenuUpdate(tDelta);
		if (GetGame().GetInputManager().GetActionValue("MenuBack") > 0.5)
			CloseMenuInternal();
	}
	
	//------------------------------------------------------------------------------------------------
	// Appele par RPC serveur pour afficher les capsules du joueur
	//------------------------------------------------------------------------------------------------
	void DisplayCapsules(int capsules)
	{
		if (!m_CapsulesText) return;
		m_CapsulesText.SetText(string.Format("Capsules : %1", capsules.ToString()));
		if (m_BtnBuy)
			m_BtnBuy.SetEnabled(capsules >= JobPochonData.PRIX_SAC_POCHON);
	}
	
	//------------------------------------------------------------------------------------------------
	void OnButtonClicked(string action)
	{
		if (action == "close")
		{
			CloseMenuInternal();
			return;
		}
		if (action == "buy")
		{
			PlayerController pc = GetGame().GetPlayerController();
			if (!pc) return;
			JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
			if (jpc) jpc.ClientAskBuyPochonBag();
			// On ferme apres achat, le serveur enverra une notif chat
			GetGame().GetCallqueue().CallLater(CloseMenuInternal, 300, false);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void CloseMenuInternal()
	{
		GetGame().GetMenuManager().CloseMenu(this);
	}
	
	//------------------------------------------------------------------------------------------------
	static JobPochonShopMenu GetOpenMenu() { return s_Instance; }
}

//------------------------------------------------------------------------------------------------
class PochonShopBtnHandler : ScriptedWidgetEventHandler
{
	JobPochonShopMenu m_Menu;
	string m_Action;
	
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.OnButtonClicked(m_Action);
		return true;
	}
}
