//------------------------------------------------------------------------------------------------
// JobBonPointChatMenu.c
// Chat 1-to-1 entre vendeur et acheteur sur une annonce.
//
// Workflow :
//  1. Le menu s ouvre avec adId + buyerUID pre-charges
//  2. Le serveur envoie les messages existants
//  3. Auto-refresh toutes les 5 secondes (re-demande au serveur)
//  4. Bouton Envoyer : envoie un nouveau message
//
// Pattern : la conversation est cle = "adId_buyerUID"
// L acheteur identifie sa conversation par son propre UID.
// Le vendeur, si plusieurs acheteurs lui ont parle, devra choisir avec lequel discuter
// (pour l instant : on ouvre toujours la conversation avec l acheteur courant = soi-meme
// si on est acheteur, sinon avec le 1er acheteur qui a ecrit - simplification Session 3).
//------------------------------------------------------------------------------------------------

class JobBonPointChatMenu : ChimeraMenuBase
{
	const string ENTRY_LAYOUT_PATH = "{782FC5924D5F5CC3}UI/layouts/JobBonPointChatEntry.layout";
	const int REFRESH_INTERVAL_MS = 5000;
	
	Widget m_RootWidget;
	TextWidget m_TitleText;
	TextWidget m_SubtitleText;
	Widget m_MessagesContainer;
	TextWidget m_EmptyText;
	EditBoxWidget m_InputBox;
	ButtonWidget m_BtnSend;
	ButtonWidget m_BtnBack;
	
	// Pre-charge avant ouverture
	static int s_AdId;
	static string s_BuyerUID;        // identifie la conversation
	static string s_OtherDisplayName; // affichage : a qui je parle
	static string s_AdTitle;
	
	// Donnees recues du serveur (les messages)
	static ref array<int> s_PendingTimestamps = new array<int>();
	static ref array<string> s_PendingAuthorUIDs = new array<string>();
	static ref array<string> s_PendingAuthorNames = new array<string>();
	static ref array<string> s_PendingTexts = new array<string>();
	
	// Mon propre UID, recu du serveur a l ouverture (pour aligner mes messages a droite)
	static string s_MyUID = "";
	
	static JobBonPointChatMenu s_Instance;
	
	//------------------------------------------------------------------------------------------------
	static void SetPendingContext(int adId, string buyerUID, string otherName, string adTitle)
	{
		s_AdId = adId;
		s_BuyerUID = buyerUID;
		s_OtherDisplayName = otherName;
		s_AdTitle = adTitle;
	}
	
	static void SetPendingMessages(array<int> ts, array<string> uids, array<string> names,
		array<string> texts, string myUID)
	{
		s_PendingTimestamps.Clear();
		s_PendingAuthorUIDs.Clear();
		s_PendingAuthorNames.Clear();
		s_PendingTexts.Clear();
		foreach (int t : ts) s_PendingTimestamps.Insert(t);
		foreach (string u : uids) s_PendingAuthorUIDs.Insert(u);
		foreach (string n : names) s_PendingAuthorNames.Insert(n);
		foreach (string txt : texts) s_PendingTexts.Insert(txt);
		s_MyUID = myUID;
		
		// Si le menu est deja ouvert (auto-refresh), met a jour la liste sans tout reconstruire
		if (s_Instance)
			s_Instance.BuildMessages();
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuOpen()
	{
		super.OnMenuOpen();
		s_Instance = this;
		JobFocusHandler.ClearRegistry();
		
		m_RootWidget = GetRootWidget();
		if (!m_RootWidget) return;
		
		m_TitleText = TextWidget.Cast(m_RootWidget.FindAnyWidget("TitleText"));
		m_SubtitleText = TextWidget.Cast(m_RootWidget.FindAnyWidget("SubtitleText"));
		m_MessagesContainer = m_RootWidget.FindAnyWidget("MessagesContainer");
		m_EmptyText = TextWidget.Cast(m_RootWidget.FindAnyWidget("EmptyText"));
		m_InputBox = EditBoxWidget.Cast(m_RootWidget.FindAnyWidget("InputBox"));
		m_BtnSend = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnSend"));
		m_BtnBack = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnBack"));
		
		if (m_TitleText)
			m_TitleText.SetText(string.Format("Discussion : %1", s_AdTitle));
		if (m_SubtitleText)
			m_SubtitleText.SetText(string.Format("Avec : %1", s_OtherDisplayName));
		
		if (m_BtnSend)
		{
			BonPointChatHandler h = new BonPointChatHandler();
			h.m_Menu = this;
			h.m_Action = "send";
			m_BtnSend.AddHandler(h);
			JobFocusHandler.Attach(m_BtnSend);
		}
		if (m_BtnBack)
		{
			BonPointChatHandler h = new BonPointChatHandler();
			h.m_Menu = this;
			h.m_Action = "back";
			m_BtnBack.AddHandler(h);
			JobFocusHandler.Attach(m_BtnBack);
			GetGame().GetWorkspace().SetFocusedWidget(m_BtnBack);
		}
		
		// Affichage initial des messages deja pre-charges
		BuildMessages();
		
		// Demarre auto-refresh toutes les 5s
		GetGame().GetCallqueue().CallLater(AutoRefresh, REFRESH_INTERVAL_MS, true);
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuClose()
	{
		GetGame().GetCallqueue().Remove(AutoRefresh);
		if (s_Instance == this) s_Instance = null;
		super.OnMenuClose();
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuUpdate(float tDelta)
	{
		super.OnMenuUpdate(tDelta);
		if (GetGame().GetInputManager().GetActionValue("MenuBack") > 0.5)
			CloseMenuInternal();
	}
	
	//------------------------------------------------------------------------------------------------
	// Reconstruit la liste des messages (appelee a chaque refresh ou ouverture)
	void BuildMessages()
	{
		if (!m_MessagesContainer) return;
		
		Widget child = m_MessagesContainer.GetChildren();
		while (child)
		{
			Widget next = child.GetSibling();
			child.RemoveFromHierarchy();
			child = next;
		}
		
		if (s_PendingTimestamps.Count() == 0)
		{
			if (m_EmptyText)
			{
				m_EmptyText.SetText("Aucun message. Commencez la conversation !");
				m_EmptyText.SetVisible(true);
			}
			return;
		}
		if (m_EmptyText) m_EmptyText.SetVisible(false);
		
		WorkspaceWidget ws = GetGame().GetWorkspace();
		for (int i = 0; i < s_PendingTimestamps.Count(); i++)
		{
			string authorUID = s_PendingAuthorUIDs.Get(i);
			string authorName = s_PendingAuthorNames.Get(i);
			string text = s_PendingTexts.Get(i);
			bool isMyMsg = (authorUID == s_MyUID);
			
			Widget entry = ws.CreateWidgets(ENTRY_LAYOUT_PATH, m_MessagesContainer);
			if (!entry) continue;
			
			TextWidget nameW = TextWidget.Cast(entry.FindAnyWidget("MsgAuthor"));
			if (nameW)
			{
				string prefix;
				if (isMyMsg)
					prefix = "Moi";
				else
					prefix = authorName;
				nameW.SetText(prefix);
				// Couleur differente selon auteur
				if (isMyMsg)
					nameW.SetColor(Color.FromRGBA(50, 190, 75, 255));  // vert pour moi
				else
					nameW.SetColor(Color.FromRGBA(240, 190, 50, 255)); // or pour l autre
			}
			TextWidget textW = TextWidget.Cast(entry.FindAnyWidget("MsgText"));
			if (textW) textW.SetText(text);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Demande au serveur les derniers messages (auto-refresh + apres envoi)
	void AutoRefresh()
	{
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		jpc.ClientAskBonPointChatMessages(s_AdId, s_BuyerUID);
	}
	
	//------------------------------------------------------------------------------------------------
	void OnAction(string action)
	{
		if (action == "back")
		{
			CloseMenuInternal();
			return;
		}
		if (action == "send")
		{
			if (!m_InputBox) return;
			string text = m_InputBox.GetText();
			if (text == "") return;
			
			PlayerController pc = GetGame().GetPlayerController();
			if (!pc) return;
			JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
			if (!jpc) return;
			jpc.ClientAskSendBonPointChat(s_AdId, s_BuyerUID, text);
			
			// Vide le champ + refresh immediat (au lieu d attendre 5s)
			m_InputBox.SetText("");
			GetGame().GetCallqueue().CallLater(AutoRefresh, 200, false);
			return;
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void CloseMenuInternal()
	{
		GetGame().GetMenuManager().CloseMenu(this);
	}
	
	static JobBonPointChatMenu GetOpenMenu() { return s_Instance; }
}

//------------------------------------------------------------------------------------------------
class BonPointChatHandler : ScriptedWidgetEventHandler
{
	JobBonPointChatMenu m_Menu;
	string m_Action;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.OnAction(m_Action);
		return true;
	}
}
