//------------------------------------------------------------------------------------------------
// LP_EpicerieCraftAction.c
// Action "Craft epicerie" a placer sur une entite dediee via Workbench (comme la table de fishing).
// Visible UNIQUEMENT si le joueur a le metier EPICIER.
//------------------------------------------------------------------------------------------------

class LP_EpicerieCraftAction : ScriptedUserAction
{
	//------------------------------------------------------------------------------------------------
	override bool CanBeShownScript(IEntity user)
	{
		if (!user) return false;
		
		// Verifie le metier via JobCharacterJobComponent (client-side, rapide)
		JobCharacterJobComponent jcjc = JobCharacterJobComponent.Cast(
			user.FindComponent(JobCharacterJobComponent));
		if (!jcjc) return false;
		
		return jcjc.GetJob() == EJobType.EPICIER;
	}
	
	//------------------------------------------------------------------------------------------------
	override bool CanBePerformedScript(IEntity user)
	{
		return CanBeShownScript(user);
	}
	
	//------------------------------------------------------------------------------------------------
	override bool GetActionNameScript(out string outName)
	{
		outName = "Craft epicerie";
		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
	{
		PlayerController pc = PlayerController.Cast(GetGame().GetPlayerController());
		if (!pc) return;
		if (pUserEntity != pc.GetControlledEntity()) return;
		
		// Double check server-side : ouvre le menu localement
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		
		// Verifie le metier localement avant d ouvrir
		JobCharacterJobComponent jcjc = JobCharacterJobComponent.Cast(
			pUserEntity.FindComponent(JobCharacterJobComponent));
		if (!jcjc || jcjc.GetJob() != EJobType.EPICIER)
			return;
		
		GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.LP_EpicerieCraftMenu);
	}
}
