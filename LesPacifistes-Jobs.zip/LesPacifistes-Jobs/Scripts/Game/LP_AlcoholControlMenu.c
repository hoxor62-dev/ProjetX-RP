//------------------------------------------------------------------------------------------------
// LP_AlcoholControlMenu.c
// Menu qui affiche le taux d alcool d un joueur cible (pour Police / Militaire).
// Ouvert par LP_AlcoholControlAction, alimente par RPC serveur.
//------------------------------------------------------------------------------------------------

class LP_AlcoholControlMenu : ChimeraMenuBase
{
	static LP_AlcoholControlMenu s_Instance;
	static LP_AlcoholControlMenu GetOpenMenu() { return s_Instance; }
	
	Widget m_Root;
	TextWidget m_TitleText;
	TextWidget m_TargetNameText;
	TextWidget m_AlcoholLevelText;
	TextWidget m_StatusText;
	ButtonWidget m_BtnClose;
	
	int m_TargetPlayerId = 0;
	string m_TargetName = "";
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuOpen()
	{
		super.OnMenuOpen();
		s_Instance = this;
		JobFocusHandler.ClearRegistry();
		m_Root = GetRootWidget();
		if (!m_Root) return;
		
		m_TitleText        = TextWidget.Cast(m_Root.FindAnyWidget("TitleText"));
		m_TargetNameText   = TextWidget.Cast(m_Root.FindAnyWidget("TargetNameText"));
		m_AlcoholLevelText = TextWidget.Cast(m_Root.FindAnyWidget("AlcoholLevelText"));
		m_StatusText       = TextWidget.Cast(m_Root.FindAnyWidget("StatusText"));
		m_BtnClose         = ButtonWidget.Cast(m_Root.FindAnyWidget("BtnClose"));
		
		if (m_TitleText) m_TitleText.SetText("Controle Alcool");
		if (m_AlcoholLevelText) m_AlcoholLevelText.SetText("...");
		if (m_StatusText) m_StatusText.SetText("Recuperation du taux en cours...");
		
		if (m_BtnClose)
		{
			LP_AlcoholControlClickHandler h = new LP_AlcoholControlClickHandler();
			h.m_Menu = this;
			m_BtnClose.AddHandler(h);
			JobFocusHandler.Attach(m_BtnClose);
			GetGame().GetCallqueue().CallLater(FocusCloseButton, 50, false);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	protected void FocusCloseButton()
	{
		if (m_BtnClose)
			GetGame().GetWorkspace().SetFocusedWidget(m_BtnClose);
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuClose()
	{
		s_Instance = null;
		JobFocusHandler.ClearRegistry();
		super.OnMenuClose();
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuUpdate(float tDelta)
	{
		super.OnMenuUpdate(tDelta);
		if (GetGame().GetInputManager().GetActionValue("MenuBack") > 0.5)
			CloseMenuInternal();
	}
	
	//------------------------------------------------------------------------------------------------
	void Initialize(int targetPlayerId, string targetName)
	{
		m_TargetPlayerId = targetPlayerId;
		m_TargetName = targetName;
		
		if (m_TargetNameText)
			m_TargetNameText.SetText("Cible : " + targetName);
	}
	
	//------------------------------------------------------------------------------------------------
	// Appele par RPC serveur avec le taux d alcool de la cible
	//------------------------------------------------------------------------------------------------
	void DisplayAlcoholLevel(float level, string targetName)
	{
		if (m_TargetNameText && targetName != "")
			m_TargetNameText.SetText("Cible : " + targetName);
		
		if (m_AlcoholLevelText)
		{
			int rounded = level;
			m_AlcoholLevelText.SetText(rounded.ToString() + "%");
		}
		
		if (m_StatusText)
		{
			string status;
			if (level < 25)
				status = "Sobre - aucune trace d alcool notable";
			else if (level < 50)
				status = "Legere alcoolemie - conduite risquee";
			else if (level < 70)
				status = "Alcoolemie moyenne - INFRACTION";
			else if (level < 100)
				status = "Alcoolemie elevee - INFRACTION GRAVE";
			else
				status = "Alcoolemie critique - joueur inconscient";
			m_StatusText.SetText(status);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void CloseMenuInternal()
	{
		GetGame().GetMenuManager().CloseMenu(this);
	}
}

//------------------------------------------------------------------------------------------------
class LP_AlcoholControlClickHandler : ScriptedWidgetEventHandler
{
	LP_AlcoholControlMenu m_Menu;
	
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.CloseMenuInternal();
		return true;
	}
}
