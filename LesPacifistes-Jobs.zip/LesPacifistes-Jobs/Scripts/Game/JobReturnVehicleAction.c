//------------------------------------------------------------------------------------------------
// JobReturnVehicleAction.c
// Action F sur le PNJ ou prefab de retour de vehicule loue.
// A attacher via ActionsManagerComponent.
//
// Le serveur fait toutes les verifications (vehicule a moins de 7m, joueur sortie, etc).
//------------------------------------------------------------------------------------------------

class JobReturnVehicleAction : ScriptedUserAction
{
	//------------------------------------------------------------------------------------------------
	override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
	{
		if (!pUserEntity)
			return;
		
		PlayerController localPC = GetGame().GetPlayerController();
		if (!localPC)
			return;
		IEntity localEntity = localPC.GetControlledEntity();
		if (localEntity != pUserEntity)
			return;
		
		JobPlayerComponent jpc = JobPlayerComponent.Cast(localPC.FindComponent(JobPlayerComponent));
		if (!jpc)
			return;
		
		jpc.ClientAskReturnVehicle();
	}
	
	//------------------------------------------------------------------------------------------------
	override bool CanBeShownScript(IEntity user)
	{
		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	override bool CanBePerformedScript(IEntity user)
	{
		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	override bool GetActionNameScript(out string outName)
	{
		outName = "Rendre mon vehicule loue";
		return true;
	}
}
