//------------------------------------------------------------------------------------------------
// JobStoreVehicleAction.c
// Action UserAction "Stocker mon vehicule" sur le PNJ garage virtuel.
// Toujours visible : la verification "vehicule a proximite" est faite cote serveur lors
// de l execution (on n a pas envie de scan permanent cote client pour afficher/cacher).
//------------------------------------------------------------------------------------------------

class JobStoreVehicleAction : ScriptedUserAction
{
	//------------------------------------------------------------------------------------------------
	override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
	{
		if (!pOwnerEntity)
			return;
		
		// IMPORTANT (dedicated server) : PerformAction s execute sur TOUS les clients qui
		// voient l action localement. On filtre pour que seul le joueur local agisse.
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc)
			return;
		if (pUserEntity != pc.GetControlledEntity())
			return;
		
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc)
			return;
		
		// Envoie la RPC : le serveur cherchera le vehicule le plus proche du PNJ
		RplComponent rpl = RplComponent.Cast(pOwnerEntity.FindComponent(RplComponent));
		if (!rpl)
			return;
		jpc.ClientAskStoreVehicle(rpl.Id());
	}
	
	//------------------------------------------------------------------------------------------------
	override bool GetActionNameScript(out string outName)
	{
		outName = "Stocker mon vehicule";
		return true;
	}
}
