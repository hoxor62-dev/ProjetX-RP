//------------------------------------------------------------------------------------------------
// LP_CannabisControlMenu.c
// Menu qui affiche le taux de THC d un joueur cible (pour Police / Militaire).
//------------------------------------------------------------------------------------------------

class LP_CannabisControlMenu : ChimeraMenuBase
{
	static LP_CannabisControlMenu s_Instance;
	static LP_CannabisControlMenu GetOpenMenu() { return s_Instance; }
	
	Widget m_Root;
	TextWidget m_TitleText;
	TextWidget m_TargetNameText;
	TextWidget m_ThcLevelText;
	TextWidget m_StatusText;
	ButtonWidget m_BtnClose;
	
	int m_TargetPlayerId = 0;
	string m_TargetName = "";
	
	override void OnMenuOpen()
	{
		super.OnMenuOpen();
		s_Instance = this;
		JobFocusHandler.ClearRegistry();
		m_Root = GetRootWidget();
		if (!m_Root) return;
		
		m_TitleText      = TextWidget.Cast(m_Root.FindAnyWidget("TitleText"));
		m_TargetNameText = TextWidget.Cast(m_Root.FindAnyWidget("TargetNameText"));
		m_ThcLevelText   = TextWidget.Cast(m_Root.FindAnyWidget("ThcLevelText"));
		m_StatusText     = TextWidget.Cast(m_Root.FindAnyWidget("StatusText"));
		m_BtnClose       = ButtonWidget.Cast(m_Root.FindAnyWidget("BtnClose"));
		
		if (m_TitleText) m_TitleText.SetText("Controle Cannabis");
		if (m_ThcLevelText) m_ThcLevelText.SetText("...");
		if (m_StatusText) m_StatusText.SetText("Recuperation du taux en cours...");
		
		if (m_BtnClose)
		{
			LP_CannabisControlClickHandler h = new LP_CannabisControlClickHandler();
			h.m_Menu = this;
			m_BtnClose.AddHandler(h);
			JobFocusHandler.Attach(m_BtnClose);
			GetGame().GetCallqueue().CallLater(FocusCloseButton, 50, false);
		}
	}
	
	protected void FocusCloseButton()
	{
		if (m_BtnClose)
			GetGame().GetWorkspace().SetFocusedWidget(m_BtnClose);
	}
	
	override void OnMenuClose()
	{
		s_Instance = null;
		JobFocusHandler.ClearRegistry();
		super.OnMenuClose();
	}
	
	override void OnMenuUpdate(float tDelta)
	{
		super.OnMenuUpdate(tDelta);
		if (GetGame().GetInputManager().GetActionValue("MenuBack") > 0.5)
			CloseMenuInternal();
	}
	
	void Initialize(int targetPlayerId, string targetName)
	{
		m_TargetPlayerId = targetPlayerId;
		m_TargetName = targetName;
		if (m_TargetNameText)
			m_TargetNameText.SetText("Cible : " + targetName);
	}
	
	void DisplayThcLevel(float level, string targetName)
	{
		if (m_TargetNameText && targetName != "")
			m_TargetNameText.SetText("Cible : " + targetName);
		
		if (m_ThcLevelText)
		{
			int rounded = level;
			m_ThcLevelText.SetText(rounded.ToString() + "%");
		}
		
		if (m_StatusText)
		{
			string status;
			if (level < 25)
				status = "Negatif - aucune trace de THC notable";
			else if (level < 50)
				status = "Positif - consommation legere";
			else if (level < 70)
				status = "Positif - consommation moyenne - INFRACTION";
			else if (level < 100)
				status = "Positif - consommation elevee - INFRACTION GRAVE";
			else
				status = "Overdose THC - joueur inconscient";
			m_StatusText.SetText(status);
		}
	}
	
	void CloseMenuInternal()
	{
		GetGame().GetMenuManager().CloseMenu(this);
	}
}

class LP_CannabisControlClickHandler : ScriptedWidgetEventHandler
{
	LP_CannabisControlMenu m_Menu;
	
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.CloseMenuInternal();
		return true;
	}
}
