//------------------------------------------------------------------------------------------------
// JobZoneCaptureManager.c
// Singleton serveur gerant les captures de zone d extraction en cours.
//
// LOGIQUE :
//   - Un joueur (chef ou membre d un gang) lance une capture sur une zone
//   - Il doit rester 30 min dans un rayon de 30m autour de la zone
//   - Si le joueur MEURT -> capture annulee
//   - Si le joueur SORT du rayon -> capture annulee
//   - Si un membre d un AUTRE gang est present dans le rayon -> timer EN PAUSE (contestation)
//   - Au bout de 30 min cumulees -> le gang prend le controle de la zone
//
// Un seul joueur capture une zone a la fois (le 1er qui lance).
//------------------------------------------------------------------------------------------------

class JobZoneCaptureManager
{
	static ref JobZoneCaptureManager s_Instance;
	
	// Captures en cours : on track par entite de zone
	ref array<ref JobActiveCapture> m_ActiveCaptures;
	
	bool m_TickStarted = false;
	
	//------------------------------------------------------------------------------------------------
	void JobZoneCaptureManager()
	{
		m_ActiveCaptures = new array<ref JobActiveCapture>();
	}
	
	//------------------------------------------------------------------------------------------------
	static JobZoneCaptureManager GetInstance()
	{
		if (!s_Instance)
			s_Instance = new JobZoneCaptureManager();
		return s_Instance;
	}
	
	//------------------------------------------------------------------------------------------------
	// Demarre le tick global (1x par seconde) s il ne tourne pas deja
	//------------------------------------------------------------------------------------------------
	void EnsureTick()
	{
		if (m_TickStarted)
			return;
		m_TickStarted = true;
		GetGame().GetCallqueue().CallLater(Tick, 1000, true);
	}
	
	//------------------------------------------------------------------------------------------------
	// Lance une capture. Retourne 0 = OK, code erreur sinon :
	//   1 = pas dans un gang
	//   2 = zone deja en cours de capture
	//   3 = zone deja controlee par ton gang
	//------------------------------------------------------------------------------------------------
	int StartCapture(IEntity zoneEntity, int playerId, string playerUID)
	{
		// Verifie que le joueur est dans un gang
		JobGang gang = JobGangManager.GetInstance().GetGangOfPlayer(playerUID);
		if (!gang)
			return 1;
		
		JobDrugZoneComponent zoneComp = JobDrugZoneComponent.Cast(
			zoneEntity.FindComponent(JobDrugZoneComponent));
		if (!zoneComp)
			return 1;
		
		// Deja controlee par ton propre gang ?
		string currentController = JobGangManager.GetInstance().GetZoneController(zoneComp.GetDrugType());
		if (currentController == gang.m_Name)
			return 3;
		
		// Zone deja en cours de capture ?
		foreach (JobActiveCapture cap : m_ActiveCaptures)
		{
			if (cap && cap.m_ZoneEntity == zoneEntity)
				return 2;
		}
		
		// Cree la capture
		JobActiveCapture capture = new JobActiveCapture();
		capture.m_ZoneEntity = zoneEntity;
		capture.m_PlayerId = playerId;
		capture.m_PlayerUID = playerUID;
		capture.m_GangName = gang.m_Name;
		capture.m_SecondsElapsed = 0;
		capture.m_DrugType = zoneComp.GetDrugType();
		capture.m_Radius = zoneComp.GetCaptureRadius();
		m_ActiveCaptures.Insert(capture);
		
		zoneComp.m_CaptureInProgress = true;
		zoneComp.m_CapturingGangName = gang.m_Name;
		zoneComp.m_CapturingPlayerId = playerId;
		
		EnsureTick();
		
		JobManager.GetInstance().NotifyPlayerChat(playerId,
			string.Format("[GANG] Capture de la zone %1 lancee ! Restez 30 min dans la zone (30m). La mort ou une sortie annule.",
				zoneComp.GetDrugLabel()));
		
		// === ALERTE le gang proprietaire actuel (Gang B) que sa zone est attaquee ===
		// currentController = nom du gang qui controle la zone avant cette capture (peut etre vide)
		if (currentController != "")
		{
			NotifyGangMembers(currentController,
				string.Format("[GANG] ALERTE ! Le gang %1 tente de prendre votre zone %2 ! Defendez-la (restez sur place pour contester).",
					gang.m_Name, zoneComp.GetDrugLabel()));
		}
		
		return 0;
	}
	
	//------------------------------------------------------------------------------------------------
	// Envoie un hint a TOUS les membres connectes d un gang (par son nom)
	//------------------------------------------------------------------------------------------------
	void NotifyGangMembers(string gangName, string message)
	{
		if (gangName == "")
			return;
		JobGang gang = JobGangManager.GetInstance().GetGangByName(gangName);
		if (!gang)
			return;
		
		PlayerManager pm = GetGame().GetPlayerManager();
		if (!pm)
			return;
		array<int> playerIds = new array<int>();
		pm.GetPlayers(playerIds);
		
		// Pour chaque joueur connecte, on verifie s il fait partie du gang (chef ou membre)
		foreach (int pid : playerIds)
		{
			string uid = JobManager.GetInstance().GetPersistentUID(pid);
			if (uid == "")
				continue;
			if (gang.Contains(uid))
				JobManager.GetInstance().NotifyPlayerChat(pid, message);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Tick global : avance toutes les captures en cours
	//------------------------------------------------------------------------------------------------
	void Tick()
	{
		if (!Replication.IsServer())
			return;
		
		for (int i = m_ActiveCaptures.Count() - 1; i >= 0; i--)
		{
			JobActiveCapture cap = m_ActiveCaptures.Get(i);
			if (!cap)
			{
				m_ActiveCaptures.Remove(i);
				continue;
			}
			ProcessCapture(cap, i);
		}
		
		// Stoppe le tick s il n y a plus de captures (economie CPU)
		if (m_ActiveCaptures.IsEmpty())
		{
			GetGame().GetCallqueue().Remove(Tick);
			m_TickStarted = false;
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Traite une capture individuelle (appele chaque seconde)
	//------------------------------------------------------------------------------------------------
	void ProcessCapture(JobActiveCapture cap, int index)
	{
		// Zone toujours valide ?
		if (!cap.m_ZoneEntity)
		{
			m_ActiveCaptures.Remove(index);
			return;
		}
		
		// Recupere le joueur captureur
		PlayerManager pm = GetGame().GetPlayerManager();
		if (!pm)
			return;
		IEntity playerEntity = pm.GetPlayerControlledEntity(cap.m_PlayerId);
		
		// Joueur deconnecte ou mort (entite nulle) -> annule
		if (!playerEntity)
		{
			CancelCapture(cap, index, "Le captureur s'est deconnecte ou est mort. Capture annulee.");
			return;
		}
		
		// Verifie la vie du joueur (mort = annulation)
		DamageManagerComponent dmg = DamageManagerComponent.Cast(
			playerEntity.FindComponent(DamageManagerComponent));
		if (dmg && dmg.GetState() == EDamageState.DESTROYED)
		{
			CancelCapture(cap, index, "Le captureur est mort. Capture annulee.");
			return;
		}
		
		vector zonePos = cap.m_ZoneEntity.GetOrigin();
		vector playerPos = playerEntity.GetOrigin();
		float distToZone = vector.Distance(zonePos, playerPos);
		
		// Joueur sorti du rayon -> annule
		if (distToZone > cap.m_Radius)
		{
			CancelCapture(cap, index, "Vous etes sorti de la zone. Capture annulee.");
			return;
		}
		
		// Verifie la contestation : un membre d un AUTRE gang dans le rayon ?
		bool contested = IsZoneContested(cap, zonePos);
		if (contested)
		{
			// Timer en pause. On notifie le captureur regulierement (toutes les 5s)
			// via un compteur dedie m_ContestSeconds (le timer principal m_SecondsElapsed
			// etant fige, on ne peut pas se baser dessus pour cadencer la notif).
			cap.m_ContestSeconds = cap.m_ContestSeconds + 1;
			if (cap.m_ContestSeconds == 1 || cap.m_ContestSeconds % 5 == 0)
			{
				JobManager.GetInstance().NotifyPlayerChat(cap.m_PlayerId,
					"[GANG] Zone CONTESTEE ! Un gang rival est present. Le minuteur est EN PAUSE.");
			}
			// Met a jour la barre a l ecran en mode "contestee" (en pause)
			SendProgressToPlayer(cap, true);
			return;  // Ne pas incrementer le timer principal
		}
		
		// Plus de contestation : reset le compteur de contestation
		cap.m_ContestSeconds = 0;
		
		// Avance le timer
		cap.m_SecondsElapsed = cap.m_SecondsElapsed + 1;
		
		// Met a jour la barre de progression a l ecran (mode normal)
		SendProgressToPlayer(cap, false);
		
		// Notification de progression toutes les 5 min (300s)
		if (cap.m_SecondsElapsed % 300 == 0)
		{
			int remainingMin = (cap.GetCaptureDuration() - cap.m_SecondsElapsed) / 60;
			JobManager.GetInstance().NotifyPlayerChat(cap.m_PlayerId,
				string.Format("[GANG] Capture en cours... %1 min restantes.", remainingMin));
		}
		
		// Capture terminee ?
		if (cap.m_SecondsElapsed >= cap.GetCaptureDuration())
		{
			CompleteCapture(cap, index);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Envoie la progression de capture au joueur captureur (pour la barre a l ecran)
	// percent 0-100, remainingSeconds, contested = barre en pause (orange)
	//------------------------------------------------------------------------------------------------
	void SendProgressToPlayer(JobActiveCapture cap, bool contested)
	{
		PlayerManager pm = GetGame().GetPlayerManager();
		if (!pm)
			return;
		PlayerController pc = pm.GetPlayerController(cap.m_PlayerId);
		if (!pc)
			return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc)
			return;
		
		int duration = cap.GetCaptureDuration();
		int percent = (cap.m_SecondsElapsed * 100) / duration;
		int remainingSeconds = duration - cap.m_SecondsElapsed;
		jpc.ServerSendCaptureProgress(percent, remainingSeconds, contested);
	}
	
	//------------------------------------------------------------------------------------------------
	// Verifie si un membre d un autre gang est present dans le rayon de la zone
	//------------------------------------------------------------------------------------------------
	bool IsZoneContested(JobActiveCapture cap, vector zonePos)
	{
		PlayerManager pm = GetGame().GetPlayerManager();
		if (!pm)
			return false;
		
		array<int> playerIds = new array<int>();
		pm.GetPlayers(playerIds);
		
		foreach (int pid : playerIds)
		{
			if (pid == cap.m_PlayerId)
				continue;  // ignore le captureur
			
			IEntity ent = pm.GetPlayerControlledEntity(pid);
			if (!ent)
				continue;
			
			float dist = vector.Distance(zonePos, ent.GetOrigin());
			if (dist > cap.m_Radius)
				continue;  // hors zone
			
			// Ce joueur est dans la zone. Est-il d un autre gang ?
			string otherUID = JobManager.GetInstance().GetPersistentUID(pid);
			if (otherUID == "")
				continue;
			JobGang otherGang = JobGangManager.GetInstance().GetGangOfPlayer(otherUID);
			
			// Contestation si : pas de gang OU gang different du captureur
			if (!otherGang || otherGang.m_Name != cap.m_GangName)
				return true;
		}
		return false;
	}
	
	//------------------------------------------------------------------------------------------------
	// Annule une capture en cours
	//------------------------------------------------------------------------------------------------
	void CancelCapture(JobActiveCapture cap, int index, string reason)
	{
		JobManager.GetInstance().NotifyPlayerChat(cap.m_PlayerId, "[GANG] " + reason);
		
		// Masque la barre de progression a l ecran du captureur
		HideProgressForPlayer(cap.m_PlayerId);
		
		// Reset l etat du component zone
		if (cap.m_ZoneEntity)
		{
			JobDrugZoneComponent zoneComp = JobDrugZoneComponent.Cast(
				cap.m_ZoneEntity.FindComponent(JobDrugZoneComponent));
			if (zoneComp)
			{
				zoneComp.m_CaptureInProgress = false;
				zoneComp.m_CapturingGangName = "";
				zoneComp.m_CapturingPlayerId = -1;
			}
		}
		
		m_ActiveCaptures.Remove(index);
	}
	
	//------------------------------------------------------------------------------------------------
	// Masque la barre de progression a l ecran d un joueur (fin/annulation de capture)
	//------------------------------------------------------------------------------------------------
	void HideProgressForPlayer(int playerId)
	{
		PlayerManager pm = GetGame().GetPlayerManager();
		if (!pm)
			return;
		PlayerController pc = pm.GetPlayerController(playerId);
		if (!pc)
			return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (jpc)
			jpc.ServerHideCaptureProgress();
	}
	
	//------------------------------------------------------------------------------------------------
	// Termine une capture avec succes : le gang prend le controle de la zone
	//------------------------------------------------------------------------------------------------
	void CompleteCapture(JobActiveCapture cap, int index)
	{
		// Recupere la position de la zone pour le marqueur persistant
		float zonePosX = 0;
		float zonePosZ = 0;
		if (cap.m_ZoneEntity)
		{
			vector zp = cap.m_ZoneEntity.GetOrigin();
			zonePosX = zp[0];
			zonePosZ = zp[2];
		}
		
		// Recupere l ancien proprietaire AVANT l ecrasement (pour l alerter de la perte)
		string previousController = JobGangManager.GetInstance().GetZoneController(cap.m_DrugType);
		
		// Le gang prend le controle (ecrase l ancien controleur s il y en avait un)
		JobGangManager.GetInstance().SetZoneControl(cap.m_DrugType, cap.m_GangName, zonePosX, zonePosZ);
		
		// Reset l etat du component zone
		if (cap.m_ZoneEntity)
		{
			JobDrugZoneComponent zoneComp = JobDrugZoneComponent.Cast(
				cap.m_ZoneEntity.FindComponent(JobDrugZoneComponent));
			if (zoneComp)
			{
				zoneComp.m_CaptureInProgress = false;
				zoneComp.m_CapturingGangName = "";
				zoneComp.m_CapturingPlayerId = -1;
			}
		}
		
		string drugLabel = "zone";
		if (cap.m_DrugType == EMarketItem.CANNABIS)
			drugLabel = "Cannabis";
		else if (cap.m_DrugType == EMarketItem.COCAINE)
			drugLabel = "Cocaine";
		
		// Notifie le captureur + tout le gang
		JobManager.GetInstance().NotifyPlayerChat(cap.m_PlayerId,
			string.Format("[GANG] Zone %1 capturee ! Votre gang %2 touche desormais 5%% sur les ventes.",
				drugLabel, cap.m_GangName));
		
		// === ALERTE l ancien gang proprietaire (Gang B) qu il a perdu sa zone ===
		// On verifie que c est bien un AUTRE gang (pas le meme, pas vide)
		if (previousController != "" && previousController != cap.m_GangName)
		{
			NotifyGangMembers(previousController,
				string.Format("[GANG] Vous avez perdu le controle de la zone %1 au profit du gang %2. Vous ne touchez plus les taxes.",
					drugLabel, cap.m_GangName));
		}
		
		// Cree/met a jour le marqueur de carte pour tous (via RPC sur tous les clients)
		BroadcastZoneMarker(cap.m_ZoneEntity, cap.m_GangName, drugLabel);
		
		// Masque la barre de progression a l ecran du captureur (capture terminee)
		HideProgressForPlayer(cap.m_PlayerId);
		
		m_ActiveCaptures.Remove(index);
		
		Print(string.Format("[JobZoneCaptureManager] Zone %1 capturee par gang %2",
			drugLabel, cap.m_GangName), LogLevel.NORMAL);
	}
	
	//------------------------------------------------------------------------------------------------
	// Diffuse un marqueur de carte "Zone Controlee (GangName)" a tous les joueurs.
	// On passe par le JobPlayerComponent de chaque joueur connecte (RPC Owner).
	//------------------------------------------------------------------------------------------------
	void BroadcastZoneMarker(IEntity zoneEntity, string gangName, string drugLabel)
	{
		if (!zoneEntity)
			return;
		vector pos = zoneEntity.GetOrigin();
		
		PlayerManager pm = GetGame().GetPlayerManager();
		if (!pm)
			return;
		array<int> playerIds = new array<int>();
		pm.GetPlayers(playerIds);
		
		foreach (int pid : playerIds)
		{
			// Filtre : seuls les voyous OU membres d un gang voient le marqueur
			if (!CanSeeZoneMarker(pid))
				continue;
			PlayerController pc = pm.GetPlayerController(pid);
			if (!pc)
				continue;
			JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
			if (!jpc)
				continue;
			jpc.ServerSendZoneMarker(pos[0], pos[2], gangName, drugLabel);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Determine si un joueur a le droit de voir les marqueurs de zone controlee :
	// uniquement les VOYOUS ou les membres d un gang (chef ou membre).
	//------------------------------------------------------------------------------------------------
	static bool CanSeeZoneMarker(int playerId)
	{
		// Voyou ?
		JobPlayerData data = JobManager.GetInstance().GetPlayerData(playerId);
		if (data && data.m_Job == EJobType.VOYOU)
			return true;
		
		// Membre d un gang ?
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid != "")
		{
			JobGang gang = JobGangManager.GetInstance().GetGangOfPlayer(uid);
			if (gang)
				return true;
		}
		return false;
	}
}

//------------------------------------------------------------------------------------------------
// Structure d une capture active
//------------------------------------------------------------------------------------------------
class JobActiveCapture
{
	IEntity m_ZoneEntity;
	int m_PlayerId;
	string m_PlayerUID;
	string m_GangName;
	int m_SecondsElapsed;
	int m_ContestSeconds;  // secondes de contestation consecutives (pour cadencer la notif de pause)
	int m_DrugType;
	float m_Radius;
	
	int GetCaptureDuration()
	{
		return 1800;  // 30 minutes
	}
}
