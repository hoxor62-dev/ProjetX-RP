//------------------------------------------------------------------------------------------------
// JobTresorManager.c
// Manager singleton SERVEUR du systeme de fouille de coffre au tresor sous-marin.
//
// Flux :
//  1. Joueur clique 'Ouvrir le coffre' devant le coffre
//  2. Serveur verifie : pas en cooldown + a les 2 items requis (palmes + scuba)
//  3. Demarre une session de 5 minutes
//  4. Toutes les 30s : 1 chance sur 2 de gagner UN item, tirage pondere parmi la loot table.
//     -> max 10 items sur 5 min, moyenne 5 items, 99.9% chance d en avoir au moins 1.
//     - Si l item tombe, on le spawn dans l inventaire + hint si rare
//  5. Annulation si :
//     - Joueur s eloigne > 15m du coffre
//     - Joueur meurt / inconscient / deconnecte
//     -> dans tous les cas : cooldown 1 min applique (comme un achevement complet)
//  6. Fin de 5 min normales : cooldown 1 min applique
//------------------------------------------------------------------------------------------------

class JobTresorActiveSession
{
	int m_PlayerId;
	string m_PlayerUID;
	int m_CoffreEntityId;       // pour identification
	vector m_CoffreOrigin;
	int m_StartTime;            // timestamp unix de demarrage
	int m_NextLootTickTime;     // timestamp du prochain tirage de loot
	int m_TotalItemsObtained;   // compteur HUD
	int m_RareItemsObtained;    // compteur HUD
}

class JobTresorManager
{
	static ref JobTresorManager s_Instance;
	
	// Sessions actives : cle = playerId (chaque joueur a sa propre session, possible multi
	// sur le meme coffre)
	ref map<int, ref JobTresorActiveSession> m_ActiveSessions;
	
	// Cooldown : UID joueur -> timestamp unix de fin de cooldown
	ref map<string, int> m_Cooldowns;
	
	const int TICK_INTERVAL_MS = 1000;
	
	//------------------------------------------------------------------------------------------------
	void JobTresorManager()
	{
		m_ActiveSessions = new map<int, ref JobTresorActiveSession>();
		m_Cooldowns = new map<string, int>();
	}
	
	//------------------------------------------------------------------------------------------------
	static JobTresorManager GetInstance()
	{
		if (!s_Instance)
		{
			s_Instance = new JobTresorManager();
			s_Instance.Init();
		}
		return s_Instance;
	}
	
	//------------------------------------------------------------------------------------------------
	void Init()
	{
		Print("[JobTresorManager] Initialisation", LogLevel.NORMAL);
		if (Replication.IsServer())
			GetGame().GetCallqueue().CallLater(Tick, TICK_INTERVAL_MS, true);
	}
	
	//------------------------------------------------------------------------------------------------
	bool HasActiveTresor(int playerId)
	{
		return m_ActiveSessions.Contains(playerId);
	}
	
	//------------------------------------------------------------------------------------------------
	// Verifie le cooldown. Retourne 0 si OK, sinon nombre de secondes restantes
	//------------------------------------------------------------------------------------------------
	int CheckCooldown(string playerUID)
	{
		if (playerUID == "") return 1;
		int endTime;
		if (!m_Cooldowns.Find(playerUID, endTime))
			return 0;
		int now = System.GetUnixTime();
		if (now >= endTime)
			return 0;
		return endTime - now;
	}
	
	//------------------------------------------------------------------------------------------------
	// Verifie que le joueur a les 2 items requis dans son inventaire (palmes + scuba)
	//------------------------------------------------------------------------------------------------
	bool HasRequiredGear(int playerId)
	{
		PlayerController pc = GetGame().GetPlayerManager().GetPlayerController(playerId);
		if (!pc) return false;
		IEntity playerEntity = pc.GetControlledEntity();
		if (!playerEntity) return false;
		
		SCR_InventoryStorageManagerComponent invMgr = SCR_InventoryStorageManagerComponent.Cast(
			playerEntity.FindComponent(SCR_InventoryStorageManagerComponent));
		if (!invMgr) return false;
		
		array<IEntity> items = new array<IEntity>();
		invMgr.GetItems(items);
		
		bool hasFins = false;
		bool hasScuba = false;
		foreach (IEntity item : items)
		{
			if (!item) continue;
			EntityPrefabData pd = item.GetPrefabData();
			if (!pd) continue;
			string rn = pd.GetPrefabName();
			if (rn == JobTresorData.REQUIRED_ITEM_FINS)
				hasFins = true;
			if (rn == JobTresorData.REQUIRED_ITEM_SCUBA)
				hasScuba = true;
			if (hasFins && hasScuba)
				return true;
		}
		return (hasFins && hasScuba);
	}
	
	//------------------------------------------------------------------------------------------------
	// Tente de demarrer une recherche. Retourne :
	//   0 = OK demarre
	//   1 = deja une recherche en cours
	//   2 = cooldown actif (X secondes restantes)
	//   3 = pas de materiel de plongee (palmes + scuba)
	//   4 = erreur generique
	//------------------------------------------------------------------------------------------------
	int StartTresor(int playerId, IEntity coffreEntity, out int outCooldownRemaining)
	{
		outCooldownRemaining = 0;
		if (!Replication.IsServer()) return 4;
		
		// Verif deja en cours
		if (HasActiveTresor(playerId)) return 1;
		
		// Verif cooldown
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "") return 4;
		int cdRemaining = CheckCooldown(uid);
		if (cdRemaining > 0)
		{
			outCooldownRemaining = cdRemaining;
			return 2;
		}
		
		// Verif materiel de plongee
		if (!HasRequiredGear(playerId))
			return 3;
		
		// Cree la session
		int now = System.GetUnixTime();
		JobTresorActiveSession session = new JobTresorActiveSession();
		session.m_PlayerId = playerId;
		session.m_PlayerUID = uid;
		session.m_CoffreEntityId = coffreEntity.GetID();
		session.m_CoffreOrigin = coffreEntity.GetOrigin();
		session.m_StartTime = now;
		session.m_NextLootTickTime = now + JobTresorData.LOOT_TICK_INTERVAL_SECONDS;
		session.m_TotalItemsObtained = 0;
		session.m_RareItemsObtained = 0;
		m_ActiveSessions.Set(playerId, session);
		
		// Envoie au client : HUD progression
		PlayerController pc = GetGame().GetPlayerManager().GetPlayerController(playerId);
		if (pc)
		{
			JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
			if (jpc)
				jpc.ServerStartTresorHud(JobTresorData.RECHERCHE_DURATION_SECONDS,
					session.m_CoffreOrigin);
		}
		
		Print(string.Format("[JobTresorManager] Recherche demarree : player=%1", playerId),
			LogLevel.NORMAL);
		return 0;
	}
	
	//------------------------------------------------------------------------------------------------
	// Tick serveur : pour chaque session, check vie/distance + roll loot toutes les 30s
	//------------------------------------------------------------------------------------------------
	void Tick()
	{
		if (!Replication.IsServer()) return;
		if (m_ActiveSessions.Count() == 0) return;
		
		int now = System.GetUnixTime();
		array<int> toEnd = new array<int>();
		array<int> toEndCompleted = new array<int>();  // ceux qui finissent normalement (cooldown applique)
		
		foreach (int playerId, JobTresorActiveSession session : m_ActiveSessions)
		{
			if (!session)
			{
				toEnd.Insert(playerId);
				continue;
			}
			
			// Fin de duree (5 min) ?
			int elapsed = now - session.m_StartTime;
			if (elapsed >= JobTresorData.RECHERCHE_DURATION_SECONDS)
			{
				toEndCompleted.Insert(playerId);  // achevement complet -> cooldown
				continue;
			}
			
			// Verif joueur connecte
			PlayerController pc = GetGame().GetPlayerManager().GetPlayerController(playerId);
			if (!pc)
			{
				toEnd.Insert(playerId);
				continue;
			}
			IEntity playerEntity = pc.GetControlledEntity();
			if (!playerEntity)
			{
				toEnd.Insert(playerId);
				continue;
			}
			
			// Verif vie / inconscience
			ChimeraCharacter ch = ChimeraCharacter.Cast(playerEntity);
			if (ch)
			{
				CharacterControllerComponent ccc = ch.GetCharacterController();
				if (ccc)
				{
					ECharacterLifeState ls = ccc.GetLifeState();
					if (ls == ECharacterLifeState.DEAD || ls == ECharacterLifeState.INCAPACITATED)
					{
						JobManager.GetInstance().NotifyPlayerChat(playerId,
							"[TRESOR] Vous etes hors-jeu : la recherche est interrompue.");
						toEnd.Insert(playerId);
						continue;
					}
				}
			}
			
			// Verif distance au coffre
			float dist = vector.Distance(playerEntity.GetOrigin(), session.m_CoffreOrigin);
			if (dist > JobTresorData.MAX_DISTANCE_FROM_COFFRE)
			{
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					string.Format("[TRESOR] Vous etes trop loin du coffre (%1m) : recherche annulee.",
						Math.Floor(dist).ToString()));
				toEnd.Insert(playerId);
				continue;
			}
			
			// Tirage de loot (toutes les 30s)
			if (now >= session.m_NextLootTickTime)
			{
				RollLoot(session, pc);
				session.m_NextLootTickTime = now + JobTresorData.LOOT_TICK_INTERVAL_SECONDS;
			}
		}
		
		// Annulations AVEC cooldown (eloignement, mort, inconscience, deconnexion)
		foreach (int pid : toEnd)
			EndTresor(pid, true);
		// Achevements normaux avec cooldown
		foreach (int pid : toEndCompleted)
		{
			JobManager.GetInstance().NotifyPlayerChat(pid,
				"[TRESOR] Recherche terminee ! Cooldown 3 heures avant de pouvoir reouvrir un coffre.");
			EndTresor(pid, true);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Tirage de loot a chaque tick :
	//   1. 1 chance sur 2 (50%) de gagner UN item ce tick
	//   2. Si gagne : choisit UN item selon les POIDS de la loot table
	//      (poids = m_ProbabilityPercent, somme totale = 285)
	// Cela garantit max 10 items sur les 5 min (1 tick = 0 ou 1 item).
	//------------------------------------------------------------------------------------------------
	void RollLoot(JobTresorActiveSession session, PlayerController pc)
	{
		if (!session || !pc) return;
		IEntity playerEntity = pc.GetControlledEntity();
		if (!playerEntity) return;
		
		SCR_InventoryStorageManagerComponent invMgr = SCR_InventoryStorageManagerComponent.Cast(
			playerEntity.FindComponent(SCR_InventoryStorageManagerComponent));
		if (!invMgr) return;
		
		// Etape 1 : 1 chance sur 2 de rien gagner ce tick
		int coinFlip = Math.RandomInt(0, 100);
		if (coinFlip < 50)
		{
			// Rien ce tick : juste une notif optionnelle
			JobManager.GetInstance().NotifyPlayerChat(session.m_PlayerId,
				"[TRESOR] Rien trouve ce coup-ci...");
			return;
		}
		
		// Etape 2 : tirage pondere parmi la loot table
		array<ref JobTresorLootEntry> table = JobTresorData.GetLootTable();
		
		// Calcule la somme totale des poids
		int totalWeight = 0;
		foreach (JobTresorLootEntry e : table)
		{
			if (!e) continue;
			totalWeight += e.m_ProbabilityPercent;
		}
		if (totalWeight <= 0)
			return;
		
		// Tire un nombre aleatoire dans [0, totalWeight)
		int roll = Math.RandomInt(0, totalWeight);
		int cumul = 0;
		JobTresorLootEntry chosen = null;
		foreach (JobTresorLootEntry entry : table)
		{
			if (!entry) continue;
			cumul += entry.m_ProbabilityPercent;
			if (roll < cumul)
			{
				chosen = entry;
				break;
			}
		}
		
		if (!chosen)
			return;
		
		// Spawn dans l inventaire
		ResourceName rn = chosen.m_PrefabName;
		bool ok = invMgr.TrySpawnPrefabToStorage(rn);
		if (!ok)
		{
			Print(string.Format("[JobTresorManager] Impossible de spawn item dans inventaire (plein ?) : %1",
				chosen.m_PrefabName), LogLevel.WARNING);
			JobManager.GetInstance().NotifyPlayerChat(session.m_PlayerId,
				"[TRESOR] Inventaire plein : item perdu.");
			return;
		}
		session.m_TotalItemsObtained++;
		
		// Item rare ? hint dedie
		bool isRare = JobTresorData.IsRareItem(chosen.m_ProbabilityPercent);
		if (isRare)
		{
			session.m_RareItemsObtained++;
			JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
			if (jpc)
			{
				string msg = string.Format("Vous avez obtenu un item rare a %1%% !",
					chosen.m_ProbabilityPercent.ToString());
				jpc.ServerShowTresorRareHint(msg);
			}
		}
		
		// Notif chat
		string raretyTag = "";
		if (isRare)
			raretyTag = " (RARE)";
		JobManager.GetInstance().NotifyPlayerChat(session.m_PlayerId,
			string.Format("[TRESOR] +1 item trouve%1 ! (total : %2)",
				raretyTag, session.m_TotalItemsObtained.ToString()));
		
		// Sync stats HUD
		JobPlayerComponent jpcSync = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (jpcSync)
			jpcSync.ServerSyncTresorStats(session.m_TotalItemsObtained, session.m_RareItemsObtained);
	}
	
	//------------------------------------------------------------------------------------------------
	// Termine une session
	//------------------------------------------------------------------------------------------------
	void EndTresor(int playerId, bool applyCooldown)
	{
		JobTresorActiveSession session;
		if (!m_ActiveSessions.Find(playerId, session))
			return;
		
		// Cooldown uniquement si achevement complet
		if (applyCooldown && session.m_PlayerUID != "")
		{
			int now = System.GetUnixTime();
			m_Cooldowns.Set(session.m_PlayerUID, now + JobTresorData.COOLDOWN_SECONDS);
		}
		
		// Stoppe le HUD chez le client
		PlayerController pc = GetGame().GetPlayerManager().GetPlayerController(playerId);
		if (pc)
		{
			JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
			if (jpc)
				jpc.ServerEndTresorHud();
		}
		
		m_ActiveSessions.Remove(playerId);
		Print(string.Format("[JobTresorManager] Recherche terminee : player=%1 (cooldown=%2)",
			playerId, applyCooldown), LogLevel.NORMAL);
	}
	
	//------------------------------------------------------------------------------------------------
	void OnPlayerDisconnected(int playerId)
	{
		if (HasActiveTresor(playerId))
			EndTresor(playerId, true);  // cooldown applique meme en cas de deconnexion
	}
}