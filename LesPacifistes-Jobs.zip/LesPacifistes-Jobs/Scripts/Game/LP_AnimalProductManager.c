//------------------------------------------------------------------------------------------------
// LP_AnimalProductManager.c
// Singleton SERVEUR qui spawn periodiquement des produits sur la position d entites animales :
//   - Toutes les 3 heures : 1 oeuf spawne sur chaque Chicken vivant
//   - Toutes les 3 heures : 1 lait spawne sur chaque Cow vivante
//
// FONCTIONNEMENT :
//   - Timer unique 3h (SPAWN_INTERVAL_MS = 3*60*60*1000 = 10 800 000 ms)
//   - Demarre au 1er OnPlayerConnected du serveur (comme les autres systemes)
//   - A chaque tick : QueryEntitiesByAABB monde entier, filtre les Chicken + Cow vivants
//     (EDamageState != DESTROYED), spawn le produit correspondant sur GetOrigin
//   - Position spawn = position de l animal + petit offset Y (+0.3m) pour eviter clip sol
//
// PREFABS :
//   Chicken :  {69E4F17000000010}Prefabs/Wildlife/Chicken.et  -> spawn oeuf.et
//   Cow    :  {69E4F1C000000010}Prefabs/Wildlife/Cow.et      -> spawn lait.et
//------------------------------------------------------------------------------------------------

class LP_AnimalProductManager
{
	static ref LP_AnimalProductManager s_Instance;
	
	// Prefabs cibles (entites vivantes)
	static string CHICKEN_PREFAB = "{69E4F17000000011}Prefabs/Wildlife/Editable/E_Chicken.et";
	static string COW_PREFAB     = "{69E4F1C000000011}Prefabs/Wildlife/Editable/E_Cow.et";
	
	// Prefabs produits a spawner
	static string EGG_PREFAB  = "{40DD771C1264953C}Prefabs/Weapons/Grenades/oeuf.et";
	static string MILK_PREFAB = "{14B5AE4385CA2AC7}Prefabs/Weapons/Grenades/lait.et";
	
	// Intervalle : 3 heures en ms
	const int SPAWN_INTERVAL_MS = 3600000;
	
	// Offset Y pour eviter clip sol
	const float SPAWN_Y_OFFSET = 0.3;
	
	bool m_TickerStarted = false;
	
	// Collecteur temporaire pour QueryEntitiesByAABB (reutilise a chaque tick)
	ref array<IEntity> m_TmpChickens = new array<IEntity>();
	ref array<IEntity> m_TmpCows = new array<IEntity>();
	
	//------------------------------------------------------------------------------------------------
	static LP_AnimalProductManager GetInstance()
	{
		if (!s_Instance)
			s_Instance = new LP_AnimalProductManager();
		return s_Instance;
	}
	
	//------------------------------------------------------------------------------------------------
	// Demarre le timer 3h (a appeler une fois au boot serveur)
	void StartTicker()
	{
		if (m_TickerStarted) return;
		if (!Replication.IsServer()) return;
		m_TickerStarted = true;
		
		GetGame().GetCallqueue().CallLater(TickSpawnProducts, SPAWN_INTERVAL_MS, true);
		Print(string.Format("[LP_AnimalProduct] Timer demarre (spawn toutes les %1h).",
			(SPAWN_INTERVAL_MS / 3600000).ToString()), LogLevel.NORMAL);
	}
	
	//------------------------------------------------------------------------------------------------
	// Tick 3h : parcourt le monde, spawn les produits sur chaque Chicken/Cow vivant
	void TickSpawnProducts()
	{
		if (!Replication.IsServer()) return;
		
		BaseWorld world = GetGame().GetWorld();
		if (!world) return;
		
		m_TmpChickens.Clear();
		m_TmpCows.Clear();
		world.QueryEntitiesByAABB("-99999 -99999 -99999", "99999 99999 99999", OnEntityFilter);
		
		int eggSpawned = 0;
		int milkSpawned = 0;
		
		// Spawn 1 oeuf sur chaque Chicken vivant
		foreach (IEntity chicken : m_TmpChickens)
		{
			if (!IsAlive(chicken)) continue;
			if (SpawnProductAt(EGG_PREFAB, chicken.GetOrigin()))
				eggSpawned = eggSpawned + 1;
		}
		
		// Spawn 1 lait sur chaque Cow vivante
		foreach (IEntity cow : m_TmpCows)
		{
			if (!IsAlive(cow)) continue;
			if (SpawnProductAt(MILK_PREFAB, cow.GetOrigin()))
				milkSpawned = milkSpawned + 1;
		}
		
		Print(string.Format("[LP_AnimalProduct] Tick 3h : %1 oeuf(s) sur %2 chicken(s), %3 lait(s) sur %4 cow(s)",
			eggSpawned.ToString(), m_TmpChickens.Count().ToString(),
			milkSpawned.ToString(), m_TmpCows.Count().ToString()), LogLevel.NORMAL);
	}
	
	//------------------------------------------------------------------------------------------------
	// Filtre : collecte Chicken + Cow dans les 2 arrays dedies
	bool OnEntityFilter(IEntity entity)
	{
		if (!entity) return true;
		EntityPrefabData pd = entity.GetPrefabData();
		if (!pd) return true;
		string rn = pd.GetPrefabName();
		
		if (rn == CHICKEN_PREFAB)
			m_TmpChickens.Insert(entity);
		else if (rn == COW_PREFAB)
			m_TmpCows.Insert(entity);
		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	// Verifie que l animal n est pas mort/detruit (evite spawn produit sur cadavre)
	protected bool IsAlive(IEntity animal)
	{
		if (!animal) return false;
		DamageManagerComponent dmg = DamageManagerComponent.Cast(
			animal.FindComponent(DamageManagerComponent));
		if (!dmg) return true; // pas de damage manager = considere vivant par defaut
		return dmg.GetState() != EDamageState.DESTROYED;
	}
	
	//------------------------------------------------------------------------------------------------
	// Spawn un produit a la position donnee (+ petit offset Y)
	protected bool SpawnProductAt(string prefabName, vector pos)
	{
		Resource res = Resource.Load(prefabName);
		if (!res || !res.IsValid())
		{
			Print(string.Format("[LP_AnimalProduct] Resource.Load echec pour %1", prefabName),
				LogLevel.WARNING);
			return false;
		}
		
		EntitySpawnParams p = new EntitySpawnParams();
		p.TransformMode = ETransformMode.WORLD;
		Math3D.MatrixIdentity4(p.Transform);
		vector spawnPos = pos + Vector(0, SPAWN_Y_OFFSET, 0);
		p.Transform[3] = spawnPos;
		
		IEntity item = GetGame().SpawnEntityPrefab(res, GetGame().GetWorld(), p);
		return item != null;
	}
}
