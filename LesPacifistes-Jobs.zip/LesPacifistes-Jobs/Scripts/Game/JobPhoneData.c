//------------------------------------------------------------------------------------------------
// JobPhoneData.c
// Structures et helpers du systeme telephone / SOS
//------------------------------------------------------------------------------------------------

enum EPhoneCallType
{
	NONE = 0,
	POLICE = 1,       // alerte les POLICIER
	GENDARMERIE = 2,  // alerte les MILITAIRE
	URGENCES = 3,     // alerte les MEDECIN
	MECANICIEN = 4,   // alerte les CONCESSIONNAIRE
	UBER = 5,         // alerte les UBER (chauffeurs)
	FOURRIERE_ALERT = 6 // alerte les FOURRIERE (envoyee par police/militaire via mise en fourriere)
}

class JobPhoneData
{
	//------------------------------------------------------------------------------------------------
	// Metier cible pour chaque type d'appel
	//------------------------------------------------------------------------------------------------
	static EJobType GetTargetJob(EPhoneCallType type)
	{
		switch (type)
		{
			case EPhoneCallType.POLICE:           return EJobType.POLICIER;
			case EPhoneCallType.GENDARMERIE:      return EJobType.MILITAIRE;
			case EPhoneCallType.URGENCES:         return EJobType.MEDECIN;
			case EPhoneCallType.MECANICIEN:       return EJobType.MECANICIEN;
			case EPhoneCallType.UBER:             return EJobType.UBER;
			case EPhoneCallType.FOURRIERE_ALERT:  return EJobType.FOURRIERE;
		}
		return EJobType.NONE;
	}

	//------------------------------------------------------------------------------------------------
	// Libelle affiche dans le menu telephone
	//------------------------------------------------------------------------------------------------
	static string GetCallLabel(EPhoneCallType type)
	{
		switch (type)
		{
			case EPhoneCallType.POLICE:       return "Appeler la police";
			case EPhoneCallType.GENDARMERIE:  return "Appeler la gendarmerie";
			case EPhoneCallType.URGENCES:     return "Appeler les urgences";
			case EPhoneCallType.MECANICIEN:   return "Appeler un mecanicien";
			case EPhoneCallType.UBER:         return "Appeler Uber";
			// FOURRIERE_ALERT n a pas de label menu : alerte declenchee server-side
			// par la mise en fourriere police/militaire, pas par un joueur via telephone.
		}
		return "Appel inconnu";
	}

	//------------------------------------------------------------------------------------------------
	// Tag affiche aux agents recevant l'alerte
	//------------------------------------------------------------------------------------------------
	static string GetAlertTag(EPhoneCallType type)
	{
		switch (type)
		{
			case EPhoneCallType.POLICE:           return "SOS POLICE";
			case EPhoneCallType.GENDARMERIE:      return "SOS GENDARMERIE";
			case EPhoneCallType.URGENCES:         return "SOS URGENCES";
			case EPhoneCallType.MECANICIEN:       return "SOS MECANICIEN";
			case EPhoneCallType.UBER:             return "CLIENT UBER";
			case EPhoneCallType.FOURRIERE_ALERT:  return "FOURRIERE";
		}
		return "SOS";
	}

	//------------------------------------------------------------------------------------------------
	// Titre du hint affiche a l'agent
	//------------------------------------------------------------------------------------------------
	static string GetAlertTitle(EPhoneCallType type)
	{
		switch (type)
		{
			case EPhoneCallType.POLICE:           return "Appel Police";
			case EPhoneCallType.GENDARMERIE:      return "Appel Gendarmerie";
			case EPhoneCallType.URGENCES:         return "Appel Urgences";
			case EPhoneCallType.MECANICIEN:       return "Appel Mecanicien";
			case EPhoneCallType.UBER:             return "Appel Uber";
			case EPhoneCallType.FOURRIERE_ALERT:  return "Mise en fourriere demandee";
		}
		return "Appel";
	}
}
