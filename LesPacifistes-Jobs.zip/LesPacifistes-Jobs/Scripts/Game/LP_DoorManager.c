//------------------------------------------------------------------------------------------------
// LP_DoorManager.c
// Singleton SERVEUR qui gere toutes les portes achetees.
//
// STOCKAGE :
//   - m_DoorsByKey : map cle stable (prefab + xyz) -> LP_DoorData (SOURCE DE VERITE persistante)
//   - m_DoorsByRplIdStr : cache runtime, cle = rplId.ToString() -> LP_DoorData
//
// PERSISTANCE :
//   - Fichier plat unique : $profile:LesPacifistesJobs/doors.json
//   - Cle = prefabName + posX + posY + posZ (arrondis) - STABLE entre reboots
//   - Le RplId change a chaque reboot, on ne le sauvegarde jamais
//------------------------------------------------------------------------------------------------

class LP_DoorManager
{
	static ref LP_DoorManager s_Instance;
	
	const int DOOR_BASE_COST = 15000;
	
	// SOURCE DE VERITE : cle stable prefab+xyz -> LP_DoorData
	ref map<string, ref LP_DoorData> m_DoorsByKey = new map<string, ref LP_DoorData>();
	
	// INDEX RUNTIME : rplId.ToString() -> LP_DoorData (cache, reconstruit a la volee)
	ref map<string, ref LP_DoorData> m_DoorsByRplIdStr = new map<string, ref LP_DoorData>();
	
	// CACHE ENTITE : cle stable prefab+xyz -> IEntity (runtime, remplit au boot + a chaque achat)
	// Sert a eviter les scans complets du monde a chaque connexion/deconnexion joueur.
	// Non-persiste : reconstruit au boot serveur via LP_LockAllOwnedDoorsOnBoot.
	ref map<string, IEntity> m_DoorEntitiesByKey = new map<string, IEntity>();
	
	const string SAVE_FILE = "$profile:LesPacifistesJobs/doors.json";
	bool m_Loaded = false;
	
	//------------------------------------------------------------------------------------------------
	static LP_DoorManager GetInstance()
	{
		if (!s_Instance)
		{
			s_Instance = new LP_DoorManager();
			s_Instance.LoadFromDisk();
		}
		return s_Instance;
	}
	
	//------------------------------------------------------------------------------------------------
	// Lookup principal : via RplId d une entite porte.
	// 1. Si l index runtime connait ce RplId, retourne direct
	// 2. Sinon, resout via l entite (prefab + position), met a jour l index, retourne
	//------------------------------------------------------------------------------------------------
	LP_DoorData GetDoorByRplId(RplId rplId)
	{
		string rplKey = rplId.ToString();
		
		// Cache hit
		LP_DoorData cached = m_DoorsByRplIdStr.Get(rplKey);
		if (cached) return cached;
		
		// Cache miss : resout via entite (prefab + position)
		RplComponent rpl = RplComponent.Cast(Replication.FindItem(rplId));
		if (!rpl) return null;
		IEntity doorEntity = rpl.GetEntity();
		if (!doorEntity) return null;
		
		return ResolveDoorFromEntity(doorEntity, rplKey);
	}
	
	//------------------------------------------------------------------------------------------------
	// Version depuis string (utilisee quand on a stocke le rplId comme string).
	// Cache uniquement - retourne null si pas dans le cache.
	// Si la porte a ete achetee dans la meme session, le cache la connait forcement
	// (car GetDoorByRplId(RplId) a ete appele au moins une fois).
	//------------------------------------------------------------------------------------------------
	LP_DoorData GetDoorByRplIdStr(string rplKey)
	{
		if (rplKey == "") return null;
		return m_DoorsByRplIdStr.Get(rplKey);
	}
	
	//------------------------------------------------------------------------------------------------
	// Resout la LP_DoorData depuis une entite + met a jour l index runtime
	//------------------------------------------------------------------------------------------------
	LP_DoorData ResolveDoorFromEntity(IEntity doorEntity, string rplKey)
	{
		if (!doorEntity) return null;
		string prefabName = doorEntity.GetPrefabData().GetPrefabName();
		vector pos = doorEntity.GetOrigin();
		string key = LP_DoorData.BuildDoorKey(prefabName, pos);
		
		LP_DoorData d = m_DoorsByKey.Get(key);
		if (!d) return null;
		
		// Met a jour l index runtime
		m_DoorsByRplIdStr.Set(rplKey, d);
		return d;
	}
	
	//------------------------------------------------------------------------------------------------
	bool IsPurchasedByEntity(IEntity doorEntity)
	{
		if (!doorEntity) return false;
		string prefabName = doorEntity.GetPrefabData().GetPrefabName();
		vector pos = doorEntity.GetOrigin();
		string key = LP_DoorData.BuildDoorKey(prefabName, pos);
		return m_DoorsByKey.Contains(key);
	}
	
	//------------------------------------------------------------------------------------------------
	// Achat initial - prend l entite pour extraire prefab + position (cle stable)
	//------------------------------------------------------------------------------------------------
	LP_DoorData PurchaseDoor(IEntity doorEntity, RplId rplId, string ownerUID, string ownerDisplayName, int price)
	{
		if (!doorEntity || ownerUID == "") return null;
		
		string prefabName = doorEntity.GetPrefabData().GetPrefabName();
		vector pos = doorEntity.GetOrigin();
		string key = LP_DoorData.BuildDoorKey(prefabName, pos);
		
		if (m_DoorsByKey.Contains(key)) return null; // deja achetee
		
		LP_DoorData d = new LP_DoorData();
		d.m_DoorKey = key;
		d.m_PrefabName = prefabName;
		d.m_Position = pos;
		d.m_OwnerUID = ownerUID;
		d.m_OwnerDisplayName = ownerDisplayName;
		d.m_ShareCode = "";
		d.m_PurchaseUnix = System.GetUnixTime();
		d.m_PurchasePrice = price;
		
		m_DoorsByKey.Set(key, d);
		m_DoorsByRplIdStr.Set(rplId.ToString(), d);
		m_DoorEntitiesByKey.Set(key, doorEntity);  // cache entite pour eviter scan monde
		SaveToDisk();
		
		Print(string.Format("[LP_DoorManager] Porte achetee: %1 par %2 (prix=%3)",
			key, ownerDisplayName, price.ToString()), LogLevel.NORMAL);
		return d;
	}
	
	//------------------------------------------------------------------------------------------------
	bool TransferDoor(LP_DoorData door, string newOwnerUID, string newOwnerDisplayName)
	{
		if (!door || newOwnerUID == "") return false;
		door.m_OwnerUID = newOwnerUID;
		door.m_OwnerDisplayName = newOwnerDisplayName;
		door.m_ShareCode = "";
		door.ClearKnownPlayers();
		SaveToDisk();
		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	void SetDoorCode(LP_DoorData door, string newCode)
	{
		if (!door) return;
		door.m_ShareCode = newCode;
		door.ClearKnownPlayers();
		SaveToDisk();
	}
	
	//------------------------------------------------------------------------------------------------
	bool TryEnterCode(LP_DoorData door, string uid, string code)
	{
		if (!door || uid == "" || code == "") return false;
		if (door.m_ShareCode == "" || door.m_ShareCode != code) return false;
		door.AddKnownPlayer(uid);
		SaveToDisk();
		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	// PERSISTANCE - Ne sauvegarde PAS le RplId (change a chaque reboot).
	// Cle = prefab + position -> stable.
	//------------------------------------------------------------------------------------------------
	void SaveToDisk()
	{
		SCR_JsonSaveContext ctx = new SCR_JsonSaveContext();
		ctx.WriteValue("count", m_DoorsByKey.Count());
		
		int i = 0;
		foreach (string key, LP_DoorData d : m_DoorsByKey)
		{
			if (!d) continue;
			string prefix = "doors/" + i.ToString() + "/";
			ctx.WriteValue(prefix + "key", d.m_DoorKey);
			ctx.WriteValue(prefix + "prefab", d.m_PrefabName);
			ctx.WriteValue(prefix + "posX", d.m_Position[0]);
			ctx.WriteValue(prefix + "posY", d.m_Position[1]);
			ctx.WriteValue(prefix + "posZ", d.m_Position[2]);
			ctx.WriteValue(prefix + "ownerUID", d.m_OwnerUID);
			ctx.WriteValue(prefix + "ownerName", d.m_OwnerDisplayName);
			ctx.WriteValue(prefix + "shareCode", d.m_ShareCode);
			ctx.WriteValue(prefix + "purchaseUnix", d.m_PurchaseUnix);
			ctx.WriteValue(prefix + "purchasePrice", d.m_PurchasePrice);
			
			ctx.WriteValue(prefix + "knownCount", d.m_KnownPlayerUIDs.Count());
			for (int j = 0; j < d.m_KnownPlayerUIDs.Count(); j++)
				ctx.WriteValue(prefix + "known/" + j.ToString(), d.m_KnownPlayerUIDs.Get(j));
			
			i = i + 1;
		}
		ctx.SaveToFile(SAVE_FILE);
	}
	
	//------------------------------------------------------------------------------------------------
	void LoadFromDisk()
	{
		if (m_Loaded) return;
		m_Loaded = true;
		if (!FileIO.FileExists(SAVE_FILE)) return;
		
		SCR_JsonLoadContext ctx = new SCR_JsonLoadContext();
		if (!ctx.LoadFromFile(SAVE_FILE)) return;
		
		int count = 0;
		ctx.ReadValue("count", count);
		
		for (int i = 0; i < count; i++)
		{
			string prefix = "doors/" + i.ToString() + "/";
			LP_DoorData d = new LP_DoorData();
			
			float px = 0; float py = 0; float pz = 0;
			ctx.ReadValue(prefix + "key", d.m_DoorKey);
			ctx.ReadValue(prefix + "prefab", d.m_PrefabName);
			ctx.ReadValue(prefix + "posX", px);
			ctx.ReadValue(prefix + "posY", py);
			ctx.ReadValue(prefix + "posZ", pz);
			d.m_Position = Vector(px, py, pz);
			ctx.ReadValue(prefix + "ownerUID", d.m_OwnerUID);
			ctx.ReadValue(prefix + "ownerName", d.m_OwnerDisplayName);
			ctx.ReadValue(prefix + "shareCode", d.m_ShareCode);
			ctx.ReadValue(prefix + "purchaseUnix", d.m_PurchaseUnix);
			ctx.ReadValue(prefix + "purchasePrice", d.m_PurchasePrice);
			
			int knownCount = 0;
			ctx.ReadValue(prefix + "knownCount", knownCount);
			for (int j = 0; j < knownCount; j++)
			{
				string kuid = "";
				ctx.ReadValue(prefix + "known/" + j.ToString(), kuid);
				if (kuid != "") d.m_KnownPlayerUIDs.Insert(kuid);
			}
			
			if (d.m_PrefabName != "" && d.m_DoorKey == "")
				d.m_DoorKey = LP_DoorData.BuildDoorKey(d.m_PrefabName, d.m_Position);
			
			if (d.m_DoorKey != "")
				m_DoorsByKey.Set(d.m_DoorKey, d);
		}
		Print(string.Format("[LP_DoorManager] Charge %1 portes depuis disque", count), LogLevel.NORMAL);
	}
	
	//------------------------------------------------------------------------------------------------
	// Serveur : synchronise les RplProps du composant sur l entite (proprio + code connus)
	// pour que les actions client-side puissent decider leur visibilite.
	// Appele apres chaque changement de proprio / code / whitelist / connect / disconnect.
	//------------------------------------------------------------------------------------------------
	void SyncDoorComponentByEntity(IEntity doorEntity, LP_DoorData door)
	{
		if (!Replication.IsServer()) return;
		if (!doorEntity) return;
		LP_DoorAccessComponent access = LP_DoorAccessComponent.Cast(
			doorEntity.FindComponent(LP_DoorAccessComponent));
		if (!access) return;
		
		if (!door)
		{
			access.ServerSetOwnerPlayerId(-1, false);
			access.ServerSetKnownPlayerIds("");
			return;
		}
		
		int ownerPid = FindConnectedPlayerIdByUID(door.m_OwnerUID);
		access.ServerSetOwnerPlayerId(ownerPid, true);
		
		string csv = "";
		foreach (string kuid : door.m_KnownPlayerUIDs)
		{
			int pid = FindConnectedPlayerIdByUID(kuid);
			if (pid <= 0) continue;
			if (csv != "") csv = csv + ",";
			csv = csv + pid.ToString();
		}
		access.ServerSetKnownPlayerIds(csv);
	}
	
	//------------------------------------------------------------------------------------------------
	// Serveur : trouve playerId d un joueur connecte via son UID, -1 si pas trouve
	protected int FindConnectedPlayerIdByUID(string uid)
	{
		if (uid == "") return -1;
		array<int> ids = new array<int>();
		GetGame().GetPlayerManager().GetPlayers(ids);
		foreach (int pid : ids)
		{
			string curUid = JobManager.GetInstance().GetPersistentUID(pid);
			if (curUid == uid) return pid;
		}
		return -1;
	}
	
	//------------------------------------------------------------------------------------------------
	// Iterateur cross-map : pour chaque porte connue au runtime, appelle le callback
	// avec (rplId string, LP_DoorData). Utile pour resync lors de connect/disconnect.
	//------------------------------------------------------------------------------------------------
	map<string, ref LP_DoorData> GetRuntimeDoors()
	{
		return m_DoorsByRplIdStr;
	}
	
	//------------------------------------------------------------------------------------------------
	// Helper : retrouve la LP_DoorData d une entite porte via prefab + position (cle stable)
	//------------------------------------------------------------------------------------------------
	LP_DoorData FindDoorByEntity(IEntity doorEntity)
	{
		if (!doorEntity) return null;
		string prefabName = doorEntity.GetPrefabData().GetPrefabName();
		vector pos = doorEntity.GetOrigin();
		string key = LP_DoorData.BuildDoorKey(prefabName, pos);
		return m_DoorsByKey.Get(key);
	}
	
	//------------------------------------------------------------------------------------------------
	// ADMIN : supprime completement une porte (proprio + code + acces).
	// La porte redevient vendable par un agent immobilier.
	// Retourne true si la porte etait presente et a ete supprimee.
	//------------------------------------------------------------------------------------------------
	bool RemoveDoor(LP_DoorData door)
	{
		if (!door) return false;
		// Supprime des 2 maps
		if (m_DoorsByKey.Contains(door.m_DoorKey))
			m_DoorsByKey.Remove(door.m_DoorKey);
		// Supprime aussi du cache runtime (peut avoir plusieurs RplIds si reboot etc)
		array<string> toRemove = new array<string>();
		foreach (string rplKey, LP_DoorData d : m_DoorsByRplIdStr)
		{
			if (d == door) toRemove.Insert(rplKey);
		}
		foreach (string k : toRemove)
			m_DoorsByRplIdStr.Remove(k);
		
		// Nettoie aussi le cache entite (evite reference dangling apres reset)
		if (m_DoorEntitiesByKey.Contains(door.m_DoorKey))
			m_DoorEntitiesByKey.Remove(door.m_DoorKey);
		
		SaveToDisk();
		Print(string.Format("[LP_DoorManager] Porte supprimee (reset admin) : %1", door.m_DoorKey), LogLevel.NORMAL);
		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	// LECTURE (pour Avocat / Admin) : retourne toutes les portes possedees.
	// Le tableau est un snapshot, pas une reference a la map interne.
	//------------------------------------------------------------------------------------------------
	array<LP_DoorData> GetAllDoors()
	{
		array<LP_DoorData> result = new array<LP_DoorData>();
		foreach (string key, LP_DoorData d : m_DoorsByKey)
		{
			if (d) result.Insert(d);
		}
		return result;
	}
	
	//------------------------------------------------------------------------------------------------
	// CACHE ENTITE : enregistre une entite porte pour lookup rapide sans scanner le monde.
	// Appele au boot (LP_LockAllOwnedDoorsOnBoot) et lors d un achat (PurchaseDoor).
	//------------------------------------------------------------------------------------------------
	void RegisterDoorEntity(string doorKey, IEntity doorEntity)
	{
		if (!doorEntity || doorKey == "") return;
		m_DoorEntitiesByKey.Set(doorKey, doorEntity);
	}
	
	//------------------------------------------------------------------------------------------------
	// CACHE ENTITE : retourne l entite associee a une porte (peut etre null si pas encore enregistree)
	//------------------------------------------------------------------------------------------------
	IEntity GetDoorEntity(string doorKey)
	{
		return m_DoorEntitiesByKey.Get(doorKey);
	}
	
	//------------------------------------------------------------------------------------------------
	// CACHE ENTITE : retourne toutes les entites porte enregistrees.
	// Utilise par LP_ResyncPortesJoueur pour eviter le scan monde a la connexion.
	//------------------------------------------------------------------------------------------------
	array<IEntity> GetAllRegisteredDoorEntities()
	{
		array<IEntity> result = new array<IEntity>();
		foreach (string k, IEntity e : m_DoorEntitiesByKey)
		{
			if (e) result.Insert(e);
		}
		return result;
	}
}
