//------------------------------------------------------------------------------------------------
// LP_PompisteRefillStationAction.c
// Action F sur un prefab de station essence (tankpistol) : "Remplir la station".
// Visible UNIQUEMENT pour le metier POMPISTE.
//
// A placer dans l ActionsManagerComponent de la station essence.
// Comportement : remplit la jauge serveur a 150L, verse 400 caps au pompiste.
//------------------------------------------------------------------------------------------------

class LP_PompisteRefillStationAction : ScriptedUserAction
{
	//------------------------------------------------------------------------------------------------
	override bool CanBeShownScript(IEntity user)
	{
		if (!user) return false;

		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return false;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return false;
		return jpc.GetJob() == EJobType.POMPISTE;
	}

	//------------------------------------------------------------------------------------------------
	override bool CanBePerformedScript(IEntity user)
	{
		return CanBeShownScript(user);
	}

	//------------------------------------------------------------------------------------------------
	override bool GetActionNameScript(out string outName)
	{
		outName = "Remplir la station essence";
		return true;
	}

	//------------------------------------------------------------------------------------------------
	override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
	{
		PlayerController localPC = GetGame().GetPlayerController();
		if (!localPC) return;
		if (localPC.GetControlledEntity() != pUserEntity) return;
		if (!pOwnerEntity) return;

		RplComponent rpl = RplComponent.Cast(pOwnerEntity.FindComponent(RplComponent));
		if (!rpl) return;

		JobPlayerComponent jpc = JobPlayerComponent.Cast(localPC.FindComponent(JobPlayerComponent));
		if (!jpc) return;

		jpc.ClientAskPompisteRefillStation(rpl.Id());
	}
}
