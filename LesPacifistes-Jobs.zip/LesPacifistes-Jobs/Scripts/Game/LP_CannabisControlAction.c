//------------------------------------------------------------------------------------------------
// LP_CannabisControlAction.c
// Action "Controle Cannabis" visible uniquement pour POLICIER et MILITAIRE.
// A placer sur le prefab PlayerController / personnage joueur.
//------------------------------------------------------------------------------------------------

class LP_CannabisControlAction : ScriptedUserAction
{
	override bool CanBeShownScript(IEntity user)
	{
		if (!user) return false;
		JobCharacterJobComponent jcjc = JobCharacterJobComponent.Cast(
			user.FindComponent(JobCharacterJobComponent));
		if (!jcjc) return false;
		EJobType job = jcjc.GetJob();
		return (job == EJobType.POLICIER || job == EJobType.MILITAIRE);
	}
	
	override bool CanBePerformedScript(IEntity user)
	{
		return CanBeShownScript(user);
	}
	
	override bool GetActionNameScript(out string outName)
	{
		outName = "Controle Cannabis";
		return true;
	}
	
	override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
	{
		PlayerController pc = PlayerController.Cast(GetGame().GetPlayerController());
		if (!pc) return;
		if (pUserEntity != pc.GetControlledEntity()) return;
		
		JobCharacterJobComponent jcjc = JobCharacterJobComponent.Cast(
			pUserEntity.FindComponent(JobCharacterJobComponent));
		if (!jcjc) return;
		EJobType job = jcjc.GetJob();
		if (job != EJobType.POLICIER && job != EJobType.MILITAIRE) return;
		
		int targetPlayerId = GetGame().GetPlayerManager().GetPlayerIdFromControlledEntity(pOwnerEntity);
		if (targetPlayerId <= 0) return;
		
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		
		jpc.ClientAskCannabisControl(targetPlayerId);
	}
}
