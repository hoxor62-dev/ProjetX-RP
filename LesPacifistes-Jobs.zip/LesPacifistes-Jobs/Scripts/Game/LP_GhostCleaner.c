//------------------------------------------------------------------------------------------------
// LP_GhostCleaner.c
// SCRIPT DE DEPANNAGE TEMPORAIRE pour Arma Reforger 1.9
//
// PROBLEME
// Depuis la 1.9, les joueurs qui se reconnectent ont une copie "ghost" de leur ancien
// character qui reste dans le monde avec tous leurs items. Les ghosts s accumulent
// d une session a l autre (constate : 2 ghosts sur une meme reconnexion).
//
// METHODE DE DETECTION (validee sur serveur le 5 nov 2026)
// Les composants AI (AIPathfindingComponent, AICharacterAimingComponent) ne permettent
// PAS de distinguer un ghost d un NPC : le prefab de character JOUEUR les porte aussi.
//
// Le signal fiable : le ghost est une COPIE du joueur, donc il a EXACTEMENT LE MEME
// PREFAB que le character du joueur qui se reconnecte. Un NPC a un prefab different.
//
//==================================================================================================
// OPTIMISATION DU 11 NOV 2026 - SUPPRESSION QUASI INSTANTANEE
//==================================================================================================
// Avant, le premier scan avait lieu a T+1s et devait attendre que PlayerManager et
// PlayerController soient d accord sur l entite controlee. Dans les faits l entite n etait
// resolue que vers T+5s a T+10s, et les autres joueurs voyaient le doublon pendant ce temps.
//
// Deux changements :
//   1. On s accroche desormais a GetOnPlayerSpawned(), qui fournit DIRECTEMENT l entite
//      du joueur au moment exact ou son character apparait. Plus besoin d attendre une
//      resolution d API : on a l entite de reference tout de suite.
//   2. Le planning des tentatives passe en millisecondes, avec un premier scan a T+150ms
//      puis des reessais rapproches (400ms, 800ms, 1.5s...) avant de s espacer.
//
// GetOnPlayerConnected() reste branche en secours, au cas ou l evenement de spawn ne se
// declenche pas dans certaines situations.
//==================================================================================================
//
// Un character est supprime seulement s il remplit TOUTES ces conditions :
//   1. c est un SCR_ChimeraCharacter
//   2. ce n est PAS l entite de reference du joueur qui vient de spawn
//   3. il n est controle par AUCUN joueur connecte actuellement
//   4. il n a PAS de JobNPCComponent (securite supplementaire pour les NPC du mod)
//   5. il n est PAS en etat DEAD (on laisse les vrais dead bodies au GC engine)
//   6. son prefab est IDENTIQUE a celui du character du joueur
//   7. il est a moins de GHOST_MAX_DIST_M du joueur
//
// MODE DIAGNOSTIC
//   VERBOSE_DIAG = true : logge chaque character trouve avec son prefab, sa distance et
//   le verdict exact. Passer a false une fois le comportement valide en prod.
//
// INSTALLATION
//   Attacher ce composant a ton GameMode entity (meme endroit que InventorySaveManager).
//------------------------------------------------------------------------------------------------

class LP_GhostCleanerClass : ScriptComponentClass {}

class LP_GhostCleaner : ScriptComponent
{
    static LP_GhostCleaner s_Instance;

    // Rayon du scan (metres). Le ghost est toujours a moins de 2m dans les logs reels,
    // on garde de la marge pour le diagnostic sans scanner toute la zone.
    protected const float SCAN_RADIUS_M = 25.0;

    // Distance max a laquelle un character peut etre considere comme le ghost du joueur.
    protected const float GHOST_MAX_DIST_M = 15.0;

    // Diagnostic verbeux. Passer a false une fois valide pour alleger les logs.
    protected const bool VERBOSE_DIAG = true;

    // Buffer temporaire pour le callback de QueryEntitiesBySphere.
    protected ref array<IEntity> m_FoundBuffer = new array<IEntity>();

    // Entite de reference fournie par GetOnPlayerSpawned, par playerId.
    // C est le character REEL du joueur : il sert de reference (prefab + position) et il
    // est protege explicitement, meme si PlayerManager n a pas encore rattrape son retard.
    protected ref map<int, IEntity> m_SpawnedEntity = new map<int, IEntity>();

    //------------------------------------------------------------------------------------------------
    override void OnPostInit(IEntity owner)
    {
        super.OnPostInit(owner);
        s_Instance = this;

        if (!Replication.IsServer()) return;

        SCR_BaseGameMode gm = SCR_BaseGameMode.Cast(GetGame().GetGameMode());
        if (!gm)
        {
            Print("[LP_GhostCleaner] GameMode introuvable, script inactif", LogLevel.ERROR);
            return;
        }

        // Voie rapide : l evenement de spawn donne directement l entite du joueur.
        //
        // ATTENTION AU TYPE : GetOnPlayerSpawned() ne renvoie PAS un ScriptInvoker generique
        // mais un ScriptInvokerBase<SCR_BaseGameMode_PlayerIdAndEntity>, type par la signature
        // (int playerId, IEntity controlledEntity). Declarer un ScriptInvoker provoque
        // "Types ... are unrelated" a la compilation.
        ScriptInvokerBase<SCR_BaseGameMode_PlayerIdAndEntity> onSpawned = gm.GetOnPlayerSpawned();
        if (onSpawned)
        {
            onSpawned.Insert(OnPlayerSpawned);
            Print("[LP_GhostCleaner] Initialise - voie rapide OnPlayerSpawned active (premier scan a T+150ms)", LogLevel.NORMAL);
        }
        else
        {
            Print("[LP_GhostCleaner] ATTENTION : GetOnPlayerSpawned indisponible, seul le secours OnPlayerConnected sera utilise", LogLevel.WARNING);
        }

        // Secours : si l evenement de spawn ne se declenche pas, on repart de la connexion.
        gm.GetOnPlayerConnected().Insert(OnPlayerConnected);
    }

    static LP_GhostCleaner GetInstance()
    {
        return s_Instance;
    }

    //------------------------------------------------------------------------------------------------
    // ===== PLANNING DES TENTATIVES =====
    //------------------------------------------------------------------------------------------------

    //------------------------------------------------------------------------------------------------
    // Moment (en MILLISECONDES depuis le declenchement) de la tentative N.
    // Retourne -1 si N depasse le nombre de tentatives prevues.
    // Pour modifier le planning, c est ICI et nulle part ailleurs.
    //------------------------------------------------------------------------------------------------
    int GetAbsoluteScheduleMs(int attempt)
    {
        // Rafale initiale : objectif supprimer le doublon avant que quiconque le voie.
        if (attempt == 1) return 150;
        if (attempt == 2) return 400;
        if (attempt == 3) return 800;
        if (attempt == 4) return 1500;
        if (attempt == 5) return 2500;
        if (attempt == 6) return 4000;

        // Filet de securite si le ghost se materialise tard.
        if (attempt == 7) return 6000;
        if (attempt == 8) return 10000;
        if (attempt == 9) return 15000;
        if (attempt == 10) return 25000;
        if (attempt == 11) return 40000;

        return -1;
    }

    //------------------------------------------------------------------------------------------------
    // Delai en ms entre la tentative courante et la suivante. -1 s il n y en a plus.
    //------------------------------------------------------------------------------------------------
    int GetDelayToNextAttemptMs(int currentAttempt)
    {
        int cur = GetAbsoluteScheduleMs(currentAttempt);
        int next = GetAbsoluteScheduleMs(currentAttempt + 1);
        if (cur < 0 || next < 0)
            return -1;
        return next - cur;
    }

    //------------------------------------------------------------------------------------------------
    protected void ScheduleNextAttempt(int playerId, int attempt, string tag)
    {
        int nextDelay = GetDelayToNextAttemptMs(attempt);
        if (nextDelay <= 0)
        {
            Print("[LP_GhostCleaner] " + tag + " : aucun ghost apres toutes les tentatives, abandon", LogLevel.WARNING);
            m_SpawnedEntity.Remove(playerId);
            return;
        }

        if (VERBOSE_DIAG)
        {
            int nextAbs = GetAbsoluteScheduleMs(attempt + 1);
            Print("[LP_GhostCleaner] " + tag + " : rien, prochaine tentative a T+" + nextAbs + "ms", LogLevel.NORMAL);
        }

        GetGame().GetCallqueue().CallLater(ScanAroundPlayer, nextDelay, false, playerId, attempt + 1);
    }

    //------------------------------------------------------------------------------------------------
    // ===== DECLENCHEURS =====
    //------------------------------------------------------------------------------------------------

    //------------------------------------------------------------------------------------------------
    // VOIE RAPIDE. L evenement fournit l entite du joueur au moment exact du spawn :
    // on la memorise comme reference et on lance la rafale de scans immediatement.
    //------------------------------------------------------------------------------------------------
    void OnPlayerSpawned(int playerId, IEntity controlledEntity)
    {
        if (!Replication.IsServer()) return;

        if (controlledEntity)
            m_SpawnedEntity.Set(playerId, controlledEntity);

        int firstDelay = GetAbsoluteScheduleMs(1);
        GetGame().GetCallqueue().CallLater(ScanAroundPlayer, firstDelay, false, playerId, 1);
    }

    //------------------------------------------------------------------------------------------------
    // SECOURS. Si l evenement de spawn n a pas fourni d entite, on repart de la connexion
    // avec le meme planning. Si une chaine est deja lancee par OnPlayerSpawned, les deux
    // cohabitent sans dommage (le scan est idempotent et s arrete des qu un ghost tombe).
    //------------------------------------------------------------------------------------------------
    void OnPlayerConnected(int playerId)
    {
        if (!Replication.IsServer()) return;

        int firstDelay = GetAbsoluteScheduleMs(1);
        GetGame().GetCallqueue().CallLater(ScanAroundPlayer, firstDelay, false, playerId, 1);
    }

    //------------------------------------------------------------------------------------------------
    // ===== SCAN =====
    //------------------------------------------------------------------------------------------------

    //------------------------------------------------------------------------------------------------
    // Resout l entite de reference du joueur : d abord celle fournie par l evenement de
    // spawn (disponible immediatement), sinon celle de PlayerManager.
    //------------------------------------------------------------------------------------------------
    protected IEntity ResolvePlayerEntity(int playerId)
    {
        IEntity fromSpawn = m_SpawnedEntity.Get(playerId);
        if (fromSpawn)
            return fromSpawn;
        return GetGame().GetPlayerManager().GetPlayerControlledEntity(playerId);
    }

    //------------------------------------------------------------------------------------------------
    void ScanAroundPlayer(int playerId, int attempt)
    {
        int absMs = GetAbsoluteScheduleMs(attempt);
        string tag = "T" + attempt + " (T+" + absMs + "ms) player " + playerId;

        IEntity playerEntity = ResolvePlayerEntity(playerId);
        if (!playerEntity)
        {
            if (VERBOSE_DIAG)
                Print("[LP_GhostCleaner] " + tag + " : entite joueur pas encore disponible", LogLevel.NORMAL);
            ScheduleNextAttempt(playerId, attempt, tag);
            return;
        }

        int cleaned = DoScan(playerEntity, tag);

        if (cleaned > 0)
        {
            Print("[LP_GhostCleaner] " + tag + " : " + cleaned + " ghost(s) supprime(s) - arret des tentatives", LogLevel.NORMAL);
            m_SpawnedEntity.Remove(playerId);
            return;
        }

        ScheduleNextAttempt(playerId, attempt, tag);
    }

    //------------------------------------------------------------------------------------------------
    // Coeur du scan. Compare chaque character trouve au prefab du character du joueur.
    // Retourne le nombre de ghosts effectivement supprimes.
    //------------------------------------------------------------------------------------------------
    int DoScan(IEntity playerEntity, string tag)
    {
        vector origin = playerEntity.GetOrigin();

        // Prefab du character du joueur : reference pour identifier son ghost.
        string playerPrefab = "";
        EntityPrefabData ppd = playerEntity.GetPrefabData();
        if (ppd)
            playerPrefab = ppd.GetPrefabName();

        if (playerPrefab == "")
        {
            if (VERBOSE_DIAG)
                Print("[LP_GhostCleaner] " + tag + " : prefab du joueur introuvable, scan annule", LogLevel.NORMAL);
            return 0;
        }

        // Entites intouchables.
        array<string> legitIds = {};

        // 1) L entite de reference elle-meme. ESSENTIEL : avec la voie rapide on scanne
        //    avant que PlayerManager ait rattrape son retard, donc le vrai corps du joueur
        //    pourrait ne pas apparaitre dans la liste ci-dessous. On le protege en dur.
        legitIds.Insert(playerEntity.GetID().ToString());

        // 2) Tout ce que les joueurs connectes controlent, vu des deux sources d autorite.
        array<int> allPids = {};
        GetGame().GetPlayerManager().GetPlayers(allPids);
        foreach (int pid : allPids)
        {
            IEntity e = GetGame().GetPlayerManager().GetPlayerControlledEntity(pid);
            if (e)
                legitIds.Insert(e.GetID().ToString());

            PlayerController otherPc = GetGame().GetPlayerManager().GetPlayerController(pid);
            if (otherPc)
            {
                IEntity otherCtrl = otherPc.GetControlledEntity();
                if (otherCtrl)
                    legitIds.Insert(otherCtrl.GetID().ToString());
            }

            // 3) Et les entites de reference memorisees pour les joueurs en cours de spawn.
            IEntity otherSpawn = m_SpawnedEntity.Get(pid);
            if (otherSpawn)
                legitIds.Insert(otherSpawn.GetID().ToString());
        }

        // Scan sphere autour du joueur
        m_FoundBuffer.Clear();
        GetGame().GetWorld().QueryEntitiesBySphere(origin, SCAN_RADIUS_M, QueryCallback, null, EQueryEntitiesFlags.ALL);

        int charsSeen = 0;
        int deleted = 0;
        ref array<IEntity> toDelete = {};

        foreach (IEntity found : m_FoundBuffer)
        {
            if (!found) continue;

            SCR_ChimeraCharacter chara = SCR_ChimeraCharacter.Cast(found);
            if (!chara) continue;

            charsSeen++;

            string reason;
            bool isGhost = IsGhostCharacter(found, legitIds, playerPrefab, origin, reason);

            if (VERBOSE_DIAG)
            {
                float dist = vector.Distance(origin, found.GetOrigin());
                string foundPrefab = "(inconnu)";
                EntityPrefabData fpd = found.GetPrefabData();
                if (fpd)
                    foundPrefab = ShortPrefab(fpd.GetPrefabName());

                Print("[LP_GhostCleaner]   id=" + found.GetID() + " dist=" + dist + "m prefab=" + foundPrefab + " verdict=" + reason, LogLevel.NORMAL);
            }

            if (isGhost)
                toDelete.Insert(found);
        }

        if (toDelete.Count() > 0 || VERBOSE_DIAG)
        {
            Print("[LP_GhostCleaner] " + tag + " : prefab joueur = " + ShortPrefab(playerPrefab)
                + ", " + charsSeen + " character(s) examine(s), " + toDelete.Count() + " ghost(s) identifie(s)", LogLevel.NORMAL);
        }

        // Suppression hors de la boucle d iteration du buffer
        foreach (IEntity ghost : toDelete)
        {
            if (!ghost) continue;
            vector gpos = ghost.GetOrigin();
            Print("[LP_GhostCleaner] Suppression ghost id=" + ghost.GetID() + " pos=(" + gpos[0] + ", " + gpos[1] + ", " + gpos[2] + ")", LogLevel.NORMAL);
            SCR_EntityHelper.DeleteEntityAndChildren(ghost);
            deleted++;
        }

        m_FoundBuffer.Clear();
        return deleted;
    }

    //------------------------------------------------------------------------------------------------
    // Determine si une entite est le ghost du joueur. Renseigne outReason pour le diagnostic.
    //
    // ORDRE DES CHECKS (le premier qui matche gagne et donne la raison affichee) :
    //   1. pas un character                -> ignore
    //   2. controle / entite de reference  -> protege
    //   3. JobNPCComponent present         -> protege (NPC du mod)
    //   4. etat DEAD                       -> protege (dead body legitime)
    //   5. prefab different du joueur      -> protege (AI ou autre character)
    //   6. trop loin                       -> protege (pas le ghost de CE joueur)
    //   7. sinon                           -> GHOST
    //------------------------------------------------------------------------------------------------
    bool IsGhostCharacter(IEntity ent, array<string> legitIds, string playerPrefab, vector playerPos, out string outReason)
    {
        outReason = "";

        SCR_ChimeraCharacter chara = SCR_ChimeraCharacter.Cast(ent);
        if (!chara)
        {
            outReason = "pas un character";
            return false;
        }

        string idStr = ent.GetID().ToString();
        if (legitIds.Find(idStr) >= 0)
        {
            outReason = "JOUEUR ACTIF (controle)";
            return false;
        }

        if (ent.FindComponent(JobNPCComponent))
        {
            outReason = "NPC (JobNPCComponent)";
            return false;
        }

        CharacterControllerComponent ccc = CharacterControllerComponent.Cast(
            ent.FindComponent(CharacterControllerComponent)
        );
        if (ccc)
        {
            ECharacterLifeState state = ccc.GetLifeState();
            if (state == ECharacterLifeState.DEAD)
            {
                outReason = "dead body (DEAD)";
                return false;
            }
        }

        EntityPrefabData pd = ent.GetPrefabData();
        if (!pd)
        {
            outReason = "pas de prefab data";
            return false;
        }
        string entPrefab = pd.GetPrefabName();
        if (entPrefab != playerPrefab)
        {
            outReason = "prefab different";
            return false;
        }

        float dist = vector.Distance(playerPos, ent.GetOrigin());
        if (dist > GHOST_MAX_DIST_M)
        {
            outReason = "meme prefab mais trop loin (" + dist + "m)";
            return false;
        }

        outReason = "GHOST";
        return true;
    }

    //------------------------------------------------------------------------------------------------
    // Raccourcit un ResourceName pour l affichage dans les logs :
    // "{GUID}Prefabs/Characters/Civilian_01.et" -> "Civilian_01.et"
    // Enforce n a pas de LastIndexOf, on scanne manuellement.
    //------------------------------------------------------------------------------------------------
    string ShortPrefab(string full)
    {
        if (full == "")
            return "(vide)";

        int len = full.Length();
        int lastSlash = -1;
        for (int i = 0; i < len; i++)
        {
            if (full.Substring(i, 1) == "/")
                lastSlash = i;
        }

        if (lastSlash < 0 || lastSlash >= len - 1)
            return full;

        return full.Substring(lastSlash + 1, len - lastSlash - 1);
    }

    //------------------------------------------------------------------------------------------------
    bool QueryCallback(IEntity entity)
    {
        if (entity)
            m_FoundBuffer.Insert(entity);
        return true;
    }
}
