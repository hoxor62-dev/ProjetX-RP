//------------------------------------------------------------------------------------------------
// LP_BucheronCraftAction.c
// Action "Craft bucheron" a placer sur une entite dediee via Workbench.
// Visible UNIQUEMENT si le joueur a le metier BUCHERON.
//------------------------------------------------------------------------------------------------

class LP_BucheronCraftAction : ScriptedUserAction
{
	//------------------------------------------------------------------------------------------------
	override bool CanBeShownScript(IEntity user)
	{
		if (!user) return false;
		
		JobCharacterJobComponent jcjc = JobCharacterJobComponent.Cast(
			user.FindComponent(JobCharacterJobComponent));
		if (!jcjc) return false;
		
		return jcjc.GetJob() == EJobType.BUCHERON;
	}
	
	//------------------------------------------------------------------------------------------------
	override bool CanBePerformedScript(IEntity user)
	{
		return CanBeShownScript(user);
	}
	
	//------------------------------------------------------------------------------------------------
	override bool GetActionNameScript(out string outName)
	{
		outName = "Craft bucheron";
		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
	{
		PlayerController pc = PlayerController.Cast(GetGame().GetPlayerController());
		if (!pc) return;
		if (pUserEntity != pc.GetControlledEntity()) return;
		
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		
		JobCharacterJobComponent jcjc = JobCharacterJobComponent.Cast(
			pUserEntity.FindComponent(JobCharacterJobComponent));
		if (!jcjc || jcjc.GetJob() != EJobType.BUCHERON)
			return;
		
		GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.LP_BucheronCraftMenu);
	}
}
