//------------------------------------------------------------------------------------------------
// LP_DoorAdminResetAction.c
// Action "Admin[RESET]" - visible UNIQUEMENT pour les admins.
// Reset la porte : supprime le proprietaire + tous les acces + code partage.
// La porte redevient vendable par un agent immobilier.
//
// Le check admin est fait cote client (visibilite via m_ClientIsAdmin) ET serveur
// (authoritative dans RpcAsk_AdminResetDoor via JobAdminManager.IsAdmin).
//
// SECURITE : exige un DOUBLE-APPUI dans les 3 secondes pour confirmer.
//   - 1er appui : affiche un hint "Appuyez a nouveau pour CONFIRMER le reset"
//   - 2eme appui dans les 3s sur la MEME porte : execute le reset effectif
//   - Hors fenetre ou autre porte : repart a zero (nouveau prompt)
//------------------------------------------------------------------------------------------------

class LP_DoorAdminResetAction : ScriptedUserAction
{
	// Etat partage entre deux appels pour tracker la fenetre de confirmation.
	// Static car l action est instanciee par porte, mais le double-tap doit cibler
	// la meme porte dans la meme fenetre temporelle quelle que soit l instance.
	static RplId s_PendingDoorRplId = RplId.Invalid();
	static int s_PendingClickTime = 0;
	const int CONFIRM_WINDOW_MS = 3000;

	override bool CanBeShownScript(IEntity user)
	{
		if (!user) return false;

		// Check admin local
		PlayerController pc = PlayerController.Cast(GetGame().GetPlayerController());
		if (!pc) return false;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc || !jpc.IsClientAdmin()) return false;

		// La porte doit avoir un proprietaire pour etre reset
		IEntity door = GetOwner();
		if (!door) return false;
		LP_DoorAccessComponent access = LP_DoorAccessComponent.Cast(
			door.FindComponent(LP_DoorAccessComponent));
		if (!access || !access.HasOwner()) return false;

		return true;
	}

	override bool CanBePerformedScript(IEntity user) { return CanBeShownScript(user); }

	override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
	{
		PlayerController pc = PlayerController.Cast(GetGame().GetPlayerController());
		if (!pc) return;
		if (pUserEntity != pc.GetControlledEntity()) return;

		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;

		RplComponent rpl = RplComponent.Cast(pOwnerEntity.FindComponent(RplComponent));
		if (!rpl) return;

		RplId doorId = rpl.Id();
		int now = System.GetTickCount();

		// Deuxieme appui sur la meme porte dans la fenetre de confirmation : execute
		if (s_PendingDoorRplId == doorId && (now - s_PendingClickTime) <= CONFIRM_WINDOW_MS)
		{
			s_PendingDoorRplId = RplId.Invalid();
			s_PendingClickTime = 0;
			jpc.ClientAskAdminResetDoor(doorId);
			LP_NotificationManager.Show(
				"Reset confirme : envoi au serveur en cours.",
				"ADMIN",
				3);
			return;
		}

		// Premier appui (ou nouvelle porte, ou fenetre expiree) : affiche le prompt de confirmation
		s_PendingDoorRplId = doorId;
		s_PendingClickTime = now;
		LP_NotificationManager.Show(
			"RESET de cette porte : appuyez a nouveau dans les 3 secondes pour CONFIRMER.",
			"ADMIN",
			3);
	}
}
