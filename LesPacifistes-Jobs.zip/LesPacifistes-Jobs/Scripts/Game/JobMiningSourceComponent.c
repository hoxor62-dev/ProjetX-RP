//------------------------------------------------------------------------------------------------
// JobMiningSourceComponent.c
// A attacher sur les prefabs source d'extraction (roche, plant cannabis, plant cocaine,
// arbre pour le bois, pommier pour les pommes, champ pour le ble).
// Configure dans Workbench le type via l'attribut m_MineralType :
//  - 1 = ROCK
//  - 2 = CANNABIS
//  - 3 = COCAINE
//  - 4 = WOOD
//  - 5 = APPLE
//  - 6 = WHEAT
//
// Plusieurs joueurs peuvent miner simultanement le meme prefab, chacun a son propre compteur
// gere via JobMiningSession (cote serveur dans JobPlayerComponent).
//
// Apres qu'un joueur ait fini 30/30 sur cette source, un cooldown de 5 minutes s'applique
// uniquement pour CE joueur sur CETTE source.
//------------------------------------------------------------------------------------------------

[ComponentEditorProps(category: "LesPacifistesJobs", description: "Source d'extraction (roche, plant, champ)")]
class JobMiningSourceComponentClass : ScriptComponentClass
{
}

class JobMiningSourceComponent : ScriptComponent
{
	[Attribute(defvalue: "1", uiwidget: UIWidgets.ComboBox, desc: "Type de ressource",
		enums: { ParamEnum("Roche", "1"), ParamEnum("Cannabis", "2"), ParamEnum("Cocaine", "3"),
			ParamEnum("Bois", "4"), ParamEnum("Pomme", "5"), ParamEnum("Ble", "6") })]
	int m_MineralType;
	
	//------------------------------------------------------------------------------------------------
	EMineralType GetMineralType()
	{
		return m_MineralType;
	}
}
