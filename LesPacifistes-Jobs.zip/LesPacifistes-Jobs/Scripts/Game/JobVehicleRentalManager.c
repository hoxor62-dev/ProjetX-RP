//------------------------------------------------------------------------------------------------
// JobVehicleRentalManager.c
// Manager singleton server-side des locations de vehicules au shop public.
//
// Workflow :
// 1. Joueur paye et selectionne vehicule + duree
// 2. Vehicule spawn pres du joueur, location enregistree avec timestamp Unix de fin
// 3. Tick 10s verifie les notifications (10 min avant fin, 5 min avant fin)
// 4. Si timeout depasse de 5 min : eject joueur + supprime vehicule
// 5. Joueur peut rendre le vehicule a la zone de retour (7m de la position de retour)
//
// Persistance : $profile:LesPacifistesJobs/vehicle_rentals.json
// Robuste au reboot serveur via timestamps Unix (System.GetUnixTime).
//------------------------------------------------------------------------------------------------

class JobVehicleRental
{
	string m_PlayerUID;          // UID Bohemia du locataire
	int m_PlayerId;              // playerId courant (peut changer entre sessions, ne pas se fier en dur)
	RplId m_VehicleRplId;        // RplId du vehicule spawne (peut etre invalide apres reboot)
	int m_VehicleType;           // EVehicleRentalType (1=GolfCart, 2=Bike, 3=Ford)
	int m_StartUnix;             // timestamp Unix de debut
	int m_EndUnix;               // timestamp Unix de fin de location
	bool m_Notif10MinSent;       // true si la notif 10 min a deja ete envoyee
	bool m_Notif5MinSent;        // true si la notif 5 min a deja ete envoyee
	bool m_TimeExpiredNotified;  // true si le message timeout a ete envoye
	int m_GraceEndUnix;          // si > 0 : timestamp jusqu'auquel on tolere avant ejection
	// Derniere position connue du vehicule (mise a jour periodiquement par le tick).
	// Utilisee apres reboot pour retrouver le vehicule physique dans le monde
	// (le RplId change entre sessions mais la position est preservee par la persistance native).
	float m_LastPosX;
	float m_LastPosY;
	float m_LastPosZ;
	bool m_HasLastPos;
	
	void JobVehicleRental()
	{
		m_VehicleRplId = RplId.Invalid();
		m_Notif10MinSent = false;
		m_Notif5MinSent = false;
		m_TimeExpiredNotified = false;
		m_GraceEndUnix = 0;
		m_HasLastPos = false;
	}
}

enum EVehicleRentalType
{
	NONE = 0,
	GOLF_CART = 1,
	WW2_BIKE = 2,
	FORD_F150 = 3
}

class JobVehicleRentalManager
{
	static ref JobVehicleRentalManager s_Instance;
	
	// Locations actives - clef = UID joueur
	ref map<string, ref JobVehicleRental> m_Rentals;
	
	// Constantes
	const string SAVE_PATH = "$profile:LesPacifistesJobs/vehicle_rentals.json";
	
	// Position de retour du vehicule (zone shop location)
	const float RETURN_X = 1962.639;
	const float RETURN_Y = 365.646;
	const float RETURN_Z = 734.93;
	const float RETURN_RADIUS = 7.0;       // distance max du vehicule a la zone de retour
	
	// Spawn pres du joueur
	const float SPAWN_DISTANCE = 8.0;       // distance au joueur lors du spawn
	
	// Notifications
	const int NOTIF_10_MIN_SECONDS = 600;
	const int NOTIF_5_MIN_SECONDS = 300;
	
	// Tolerance apres expiration avant ejection
	const int GRACE_PERIOD_SECONDS = 300;   // 5 minutes
	
	//------------------------------------------------------------------------------------------------
	void JobVehicleRentalManager()
	{
		m_Rentals = new map<string, ref JobVehicleRental>();
	}
	
	//------------------------------------------------------------------------------------------------
	static JobVehicleRentalManager GetInstance()
	{
		if (!s_Instance)
		{
			s_Instance = new JobVehicleRentalManager();
			// Differe le chargement pour s'assurer que le monde est completement initialise
			// (sinon GetWorld() peut retourner null lors du respawn des vehicules au reboot)
			GetGame().GetCallqueue().CallLater(s_Instance.LoadFromDisk, 5000, false);
			GetGame().GetCallqueue().CallLater(TickCallback, 15000, true);
		}
		return s_Instance;
	}
	
	//------------------------------------------------------------------------------------------------
	static void TickCallback()
	{
		if (!Replication.IsServer())
			return;
		if (!s_Instance)
			return;
		s_Instance.Tick();
	}
	
	//------------------------------------------------------------------------------------------------
	// Renvoie le prefab du vehicule selon le type
	//------------------------------------------------------------------------------------------------
	static ResourceName GetVehiclePrefab(int vehicleType)
	{
		switch (vehicleType)
		{
			case EVehicleRentalType.GOLF_CART:
				return "{C25C065F5B173ED6}Prefabs/Vehicles/moto/tmax/tmax2-rental.et";
			case EVehicleRentalType.WW2_BIKE:
				return "{3FDBFE7F1A1EB8F2}Prefabs/Vehicles/Wheeled/WW2_Bike/WW2_Bike_base.et";
			case EVehicleRentalType.FORD_F150:
				return "{1B3D4C7040A97656}Prefabs/Vehicles/Wheeled/twingo/twingo-rental.et";
		}
		return "";
	}
	
	//------------------------------------------------------------------------------------------------
	static string GetVehicleLabel(int vehicleType)
	{
		switch (vehicleType)
		{
			case EVehicleRentalType.GOLF_CART: return "Vieille Moto Susuki";
			case EVehicleRentalType.WW2_BIKE:  return "Vieux Velo";
			case EVehicleRentalType.FORD_F150: return "Sarka Bleu";
		}
		return "Vehicule";
	}
	
	//------------------------------------------------------------------------------------------------
	// Renvoie le prix selon le vehicule et la duree (en heures)
	//------------------------------------------------------------------------------------------------
	static int GetPrice(int vehicleType, int hours)
	{
		switch (vehicleType)
		{
			case EVehicleRentalType.GOLF_CART:
			{
				if (hours == 1) return 150;
				if (hours == 2) return 200;
				if (hours == 3) return 250;
				break;
			}
			case EVehicleRentalType.WW2_BIKE:
			{
				if (hours == 1) return 75;
				if (hours == 2) return 125;
				if (hours == 3) return 200;
				break;
			}
			case EVehicleRentalType.FORD_F150:
			{
				if (hours == 1) return 225;
				if (hours == 2) return 310;
				if (hours == 3) return 400;
				break;
			}
		}
		return 0;
	}
	
	//------------------------------------------------------------------------------------------------
	// Verifie si un joueur a deja une location active
	//------------------------------------------------------------------------------------------------
	bool HasActiveRental(string uid)
	{
		return (m_Rentals.Get(uid) != null);
	}
	
	//------------------------------------------------------------------------------------------------
	JobVehicleRental GetRental(string uid)
	{
		return m_Rentals.Get(uid);
	}
	
	//------------------------------------------------------------------------------------------------
	// Retourne le timestamp Unix de fin de location du vehicule identifie par son RplId,
	// ou 0 si ce vehicule n est pas une location active.
	// Utilise par le HUD client (LP_VehicleRentalHudComponent) pour afficher le compte a rebours.
	//------------------------------------------------------------------------------------------------
	int GetRentalEndUnixByVehicleRplId(int rplIdInt)
	{
		if (rplIdInt == 0)
		{
			return 0;
		}
		RplId targetRid = rplIdInt;
		
		
		foreach (string uid, JobVehicleRental r : m_Rentals)
		{
			if (!r) continue;
			int storedRplInt = r.m_VehicleRplId.ToString().ToInt();
			if (r.m_VehicleRplId == targetRid)
			{
				return r.m_EndUnix;
			}
		}
		return 0;
	}
	
	//------------------------------------------------------------------------------------------------
	// Demarre une nouvelle location. Retourne 0 = OK, code erreur sinon.
	// 1 = deja une location active
	// 2 = pas assez de capsules
	// 3 = vehicule introuvable / spawn echec
	//------------------------------------------------------------------------------------------------
	int StartRental(int playerId, string uid, int vehicleType, int hours)
	{
		if (HasActiveRental(uid))
			return 1;
		
		int price = GetPrice(vehicleType, hours);
		if (price <= 0)
			return 3;
		
		CapsuleEconomyManager eco = CapsuleEconomyManager.GetInstance();
		if (!eco)
			return 3;
		int balance = eco.GetCapsules(uid);
		if (balance < price)
			return 2;
		
		// Spawn du vehicule pres du joueur
		PlayerManager pm = GetGame().GetPlayerManager();
		if (!pm)
			return 3;
		PlayerController pc = pm.GetPlayerController(playerId);
		if (!pc)
			return 3;
		IEntity character = pc.GetControlledEntity();
		if (!character)
			return 3;
		
		IEntity vehicle = SpawnVehicleNearPlayer(character, vehicleType);
		if (!vehicle)
			return 3;
		
		RplComponent rpl = RplComponent.Cast(vehicle.FindComponent(RplComponent));
		if (!rpl)
			return 3;
		
		// Debit des capsules (pattern : AddCapsules avec montant negatif)
		eco.AddCapsules(uid, -price);
		// Sync HUD capsules
		CapsulePlayerComponent caps = CapsulePlayerComponent.Cast(pc.FindComponent(CapsulePlayerComponent));
		if (caps)
			caps.Svr_SendCapsules(eco.GetCapsules(uid));
		
		// Cree l'entree de location
		JobVehicleRental r = new JobVehicleRental();
		r.m_PlayerUID = uid;
		r.m_PlayerId = playerId;
		r.m_VehicleRplId = rpl.Id();
		r.m_VehicleType = vehicleType;
		r.m_StartUnix = System.GetUnixTime();
		r.m_EndUnix = r.m_StartUnix + (hours * 3600);
		// Sauve la position initiale du vehicule (utile pour la persistance)
		vector initPos = vehicle.GetOrigin();
		r.m_LastPosX = initPos[0];
		r.m_LastPosY = initPos[1];
		r.m_LastPosZ = initPos[2];
		r.m_HasLastPos = true;
		m_Rentals.Set(uid, r);
		SaveToDisk();
		
		string label = GetVehicleLabel(vehicleType);
		JobManager.GetInstance().NotifyPlayerChat(playerId,
			string.Format("[LOCATION] %1 louee pour %2h - %3 capsules debitees. Le vehicule est pres de vous.",
				label, hours, price));
		
		return 0;
	}
	
	//------------------------------------------------------------------------------------------------
	IEntity SpawnVehicleNearPlayer(IEntity character, int vehicleType)
	{
		ResourceName prefab = GetVehiclePrefab(vehicleType);
		if (prefab == "")
			return null;
		
		Resource res = Resource.Load(prefab);
		if (!res || !res.IsValid())
		{
			Print(string.Format("[JobVehicleRentalManager] Prefab invalide : %1", prefab),
				LogLevel.WARNING);
			return null;
		}
		
		// Position de spawn : a 8m derriere/cote du joueur
		vector playerPos = character.GetOrigin();
		vector playerDir = character.GetTransformAxis(2);  // forward
		vector spawnPos = playerPos + (playerDir * SPAWN_DISTANCE);
		
		// Ajuste la hauteur (peut etre ajustee par le moteur ensuite)
		float surfaceY = GetGame().GetWorld().GetSurfaceY(spawnPos[0], spawnPos[2]);
		spawnPos[1] = surfaceY + 0.3;
		
		EntitySpawnParams p = new EntitySpawnParams();
		p.TransformMode = ETransformMode.WORLD;
		Math3D.MatrixIdentity4(p.Transform);
		p.Transform[3] = spawnPos;
		
		IEntity vehicle = GetGame().SpawnEntityPrefab(res, GetGame().GetWorld(), p);
		return vehicle;
	}
	
	//------------------------------------------------------------------------------------------------
	// Tick principal (toutes les 10s)
	//------------------------------------------------------------------------------------------------
	void Tick()
	{
		int now = System.GetUnixTime();
		array<string> toCheck = new array<string>();
		foreach (string uid, JobVehicleRental r : m_Rentals)
		{
			if (r) toCheck.Insert(uid);
		}
		
		foreach (string uid : toCheck)
		{
			JobVehicleRental r = m_Rentals.Get(uid);
			if (!r)
				continue;
			
			// Verifie que le vehicule existe encore
			RplComponent vehRpl = RplComponent.Cast(Replication.FindItem(r.m_VehicleRplId));
			IEntity vehicle = null;
			if (vehRpl)
				vehicle = vehRpl.GetEntity();
			
			if (!vehicle)
			{
				// Vehicule detruit ou perdu : on annule la location proprement
				NotifyOwnerChat(uid, "[LOCATION] Votre vehicule a ete detruit ou est introuvable. Location annulee.");
				m_Rentals.Remove(uid);
				SaveToDisk();
				continue;
			}
			
			// Met a jour la derniere position connue du vehicule (pour retrouvabilite apres reboot)
			vector vehPos = vehicle.GetOrigin();
			r.m_LastPosX = vehPos[0];
			r.m_LastPosY = vehPos[1];
			r.m_LastPosZ = vehPos[2];
			r.m_HasLastPos = true;
			
			// Resoud le playerId actuel (peut avoir change)
			int playerId = ResolvePlayerIdFromUID(uid);
			
			int remaining = r.m_EndUnix - now;
			
			// Notifications
			if (!r.m_Notif10MinSent && remaining <= NOTIF_10_MIN_SECONDS && remaining > NOTIF_5_MIN_SECONDS)
			{
				if (playerId > 0)
				{
					JobManager.GetInstance().NotifyPlayerChat(playerId,
						"[LOCATION] Plus que 10 minutes ! Pensez a rendre votre vehicule au shop de location.");
				}
				r.m_Notif10MinSent = true;
				SaveToDisk();
			}
			else if (!r.m_Notif5MinSent && remaining <= NOTIF_5_MIN_SECONDS && remaining > 0)
			{
				if (playerId > 0)
				{
					JobManager.GetInstance().NotifyPlayerChat(playerId,
						"[LOCATION] Plus que 5 minutes ! Rendez votre vehicule rapidement.");
				}
				r.m_Notif5MinSent = true;
				SaveToDisk();
			}
			
			// Expiration : on demarre la grace period
			if (remaining <= 0 && r.m_GraceEndUnix == 0)
			{
				r.m_GraceEndUnix = now + GRACE_PERIOD_SECONDS;
				if (playerId > 0)
				{
					JobManager.GetInstance().NotifyPlayerChat(playerId,
						"[LOCATION] Temps de location ECOULE ! Vous avez 5 minutes pour rendre le vehicule, sinon il sera supprime.");
				}
				SaveToDisk();
			}
			
			// Grace period expiree : eject + suppression
			if (r.m_GraceEndUnix > 0 && now >= r.m_GraceEndUnix)
			{
				if (playerId > 0)
				{
					JobManager.GetInstance().NotifyPlayerChat(playerId,
						"[LOCATION] Temps largement depasse, vehicule supprime.");
				}
				EjectAndDelete(vehicle);
				m_Rentals.Remove(uid);
				SaveToDisk();
				continue;
			}
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Tente de rendre le vehicule. Retourne 0 OK, code erreur sinon.
	// 1 = pas de location active
	// 2 = vehicule trop loin de la zone de retour
	// 3 = joueur encore dans le vehicule
	//------------------------------------------------------------------------------------------------
	int TryReturnVehicle(int playerId, string uid)
	{
		JobVehicleRental r = m_Rentals.Get(uid);
		if (!r)
			return 1;
		RplComponent vehRpl = RplComponent.Cast(Replication.FindItem(r.m_VehicleRplId));
		IEntity vehicle = null;
		if (vehRpl)
			vehicle = vehRpl.GetEntity();
		if (!vehicle)
		{
			m_Rentals.Remove(uid);
			SaveToDisk();
			return 1;
		}
		
		// Verifie distance vehicule a la zone de retour
		vector vehiclePos = vehicle.GetOrigin();
		vector returnPos = Vector(RETURN_X, RETURN_Y, RETURN_Z);
		float dist = vector.Distance(vehiclePos, returnPos);
		if (dist > RETURN_RADIUS)
			return 2;
		
		// Verifie que le joueur n'est plus DANS le vehicule
		PlayerManager pm = GetGame().GetPlayerManager();
		if (pm)
		{
			PlayerController pc = pm.GetPlayerController(playerId);
			if (pc)
			{
				IEntity character = pc.GetControlledEntity();
				if (character)
				{
					// Pattern Reforger : CompartmentAccessComponent du character + GetCompartment()
					CompartmentAccessComponent compAccess = CompartmentAccessComponent.Cast(
						character.FindComponent(CompartmentAccessComponent));
					if (compAccess)
					{
						BaseCompartmentSlot slot = compAccess.GetCompartment();
						if (slot)
						{
							IEntity vehFromSlot = slot.GetOwner();
							if (vehFromSlot == vehicle)
								return 3;  // joueur encore dedans
						}
					}
				}
			}
		}
		
		// Tout OK : on supprime le vehicule et la location
		SCR_EntityHelper.DeleteEntityAndChildren(vehicle);
		m_Rentals.Remove(uid);
		SaveToDisk();
		
		JobManager.GetInstance().NotifyPlayerChat(playerId,
			"[LOCATION] Vehicule rendu ! Merci d'avoir utilise notre service.");
		return 0;
	}
	
	//------------------------------------------------------------------------------------------------
	// Ejecte le joueur du vehicule (si dedans) puis supprime le vehicule
	//------------------------------------------------------------------------------------------------
	void EjectAndDelete(IEntity vehicle)
	{
		if (!vehicle)
			return;
		// Recupere les passagers via SCR_CompartmentAccessComponent
		// Approche simple : on supprime juste, le moteur ejectera les passagers
		SCR_EntityHelper.DeleteEntityAndChildren(vehicle);
	}
	
	//------------------------------------------------------------------------------------------------
	int ResolvePlayerIdFromUID(string uid)
	{
		PlayerManager pm = GetGame().GetPlayerManager();
		if (!pm)
			return 0;
		array<int> all = new array<int>();
		pm.GetPlayers(all);
		foreach (int pid : all)
		{
			string pidUid = JobManager.GetInstance().GetPersistentUID(pid);
			if (pidUid == uid)
				return pid;
		}
		return 0;
	}
	
	//------------------------------------------------------------------------------------------------
	void NotifyOwnerChat(string uid, string msg)
	{
		int pid = ResolvePlayerIdFromUID(uid);
		if (pid > 0)
			JobManager.GetInstance().NotifyPlayerChat(pid, msg);
	}
	
	//------------------------------------------------------------------------------------------------
	void SaveToDisk()
	{
		SCR_JsonSaveContext ctx = new SCR_JsonSaveContext();
		ctx.WriteValue("count", m_Rentals.Count());
		int idx = 0;
		foreach (string uid, JobVehicleRental r : m_Rentals)
		{
			if (!r) continue;
			string prefix = "rental_" + idx.ToString() + "_";
			ctx.WriteValue(prefix + "uid", uid);
			ctx.WriteValue(prefix + "vehicleType", r.m_VehicleType);
			ctx.WriteValue(prefix + "vehicleRplId", r.m_VehicleRplId.ToString());
			ctx.WriteValue(prefix + "startUnix", r.m_StartUnix);
			ctx.WriteValue(prefix + "endUnix", r.m_EndUnix);
			ctx.WriteValue(prefix + "notif10", r.m_Notif10MinSent);
			ctx.WriteValue(prefix + "notif5", r.m_Notif5MinSent);
			ctx.WriteValue(prefix + "graceEnd", r.m_GraceEndUnix);
			// Position (pour retrouver le vehicule apres reboot via la persistance native du jeu)
			ctx.WriteValue(prefix + "hasPos", r.m_HasLastPos);
			ctx.WriteValue(prefix + "posX", r.m_LastPosX);
			ctx.WriteValue(prefix + "posY", r.m_LastPosY);
			ctx.WriteValue(prefix + "posZ", r.m_LastPosZ);
			idx++;
		}
		ctx.SaveToFile(SAVE_PATH);
	}
	
	//------------------------------------------------------------------------------------------------
	void LoadFromDisk()
	{
		SCR_JsonLoadContext ctx = new SCR_JsonLoadContext();
		if (!ctx.LoadFromFile(SAVE_PATH))
			return;
		int count = 0;
		ctx.ReadValue("count", count);
		for (int i = 0; i < count; i++)
		{
			string prefix = "rental_" + i.ToString() + "_";
			string uid = "";
			ctx.ReadValue(prefix + "uid", uid);
			if (uid == "")
				continue;
			
			JobVehicleRental r = new JobVehicleRental();
			r.m_PlayerUID = uid;
			ctx.ReadValue(prefix + "vehicleType", r.m_VehicleType);
			
			// Le RplId est volatile entre sessions, on l'ignore (sera retrouve via la position)
			string rplStr = "";
			ctx.ReadValue(prefix + "vehicleRplId", rplStr);
			r.m_VehicleRplId = RplId.Invalid();
			
			ctx.ReadValue(prefix + "startUnix", r.m_StartUnix);
			ctx.ReadValue(prefix + "endUnix", r.m_EndUnix);
			ctx.ReadValue(prefix + "notif10", r.m_Notif10MinSent);
			ctx.ReadValue(prefix + "notif5", r.m_Notif5MinSent);
			ctx.ReadValue(prefix + "graceEnd", r.m_GraceEndUnix);
			
			// Position derniere connue
			ctx.ReadValue(prefix + "hasPos", r.m_HasLastPos);
			ctx.ReadValue(prefix + "posX", r.m_LastPosX);
			ctx.ReadValue(prefix + "posY", r.m_LastPosY);
			ctx.ReadValue(prefix + "posZ", r.m_LastPosZ);
			
			m_Rentals.Set(uid, r);
		}
		Print(string.Format("[JobVehicleRentalManager] Charge %1 locations existantes - recherche des vehicules...", count),
			LogLevel.NORMAL);
		
		// Differe la recherche des vehicules pour laisser le temps au monde de recharger
		// les vehicules persistes (sinon ils ne sont pas encore dans GetWorld())
		GetGame().GetCallqueue().CallLater(RelinkVehiclesFromWorld, 8000, false);
	}
	
	//------------------------------------------------------------------------------------------------
	// Apres reboot : pour chaque location chargee, retrouve le vehicule physique dans le monde
	// a partir de sa derniere position sauvegardee. Le vehicule est conserve par la persistance
	// native d'Arma Reforger, on doit juste re-lier son RplId actuel a notre location.
	//------------------------------------------------------------------------------------------------
	void RelinkVehiclesFromWorld()
	{
		const float SEARCH_RADIUS = 30.0;  // rayon de recherche autour de la derniere position connue
		int relinked = 0;
		int notFound = 0;
		
		array<string> toCheck = new array<string>();
		foreach (string uid, JobVehicleRental r : m_Rentals)
		{
			if (r) toCheck.Insert(uid);
		}
		
		foreach (string uid : toCheck)
		{
			JobVehicleRental r = m_Rentals.Get(uid);
			if (!r)
				continue;
			if (!r.m_HasLastPos)
			{
				notFound++;
				continue;
			}
			
			vector lastPos = Vector(r.m_LastPosX, r.m_LastPosY, r.m_LastPosZ);
			IEntity vehicle = FindVehicleNear(lastPos, SEARCH_RADIUS, r.m_VehicleType);
			
			if (vehicle)
			{
				RplComponent rpl = RplComponent.Cast(vehicle.FindComponent(RplComponent));
				if (rpl)
				{
					r.m_VehicleRplId = rpl.Id();
					relinked++;
					continue;
				}
			}
			
			notFound++;
		}
		
		Print(string.Format("[JobVehicleRentalManager] Relink: %1 vehicules retrouves, %2 manquants",
			relinked, notFound), LogLevel.NORMAL);
		
		// Sauve les nouveaux RplId (meme si non utilises directement, par coherence)
		SaveToDisk();
	}
	
	//------------------------------------------------------------------------------------------------
	// Recherche un vehicule du type donne dans un rayon autour d'une position
	// Utilise GetWorld().QueryEntitiesBySphere pour parcourir les entites proches
	//------------------------------------------------------------------------------------------------
	IEntity FindVehicleNear(vector pos, float radius, int vehicleType)
	{
		BaseWorld world = GetGame().GetWorld();
		if (!world)
			return null;
		
		ResourceName expectedPrefab = GetVehiclePrefab(vehicleType);
		if (expectedPrefab == "")
			return null;
		
		// On stocke le candidat trouve dans une variable de contexte
		m_SearchExpectedPrefab = expectedPrefab;
		m_SearchFoundEntity = null;
		m_SearchRefPos = pos;
		m_SearchBestDist = radius * radius;  // distance carre pour eviter sqrt
		
		world.QueryEntitiesBySphere(pos, radius, FilterFoundVehicleNear, null, EQueryEntitiesFlags.ALL);
		
		IEntity result = m_SearchFoundEntity;
		m_SearchFoundEntity = null;
		return result;
	}
	
	// Variables temporaires pour la recherche (utilisees par le callback de QueryEntitiesBySphere)
	ResourceName m_SearchExpectedPrefab;
	IEntity m_SearchFoundEntity;
	vector m_SearchRefPos;
	float m_SearchBestDist;
	
	//------------------------------------------------------------------------------------------------
	// Callback pour QueryEntitiesBySphere - filtre les entites pour trouver le vehicule
	//------------------------------------------------------------------------------------------------
	bool FilterFoundVehicleNear(IEntity ent)
	{
		if (!ent)
			return true;  // continue
		
		// On veut un vehicule (Vehicle est la classe de base des wheeled/tracked)
		Vehicle veh = Vehicle.Cast(ent);
		if (!veh)
			return true;
		
		// Verifie que c'est le bon prefab
		EntityPrefabData prefabData = ent.GetPrefabData();
		if (!prefabData)
			return true;
		ResourceName prefabName = prefabData.GetPrefabName();
		if (prefabName != m_SearchExpectedPrefab)
			return true;
		
		// Verifie distance par rapport a la position de reference
		vector entPos = ent.GetOrigin();
		float dx = entPos[0] - m_SearchRefPos[0];
		float dz = entPos[2] - m_SearchRefPos[2];
		float distSq = dx * dx + dz * dz;
		
		if (distSq < m_SearchBestDist)
		{
			m_SearchBestDist = distSq;
			m_SearchFoundEntity = ent;
		}
		
		return true;  // continue iteration
	}
}
