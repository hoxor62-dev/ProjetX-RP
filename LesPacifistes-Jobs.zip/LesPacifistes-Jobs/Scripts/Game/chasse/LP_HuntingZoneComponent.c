//------------------------------------------------------------------------------------------------
// LP_HuntingZoneComponent.c
// Component a placer sur une entite existante (arbre, panneau, poteau, etc.) pour marquer
// une zone de chasse. Quand le joueur local est dans un rayon de 200m, un HUD s affiche
// avec le texte "/!\ Attention Zone de chasse /!\" + le nombre de cerfs dans le rayon.
//
// CONFIGURATION WORKBENCH :
//   - Ajouter ce component sur n importe quelle entite du monde
//   - Aucun attribut a configurer (rayon 200m en dur)
//   - Aucun RplComponent requis (100% client-side, pas de reseau)
//
// FONCTIONNEMENT :
//   - Tick 5s client-side (CallLater recurrent)
//   - Recupere le joueur local + calcule distance a l entite hote
//   - Si dans le rayon : compte les cerfs via QueryEntitiesBySphere, affiche/update le HUD
//   - Si hors du rayon : notifie le HUD manager que cette zone est inactive
//------------------------------------------------------------------------------------------------

class LP_HuntingZoneComponentClass : ScriptComponentClass
{
}

class LP_HuntingZoneComponent : ScriptComponent
{
	// Constantes
	const float ZONE_RADIUS = 200.0;
	const float ZONE_RADIUS_SQ = 40000.0;    // 200 * 200 (evite sqrt)
	const int TICK_INTERVAL_MS = 5000;       // 5s
	static string DEER_PREFAB = "{69E4F1B000000010}Prefabs/Wildlife/Bull.et";
	
	IEntity m_Owner;
	bool m_ClientInited = false;
	
	// Variables temporaires pour QueryEntitiesBySphere (le callback ne prend pas de contexte)
	int m_TmpDeerCount = 0;
	
	//------------------------------------------------------------------------------------------------
	override void OnPostInit(IEntity owner)
	{
		super.OnPostInit(owner);
		m_Owner = owner;
		
		// Init cote client uniquement (le HUD est visuel)
		if (Replication.IsServer() && !Replication.IsClient())
		{
			// Serveur dedie pur : pas de HUD
			return;
		}
		
		// Delay 3s pour laisser le monde + player controller se stabiliser
		GetGame().GetCallqueue().CallLater(InitClientTick, 3000, false);
	}
	
	//------------------------------------------------------------------------------------------------
	void InitClientTick()
	{
		if (m_ClientInited) return;
		m_ClientInited = true;
		
		// Tick recurrent 5s
		GetGame().GetCallqueue().CallLater(TickZone, TICK_INTERVAL_MS, true);
		// Premier tick immediat
		TickZone();
	}
	
	//------------------------------------------------------------------------------------------------
	// Tick client-side toutes les 5s : check si joueur local dans rayon + compte cerfs
	//------------------------------------------------------------------------------------------------
	void TickZone()
	{
		if (!m_Owner) return;
		
		// Recupere entite du joueur local
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc)
		{
			LP_HuntingZoneHudManager.GetInstance().NotifyZoneInactive(this);
			return;
		}
		IEntity playerEntity = pc.GetControlledEntity();
		if (!playerEntity)
		{
			LP_HuntingZoneHudManager.GetInstance().NotifyZoneInactive(this);
			return;
		}
		
		// Check distance
		vector zonePos = m_Owner.GetOrigin();
		vector playerPos = playerEntity.GetOrigin();
		float distSq = vector.DistanceSq(playerPos, zonePos);
		
		if (distSq > ZONE_RADIUS_SQ)
		{
			// Hors zone : hide HUD (le manager decide si un autre zone reste active)
			LP_HuntingZoneHudManager.GetInstance().NotifyZoneInactive(this);
			return;
		}
		
		// Dans la zone : compte les cerfs
		int deerCount = CountDeerInZone(zonePos);
		LP_HuntingZoneHudManager.GetInstance().NotifyZoneActive(this, deerCount);
	}
	
	//------------------------------------------------------------------------------------------------
	// Compte les cerfs dans le rayon via QueryEntitiesBySphere
	//------------------------------------------------------------------------------------------------
	int CountDeerInZone(vector center)
	{
		BaseWorld world = GetGame().GetWorld();
		if (!world) return 0;
		
		m_TmpDeerCount = 0;
		world.QueryEntitiesBySphere(center, ZONE_RADIUS, FilterDeerCallback, null, EQueryEntitiesFlags.ALL);
		return m_TmpDeerCount;
	}
	
	//------------------------------------------------------------------------------------------------
	// Callback pour QueryEntitiesBySphere : filtre les entites Deer et incremente le compteur
	//------------------------------------------------------------------------------------------------
	bool FilterDeerCallback(IEntity ent)
	{
		if (!ent) return true;
		EntityPrefabData prefabData = ent.GetPrefabData();
		if (!prefabData) return true;
		if (prefabData.GetPrefabName() == DEER_PREFAB)
			m_TmpDeerCount = m_TmpDeerCount + 1;
		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	// Cleanup au destroy du component
	override void OnDelete(IEntity owner)
	{
		if (m_ClientInited)
			GetGame().GetCallqueue().Remove(TickZone);
		LP_HuntingZoneHudManager.GetInstance().NotifyZoneInactive(this);
		super.OnDelete(owner);
	}
}