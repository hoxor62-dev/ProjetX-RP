//------------------------------------------------------------------------------------------------
// LP_HuntingZoneHudManager.c
// Singleton client-side qui gere l affichage du HUD "Zone de chasse".
//
// Plusieurs LP_HuntingZoneComponent peuvent exister sur la map. Le manager :
//   - Tient un tracking des zones actives (dans lesquelles le joueur se trouve)
//   - Affiche le HUD des qu au moins une zone est active
//   - Update le compteur de cerfs si plusieurs zones actives : prend le max (peu probable)
//   - Cache le HUD quand aucune zone n est active
//------------------------------------------------------------------------------------------------

class LP_HuntingZoneHudManager
{
	static ref LP_HuntingZoneHudManager s_Instance;
	
	Widget m_Root;
	TextWidget m_DeerCountText;
	
	// Zones actives : cle = component, valeur = nombre de cerfs de cette zone
	ref map<LP_HuntingZoneComponent, int> m_ActiveZones = new map<LP_HuntingZoneComponent, int>();
	
	//------------------------------------------------------------------------------------------------
	static LP_HuntingZoneHudManager GetInstance()
	{
		if (!s_Instance) s_Instance = new LP_HuntingZoneHudManager();
		return s_Instance;
	}
	
	//------------------------------------------------------------------------------------------------
	// Appele par une zone quand le joueur entre / est deja dedans
	void NotifyZoneActive(LP_HuntingZoneComponent zone, int deerCount)
	{
		if (!zone) return;
		m_ActiveZones.Set(zone, deerCount);
		RefreshHud();
	}
	
	//------------------------------------------------------------------------------------------------
	// Appele par une zone quand le joueur sort / n est pas dedans / est delete
	void NotifyZoneInactive(LP_HuntingZoneComponent zone)
	{
		if (!zone) return;
		if (m_ActiveZones.Contains(zone))
			m_ActiveZones.Remove(zone);
		RefreshHud();
	}
	
	//------------------------------------------------------------------------------------------------
	// Show/Hide + update du HUD selon m_ActiveZones
	protected void RefreshHud()
	{
		int activeCount = m_ActiveZones.Count();
		
		if (activeCount == 0)
		{
			// Aucune zone active : hide HUD
			HideHud();
			return;
		}
		
		// Au moins une zone active : recupere le max de cerfs (au cas ou plusieurs zones)
		int maxDeer = 0;
		foreach (LP_HuntingZoneComponent z, int count : m_ActiveZones)
		{
			if (count > maxDeer) maxDeer = count;
		}
		
		ShowHud(maxDeer);
	}
	
	//------------------------------------------------------------------------------------------------
	protected void ShowHud(int deerCount)
	{
		if (!m_Root)
		{
			WorkspaceWidget ws = GetGame().GetWorkspace();
			if (!ws) return;
			m_Root = ws.CreateWidgets("UI/layouts/LP_HuntingZoneHud.layout");
			if (!m_Root) return;
			m_DeerCountText = TextWidget.Cast(m_Root.FindAnyWidget("DeerCountText"));
		}
		
		if (m_DeerCountText)
		{
			string label = "Taureau detecte : ";
			if (deerCount > 1) label = "Taureau detectes : ";
			m_DeerCountText.SetText(label + deerCount.ToString());
		}
	}
	
	//------------------------------------------------------------------------------------------------
	protected void HideHud()
	{
		if (m_Root)
		{
			m_Root.RemoveFromHierarchy();
			m_Root = null;
			m_DeerCountText = null;
		}
	}
}
