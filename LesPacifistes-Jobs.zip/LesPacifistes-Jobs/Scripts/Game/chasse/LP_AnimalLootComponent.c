//------------------------------------------------------------------------------------------------
// LP_AnimalLootComponent.c
// Composant a placer sur les prefabs d animaux pour spawn du loot a leur mort.
// Detecte la mort de l entite (EDamageState.DESTROYED) et spawn 3-5 items d un prefab
// donne en cercle autour du cadavre, puis supprime le cadavre.
//
// CONFIGURATION WORKBENCH :
//   - Ouvrir le prefab de l animal (ex : Bull.et, E_Chicken.et, E_Cow.et)
//   - Add Component -> LP_AnimalLootComponent
//   - Aucun attribut a configurer : la table de loot par prefab est en dur dans le code
//     (via LookupLootPrefab a partir du GetPrefabName du owner)
//
// TABLE DE LOOT :
//   Bull      ({69E4F1B000000010}Prefabs/Wildlife/Bull.et)              -> MeatLeg_01
//   E_Chicken ({69E4F17000000011}Prefabs/Wildlife/Editable/E_Chicken.et) -> poulet.et
//   E_Cow     ({69E4F1C000000011}Prefabs/Wildlife/Editable/E_Cow.et)     -> MeatLeg_01
//
// Pour ajouter un nouvel animal : editer la methode LookupLootPrefab plus bas et ajouter
// une correspondance prefab source -> prefab loot.
//
// FONCTIONNEMENT :
//   - Server-side uniquement (Replication.IsServer)
//   - OnPostInit : delay 1s pour laisser DamageManager s initialiser, puis tick 2s
//   - Quand DamageState passe a DESTROYED : lookup du loot en fonction du prefab owner,
//     spawn 3-5 items en cercle rayon 1.5m, puis DeleteEntityAndChildren du cadavre
//   - Flag m_LootSpawned pour ne pas re-looter
//------------------------------------------------------------------------------------------------

class LP_AnimalLootComponentClass : ScriptComponentClass
{
}

class LP_AnimalLootComponent : ScriptComponent
{
	// Prefabs animaux (sources)
	static string BULL_PREFAB      = "{69E4F1B000000010}Prefabs/Wildlife/Bull.et";
	static string E_CHICKEN_PREFAB = "{69E4F17000000011}Prefabs/Wildlife/Editable/E_Chicken.et";
	static string E_COW_PREFAB     = "{69E4F1C000000011}Prefabs/Wildlife/Editable/E_Cow.et";
	
	// Prefabs loot (cibles)
	static string MEAT_PREFAB     = "{3610E30E5946AD2B}Prefabs/Items/Food/MeatLeg_01.et";
	static string CHICKEN_LOOT    = "{D8AAF1F088605E7E}Prefabs/Weapons/Grenades/poulet.et";
	
	// Configuration loot
	const int LOOT_MIN = 3;
	const int LOOT_MAX = 5;
	const float LOOT_CIRCLE_RADIUS = 1.5;
	
	// Tick pour detecter la mort (polling leger, event OnDamageStateChanged pas expose facilement)
	const int DEATH_CHECK_INTERVAL_MS = 2000;
	
	IEntity m_Owner;
	DamageManagerComponent m_DmgManager;
	string m_LootPrefab = "";  // prefab a spawner en loot pour ce owner (resolu dans InitDeathCheck)
	bool m_LootSpawned = false;
	bool m_TickerStarted = false;
	
	//------------------------------------------------------------------------------------------------
	override void OnPostInit(IEntity owner)
	{
		super.OnPostInit(owner);
		m_Owner = owner;
		
		if (!Replication.IsServer())
			return;
		
		// Delay 1s pour laisser DamageManager s initialiser
		GetGame().GetCallqueue().CallLater(InitDeathCheck, 1000, false);
	}
	
	//------------------------------------------------------------------------------------------------
	void InitDeathCheck()
	{
		if (m_TickerStarted || !m_Owner)
			return;
		
		m_DmgManager = DamageManagerComponent.Cast(m_Owner.FindComponent(DamageManagerComponent));
		if (!m_DmgManager)
		{
			Print(string.Format("[LP_AnimalLoot] Aucun DamageManagerComponent sur %1",
				m_Owner.GetID().ToString()), LogLevel.WARNING);
			return;
		}
		
		// Resout le prefab de loot en fonction du prefab de l animal
		EntityPrefabData pd = m_Owner.GetPrefabData();
		if (!pd)
		{
			Print("[LP_AnimalLoot] Owner sans EntityPrefabData - loot desactive", LogLevel.WARNING);
			return;
		}
		string ownerPrefab = pd.GetPrefabName();
		m_LootPrefab = LookupLootPrefab(ownerPrefab);
		
		if (m_LootPrefab == "")
		{
			Print(string.Format("[LP_AnimalLoot] Aucun loot configure pour prefab %1 - composant inactif",
				ownerPrefab), LogLevel.WARNING);
			return;
		}
		
		m_TickerStarted = true;
		GetGame().GetCallqueue().CallLater(TickCheckDeath, DEATH_CHECK_INTERVAL_MS, true);
	}
	
	//------------------------------------------------------------------------------------------------
	// Table de correspondance prefab source -> prefab loot.
	// Retourne "" si aucun loot n est configure pour ce prefab.
	// Pour ajouter un nouvel animal : ajouter une clause ici.
	//------------------------------------------------------------------------------------------------
	protected string LookupLootPrefab(string sourcePrefab)
	{
		if (sourcePrefab == BULL_PREFAB)      return MEAT_PREFAB;
		if (sourcePrefab == E_CHICKEN_PREFAB) return CHICKEN_LOOT;
		if (sourcePrefab == E_COW_PREFAB)     return MEAT_PREFAB;
		return "";
	}
	
	//------------------------------------------------------------------------------------------------
	// Tick 2s : verifie si l animal est mort (DESTROYED) et declenche le loot une seule fois
	//------------------------------------------------------------------------------------------------
	void TickCheckDeath()
	{
		if (m_LootSpawned || !m_Owner || !m_DmgManager)
		{
			GetGame().GetCallqueue().Remove(TickCheckDeath);
			return;
		}
		
		EDamageState state = m_DmgManager.GetState();
		if (state == EDamageState.DESTROYED)
		{
			m_LootSpawned = true;
			GetGame().GetCallqueue().Remove(TickCheckDeath);
			SpawnLootAndCleanup();
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Spawn 3-5 items en cercle autour du cadavre + supprime le cadavre
	//------------------------------------------------------------------------------------------------
	void SpawnLootAndCleanup()
	{
		if (!m_Owner || m_LootPrefab == "") return;
		
		vector centerPos = m_Owner.GetOrigin();
		int lootCount = Math.RandomInt(LOOT_MIN, LOOT_MAX + 1);
		
		Resource res = Resource.Load(m_LootPrefab);
		if (!res || !res.IsValid())
		{
			Print(string.Format("[LP_AnimalLoot] Resource.Load echec pour %1", m_LootPrefab),
				LogLevel.WARNING);
			return;
		}
		
		int spawned = 0;
		for (int i = 0; i < lootCount; i++)
		{
			float angle = (i * 360.0 / lootCount) * Math.DEG2RAD;
			float offsetX = Math.Cos(angle) * LOOT_CIRCLE_RADIUS;
			float offsetZ = Math.Sin(angle) * LOOT_CIRCLE_RADIUS;
			vector spawnPos = centerPos + Vector(offsetX, 0.2, offsetZ);
			
			EntitySpawnParams p = new EntitySpawnParams();
			p.TransformMode = ETransformMode.WORLD;
			Math3D.MatrixIdentity4(p.Transform);
			p.Transform[3] = spawnPos;
			
			IEntity item = GetGame().SpawnEntityPrefab(res, GetGame().GetWorld(), p);
			if (item)
				spawned = spawned + 1;
		}
		
		Print(string.Format("[LP_AnimalLoot] Animal tue - %1 loot(s) spawne(s) (prefab: %2)",
			spawned.ToString(), m_LootPrefab), LogLevel.NORMAL);
		
		// Delete du cadavre apres un court delai (laisse les items se stabiliser physiquement)
		GetGame().GetCallqueue().CallLater(DeleteAnimalCorpse, 500, false);
	}
	
	//------------------------------------------------------------------------------------------------
	void DeleteAnimalCorpse()
	{
		if (!m_Owner) return;
		SCR_EntityHelper.DeleteEntityAndChildren(m_Owner);
	}
	
	//------------------------------------------------------------------------------------------------
	// Cleanup au destroy du composant
	override void OnDelete(IEntity owner)
	{
		if (m_TickerStarted)
			GetGame().GetCallqueue().Remove(TickCheckDeath);
		super.OnDelete(owner);
	}
}
