//------------------------------------------------------------------------------------------------
// JobRobPlayerAction.c
// Action "F - Voler la personne"
// VISIBLE UNIQUEMENT si la victime est INCONSCIENTE (via SCR_CharacterControllerComponent.IsUnconscious)
// Cooldown 30min par couple voleur->victime (server-side)
//------------------------------------------------------------------------------------------------

class JobRobPlayerAction : ScriptedUserAction
{
	const float MAX_DISTANCE = 2.5;
	
	//------------------------------------------------------------------------------------------------
	override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
	{
		if (!pOwnerEntity || !pUserEntity)
			return;
		
		PlayerController localPC = GetGame().GetPlayerController();
		if (!localPC)
			return;
		IEntity localEntity = localPC.GetControlledEntity();
		if (localEntity != pUserEntity)
			return;
		
		// pOwnerEntity = joueur vole (victime)
		int victimPlayerId = GetGame().GetPlayerManager().GetPlayerIdFromControlledEntity(pOwnerEntity);
		if (victimPlayerId <= 0)
			return;
		
		JobPlayerComponent jpc = JobPlayerComponent.Cast(localPC.FindComponent(JobPlayerComponent));
		if (jpc)
			jpc.ClientAskRobPlayer(victimPlayerId);
	}
	
	//------------------------------------------------------------------------------------------------
	// Helper : verifie si la victime est INCONSCIENTE
	// API officielle : SCR_CharacterControllerComponent.IsUnconscious() (pas GetIsUnconscious)
	// Considere aussi l animation (wake-up animation en cours = toujours inconscient)
	//------------------------------------------------------------------------------------------------
	protected bool IsVictimUnconscious(IEntity victim)
	{
		if (!victim)
			return false;
		
		SCR_CharacterControllerComponent ccc = SCR_CharacterControllerComponent.Cast(
			victim.FindComponent(SCR_CharacterControllerComponent));
		if (!ccc)
			return false;
		
		return ccc.IsUnconscious();
	}
	
	//------------------------------------------------------------------------------------------------
	// Visible UNIQUEMENT si la victime est inconsciente (sauf sur soi-meme)
	//------------------------------------------------------------------------------------------------
	override bool CanBeShownScript(IEntity user)
	{
		if (!user)
			return false;
		
		IEntity owner = GetOwner();
		if (!owner || owner == user)
			return false;
		
		// Ne montre l action que si la victime est inconsciente
		return IsVictimUnconscious(owner);
	}
	
	//------------------------------------------------------------------------------------------------
	// Executable uniquement si toujours inconsciente + a portee
	//------------------------------------------------------------------------------------------------
	override bool CanBePerformedScript(IEntity user)
	{
		if (!user)
			return false;
		
		IEntity owner = GetOwner();
		if (!owner || owner == user)
			return false;
		
		// Double check : la victime doit toujours etre inconsciente
		if (!IsVictimUnconscious(owner))
			return false;
		
		float dist = vector.Distance(user.GetOrigin(), owner.GetOrigin());
		return dist <= MAX_DISTANCE;
	}
	
	//------------------------------------------------------------------------------------------------
	override bool GetActionNameScript(out string outName)
	{
		outName = "Voler la personne";
		return true;
	}
}
