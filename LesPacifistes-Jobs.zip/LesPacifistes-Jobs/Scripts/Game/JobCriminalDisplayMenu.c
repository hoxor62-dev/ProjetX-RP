//------------------------------------------------------------------------------------------------
// JobCriminalDisplayMenu.c
// Menu d'affichage du casier judiciaire.
// Le menu se contente de demander les infos au serveur qui les envoie via chat notification.
// Ceci evite de compliquer avec de la replication dynamique pour peu d'info.
//------------------------------------------------------------------------------------------------

class JobCriminalDisplayMenu : ChimeraMenuBase
{
	Widget m_RootWidget;
	TextWidget m_InfoText;
	int m_TargetPlayerId;
	string m_TargetName;
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuOpen()
	{
		super.OnMenuOpen();
		m_RootWidget = GetRootWidget();
		if (!m_RootWidget)
			return;
		
		m_InfoText = TextWidget.Cast(m_RootWidget.FindAnyWidget("InfoText"));
		
		ButtonWidget close = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("CloseButton"));
		if (close)
		{
			CriminalDisplayClickHandler h = new CriminalDisplayClickHandler();
			h.m_Menu = this;
			close.AddHandler(h);
			JobFocusHandler.Attach(close);
			GetGame().GetWorkspace().SetFocusedWidget(close);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuUpdate(float tDelta)
	{
		super.OnMenuUpdate(tDelta);
		if (GetGame().GetInputManager().GetActionValue("MenuBack") > 0.5)
		{
			CloseMenuInternal();
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void Initialize(int targetPlayerId, string targetName)
	{
		m_TargetPlayerId = targetPlayerId;
		m_TargetName = targetName;
		
		if (m_InfoText)
			m_InfoText.SetText(string.Format("Recherche du casier de %1...\n(resultat dans le chat)", targetName));
		
		// Demande au serveur
		PlayerController pc = GetGame().GetPlayerController();
		if (pc)
		{
			JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
			if (jpc)
				jpc.ClientAskCriminalRecord(targetPlayerId);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void CloseMenuInternal()
	{
		GetGame().GetMenuManager().CloseMenu(this);
	}
}

class CriminalDisplayClickHandler : ScriptedWidgetEventHandler
{
	JobCriminalDisplayMenu m_Menu;
	
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu)
			m_Menu.CloseMenuInternal();
		return true;
	}
}
