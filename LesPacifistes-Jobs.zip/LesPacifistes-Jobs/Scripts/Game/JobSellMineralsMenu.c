//------------------------------------------------------------------------------------------------
// JobSellMineralsMenu.c
// Menu de vente de minerais transformes.
//
// Selon le type configure dans le PNJ :
//  - Type 1 (ROCK)     : un seul bouton "Tout vendre"
//  - Type 2 (CANNABIS) : un seul bouton "Tout vendre"
//  - Type 3 (COCAINE)  : un seul bouton "Tout vendre"
//  - Type 4 (DROGUES)  : 2 boutons - "Vendre cannabis" et "Vendre cocaine"
//------------------------------------------------------------------------------------------------

class JobSellMineralsMenu : ChimeraMenuBase
{
	// Singleton runtime : instance actuellement ouverte (null si ferme)
	static JobSellMineralsMenu s_Instance;
	static JobSellMineralsMenu GetOpenMenu() { return s_Instance; }
	
	Widget m_RootWidget;
	TextWidget m_TitleText;
	TextWidget m_StockText;
	TextWidget m_PriceText;
	TextWidget m_TotalText;
	ButtonWidget m_SellAllButton;
	ButtonWidget m_SellAlt2Button;
	TextWidget m_SellAlt2Text;
	ButtonWidget m_CloseButton;
	
	int m_BuyerType;            // EMineralType ou 100 = drogues, 101 = agriculteur
	int m_PrimaryStock;         // stock du minerai principal
	int m_PrimaryPrice;         // prix unitaire principal
	EMineralType m_PrimaryType; // type principal
	int m_SecondaryStock;       // stock secondaire
	int m_SecondaryPrice;
	EMineralType m_SecondaryType;
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuOpen()
	{
		super.OnMenuOpen();
		s_Instance = this;
		m_RootWidget = GetRootWidget();
		if (!m_RootWidget)
			return;
		
		m_TitleText = TextWidget.Cast(m_RootWidget.FindAnyWidget("TitleText"));
		m_StockText = TextWidget.Cast(m_RootWidget.FindAnyWidget("StockText"));
		m_PriceText = TextWidget.Cast(m_RootWidget.FindAnyWidget("PriceText"));
		m_TotalText = TextWidget.Cast(m_RootWidget.FindAnyWidget("TotalText"));
		m_SellAllButton = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("SellAllButton"));
		m_SellAlt2Button = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("SellAlt2Button"));
		m_SellAlt2Text = TextWidget.Cast(m_RootWidget.FindAnyWidget("SellAlt2Text"));
		m_CloseButton = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("CloseButton"));
		
		AttachButton(m_SellAllButton, "sell_primary");
		AttachButton(m_SellAlt2Button, "sell_secondary");
		AttachButton(m_CloseButton, "close");
		
		if (m_SellAllButton)
			GetGame().GetWorkspace().SetFocusedWidget(m_SellAllButton);
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuClose()
	{
		s_Instance = null;
		super.OnMenuClose();
	}
	
	//------------------------------------------------------------------------------------------------
	void AttachButton(ButtonWidget btn, string action)
	{
		if (!btn)
			return;
		SellMenuClickHandler h = new SellMenuClickHandler();
		h.m_Menu = this;
		h.m_Action = action;
		btn.AddHandler(h);
		JobFocusHandler.Attach(btn);
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuUpdate(float tDelta)
	{
		super.OnMenuUpdate(tDelta);
		if (GetGame().GetInputManager().GetActionValue("MenuBack") > 0.5)
		{
			CloseMenuInternal();
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void Initialize(int buyerType)
	{
		m_BuyerType = buyerType;
		
		// Cas special : "toutes drogues" (cannabis + cocaine) = valeur 100
		if (buyerType == 100)
		{
			m_PrimaryType = EMineralType.CANNABIS;
			m_SecondaryType = EMineralType.COCAINE;
			m_PrimaryPrice = JobMiningData.GetSellPrice(m_PrimaryType);
			m_SecondaryPrice = JobMiningData.GetSellPrice(m_SecondaryType);
		}
		// Cas special : "agriculteur" (jus de pomme + farine) = valeur 101
		else if (buyerType == 101)
		{
			m_PrimaryType = EMineralType.APPLE;
			m_SecondaryType = EMineralType.WHEAT;
			m_PrimaryPrice = JobMiningData.GetSellPrice(m_PrimaryType);
			m_SecondaryPrice = JobMiningData.GetSellPrice(m_SecondaryType);
		}
		else
		{
			m_PrimaryType = buyerType;
			m_SecondaryType = EMineralType.NONE;
			m_PrimaryPrice = JobMiningData.GetSellPrice(m_PrimaryType);
			m_SecondaryPrice = 0;
		}
		
		RefreshUI();
	}
	
	//------------------------------------------------------------------------------------------------
	void RefreshUI()
	{
		// Compte les items dans l inventaire local
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc)
			return;
		IEntity character = pc.GetControlledEntity();
		if (!character)
			return;
		
		ResourceName primaryPrefab = JobMiningData.GetItemPrefab(m_PrimaryType, EMineralState.PROCESSED);
		m_PrimaryStock = JobMiningManager.CountItemsInInventory(character, primaryPrefab);
		
		if (m_BuyerType == 100 || m_BuyerType == 101)
		{
			ResourceName secondaryPrefab = JobMiningData.GetItemPrefab(m_SecondaryType, EMineralState.PROCESSED);
			m_SecondaryStock = JobMiningManager.CountItemsInInventory(character, secondaryPrefab);
		}
		else
		{
			m_SecondaryStock = 0;
		}
		
		// Met a jour les textes
		if (m_TitleText)
		{
			if (m_BuyerType == 100)
				m_TitleText.SetText("Vente de drogues");
			else if (m_BuyerType == 101)
				m_TitleText.SetText("Vente Agriculteur (Jus + Farine)");
			else
				m_TitleText.SetText("Vente de " + JobMiningData.GetMineralLabel(m_PrimaryType, EMineralState.PROCESSED));
		}
		
		// Calcule les prix effectifs en appliquant le cours dynamique
		EMarketItem primaryMarket = JobMarketManager.FromMineralType(m_PrimaryType);
		int primaryEffectivePrice = m_PrimaryPrice;
		int primaryCours = 0;
		if (primaryMarket != EMarketItem.NONE)
		{
			primaryCours = JobMarketManager.GetInstance().GetCours(primaryMarket);
			primaryEffectivePrice = JobMarketManager.GetInstance().GetEffectivePrice(primaryMarket, m_PrimaryPrice);
		}
		
		EMarketItem secondaryMarket = EMarketItem.NONE;
		int secondaryEffectivePrice = m_SecondaryPrice;
		int secondaryCours = 0;
		if (m_BuyerType == 100 || m_BuyerType == 101)
		{
			secondaryMarket = JobMarketManager.FromMineralType(m_SecondaryType);
			if (secondaryMarket != EMarketItem.NONE)
			{
				secondaryCours = JobMarketManager.GetInstance().GetCours(secondaryMarket);
				secondaryEffectivePrice = JobMarketManager.GetInstance().GetEffectivePrice(secondaryMarket, m_SecondaryPrice);
			}
		}
		
		if (m_BuyerType == 100 || m_BuyerType == 101)
		{
			// Labels dynamiques selon le type de buyer
			string primaryLabel = JobMiningData.GetMineralLabel(m_PrimaryType, EMineralState.PROCESSED);
			string secondaryLabel = JobMiningData.GetMineralLabel(m_SecondaryType, EMineralState.PROCESSED);
			
			// Affichage des 2 stocks
			if (m_StockText)
				m_StockText.SetText(string.Format("%1 : %2 unites | %3 : %4 unites",
					primaryLabel, m_PrimaryStock, secondaryLabel, m_SecondaryStock));
			if (m_PriceText)
				m_PriceText.SetText(string.Format("Prix : %1c (%2 %3) | %4c (%5 %6)",
					primaryEffectivePrice, primaryLabel, FormatCours(primaryCours),
					secondaryEffectivePrice, secondaryLabel, FormatCours(secondaryCours)));
			
			int totalPrimary = m_PrimaryStock * primaryEffectivePrice;
			int totalSecondary = m_SecondaryStock * secondaryEffectivePrice;
			if (m_TotalText)
				m_TotalText.SetText(string.Format("Total %1 : %2c | Total %3 : %4c",
					primaryLabel, totalPrimary, secondaryLabel, totalSecondary));
			
			// Boutons : un par type
			if (m_SellAllButton)
			{
				Widget c = m_SellAllButton.GetChildren();
				while (c)
				{
					TextWidget tw = TextWidget.Cast(c);
					if (tw)
					{
						tw.SetText(string.Format("Vendre %1 (%2c)", primaryLabel, totalPrimary));
						break;
					}
					c = c.GetSibling();
				}
				m_SellAllButton.SetEnabled(m_PrimaryStock > 0);
			}
			
			if (m_SellAlt2Button)
			{
				m_SellAlt2Button.SetVisible(true);
				if (m_SellAlt2Text)
					m_SellAlt2Text.SetText(string.Format("Vendre %1 (%2c)", secondaryLabel, totalSecondary));
				m_SellAlt2Button.SetEnabled(m_SecondaryStock > 0);
			}
		}
		else
		{
			// Type unique : un seul bouton
			string label = JobMiningData.GetMineralLabel(m_PrimaryType, EMineralState.PROCESSED);
			
			if (m_StockText)
				m_StockText.SetText(string.Format("Stock : %1 unites", m_PrimaryStock));
			if (m_PriceText)
				m_PriceText.SetText(string.Format("Prix unitaire : %1 capsules %2",
					primaryEffectivePrice, FormatCours(primaryCours)));
			
			int total = m_PrimaryStock * primaryEffectivePrice;
			if (m_TotalText)
				m_TotalText.SetText(string.Format("Total : %1 capsules", total));
			
			if (m_SellAllButton)
			{
				Widget c = m_SellAllButton.GetChildren();
				while (c)
				{
					TextWidget tw = TextWidget.Cast(c);
					if (tw)
					{
						tw.SetText(string.Format("Tout vendre (%1c)", total));
						break;
					}
					c = c.GetSibling();
				}
				m_SellAllButton.SetEnabled(m_PrimaryStock > 0);
			}
			
			// On masque le bouton secondaire pour les types simples
			if (m_SellAlt2Button)
				m_SellAlt2Button.SetVisible(false);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Formate le cours en %, avec signe et indicateur de tendance
	// "Cours -23%" / "Cours +15%" / "" si cours = 0
	//------------------------------------------------------------------------------------------------
	string FormatCours(int cours)
	{
		if (cours == 0)
			return "(cours stable)";
		if (cours > 0)
			return string.Format("(cours +%1%%)", cours);
		// Le moins est deja dans le nombre
		return string.Format("(cours %1%%)", cours);
	}
	
	//------------------------------------------------------------------------------------------------
	void OnButtonClicked(string action)
	{
		if (action == "close")
		{
			CloseMenuInternal();
			return;
		}
		
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc)
			return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc)
			return;
		
		EMineralType targetType = EMineralType.NONE;
		if (action == "sell_primary")
			targetType = m_PrimaryType;
		else if (action == "sell_secondary")
			targetType = m_SecondaryType;
		
		if (targetType == EMineralType.NONE)
			return;
		
		jpc.ClientAskSellMinerals(targetType);
		
		// On rafraichit apres un court delai pour laisser le serveur traiter
		GetGame().GetCallqueue().CallLater(RefreshAfterSell, 500, false);
	}
	
	void RefreshAfterSell()
	{
		RefreshUI();
	}
	
	//------------------------------------------------------------------------------------------------
	void CloseMenuInternal()
	{
		GetGame().GetMenuManager().CloseMenu(this);
	}
}

class SellMenuClickHandler : ScriptedWidgetEventHandler
{
	JobSellMineralsMenu m_Menu;
	string m_Action;
	
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu)
			m_Menu.OnButtonClicked(m_Action);
		return true;
	}
}
