//------------------------------------------------------------------------------------------------
// JobCompanyEmployeesMenu.c
// Menu de gestion des employes (vu par le patron uniquement).
//
// Pre-charge la liste via SetPendingData : UIDs + noms d affichage.
// Affiche chaque employe sur une ligne avec :
//   - Nom
//   - Bouton "Payer" -> ouvre JobCompanyPaySalaryMenu avec UID + nom pre-charge
//   - Bouton "Licencier" -> RPC directe (pas de confirmation)
// En bas : bouton "Recruter" -> demande la liste des joueurs connectes au serveur
//------------------------------------------------------------------------------------------------

class JobCompanyEmployeesMenu : ChimeraMenuBase
{
	const string ENTRY_LAYOUT_PATH = "{187B5171B3DFE39D}UI/layouts/JobCompanyEmployeeEntry.layout";
	
	Widget m_RootWidget;
	Widget m_ListContainer;
	TextWidget m_TitleText;
	TextWidget m_EmptyText;
	ButtonWidget m_BtnRecruit;
	ButtonWidget m_BtnBack;
	
	static ref array<string> s_PendingUIDs = new array<string>();
	static ref array<string> s_PendingNames = new array<string>();
	
	static JobCompanyEmployeesMenu s_Instance;
	
	//------------------------------------------------------------------------------------------------
	static void SetPendingData(array<string> uids, array<string> names)
	{
		s_PendingUIDs.Clear();
		s_PendingNames.Clear();
		foreach (string u : uids)
			s_PendingUIDs.Insert(u);
		foreach (string n : names)
			s_PendingNames.Insert(n);
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuOpen()
	{
		super.OnMenuOpen();
		s_Instance = this;
		JobFocusHandler.ClearRegistry();
		
		m_RootWidget = GetRootWidget();
		if (!m_RootWidget) return;
		
		m_ListContainer = m_RootWidget.FindAnyWidget("ListContainer");
		m_TitleText = TextWidget.Cast(m_RootWidget.FindAnyWidget("TitleText"));
		m_EmptyText = TextWidget.Cast(m_RootWidget.FindAnyWidget("EmptyText"));
		m_BtnRecruit = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnRecruit"));
		m_BtnBack = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnBack"));
		
		if (m_TitleText)
			m_TitleText.SetText("Gestion des employes");
		
		BuildList();
		
		if (m_BtnRecruit)
		{
			EmployeesRecruitHandler rh = new EmployeesRecruitHandler();
			rh.m_Menu = this;
			m_BtnRecruit.AddHandler(rh);
			JobFocusHandler.Attach(m_BtnRecruit);
		}
		if (m_BtnBack)
		{
			EmployeesBackHandler bh = new EmployeesBackHandler();
			bh.m_Menu = this;
			m_BtnBack.AddHandler(bh);
			JobFocusHandler.Attach(m_BtnBack);
			GetGame().GetWorkspace().SetFocusedWidget(m_BtnBack);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuClose()
	{
		if (s_Instance == this)
			s_Instance = null;
		super.OnMenuClose();
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuUpdate(float tDelta)
	{
		super.OnMenuUpdate(tDelta);
		if (GetGame().GetInputManager().GetActionValue("MenuBack") > 0.5)
			CloseMenuInternal();
	}
	
	//------------------------------------------------------------------------------------------------
	void BuildList()
	{
		if (!m_ListContainer) return;
		
		// Reset
		Widget child = m_ListContainer.GetChildren();
		while (child)
		{
			Widget next = child.GetSibling();
			child.RemoveFromHierarchy();
			child = next;
		}
		
		if (s_PendingUIDs.Count() == 0)
		{
			if (m_EmptyText)
			{
				m_EmptyText.SetText("Aucun employe.");
				m_EmptyText.SetVisible(true);
			}
			return;
		}
		if (m_EmptyText)
			m_EmptyText.SetVisible(false);
		
		WorkspaceWidget ws = GetGame().GetWorkspace();
		for (int i = 0; i < s_PendingUIDs.Count(); i++)
		{
			string uid = s_PendingUIDs.Get(i);
			string name = s_PendingNames.Get(i);
			
			Widget entry = ws.CreateWidgets(ENTRY_LAYOUT_PATH, m_ListContainer);
			if (!entry) continue;
			
			TextWidget nameW = TextWidget.Cast(entry.FindAnyWidget("EmployeeName"));
			if (nameW)
				nameW.SetText(name);
			
			ButtonWidget btnPay = ButtonWidget.Cast(entry.FindAnyWidget("BtnPay"));
			if (btnPay)
			{
				EmployeesPayHandler ph = new EmployeesPayHandler();
				ph.m_Menu = this;
				ph.m_TargetUID = uid;
				ph.m_TargetName = name;
				btnPay.AddHandler(ph);
				JobFocusHandler.Attach(btnPay);
			}
			ButtonWidget btnFire = ButtonWidget.Cast(entry.FindAnyWidget("BtnFire"));
			if (btnFire)
			{
				EmployeesFireHandler fh = new EmployeesFireHandler();
				fh.m_Menu = this;
				fh.m_TargetUID = uid;
				btnFire.AddHandler(fh);
				JobFocusHandler.Attach(btnFire);
			}
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void OnPayClicked(string targetUID, string targetName)
	{
		JobCompanyPaySalaryMenu.SetPendingData(targetUID, targetName);
		MenuManager mm = GetGame().GetMenuManager();
		mm.CloseMenu(this);
		mm.OpenMenu(ChimeraMenuPreset.JobCompanyPaySalaryMenu);
	}
	
	void OnFireClicked(string targetUID)
	{
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		jpc.ClientAskFireEmployee(targetUID);
		// Le menu se ferme : le patron reviendra pour voir la liste mise a jour
		CloseMenuInternal();
	}
	
	void OnRecruitClicked()
	{
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		jpc.ClientAskOpenRecruitMenu();
		CloseMenuInternal();
	}
	
	void CloseMenuInternal()
	{
		GetGame().GetMenuManager().CloseMenu(this);
	}
	
	static JobCompanyEmployeesMenu GetOpenMenu() { return s_Instance; }
}

//------------------------------------------------------------------------------------------------
class EmployeesBackHandler : ScriptedWidgetEventHandler
{
	JobCompanyEmployeesMenu m_Menu;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.CloseMenuInternal();
		return true;
	}
}

//------------------------------------------------------------------------------------------------
class EmployeesRecruitHandler : ScriptedWidgetEventHandler
{
	JobCompanyEmployeesMenu m_Menu;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.OnRecruitClicked();
		return true;
	}
}

//------------------------------------------------------------------------------------------------
class EmployeesPayHandler : ScriptedWidgetEventHandler
{
	JobCompanyEmployeesMenu m_Menu;
	string m_TargetUID;
	string m_TargetName;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.OnPayClicked(m_TargetUID, m_TargetName);
		return true;
	}
}

//------------------------------------------------------------------------------------------------
class EmployeesFireHandler : ScriptedWidgetEventHandler
{
	JobCompanyEmployeesMenu m_Menu;
	string m_TargetUID;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.OnFireClicked(m_TargetUID);
		return true;
	}
}
