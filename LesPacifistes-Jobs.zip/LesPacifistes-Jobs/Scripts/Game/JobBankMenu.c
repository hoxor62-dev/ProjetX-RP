//------------------------------------------------------------------------------------------------
// JobBankMenu.c
// Menu banque : affiche le solde + permet de deposer ou retirer des capsules.
//
// Flow :
//   1. Ouverture -> ClientAskBankInfo pour recuperer solde + cash
//   2. Le joueur tape un montant dans un des 2 champs (depot ou retrait)
//   3. Clic "Deposer" ou "Retirer" -> RPC serveur
//   4. Le serveur push un nouveau BankInfo -> UI se met a jour
//
// Frais : 1% depot + 1% retrait (redirige vers cagnotte municipale)
//------------------------------------------------------------------------------------------------

class JobBankMenu : ChimeraMenuBase
{
	Widget m_RootWidget;
	TextWidget m_TitleText;
	TextWidget m_BalanceText;          // "Solde banque : X capsules"
	TextWidget m_CashText;             // "Cash : X capsules"
	TextWidget m_FeeInfoText;          // "Frais : 1% depot + 1% retrait"
	TextWidget m_RateText;             // "Taux : 0.1% par jour"
	TextWidget m_TotalInterestText;    // "Interets gagnes : X capsules"
	TextWidget m_DailyEstimateText;    // "Interets/jour a solde actuel : ~Y caps"
	EditBoxWidget m_DepositInput;
	EditBoxWidget m_WithdrawInput;
	ButtonWidget m_DepositButton;
	ButtonWidget m_WithdrawButton;
	ButtonWidget m_CloseButton;
	TextWidget m_DepositPreview;       // "-> Net credite : X (frais Y)"
	TextWidget m_WithdrawPreview;      // "-> Net recu : X (frais Y)"
	
	// Etat client
	int m_CurrentBalance = 0;
	int m_CurrentCash = 0;
	
	// Instance statique pour recevoir les RPCs push
	static JobBankMenu s_Instance;
	
	static JobBankMenu GetOpenMenu()
	{
		return s_Instance;
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuOpen()
	{
		super.OnMenuOpen();
		s_Instance = this;
		JobFocusHandler.ClearRegistry();
		
		m_RootWidget = GetRootWidget();
		if (!m_RootWidget)
			return;
		
		m_TitleText = TextWidget.Cast(m_RootWidget.FindAnyWidget("TitleText"));
		m_BalanceText = TextWidget.Cast(m_RootWidget.FindAnyWidget("BalanceText"));
		m_CashText = TextWidget.Cast(m_RootWidget.FindAnyWidget("CashText"));
		m_FeeInfoText = TextWidget.Cast(m_RootWidget.FindAnyWidget("FeeInfoText"));
		m_RateText = TextWidget.Cast(m_RootWidget.FindAnyWidget("RateText"));
		m_TotalInterestText = TextWidget.Cast(m_RootWidget.FindAnyWidget("TotalInterestText"));
		m_DailyEstimateText = TextWidget.Cast(m_RootWidget.FindAnyWidget("DailyEstimateText"));
		m_DepositInput = EditBoxWidget.Cast(m_RootWidget.FindAnyWidget("DepositInput"));
		m_WithdrawInput = EditBoxWidget.Cast(m_RootWidget.FindAnyWidget("WithdrawInput"));
		m_DepositButton = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("DepositButton"));
		m_WithdrawButton = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("WithdrawButton"));
		m_CloseButton = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("CloseButton"));
		m_DepositPreview = TextWidget.Cast(m_RootWidget.FindAnyWidget("DepositPreview"));
		m_WithdrawPreview = TextWidget.Cast(m_RootWidget.FindAnyWidget("WithdrawPreview"));
		
		AttachHandler(m_DepositButton, "deposit");
		AttachHandler(m_WithdrawButton, "withdraw");
		AttachHandler(m_CloseButton, "close");
		
		if (m_FeeInfoText)
			m_FeeInfoText.SetText("Frais bancaires : 1% depot + 1% retrait (versement mairie)");
		if (m_RateText)
			m_RateText.SetText("Taux : 1% par jour (interet horaire automatique)");
		if (m_TotalInterestText)
			m_TotalInterestText.SetText("Interets gagnes : chargement...");
		if (m_DailyEstimateText)
			m_DailyEstimateText.SetText("Interets/jour a solde actuel : ~0 caps");
		if (m_BalanceText)
			m_BalanceText.SetText("Solde banque : chargement...");
		if (m_CashText)
			m_CashText.SetText("Cash : chargement...");
		if (m_DepositPreview)
			m_DepositPreview.SetText("");
		if (m_WithdrawPreview)
			m_WithdrawPreview.SetText("");
		
		// Focus initial sur le champ depot
		if (m_DepositInput)
			GetGame().GetWorkspace().SetFocusedWidget(m_DepositInput);
		else if (m_CloseButton)
			GetGame().GetWorkspace().SetFocusedWidget(m_CloseButton);
		
		RequestRefresh();
		
		// Preview live des frais (recalcule chaque frame)
		GetGame().GetCallqueue().CallLater(TickPreview, 200, true);
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuUpdate(float tDelta)
	{
		super.OnMenuUpdate(tDelta);
		if (GetGame().GetInputManager().GetActionValue("MenuBack") > 0.5)
			CloseMenuInternal();
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuClose()
	{
		if (s_Instance == this)
			s_Instance = null;
		GetGame().GetCallqueue().Remove(TickPreview);
		super.OnMenuClose();
	}
	
	//------------------------------------------------------------------------------------------------
	void AttachHandler(ButtonWidget btn, string action)
	{
		if (!btn) return;
		BankMenuHandler h = new BankMenuHandler();
		h.m_Menu = this;
		h.m_Action = action;
		btn.AddHandler(h);
		JobFocusHandler.Attach(btn);
	}
	
	//------------------------------------------------------------------------------------------------
	// Demande au serveur le solde actuel + cash
	//------------------------------------------------------------------------------------------------
	void RequestRefresh()
	{
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		jpc.ClientAskBankInfo();
	}
	
	//------------------------------------------------------------------------------------------------
	// Push depuis le serveur.
	// balance : solde actuel du compte
	// cash : capsules en poche
	// totalInterest : total historique d interets recus (statistique cumulee)
	//------------------------------------------------------------------------------------------------
	void UpdateDisplay(int balance, int cash, int totalInterest)
	{
		m_CurrentBalance = balance;
		m_CurrentCash = cash;
		if (m_BalanceText)
			m_BalanceText.SetText(string.Format("Solde banque : %1 capsules", balance.ToString()));
		if (m_CashText)
			m_CashText.SetText(string.Format("Cash : %1 capsules", cash.ToString()));
		if (m_TotalInterestText)
			m_TotalInterestText.SetText(string.Format("Interets gagnes : %1 capsules",
				totalInterest.ToString()));
		if (m_DailyEstimateText)
		{
			// Estimation : 0.1% du solde par jour = balance / 1000
			int dailyEstimate = balance / 100;
			m_DailyEstimateText.SetText(string.Format("Interets/jour a solde actuel : ~%1 capsules",
				dailyEstimate.ToString()));
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Preview live : lit les champs et affiche les frais + net
	//------------------------------------------------------------------------------------------------
	void TickPreview()
	{
		if (!m_DepositInput || !m_WithdrawInput)
			return;
		
		// Preview depot
		string depStr = m_DepositInput.GetText();
		int depAmount = depStr.ToInt();
		if (m_DepositPreview)
		{
			if (depAmount <= 0)
				m_DepositPreview.SetText("");
			else
			{
				int fee = depAmount / 100;
				int net = depAmount - fee;
				m_DepositPreview.SetText(string.Format("-> Credit : %1 capsules (frais %2)",
					net.ToString(), fee.ToString()));
			}
		}
		
		// Preview retrait
		string wStr = m_WithdrawInput.GetText();
		int wAmount = wStr.ToInt();
		if (m_WithdrawPreview)
		{
			if (wAmount <= 0)
				m_WithdrawPreview.SetText("");
			else
			{
				int fee = wAmount / 100;
				int net = wAmount - fee;
				m_WithdrawPreview.SetText(string.Format("-> Recu : %1 capsules cash (frais %2)",
					net.ToString(), fee.ToString()));
			}
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void OnButtonClicked(string action)
	{
		if (action == "close")
		{
			CloseMenuInternal();
			return;
		}
		
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		
		if (action == "deposit")
		{
			if (!m_DepositInput) return;
			string amountStr = m_DepositInput.GetText();
			int amount = amountStr.ToInt();
			if (amount <= 0)
			{
				if (m_DepositPreview)
					m_DepositPreview.SetText("Montant invalide.");
				return;
			}
			jpc.ClientAskBankDeposit(amount);
			m_DepositInput.SetText("");
			// Le serveur va push un nouveau BankInfo
		}
		else if (action == "withdraw")
		{
			if (!m_WithdrawInput) return;
			string amountStr = m_WithdrawInput.GetText();
			int amount = amountStr.ToInt();
			if (amount <= 0)
			{
				if (m_WithdrawPreview)
					m_WithdrawPreview.SetText("Montant invalide.");
				return;
			}
			jpc.ClientAskBankWithdraw(amount);
			m_WithdrawInput.SetText("");
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void CloseMenuInternal()
	{
		GetGame().GetMenuManager().CloseMenu(this);
	}
}

//------------------------------------------------------------------------------------------------
class BankMenuHandler : ScriptedWidgetEventHandler
{
	JobBankMenu m_Menu;
	string m_Action;
	
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu)
			m_Menu.OnButtonClicked(m_Action);
		return true;
	}
}
