//------------------------------------------------------------------------------------------------
// LP_DoorAccessComponent.c
// Component a attacher (via Workbench) sur les portes que l on veut pouvoir vendre.
//
// STOCKAGE REPLIQUE (RplProp) pour permettre aux actions cote client de decider
// leur visibilite via CanBeShownScript :
//   - m_Locked : etat verrouille
//   - m_OwnerPlayerId : playerId (int, session-scoped) du proprietaire connecte,
//                       ou -1 si aucun proprio OU si le proprio n est pas connecte
//   - m_KnownPlayerIdsPacked : CSV des playerIds qui connaissent le code (permanent
//                              tant que dans la session ; le serveur met a jour au
//                              connect/disconnect ET au moment du achat/code entre)
//
// L association porte -> UID proprietaire (persistante) reste dans LP_DoorManager cote serveur.
// Ces RplProps ne servent qu a la visibilite client des actions.
//------------------------------------------------------------------------------------------------

class LP_DoorAccessComponentClass : ScriptComponentClass
{
}

class LP_DoorAccessComponent : ScriptComponent
{
	[RplProp()]
	bool m_Locked = false;
	
	[RplProp()]
	int m_OwnerPlayerId = -1; // -1 = personne ou proprio non connecte
	
	[RplProp()]
	string m_KnownPlayerIdsPacked = ""; // CSV : "5,12,42"
	
	[RplProp()]
	bool m_RaidInProgress = false;
	
	//------------------------------------------------------------------------------------------------
	bool IsLocked() { return m_Locked; }
	
	//------------------------------------------------------------------------------------------------
	bool IsRaidInProgress() { return m_RaidInProgress; }
	
	//------------------------------------------------------------------------------------------------
	// True si la porte est possedee (independant du fait que le proprio soit connecte ou non)
	// -> a completer avec un flag serveur, mais pour l affichage on utilise m_OwnerPlayerId > -1
	// OU m_KnownPlayerIdsPacked non vide, OU une base persistante lookup manager.
	// SIMPLIFIE : cote client, on considere la porte "vendue" si m_OwnerPlayerId > -1
	// (le serveur met -1 si proprio non connecte -> les actions restreintes disparaissent,
	// mais l action Entrer code reste visible via m_HasOwner qu on ajoute).
	//------------------------------------------------------------------------------------------------
	[RplProp()]
	bool m_HasOwner = false; // true si la porte a un proprio dans LP_DoorManager
	
	bool HasOwner() { return m_HasOwner; }
	
	//------------------------------------------------------------------------------------------------
	// True si le playerId donne est le proprio actuellement connecte
	bool IsOwnerPlayerId(int playerId)
	{
		return m_OwnerPlayerId > 0 && m_OwnerPlayerId == playerId;
	}
	
	//------------------------------------------------------------------------------------------------
	// True si le playerId donne connait le code (parse CSV cote client)
	bool KnowsCodePlayerId(int playerId)
	{
		if (m_KnownPlayerIdsPacked == "" || playerId <= 0) return false;
		string needle = playerId.ToString();
		string csv = m_KnownPlayerIdsPacked;
		int len = csv.Length();
		int start = 0;
		for (int i = 0; i <= len; i++)
		{
			if (i == len || csv.Substring(i, 1) == ",")
			{
				string chunk = csv.Substring(start, i - start);
				if (chunk == needle) return true;
				start = i + 1;
			}
		}
		return false;
	}
	
	//------------------------------------------------------------------------------------------------
	// True si le joueur peut lock/unlock (proprio OU code connu)
	bool CanUseDoorPlayerId(int playerId)
	{
		return IsOwnerPlayerId(playerId) || KnowsCodePlayerId(playerId);
	}
	
	//------------------------------------------------------------------------------------------------
	// SERVEUR uniquement
	void ServerSetLocked(bool locked)
	{
		if (!Replication.IsServer()) return;
		m_Locked = locked;
		Replication.BumpMe();
	}
	
	void ServerSetOwnerPlayerId(int playerId, bool hasOwner)
	{
		if (!Replication.IsServer()) return;
		m_OwnerPlayerId = playerId;
		m_HasOwner = hasOwner;
		Replication.BumpMe();
	}
	
	void ServerSetKnownPlayerIds(string csv)
	{
		if (!Replication.IsServer()) return;
		m_KnownPlayerIdsPacked = csv;
		Replication.BumpMe();
	}
	
	void ServerSetRaidInProgress(bool inProgress)
	{
		if (!Replication.IsServer()) return;
		m_RaidInProgress = inProgress;
		Replication.BumpMe();
	}
}
