//------------------------------------------------------------------------------------------------
// JobGarageTransferMenu.c
// Menu de transfert d un vehicule du garage virtuel a un autre joueur.
//
// Workflow :
//  1. Le joueur clique "Transfert" dans JobVirtualGarageMenu sur un vehicule.
//  2. JobVirtualGarageMenu pre-charge l index et le nom du vehicule via SetPendingXxx.
//  3. JobGarageTransferMenu s ouvre, demande au serveur la liste des joueurs connectes.
//  4. Le serveur repond -> SetPlayersList -> construction de la liste cliquable.
//  5. Clic sur un joueur -> popup confirmation.
//  6. Confirmer -> RPC ClientAskTransferVehicle + fermeture du menu.
//------------------------------------------------------------------------------------------------

class JobGarageTransferMenu : ChimeraMenuBase
{
	// Reutilise JobSmsEntry.layout (PlayerName + SelectButton) pour la liste joueurs
	const string ENTRY_LAYOUT_PATH = "{9D68BEB73DF970D8}UI/layouts/JobSmsEntry.layout";
	
	// Pagination : 10 joueurs par page (cf. pattern ATM)
	const int ITEMS_PER_PAGE = 10;
	const int PAGE_CHANGE_COOLDOWN_MS = 300;
	
	Widget m_RootWidget;
	Widget m_PlayersContainer;
	TextWidget m_TitleText;
	TextWidget m_EmptyText;
	ButtonWidget m_BtnClose;
	
	// Pagination widgets
	ButtonWidget m_PrevPageButton;
	ButtonWidget m_NextPageButton;
	TextWidget m_PageLabel;
	
	// Popup confirmation
	Widget m_ConfirmOverlay;
	TextWidget m_ConfirmText;
	ButtonWidget m_BtnConfirmYes;
	ButtonWidget m_BtnConfirmNo;
	
	// === DONNEES PRE-CHARGEES ===
	static int s_PendingGarageIndex = -1;
	static string s_PendingVehicleName = "";
	
	// Liste des joueurs (recue du serveur)
	ref array<string> m_PlayerUIDs = new array<string>();
	ref array<string> m_PlayerNames = new array<string>();
	
	// Etat pagination
	int m_CurrentPage = 0;
	int m_LastPageChangeTime = 0;
	
	// Selection en cours pour la confirmation
	string m_PendingTargetUID = "";
	string m_PendingTargetName = "";
	
	static JobGarageTransferMenu s_Instance;
	
	//------------------------------------------------------------------------------------------------
	static void SetPendingGarageIndex(int idx)
	{
		s_PendingGarageIndex = idx;
	}
	
	static void SetPendingVehicleName(string name)
	{
		s_PendingVehicleName = name;
	}
	
	static JobGarageTransferMenu GetOpenMenu()
	{
		return s_Instance;
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuOpen()
	{
		super.OnMenuOpen();
		s_Instance = this;
		JobFocusHandler.ClearRegistry();
		
		m_RootWidget = GetRootWidget();
		if (!m_RootWidget)
			return;
		
		m_PlayersContainer = m_RootWidget.FindAnyWidget("PlayersContainer");
		m_TitleText = TextWidget.Cast(m_RootWidget.FindAnyWidget("TitleText"));
		m_EmptyText = TextWidget.Cast(m_RootWidget.FindAnyWidget("EmptyText"));
		m_BtnClose = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnClose"));
		
		// Pagination widgets
		m_PrevPageButton = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("PrevPageButton"));
		m_NextPageButton = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("NextPageButton"));
		m_PageLabel = TextWidget.Cast(m_RootWidget.FindAnyWidget("PageLabel"));
		
		if (m_PrevPageButton)
		{
			TransferPrevPageHandler ph = new TransferPrevPageHandler();
			ph.m_Menu = this;
			m_PrevPageButton.AddHandler(ph);
			JobFocusHandler.Attach(m_PrevPageButton);
		}
		if (m_NextPageButton)
		{
			TransferNextPageHandler nh = new TransferNextPageHandler();
			nh.m_Menu = this;
			m_NextPageButton.AddHandler(nh);
			JobFocusHandler.Attach(m_NextPageButton);
		}
		
		m_ConfirmOverlay = m_RootWidget.FindAnyWidget("ConfirmOverlay");
		m_ConfirmText = TextWidget.Cast(m_RootWidget.FindAnyWidget("ConfirmText"));
		m_BtnConfirmYes = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnConfirmYes"));
		m_BtnConfirmNo = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnConfirmNo"));
		
		// Popup cache au demarrage
		if (m_ConfirmOverlay)
			m_ConfirmOverlay.SetVisible(false);
		
		if (m_TitleText)
			m_TitleText.SetText("Transfert : " + s_PendingVehicleName);
		
		if (m_EmptyText)
		{
			m_EmptyText.SetText("Recuperation des joueurs connectes...");
			m_EmptyText.SetVisible(true);
		}
		
		if (m_BtnClose)
		{
			TransferCloseHandler ch = new TransferCloseHandler();
			ch.m_Menu = this;
			m_BtnClose.AddHandler(ch);
			JobFocusHandler.Attach(m_BtnClose);
			GetGame().GetWorkspace().SetFocusedWidget(m_BtnClose);
		}
		if (m_BtnConfirmYes)
		{
			TransferConfirmYesHandler yh = new TransferConfirmYesHandler();
			yh.m_Menu = this;
			m_BtnConfirmYes.AddHandler(yh);
		}
		if (m_BtnConfirmNo)
		{
			TransferConfirmNoHandler nh = new TransferConfirmNoHandler();
			nh.m_Menu = this;
			m_BtnConfirmNo.AddHandler(nh);
		}
		
		// Demande la liste des joueurs au serveur
		PlayerController pc = GetGame().GetPlayerController();
		if (pc)
		{
			JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
			if (jpc)
				jpc.ClientAskConnectedPlayersList();
		}
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuClose()
	{
		if (s_Instance == this)
			s_Instance = null;
		super.OnMenuClose();
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuUpdate(float tDelta)
	{
		super.OnMenuUpdate(tDelta);
		if (GetGame().GetInputManager().GetActionValue("MenuBack") > 0.5)
		{
			// Si popup ouvert : ferme le popup d abord, sinon ferme le menu
			if (m_ConfirmOverlay && m_ConfirmOverlay.IsVisible())
				m_ConfirmOverlay.SetVisible(false);
			else
				CloseMenuInternal();
		}
		// Pagination manette : LB = page precedente, RB = page suivante (popup ferme uniquement)
		if (!m_ConfirmOverlay || !m_ConfirmOverlay.IsVisible())
		{
			if (GetGame().GetInputManager().GetActionValue("MenuTabLeft") > 0.5)
				OnPrevPageClicked();
			if (GetGame().GetInputManager().GetActionValue("MenuTabRight") > 0.5)
				OnNextPageClicked();
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Appele par RpcDo_ReceiveConnectedPlayers cote client a reception de la liste serveur.
	//------------------------------------------------------------------------------------------------
	void SetPlayersList(array<string> uids, array<string> names)
	{
		m_PlayerUIDs.Clear();
		m_PlayerNames.Clear();
		foreach (string u : uids)
			m_PlayerUIDs.Insert(u);
		foreach (string n : names)
			m_PlayerNames.Insert(n);
		
		m_CurrentPage = 0;
		BuildPlayersList();
	}
	
	//------------------------------------------------------------------------------------------------
	// Calcule le nombre total de pages (au moins 1)
	//------------------------------------------------------------------------------------------------
	int GetTotalPages()
	{
		int total = (m_PlayerUIDs.Count() + ITEMS_PER_PAGE - 1) / ITEMS_PER_PAGE;
		if (total < 1)
			total = 1;
		return total;
	}
	
	//------------------------------------------------------------------------------------------------
	void BuildPlayersList()
	{
		if (!m_PlayersContainer)
			return;
		
		// Reset focus registry (les widgets vont changer)
		JobFocusHandler.ClearRegistry();
		// Re-attache les widgets persistants
		if (m_BtnClose)
			JobFocusHandler.Attach(m_BtnClose);
		if (m_PrevPageButton)
			JobFocusHandler.Attach(m_PrevPageButton);
		if (m_NextPageButton)
			JobFocusHandler.Attach(m_NextPageButton);
		
		// Reset container
		Widget child = m_PlayersContainer.GetChildren();
		while (child)
		{
			Widget next = child.GetSibling();
			child.RemoveFromHierarchy();
			child = next;
		}
		
		int totalPages = GetTotalPages();
		// Clamp current page
		if (m_CurrentPage < 0)
			m_CurrentPage = 0;
		if (m_CurrentPage >= totalPages)
			m_CurrentPage = totalPages - 1;
		
		if (m_PlayerUIDs.Count() == 0)
		{
			if (m_EmptyText)
			{
				m_EmptyText.SetText("Aucun autre joueur connecte.");
				m_EmptyText.SetVisible(true);
			}
			UpdatePaginationUI(totalPages);
			return;
		}
		
		if (m_EmptyText)
			m_EmptyText.SetVisible(false);
		
		WorkspaceWidget ws = GetGame().GetWorkspace();
		int startIdx = m_CurrentPage * ITEMS_PER_PAGE;
		int endIdx = startIdx + ITEMS_PER_PAGE;
		if (endIdx > m_PlayerUIDs.Count())
			endIdx = m_PlayerUIDs.Count();
		
		for (int i = startIdx; i < endIdx; i++)
		{
			string uid = m_PlayerUIDs.Get(i);
			string name = m_PlayerNames.Get(i);
			
			Widget entry = ws.CreateWidgets(ENTRY_LAYOUT_PATH, m_PlayersContainer);
			if (!entry)
				continue;
			
			TextWidget nameW = TextWidget.Cast(entry.FindAnyWidget("PlayerName"));
			if (nameW)
				nameW.SetText(name);
			
			ButtonWidget btn = ButtonWidget.Cast(entry.FindAnyWidget("SelectButton"));
			if (btn)
			{
				TransferPlayerSelectHandler ph = new TransferPlayerSelectHandler();
				ph.m_Menu = this;
				ph.m_TargetUID = uid;
				ph.m_TargetName = name;
				btn.AddHandler(ph);
				JobFocusHandler.Attach(btn);
			}
		}
		
		UpdatePaginationUI(totalPages);
	}
	
	//------------------------------------------------------------------------------------------------
	void UpdatePaginationUI(int totalPages)
	{
		if (m_PageLabel)
			m_PageLabel.SetText(string.Format("Page %1 / %2", (m_CurrentPage + 1).ToString(), totalPages.ToString()));
		if (m_PrevPageButton)
			m_PrevPageButton.SetEnabled(m_CurrentPage > 0);
		if (m_NextPageButton)
			m_NextPageButton.SetEnabled(m_CurrentPage < totalPages - 1);
	}
	
	//------------------------------------------------------------------------------------------------
	void OnPrevPageClicked()
	{
		int now = System.GetTickCount();
		if (now - m_LastPageChangeTime < PAGE_CHANGE_COOLDOWN_MS)
			return;
		m_LastPageChangeTime = now;
		
		if (m_CurrentPage <= 0)
			return;
		m_CurrentPage--;
		BuildPlayersList();
	}
	
	void OnNextPageClicked()
	{
		int now = System.GetTickCount();
		if (now - m_LastPageChangeTime < PAGE_CHANGE_COOLDOWN_MS)
			return;
		m_LastPageChangeTime = now;
		
		if (m_CurrentPage >= GetTotalPages() - 1)
			return;
		m_CurrentPage++;
		BuildPlayersList();
	}
	
	//------------------------------------------------------------------------------------------------
	// Selection d un joueur dans la liste : affiche le popup confirmation.
	//------------------------------------------------------------------------------------------------
	void OnPlayerSelected(string uid, string name)
	{
		m_PendingTargetUID = uid;
		m_PendingTargetName = name;
		
		if (m_ConfirmText)
			m_ConfirmText.SetText(string.Format("Transferer le vehicule '%1' a '%2' ?",
				s_PendingVehicleName, name));
		if (m_ConfirmOverlay)
			m_ConfirmOverlay.SetVisible(true);
		if (m_BtnConfirmNo)
			GetGame().GetWorkspace().SetFocusedWidget(m_BtnConfirmNo);
	}
	
	//------------------------------------------------------------------------------------------------
	void OnConfirmYes()
	{
		if (m_PendingTargetUID == "")
			return;
		
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		jpc.ClientAskTransferVehicle(s_PendingGarageIndex, m_PendingTargetUID);
		
		// Ferme le menu apres un court delai pour que la RPC parte
		GetGame().GetCallqueue().CallLater(CloseMenuInternal, 300, false);
	}
	
	void OnConfirmNo()
	{
		if (m_ConfirmOverlay)
			m_ConfirmOverlay.SetVisible(false);
		m_PendingTargetUID = "";
		m_PendingTargetName = "";
	}
	
	//------------------------------------------------------------------------------------------------
	void CloseMenuInternal()
	{
		GetGame().GetMenuManager().CloseMenu(this);
	}
}

//------------------------------------------------------------------------------------------------
class TransferCloseHandler : ScriptedWidgetEventHandler
{
	JobGarageTransferMenu m_Menu;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.CloseMenuInternal();
		return true;
	}
	override bool OnMouseButtonDown(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.CloseMenuInternal();
		return true;
	}
}

//------------------------------------------------------------------------------------------------
class TransferPlayerSelectHandler : ScriptedWidgetEventHandler
{
	JobGarageTransferMenu m_Menu;
	string m_TargetUID;
	string m_TargetName;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.OnPlayerSelected(m_TargetUID, m_TargetName);
		return true;
	}
	override bool OnMouseButtonDown(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.OnPlayerSelected(m_TargetUID, m_TargetName);
		return true;
	}
}

//------------------------------------------------------------------------------------------------
class TransferConfirmYesHandler : ScriptedWidgetEventHandler
{
	JobGarageTransferMenu m_Menu;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.OnConfirmYes();
		return true;
	}
	override bool OnMouseButtonDown(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.OnConfirmYes();
		return true;
	}
}

//------------------------------------------------------------------------------------------------
class TransferConfirmNoHandler : ScriptedWidgetEventHandler
{
	JobGarageTransferMenu m_Menu;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.OnConfirmNo();
		return true;
	}
	override bool OnMouseButtonDown(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.OnConfirmNo();
		return true;
	}
}

//------------------------------------------------------------------------------------------------
class TransferPrevPageHandler : ScriptedWidgetEventHandler
{
	JobGarageTransferMenu m_Menu;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.OnPrevPageClicked();
		return true;
	}
	override bool OnMouseButtonDown(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.OnPrevPageClicked();
		return true;
	}
}

//------------------------------------------------------------------------------------------------
class TransferNextPageHandler : ScriptedWidgetEventHandler
{
	JobGarageTransferMenu m_Menu;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.OnNextPageClicked();
		return true;
	}
	override bool OnMouseButtonDown(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.OnNextPageClicked();
		return true;
	}
}
