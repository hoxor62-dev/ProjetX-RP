//------------------------------------------------------------------------------------------------
// JobCompanyAccessMenu.c
// Menu principal "Acces entreprise" - ouvert apres clic sur UserAction du PNJ metier.
//
// Le serveur a deja verifie que le joueur est patron ou employe d une entreprise de CE
// metier. Il envoie un payload pre-charge contenant :
//   - role du joueur (PATRON ou EMPLOYE)
//   - nom entreprise + metier + benefices + nb ventes + nb bons en attente
//   - liste des bons (id, statut, prix propose, date)
//
// Selon le role, le menu affiche les bons boutons :
//   PATRON : Tableau de bord, Bons en attente, Retirer benefices, Dissoudre
//   EMPLOYE : Creer un bon, Mes bons (en cours / historique), Demissioner
//------------------------------------------------------------------------------------------------

// Donnees pre-chargees envoyees par le serveur
class JobCompanyMenuPayload
{
	bool m_IsOwner;
	string m_CompanyName;
	int m_JobType;
	int m_Benefits;
	int m_TotalSales;
	int m_PendingOrderCount;
	int m_TotalOrderCount;
	int m_EmployeeCount;
	// Texte top 3 employes (formate par le serveur)
	string m_Top3Text;
}

class JobCompanyAccessMenu : ChimeraMenuBase
{
	Widget m_RootWidget;
	TextWidget m_TitleText;
	TextWidget m_SubTitleText;
	
	// Boutons PATRON
	ButtonWidget m_BtnDashboard;
	ButtonWidget m_BtnPendingOrders;
	ButtonWidget m_BtnWithdraw;
	ButtonWidget m_BtnManageEmployees;
	ButtonWidget m_BtnDissolve;
	
	// Boutons EMPLOYE
	ButtonWidget m_BtnCreateOrder;
	ButtonWidget m_BtnMyOrders;
	ButtonWidget m_BtnResign;
	
	// Boutons COMMUNS (tous membres)
	ButtonWidget m_BtnChat;
	
	ButtonWidget m_BtnClose;
	
	// Popup confirmation dissolution
	Widget m_ConfirmOverlay;
	TextWidget m_ConfirmText;
	ButtonWidget m_BtnConfirmYes;
	ButtonWidget m_BtnConfirmNo;
	
	// Donnees pre-chargees
	static ref JobCompanyMenuPayload s_Payload;
	
	static JobCompanyAccessMenu s_Instance;
	
	//------------------------------------------------------------------------------------------------
	static void SetPendingPayload(JobCompanyMenuPayload p)
	{
		s_Payload = p;
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuOpen()
	{
		super.OnMenuOpen();
		s_Instance = this;
		JobFocusHandler.ClearRegistry();
		
		m_RootWidget = GetRootWidget();
		if (!m_RootWidget)
			return;
		
		m_TitleText = TextWidget.Cast(m_RootWidget.FindAnyWidget("TitleText"));
		m_SubTitleText = TextWidget.Cast(m_RootWidget.FindAnyWidget("SubTitleText"));
		
		m_BtnDashboard = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnDashboard"));
		m_BtnPendingOrders = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnPendingOrders"));
		m_BtnWithdraw = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnWithdraw"));
		m_BtnManageEmployees = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnManageEmployees"));
		m_BtnDissolve = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnDissolve"));
		
		m_BtnCreateOrder = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnCreateOrder"));
		m_BtnMyOrders = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnMyOrders"));
		m_BtnResign = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnResign"));
		
		m_BtnChat = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnChat"));
		
		m_BtnClose = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnClose"));
		
		// Popup confirmation
		m_ConfirmOverlay = m_RootWidget.FindAnyWidget("ConfirmOverlay");
		m_ConfirmText = TextWidget.Cast(m_RootWidget.FindAnyWidget("ConfirmText"));
		m_BtnConfirmYes = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnConfirmYes"));
		m_BtnConfirmNo = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnConfirmNo"));
		if (m_ConfirmOverlay)
			m_ConfirmOverlay.SetVisible(false);
		
		ApplyPayload();
		
		// Bind handlers
		BindBtn(m_BtnDashboard, "dashboard");
		BindBtn(m_BtnPendingOrders, "pending");
		BindBtn(m_BtnWithdraw, "withdraw");
		BindBtn(m_BtnManageEmployees, "manage_employees");
		BindBtn(m_BtnDissolve, "dissolve");
		BindBtn(m_BtnCreateOrder, "create_order");
		BindBtn(m_BtnMyOrders, "my_orders");
		BindBtn(m_BtnResign, "resign");
		BindBtn(m_BtnChat, "chat");
		BindBtn(m_BtnClose, "close");
		BindBtn(m_BtnConfirmYes, "confirm_yes");
		BindBtn(m_BtnConfirmNo, "confirm_no");
		
		if (m_BtnClose)
			GetGame().GetWorkspace().SetFocusedWidget(m_BtnClose);
	}
	
	void BindBtn(ButtonWidget btn, string action)
	{
		if (!btn) return;
		CompanyAccessHandler h = new CompanyAccessHandler();
		h.m_Menu = this;
		h.m_Action = action;
		btn.AddHandler(h);
		JobFocusHandler.Attach(btn);
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuClose()
	{
		if (s_Instance == this)
			s_Instance = null;
		super.OnMenuClose();
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuUpdate(float tDelta)
	{
		super.OnMenuUpdate(tDelta);
		if (GetGame().GetInputManager().GetActionValue("MenuBack") > 0.5)
		{
			// Si popup ouvert : ferme le popup d abord, sinon ferme le menu
			if (m_ConfirmOverlay && m_ConfirmOverlay.IsVisible())
				m_ConfirmOverlay.SetVisible(false);
			else
				CloseMenuInternal();
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void ApplyPayload()
	{
		if (!s_Payload)
			return;
		
		if (m_TitleText)
			m_TitleText.SetText(string.Format("Acces entreprise - %1", s_Payload.m_CompanyName));
		
		string role;
		if (s_Payload.m_IsOwner)
			role = "Patron";
		else
			role = "Employe";
		if (m_SubTitleText)
			m_SubTitleText.SetText(string.Format("Role : %1   |   Bons en attente : %2",
				role, s_Payload.m_PendingOrderCount.ToString()));
		
		// Cache les boutons selon le role
		bool isOwner = s_Payload.m_IsOwner;
		SetVisible(m_BtnDashboard, isOwner);
		SetVisible(m_BtnPendingOrders, isOwner);
		SetVisible(m_BtnWithdraw, isOwner);
		SetVisible(m_BtnManageEmployees, isOwner);
		SetVisible(m_BtnDissolve, isOwner);
		SetVisible(m_BtnCreateOrder, true);  // patron PEUT aussi creer des bons
		SetVisible(m_BtnMyOrders, true);     // patron PEUT aussi voir ses bons
		SetVisible(m_BtnResign, !isOwner);   // demission = employe uniquement
		SetVisible(m_BtnChat, true);         // chat = tous les membres
	}
	
	void SetVisible(ButtonWidget btn, bool visible)
	{
		if (!btn) return;
		btn.SetVisible(visible);
		btn.SetEnabled(visible);
	}
	
	//------------------------------------------------------------------------------------------------
	void OnAction(string action)
	{
		if (action == "close")
		{
			CloseMenuInternal();
			return;
		}
		
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		
		if (action == "dashboard")
		{
			// Ouvre menu tableau de bord (deja en partie pre-charge ; demande complement)
			MenuManager mm = GetGame().GetMenuManager();
			JobCompanyDashboardMenu.SetPendingPayload(s_Payload);
			mm.CloseMenu(this);
			mm.OpenMenu(ChimeraMenuPreset.JobCompanyDashboardMenu);
			return;
		}
		if (action == "pending" || action == "my_orders")
		{
			// Pour la V1 : meme menu (le filtrage est par auteur ou statut cote serveur)
			// On va demander la liste des bons puis afficher
			bool ownerView = (action == "pending");  // owner = bons en attente filtre
			jpc.ClientAskListOrders(ownerView);
			return;
		}
		if (action == "withdraw")
		{
			jpc.ClientAskWithdrawCompanyBenefits();
			CloseMenuInternal();
			return;
		}
		if (action == "dissolve")
		{
			// Affiche le popup de confirmation (au lieu d envoyer la RPC direct)
			if (m_ConfirmText && s_Payload)
				m_ConfirmText.SetText(string.Format(
					"Voulez-vous vraiment DISSOUDRE l entreprise '%1' ?\nCette action est irreversible.",
					s_Payload.m_CompanyName));
			if (m_ConfirmOverlay)
				m_ConfirmOverlay.SetVisible(true);
			if (m_BtnConfirmNo)
				GetGame().GetWorkspace().SetFocusedWidget(m_BtnConfirmNo);
			return;
		}
		if (action == "confirm_yes")
		{
			// Dissolution confirmee
			jpc.ClientAskDissolveCompany();
			CloseMenuInternal();
			return;
		}
		if (action == "confirm_no")
		{
			// Annulation : ferme le popup, garde le menu ouvert
			if (m_ConfirmOverlay)
				m_ConfirmOverlay.SetVisible(false);
			return;
		}
		if (action == "create_order")
		{
			// Demande au serveur la liste des items dans l inventaire du joueur
			jpc.ClientAskListInventoryForOrder();
			CloseMenuInternal();
			return;
		}
		if (action == "manage_employees")
		{
			// Demande la liste des employes au serveur
			jpc.ClientAskOpenEmployees();
			CloseMenuInternal();
			return;
		}
		if (action == "chat")
		{
			// Demande l etat initial du chat au serveur (le menu s ouvre apres)
			jpc.ClientAskOpenChat();
			CloseMenuInternal();
			return;
		}
		if (action == "resign")
		{
			jpc.ClientAskResignFromCompany();
			CloseMenuInternal();
			return;
		}
	}
	
	void CloseMenuInternal()
	{
		GetGame().GetMenuManager().CloseMenu(this);
	}
	
	static JobCompanyAccessMenu GetOpenMenu() { return s_Instance; }
}

//------------------------------------------------------------------------------------------------
class CompanyAccessHandler : ScriptedWidgetEventHandler
{
	JobCompanyAccessMenu m_Menu;
	string m_Action;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.OnAction(m_Action);
		return true;
	}
	override bool OnMouseButtonDown(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.OnAction(m_Action);
		return true;
	}
}
