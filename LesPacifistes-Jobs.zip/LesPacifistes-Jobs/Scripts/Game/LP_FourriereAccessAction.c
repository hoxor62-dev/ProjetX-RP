//------------------------------------------------------------------------------------------------
// LP_FourriereAccessAction.c
// Action F sur le PNJ Fourriere : "Acceder au garage Fourriere".
//
// Visible UNIQUEMENT pour les joueurs ayant le metier FOURRIERE. Le garage virtuel ouvert
// est un garage PARTAGE : tous les employes Fourriere voient les memes vehicules et peuvent
// les stocker / recuperer. Lie au METIER, pas au joueur.
//
// Techniquement : cote serveur, le JobVirtualGarageManager est appele avec l owner UID
// special "FOURRIERE_SHARED" au lieu du UID du joueur. Donc tous les joueurs Fourriere
// partagent le meme garage virtuel.
//------------------------------------------------------------------------------------------------

class LP_FourriereAccessAction : ScriptedUserAction
{
	//------------------------------------------------------------------------------------------------
	override bool CanBeShownScript(IEntity user)
	{
		if (!user) return false;

		// Verifie cote client que le joueur local a le metier FOURRIERE
		// JobPlayerComponent est attache au PlayerController, pas au character.
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc)
			return false;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc)
			return false;
		return jpc.GetJob() == EJobType.FOURRIERE;
	}

	//------------------------------------------------------------------------------------------------
	override bool CanBePerformedScript(IEntity user)
	{
		return CanBeShownScript(user);
	}

	//------------------------------------------------------------------------------------------------
	override bool GetActionNameScript(out string outName)
	{
		outName = "Acceder au garage Fourriere";
		return true;
	}

	//------------------------------------------------------------------------------------------------
	override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
	{
		if (!pOwnerEntity || !pUserEntity)
			return;

		// Garde multijoueur : seul le joueur local execute la suite
		PlayerController localPC = GetGame().GetPlayerController();
		if (!localPC)
			return;
		IEntity localEntity = localPC.GetControlledEntity();
		if (localEntity != pUserEntity)
			return;

		// Recupere le RplId du PNJ (necessaire pour le serveur)
		RplComponent rpl = RplComponent.Cast(pOwnerEntity.FindComponent(RplComponent));
		if (!rpl)
			return;
		RplId npcRplId = rpl.Id();

		JobPlayerComponent jpc = JobPlayerComponent.Cast(localPC.FindComponent(JobPlayerComponent));
		if (!jpc)
			return;

		// Demande au serveur la liste des vehicules du garage partage Fourriere.
		// Le serveur verifiera que le joueur a bien le metier FOURRIERE avant de repondre.
		jpc.ClientAskFourriereGarageList(npcRplId);
	}
}
