//------------------------------------------------------------------------------------------------
// JobCreateCompanyMenu.c
// Menu de creation d entreprise (ouvert depuis le PNJ Maire).
//
// Le joueur :
//   1. Tape le nom de son entreprise dans l editbox
//   2. Selectionne un metier (1 des 5 disponibles) via boutons
//   3. Clique sur "Creer" : envoie ClientAskCreateCompany(name, jobType) au serveur
//   4. Le serveur verifie tout (solde 30k, nom unique, deja patron, etc.) et notifie via chat
//
// La selection metier est visuelle : le bouton selectionne change de couleur.
//------------------------------------------------------------------------------------------------

class JobCreateCompanyMenu : ChimeraMenuBase
{
	Widget m_RootWidget;
	TextWidget m_TitleText;
	EditBoxWidget m_NameInput;
	
	// Boutons des 5 metiers eligibles
	ButtonWidget m_BtnJobMineur;
	ButtonWidget m_BtnJobAgriculteur;
	ButtonWidget m_BtnJobBucheron;
	ButtonWidget m_BtnJobConcessionnaire;
	ButtonWidget m_BtnJobImmobilier;
	
	ButtonWidget m_BtnCreate;
	ButtonWidget m_BtnCancel;
	
	TextWidget m_InfoText;  // affiche le metier selectionne / aide
	
	// Etat
	EJobType m_SelectedJob = -1;  // -1 = aucun selectionne
	
	// Couleurs : selectionne / non selectionne
	const float SEL_R = 0.18;
	const float SEL_G = 0.45;
	const float SEL_B = 0.65;  // bleu marine
	
	const float UNSEL_R = 0.30;
	const float UNSEL_G = 0.30;
	const float UNSEL_B = 0.36;  // gris bleute
	
	static JobCreateCompanyMenu s_Instance;
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuOpen()
	{
		super.OnMenuOpen();
		s_Instance = this;
		JobFocusHandler.ClearRegistry();
		
		m_RootWidget = GetRootWidget();
		if (!m_RootWidget)
			return;
		
		m_TitleText = TextWidget.Cast(m_RootWidget.FindAnyWidget("TitleText"));
		m_NameInput = EditBoxWidget.Cast(m_RootWidget.FindAnyWidget("NameInput"));
		m_BtnJobMineur = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnJobMineur"));
		m_BtnJobAgriculteur = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnJobAgriculteur"));
		m_BtnJobBucheron = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnJobBucheron"));
		m_BtnJobConcessionnaire = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnJobConcessionnaire"));
		m_BtnJobImmobilier = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnJobImmobilier"));
		m_BtnCreate = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnCreate"));
		m_BtnCancel = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnCancel"));
		m_InfoText = TextWidget.Cast(m_RootWidget.FindAnyWidget("InfoText"));
		
		AttachJobButton(m_BtnJobMineur, EJobType.MINEUR);
		AttachJobButton(m_BtnJobAgriculteur, EJobType.AGRICULTEUR);
		AttachJobButton(m_BtnJobBucheron, EJobType.BUCHERON);
		AttachJobButton(m_BtnJobConcessionnaire, EJobType.CONCESSIONNAIRE);
		AttachJobButton(m_BtnJobImmobilier, EJobType.VENDEUR_IMMOBILIER);
		
		if (m_BtnCreate)
		{
			CreateCompanyCreateHandler ch = new CreateCompanyCreateHandler();
			ch.m_Menu = this;
			m_BtnCreate.AddHandler(ch);
			JobFocusHandler.Attach(m_BtnCreate);
		}
		if (m_BtnCancel)
		{
			CreateCompanyCancelHandler ch = new CreateCompanyCancelHandler();
			ch.m_Menu = this;
			m_BtnCancel.AddHandler(ch);
			JobFocusHandler.Attach(m_BtnCancel);
			GetGame().GetWorkspace().SetFocusedWidget(m_BtnCancel);
		}
		
		UpdateInfoText();
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuClose()
	{
		if (s_Instance == this)
			s_Instance = null;
		super.OnMenuClose();
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuUpdate(float tDelta)
	{
		super.OnMenuUpdate(tDelta);
		if (GetGame().GetInputManager().GetActionValue("MenuBack") > 0.5)
			CloseMenuInternal();
	}
	
	//------------------------------------------------------------------------------------------------
	void AttachJobButton(ButtonWidget btn, EJobType job)
	{
		if (!btn)
			return;
		CreateCompanyJobSelectHandler h = new CreateCompanyJobSelectHandler();
		h.m_Menu = this;
		h.m_Job = job;
		btn.AddHandler(h);
		JobFocusHandler.Attach(btn);
		// Couleur initiale = non selectionne
		btn.SetColor(Color.FromRGBA(UNSEL_R * 255, UNSEL_G * 255, UNSEL_B * 255, 255));
	}
	
	//------------------------------------------------------------------------------------------------
	void OnJobSelected(EJobType job)
	{
		m_SelectedJob = job;
		
		// Reset toutes les couleurs en non-selectionne
		SetButtonColor(m_BtnJobMineur, false);
		SetButtonColor(m_BtnJobAgriculteur, false);
		SetButtonColor(m_BtnJobBucheron, false);
		SetButtonColor(m_BtnJobConcessionnaire, false);
		SetButtonColor(m_BtnJobImmobilier, false);
		
		// Met en selectionne le bon
		switch (job)
		{
			case EJobType.MINEUR:           SetButtonColor(m_BtnJobMineur, true); break;
			case EJobType.AGRICULTEUR:      SetButtonColor(m_BtnJobAgriculteur, true); break;
			case EJobType.BUCHERON:         SetButtonColor(m_BtnJobBucheron, true); break;
			case EJobType.CONCESSIONNAIRE:  SetButtonColor(m_BtnJobConcessionnaire, true); break;
			case EJobType.VENDEUR_IMMOBILIER: SetButtonColor(m_BtnJobImmobilier, true); break;
		}
		
		UpdateInfoText();
	}
	
	//------------------------------------------------------------------------------------------------
	void SetButtonColor(ButtonWidget btn, bool selected)
	{
		if (!btn)
			return;
		if (selected)
			btn.SetColor(Color.FromRGBA(SEL_R * 255, SEL_G * 255, SEL_B * 255, 255));
		else
			btn.SetColor(Color.FromRGBA(UNSEL_R * 255, UNSEL_G * 255, UNSEL_B * 255, 255));
	}
	
	//------------------------------------------------------------------------------------------------
	void UpdateInfoText()
	{
		if (!m_InfoText)
			return;
		if (m_SelectedJob == -1)
			m_InfoText.SetText("Saisissez un nom et selectionnez un metier (cout : 30000 capsules)");
		else
			m_InfoText.SetText(string.Format("Metier selectionne : %1 (cout : 30000 capsules)",
				JobData.GetJobLabel(m_SelectedJob)));
	}
	
	//------------------------------------------------------------------------------------------------
	void OnCreateClicked()
	{
		if (!m_NameInput)
			return;
		string name = m_NameInput.GetText();
		if (name == "")
		{
			if (m_InfoText)
				m_InfoText.SetText("Veuillez saisir un nom pour votre entreprise.");
			return;
		}
		if (m_SelectedJob == -1)
		{
			if (m_InfoText)
				m_InfoText.SetText("Veuillez selectionner un metier.");
			return;
		}
		
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		jpc.ClientAskCreateCompany(name, m_SelectedJob);
		
		// Ferme le menu (le serveur enverra une notif chat avec le resultat)
		CloseMenuInternal();
	}
	
	//------------------------------------------------------------------------------------------------
	void CloseMenuInternal()
	{
		GetGame().GetMenuManager().CloseMenu(this);
	}
	
	static JobCreateCompanyMenu GetOpenMenu()
	{
		return s_Instance;
	}
}

//------------------------------------------------------------------------------------------------
class CreateCompanyJobSelectHandler : ScriptedWidgetEventHandler
{
	JobCreateCompanyMenu m_Menu;
	EJobType m_Job;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.OnJobSelected(m_Job);
		return true;
	}
	override bool OnMouseButtonDown(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.OnJobSelected(m_Job);
		return true;
	}
}

//------------------------------------------------------------------------------------------------
class CreateCompanyCreateHandler : ScriptedWidgetEventHandler
{
	JobCreateCompanyMenu m_Menu;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.OnCreateClicked();
		return true;
	}
	override bool OnMouseButtonDown(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.OnCreateClicked();
		return true;
	}
}

//------------------------------------------------------------------------------------------------
class CreateCompanyCancelHandler : ScriptedWidgetEventHandler
{
	JobCreateCompanyMenu m_Menu;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.CloseMenuInternal();
		return true;
	}
	override bool OnMouseButtonDown(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.CloseMenuInternal();
		return true;
	}
}
