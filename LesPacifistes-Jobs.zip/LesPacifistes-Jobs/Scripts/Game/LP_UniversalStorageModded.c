//------------------------------------------------------------------------------------------------
// LP_UniversalStorageModded.c
// Expose la methode protected InsertItem de BaseInventoryStorageComponent via un wrapper
// public LP_StorageInsertItemForRestore, utilisable par StorageSaveManager pour restaurer
// les items disparus dans les coffres au boot serveur.
//
// PATTERN : impossible de modder BaseInventoryStorageComponent (engine class), donc on
// modde SCR_UniversalInventoryStorageComponent qui herite de BaseInventoryStorageComponent
// et a acces a InsertItem protected.
//
// SIGNATURE EXACTE (Arma Reforger) :
//   event protected ref BaseInventoryTask InsertItem(IEntity item, int slotID, bool justSpawned)
//
// IMPORTANT : InsertItem est fondamentalement ASYNC. Le rattachement au storage n arrive
// pas dans la meme frame que l appel. Ni la valeur de retour ni item.GetParent() ne sont
// fiables immediatement apres l appel.
// Solution : on lance simplement InsertItem et on retourne toujours true. Si l insertion
// echoue reellement (coffre plein), l item restera au sol pres du coffre - ce qui est
// acceptable pour un restore boot (le joueur trouvera son item a cote).
//
// NOTE : nom du wrapper choisi specifique (LP_StorageInsertItemForRestore) pour eviter
// toute collision avec d autres mods qui pourraient definir un LP_InsertItem(IEntity, int)
// generique.
//------------------------------------------------------------------------------------------------

modded class SCR_UniversalInventoryStorageComponent
{
	//------------------------------------------------------------------------------------------------
	// Wrapper public pour InsertItem protected. Utilise UNIQUEMENT par le systeme de restore coffres.
	// Retourne toujours true : InsertItem est async, impossible de verifier synchronement le succes.
	// L item est spawn au-dessus du coffre - si InsertItem echoue reellement (coffre plein), l item
	// tombera au sol pres du coffre.
	//------------------------------------------------------------------------------------------------
	bool LP_StorageInsertItemForRestore(IEntity item)
	{
		if (!item) return false;
		InsertItem(item, -1, true);
		return true;
	}
}
