//------------------------------------------------------------------------------------------------
// JobUnlockHospitalDoorAction.c
// Action UserAction "Deverrouiller" sur les portes de l hopital.
// Symetrique de JobLockHospitalDoorAction : visible uniquement si porte deja VERROUILLEE
// et que le joueur local est MEDECIN.
//------------------------------------------------------------------------------------------------

class JobUnlockHospitalDoorAction : ScriptedUserAction
{
	//------------------------------------------------------------------------------------------------
	override bool CanBeShownScript(IEntity user)
	{
		if (!user)
			return false;
		
		// Verifie le metier
		JobCharacterJobComponent localJobComp = JobCharacterJobComponent.Cast(
			user.FindComponent(JobCharacterJobComponent));
		if (!localJobComp)
			return false;
		EJobType localJob = localJobComp.GetJob();
		if (localJob != EJobType.MEDECIN)
			return false;
		
		// Visible UNIQUEMENT si verrouillee
		IEntity door = GetOwner();
		if (!door)
			return false;
		JobHospitalDoorComponent doorComp = JobHospitalDoorComponent.Cast(
			door.FindComponent(JobHospitalDoorComponent));
		if (!doorComp)
			return false;
		return doorComp.IsLocked();
	}
	
	//------------------------------------------------------------------------------------------------
	override bool CanBePerformedScript(IEntity user)
	{
		return CanBeShownScript(user);
	}
	
	//------------------------------------------------------------------------------------------------
	override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
	{
		if (!pOwnerEntity)
			return;
		
		// IMPORTANT (dedicated server) : PerformAction s execute sur TOUS les clients qui
		// voient l action localement. On filtre pour que seul le joueur local agisse.
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc)
			return;
		if (pUserEntity != pc.GetControlledEntity())
			return;
		
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc)
			return;
		RplComponent rpl = RplComponent.Cast(pOwnerEntity.FindComponent(RplComponent));
		if (!rpl)
			return;
		jpc.ClientAskToggleHospitalDoor(rpl.Id(), false);  // false = unlock
	}
	
	//------------------------------------------------------------------------------------------------
	override bool GetActionNameScript(out string outName)
	{
		outName = "Deverrouiller la porte";
		return true;
	}
}
