//------------------------------------------------------------------------------------------------
// JobBonPointManager.c
// Manager singleton SERVEUR du systeme LeBonPoint (marketplace inter-joueurs).
//
// Fonctionnalites :
//  - Annonces de vente d items (5 max par joueur, expiration 7 jours)
//  - Achat par d autres joueurs (item recupere via 'Mes achats' dans le menu)
//  - Taxe 5% sur chaque vente -> cagnotte ville
//  - Chat 1-to-1 entre vendeur et chaque acheteur potentiel (Session 3)
//  - Modification/retrait d annonces par le vendeur
//
// Persistance :
//  - $profile:LesPacifistesJobs/bonpoint_ads.json (annonces actives)
//  - $profile:LesPacifistesJobs/bonpoint_purchases.json (achats a recuperer)
//  - $profile:LesPacifistesJobs/bonpoint_treasury.json (cagnotte ville)
//  - $profile:LesPacifistesJobs/bonpoint_blacklist.json (items interdits a la vente)
//------------------------------------------------------------------------------------------------

// Annonce de vente
class JobBonPointAd
{
	int m_AdId;                 // identifiant unique (auto-increment)
	string m_SellerUID;
	string m_SellerDisplayName; // Prenom Nom RP
	string m_PrefabName;        // ResourceName de l item
	string m_ItemTitle;         // titre saisi par le vendeur (max ~50 chars)
	string m_ItemDescription;   // description longue (max ~500 chars)
	int m_Price;                // prix en capsules
	int m_CreatedAt;            // timestamp creation
	int m_ExpiresAt;            // timestamp expiration (= CreatedAt + 7 jours)
}

// Achat a recuperer (l acheteur a paye, doit cliquer 'Recuperer mon item')
class JobBonPointPurchase
{
	int m_PurchaseId;           // identifiant unique
	string m_BuyerUID;
	string m_PrefabName;        // a respawn lors du retrait
	string m_ItemTitle;
	string m_SellerDisplayName; // pour affichage "achete chez X"
	int m_BoughtAt;             // timestamp achat
}

// Message de chat 1-to-1 sur une annonce
// (utilise en Session 3 mais structure declaree ici pour la persistance)
class JobBonPointChatMsg
{
	int m_Timestamp;
	string m_AuthorUID;
	string m_AuthorDisplayName;
	string m_Text;
}

class JobBonPointManager
{
	static ref JobBonPointManager s_Instance;
	
	// Toutes les annonces actives (cle = adId)
	ref map<int, ref JobBonPointAd> m_Ads;
	
	// Tous les achats en attente de retrait (cle = purchaseId)
	ref map<int, ref JobBonPointPurchase> m_Purchases;
	
	// Auto-increment pour les IDs
	int m_NextAdId = 1;
	int m_NextPurchaseId = 1;
	
	// Cagnotte ville (taxes accumulees)
	int m_CityTreasury = 0;
	
	// Blacklist : ResourceName des items INTERDITS a la vente
	ref array<string> m_BlacklistPrefabs;
	
	// Chat 1-to-1 entre vendeur et chaque acheteur potentiel.
	// Cle = "adId_buyerUID" (1 conversation par paire annonce/acheteur)
	// Valeur = liste des messages (max 50)
	ref map<string, ref array<ref JobBonPointChatMsg>> m_Chats;
	
	// Constantes
	const int MAX_ADS_PER_PLAYER = 5;
	const int AD_EXPIRY_SECONDS = 86400;  // 7 jours = 7 * 86400
	const int DEFAULT_TAX_RATE_PERCENT = 5;  // valeur par defaut au boot
	const int MIN_TAX_RATE_PERCENT = 0;      // borne min (limite stricte demandee par le boss)
	const int MAX_TAX_RATE_PERCENT = 20;     // borne max (limite stricte)
	const int CLEANUP_INTERVAL_MS = 60000;  // verif expiration chaque minute
	const int MAX_MSG_PER_CHAT = 50;        // limite par paire vendeur/acheteur
	const int MAX_MSG_LENGTH = 200;         // longueur max d un message
	
	// Taxe modifiable par le President (en %). Chargee depuis JSON au boot.
	int m_TaxRatePercent = DEFAULT_TAX_RATE_PERCENT;
	
	const string ADS_PATH = "$profile:LesPacifistesJobs/bonpoint_ads.json";
	const string PURCHASES_PATH = "$profile:LesPacifistesJobs/bonpoint_purchases.json";
	const string TREASURY_PATH = "$profile:LesPacifistesJobs/bonpoint_treasury.json";
	const string BLACKLIST_PATH = "$profile:LesPacifistesJobs/bonpoint_blacklist.json";
	const string CHATS_PATH = "$profile:LesPacifistesJobs/bonpoint_chats.json";
	
	//------------------------------------------------------------------------------------------------
	void JobBonPointManager()
	{
		m_Ads = new map<int, ref JobBonPointAd>();
		m_Purchases = new map<int, ref JobBonPointPurchase>();
		m_BlacklistPrefabs = new array<string>();
		m_Chats = new map<string, ref array<ref JobBonPointChatMsg>>();
	}
	
	//------------------------------------------------------------------------------------------------
	static JobBonPointManager GetInstance()
	{
		if (!s_Instance)
		{
			s_Instance = new JobBonPointManager();
			s_Instance.Init();
		}
		return s_Instance;
	}
	
	//------------------------------------------------------------------------------------------------
	void Init()
	{
		Print("[JobBonPointManager] Initialisation", LogLevel.NORMAL);
		LoadFromDisk();
		LoadBlacklist();
		LoadChatsFromDisk();
		
		// Demarre la boucle de cleanup des annonces expirees (toutes les minutes)
		GetGame().GetCallqueue().CallLater(CleanupExpiredAds, CLEANUP_INTERVAL_MS, true);
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== HELPERS LECTURE =====
	//------------------------------------------------------------------------------------------------
	
	// Compte les annonces actives d un joueur
	int CountAdsByPlayer(string sellerUID)
	{
		int count = 0;
		foreach (int adId, JobBonPointAd ad : m_Ads)
		{
			if (ad && ad.m_SellerUID == sellerUID)
				count++;
		}
		return count;
	}
	
	// Retourne toutes les annonces actives (tri par date desc dans Session 2)
	array<ref JobBonPointAd> GetAllAds()
	{
		array<ref JobBonPointAd> result = new array<ref JobBonPointAd>();
		foreach (int adId, JobBonPointAd ad : m_Ads)
		{
			if (ad)
				result.Insert(ad);
		}
		return result;
	}
	
	// Retourne les annonces actives d un joueur
	array<ref JobBonPointAd> GetAdsByPlayer(string sellerUID)
	{
		array<ref JobBonPointAd> result = new array<ref JobBonPointAd>();
		foreach (int adId, JobBonPointAd ad : m_Ads)
		{
			if (ad && ad.m_SellerUID == sellerUID)
				result.Insert(ad);
		}
		return result;
	}
	
	// Recupere une annonce par son ID (null si introuvable)
	JobBonPointAd GetAdById(int adId)
	{
		return m_Ads.Get(adId);
	}
	
	// Verifie si un prefab est blackliste (interdit a la vente)
	bool IsPrefabBlacklisted(string prefabName)
	{
		foreach (string black : m_BlacklistPrefabs)
		{
			if (black == prefabName)
				return true;
		}
		return false;
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== CREATION D ANNONCE =====
	//------------------------------------------------------------------------------------------------
	// Cree une nouvelle annonce. Le caller (RPC) doit avoir deja retire l item de l inventaire
	// et fourni son prefab name.
	//
	// Retourne :
	//   0 = OK (outAdId rempli)
	//   1 = limite 5 annonces atteinte
	//   2 = prix invalide (<= 0)
	//   3 = item blackliste
	//   4 = donnees invalides (titre/prefab vide)
	int CreateAd(string sellerUID, string sellerDisplayName, string prefabName,
		string itemTitle, string itemDescription, int price, out int outAdId)
	{
		outAdId = 0;
		
		if (prefabName == "" || itemTitle == "")
			return 4;
		if (price <= 0)
			return 2;
		if (IsPrefabBlacklisted(prefabName))
			return 3;
		if (CountAdsByPlayer(sellerUID) >= MAX_ADS_PER_PLAYER)
			return 1;
		
		int now = System.GetUnixTime();
		JobBonPointAd ad = new JobBonPointAd();
		ad.m_AdId = m_NextAdId;
		m_NextAdId++;
		ad.m_SellerUID = sellerUID;
		ad.m_SellerDisplayName = sellerDisplayName;
		ad.m_PrefabName = prefabName;
		ad.m_ItemTitle = itemTitle;
		ad.m_ItemDescription = itemDescription;
		ad.m_Price = price;
		ad.m_CreatedAt = now;
		ad.m_ExpiresAt = now + AD_EXPIRY_SECONDS;
		
		m_Ads.Set(ad.m_AdId, ad);
		SaveToDisk();
		
		outAdId = ad.m_AdId;
		Print(string.Format("[JobBonPointManager] Nouvelle annonce : id=%1 vendeur=%2 prix=%3",
			ad.m_AdId, sellerUID, price), LogLevel.NORMAL);
		return 0;
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== ACHAT D UNE ANNONCE =====
	//------------------------------------------------------------------------------------------------
	// Le caller (RPC serveur) doit deja avoir verifie que l acheteur a assez de capsules.
	// Cette methode :
	//   1. Verifie l existence de l annonce
	//   2. Retire l annonce de m_Ads
	//   3. Cree un Purchase pour l acheteur (a recuperer)
	//   4. Le caller doit creditEr le vendeur (montant - taxe) et la cagnotte ville (taxe)
	//
	// Retourne :
	//   0 = OK (outSellerUID, outPriceForSeller, outTax remplis)
	//   1 = annonce introuvable
	//   2 = l acheteur est le vendeur (pas d auto-achat)
	int BuyAd(int adId, string buyerUID, out string outSellerUID, out int outPriceForSeller,
		out int outTax, out string outItemTitle, out string outSellerName)
	{
		outSellerUID = "";
		outPriceForSeller = 0;
		outTax = 0;
		outItemTitle = "";
		outSellerName = "";
		
		JobBonPointAd ad = m_Ads.Get(adId);
		if (!ad)
			return 1;
		if (ad.m_SellerUID == buyerUID)
			return 2;
		
		// Calcul taxe + montant vendeur
		int totalPrice = ad.m_Price;
		int tax = totalPrice * m_TaxRatePercent / 100;
		int forSeller = totalPrice - tax;
		
		outSellerUID = ad.m_SellerUID;
		outPriceForSeller = forSeller;
		outTax = tax;
		outItemTitle = ad.m_ItemTitle;
		outSellerName = ad.m_SellerDisplayName;
		
		// Cree le Purchase pour l acheteur
		JobBonPointPurchase p = new JobBonPointPurchase();
		p.m_PurchaseId = m_NextPurchaseId;
		m_NextPurchaseId++;
		p.m_BuyerUID = buyerUID;
		p.m_PrefabName = ad.m_PrefabName;
		p.m_ItemTitle = ad.m_ItemTitle;
		p.m_SellerDisplayName = ad.m_SellerDisplayName;
		p.m_BoughtAt = System.GetUnixTime();
		m_Purchases.Set(p.m_PurchaseId, p);
		
		// Cagnotte ville
		AddToTreasury(tax);
		
		// Retire l annonce
		m_Ads.Remove(adId);
		SaveToDisk();
		
		Print(string.Format("[JobBonPointManager] Vente : annonce #%1 vendue a %2 pour %3 (tax=%4)",
			adId, buyerUID, totalPrice, tax), LogLevel.NORMAL);
		return 0;
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== RECUPERATION D UN ACHAT =====
	//------------------------------------------------------------------------------------------------
	// L acheteur (ou le vendeur si annonce expiree) recupere son item.
	// Retire le Purchase et renvoie le prefab pour spawn cote caller.
	//
	// Retourne :
	//   0 = OK (outPrefabName rempli)
	//   1 = achat introuvable
	//   2 = pas le bon UID (pas votre achat)
	int RecoverPurchase(int purchaseId, string playerUID, out string outPrefabName, out string outItemTitle)
	{
		outPrefabName = "";
		outItemTitle = "";
		
		JobBonPointPurchase p = m_Purchases.Get(purchaseId);
		if (!p)
			return 1;
		if (p.m_BuyerUID != playerUID)
			return 2;
		
		outPrefabName = p.m_PrefabName;
		outItemTitle = p.m_ItemTitle;
		m_Purchases.Remove(purchaseId);
		SaveToDisk();
		
		Print(string.Format("[JobBonPointManager] Achat #%1 recupere par %2",
			purchaseId, playerUID), LogLevel.NORMAL);
		return 0;
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== RETRAIT D ANNONCE PAR LE VENDEUR =====
	//------------------------------------------------------------------------------------------------
	// Le vendeur retire son annonce. Cree un Purchase pour qu il recupere son item.
	//
	// Retourne :
	//   0 = OK
	//   1 = annonce introuvable
	//   2 = pas votre annonce
	int RemoveAd(int adId, string sellerUID)
	{
		JobBonPointAd ad = m_Ads.Get(adId);
		if (!ad)
			return 1;
		if (ad.m_SellerUID != sellerUID)
			return 2;
		
		// Cree un Purchase pour que le vendeur recupere son item
		JobBonPointPurchase p = new JobBonPointPurchase();
		p.m_PurchaseId = m_NextPurchaseId;
		m_NextPurchaseId++;
		p.m_BuyerUID = sellerUID;
		p.m_PrefabName = ad.m_PrefabName;
		p.m_ItemTitle = ad.m_ItemTitle;
		p.m_SellerDisplayName = "Annonce retiree";
		p.m_BoughtAt = System.GetUnixTime();
		m_Purchases.Set(p.m_PurchaseId, p);
		
		m_Ads.Remove(adId);
		SaveToDisk();
		Print(string.Format("[JobBonPointManager] Annonce #%1 retiree par %2",
			adId, sellerUID), LogLevel.NORMAL);
		return 0;
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== MODIFICATION D ANNONCE =====
	//------------------------------------------------------------------------------------------------
	// Le vendeur modifie le prix et/ou la description de son annonce.
	//
	// Retourne :
	//   0 = OK
	//   1 = annonce introuvable
	//   2 = pas votre annonce
	//   3 = prix invalide
	int UpdateAd(int adId, string sellerUID, int newPrice, string newDescription)
	{
		JobBonPointAd ad = m_Ads.Get(adId);
		if (!ad)
			return 1;
		if (ad.m_SellerUID != sellerUID)
			return 2;
		if (newPrice <= 0)
			return 3;
		
		ad.m_Price = newPrice;
		ad.m_ItemDescription = newDescription;
		SaveToDisk();
		Print(string.Format("[JobBonPointManager] Annonce #%1 modifiee par %2 (nouveau prix=%3)",
			adId, sellerUID, newPrice), LogLevel.NORMAL);
		return 0;
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== RECUPERATION DES ACHATS PAR JOUEUR =====
	//------------------------------------------------------------------------------------------------
	array<ref JobBonPointPurchase> GetPurchasesByPlayer(string playerUID)
	{
		array<ref JobBonPointPurchase> result = new array<ref JobBonPointPurchase>();
		foreach (int pid, JobBonPointPurchase p : m_Purchases)
		{
			if (p && p.m_BuyerUID == playerUID)
				result.Insert(p);
		}
		return result;
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== CHAT 1-TO-1 =====
	//------------------------------------------------------------------------------------------------
	// Une conversation est identifiee par la paire (adId, buyerUID).
	// Le vendeur voit toutes les conversations sur ses annonces.
	// L acheteur voit seulement sa propre conversation par annonce.
	//------------------------------------------------------------------------------------------------
	
	// Genere la cle de chat unique pour une paire annonce/acheteur
	string BuildChatKey(int adId, string buyerUID)
	{
		return adId.ToString() + "_" + buyerUID;
	}
	
	// Ajoute un message a la conversation. Tronque a 50 si depassement.
	// authorUID = qui ecrit (vendeur ou acheteur, selon contexte)
	// adId = sur quelle annonce
	// buyerUID = quel acheteur participe a cette conversation
	//
	// Retourne :
	//   0 = OK
	//   1 = annonce introuvable
	//   2 = vous n etes ni vendeur ni acheteur de cette paire
	//   3 = message vide ou trop long
	int SendChatMessage(int adId, string buyerUID, string authorUID, string authorDisplayName, string text)
	{
		if (text == "")
			return 3;
		if (text.Length() > MAX_MSG_LENGTH)
			return 3;
		
		JobBonPointAd ad = m_Ads.Get(adId);
		if (!ad)
			return 1;
		
		// L auteur doit etre soit le vendeur, soit l acheteur identifie
		if (authorUID != ad.m_SellerUID && authorUID != buyerUID)
			return 2;
		
		string key = BuildChatKey(adId, buyerUID);
		array<ref JobBonPointChatMsg> conv = m_Chats.Get(key);
		if (!conv)
		{
			conv = new array<ref JobBonPointChatMsg>();
			m_Chats.Set(key, conv);
		}
		
		JobBonPointChatMsg msg = new JobBonPointChatMsg();
		msg.m_Timestamp = System.GetUnixTime();
		msg.m_AuthorUID = authorUID;
		msg.m_AuthorDisplayName = authorDisplayName;
		msg.m_Text = text;
		conv.Insert(msg);
		
		// Tronque a 50 messages max (retire les plus anciens)
		while (conv.Count() > MAX_MSG_PER_CHAT)
			conv.Remove(0);
		
		SaveChatsToDisk();
		return 0;
	}
	
	// Recupere les messages d une conversation (adId + buyerUID).
	// Retourne array vide si conversation inexistante.
	array<ref JobBonPointChatMsg> GetChatMessages(int adId, string buyerUID)
	{
		string key = BuildChatKey(adId, buyerUID);
		array<ref JobBonPointChatMsg> conv = m_Chats.Get(key);
		if (!conv)
			return new array<ref JobBonPointChatMsg>();
		return conv;
	}
	
	//------------------------------------------------------------------------------------------------
	// Liste les UIDs d acheteurs uniques qui ont chatte sur une annonce donnee.
	// Utilise par le vendeur dans son profil pour voir "qui m a ecrit".
	//
	// outBuyerUIDs : liste des UIDs uniques
	// outDisplayNames : noms RP correspondants (pris du PREMIER message non-vendeur de chaque conv)
	void GetBuyersWhoChatted(int adId, out array<string> outBuyerUIDs, out array<string> outDisplayNames)
	{
		outBuyerUIDs = new array<string>();
		outDisplayNames = new array<string>();
		
		JobBonPointAd ad = m_Ads.Get(adId);
		string sellerUID = "";
		if (ad)
			sellerUID = ad.m_SellerUID;
		
		string prefix = adId.ToString() + "_";
		int prefixLen = prefix.Length();
		
		foreach (string key, array<ref JobBonPointChatMsg> conv : m_Chats)
		{
			if (!conv || conv.Count() == 0)
				continue;
			// Verifie que la cle commence par adId_
			if (key.Length() <= prefixLen)
				continue;
			string keyPrefix = key.Substring(0, prefixLen);
			if (keyPrefix != prefix)
				continue;
			
			// Extrait le buyerUID (tout ce qui est apres adId_)
			string buyerUID = key.Substring(prefixLen, key.Length() - prefixLen);
			if (buyerUID == "")
				continue;
			
			// Cherche le nom RP : 1er message dont l auteur n est pas le vendeur
			string displayName = "Acheteur";
			foreach (JobBonPointChatMsg m : conv)
			{
				if (!m) continue;
				if (m.m_AuthorUID != "" && m.m_AuthorUID != sellerUID)
				{
					displayName = m.m_AuthorDisplayName;
					break;
				}
			}
			
			outBuyerUIDs.Insert(buyerUID);
			outDisplayNames.Insert(displayName);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Compte le nombre d acheteurs qui ont chatte sur une annonce (pour bouton Discuter (X))
	int CountBuyersWhoChatted(int adId)
	{
		string prefix = adId.ToString() + "_";
		int prefixLen = prefix.Length();
		int count = 0;
		foreach (string key, array<ref JobBonPointChatMsg> conv : m_Chats)
		{
			if (!conv || conv.Count() == 0)
				continue;
			if (key.Length() <= prefixLen)
				continue;
			string keyPrefix = key.Substring(0, prefixLen);
			if (keyPrefix != prefix)
				continue;
			count++;
		}
		return count;
	}
	
	//------------------------------------------------------------------------------------------------
	// Persistance chat : on ecrit toutes les conversations (cle + messages)
	void SaveChatsToDisk()
	{
		SCR_JsonSaveContext ctx = new SCR_JsonSaveContext();
		ctx.WriteValue("chat_count", m_Chats.Count());
		int cidx = 0;
		foreach (string key, array<ref JobBonPointChatMsg> conv : m_Chats)
		{
			if (!conv)
				continue;
			string p = "chat_" + cidx.ToString() + "_";
			ctx.WriteValue(p + "key", key);
			ctx.WriteValue(p + "msg_count", conv.Count());
			for (int mi = 0; mi < conv.Count(); mi++)
			{
				JobBonPointChatMsg msg = conv.Get(mi);
				if (!msg) continue;
				string m = p + "msg_" + mi.ToString() + "_";
				ctx.WriteValue(m + "ts", msg.m_Timestamp);
				ctx.WriteValue(m + "uid", msg.m_AuthorUID);
				ctx.WriteValue(m + "name", msg.m_AuthorDisplayName);
				ctx.WriteValue(m + "text", msg.m_Text);
			}
			cidx++;
		}
		ctx.SaveToFile(CHATS_PATH);
	}
	
	void LoadChatsFromDisk()
	{
		m_Chats.Clear();
		SCR_JsonLoadContext ctx = new SCR_JsonLoadContext();
		if (!ctx.LoadFromFile(CHATS_PATH))
			return;
		
		int count = 0;
		ctx.ReadValue("chat_count", count);
		for (int i = 0; i < count; i++)
		{
			string p = "chat_" + i.ToString() + "_";
			string key = "";
			ctx.ReadValue(p + "key", key);
			if (key == "")
				continue;
			int msgCount = 0;
			ctx.ReadValue(p + "msg_count", msgCount);
			
			array<ref JobBonPointChatMsg> conv = new array<ref JobBonPointChatMsg>();
			for (int mi = 0; mi < msgCount; mi++)
			{
				string m = p + "msg_" + mi.ToString() + "_";
				JobBonPointChatMsg msg = new JobBonPointChatMsg();
				ctx.ReadValue(m + "ts", msg.m_Timestamp);
				ctx.ReadValue(m + "uid", msg.m_AuthorUID);
				ctx.ReadValue(m + "name", msg.m_AuthorDisplayName);
				ctx.ReadValue(m + "text", msg.m_Text);
				if (msg.m_AuthorUID != "")
					conv.Insert(msg);
			}
			if (conv.Count() > 0)
				m_Chats.Set(key, conv);
		}
		Print(string.Format("[JobBonPointManager] %1 conversations chat chargees",
			m_Chats.Count()), LogLevel.NORMAL);
	}
	
	// Cleanup : supprime les conversations dont l annonce n existe plus.
	// Appele apres CleanupExpiredAds.
	void CleanupOrphanChats()
	{
		array<string> toRemove = new array<string>();
		foreach (string key, array<ref JobBonPointChatMsg> conv : m_Chats)
		{
			// La cle est de la forme "adId_buyerUID" : extrait adId
			int underscoreIdx = key.IndexOf("_");
			if (underscoreIdx <= 0)
			{
				toRemove.Insert(key);
				continue;
			}
			string adIdStr = key.Substring(0, underscoreIdx);
			int adId = adIdStr.ToInt();
			if (!m_Ads.Get(adId))
				toRemove.Insert(key);
		}
		foreach (string k : toRemove)
			m_Chats.Remove(k);
		if (toRemove.Count() > 0)
			SaveChatsToDisk();
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== EXPIRATION =====
	//------------------------------------------------------------------------------------------------
	// Nettoie les annonces expirees (>= 7 jours). Pour chaque annonce expiree,
	// genere un Purchase pour que le vendeur puisse recuperer son item.
	// Appele toutes les 60s via CallLater.
	void CleanupExpiredAds()
	{
		int now = System.GetUnixTime();
		array<int> toRemove = new array<int>();
		foreach (int adId, JobBonPointAd ad : m_Ads)
		{
			if (!ad)
				continue;
			if (now >= ad.m_ExpiresAt)
				toRemove.Insert(adId);
		}
		
		foreach (int adId : toRemove)
		{
			JobBonPointAd ad = m_Ads.Get(adId);
			if (!ad)
				continue;
			// Cree un Purchase pour que le vendeur recupere son item
			JobBonPointPurchase p = new JobBonPointPurchase();
			p.m_PurchaseId = m_NextPurchaseId;
			m_NextPurchaseId++;
			p.m_BuyerUID = ad.m_SellerUID;  // le vendeur lui-meme recupere son item
			p.m_PrefabName = ad.m_PrefabName;
			p.m_ItemTitle = ad.m_ItemTitle;
			p.m_SellerDisplayName = "Annonce expiree";
			p.m_BoughtAt = now;
			m_Purchases.Set(p.m_PurchaseId, p);
			
			m_Ads.Remove(adId);
			Print(string.Format("[JobBonPointManager] Annonce #%1 expiree, item restitue au vendeur %2",
				adId, ad.m_SellerUID), LogLevel.NORMAL);
		}
		
		if (toRemove.Count() > 0)
		{
			SaveToDisk();
			CleanupOrphanChats();
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== CAGNOTTE VILLE =====
	//------------------------------------------------------------------------------------------------
	// Ajoute des capsules a la cagnotte ville (taxes)
	void AddToTreasury(int amount)
	{
		if (amount <= 0)
			return;
		m_CityTreasury = m_CityTreasury + amount;
		SaveTreasury();
		Print(string.Format("[JobBonPointManager] Cagnotte ville +%1 (total : %2)",
			amount, m_CityTreasury), LogLevel.NORMAL);
	}
	
	int GetTreasury() { return m_CityTreasury; }
	
	//------------------------------------------------------------------------------------------------
	// ===== METHODES POUR LE MENU PRESIDENT =====
	//------------------------------------------------------------------------------------------------
	
	// Retourne le taux de taxe LeBonPoint actuel (en %)
	int GetTaxRatePercent() { return m_TaxRatePercent; }
	
	//------------------------------------------------------------------------------------------------
	// Modifie le taux de taxe LeBonPoint. Borne entre MIN et MAX.
	// Appele par le Menu President.
	// Retourne le nouveau taux applique (clampe si depasse les bornes).
	//------------------------------------------------------------------------------------------------
	int SetTaxRatePercent(int newRate)
	{
		if (newRate < MIN_TAX_RATE_PERCENT)
			newRate = MIN_TAX_RATE_PERCENT;
		if (newRate > MAX_TAX_RATE_PERCENT)
			newRate = MAX_TAX_RATE_PERCENT;
		m_TaxRatePercent = newRate;
		SaveTreasury();
		Print(string.Format("[JobBonPointManager] Taux de taxe modifie : %1%%",
			m_TaxRatePercent), LogLevel.NORMAL);
		return m_TaxRatePercent;
	}
	
	//------------------------------------------------------------------------------------------------
	// Retire un montant de la cagnotte municipale.
	// Retourne le montant reellement retire (peut etre inferieur si cagnotte insuffisante).
	// Garde-fou : le Menu President limite a 10% mais on accepte n importe quel montant ici
	// (la limite metier est dans le menu, pas dans le manager).
	//------------------------------------------------------------------------------------------------
	int WithdrawFromTreasury(int amount)
	{
		if (amount <= 0) return 0;
		if (amount > m_CityTreasury)
			amount = m_CityTreasury;
		m_CityTreasury = m_CityTreasury - amount;
		SaveTreasury();
		Print(string.Format("[JobBonPointManager] Retrait cagnotte : -%1 (reste : %2)",
			amount, m_CityTreasury), LogLevel.NORMAL);
		return amount;
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== PERSISTANCE =====
	//------------------------------------------------------------------------------------------------
	
	void SaveToDisk()
	{
		// === ANNONCES ===
		SCR_JsonSaveContext ctxAds = new SCR_JsonSaveContext();
		ctxAds.WriteValue("next_ad_id", m_NextAdId);
		ctxAds.WriteValue("ad_count", m_Ads.Count());
		int idx = 0;
		foreach (int adId, JobBonPointAd ad : m_Ads)
		{
			if (!ad)
				continue;
			string p = "ad_" + idx.ToString() + "_";
			ctxAds.WriteValue(p + "id", ad.m_AdId);
			ctxAds.WriteValue(p + "seller_uid", ad.m_SellerUID);
			ctxAds.WriteValue(p + "seller_name", ad.m_SellerDisplayName);
			ctxAds.WriteValue(p + "prefab", ad.m_PrefabName);
			ctxAds.WriteValue(p + "title", ad.m_ItemTitle);
			ctxAds.WriteValue(p + "desc", ad.m_ItemDescription);
			ctxAds.WriteValue(p + "price", ad.m_Price);
			ctxAds.WriteValue(p + "created_at", ad.m_CreatedAt);
			ctxAds.WriteValue(p + "expires_at", ad.m_ExpiresAt);
			idx++;
		}
		ctxAds.SaveToFile(ADS_PATH);
		
		// === ACHATS ===
		SCR_JsonSaveContext ctxPur = new SCR_JsonSaveContext();
		ctxPur.WriteValue("next_purchase_id", m_NextPurchaseId);
		ctxPur.WriteValue("purchase_count", m_Purchases.Count());
		int pidx = 0;
		foreach (int purchaseId, JobBonPointPurchase p : m_Purchases)
		{
			if (!p)
				continue;
			string pp = "purchase_" + pidx.ToString() + "_";
			ctxPur.WriteValue(pp + "id", p.m_PurchaseId);
			ctxPur.WriteValue(pp + "buyer_uid", p.m_BuyerUID);
			ctxPur.WriteValue(pp + "prefab", p.m_PrefabName);
			ctxPur.WriteValue(pp + "title", p.m_ItemTitle);
			ctxPur.WriteValue(pp + "seller_name", p.m_SellerDisplayName);
			ctxPur.WriteValue(pp + "bought_at", p.m_BoughtAt);
			pidx++;
		}
		ctxPur.SaveToFile(PURCHASES_PATH);
	}
	
	void SaveTreasury()
	{
		SCR_JsonSaveContext ctx = new SCR_JsonSaveContext();
		ctx.WriteValue("treasury", m_CityTreasury);
		// Sauvegarde aussi le taux de taxe modifiable par le President
		ctx.WriteValue("tax_rate", m_TaxRatePercent);
		ctx.SaveToFile(TREASURY_PATH);
	}
	
	void LoadFromDisk()
	{
		m_Ads.Clear();
		m_Purchases.Clear();
		
		// === ANNONCES ===
		SCR_JsonLoadContext ctxAds = new SCR_JsonLoadContext();
		if (ctxAds.LoadFromFile(ADS_PATH))
		{
			ctxAds.ReadValue("next_ad_id", m_NextAdId);
			int count = 0;
			ctxAds.ReadValue("ad_count", count);
			for (int i = 0; i < count; i++)
			{
				string p = "ad_" + i.ToString() + "_";
				JobBonPointAd ad = new JobBonPointAd();
				ctxAds.ReadValue(p + "id", ad.m_AdId);
				ctxAds.ReadValue(p + "seller_uid", ad.m_SellerUID);
				ctxAds.ReadValue(p + "seller_name", ad.m_SellerDisplayName);
				ctxAds.ReadValue(p + "prefab", ad.m_PrefabName);
				ctxAds.ReadValue(p + "title", ad.m_ItemTitle);
				ctxAds.ReadValue(p + "desc", ad.m_ItemDescription);
				ctxAds.ReadValue(p + "price", ad.m_Price);
				ctxAds.ReadValue(p + "created_at", ad.m_CreatedAt);
				ctxAds.ReadValue(p + "expires_at", ad.m_ExpiresAt);
				if (ad.m_AdId > 0)
					m_Ads.Set(ad.m_AdId, ad);
			}
			Print(string.Format("[JobBonPointManager] %1 annonces chargees", m_Ads.Count()),
				LogLevel.NORMAL);
		}
		
		// === ACHATS ===
		SCR_JsonLoadContext ctxPur = new SCR_JsonLoadContext();
		if (ctxPur.LoadFromFile(PURCHASES_PATH))
		{
			ctxPur.ReadValue("next_purchase_id", m_NextPurchaseId);
			int count = 0;
			ctxPur.ReadValue("purchase_count", count);
			for (int i = 0; i < count; i++)
			{
				string pp = "purchase_" + i.ToString() + "_";
				JobBonPointPurchase p = new JobBonPointPurchase();
				ctxPur.ReadValue(pp + "id", p.m_PurchaseId);
				ctxPur.ReadValue(pp + "buyer_uid", p.m_BuyerUID);
				ctxPur.ReadValue(pp + "prefab", p.m_PrefabName);
				ctxPur.ReadValue(pp + "title", p.m_ItemTitle);
				ctxPur.ReadValue(pp + "seller_name", p.m_SellerDisplayName);
				ctxPur.ReadValue(pp + "bought_at", p.m_BoughtAt);
				if (p.m_PurchaseId > 0)
					m_Purchases.Set(p.m_PurchaseId, p);
			}
			Print(string.Format("[JobBonPointManager] %1 achats en attente chargees",
				m_Purchases.Count()), LogLevel.NORMAL);
		}
		
		// === TREASURY ===
		SCR_JsonLoadContext ctxTr = new SCR_JsonLoadContext();
		if (ctxTr.LoadFromFile(TREASURY_PATH))
		{
			ctxTr.ReadValue("treasury", m_CityTreasury);
			Print(string.Format("[JobBonPointManager] Cagnotte ville : %1", m_CityTreasury),
				LogLevel.NORMAL);
			// Charge le taux de taxe (compat retroactif : si absent, garde la valeur par defaut)
			int loadedTaxRate = -1;
			ctxTr.ReadValue("tax_rate", loadedTaxRate);
			if (loadedTaxRate >= MIN_TAX_RATE_PERCENT && loadedTaxRate <= MAX_TAX_RATE_PERCENT)
			{
				m_TaxRatePercent = loadedTaxRate;
				Print(string.Format("[JobBonPointManager] Taux de taxe charge : %1%%", m_TaxRatePercent),
					LogLevel.NORMAL);
			}
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Charge la blacklist. Si fichier inexistant, cree un exemple.
	void LoadBlacklist()
	{
		m_BlacklistPrefabs.Clear();
		SCR_JsonLoadContext ctx = new SCR_JsonLoadContext();
		if (!ctx.LoadFromFile(BLACKLIST_PATH))
		{
			// Cree un fichier exemple
			CreateExampleBlacklist();
			return;
		}
		ctx.ReadValue("blacklist", m_BlacklistPrefabs);
		Print(string.Format("[JobBonPointManager] %1 items blacklists charges",
			m_BlacklistPrefabs.Count()), LogLevel.NORMAL);
	}
	
	void CreateExampleBlacklist()
	{
		SCR_JsonSaveContext ctx = new SCR_JsonSaveContext();
		array<string> example = new array<string>();
		example.Insert("REPLACE_BY_ADMIN_PREFAB_TO_BLACKLIST");
		ctx.WriteValue("blacklist", example);
		ctx.SaveToFile(BLACKLIST_PATH);
		Print(string.Format("[JobBonPointManager] Fichier blacklist exemple cree : %1",
			BLACKLIST_PATH), LogLevel.NORMAL);
	}
}
