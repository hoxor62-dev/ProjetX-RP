//------------------------------------------------------------------------------------------------
// JobPhoneUseAction.c
// Action "Utiliser le telephone" sur le prefab iPhone15.
// Declenchee par le maintien de R (configure dans le ActionsManagerComponent du prefab iPhone15).
// A attacher via l'ActionsManagerComponent du prefab Iphone15 (override) :
//   {F01C74E1B289DFF2}Prefabs/Items/InventoryItems/Electronics/Iphone15.et
//
// Configuration dans Workbench :
// - Override le prefab vanilla
// - Configurer l'ActionsManagerComponent avec l'action JobPhoneUseAction
// - Bind sur maintien R (action context approprie)
//------------------------------------------------------------------------------------------------

class JobPhoneUseAction : ScriptedUserAction
{
	//------------------------------------------------------------------------------------------------
	override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
	{
		if (!pUserEntity)
			return;
		
		// Securite: seul le joueur local doit ouvrir le menu (sinon ouvre chez tous les clients)
		PlayerController localPC = GetGame().GetPlayerController();
		if (!localPC)
			return;
		IEntity localEntity = localPC.GetControlledEntity();
		if (localEntity != pUserEntity)
			return;
		
		// Ouvre le menu telephone
		GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.JobPhoneMenu);
	}
	
	//------------------------------------------------------------------------------------------------
	override bool CanBeShownScript(IEntity user)
	{
		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	override bool CanBePerformedScript(IEntity user)
	{
		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	override bool GetActionNameScript(out string outName)
	{
		outName = "Maintenir pour utiliser le telephone";
		return true;
	}
}