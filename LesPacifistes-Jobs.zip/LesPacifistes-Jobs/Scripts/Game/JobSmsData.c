//------------------------------------------------------------------------------------------------
// JobSmsData.c
// Structures de donnees du systeme SMS RP.
//
// Chaque joueur a son propre fichier JSON dans $profile:LesPacifistesJobs/sms/UID.json
// contenant TOUS ses SMS (recus et envoyes).
//
// Limite globale : 200 SMS max par joueur (rotation : on supprime les plus vieux).
//------------------------------------------------------------------------------------------------

class JobSmsMessage
{
	int m_Timestamp;            // Unix timestamp d'envoi
	string m_FromUID;           // UID expediteur
	string m_FromDisplayName;   // Nom affiche au moment de l'envoi (cache pour eviter relookup)
	string m_ToUID;             // UID destinataire
	string m_ToDisplayName;     // Nom affiche destinataire au moment de l'envoi
	string m_Content;           // Texte du message (max 150 chars)
	bool m_Read;                // True si le destinataire a lu le message
	
	void JobSmsMessage()
	{
		m_Read = false;
	}
}

class JobSmsInbox
{
	ref array<ref JobSmsMessage> m_Messages;
	
	void JobSmsInbox()
	{
		m_Messages = new array<ref JobSmsMessage>();
	}
}

class JobSmsData
{
	const int MAX_MESSAGE_LENGTH = 150;     // chars max par message
	const int MAX_TOTAL_MESSAGES = 200;     // limite par joueur (tous contacts confondus)
}
