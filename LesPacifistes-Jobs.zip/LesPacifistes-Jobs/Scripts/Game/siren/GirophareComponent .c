class GirophareComponentClass : ScriptComponentClass {}

class GirophareComponent : ScriptComponent
{
    protected ref array<LightEntity> m_aLights = {};
    protected bool m_bActive = false;
    protected bool m_bFlashState = false;
    protected float m_fTimer = 0;
    protected float m_fInterval = 0.15;
    protected bool m_bSoundPlaying = false;
    protected int m_iSoundDurationMs = 2000;

    // Distance max d'audibilité du son (en mètres) - carré pour éviter sqrt
    protected const float SIREN_MAX_DISTANCE_SQ = 10000.0; // 100m * 100m

    override void OnPostInit(IEntity owner)
    {
        super.OnPostInit(owner);
        CollectLights(owner);

        // Éteindre toutes les lumières au démarrage
        foreach (LightEntity light : m_aLights)
        {
            if (light)
                light.SetEnabled(false);
        }

        // Seul le serveur pilote le rythme du flash (autoritatif)
        if (Replication.IsServer())
        {
            SetEventMask(owner, EntityEvent.FRAME);
        }
    }

    protected void CollectLights(IEntity owner)
    {
        IEntity child = owner.GetChildren();
        while (child)
        {
            LightEntity light = LightEntity.Cast(child);
            if (light)
                m_aLights.Insert(light);
            child = child.GetSibling();
        }
    }

    // ============================================================
    // ACTIVATION / DÉSACTIVATION
    // ============================================================

    void ToggleGirophare()
    {
        Rpc(RpcAsk_SetActive, !m_bActive);
    }

    [RplRpc(RplChannel.Reliable, RplRcver.Server)]
    void RpcAsk_SetActive(bool active)
    {
        // Serveur applique l'état localement + broadcast à tous les clients
        m_bActive = active;
        m_fTimer = 0;
        m_bFlashState = false;

        Rpc(RpcDo_SetActive, active);
        ApplySetActive(active);
    }

    [RplRpc(RplChannel.Reliable, RplRcver.Broadcast)]
    void RpcDo_SetActive(bool active)
    {
        // Clients : applique l'état
        m_bActive = active;
        m_fTimer = 0;
        m_bFlashState = false;
        ApplySetActive(active);
    }

    protected void ApplySetActive(bool active)
    {
        if (active)
        {
            StartSirenLoop();
        }
        else
        {
            StopSirenLoop();
            foreach (LightEntity light : m_aLights)
            {
                if (light)
                    light.SetEnabled(false);
            }
        }
    }

    // ============================================================
    // FLASH (piloté par le serveur, broadcast à tous les clients)
    // ============================================================

    override void EOnFrame(IEntity owner, float timeSlice)
    {
        // Seul le serveur arrive ici (cf. OnPostInit)
        if (!m_bActive)
            return;

        m_fTimer += timeSlice;
        if (m_fTimer >= m_fInterval)
        {
            m_fTimer = 0;
            m_bFlashState = !m_bFlashState;

            // Applique localement (serveur listen)
            ApplyFlashState(m_bFlashState);
            // Broadcast à tous les clients
            Rpc(RpcDo_SetFlash, m_bFlashState);
        }
    }

    [RplRpc(RplChannel.Unreliable, RplRcver.Broadcast)]
    void RpcDo_SetFlash(bool flashState)
    {
        m_bFlashState = flashState;
        ApplyFlashState(flashState);
    }

    protected void ApplyFlashState(bool flashState)
    {
        int count = m_aLights.Count();
        for (int i = 0; i < count; i++)
        {
            LightEntity light = m_aLights[i];
            if (!light)
                continue;
            bool on = (i % 2 == 0) == flashState;
            light.SetEnabled(on);
        }
    }

    // ============================================================
    // SON (local, limité à 100m du joueur)
    // ============================================================

    protected void StartSirenLoop()
    {
        if (m_bSoundPlaying)
            return;
        m_bSoundPlaying = true;
        PlaySirenOnce();
    }

    protected void PlaySirenOnce()
    {
        if (!m_bActive)
        {
            m_bSoundPlaying = false;
            return;
        }

        if (IsLocalPlayerInRange())
        {
            AudioSystem.PlaySound("{5A560A30332D9378}Scripts/Game/siren/sirenpolice.wav");
        }

        GetGame().GetCallqueue().CallLater(PlaySirenOnce, m_iSoundDurationMs, false);
    }

    protected bool IsLocalPlayerInRange()
    {
        IEntity owner = GetOwner();
        if (!owner)
            return false;

        PlayerController pc = GetGame().GetPlayerController();
        if (!pc)
            return false;

        IEntity localPlayer = pc.GetControlledEntity();
        if (!localPlayer)
            return false;

        float distSq = vector.DistanceSq(owner.GetOrigin(), localPlayer.GetOrigin());
        return distSq <= SIREN_MAX_DISTANCE_SQ;
    }

    protected void StopSirenLoop()
    {
        m_bSoundPlaying = false;
        GetGame().GetCallqueue().Remove(PlaySirenOnce);
    }
}