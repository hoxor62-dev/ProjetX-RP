class GirophareAction : ScriptedUserAction
{
    override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
    {
        GirophareComponent giro = GirophareComponent.Cast(
            pOwnerEntity.FindComponent(GirophareComponent)
        );
        if (giro)
            giro.ToggleGirophare();
    }

    override bool CanBeShownScript(IEntity user)
    {
        return true;
    }

    override bool CanBePerformedScript(IEntity user)
    {
        return true;
    }

    override bool HasLocalEffectOnlyScript()
    {
        return false;
    }
}
