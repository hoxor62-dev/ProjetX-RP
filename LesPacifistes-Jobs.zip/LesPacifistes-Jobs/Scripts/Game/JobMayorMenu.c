//------------------------------------------------------------------------------------------------
// JobMayorMenu.c
// Menu d'interaction avec le PNJ Maire.
// 3 options :
//   1) Ecouter la presentation du serveur (joue un .wav local)
//   2) Ecouter les regles du serveur (joue un .wav local)
//   3) Obtenir la recompense de debut (250c, one-shot par UID Bohemia)
//------------------------------------------------------------------------------------------------

class JobMayorMenu : ChimeraMenuBase
{
	Widget m_RootWidget;
	ButtonWidget m_BtnPresentation;
	ButtonWidget m_BtnRules;
	ButtonWidget m_BtnReward;
	TextWidget m_BtnRewardText;
	ButtonWidget m_BtnIdentity;
	ButtonWidget m_BtnCreateCompany;
	ButtonWidget m_BtnInvitations;
	ButtonWidget m_CloseButton;
	
	// GUIDs des fichiers .wav (a remplir par le boss dans Workbench)
	const ResourceName WAV_PRESENTATION = "{4AFFCA8D3B23D496}Sounds/maire/bienvenue.wav";
	const ResourceName WAV_RULES = "{D98D1413AAC677F2}Sounds/maire/regles.wav";
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuOpen()
	{
		super.OnMenuOpen();
		m_RootWidget = GetRootWidget();
		if (!m_RootWidget)
			return;
		
		m_BtnPresentation = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnPresentation"));
		m_BtnRules = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnRules"));
		m_BtnReward = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnReward"));
		m_BtnRewardText = TextWidget.Cast(m_RootWidget.FindAnyWidget("BtnRewardText"));
		m_BtnIdentity = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnIdentity"));
		m_BtnCreateCompany = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnCreateCompany"));
		m_BtnInvitations = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnInvitations"));
		m_CloseButton = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("CloseButton"));
		
		AttachButton(m_BtnPresentation, "presentation");
		AttachButton(m_BtnRules, "rules");
		AttachButton(m_BtnReward, "reward");
		AttachButton(m_BtnIdentity, "identity");
		AttachButton(m_BtnCreateCompany, "createcompany");
		AttachButton(m_BtnInvitations, "invitations");
		AttachButton(m_CloseButton, "close");
		
		if (m_BtnPresentation)
			GetGame().GetWorkspace().SetFocusedWidget(m_BtnPresentation);
	}
	
	//------------------------------------------------------------------------------------------------
	void AttachButton(ButtonWidget btn, string action)
	{
		if (!btn)
			return;
		MayorMenuClickHandler h = new MayorMenuClickHandler();
		h.m_Menu = this;
		h.m_Action = action;
		btn.AddHandler(h);
		JobFocusHandler.Attach(btn);
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuUpdate(float tDelta)
	{
		super.OnMenuUpdate(tDelta);
		if (GetGame().GetInputManager().GetActionValue("MenuBack") > 0.5)
		{
			CloseMenuInternal();
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void OnButtonClicked(string action)
	{
		if (action == "close")
		{
			CloseMenuInternal();
			return;
		}
		
		if (action == "presentation")
		{
			PlayLocalSound(WAV_PRESENTATION);
			LP_NotificationManager.Show(
				"Lecture en cours...",
				"Presentation du serveur",
				4);
			CloseMenuInternal();
			return;
		}
		
		if (action == "rules")
		{
			PlayLocalSound(WAV_RULES);
			LP_NotificationManager.Show(
				"Lecture en cours...",
				"Regles du serveur",
				4);
			CloseMenuInternal();
			return;
		}
		
		if (action == "reward")
		{
			// Demande au serveur la recompense
			PlayerController pc = GetGame().GetPlayerController();
			if (!pc)
				return;
			JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
			if (!jpc)
				return;
			jpc.ClientAskMayorReward();
			CloseMenuInternal();
			return;
		}
		
		if (action == "createcompany")
		{
			// Ouvre le menu de creation d entreprise (ferme d abord le menu maire)
			MenuManager mm = GetGame().GetMenuManager();
			mm.CloseMenu(this);
			mm.OpenMenu(ChimeraMenuPreset.JobCreateCompanyMenu);
			return;
		}
		
		if (action == "invitations")
		{
			// Demande au serveur les invitations en attente. Le serveur ouvre le menu
			// si invitation, sinon notif chat "Aucune invitation".
			PlayerController pc = GetGame().GetPlayerController();
			if (!pc) return;
			JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
			if (!jpc) return;
			jpc.ClientAskOpenInvitations();
			CloseMenuInternal();
			return;
		}
		
		if (action == "identity")
		{
			// Ouvre le menu de creation d'identite
			// Ferme d'abord le menu maire pour que les 2 ne soient pas empiles
			MenuManager mm = GetGame().GetMenuManager();
			GetGame().GetMenuManager().CloseMenu(this);
			mm.OpenMenu(ChimeraMenuPreset.JobCreateIdentityMenu);
			return;
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Joue un son en local (cote client uniquement)
	//------------------------------------------------------------------------------------------------
	void PlayLocalSound(ResourceName soundResource)
	{
		if (!soundResource)
			return;
		AudioSystem.PlaySound(soundResource);
	}
	
	//------------------------------------------------------------------------------------------------
	void CloseMenuInternal()
	{
		GetGame().GetMenuManager().CloseMenu(this);
	}
}

class MayorMenuClickHandler : ScriptedWidgetEventHandler
{
	JobMayorMenu m_Menu;
	string m_Action;
	
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu)
			m_Menu.OnButtonClicked(m_Action);
		return true;
	}
}
