//------------------------------------------------------------------------------------------------
// JobMineralsBuyerComponent.c
// A attacher sur les PNJ qui achetent les minerais transformes.
//
// Configuration dans Workbench :
//  - PNJ Mineur                    : m_MineralType = 1 (ROCK)
//  - PNJ Bucheron                  : m_MineralType = 4 (Bois/Planches)
//  - PNJ Agriculteur (jus + farine): m_MineralType = 101 (Agriculteur)
//  - DrugDealer (cannabis+cocaine) : m_MineralType = 100 (Toutes drogues)
//
// Note : les valeurs 100 et 101 ne sont PAS des EMineralType (qui va de 0 a 6),
// ce sont des codes speciaux pour regrouper plusieurs types dans un seul menu.
//------------------------------------------------------------------------------------------------

[ComponentEditorProps(category: "LesPacifistesJobs", description: "PNJ acheteur de minerais transformes")]
class JobMineralsBuyerComponentClass : ScriptComponentClass
{
}

class JobMineralsBuyerComponent : ScriptComponent
{
	[Attribute(defvalue: "1", uiwidget: UIWidgets.ComboBox, desc: "Type principal de minerai achete",
		enums: { ParamEnum("Roche", "1"), ParamEnum("Cannabis", "2"), ParamEnum("Cocaine", "3"),
			ParamEnum("Bois (planches)", "4"), ParamEnum("Pomme (jus)", "5"),
			ParamEnum("Ble (farine)", "6"),
			ParamEnum("Toutes drogues (Cannabis+Cocaine)", "100"),
			ParamEnum("Agriculteur (Jus+Farine)", "101") })]
	int m_MineralType;
	
	//------------------------------------------------------------------------------------------------
	int GetMineralType()
	{
		return m_MineralType;
	}
}
