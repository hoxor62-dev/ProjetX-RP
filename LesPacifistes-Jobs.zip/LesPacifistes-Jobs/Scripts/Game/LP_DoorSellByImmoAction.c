//------------------------------------------------------------------------------------------------
// LP_DoorSellByImmoAction.c
// Action "Vendre l acces" - visible UNIQUEMENT si :
//   - le joueur local a le metier VENDEUR_IMMOBILIER (JobCharacterJobComponent)
//   - la porte n a pas encore de proprio (LP_DoorAccessComponent.HasOwner == false)
//------------------------------------------------------------------------------------------------

class LP_DoorSellByImmoAction : ScriptedUserAction
{
	override bool CanBeShownScript(IEntity user)
	{
		if (!user) return false;
		
		// Check metier local
		JobCharacterJobComponent jobComp = JobCharacterJobComponent.Cast(
			user.FindComponent(JobCharacterJobComponent));
		if (!jobComp) return false;
		if (jobComp.GetJob() != EJobType.VENDEUR_IMMOBILIER) return false;
		
		// Check : porte pas encore vendue
		IEntity door = GetOwner();
		if (!door) return false;
		LP_DoorAccessComponent access = LP_DoorAccessComponent.Cast(
			door.FindComponent(LP_DoorAccessComponent));
		if (!access) return false;
		return !access.HasOwner();
	}
	
	override bool CanBePerformedScript(IEntity user) { return CanBeShownScript(user); }
	
	override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
	{
		PlayerController pc = PlayerController.Cast(GetGame().GetPlayerController());
		if (!pc) return;
		if (pUserEntity != pc.GetControlledEntity()) return;
		
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		
		RplComponent rpl = RplComponent.Cast(pOwnerEntity.FindComponent(RplComponent));
		if (!rpl) return;
		
		jpc.ClientAskOpenDoorSellMenu(rpl.Id(), false);
	}
}
