//------------------------------------------------------------------------------------------------
// JobHarvestAction.c
// UserAction "Recolter" sur une plante avec JobHarvestComponent
//------------------------------------------------------------------------------------------------

class JobHarvestAction : ScriptedUserAction
{
	//------------------------------------------------------------------------------------------------
	override bool CanBeShownScript(IEntity user)
	{
		JobHarvestComponent harvest = JobHarvestComponent.Cast(GetOwner().FindComponent(JobHarvestComponent));
		return (harvest != null);
	}
	
	//------------------------------------------------------------------------------------------------
	override bool CanBePerformedScript(IEntity user)
	{
		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	override bool GetActionNameScript(out string outName)
	{
		JobHarvestComponent harvest = JobHarvestComponent.Cast(GetOwner().FindComponent(JobHarvestComponent));
		if (!harvest)
			return false;
		
		EDrugType drug = harvest.GetDrugType();
		outName = string.Format("Recolter %1", JobDrugSystem.GetDrugLabel(drug));
		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
	{
		// GARDE MULTIJOUEUR
		IEntity localPlayer = SCR_PlayerController.GetLocalControlledEntity();
		if (!localPlayer || pUserEntity != localPlayer)
			return;
		
		JobHarvestComponent harvest = JobHarvestComponent.Cast(pOwnerEntity.FindComponent(JobHarvestComponent));
		if (!harvest)
			return;
		
		EDrugType drug = harvest.GetDrugType();
		
		// Recupere le RplId de la plante (pour pouvoir la retrouver cote serveur)
		RplComponent rpl = RplComponent.Cast(pOwnerEntity.FindComponent(RplComponent));
		RplId plantRplId = RplId.Invalid();
		if (rpl)
			plantRplId = rpl.Id();
		
		// Envoie la RPC via le JobPlayerComponent local
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc)
			return;
		
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc)
			return;
		
		jpc.ClientAskHarvest(drug, plantRplId);
	}
}
