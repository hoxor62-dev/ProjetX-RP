//------------------------------------------------------------------------------------------------
// JobSelectionMenu.c
// Menu UI de selection de metier (inspire CapsuleShopMenu).
// Affiche la liste des metiers disponibles avec description et bouton de selection.
// Utilise un FrameWidget avec FrameSlot.SetPos/SetSize (pas de ScrollLayoutWidget dynamique).
//------------------------------------------------------------------------------------------------

class JobSelectionMenu : ChimeraMenuBase
{
	const string LAYOUT_PATH = "{3EB68FABFA5BD6D9}UI/layouts/JobSelectionMenu.layout";
	const string ENTRY_LAYOUT_PATH = "{94D57C3124882310}UI/layouts/JobEntry.layout";
	
	Widget m_RootWidget;
	Widget m_EntriesContainer;
	TextWidget m_TitleText;
	ButtonWidget m_CloseButton;
	
	// Liste des metiers a afficher
	ref array<EJobType> m_AvailableJobs;
	
	// RplId du PNJ (pour la RPC de confirmation)
	RplId m_NpcRplId;
	
	// Flag "menu avance" (ajoute un warning "Prive / Admin")
	bool m_IsAdvancedMenu;
	
	// Cache des boutons crees (pour click handling)
	ref map<ButtonWidget, int> m_ButtonToJobInt = new map<ButtonWidget, int>();
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuOpen()
	{
		super.OnMenuOpen();
		m_RootWidget = GetRootWidget();
		if (!m_RootWidget)
			return;
		
		m_EntriesContainer = m_RootWidget.FindAnyWidget("EntriesContainer");
		m_TitleText = TextWidget.Cast(m_RootWidget.FindAnyWidget("TitleText"));
		m_CloseButton = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("CloseButton"));
		
		if (m_CloseButton)
		{
			ClickHandler clickHandler = new ClickHandler();
			clickHandler.m_Menu = this;
			clickHandler.m_IsClose = true;
			m_CloseButton.AddHandler(clickHandler);
			JobFocusHandler.Attach(m_CloseButton);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Initialisation depuis JobTalkAction.PerformAction
	//------------------------------------------------------------------------------------------------
	void Initialize(array<EJobType> jobs, RplId npcRplId, bool isAdvanced)
	{
		m_AvailableJobs = jobs;
		m_NpcRplId = npcRplId;
		m_IsAdvancedMenu = isAdvanced;
		
		if (m_TitleText)
		{
			if (isAdvanced)
				m_TitleText.SetText("Recrutement - Metiers speciaux");
			else
				m_TitleText.SetText("Agence d'emploi - Les Pacifistes");
		}
		
		BuildEntries();
	}
	
	//------------------------------------------------------------------------------------------------
	void BuildEntries()
	{
		if (!m_EntriesContainer || !m_AvailableJobs)
			return;
		
		WorkspaceWidget ws = GetGame().GetWorkspace();
		
		// Entree par metier (hauteur alignee avec JobEntry.layout)
		const int ENTRY_HEIGHT = 100;
		const int ENTRY_PADDING = 10;
		
		ButtonWidget firstButton = null;
		
		for (int i = 0; i < m_AvailableJobs.Count(); i++)
		{
			EJobType job = m_AvailableJobs.Get(i);
			
			Widget entry = ws.CreateWidgets(ENTRY_LAYOUT_PATH, m_EntriesContainer);
			if (!entry)
				continue;
			
			// Positionnement dans le FrameWidget
			FrameSlot.SetPos(entry, 0, i * (ENTRY_HEIGHT + ENTRY_PADDING));
			FrameSlot.SetSize(entry, 660, ENTRY_HEIGHT);
			
			// Nom du metier
			TextWidget nameW = TextWidget.Cast(entry.FindAnyWidget("JobName"));
			if (nameW)
				nameW.SetText(JobData.GetJobLabel(job));
			
			// Description
			TextWidget descW = TextWidget.Cast(entry.FindAnyWidget("JobDescription"));
			if (descW)
				descW.SetText(JobData.GetJobDescription(job));
			
			// Bouton "Choisir"
			ButtonWidget btn = ButtonWidget.Cast(entry.FindAnyWidget("SelectButton"));
			if (btn)
			{
				m_ButtonToJobInt.Set(btn, job);
				ClickHandler ch = new ClickHandler();
				ch.m_Menu = this;
				ch.m_IsClose = false;
				btn.AddHandler(ch);
				JobFocusHandler.Attach(btn);
				
				if (!firstButton)
					firstButton = btn;
			}
		}
		
		// Focus clavier/gamepad sur le premier bouton (navigation immediate)
		if (firstButton)
			GetGame().GetWorkspace().SetFocusedWidget(firstButton);
	}
	
	//------------------------------------------------------------------------------------------------
	// Handler de click: appele par ClickHandler quand un bouton est clique
	//------------------------------------------------------------------------------------------------
	void OnEntryClicked(ButtonWidget btn)
	{
		int jobInt;
		if (!m_ButtonToJobInt.Find(btn, jobInt))
			return;
		
		EJobType selectedJob = jobInt;
		ConfirmSelection(selectedJob);
	}
	
	//------------------------------------------------------------------------------------------------
	void ConfirmSelection(EJobType selectedJob)
	{
		// Envoie la RPC via le JobPlayerComponent du joueur local
		// (le PlayerController est owner du composant = RPC passe correctement en multi)
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc)
		{
			Print("[JobSelectionMenu] Local PlayerController introuvable", LogLevel.WARNING);
			return;
		}
		
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc)
		{
			Print("[JobSelectionMenu] JobPlayerComponent manquant sur le PlayerController local",
				LogLevel.WARNING);
			return;
		}
		
		jpc.ClientAskSelectJob(selectedJob);
		
		// Ferme le menu
		CloseMenuInternal();
	}
	
	//------------------------------------------------------------------------------------------------
	void CloseMenuInternal()
	{
		GetGame().GetMenuManager().CloseMenu(this);
	}
}

//------------------------------------------------------------------------------------------------
// Handler de click simple (pour boutons)
//------------------------------------------------------------------------------------------------
class ClickHandler : ScriptedWidgetEventHandler
{
	JobSelectionMenu m_Menu;
	bool m_IsClose;
	
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (!m_Menu)
			return false;
		
		if (m_IsClose)
		{
			m_Menu.CloseMenuInternal();
			return true;
		}
		
		ButtonWidget btn = ButtonWidget.Cast(w);
		if (btn)
			m_Menu.OnEntryClicked(btn);
		return true;
	}
}
