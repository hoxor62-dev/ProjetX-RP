//------------------------------------------------------------------------------------------------
// JobGangCreateMenu.c
// Menu affiche quand un voyou SANS gang clique sur "Gerer mon Gang".
// Permet de saisir un nom et creer le gang (cout 30000 capsules).
//------------------------------------------------------------------------------------------------

class JobGangCreateMenu : ChimeraMenuBase
{
	const string LAYOUT_PATH = "{848175C6542E3BD8}UI/layouts/JobGangCreateMenu.layout";
	
	Widget m_RootWidget;
	TextWidget m_TitleText;
	TextWidget m_InfoText;
	EditBoxWidget m_NameInput;
	ButtonWidget m_CreateButton;
	ButtonWidget m_CloseButton;
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuOpen()
	{
		super.OnMenuOpen();
		m_RootWidget = GetRootWidget();
		if (!m_RootWidget)
			return;
		
		m_TitleText = TextWidget.Cast(m_RootWidget.FindAnyWidget("TitleText"));
		m_InfoText = TextWidget.Cast(m_RootWidget.FindAnyWidget("InfoText"));
		m_NameInput = EditBoxWidget.Cast(m_RootWidget.FindAnyWidget("NameInput"));
		m_CreateButton = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("CreateButton"));
		m_CloseButton = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("CloseButton"));
		
		if (m_CreateButton)
		{
			GangCreateClickHandler ch = new GangCreateClickHandler();
			ch.m_Menu = this;
			ch.m_Action = "create";
			m_CreateButton.AddHandler(ch);
			JobFocusHandler.Attach(m_CreateButton);
		}
		if (m_CloseButton)
		{
			GangCreateClickHandler ch = new GangCreateClickHandler();
			ch.m_Menu = this;
			ch.m_Action = "close";
			m_CloseButton.AddHandler(ch);
			JobFocusHandler.Attach(m_CloseButton);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuUpdate(float tDelta)
	{
		super.OnMenuUpdate(tDelta);
		if (GetGame().GetInputManager().GetActionValue("MenuBack") > 0.5)
			CloseMenuInternal();
	}
	
	//------------------------------------------------------------------------------------------------
	void Initialize()
	{
		if (m_TitleText)
			m_TitleText.SetText("Creer un Gang");
		if (m_InfoText)
			m_InfoText.SetText("Entrez le nom de votre gang.\nCout de creation : 30000 capsules.");
	}
	
	//------------------------------------------------------------------------------------------------
	void OnCreateClicked()
	{
		if (!m_NameInput)
			return;
		string gangName = m_NameInput.GetText();
		if (gangName == "")
			return;
		
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc)
			return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc)
			return;
		
		jpc.ClientAskCreateGang(gangName);
		CloseMenuInternal();
	}
	
	//------------------------------------------------------------------------------------------------
	void CloseMenuInternal()
	{
		GetGame().GetMenuManager().CloseMenu(this);
	}
}

//------------------------------------------------------------------------------------------------
class GangCreateClickHandler : ScriptedWidgetEventHandler
{
	JobGangCreateMenu m_Menu;
	string m_Action;
	
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (!m_Menu)
			return false;
		if (m_Action == "close")
		{
			m_Menu.CloseMenuInternal();
			return true;
		}
		if (m_Action == "create")
		{
			m_Menu.OnCreateClicked();
			return true;
		}
		return false;
	}
}
