//------------------------------------------------------------------------------------------------
// JobRetrieveVehicleAction.c
// Action UserAction "Recuperer mon vehicule" sur le PNJ garage virtuel.
// Au clic : envoie une RPC au serveur pour recuperer la liste des vehicules stockes
// du joueur. Le serveur repond et le client ouvre alors JobVirtualGarageMenu.
//------------------------------------------------------------------------------------------------

class JobRetrieveVehicleAction : ScriptedUserAction
{
	//------------------------------------------------------------------------------------------------
	override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
	{
		if (!pOwnerEntity)
			return;
		
		// IMPORTANT (dedicated server) : PerformAction s execute sur TOUS les clients qui
		// voient l action localement. On filtre pour que seul le joueur local agisse.
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc)
			return;
		if (pUserEntity != pc.GetControlledEntity())
			return;
		
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc)
			return;
		
		// Envoie la RPC : le serveur renverra la liste des vehicules stockes du joueur,
		// et le client ouvrira automatiquement le menu garage virtuel a reception.
		RplComponent rpl = RplComponent.Cast(pOwnerEntity.FindComponent(RplComponent));
		if (!rpl)
			return;
		jpc.ClientAskRetrieveVehicleList(rpl.Id());
	}
	
	//------------------------------------------------------------------------------------------------
	override bool GetActionNameScript(out string outName)
	{
		outName = "Recuperer mon vehicule";
		return true;
	}
}
