//------------------------------------------------------------------------------------------------
// JobTalkAction.c
// UserAction "F - Parler" sur les PNJ metier.
// Le texte de l'action change selon le type de PNJ et le metier du joueur.
// Conforme a la reponse C du boss: action contextuelle.
//------------------------------------------------------------------------------------------------

class JobTalkAction : ScriptedUserAction
{
	//------------------------------------------------------------------------------------------------
	override bool CanBePerformedScript(IEntity user)
	{
		// Recupere le JobNPCComponent sur le PNJ (pawn)
		IEntity pawn = GetOwner();
		if (!pawn)
			return false;
		
		JobNPCComponent npcComp = JobNPCComponent.Cast(pawn.FindComponent(JobNPCComponent));
		if (!npcComp)
			return false;
		
		// Recupere le metier du joueur cote client via son JobPlayerComponent
		// Plusieurs strategies car le "user" passe n'est pas toujours le character
		EJobType playerJob = EJobType.NONE;
		JobPlayerComponent jpc = GetJobComponentFromEntity(user);
		if (!jpc)
		{
			// Fallback: utilise le player local (client uniquement)
			IEntity local = SCR_PlayerController.GetLocalControlledEntity();
			if (local)
				jpc = GetJobComponentFromEntity(local);
		}
		if (jpc)
			playerJob = jpc.GetJob();
		
		bool canInteract = npcComp.CanInteract(playerJob);
		
		// Debug une fois par 5s max pour pas spam
		int now = System.GetTickCount();
		if (now - s_LastDebugTick > 5000)
		{
			s_LastDebugTick = now;
			Print(string.Format("[JobTalkAction] CanBePerformed: npcType=%1 npcJob=%2 playerJob=%3 -> %4",
				npcComp.GetNPCType(), JobData.JobToString(npcComp.GetJobType()),
				JobData.JobToString(playerJob), canInteract), LogLevel.NORMAL);
		}
		
		return canInteract;
	}
	
	static int s_LastDebugTick = 0;
	
	//------------------------------------------------------------------------------------------------
	override bool CanBeShownScript(IEntity user)
	{
		return CanBePerformedScript(user);
	}
	
	//------------------------------------------------------------------------------------------------
	override bool GetActionNameScript(out string outName)
	{
		IEntity pawn = GetOwner();
		if (!pawn)
			return false;
		
		JobNPCComponent npcComp = JobNPCComponent.Cast(pawn.FindComponent(JobNPCComponent));
		if (!npcComp)
			return false;
		
		// Recupere le metier du joueur local
		EJobType playerJob = EJobType.NONE;
		IEntity localPlayer = SCR_PlayerController.GetLocalControlledEntity();
		if (localPlayer)
		{
			JobPlayerComponent jpc = GetJobComponentFromEntity(localPlayer);
			if (jpc)
				playerJob = jpc.GetJob();
		}
		
		outName = npcComp.GetActionLabel(playerJob);
		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	// Helper: trouve le JobPlayerComponent via le PlayerController
	// (le composant est attache au PlayerController, pas au character)
	//------------------------------------------------------------------------------------------------
	static JobPlayerComponent GetJobComponentFromEntity(IEntity entity)
	{
		if (!entity)
			return null;
		
		// Strategie 1: le user passe est peut-etre deja le PlayerController
		PlayerController pcDirect = PlayerController.Cast(entity);
		if (pcDirect)
		{
			JobPlayerComponent jpc = JobPlayerComponent.Cast(pcDirect.FindComponent(JobPlayerComponent));
			if (jpc)
				return jpc;
		}
		
		// Strategie 2: le user est un character, on cherche son PlayerController via PlayerManager
		PlayerManager pm = GetGame().GetPlayerManager();
		if (pm)
		{
			int playerId = pm.GetPlayerIdFromControlledEntity(entity);
			if (playerId > 0)
			{
				PlayerController pc = pm.GetPlayerController(playerId);
				if (pc)
				{
					JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
					if (jpc)
						return jpc;
				}
			}
		}
		
		// Strategie 3: fallback via le PlayerController local (client uniquement)
		PlayerController localPc = GetGame().GetPlayerController();
		if (localPc)
		{
			JobPlayerComponent jpc = JobPlayerComponent.Cast(localPc.FindComponent(JobPlayerComponent));
			if (jpc)
				return jpc;
		}
		
		return null;
	}
	
	//------------------------------------------------------------------------------------------------
	// Execution de l'action: ouvre le bon menu selon le type de PNJ
	//------------------------------------------------------------------------------------------------
	override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
	{
		// GARDE CRITIQUE MULTIJOUEUR:
		// Cette methode est appelee sur TOUS les clients qui voient le PNJ.
		// On n'ouvre le menu que si pUserEntity est bien le joueur local (celui qui a appuye sur F).
		IEntity localPlayer = SCR_PlayerController.GetLocalControlledEntity();
		if (!localPlayer || pUserEntity != localPlayer)
			return;
		
		JobNPCComponent npcComp = JobNPCComponent.Cast(pOwnerEntity.FindComponent(JobNPCComponent));
		if (!npcComp)
			return;
		
		// Recupere l'RplId du PNJ (pour envoyer au serveur lors du choix)
		RplComponent npcRpl = RplComponent.Cast(pOwnerEntity.FindComponent(RplComponent));
		RplId npcRplId = RplId.Invalid();
		if (npcRpl)
			npcRplId = npcRpl.Id();
		
		ENPCType npcType = npcComp.GetNPCType();
		EJobType npcJob = npcComp.GetJobType();
		
		switch (npcType)
		{
			case ENPCType.INTERIM_RECRUITER:
				OpenInterimMenu(npcRplId);
				break;
			
			case ENPCType.ADVANCED_RECRUITER:
				OpenAdvancedMenu(npcRplId);
				break;
			
			case ENPCType.JOB_SPECIFIC:
				OpenJobMenu(npcRplId, npcJob);
				break;
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Ouvre le menu de selection parmi les metiers interim
	//------------------------------------------------------------------------------------------------
	void OpenInterimMenu(RplId npcRplId)
	{
		JobSelectionMenu menu = JobSelectionMenu.Cast(GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.JobSelectionMenu));
		if (menu)
			menu.Initialize(JobData.GetInterimMenuJobs(), npcRplId, false);
	}
	
	//------------------------------------------------------------------------------------------------
	// Ouvre le menu de selection parmi les metiers avances (PNJ cache)
	//------------------------------------------------------------------------------------------------
	void OpenAdvancedMenu(RplId npcRplId)
	{
		JobSelectionMenu menu = JobSelectionMenu.Cast(GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.JobSelectionMenu));
		if (menu)
			menu.Initialize(JobData.GetAdvancedMenuJobs(), npcRplId, true);
	}
	
	//------------------------------------------------------------------------------------------------
	// Ouvre le menu d'un PNJ metier specifique (quetes + equipement)
	//------------------------------------------------------------------------------------------------
	void OpenJobMenu(RplId npcRplId, EJobType job)
	{
		// Menu de metier: ouvre un autre menu (JobActionMenu) qui propose:
		//  - "Voir les quetes disponibles"
		//  - "Recevoir equipement et outils de service"
		//  - (Concessionnaire uniquement) "Acheter un vehicule"
		JobActionMenu menu = JobActionMenu.Cast(GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.JobActionMenu));
		if (menu)
			menu.Initialize(job, npcRplId);
	}
}
