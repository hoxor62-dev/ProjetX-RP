//------------------------------------------------------------------------------------------------
// JobDrugDealerAction.c
// UserAction "Vendre de la drogue" - ouvre le JobDrugDealerMenu
// Visible UNIQUEMENT si le joueur a le metier VOYOU.
//------------------------------------------------------------------------------------------------

class JobDrugDealerAction : ScriptedUserAction
{
	//------------------------------------------------------------------------------------------------
	override bool CanBeShownScript(IEntity user)
	{
		if (!user) return false;
		
		// Verifie que l entite proprietaire est bien un dealer
		JobDrugDealerComponent dealer = JobDrugDealerComponent.Cast(
			GetOwner().FindComponent(JobDrugDealerComponent));
		if (!dealer) return false;
		
		// Verifie que le joueur a bien le metier VOYOU
		JobCharacterJobComponent jcjc = JobCharacterJobComponent.Cast(
			user.FindComponent(JobCharacterJobComponent));
		if (!jcjc) return false;
		
		return jcjc.GetJob() == EJobType.VOYOU;
	}
	
	//------------------------------------------------------------------------------------------------
	override bool CanBePerformedScript(IEntity user)
	{
		return CanBeShownScript(user);
	}
	
	//------------------------------------------------------------------------------------------------
	override bool GetActionNameScript(out string outName)
	{
		outName = "Vendre de la drogue";
		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
	{
		// GARDE MULTIJOUEUR
		IEntity localPlayer = SCR_PlayerController.GetLocalControlledEntity();
		if (!localPlayer || pUserEntity != localPlayer)
			return;
		
		// Re-verifie le metier VOYOU (anti-cheat si le joueur change de job pendant l action)
		JobCharacterJobComponent jcjc = JobCharacterJobComponent.Cast(
			pUserEntity.FindComponent(JobCharacterJobComponent));
		if (!jcjc || jcjc.GetJob() != EJobType.VOYOU)
			return;
		
		// Ouvre le menu dealer
		JobDrugDealerMenu menu = JobDrugDealerMenu.Cast(
			GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.JobDrugDealerMenu));
		if (menu)
			menu.Initialize();
	}
}
