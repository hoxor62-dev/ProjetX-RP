//------------------------------------------------------------------------------------------------
// LP_EpicerieCraftMenu.c
// Menu de craft de l epicerie (accessible uniquement au metier EPICIER).
// Layout : liste recettes a gauche, preview 3D + ingredients + bouton Craft a droite,
//          file d attente en bas.
//------------------------------------------------------------------------------------------------

class LP_EpicerieCraftMenu : ChimeraMenuBase
{
	static LP_EpicerieCraftMenu s_Instance;
	static LP_EpicerieCraftMenu GetOpenMenu() { return s_Instance; }
	
	Widget m_Root;
	Widget m_RecipeListContainer;
	Widget m_QueueContainer;
	TextWidget m_TitleText;
	TextWidget m_PreviewName;
	TextWidget m_PreviewIngredients;
	ItemPreviewWidget m_PreviewWidget;
	ButtonWidget m_BtnCraft;
	ButtonWidget m_BtnClose;
	
	int m_SelectedRecipeId = -1;
	
	// Focus manette : reference au premier bouton de recette (pour focus initial)
	ButtonWidget m_FirstRecipeButton;
	
	// Etat file d attente (recu par push du serveur)
	ref array<int> m_QueueEntryIds = new array<int>();
	ref array<int> m_QueueRecipeIds = new array<int>();
	ref array<int> m_QueueSecondsRemaining = new array<int>();
	
	// Cache boutons recettes -> recipeId
	ref map<ButtonWidget, int> m_RecipeButtonToId = new map<ButtonWidget, int>();
	// Cache boutons queue -> entryId
	ref map<ButtonWidget, int> m_QueueButtonToEntryId = new map<ButtonWidget, int>();
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuOpen()
	{
		super.OnMenuOpen();
		s_Instance = this;
		
		// Nettoie le registre du JobFocusHandler avant d enregistrer les nouveaux handlers
		JobFocusHandler.ClearRegistry();
		
		m_Root = GetRootWidget();
		if (!m_Root) return;
		
		m_RecipeListContainer  = m_Root.FindAnyWidget("RecipeListContainer");
		m_QueueContainer       = m_Root.FindAnyWidget("QueueContainer");
		m_TitleText            = TextWidget.Cast(m_Root.FindAnyWidget("TitleText"));
		m_PreviewName          = TextWidget.Cast(m_Root.FindAnyWidget("PreviewName"));
		m_PreviewIngredients   = TextWidget.Cast(m_Root.FindAnyWidget("PreviewIngredients"));
		m_PreviewWidget        = ItemPreviewWidget.Cast(m_Root.FindAnyWidget("PreviewWidget"));
		m_BtnCraft             = ButtonWidget.Cast(m_Root.FindAnyWidget("BtnCraft"));
		m_BtnClose             = ButtonWidget.Cast(m_Root.FindAnyWidget("BtnClose"));
		
		if (m_TitleText) m_TitleText.SetText("Craft Epicerie");
		if (m_PreviewName) m_PreviewName.SetText("");
		if (m_PreviewIngredients) m_PreviewIngredients.SetText("");
		
		// Handlers boutons principaux + focus manette
		if (m_BtnCraft)
		{
			LP_EpicerieCraftClickHandler h = new LP_EpicerieCraftClickHandler();
			h.m_Menu = this;
			h.m_Kind = "craft";
			m_BtnCraft.AddHandler(h);
			JobFocusHandler.Attach(m_BtnCraft);
			
			// Bouton visible mais desactive tant qu aucune recette selectionnee
			m_BtnCraft.SetEnabled(false);
			m_BtnCraft.SetVisible(true);
		}
		if (m_BtnClose)
		{
			LP_EpicerieCraftClickHandler h = new LP_EpicerieCraftClickHandler();
			h.m_Menu = this;
			h.m_Kind = "close";
			m_BtnClose.AddHandler(h);
			JobFocusHandler.Attach(m_BtnClose);
		}
		
		// Bouton Fermer secondaire (dans la colonne droite pour navigation manette facile)
		ButtonWidget btnCloseSecondary = ButtonWidget.Cast(m_Root.FindAnyWidget("BtnCloseSecondary"));
		if (btnCloseSecondary)
		{
			LP_EpicerieCraftClickHandler h = new LP_EpicerieCraftClickHandler();
			h.m_Menu = this;
			h.m_Kind = "close";
			btnCloseSecondary.AddHandler(h);
			JobFocusHandler.Attach(btnCloseSecondary);
		}
		
		BuildRecipeList();
		RefreshQueueUI();
		
		// Focus initial sur la premiere recette pour la navigation manette
		if (m_FirstRecipeButton)
		{
			GetGame().GetCallqueue().CallLater(SetInitialFocus, 50, false);
		}
		
		// Demande au serveur l etat initial de la file
		PlayerController pc = GetGame().GetPlayerController();
		if (pc)
		{
			JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
			if (jpc) jpc.ClientAskEpicerieCraftQueueRefresh();
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Focus initial (delay 50ms pour laisser Enfusion finir le rendu)
	protected void SetInitialFocus()
	{
		if (m_FirstRecipeButton)
			GetGame().GetWorkspace().SetFocusedWidget(m_FirstRecipeButton);
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuClose()
	{
		s_Instance = null;
		JobFocusHandler.ClearRegistry();
		super.OnMenuClose();
	}
	
	//------------------------------------------------------------------------------------------------
	// Tick chaque frame : ecoute le bouton MenuBack (B manette / Echap clavier) pour fermer
	//------------------------------------------------------------------------------------------------
	override void OnMenuUpdate(float tDelta)
	{
		super.OnMenuUpdate(tDelta);
		if (GetGame().GetInputManager().GetActionValue("MenuBack") > 0.5)
		{
			OnCloseClicked();
			return;
		}
	}
	
	//------------------------------------------------------------------------------------------------
	protected void BuildRecipeList()
	{
		if (!m_RecipeListContainer) return;
		
		m_FirstRecipeButton = null;
		
		array<ref LP_CraftRecipe> recipes = LP_EpicerieCraftData.GetAllRecipes();
		foreach (LP_CraftRecipe r : recipes)
		{
			if (!r) continue;
			
			// Cree un bouton texte par recette
			Widget btnWidget = GetGame().GetWorkspace().CreateWidgets(
				"UI/layouts/LP_EpicerieCraftEntry.layout", m_RecipeListContainer);
			if (!btnWidget) continue;
			
			TextWidget label = TextWidget.Cast(btnWidget.FindAnyWidget("EntryLabel"));
			if (label) label.SetText(r.m_DisplayName);
			
			ButtonWidget btn = ButtonWidget.Cast(btnWidget.FindAnyWidget("EntryButton"));
			if (btn)
			{
				m_RecipeButtonToId.Set(btn, r.m_RecipeId);
				LP_EpicerieCraftClickHandler h = new LP_EpicerieCraftClickHandler();
				h.m_Menu = this;
				h.m_Kind = "select_recipe";
				h.m_ButtonRef = btn;
				btn.AddHandler(h);
				
				// Focus manette : couleur or au hover/focus
				JobFocusHandler.Attach(btn);
				
				// Retient le premier bouton pour le focus initial
				if (!m_FirstRecipeButton)
					m_FirstRecipeButton = btn;
			}
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void OnRecipeSelected(int recipeId)
	{
		m_SelectedRecipeId = recipeId;
		LP_CraftRecipe recipe = LP_EpicerieCraftData.GetRecipeById(recipeId);
		if (!recipe) return;
		
		// Active le bouton Craft (etait desactive tant qu aucune recette selectionnee)
		if (m_BtnCraft)
			m_BtnCraft.SetEnabled(true);
		
		if (m_PreviewName)
			m_PreviewName.SetText(recipe.m_DisplayName);
		
		// Construction du texte des ingredients
		string ingText = "Ingredients requis :\n";
		foreach (LP_CraftIngredient ing : recipe.m_Ingredients)
		{
			if (!ing) continue;
			ingText = ingText + "- " + ing.m_DisplayName + " x" + ing.m_Quantity.ToString() + "\n";
		}
		if (m_PreviewIngredients)
			m_PreviewIngredients.SetText(ingText);
		
		// Preview 3D (pattern eprouve du mod - shop menu)
		if (m_PreviewWidget)
		{
			ItemPreviewManagerEntity manager = GetPreviewManager();
			if (manager)
			{
				ResourceName prefab = recipe.m_ResultPrefab;
				manager.SetPreviewItemFromPrefab(m_PreviewWidget, prefab, null, false);
			}
		}
		
		// FIX NAVIGATION MANETTE : force le focus sur le bouton Craft apres selection recette
		// Sans ca, la navigation manette ne trouve pas le bouton Craft depuis la colonne gauche
		// (les recettes sont dans une VerticalLayout et Enfusion ne fait pas la nav horizontale)
		if (m_BtnCraft)
			GetGame().GetCallqueue().CallLater(FocusCraftButton, 50, false);
	}
	
	//------------------------------------------------------------------------------------------------
	protected void FocusCraftButton()
	{
		if (m_BtnCraft)
			GetGame().GetWorkspace().SetFocusedWidget(m_BtnCraft);
	}
	
	// Reference au manager (trouve une fois dans le monde et mise en cache)
	ItemPreviewManagerEntity m_PreviewManager;
	
	//------------------------------------------------------------------------------------------------
	// Trouve (ou retrouve en cache) le manager de preview 3D.
	// Le manager est un GenericEntity present dans la scene (pattern eprouve du mod - shop menu).
	//------------------------------------------------------------------------------------------------
	protected ItemPreviewManagerEntity GetPreviewManager()
	{
		if (m_PreviewManager)
			return m_PreviewManager;
		
		BaseWorld world = GetGame().GetWorld();
		if (!world)
			return null;
		
		IEntity entity = world.FindEntityByName("ItemPreviewManagerEntity");
		if (entity)
			m_PreviewManager = ItemPreviewManagerEntity.Cast(entity);
		
		return m_PreviewManager;
	}
	
	//------------------------------------------------------------------------------------------------
	void OnCraftClicked()
	{
		if (m_SelectedRecipeId < 0) return;
		
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		
		jpc.ClientAskEpicerieCraftAdd(m_SelectedRecipeId);
	}
	
	//------------------------------------------------------------------------------------------------
	void OnQueueCollectClicked(int entryId)
	{
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		
		jpc.ClientAskEpicerieCraftCollect(entryId);
	}
	
	//------------------------------------------------------------------------------------------------
	void OnCloseClicked()
	{
		GetGame().GetMenuManager().CloseMenu(this);
	}
	
	//------------------------------------------------------------------------------------------------
	// Appele quand le serveur push une nouvelle version de la file d attente
	//------------------------------------------------------------------------------------------------
	void UpdateQueue(array<int> entryIds, array<int> recipeIds, array<int> secondsRemaining)
	{
		m_QueueEntryIds.Clear();
		m_QueueRecipeIds.Clear();
		m_QueueSecondsRemaining.Clear();
		
		foreach (int id : entryIds) m_QueueEntryIds.Insert(id);
		foreach (int rid : recipeIds) m_QueueRecipeIds.Insert(rid);
		foreach (int sec : secondsRemaining) m_QueueSecondsRemaining.Insert(sec);
		
		RefreshQueueUI();
	}
	
	//------------------------------------------------------------------------------------------------
	protected void RefreshQueueUI()
	{
		if (!m_QueueContainer) return;
		
		// Efface les anciens boutons
		m_QueueButtonToEntryId.Clear();
		Widget child = m_QueueContainer.GetChildren();
		while (child)
		{
			Widget next = child.GetSibling();
			child.RemoveFromHierarchy();
			child = next;
		}
		
		// Recree les entrees
		for (int i = 0; i < m_QueueEntryIds.Count(); i++)
		{
			int entryId = m_QueueEntryIds[i];
			int recipeId = m_QueueRecipeIds[i];
			int secLeft = m_QueueSecondsRemaining[i];
			
			LP_CraftRecipe recipe = LP_EpicerieCraftData.GetRecipeById(recipeId);
			if (!recipe) continue;
			
			Widget entryWidget = GetGame().GetWorkspace().CreateWidgets(
				"UI/layouts/LP_EpicerieCraftQueueEntry.layout", m_QueueContainer);
			if (!entryWidget) continue;
			
			TextWidget nameLabel = TextWidget.Cast(entryWidget.FindAnyWidget("QueueName"));
			TextWidget timeLabel = TextWidget.Cast(entryWidget.FindAnyWidget("QueueTime"));
			ButtonWidget btnCollect = ButtonWidget.Cast(entryWidget.FindAnyWidget("BtnCollect"));
			
			if (nameLabel) nameLabel.SetText(recipe.m_DisplayName);
			if (timeLabel)
			{
				if (secLeft > 0)
					timeLabel.SetText("En cours : " + secLeft.ToString() + "s");
				else
					timeLabel.SetText("Pret !");
			}
			
			if (btnCollect)
			{
				// Le bouton n est actif que si l item est pret
				if (secLeft > 0)
				{
					btnCollect.SetEnabled(false);
					btnCollect.SetColor(Color.FromRGBA(80, 80, 80, 200));
				}
				else
				{
					btnCollect.SetEnabled(true);
					btnCollect.SetColor(Color.FromRGBA(80, 180, 80, 255));
				}
				
				m_QueueButtonToEntryId.Set(btnCollect, entryId);
				LP_EpicerieCraftClickHandler h = new LP_EpicerieCraftClickHandler();
				h.m_Menu = this;
				h.m_Kind = "collect";
				h.m_ButtonRef = btnCollect;
				btnCollect.AddHandler(h);
				
				// Focus manette (seulement si le bouton est actif = item pret)
				if (secLeft <= 0)
					JobFocusHandler.Attach(btnCollect);
			}
		}
	}
}

//------------------------------------------------------------------------------------------------
// Handler unique pour tous les boutons du menu (identifie par m_Kind)
//------------------------------------------------------------------------------------------------
class LP_EpicerieCraftClickHandler : ScriptedWidgetEventHandler
{
	LP_EpicerieCraftMenu m_Menu;
	string m_Kind;              // "craft", "close", "select_recipe", "collect"
	ButtonWidget m_ButtonRef;   // utilise pour select_recipe et collect
	
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (!m_Menu) return false;
		
		if (m_Kind == "craft")
		{
			m_Menu.OnCraftClicked();
			return true;
		}
		if (m_Kind == "close")
		{
			m_Menu.OnCloseClicked();
			return true;
		}
		if (m_Kind == "select_recipe" && m_ButtonRef)
		{
			int recipeId = m_Menu.m_RecipeButtonToId.Get(m_ButtonRef);
			if (recipeId > 0) m_Menu.OnRecipeSelected(recipeId);
			return true;
		}
		if (m_Kind == "collect" && m_ButtonRef)
		{
			int entryId = m_Menu.m_QueueButtonToEntryId.Get(m_ButtonRef);
			if (entryId > 0) m_Menu.OnQueueCollectClicked(entryId);
			return true;
		}
		return false;
	}
}
