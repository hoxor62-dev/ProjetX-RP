//------------------------------------------------------------------------------------------------
// JobQuestManager.c
// Singleton serveur qui gere les quetes actives.
//
// Flux :
// 1. Joueur ouvre JobQuestMenu chez son PNJ metier -> liste des quetes dispo
// 2. Joueur accepte une quete -> StartQuest() -> marker carte sur step 1
// 3. Tick periodique check la distance joueur <-> step courant
// 4. Quand le joueur est dans le rayon -> AdvanceQuest() -> marker sur step suivant
// 5. Derniere step atteinte -> READY_TO_TURN_IN -> joueur retourne au PNJ
// 6. Joueur valide au PNJ -> CompleteQuest() -> reward capsules aleatoire
//------------------------------------------------------------------------------------------------

class JobQuestManager
{
	static ref JobQuestManager s_Instance;
	
	// Quetes actives par playerId
	ref map<int, ref JobActiveQuest> m_ActiveQuests = new map<int, ref JobActiveQuest>();
	
	// Markers carte par playerId (RplId du marker pour suppression)
	ref map<int, int> m_PlayerMarkerIds = new map<int, int>();
	
	const int TICK_INTERVAL_MS = 2000;
	
	//------------------------------------------------------------------------------------------------
	static JobQuestManager GetInstance()
	{
		if (!s_Instance)
		{
			s_Instance = new JobQuestManager();
			s_Instance.Init();
		}
		return s_Instance;
	}
	
	//------------------------------------------------------------------------------------------------
	void Init()
	{
		Print("[JobQuestManager] Initialisation", LogLevel.NORMAL);
		if (Replication.IsServer())
			GetGame().GetCallqueue().CallLater(Tick, TICK_INTERVAL_MS, true);
	}
	
	//------------------------------------------------------------------------------------------------
	// Retourne la quete active d'un joueur (null si aucune)
	//------------------------------------------------------------------------------------------------
	JobActiveQuest GetActiveQuest(int playerId)
	{
		JobActiveQuest q;
		if (m_ActiveQuests.Find(playerId, q))
			return q;
		return null;
	}
	
	//------------------------------------------------------------------------------------------------
	// Demarre une quete pour un joueur (appelee depuis JobQuestMenu)
	//------------------------------------------------------------------------------------------------
	bool StartQuest(int playerId, EQuestType questType)
	{
		if (!Replication.IsServer())
			return false;
		
		// Empeche d'accepter plusieurs quetes en meme temps
		if (GetActiveQuest(playerId))
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[QUETE] Vous avez deja une quete active. Terminez-la ou abandonnez.");
			return false;
		}
		
		JobQuest quest = JobQuestData.GetQuest(questType);
		if (!quest || quest.m_Steps.IsEmpty())
			return false;
		
		// Verifie que le metier matche
		JobPlayerData data = JobManager.GetInstance().GetPlayerData(playerId);
		if (!data || data.m_Job != quest.m_ForJob)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[QUETE] Cette quete n'est pas pour votre metier.");
			return false;
		}
		
		// Cree l'etat
		JobActiveQuest active = new JobActiveQuest();
		active.m_PlayerId = playerId;
		active.m_QuestType = questType;
		active.m_State = EQuestState.STEP_1;
		active.m_StartTime = System.GetUnixTime();
		m_ActiveQuests.Set(playerId, active);
		
		// Sync client-side pour l'UI (afficher bouton Abandonner)
		SyncActiveQuestToClient(playerId, questType, EQuestState.STEP_1);
		
		// Cree le marker sur la premiere etape
		JobQuestStep step = quest.m_Steps.Get(0);
		CreateMarkerForPlayer(playerId, step.m_Position, step.m_MarkerLabel);
		
		// Notification joueur
		JobManager.GetInstance().NotifyPlayerChat(playerId,
			string.Format("[QUETE] %1 acceptee. %2", quest.m_Label, step.m_Description));
		
		// Si time limit, info supplementaire au joueur
		if (quest.m_TimeLimit > 0)
		{
			int minutes = quest.m_TimeLimit / 60;
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				string.Format("[QUETE] ATTENTION : vous avez %1 minutes pour reussir cette quete !", minutes));
		}
		
		Print(string.Format("[JobQuestManager] StartQuest: player=%1 quest=%2",
			playerId, questType), LogLevel.NORMAL);
		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	// Tick serveur: verifie la proximite des joueurs avec leurs waypoints
	//------------------------------------------------------------------------------------------------
	void Tick()
	{
		if (!Replication.IsServer())
			return;
		
		PlayerManager pm = GetGame().GetPlayerManager();
		if (!pm)
			return;
		
		array<int> toProcess = new array<int>();
		foreach (int pid, JobActiveQuest q : m_ActiveQuests)
		{
			toProcess.Insert(pid);
		}
		
		foreach (int playerId : toProcess)
		{
			JobActiveQuest active = GetActiveQuest(playerId);
			if (!active)
				continue;
			
			// Si quete deja prete a valider, le tick ne fait plus rien
			if (active.m_State == EQuestState.READY_TO_TURN_IN)
				continue;
			
			JobQuest quest = JobQuestData.GetQuest(active.m_QuestType);
			if (!quest)
				continue;
			
			// CHECK TIMER : si la quete a une time limit et qu elle est depassee
			if (quest.m_TimeLimit > 0)
			{
				int elapsed = System.GetUnixTime() - active.m_StartTime;
				if (elapsed >= quest.m_TimeLimit)
				{
					// Echec : on annule la quete
					NotifyQuestFailed(playerId, "Temps ecoule ! Vous avez echoue la quete.");
					AbandonQuest(playerId);
					continue;
				}
			}
			
			PlayerController pc = pm.GetPlayerController(playerId);
			if (!pc)
				continue;
			IEntity playerEntity = pc.GetControlledEntity();
			if (!playerEntity)
				continue;
			
			int stepIndex = active.m_State - 1;
			if (stepIndex < 0 || stepIndex >= quest.m_Steps.Count())
				continue;
			
			JobQuestStep step = quest.m_Steps.Get(stepIndex);
			vector playerPos = playerEntity.GetOrigin();
			// Distance horizontale (X/Z) uniquement - on ignore la hauteur Y pour eviter
			// qu une coordonnee Y imprecise (ou a 0) empeche la validation de l etape.
			float dx = playerPos[0] - step.m_Position[0];
			float dz = playerPos[2] - step.m_Position[2];
			float distance = Math.Sqrt(dx * dx + dz * dz);
			
			if (distance <= step.m_ValidationRadius)
			{
				AdvanceQuest(playerId);
			}
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Passe a l'etape suivante de la quete
	//------------------------------------------------------------------------------------------------
	void AdvanceQuest(int playerId)
	{
		JobActiveQuest active = GetActiveQuest(playerId);
		if (!active)
			return;
		
		JobQuest quest = JobQuestData.GetQuest(active.m_QuestType);
		if (!quest)
			return;
		
		// Supprime le marker actuel
		RemoveMarkerForPlayer(playerId);
		
		int currentStepIndex = active.m_State - 1;
		int nextStepIndex = currentStepIndex + 1;
		
		if (nextStepIndex >= quest.m_Steps.Count())
		{
			// Plus de steps -> soit auto-complete, soit retour PNJ
			if (quest.m_AutoComplete)
			{
				// Validation automatique : on force l etat READY puis on complete direct
				active.m_State = EQuestState.READY_TO_TURN_IN;
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					string.Format("[QUETE] Objectif atteint : %1", quest.m_Label));
				CompleteQuest(playerId);
				Print(string.Format("[JobQuestManager] Quest auto-completed: player=%1 quest=%2",
					playerId, active.m_QuestType), LogLevel.NORMAL);
				return;
			}
			
			// Sinon : retour PNJ obligatoire
			active.m_State = EQuestState.READY_TO_TURN_IN;
			SyncActiveQuestToClient(playerId, active.m_QuestType, EQuestState.READY_TO_TURN_IN);
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				string.Format("[QUETE] %1 ! Retournez voir votre PNJ pour recevoir la recompense.",
					quest.m_Label));
			Print(string.Format("[JobQuestManager] Quest ready to turn in: player=%1 quest=%2",
				playerId, active.m_QuestType), LogLevel.NORMAL);
			return;
		}
		
		// Passe a l'etape suivante
		active.m_State = nextStepIndex + 1;
		SyncActiveQuestToClient(playerId, active.m_QuestType, active.m_State);
		JobQuestStep nextStep = quest.m_Steps.Get(nextStepIndex);
		CreateMarkerForPlayer(playerId, nextStep.m_Position, nextStep.m_MarkerLabel);
		
		JobManager.GetInstance().NotifyPlayerChat(playerId,
			string.Format("[QUETE] Etape validee ! %1", nextStep.m_Description));
		
		Print(string.Format("[JobQuestManager] Step advanced: player=%1 step=%2",
			playerId, active.m_State), LogLevel.NORMAL);
	}
	
	//------------------------------------------------------------------------------------------------
	// Valide la quete et donne la recompense (appelee quand le joueur parle au PNJ apres READY)
	//------------------------------------------------------------------------------------------------
	bool CompleteQuest(int playerId)
	{
		if (!Replication.IsServer())
			return false;
		
		JobActiveQuest active = GetActiveQuest(playerId);
		if (!active)
			return false;
		
		if (active.m_State != EQuestState.READY_TO_TURN_IN)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[QUETE] Votre quete n'est pas encore terminee.");
			return false;
		}
		
		JobQuest quest = JobQuestData.GetQuest(active.m_QuestType);
		if (!quest)
			return false;
		
		// Tirage reward aleatoire
		int reward = Math.RandomInt(quest.m_RewardMin, quest.m_RewardMax + 1);
		
		// Paiement via CapsuleEconomy
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		CapsuleEconomyManager eco = CapsuleEconomyManager.GetInstance();
		if (eco && uid != "")
		{
			eco.AddCapsules(uid, reward);
			int newTotal = eco.GetCapsules(uid);
			
			// Sync HUD capsules
			PlayerController pc = GetGame().GetPlayerManager().GetPlayerController(playerId);
			if (pc)
			{
				CapsulePlayerComponent capsComp = CapsulePlayerComponent.Cast(
					pc.FindComponent(CapsulePlayerComponent));
				if (capsComp)
					capsComp.Svr_SendCapsules(newTotal);
			}
			
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				string.Format("[QUETE] %1 validee ! +%2 capsules. Solde: %3",
					quest.m_Label, reward, newTotal));
		}
		
		// Increment le compteur de quetes completees
		JobManager.GetInstance().IncrementQuestsCompleted(playerId);
		
		// Nettoyage
		RemoveMarkerForPlayer(playerId);
		SyncActiveQuestToClient(playerId, 0, 0); // NONE
		m_ActiveQuests.Remove(playerId);
		
		Print(string.Format("[JobQuestManager] Quest completed: player=%1 quest=%2 reward=%3",
			playerId, active.m_QuestType, reward), LogLevel.NORMAL);
		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	// Abandonne la quete active
	//------------------------------------------------------------------------------------------------
	// Notifie un joueur d'un echec de quete
	//------------------------------------------------------------------------------------------------
	void NotifyQuestFailed(int playerId, string reason)
	{
		JobManager.GetInstance().NotifyPlayerChat(playerId,
			string.Format("[QUETE ECHEC] %1", reason));
	}
	
	//------------------------------------------------------------------------------------------------
	void AbandonQuest(int playerId)
	{
		if (!Replication.IsServer())
			return;
		
		JobActiveQuest active = GetActiveQuest(playerId);
		if (!active)
			return;
		
		RemoveMarkerForPlayer(playerId);
		SyncActiveQuestToClient(playerId, 0, 0); // NONE
		m_ActiveQuests.Remove(playerId);
		
		JobManager.GetInstance().NotifyPlayerChat(playerId, "[QUETE] Quete abandonnee.");
	}
	
	//------------------------------------------------------------------------------------------------
	// Helper: sync l'etat quete active vers le client
	//------------------------------------------------------------------------------------------------
	void SyncActiveQuestToClient(int playerId, int questType, int questState)
	{
		PlayerController pc = GetGame().GetPlayerManager().GetPlayerController(playerId);
		if (!pc)
			return;
		
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (jpc)
			jpc.ServerSetActiveQuestType(questType, questState);
	}
	
	//------------------------------------------------------------------------------------------------
	// Cree un marker carte client pour le joueur (envoie via RPC)
	//------------------------------------------------------------------------------------------------
	void CreateMarkerForPlayer(int playerId, vector pos, string label)
	{
		PlayerController pc = GetGame().GetPlayerManager().GetPlayerController(playerId);
		if (!pc)
			return;
		
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc)
			return;
		
		jpc.ServerSetQuestMarker(pos, label);
	}
	
	//------------------------------------------------------------------------------------------------
	void RemoveMarkerForPlayer(int playerId)
	{
		PlayerController pc = GetGame().GetPlayerManager().GetPlayerController(playerId);
		if (!pc)
			return;
		
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc)
			return;
		
		jpc.ServerRemoveQuestMarker();
	}
	
	//------------------------------------------------------------------------------------------------
	// Nettoyage au disconnect
	//------------------------------------------------------------------------------------------------
	void OnPlayerDisconnected(int playerId)
	{
		m_ActiveQuests.Remove(playerId);
	}
}
