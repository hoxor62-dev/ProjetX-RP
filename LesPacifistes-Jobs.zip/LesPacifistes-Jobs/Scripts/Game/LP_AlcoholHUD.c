//------------------------------------------------------------------------------------------------
// LP_AlcoholHUD.c
// HUD client-side pour l effet alcool.
// Cree la layout UI a l initialisation (singleton), s active/desactive selon le niveau recu.
//
// EFFETS VISUELS SELON LE TAUX :
//  - >= 25%  : icone coeur apparait (bas gauche) + pulse cardiaque
//  - >= 40%  : overlay teinte semi-transparent (effet "brouillard")
//  - >= 70%  : overlay plus intense + rythme cardiaque plus rapide
//  - >= 90%  : overlay tres intense (vision quasi bloquee)
//
// Le rythme du coeur : 60 bpm base + jusqu'a +150 a 100% = 210 bpm max
//------------------------------------------------------------------------------------------------

class LP_AlcoholHUD
{
	static ref LP_AlcoholHUD s_Instance;
	
	const string LAYOUT_PATH = "{A64D50B3080468FD}UI/layouts/LP_AlcoholHUD.layout";
	
	Widget m_Root;
	ImageWidget m_BlurOverlay;
	ImageWidget m_HeartIcon;
	TextWidget m_LevelText;
	
	float m_CurrentLevel = 0;
	float m_HeartPulseTimer = 0;
	bool m_HeartVisible = false;
	
	//------------------------------------------------------------------------------------------------
	static LP_AlcoholHUD GetInstance()
	{
		if (!s_Instance)
		{
			s_Instance = new LP_AlcoholHUD();
			s_Instance.Init();
		}
		return s_Instance;
	}
	
	//------------------------------------------------------------------------------------------------
	protected void Init()
	{
		WorkspaceWidget ws = GetGame().GetWorkspace();
		if (!ws) return;
		
		m_Root = ws.CreateWidgets(LAYOUT_PATH);
		if (!m_Root) 
		{
			Print("[LP_AlcoholHUD] ERREUR : layout introuvable a " + LAYOUT_PATH, LogLevel.ERROR);
			return;
		}
		
		m_BlurOverlay = ImageWidget.Cast(m_Root.FindAnyWidget("BlurOverlay"));
		m_HeartIcon = ImageWidget.Cast(m_Root.FindAnyWidget("HeartIcon"));
		m_LevelText = TextWidget.Cast(m_Root.FindAnyWidget("LevelText"));
		
		// Cache tout au demarrage (rien visible a 0%)
		Hide();
		
		// Ticker 100ms pour animer le pulse du coeur
		GetGame().GetCallqueue().CallLater(TickPulse, 100, true);
		
		Print("[LP_AlcoholHUD] HUD alcool initialise.", LogLevel.NORMAL);
	}
	
	//------------------------------------------------------------------------------------------------
	// Appele par LP_AlcoholPlayerComponent quand un RPC serveur arrive
	//------------------------------------------------------------------------------------------------
	void UpdateLevel(float level)
	{
		m_CurrentLevel = level;

		// HUD affiche des le premier verre (>= 1%)
		if (level < 1)
		{
			Hide();
			return;
		}

		Show();

		// Overlay teinte : opacite progresse RAPIDEMENT avec le niveau
		//  1%   -> opacite 0.05  (leger)
		//  25%  -> opacite 0.20  (visible)
		//  50%  -> opacite 0.45  (fort)
		//  75%  -> opacite 0.70  (tres fort)
		//  100% -> opacite 0.85  (quasi opaque)
		float overlayAlpha = (level / 100.0) * 0.85 + 0.05;
		if (overlayAlpha > 0.85) overlayAlpha = 0.85;
		if (m_BlurOverlay) m_BlurOverlay.SetOpacity(overlayAlpha);

		// Texte niveau affiche a cote du coeur
		if (m_LevelText)
		{
			int rounded = level;
			m_LevelText.SetText(rounded.ToString() + "% d ivresse");
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Anime le pulse du coeur selon le rythme cardiaque
	//------------------------------------------------------------------------------------------------
	protected void TickPulse()
	{
		if (!m_HeartIcon) return;
		if (m_CurrentLevel < 1)
		{
			m_HeartIcon.SetOpacity(0);
			return;
		}

		// Rythme cardiaque : 70 bpm base + jusqu'a +200 bpm a 100% = 270 bpm max
		float bpm = 70 + (m_CurrentLevel * 2.0);
		float beatIntervalSec = 60.0 / bpm;
		m_HeartPulseTimer = m_HeartPulseTimer + 0.1;  // tick 100ms

		if (m_HeartPulseTimer >= beatIntervalSec)
		{
			m_HeartPulseTimer = 0;
			m_HeartVisible = !m_HeartVisible;
		}

		// Battement : opacite haute (visible) puis basse (fade)
		if (m_HeartVisible)
			m_HeartIcon.SetOpacity(1.0);
		else
			m_HeartIcon.SetOpacity(0.30);
	}
	
	//------------------------------------------------------------------------------------------------
	protected void Show()
	{
		if (m_Root) m_Root.SetVisible(true);
	}
	
	//------------------------------------------------------------------------------------------------
	protected void Hide()
	{
		if (m_Root) m_Root.SetVisible(false);
		if (m_BlurOverlay) m_BlurOverlay.SetOpacity(0);
		if (m_HeartIcon) m_HeartIcon.SetOpacity(0);
		m_HeartPulseTimer = 0;
	}
}
