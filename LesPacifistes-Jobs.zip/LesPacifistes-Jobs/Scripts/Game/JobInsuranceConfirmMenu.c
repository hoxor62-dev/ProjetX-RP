//------------------------------------------------------------------------------------------------
// JobInsuranceConfirmMenu.c
// Popup de confirmation pour assurer + retirer un vehicule.
// Affiche : "Assurer ce vehicule pour 300 capsules ?"
// Boutons : Confirmer / Annuler
//------------------------------------------------------------------------------------------------

class JobInsuranceConfirmMenu : ChimeraMenuBase
{
	Widget m_RootWidget;
	TextWidget m_TitleText;
	TextWidget m_BodyText;
	ButtonWidget m_BtnConfirm;
	ButtonWidget m_BtnCancel;
	
	// Donnees pre-chargees (le menu doit savoir quel vehicule retirer)
	static int s_GarageIndex;
	static RplId s_NpcRplId;
	static string s_VehicleName;
	
	static JobInsuranceConfirmMenu s_Instance;
	
	//------------------------------------------------------------------------------------------------
	static void SetPendingData(int garageIndex, RplId npcRplId, string vehicleName)
	{
		s_GarageIndex = garageIndex;
		s_NpcRplId = npcRplId;
		s_VehicleName = vehicleName;
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuOpen()
	{
		super.OnMenuOpen();
		s_Instance = this;
		JobFocusHandler.ClearRegistry();
		
		m_RootWidget = GetRootWidget();
		if (!m_RootWidget) return;
		
		m_TitleText = TextWidget.Cast(m_RootWidget.FindAnyWidget("TitleText"));
		m_BodyText = TextWidget.Cast(m_RootWidget.FindAnyWidget("BodyText"));
		m_BtnConfirm = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnConfirm"));
		m_BtnCancel = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnCancel"));
		
		if (m_TitleText)
			m_TitleText.SetText("Assurance vehicule");
		if (m_BodyText)
			m_BodyText.SetText(string.Format(
				"Assurer le vehicule '%1' pour 250 capsules ?\n\nSi le vehicule est detruit ou perdu, il sera automatiquement restitue dans votre garage virtuel.\n\nCooldown : 3h avant la prochaine assurance.",
				s_VehicleName));
		
		if (m_BtnConfirm)
		{
			InsuranceConfirmHandler h = new InsuranceConfirmHandler();
			h.m_Menu = this;
			h.m_Action = "confirm";
			m_BtnConfirm.AddHandler(h);
			JobFocusHandler.Attach(m_BtnConfirm);
		}
		if (m_BtnCancel)
		{
			InsuranceConfirmHandler h = new InsuranceConfirmHandler();
			h.m_Menu = this;
			h.m_Action = "cancel";
			m_BtnCancel.AddHandler(h);
			JobFocusHandler.Attach(m_BtnCancel);
			// Focus initial sur Annuler par securite
			GetGame().GetWorkspace().SetFocusedWidget(m_BtnCancel);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuClose()
	{
		if (s_Instance == this) s_Instance = null;
		super.OnMenuClose();
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuUpdate(float tDelta)
	{
		super.OnMenuUpdate(tDelta);
		if (GetGame().GetInputManager().GetActionValue("MenuBack") > 0.5)
			CloseMenuInternal();
	}
	
	//------------------------------------------------------------------------------------------------
	void OnAction(string action)
	{
		if (action == "cancel")
		{
			CloseMenuInternal();
			return;
		}
		if (action == "confirm")
		{
			PlayerController pc = GetGame().GetPlayerController();
			if (!pc) return;
			JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
			if (!jpc) return;
			jpc.ClientAskInsureAndRetrieveVehicle(s_NpcRplId, s_GarageIndex);
			CloseMenuInternal();
			return;
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void CloseMenuInternal()
	{
		GetGame().GetMenuManager().CloseMenu(this);
	}
}

//------------------------------------------------------------------------------------------------
class InsuranceConfirmHandler : ScriptedWidgetEventHandler
{
	JobInsuranceConfirmMenu m_Menu;
	string m_Action;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.OnAction(m_Action);
		return true;
	}
}
