//------------------------------------------------------------------------------------------------
// JobBonPointSellMenu.c
// Menu vendre. 2 etapes :
//   ETAPE 1 : Liste paginee des items dans l inventaire du joueur (10/page)
//             Le joueur clique sur un item pour le selectionner
//   ETAPE 2 : Saisie du titre, description et prix de vente
//             Le joueur clique sur "Mettre en vente" -> RPC serveur
//
// L item est retire de l inventaire au moment de la mise en vente (cote serveur).
//------------------------------------------------------------------------------------------------

class JobBonPointSellMenu : ChimeraMenuBase
{
	const string ENTRY_LAYOUT_PATH = "{9D68BEB73DF970D8}UI/layouts/JobSmsEntry.layout";  // reutilise pattern
	const int ITEMS_PER_PAGE = 10;
	const int PAGE_COOLDOWN_MS = 300;
	
	Widget m_RootWidget;
	TextWidget m_TitleText;
	TextWidget m_EmptyText;
	TextWidget m_PageLabel;
	Widget m_ListContainer;
	
	// Etape 1 : liste inventaire
	ButtonWidget m_BtnPrev;
	ButtonWidget m_BtnNext;
	
	// Etape 2 : saisie
	Widget m_StepTwoPanel;
	TextWidget m_SelectedItemText;
	ItemPreviewWidget m_SellPreviewWidget;
	ItemPreviewManagerEntity m_PreviewManager;
	EditBoxWidget m_TitleInput;
	EditBoxWidget m_DescInput;
	EditBoxWidget m_PriceInput;
	ButtonWidget m_BtnConfirm;
	ButtonWidget m_BtnBackStep1;
	
	ButtonWidget m_BtnBack;
	
	// Donnees pre-chargees par RpcDo_ReceiveBonPointInventory
	// Format : 2 arrays paralleles "prefab path" + "display name"
	static ref array<string> s_PendingPrefabs = new array<string>();
	static ref array<string> s_PendingNames = new array<string>();
	
	int m_CurrentPage = 0;
	int m_LastPageChangeTime = 0;
	
	// Selection en cours pour etape 2
	string m_SelectedPrefab = "";
	string m_SelectedName = "";
	bool m_InStep2 = false;
	
	static JobBonPointSellMenu s_Instance;
	
	//------------------------------------------------------------------------------------------------
	static void SetPendingData(array<string> prefabs, array<string> names)
	{
		s_PendingPrefabs.Clear();
		s_PendingNames.Clear();
		foreach (string p : prefabs)
			s_PendingPrefabs.Insert(p);
		foreach (string n : names)
			s_PendingNames.Insert(n);
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuOpen()
	{
		super.OnMenuOpen();
		s_Instance = this;
		JobFocusHandler.ClearRegistry();
		
		m_RootWidget = GetRootWidget();
		if (!m_RootWidget) return;
		
		m_TitleText = TextWidget.Cast(m_RootWidget.FindAnyWidget("TitleText"));
		m_EmptyText = TextWidget.Cast(m_RootWidget.FindAnyWidget("EmptyText"));
		m_PageLabel = TextWidget.Cast(m_RootWidget.FindAnyWidget("PageLabel"));
		m_ListContainer = m_RootWidget.FindAnyWidget("ListContainer");
		m_BtnPrev = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnPrev"));
		m_BtnNext = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnNext"));
		
		m_StepTwoPanel = m_RootWidget.FindAnyWidget("StepTwoPanel");
		m_SelectedItemText = TextWidget.Cast(m_RootWidget.FindAnyWidget("SelectedItemText"));
		m_SellPreviewWidget = ItemPreviewWidget.Cast(m_RootWidget.FindAnyWidget("SellPreviewWidget"));
		m_TitleInput = EditBoxWidget.Cast(m_RootWidget.FindAnyWidget("TitleInput"));
		m_DescInput = EditBoxWidget.Cast(m_RootWidget.FindAnyWidget("DescInput"));
		m_PriceInput = EditBoxWidget.Cast(m_RootWidget.FindAnyWidget("PriceInput"));
		m_BtnConfirm = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnConfirm"));
		m_BtnBackStep1 = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnBackStep1"));
		
		m_BtnBack = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnBack"));
		
		if (m_TitleText)
			m_TitleText.SetText("Vendre un item");
		
		BindBtn(m_BtnPrev, "prev");
		BindBtn(m_BtnNext, "next");
		BindBtn(m_BtnConfirm, "confirm");
		BindBtn(m_BtnBackStep1, "back_step1");
		BindBtn(m_BtnBack, "back");
		
		// Initialise sur etape 1
		ShowStep1();
		
		if (m_BtnBack)
			GetGame().GetWorkspace().SetFocusedWidget(m_BtnBack);
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuClose()
	{
		if (s_Instance == this)
			s_Instance = null;
		super.OnMenuClose();
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuUpdate(float tDelta)
	{
		super.OnMenuUpdate(tDelta);
		if (GetGame().GetInputManager().GetActionValue("MenuBack") > 0.5)
		{
			// Si on est en etape 2 -> retour etape 1
			if (m_InStep2)
				ShowStep1();
			else
				CloseMenuInternal();
		}
		if (!m_InStep2)
		{
			if (GetGame().GetInputManager().GetActionValue("MenuTabLeft") > 0.5)
				OnPrev();
			if (GetGame().GetInputManager().GetActionValue("MenuTabRight") > 0.5)
				OnNext();
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void BindBtn(ButtonWidget btn, string action)
	{
		if (!btn) return;
		BonPointSellHandler h = new BonPointSellHandler();
		h.m_Menu = this;
		h.m_Action = action;
		btn.AddHandler(h);
		JobFocusHandler.Attach(btn);
	}
	
	//------------------------------------------------------------------------------------------------
	void ShowStep1()
	{
		m_InStep2 = false;
		m_SelectedPrefab = "";
		m_SelectedName = "";
		if (m_StepTwoPanel)
			m_StepTwoPanel.SetVisible(false);
		if (m_ListContainer)
			m_ListContainer.SetVisible(true);
		if (m_BtnPrev)
			m_BtnPrev.SetVisible(true);
		if (m_BtnNext)
			m_BtnNext.SetVisible(true);
		if (m_PageLabel)
			m_PageLabel.SetVisible(true);
		if (m_TitleText)
			m_TitleText.SetText("Vendre un item - Choisir dans l inventaire");
		BuildList();
	}
	
	//------------------------------------------------------------------------------------------------
	void ShowStep2(string prefab, string name)
	{
		m_InStep2 = true;
		m_SelectedPrefab = prefab;
		m_SelectedName = name;
		if (m_StepTwoPanel)
			m_StepTwoPanel.SetVisible(true);
		if (m_ListContainer)
			m_ListContainer.SetVisible(false);
		if (m_BtnPrev)
			m_BtnPrev.SetVisible(false);
		if (m_BtnNext)
			m_BtnNext.SetVisible(false);
		if (m_PageLabel)
			m_PageLabel.SetVisible(false);
		if (m_TitleText)
			m_TitleText.SetText("Vendre un item - Annonce");
		if (m_SelectedItemText)
			m_SelectedItemText.SetText(string.Format("Item selectionne : %1", name));
		
		// Preview 3D
		if (m_SellPreviewWidget)
		{
			ItemPreviewManagerEntity manager = GetPreviewManager();
			if (manager)
			{
				ResourceName res = prefab;
				manager.SetPreviewItemFromPrefab(m_SellPreviewWidget, res, null, false);
			}
		}
		
		// Reset les champs
		if (m_TitleInput)
			m_TitleInput.SetText(name);  // pre-rempli avec le nom
		if (m_DescInput)
			m_DescInput.SetText("");
		if (m_PriceInput)
			m_PriceInput.SetText("");
	}
	
	//------------------------------------------------------------------------------------------------
	int GetTotalPages()
	{
		int total = (s_PendingPrefabs.Count() + ITEMS_PER_PAGE - 1) / ITEMS_PER_PAGE;
		if (total < 1) total = 1;
		return total;
	}
	
	//------------------------------------------------------------------------------------------------
	void BuildList()
	{
		if (!m_ListContainer) return;
		
		// Reset focus + container
		JobFocusHandler.ClearRegistry();
		if (m_BtnPrev) JobFocusHandler.Attach(m_BtnPrev);
		if (m_BtnNext) JobFocusHandler.Attach(m_BtnNext);
		if (m_BtnBack) JobFocusHandler.Attach(m_BtnBack);
		
		Widget child = m_ListContainer.GetChildren();
		while (child)
		{
			Widget next = child.GetSibling();
			child.RemoveFromHierarchy();
			child = next;
		}
		
		int totalPages = GetTotalPages();
		if (m_CurrentPage < 0) m_CurrentPage = 0;
		if (m_CurrentPage >= totalPages) m_CurrentPage = totalPages - 1;
		
		if (s_PendingPrefabs.Count() == 0)
		{
			if (m_EmptyText)
			{
				m_EmptyText.SetText("Votre inventaire ne contient aucun item vendable.");
				m_EmptyText.SetVisible(true);
			}
			UpdatePagination(totalPages);
			return;
		}
		if (m_EmptyText)
			m_EmptyText.SetVisible(false);
		
		WorkspaceWidget ws = GetGame().GetWorkspace();
		int start = m_CurrentPage * ITEMS_PER_PAGE;
		int end = start + ITEMS_PER_PAGE;
		if (end > s_PendingPrefabs.Count())
			end = s_PendingPrefabs.Count();
		
		for (int i = start; i < end; i++)
		{
			string prefab = s_PendingPrefabs.Get(i);
			string name = s_PendingNames.Get(i);
			
			Widget entry = ws.CreateWidgets(ENTRY_LAYOUT_PATH, m_ListContainer);
			if (!entry) continue;
			
			TextWidget nameW = TextWidget.Cast(entry.FindAnyWidget("PlayerName"));
			if (nameW) nameW.SetText(name);
			
			ButtonWidget btn = ButtonWidget.Cast(entry.FindAnyWidget("SelectButton"));
			if (btn)
			{
				BonPointSellItemHandler ih = new BonPointSellItemHandler();
				ih.m_Menu = this;
				ih.m_Prefab = prefab;
				ih.m_Name = name;
				btn.AddHandler(ih);
				JobFocusHandler.Attach(btn);
			}
		}
		
		UpdatePagination(totalPages);
	}
	
	//------------------------------------------------------------------------------------------------
	void UpdatePagination(int totalPages)
	{
		if (m_PageLabel)
			m_PageLabel.SetText(string.Format("Page %1 / %2", (m_CurrentPage + 1).ToString(), totalPages.ToString()));
		if (m_BtnPrev)
			m_BtnPrev.SetEnabled(m_CurrentPage > 0);
		if (m_BtnNext)
			m_BtnNext.SetEnabled(m_CurrentPage < totalPages - 1);
	}
	
	//------------------------------------------------------------------------------------------------
	void OnPrev()
	{
		int now = System.GetTickCount();
		if (now - m_LastPageChangeTime < PAGE_COOLDOWN_MS) return;
		m_LastPageChangeTime = now;
		if (m_CurrentPage <= 0) return;
		m_CurrentPage--;
		BuildList();
	}
	
	void OnNext()
	{
		int now = System.GetTickCount();
		if (now - m_LastPageChangeTime < PAGE_COOLDOWN_MS) return;
		m_LastPageChangeTime = now;
		if (m_CurrentPage >= GetTotalPages() - 1) return;
		m_CurrentPage++;
		BuildList();
	}
	
	//------------------------------------------------------------------------------------------------
	void OnInventoryItemPicked(string prefab, string name)
	{
		ShowStep2(prefab, name);
	}
	
	//------------------------------------------------------------------------------------------------
	void OnConfirm()
	{
		if (!m_TitleInput || !m_PriceInput || !m_DescInput)
			return;
		string title = m_TitleInput.GetText();
		string desc = m_DescInput.GetText();
		string priceStr = m_PriceInput.GetText();
		int price = priceStr.ToInt();
		
		if (title == "" || price <= 0)
		{
			// Indique simplement l erreur par notif chat plus tard (RPC fera la verif)
			return;
		}
		
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		jpc.ClientAskCreateBonPointAd(m_SelectedPrefab, title, desc, price);
		CloseMenuInternal();
	}
	
	//------------------------------------------------------------------------------------------------
	void OnAction(string action)
	{
		if (action == "back")
		{
			CloseMenuInternal();
			return;
		}
		if (action == "back_step1")
		{
			ShowStep1();
			return;
		}
		if (action == "prev")
		{
			OnPrev();
			return;
		}
		if (action == "next")
		{
			OnNext();
			return;
		}
		if (action == "confirm")
		{
			OnConfirm();
			return;
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void CloseMenuInternal()
	{
		GetGame().GetMenuManager().CloseMenu(this);
	}
	
	static JobBonPointSellMenu GetOpenMenu() { return s_Instance; }
	
	//------------------------------------------------------------------------------------------------
	// Helper : retrouve le manager de preview 3D dans la scene
	ItemPreviewManagerEntity GetPreviewManager()
	{
		if (m_PreviewManager)
			return m_PreviewManager;
		BaseWorld world = GetGame().GetWorld();
		if (!world)
			return null;
		IEntity entity = world.FindEntityByName("ItemPreviewManagerEntity");
		if (entity)
			m_PreviewManager = ItemPreviewManagerEntity.Cast(entity);
		return m_PreviewManager;
	}
}

//------------------------------------------------------------------------------------------------
class BonPointSellHandler : ScriptedWidgetEventHandler
{
	JobBonPointSellMenu m_Menu;
	string m_Action;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.OnAction(m_Action);
		return true;
	}
}

//------------------------------------------------------------------------------------------------
class BonPointSellItemHandler : ScriptedWidgetEventHandler
{
	JobBonPointSellMenu m_Menu;
	string m_Prefab;
	string m_Name;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.OnInventoryItemPicked(m_Prefab, m_Name);
		return true;
	}
}
