//------------------------------------------------------------------------------------------------
// JobRepairKitPurger.c
//
// Systeme generique de purge d items par metier.
// Toutes les 10 secondes, scanne les joueurs connectes et retire de l inventaire les items
// qui ne correspondent pas au metier du joueur.
//
// Categories actuelles :
//   - MECANICIEN     : cles de reparation (kits) - seul un mecanicien peut en avoir
//   - POLICE_ARMY    : armes/mag/uniformes/gilets/casques/holsters police + militaire
//                      seul un POLICIER ou MILITAIRE peut en avoir
//   - MEDECIN        : trousse medicale (gants, uniformes EMS, medicaments, injections)
//                      seul un MEDECIN peut en avoir
//
// Chaque item est identifie par son GUID de prefab (les 18 premiers caracteres {XXX}).
//------------------------------------------------------------------------------------------------

class JobPurgerItemEntry
{
	string m_Guid;
	string m_Category;   // "MECANICIEN" | "POLICE_ARMY" | "MEDECIN"
	
	void JobPurgerItemEntry(string guid, string cat)
	{
		m_Guid = guid;
		m_Category = cat;
	}
}

class JobRepairKitPurger
{
	static ref JobRepairKitPurger s_Instance;
	
	const int TICK_INTERVAL_MS = 30000;  // 10 secondes
	
	// Liste unique de tous les items surveilles (GUID -> categorie)
	ref array<ref JobPurgerItemEntry> m_ItemRegistry = new array<ref JobPurgerItemEntry>();
	
	// DEBUG : compteur de ticks pour reperer si le tick tourne
	int m_TickCount = 0;
	
	//------------------------------------------------------------------------------------------------
	static JobRepairKitPurger GetInstance()
	{
		if (!s_Instance)
		{
			s_Instance = new JobRepairKitPurger();
			s_Instance.Init();
		}
		return s_Instance;
	}
	
	//------------------------------------------------------------------------------------------------
	void Init()
	{
		Print("[JobRepairKitPurger] Initialisation", LogLevel.NORMAL);
		BuildRegistry();
		Print("[JobRepairKitPurger] " + m_ItemRegistry.Count().ToString()
			+ " items enregistres dans le registry", LogLevel.NORMAL);
		if (Replication.IsServer())
		{
			GetGame().GetCallqueue().CallLater(Tick, TICK_INTERVAL_MS, true);
			Print("[JobRepairKitPurger] Tick programme toutes les "
				+ TICK_INTERVAL_MS.ToString() + "ms", LogLevel.NORMAL);
		}
		else
		{
			Print("[JobRepairKitPurger] WARNING : Init appele cote CLIENT, pas de tick !",
				LogLevel.WARNING);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Construit le registry en une fois au demarrage.
	// Pour ajouter/retirer un item : editer cette methode uniquement.
	//------------------------------------------------------------------------------------------------
	void BuildRegistry()
	{
		// ============================================================
		// MECANICIEN : cles de reparation (3 items)
		// ============================================================
		AddItem("{4AF9664BEE9263A4}", "MECANICIEN");
		AddItem("{05562DD0D7651987}", "MECANICIEN");
		AddItem("{33B2DFDCD0EBA3DB}", "MECANICIEN");
		AddItem("{12D5AD21E383B768}", "MECANICIEN");
		AddItem("{E7DF31108D38A8A8}", "MECANICIEN");
		AddItem("{62B2ADC4243454F9}", "MECANICIEN");
		
		
		
		
	
		// ============================================================
		// POLICE_ARMY : police + militaire (22 items)
		// Armes / Magazines / Taser
		// ============================================================
		AddItem("{B184F637A76747F3}", "POLICE_ARMY");  // HK417 mag
		AddItem("{2476B3A801103E68}", "POLICE_ARMY");  // Glock18C mag
		AddItem("{DCB6FDCC7ECD9F38}", "POLICE_ARMY");  // Glock18C
		AddItem("{CA9D4F4FD58BDC82}", "POLICE_ARMY");  // HK417
		AddItem("{17D940029746322E}", "POLICE_ARMY");  // HK417
		AddItem("{AD7416782745365A}", "POLICE_ARMY");  // HK417
		AddItem("{49B3207D2F82525C}", "POLICE_ARMY");  // HK417
		AddItem("{49B3207D2F82525B}", "POLICE_ARMY");  // HK417
		AddItem("{A016B42167B9C807}", "POLICE_ARMY");  // HK417
		AddItem("{7150CFB32206E403}", "POLICE_ARMY");
		AddItem("{C62C5902F7D54EF3}", "POLICE_ARMY");
		AddItem("{C728C74BF732F755}", "POLICE_ARMY");
		AddItem("{4C6980C6EDF7F4CE}", "POLICE_ARMY");
		AddItem("{45C04F01A516BB1A}", "POLICE_ARMY");
		
		// Uniformes / Equipement Police
		AddItem("{25620A1EFBFE15E8}", "POLICE_ARMY");  // Hat FRBI police
		AddItem("{A4A99396151F3594}", "POLICE_ARMY");  // Chemise F1 police noire
		AddItem("{76D6BDBFCEBC65BD}", "POLICE_ARMY");  // Pantalon F1 secu black
		AddItem("{8BB3EA7E222FDFC3}", "POLICE_ARMY");  // Gilet F1 police
		AddItem("{F843BEAE5B06A614}", "POLICE_ARMY");  // Backpack FRBI black
		AddItem("{7EAF5CA342E1127F}", "POLICE_ARMY");  // Holster PM F1
		AddItem("{F05A35BCC44BE9FC}", "POLICE_ARMY");  // TankerBoots US
		AddItem("{6FEB0D9130EC400E}", "POLICE_ARMY");  // FlatCap lightgrey
		AddItem("{EB0D74A43F74B522}", "POLICE_ARMY");  // Jacket Denim strippedShirt
		AddItem("{1A65EADE4B08583E}", "POLICE_ARMY");  // Pants Suit black
		
		// Uniformes / Equipement Militaire / Gendarmerie
		AddItem("{DCEC725FF5E22838}", "POLICE_ARMY");  // Callot Gendarmerie
		AddItem("{9DC9C8310EC1FF10}", "POLICE_ARMY");  // Chemise F1 base
		AddItem("{369DB679FE06AF8F}", "POLICE_ARMY");  // Pantalon F1 black
		AddItem("{EEECE7676BC61023}", "POLICE_ARMY");  // Gilet F1 gendarmerie
		AddItem("{17D6259B5C83F337}", "POLICE_ARMY");  // Vest F1 light SRU21P
		AddItem("{1C764F39C5108A15}", "POLICE_ARMY");  // Backpack FRBI
		AddItem("{1F7D5380BA42FE7F}", "POLICE_ARMY");  // Scabbard bayonet M9 F1
		AddItem("{E44FEA37D1702CD8}", "POLICE_ARMY");  // brassard
		
		
		// ============================================================
		// MEDECIN : trousse medicale (13 items)
		// Uniformes / Equipement
		// ============================================================
		
		

		
		AddItem("{D8326FEE52670D2A}", "MEDECIN");  // Gants medicaux bleus
		AddItem("{C07A52D13353AB2F}", "MEDECIN");  // Masque ZEL
		AddItem("{DAD4DC8DC9888004}", "MEDECIN");  // Chemise F1 EMS bleue
		AddItem("{42B8B837A04DC1E6}", "MEDECIN");  // Backpack EMS
		AddItem("{AA2B0708E63168E0}", "MEDECIN");  // casquette
		
		// Medicaments / Injections
		AddItem("{58CF3AB87C441295}", "MEDECIN");  // Ammonium Carbonate
		AddItem("{A81F501D3EF6F38E}", "MEDECIN");  // Field Dressing
		AddItem("{80E75A71C29190DB}", "MEDECIN");  // Tourniquet
		AddItem("{5B2FD067D70C1E8F}", "MEDECIN");  // Epinephrine
		AddItem("{D0434D5215B54181}", "MEDECIN");  // Metoprolol
		AddItem("{02DD34077F51F65E}", "MEDECIN");  // Naloxone
		AddItem("{9BBA766CD869002C}", "MEDECIN");  // Phenylephrine
		AddItem("{0D9A5DCF89AE7AA9}", "MEDECIN");  // Morphine
		AddItem("{8435F7561C0FBB44}", "MEDECIN");  // Saline Bag
		AddItem("{21EF98BFC1EB3793}", "MEDECIN");  // MedicalKit
		AddItem("{AE578EEA4244D41F}", "MEDECIN");  // MedicalKit
		AddItem("{46FD263F0F368A92}", "MEDECIN");  // MedicalKit
		AddItem("{9132672C4D9B2102}", "MEDECIN");  // MedicalKit
		
		
		// ============================================================
		// ARMY_EMS : police + militaire + MEDECIN
		// Armes / Magazines / Taser
		// ============================================================
		AddItem("{E1A5D4B878AA8980}", "RMY_EMS");  // Radio Russe
		AddItem("{C3F1FA1E2EC2B345}", "RMY_EMS");  // bandage russe
	}
	
	//------------------------------------------------------------------------------------------------
	// Helper pour ajouter un item au registry (evite les erreurs de saisie).
	//------------------------------------------------------------------------------------------------
	void AddItem(string guid, string category)
	{
		m_ItemRegistry.Insert(new JobPurgerItemEntry(guid, category));
	}
	
	//------------------------------------------------------------------------------------------------
	// Verifie si un joueur (via son metier) est autorise pour une categorie donnee.
	//------------------------------------------------------------------------------------------------
	bool IsPlayerAllowedForCategory(int job, string category)
	{
		if (category == "MECANICIEN")
			return (job == EJobType.MECANICIEN);
		if (category == "POLICE_ARMY")
			return (job == EJobType.POLICIER || job == EJobType.MILITAIRE);
		if (category == "MEDECIN")
			return (job == EJobType.MEDECIN);
		if (category == "RMY_EMS")
			return (job == EJobType.MEDECIN || job == EJobType.POLICIER || job == EJobType.MILITAIRE);
		return true;  // categorie inconnue = on ne touche pas
	}
	
	//------------------------------------------------------------------------------------------------
	// Message adapte a la categorie d items retires.
	//------------------------------------------------------------------------------------------------
	string GetCategoryMessage(string category, int count)
	{
		string plural = "";
		if (count > 1) plural = "s";
		
		if (category == "MECANICIEN")
		{
			if (count == 1)
				return "[INVENTAIRE] Ce kit de reparation est reserve aux mecaniciens. Il a ete retire de votre inventaire.";
			return string.Format("[INVENTAIRE] %1 kits de reparation reserves aux mecaniciens ont ete retires de votre inventaire.", count);
		}
		if (category == "POLICE_ARMY")
		{
			if (count == 1)
				return "[INVENTAIRE] Cet equipement est reserve aux forces de l ordre (Police/Militaire). Il a ete retire de votre inventaire.";
			return string.Format("[INVENTAIRE] %1 equipements reserves aux forces de l ordre (Police/Militaire) ont ete retires de votre inventaire.", count);
		}
		if (category == "MEDECIN")
		{
			if (count == 1)
				return "[INVENTAIRE] Cet equipement medical est reserve aux medecins (EMS). Il a ete retire de votre inventaire.";
			return string.Format("[INVENTAIRE] %1 equipements medicaux reserves aux medecins (EMS) ont ete retires de votre inventaire.", count);
		}
		if (category == "RMY_EMS")
		{
			if (count == 1)
				return "[INVENTAIRE] Cette radio est reserve aux medecins et force de l'ordres. Il a ete retire de votre inventaire.";
			return string.Format("[INVENTAIRE] %1 equipements radio reserves aux medecins et force de l'ordres ont ete retires de votre inventaire.", count);
		}
		return "[INVENTAIRE] Item retire.";
	}
	
	//------------------------------------------------------------------------------------------------
	// Tick serveur : scanne tous les joueurs connectes
	//------------------------------------------------------------------------------------------------
	void Tick()
	{
		if (!Replication.IsServer())
			return;
		
		m_TickCount++;
		
		PlayerManager pm = GetGame().GetPlayerManager();
		if (!pm)
			return;
		
		array<int> playerIds = new array<int>();
		pm.GetPlayers(playerIds);
		
		foreach (int playerId : playerIds)
		{
			ProcessPlayer(playerId);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Verifie un joueur : purge tous les items dont il n a pas le metier requis.
	//------------------------------------------------------------------------------------------------
	void ProcessPlayer(int playerId)
	{
		// 1. Recupere le metier
		JobPlayerData data = JobManager.GetInstance().GetPlayerData(playerId);
		if (!data)
			return;
		int job = data.m_Job;
		
		// 2. Recupere le character
		PlayerController pc = GetGame().GetPlayerManager().GetPlayerController(playerId);
		if (!pc)
			return;
		IEntity character = pc.GetControlledEntity();
		if (!character)
			return;
		
		// 3. Recupere son inventory storage manager
		SCR_InventoryStorageManagerComponent invMgr = SCR_InventoryStorageManagerComponent.Cast(
			character.FindComponent(SCR_InventoryStorageManagerComponent));
		if (!invMgr)
			return;
		
		// 4. Liste tous les items
		array<IEntity> items = new array<IEntity>();
		invMgr.GetItems(items);
		
		// 5. Collecte les items a retirer, par categorie
		array<IEntity> itemsMecanicien = new array<IEntity>();
		array<IEntity> itemsPoliceArmy = new array<IEntity>();
		array<IEntity> itemsMedecin = new array<IEntity>();
		array<IEntity> itemsRMYEMS = new array<IEntity>();
		
		foreach (IEntity item : items)
		{
			if (!item)
				continue;
			
			string cat = GetItemCategory(item);
			if (cat == "")
				continue;  // pas dans le registry
			
			// Skip si le joueur est autorise pour cette categorie
			if (IsPlayerAllowedForCategory(job, cat))
				continue;
			
			if (cat == "MECANICIEN")
				itemsMecanicien.Insert(item);
			else if (cat == "POLICE_ARMY")
				itemsPoliceArmy.Insert(item);
			else if (cat == "MEDECIN")
				itemsMedecin.Insert(item);
			else if (cat == "RMY_EMS")
				itemsRMYEMS.Insert(item);
		}
		
		// 6. Supprime + notifie categorie par categorie
		int totalRemoved = 0;
		totalRemoved = totalRemoved + RemoveItemsAndNotify(playerId, invMgr, itemsMecanicien, "MECANICIEN");
		totalRemoved = totalRemoved + RemoveItemsAndNotify(playerId, invMgr, itemsPoliceArmy, "POLICE_ARMY");
		totalRemoved = totalRemoved + RemoveItemsAndNotify(playerId, invMgr, itemsMedecin, "MEDECIN");
		totalRemoved = totalRemoved + RemoveItemsAndNotify(playerId, invMgr, itemsRMYEMS, "RMY_EMS");
		
		if (totalRemoved > 0)
			Print(string.Format("[JobRepairKitPurger] Player %1 : %2 items retires au total",
				playerId, totalRemoved), LogLevel.NORMAL);
	}
	
	//------------------------------------------------------------------------------------------------
	// Retire les items d une categorie et envoie une notif au joueur (une seule notif par cat).
	// Retourne le nombre d items effectivement retires.
	//------------------------------------------------------------------------------------------------
	int RemoveItemsAndNotify(int playerId, SCR_InventoryStorageManagerComponent invMgr,
		array<IEntity> itemsToRemove, string category)
	{
		if (itemsToRemove.IsEmpty())
			return 0;
		
		int removedCount = 0;
		foreach (IEntity item : itemsToRemove)
		{
			BaseInventoryStorageComponent parentStorage = invMgr.FindStorageForItem(item);
			bool removed = invMgr.TryRemoveItemFromStorage(item, parentStorage);
			SCR_EntityHelper.DeleteEntityAndChildren(item);
			removedCount = removedCount + 1;
		}
		
		if (removedCount > 0)
		{
			string msg = GetCategoryMessage(category, removedCount);
			JobManager.GetInstance().NotifyPlayerChat(playerId, msg);
		}
		return removedCount;
	}
	
	//------------------------------------------------------------------------------------------------
	// Retourne la categorie d un item (via son GUID de prefab) ou "" si non enregistre.
	//------------------------------------------------------------------------------------------------
	string GetItemCategory(IEntity item)
	{
		EntityPrefabData prefabData = item.GetPrefabData();
		if (!prefabData)
			return "";
		ResourceName prefabName = prefabData.GetPrefabName();
		if (prefabName == "" || prefabName == ResourceName.Empty)
			return "";
		
		string prefabStr = prefabName;
		int count = m_ItemRegistry.Count();
		for (int i = 0; i < count; i++)
		{
			JobPurgerItemEntry entry = m_ItemRegistry.Get(i);
			if (!entry)
				continue;
			if (prefabStr.IndexOf(entry.m_Guid) == 0)
				return entry.m_Category;
		}
		return "";
	}
}
