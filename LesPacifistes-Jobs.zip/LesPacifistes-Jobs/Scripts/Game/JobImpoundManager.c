//------------------------------------------------------------------------------------------------
// JobImpoundManager.c
// Singleton serveur gerant la fourriere pour la mise en fourriere des vehicules par la police.
//
// Position placeholder : a remplacer par les vraies coordonnees du boss apres test in-game.
// Pour eviter les vehicules empiles, chaque vehicule mis en fourriere se teleporte
// a la zone fourriere AVEC UN DECALAGE ALEATOIRE de 5-10m sur X et Z.
//------------------------------------------------------------------------------------------------

class JobImpoundManager
{
	static ref JobImpoundManager s_Instance;
	
	// Position de la fourriere - A REMPLACER PAR LE BOSS avec les vraies coordonnees in-game
	const float IMPOUND_X = 3919.773;
	const float IMPOUND_Y = 22.914;
	const float IMPOUND_Z = 4500.467;


	
	// Decalage aleatoire pour eviter que les vehicules s empilent
	const float MIN_OFFSET = 5.0;
	const float MAX_OFFSET = 10.0;
	
	//------------------------------------------------------------------------------------------------
	static JobImpoundManager GetInstance()
	{
		if (!s_Instance)
			s_Instance = new JobImpoundManager();
		return s_Instance;
	}
	
	//------------------------------------------------------------------------------------------------
	// Teleporte un vehicule en fourriere avec un offset aleatoire
	// Renvoie true si OK, false si vehicule introuvable ou autre probleme
	//------------------------------------------------------------------------------------------------
	bool ImpoundVehicle(RplId vehicleRplId)
	{
		// Resoud l entite du vehicule depuis son RplId
		RplComponent rpl = RplComponent.Cast(Replication.FindItem(vehicleRplId));
		if (!rpl)
			return false;
		IEntity vehicle = rpl.GetEntity();
		if (!vehicle)
			return false;
		
		// Verifie que c est bien un vehicule (Vehicle ou ses derives)
		Vehicle veh = Vehicle.Cast(vehicle);
		if (!veh)
			return false;
		
		// Calcule un offset aleatoire (-MAX a +MAX, evitant la zone -MIN a +MIN)
		// Resultat : entre 5 et 10m de la position fourriere (peu importe la direction)
		float offsetX = RandomOffset();
		float offsetZ = RandomOffset();
		
		// Position cible
		vector targetPos = Vector(IMPOUND_X + offsetX, IMPOUND_Y, IMPOUND_Z + offsetZ);
		
		// Aligne sur le sol pour eviter les vehicules dans les airs ou sous terre
		BaseWorld world = GetGame().GetWorld();
		if (world)
		{
			float surfaceY = world.GetSurfaceY(targetPos[0], targetPos[2]);
			targetPos[1] = surfaceY + 0.3;
		}
		
		// Teleporte le vehicule
		vehicle.SetOrigin(targetPos);
		
		// Stoppe la physique du vehicule (sinon il garde son momentum)
		Physics phys = vehicle.GetPhysics();
		if (phys)
		{
			phys.SetVelocity(Vector(0, 0, 0));
			phys.SetAngularVelocity(Vector(0, 0, 0));
		}
		
		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	// Genere une valeur aleatoire entre MIN_OFFSET et MAX_OFFSET, signee (+ ou -)
	//------------------------------------------------------------------------------------------------
	float RandomOffset()
	{
		float range = MAX_OFFSET - MIN_OFFSET;
		float val = MIN_OFFSET + Math.RandomFloat01() * range;
		// Sign aleatoire
		if (Math.RandomFloat01() < 0.5)
			val = -val;
		return val;
	}
}
