//------------------------------------------------------------------------------------------------
// JobGangData.c
// Structures de donnees pour le systeme de gang des Voyous.
//
// Un gang a :
//   - un nom unique
//   - un chef (UID du createur)
//   - une liste de membres (UIDs)
//   - une cagnotte de benefices (capsules accumulees via les taxes de zone)
//
// Les zones d extraction controlees sont stockees separement dans JobGangManager
// (map zoneId -> gangName) car une zone appartient a un gang, pas l inverse.
//------------------------------------------------------------------------------------------------

class JobGangMember
{
	string m_UID;          // UID persistant du membre
	string m_DisplayName;  // Nom RP ou playername (pour affichage)
}

class JobGang
{
	string m_Name;                       // Nom unique du gang
	string m_ChefUID;                    // UID du chef (createur)
	string m_ChefDisplayName;            // Nom du chef
	int m_Benefits;                      // Cagnotte de capsules accumulees (taxes)
	ref array<ref JobGangMember> m_Members;  // Membres (hors chef)
	
	void JobGang()
	{
		m_Benefits = 0;
		m_Members = new array<ref JobGangMember>();
	}
	
	//------------------------------------------------------------------------------------------------
	// True si l UID est le chef du gang
	//------------------------------------------------------------------------------------------------
	bool IsChef(string uid)
	{
		return m_ChefUID == uid;
	}
	
	//------------------------------------------------------------------------------------------------
	// True si l UID est membre (hors chef) du gang
	//------------------------------------------------------------------------------------------------
	bool IsMember(string uid)
	{
		foreach (JobGangMember m : m_Members)
		{
			if (m && m.m_UID == uid)
				return true;
		}
		return false;
	}
	
	//------------------------------------------------------------------------------------------------
	// True si l UID fait partie du gang (chef OU membre)
	//------------------------------------------------------------------------------------------------
	bool Contains(string uid)
	{
		return IsChef(uid) || IsMember(uid);
	}
	
	//------------------------------------------------------------------------------------------------
	// Ajoute un membre (si pas deja present et pas le chef)
	//------------------------------------------------------------------------------------------------
	bool AddMember(string uid, string displayName)
	{
		if (Contains(uid))
			return false;
		JobGangMember m = new JobGangMember();
		m.m_UID = uid;
		m.m_DisplayName = displayName;
		m_Members.Insert(m);
		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	// Retire un membre par UID
	//------------------------------------------------------------------------------------------------
	bool RemoveMember(string uid)
	{
		for (int i = 0; i < m_Members.Count(); i++)
		{
			JobGangMember m = m_Members.Get(i);
			if (m && m.m_UID == uid)
			{
				m_Members.Remove(i);
				return true;
			}
		}
		return false;
	}
	
	//------------------------------------------------------------------------------------------------
	// Nombre total de personnes dans le gang (chef + membres)
	//------------------------------------------------------------------------------------------------
	int GetTotalSize()
	{
		return 1 + m_Members.Count();  // +1 pour le chef
	}
}
