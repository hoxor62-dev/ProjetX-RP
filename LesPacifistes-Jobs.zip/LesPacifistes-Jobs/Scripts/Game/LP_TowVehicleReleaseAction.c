//------------------------------------------------------------------------------------------------
// LP_TowVehicleReleaseAction.c
// Action "Descendre le vehicule" a placer sur les depanneuses via Workbench (ActionsManagerComponent).
// Visible pour les metiers MECANICIEN et FOURRIERE (les 2 ont besoin de la depanneuse).
//
// Comportement : retire le vehicule remorque de la depanneuse et le pose 4m derriere elle.
//------------------------------------------------------------------------------------------------

class LP_TowVehicleReleaseAction : ScriptedUserAction
{
	//------------------------------------------------------------------------------------------------
	// Autorise l usage de la depanneuse pour MECANICIEN ou FOURRIERE
	//------------------------------------------------------------------------------------------------
	protected bool CanUseTowTruck(IEntity user)
	{
		if (!user) return false;
		JobCharacterJobComponent jcjc = JobCharacterJobComponent.Cast(
			user.FindComponent(JobCharacterJobComponent));
		if (!jcjc) return false;
		EJobType job = jcjc.GetJob();
		return (job == EJobType.MECANICIEN || job == EJobType.FOURRIERE);
	}

	//------------------------------------------------------------------------------------------------
	override bool CanBeShownScript(IEntity user)
	{
		return CanUseTowTruck(user);
	}

	//------------------------------------------------------------------------------------------------
	override bool CanBePerformedScript(IEntity user)
	{
		return CanUseTowTruck(user);
	}

	//------------------------------------------------------------------------------------------------
	override bool GetActionNameScript(out string outName)
	{
		outName = "Descendre le vehicule";
		return true;
	}

	//------------------------------------------------------------------------------------------------
	override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
	{
		PlayerController pc = PlayerController.Cast(GetGame().GetPlayerController());
		if (!pc) return;
		if (pUserEntity != pc.GetControlledEntity()) return;

		if (!CanUseTowTruck(pUserEntity))
			return;

		RplComponent rpl = RplComponent.Cast(pOwnerEntity.FindComponent(RplComponent));
		if (!rpl) return;

		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;

		jpc.ClientAskReleaseTowedVehicle(rpl.Id());
	}
}
