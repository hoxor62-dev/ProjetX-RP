//------------------------------------------------------------------------------------------------
// JobExtractAction.c
// Action F sur les prefabs source d'extraction (roche, plant cannabis, plant cocaine).
// A attacher via l'ActionsManagerComponent du prefab.
//
// L'action envoie au serveur une demande de demarrage/reprise de session.
//------------------------------------------------------------------------------------------------

class JobExtractAction : ScriptedUserAction
{
	//------------------------------------------------------------------------------------------------
	override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
	{
		if (!pOwnerEntity || !pUserEntity)
			return;
		
		// Securite : seul le joueur local fait la demande
		PlayerController localPC = GetGame().GetPlayerController();
		if (!localPC)
			return;
		IEntity localEntity = localPC.GetControlledEntity();
		if (localEntity != pUserEntity)
			return;
		
		// Recupere le RplComponent du prefab pour avoir le RplId a transmettre au serveur
		RplComponent rpl = RplComponent.Cast(pOwnerEntity.FindComponent(RplComponent));
		if (!rpl)
			return;
		
		JobPlayerComponent jpc = JobPlayerComponent.Cast(localPC.FindComponent(JobPlayerComponent));
		if (!jpc)
			return;
		
		jpc.ClientAskStartMining(rpl.Id(), false); // false = extraction
	}
	
	//------------------------------------------------------------------------------------------------
	override bool CanBeShownScript(IEntity user)
	{
		// Visible pour tous - le serveur fera le filtrage metier (ROCK reserve aux mineurs)
		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	override bool CanBePerformedScript(IEntity user)
	{
		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	override bool GetActionNameScript(out string outName)
	{
		// Le nom precis sera defini dans le Workbench selon le prefab
		// Par defaut on met un libelle generique
		outName = "Extraire";
		return true;
	}
}
