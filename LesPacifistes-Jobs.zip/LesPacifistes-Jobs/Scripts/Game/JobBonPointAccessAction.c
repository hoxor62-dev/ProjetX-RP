//------------------------------------------------------------------------------------------------
// JobBonPointAccessAction.c
// UserAction a placer sur l ordinateur LeBonPoint (entity dans Workbench).
// Au clic : envoie une RPC au serveur pour ouvrir le menu d acces.
//------------------------------------------------------------------------------------------------

class JobBonPointAccessAction : ScriptedUserAction
{
	override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
	{
		PlayerController pc = PlayerController.Cast(GetGame().GetPlayerController());
		if (!pc) return;
		// Filtre dedicated server : seul le client propre de l action declenche le menu
		if (pUserEntity != pc.GetControlledEntity()) return;
		
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		jpc.ClientAskOpenBonPoint();
	}
	
	override bool CanBePerformedScript(IEntity user)
	{
		return true;
	}
	
	override bool CanBeShownScript(IEntity user)
	{
		return true;
	}
}
