//------------------------------------------------------------------------------------------------
// JobPoliceRecordMenu.c
//
// Menu "Fiche Judiciaire Avancee" pour les forces de l ordre (Police + Militaire).
// Accessible via UserAction sur un ordinateur du commissariat.
//
// Structure :
//   1. Champ de recherche joueur (par nom RP ou UID) + liste de resultats
//   2. Section fiche (visible quand un joueur est selectionne) :
//        - Header : nom RP + UID + statut colore
//        - Barre d onglets : Identite / Peines / Infractions / Mandats / Notes
//        - Contenu de l onglet actif
//   3. Bouton retour + fermer
//
// Les onglets Peines / Infractions / Mandats / Notes affichent leur contenu en Phase 3-4.
//------------------------------------------------------------------------------------------------

enum EPoliceMenuTab
{
	IDENTITY = 0,
	SENTENCES = 1,
	INFRACTIONS = 2,
	WARRANTS = 3,
	NOTES = 4
}

class JobPoliceRecordMenu : ChimeraMenuBase
{
	// === Widgets principaux ===
	Widget m_RootWidget;
	TextWidget m_TitleText;
	
	// Section recherche
	Widget m_SearchPanel;
	EditBoxWidget m_SearchInput;
	ButtonWidget m_BtnSearch;
	Widget m_ResultsContainer;
	TextWidget m_ResultsInfo;
	
	// Section fiche
	Widget m_FichePanel;
	TextWidget m_FicheNameText;
	TextWidget m_FicheUIDText;
	TextWidget m_FicheStatusText;
	TextWidget m_FicheRehabText;
	
	// Onglets
	ButtonWidget m_TabIdentity;
	ButtonWidget m_TabSentences;
	ButtonWidget m_TabInfractions;
	ButtonWidget m_TabWarrants;
	ButtonWidget m_TabNotes;
	
	// Contenus par onglet (un seul visible a la fois)
	Widget m_ContentIdentity;
	Widget m_ContentSentences;
	Widget m_ContentInfractions;
	Widget m_ContentWarrants;
	Widget m_ContentNotes;
	
	// Onglet Identite : dropdown statut + bouton editer detail
	ButtonWidget m_BtnStatusFree;
	ButtonWidget m_BtnStatusPrison;
	ButtonWidget m_BtnStatusFugitive;
	ButtonWidget m_BtnStatusWanted;
	ButtonWidget m_BtnStatusProbation;
	EditBoxWidget m_StatusDetailInput;
	ButtonWidget m_BtnStatusDetailSave;
	
	// Boutons "+" pour ajouter dans chaque section (actifs en Phase 3)
	ButtonWidget m_BtnAddSentence;
	ButtonWidget m_BtnAddWarrant;
	ButtonWidget m_BtnAddNote;
	
	// Containers de listes (remplis dynamiquement)
	Widget m_SentencesList;
	Widget m_WarrantsList;
	Widget m_NotesList;
	Widget m_InfractionsList;
	
	// Popups d ajout
	Widget m_PopupAddSentence;
	EditBoxWidget m_PopupSentenceCharge;
	EditBoxWidget m_PopupSentenceDuration;
	ButtonWidget m_PopupSentenceOk;
	ButtonWidget m_PopupSentenceCancel;
	
	Widget m_PopupAddWarrant;
	EditBoxWidget m_PopupWarrantMotive;
	EditBoxWidget m_PopupWarrantDuration;
	ButtonWidget m_PopupWarrantTypeSearch;
	ButtonWidget m_PopupWarrantTypeInterrog;
	ButtonWidget m_PopupWarrantTypeArrest;
	int m_PopupWarrantType = 0;
	ButtonWidget m_PopupWarrantOk;
	ButtonWidget m_PopupWarrantCancel;
	
	Widget m_PopupAddNote;
	EditBoxWidget m_PopupNoteText;
	ButtonWidget m_PopupNoteOk;
	ButtonWidget m_PopupNoteCancel;
	
	// Retour + Fermer
	ButtonWidget m_BtnClose;
	ButtonWidget m_BtnBackToSearch;
	
	// === Etat ===
	string m_SelectedUID = "";      // UID du joueur affiche dans la fiche
	string m_SelectedName = "";     // Nom RP du joueur affiche
	EPoliceMenuTab m_ActiveTab = EPoliceMenuTab.IDENTITY;
	
	// Cache resultats de recherche pour cliquer sur un resultat
	ref map<ButtonWidget, string> m_ResultButtonToUID = new map<ButtonWidget, string>();
	
	// Instance statique pour recevoir les push depuis RPCs
	static JobPoliceRecordMenu s_Instance;
	
	static JobPoliceRecordMenu GetOpenMenu()
	{
		return s_Instance;
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuOpen()
	{
		super.OnMenuOpen();
		s_Instance = this;
		JobFocusHandler.ClearRegistry();
		m_RootWidget = GetRootWidget();
		if (!m_RootWidget)
			return;
		
		FindWidgets();
		AttachHandlers();
		
		// Etat initial : section recherche visible, fiche cachee
		ShowSearchPanel();
		if (m_TitleText)
			m_TitleText.SetText("FICHE JUDICIAIRE - CONSULTATION");
		if (m_ResultsInfo)
			m_ResultsInfo.SetText("Tapez un nom RP, un UID ou une plaque (AB-123-CD) puis cliquez Rechercher (recherche vide = tous les dossiers).");
		
		// Focus initial
		if (m_SearchInput)
			GetGame().GetWorkspace().SetFocusedWidget(m_SearchInput);
		
		// Charge une recherche vide pour afficher les dossiers existants
		RequestSearch("");
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuClose()
	{
		if (s_Instance == this)
			s_Instance = null;
		super.OnMenuClose();
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuUpdate(float tDelta)
	{
		super.OnMenuUpdate(tDelta);
		if (GetGame().GetInputManager().GetActionValue("MenuBack") > 0.5)
		{
			// Si on est sur la fiche, retour a la recherche
			if (m_FichePanel && m_FichePanel.IsVisible())
			{
				ShowSearchPanel();
				return;
			}
			CloseMenuInternal();
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== INIT WIDGETS =====
	//------------------------------------------------------------------------------------------------
	
	void FindWidgets()
	{
		m_TitleText = TextWidget.Cast(m_RootWidget.FindAnyWidget("TitleText"));
		
		m_SearchPanel = m_RootWidget.FindAnyWidget("SearchPanel");
		m_SearchInput = EditBoxWidget.Cast(m_RootWidget.FindAnyWidget("SearchInput"));
		m_BtnSearch = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnSearch"));
		m_ResultsContainer = m_RootWidget.FindAnyWidget("ResultsContainer");
		m_ResultsInfo = TextWidget.Cast(m_RootWidget.FindAnyWidget("ResultsInfo"));
		
		m_FichePanel = m_RootWidget.FindAnyWidget("FichePanel");
		m_FicheNameText = TextWidget.Cast(m_RootWidget.FindAnyWidget("FicheNameText"));
		m_FicheUIDText = TextWidget.Cast(m_RootWidget.FindAnyWidget("FicheUIDText"));
		m_FicheStatusText = TextWidget.Cast(m_RootWidget.FindAnyWidget("FicheStatusText"));
		m_FicheRehabText = TextWidget.Cast(m_RootWidget.FindAnyWidget("FicheRehabText"));
		
		m_TabIdentity = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("TabIdentity"));
		m_TabSentences = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("TabSentences"));
		m_TabInfractions = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("TabInfractions"));
		m_TabWarrants = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("TabWarrants"));
		m_TabNotes = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("TabNotes"));
		
		m_ContentIdentity = m_RootWidget.FindAnyWidget("ContentIdentity");
		m_ContentSentences = m_RootWidget.FindAnyWidget("ContentSentences");
		m_ContentInfractions = m_RootWidget.FindAnyWidget("ContentInfractions");
		m_ContentWarrants = m_RootWidget.FindAnyWidget("ContentWarrants");
		m_ContentNotes = m_RootWidget.FindAnyWidget("ContentNotes");
		
		m_BtnStatusFree = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnStatusFree"));
		m_BtnStatusPrison = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnStatusPrison"));
		m_BtnStatusFugitive = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnStatusFugitive"));
		m_BtnStatusWanted = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnStatusWanted"));
		m_BtnStatusProbation = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnStatusProbation"));
		m_StatusDetailInput = EditBoxWidget.Cast(m_RootWidget.FindAnyWidget("StatusDetailInput"));
		m_BtnStatusDetailSave = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnStatusDetailSave"));
		
		m_BtnAddSentence = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnAddSentence"));
		m_BtnAddWarrant = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnAddWarrant"));
		m_BtnAddNote = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnAddNote"));
		
		// Listes dynamiques
		m_SentencesList = m_RootWidget.FindAnyWidget("SentencesList");
		m_WarrantsList = m_RootWidget.FindAnyWidget("WarrantsList");
		m_NotesList = m_RootWidget.FindAnyWidget("NotesList");
		m_InfractionsList = m_RootWidget.FindAnyWidget("InfractionsList");
		
		// Popup ajout peine
		m_PopupAddSentence = m_RootWidget.FindAnyWidget("PopupAddSentence");
		m_PopupSentenceCharge = EditBoxWidget.Cast(m_RootWidget.FindAnyWidget("PopupSentenceCharge"));
		m_PopupSentenceDuration = EditBoxWidget.Cast(m_RootWidget.FindAnyWidget("PopupSentenceDuration"));
		m_PopupSentenceOk = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("PopupSentenceOk"));
		m_PopupSentenceCancel = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("PopupSentenceCancel"));
		
		// Popup ajout mandat
		m_PopupAddWarrant = m_RootWidget.FindAnyWidget("PopupAddWarrant");
		m_PopupWarrantMotive = EditBoxWidget.Cast(m_RootWidget.FindAnyWidget("PopupWarrantMotive"));
		m_PopupWarrantDuration = EditBoxWidget.Cast(m_RootWidget.FindAnyWidget("PopupWarrantDuration"));
		m_PopupWarrantTypeSearch = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("PopupWarrantTypeSearch"));
		m_PopupWarrantTypeInterrog = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("PopupWarrantTypeInterrog"));
		m_PopupWarrantTypeArrest = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("PopupWarrantTypeArrest"));
		m_PopupWarrantOk = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("PopupWarrantOk"));
		m_PopupWarrantCancel = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("PopupWarrantCancel"));
		
		// Popup ajout note
		m_PopupAddNote = m_RootWidget.FindAnyWidget("PopupAddNote");
		m_PopupNoteText = EditBoxWidget.Cast(m_RootWidget.FindAnyWidget("PopupNoteText"));
		m_PopupNoteOk = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("PopupNoteOk"));
		m_PopupNoteCancel = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("PopupNoteCancel"));
		
		// Cache popups
		if (m_PopupAddSentence) m_PopupAddSentence.SetVisible(false);
		if (m_PopupAddWarrant) m_PopupAddWarrant.SetVisible(false);
		if (m_PopupAddNote) m_PopupAddNote.SetVisible(false);
		
		m_BtnClose = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnClose"));
		m_BtnBackToSearch = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnBackToSearch"));
	}
	
	void AttachHandlers()
	{
		AttachHandler(m_BtnSearch, "search");
		AttachHandler(m_BtnClose, "close");
		AttachHandler(m_BtnBackToSearch, "back");
		
		AttachHandler(m_TabIdentity, "tab_identity");
		AttachHandler(m_TabSentences, "tab_sentences");
		AttachHandler(m_TabInfractions, "tab_infractions");
		AttachHandler(m_TabWarrants, "tab_warrants");
		AttachHandler(m_TabNotes, "tab_notes");
		
		AttachHandler(m_BtnStatusFree, "status_free");
		AttachHandler(m_BtnStatusPrison, "status_prison");
		AttachHandler(m_BtnStatusFugitive, "status_fugitive");
		AttachHandler(m_BtnStatusWanted, "status_wanted");
		AttachHandler(m_BtnStatusProbation, "status_probation");
		AttachHandler(m_BtnStatusDetailSave, "status_detail_save");
		
		AttachHandler(m_BtnAddSentence, "add_sentence");
		AttachHandler(m_BtnAddWarrant, "add_warrant");
		AttachHandler(m_BtnAddNote, "add_note");
		
		// Popup peine
		AttachHandler(m_PopupSentenceOk, "popup_sentence_ok");
		AttachHandler(m_PopupSentenceCancel, "popup_sentence_cancel");
		
		// Popup mandat
		AttachHandler(m_PopupWarrantTypeSearch, "popup_warrant_type_search");
		AttachHandler(m_PopupWarrantTypeInterrog, "popup_warrant_type_interrog");
		AttachHandler(m_PopupWarrantTypeArrest, "popup_warrant_type_arrest");
		AttachHandler(m_PopupWarrantOk, "popup_warrant_ok");
		AttachHandler(m_PopupWarrantCancel, "popup_warrant_cancel");
		
		// Popup note
		AttachHandler(m_PopupNoteOk, "popup_note_ok");
		AttachHandler(m_PopupNoteCancel, "popup_note_cancel");
	}
	
	void AttachHandler(ButtonWidget btn, string action)
	{
		if (!btn) return;
		PoliceMenuHandler h = new PoliceMenuHandler();
		h.m_Menu = this;
		h.m_Action = action;
		btn.AddHandler(h);
		JobFocusHandler.Attach(btn);
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== NAVIGATION =====
	//------------------------------------------------------------------------------------------------
	
	void ShowSearchPanel()
	{
		if (m_SearchPanel) m_SearchPanel.SetVisible(true);
		if (m_FichePanel) m_FichePanel.SetVisible(false);
		if (m_SearchInput)
			GetGame().GetWorkspace().SetFocusedWidget(m_SearchInput);
	}
	
	void ShowFichePanel()
	{
		if (m_SearchPanel) m_SearchPanel.SetVisible(false);
		if (m_FichePanel) m_FichePanel.SetVisible(true);
		SwitchTab(EPoliceMenuTab.IDENTITY);
	}
	
	//------------------------------------------------------------------------------------------------
	// Change l onglet actif
	//------------------------------------------------------------------------------------------------
	void SwitchTab(EPoliceMenuTab tab)
	{
		m_ActiveTab = tab;
		// Masque tout puis affiche celui choisi
		if (m_ContentIdentity)    m_ContentIdentity.SetVisible(tab == EPoliceMenuTab.IDENTITY);
		if (m_ContentSentences)   m_ContentSentences.SetVisible(tab == EPoliceMenuTab.SENTENCES);
		if (m_ContentInfractions) m_ContentInfractions.SetVisible(tab == EPoliceMenuTab.INFRACTIONS);
		if (m_ContentWarrants)    m_ContentWarrants.SetVisible(tab == EPoliceMenuTab.WARRANTS);
		if (m_ContentNotes)       m_ContentNotes.SetVisible(tab == EPoliceMenuTab.NOTES);
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== RECHERCHE =====
	//------------------------------------------------------------------------------------------------
	
	void RequestSearch(string query)
	{
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		jpc.ClientAskPoliceSearch(query);
	}
	
	//------------------------------------------------------------------------------------------------
	// Recoit les resultats de recherche depuis le serveur.
	// Format : chaque triplet (uid, name, statusVal) est passe via des arrays paralleles.
	//------------------------------------------------------------------------------------------------
	void DisplaySearchResults(array<string> uids, array<string> names, array<int> statuses)
	{
		if (!m_ResultsContainer)
			return;
		
		// Reset resultats
		Widget child = m_ResultsContainer.GetChildren();
		while (child)
		{
			Widget next = child.GetSibling();
			child.RemoveFromHierarchy();
			child = next;
		}
		m_ResultButtonToUID.Clear();
		
		int count = uids.Count();
		if (count == 0)
		{
			if (m_ResultsInfo)
				m_ResultsInfo.SetText("Aucun dossier trouve.");
			return;
		}
		
		if (m_ResultsInfo)
			m_ResultsInfo.SetText(string.Format("%1 dossier(s) trouve(s) :", count.ToString()));
		
		WorkspaceWidget ws = GetGame().GetWorkspace();
		if (!ws)
			return;
		
		// Cree une entree cliquable par resultat (via layout SmsEntry generique)
		string entryLayout = "{9D68BEB73DF970D8}UI/layouts/JobSmsEntry.layout";
		int yPos = 0;
		const int ENTRY_HEIGHT = 40;
		const int ENTRY_SPACING = 4;
		
		for (int i = 0; i < count; i++)
		{
			string uid = uids.Get(i);
			string name = names.Get(i);
			int statusVal = statuses.Get(i);
			
			Widget entry = ws.CreateWidgets(entryLayout, m_ResultsContainer);
			if (!entry)
				continue;
			
			FrameSlot.SetPos(entry, 0, yPos);
			FrameSlot.SetSize(entry, 620, ENTRY_HEIGHT);
			yPos += ENTRY_HEIGHT + ENTRY_SPACING;
			
			TextWidget nameW = TextWidget.Cast(entry.FindAnyWidget("PlayerName"));
			if (nameW)
			{
				string statusLabel = JobJudicialStatusHelper.GetLabel(statusVal);
				string uidShort = uid;
				if (uid.Length() > 12)
					uidShort = uid.Substring(0, 12) + "...";
				nameW.SetText(string.Format("%1  [%2]  UID: %3",
					name, statusLabel, uidShort));
			}
			
			ButtonWidget btn = ButtonWidget.Cast(entry.FindAnyWidget("SelectButton"));
			if (btn)
			{
				m_ResultButtonToUID.Set(btn, uid);
				PoliceSearchResultHandler h = new PoliceSearchResultHandler();
				h.m_Menu = this;
				h.m_UID = uid;
				h.m_Name = name;
				btn.AddHandler(h);
				JobFocusHandler.Attach(btn);
			}
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Ouvre la fiche detaillee d un joueur (apres clic sur un resultat)
	//------------------------------------------------------------------------------------------------
	void OpenFicheFor(string uid, string name)
	{
		m_SelectedUID = uid;
		m_SelectedName = name;
		
		// Demande au serveur les infos completes
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		jpc.ClientAskPoliceGetRecord(uid);
		
		ShowFichePanel();
		
		// Pre-affichage avec ce qu on sait deja
		if (m_FicheNameText)
			m_FicheNameText.SetText(string.Format("Nom RP : %1", name));
		if (m_FicheUIDText)
			m_FicheUIDText.SetText(string.Format("UID : %1", uid));
		if (m_FicheStatusText)
			m_FicheStatusText.SetText("Statut : chargement...");
		if (m_FicheRehabText)
			m_FicheRehabText.SetText("Rehabilitation : chargement...");
	}
	
	//------------------------------------------------------------------------------------------------
	// Recoit la fiche detaillee depuis le serveur (header + statut + rehab).
	// Les listes (peines/mandats/notes) seront envoyees via RPCs separes en Phase 3.
	//------------------------------------------------------------------------------------------------
	void DisplayRecordHeader(string uid, string name, int statusVal, string statusDetail,
		int lastConvictionTs, int rehabTs, int nowTs)
	{
		if (uid != m_SelectedUID)
			return;  // reponse pour un autre joueur, ignore
		
		if (m_FicheNameText)
			m_FicheNameText.SetText(string.Format("Nom RP : %1", name));
		if (m_FicheUIDText)
			m_FicheUIDText.SetText(string.Format("UID : %1", uid));
		
		if (m_FicheStatusText)
		{
			string statusLabel = JobJudicialStatusHelper.GetLabel(statusVal);
			string txt = string.Format("Statut : %1", statusLabel);
			if (statusDetail != "")
				txt = txt + string.Format(" - %1", statusDetail);
			m_FicheStatusText.SetText(txt);
			
			// Couleur selon statut
			float r, g, b;
			JobJudicialStatusHelper.GetColor(statusVal, r, g, b);
			m_FicheStatusText.SetColor(Color.FromRGBA(r * 255, g * 255, b * 255, 255));
		}
		
		if (m_FicheRehabText)
		{
			if (rehabTs == 0)
				m_FicheRehabText.SetText("Rehabilitation : n/a (aucune condamnation)");
			else if (nowTs >= rehabTs)
				m_FicheRehabText.SetText("Rehabilitation : ELIGIBLE (peut etre efface)");
			else
			{
				int remaining = rehabTs - nowTs;
				int days = remaining / 86400;
				m_FicheRehabText.SetText(string.Format("Rehabilitation : dans %1 jours",
					days.ToString()));
			}
		}
		
		// Pre-remplit le champ detail statut
		if (m_StatusDetailInput)
			m_StatusDetailInput.SetText(statusDetail);
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== HANDLER PRINCIPAL =====
	//------------------------------------------------------------------------------------------------
	
	void OnButtonClicked(string action)
	{
		PlayerController pc = GetGame().GetPlayerController();
		JobPlayerComponent jpc = null;
		if (pc)
			jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		
		if (action == "close")
		{
			CloseMenuInternal();
		}
		else if (action == "back")
		{
			ShowSearchPanel();
		}
		else if (action == "search")
		{
			string q = "";
			if (m_SearchInput)
				q = m_SearchInput.GetText();
			RequestSearch(q);
		}
		else if (action == "tab_identity")    SwitchTab(EPoliceMenuTab.IDENTITY);
		else if (action == "tab_sentences")   SwitchTab(EPoliceMenuTab.SENTENCES);
		else if (action == "tab_infractions") SwitchTab(EPoliceMenuTab.INFRACTIONS);
		else if (action == "tab_warrants")    SwitchTab(EPoliceMenuTab.WARRANTS);
		else if (action == "tab_notes")       SwitchTab(EPoliceMenuTab.NOTES);
		else if (action == "status_free")      { if (jpc) jpc.ClientAskPoliceSetStatus(m_SelectedUID, 0, GetStatusDetail()); }
		else if (action == "status_prison")    { if (jpc) jpc.ClientAskPoliceSetStatus(m_SelectedUID, 1, GetStatusDetail()); }
		else if (action == "status_fugitive")  { if (jpc) jpc.ClientAskPoliceSetStatus(m_SelectedUID, 2, GetStatusDetail()); }
		else if (action == "status_wanted")    { if (jpc) jpc.ClientAskPoliceSetStatus(m_SelectedUID, 3, GetStatusDetail()); }
		else if (action == "status_probation") { if (jpc) jpc.ClientAskPoliceSetStatus(m_SelectedUID, 4, GetStatusDetail()); }
		else if (action == "status_detail_save")
		{
			// Renvoie le meme statut mais avec le detail mis a jour
			if (jpc)
				jpc.ClientAskPoliceSetStatusDetail(m_SelectedUID, GetStatusDetail());
		}
		else if (action == "add_sentence")
		{
			if (m_PopupAddSentence) m_PopupAddSentence.SetVisible(true);
			if (m_PopupSentenceCharge) { m_PopupSentenceCharge.SetText(""); GetGame().GetWorkspace().SetFocusedWidget(m_PopupSentenceCharge); }
			if (m_PopupSentenceDuration) m_PopupSentenceDuration.SetText("30");
		}
		else if (action == "add_warrant")
		{
			if (m_PopupAddWarrant) m_PopupAddWarrant.SetVisible(true);
			if (m_PopupWarrantMotive) { m_PopupWarrantMotive.SetText(""); GetGame().GetWorkspace().SetFocusedWidget(m_PopupWarrantMotive); }
			if (m_PopupWarrantDuration) m_PopupWarrantDuration.SetText("7");
			m_PopupWarrantType = 0;
		}
		else if (action == "add_note")
		{
			if (m_PopupAddNote) m_PopupAddNote.SetVisible(true);
			if (m_PopupNoteText) { m_PopupNoteText.SetText(""); GetGame().GetWorkspace().SetFocusedWidget(m_PopupNoteText); }
		}
		else if (action == "popup_sentence_ok")
		{
			if (!m_PopupSentenceCharge || !m_PopupSentenceDuration) return;
			string charge = m_PopupSentenceCharge.GetText();
			int duration = m_PopupSentenceDuration.GetText().ToInt();
			if (charge != "" && jpc)
			{
				jpc.ClientAskPoliceAddSentence(m_SelectedUID, charge, duration);
				if (m_PopupAddSentence) m_PopupAddSentence.SetVisible(false);
			}
		}
		else if (action == "popup_sentence_cancel")
		{
			if (m_PopupAddSentence) m_PopupAddSentence.SetVisible(false);
		}
		else if (action == "popup_warrant_type_search")   m_PopupWarrantType = 0;
		else if (action == "popup_warrant_type_interrog") m_PopupWarrantType = 1;
		else if (action == "popup_warrant_type_arrest")   m_PopupWarrantType = 2;
		else if (action == "popup_warrant_ok")
		{
			if (!m_PopupWarrantMotive || !m_PopupWarrantDuration) return;
			string motive = m_PopupWarrantMotive.GetText();
			int duration = m_PopupWarrantDuration.GetText().ToInt();
			if (motive != "" && jpc)
			{
				jpc.ClientAskPoliceAddWarrant(m_SelectedUID, m_PopupWarrantType, motive, duration);
				if (m_PopupAddWarrant) m_PopupAddWarrant.SetVisible(false);
			}
		}
		else if (action == "popup_warrant_cancel")
		{
			if (m_PopupAddWarrant) m_PopupAddWarrant.SetVisible(false);
		}
		else if (action == "popup_note_ok")
		{
			if (!m_PopupNoteText) return;
			string txt = m_PopupNoteText.GetText();
			if (txt != "" && jpc)
			{
				jpc.ClientAskPoliceAddNote(m_SelectedUID, txt);
				if (m_PopupAddNote) m_PopupAddNote.SetVisible(false);
			}
		}
		else if (action == "popup_note_cancel")
		{
			if (m_PopupAddNote) m_PopupAddNote.SetVisible(false);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Reception des listes depuis le serveur (parsing + affichage)
	// Format Sentences : idx@@charge@@duration@@issued@@active@@issuer, separes par |||
	//------------------------------------------------------------------------------------------------
	void DisplaySentences(string uid, string data)
	{
		if (uid != m_SelectedUID) return;
		BuildDynamicList(m_SentencesList, data, "sentence");
	}
	
	void DisplayWarrants(string uid, string data)
	{
		if (uid != m_SelectedUID) return;
		BuildDynamicList(m_WarrantsList, data, "warrant");
	}
	
	void DisplayNotes(string uid, string data)
	{
		if (uid != m_SelectedUID) return;
		BuildDynamicList(m_NotesList, data, "note");
	}
	
	void DisplayInfractions(string uid, string data)
	{
		if (uid != m_SelectedUID) return;
		BuildDynamicList(m_InfractionsList, data, "infraction");
	}
	
	//------------------------------------------------------------------------------------------------
	// Construit une liste avec entrees dynamiques et bouton delete par entree
	//------------------------------------------------------------------------------------------------
	void BuildDynamicList(Widget container, string data, string kind)
	{
		if (!container) return;
		// Vide le container
		Widget child = container.GetChildren();
		while (child)
		{
			Widget next = child.GetSibling();
			child.RemoveFromHierarchy();
			child = next;
		}
		if (data == "") return;
		
		WorkspaceWidget ws = GetGame().GetWorkspace();
		if (!ws) return;
		
		// Split par |||
		array<string> entries = new array<string>();
		SplitByDelim(data, "|||", entries);
		
		int yPos = 0;
		const int ENTRY_HEIGHT = 44;
		const int ENTRY_SPACING = 4;
		const int DELETE_BTN_WIDTH = 36;
		const int LIST_WIDTH = 720;
		
		string entryLayout = "{9D68BEB73DF970D8}UI/layouts/JobSmsEntry.layout";
		
		foreach (string entryStr : entries)
		{
			array<string> parts = new array<string>();
			SplitByDelim(entryStr, "@@", parts);
			if (parts.Count() < 2) continue;
			int idx = parts.Get(0).ToInt();
			
			// 1) Entree texte (largeur reduite pour laisser place au bouton X)
			Widget entry = ws.CreateWidgets(entryLayout, container);
			if (!entry) continue;
			
			FrameSlot.SetPos(entry, 0, yPos);
			FrameSlot.SetSize(entry, LIST_WIDTH - DELETE_BTN_WIDTH - 8, ENTRY_HEIGHT);
			
			TextWidget nameW = TextWidget.Cast(entry.FindAnyWidget("PlayerName"));
			if (nameW)
				nameW.SetText(FormatEntryLine(kind, parts));
			
			// IMPORTANT : on n attache PAS de handler sur SelectButton (evite le clic
			// accidentel qui supprimait tout). L entree affiche seulement le texte.
			ButtonWidget selBtn = ButtonWidget.Cast(entry.FindAnyWidget("SelectButton"));
			if (selBtn)
			{
				// On desactive visuellement le bouton pour indiquer qu il n est pas cliquable
				// (le focus/highlight ne fera rien sur cette zone).
				JobFocusHandler.Attach(selBtn);
			}
			
			// 2) Petit bouton "X" a droite pour supprimer
			ButtonWidget deleteBtn = CreateDeleteButton(container, kind, idx, yPos, LIST_WIDTH - DELETE_BTN_WIDTH, DELETE_BTN_WIDTH, ENTRY_HEIGHT);
			
			yPos += ENTRY_HEIGHT + ENTRY_SPACING;
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Cree un petit bouton "X" pour la suppression d une entree.
	// Reutilise le layout JobSmsEntry (comme les autres widgets dynamiques) pour eviter les
	// pieges de l API CreateWidget native (Color, WidgetFlags... variables selon versions).
	//------------------------------------------------------------------------------------------------
	ButtonWidget CreateDeleteButton(Widget parent, string kind, int index, int yPos, int xPos, int width, int height)
	{
		WorkspaceWidget ws = GetGame().GetWorkspace();
		if (!ws) return null;
		
		string entryLayout = "{9D68BEB73DF970D8}UI/layouts/JobSmsEntry.layout";
		Widget deleteEntry = ws.CreateWidgets(entryLayout, parent);
		if (!deleteEntry) return null;
		
		FrameSlot.SetPos(deleteEntry, xPos, yPos);
		FrameSlot.SetSize(deleteEntry, width, height);
		
		// Change le texte affiche en "X"
		TextWidget txt = TextWidget.Cast(deleteEntry.FindAnyWidget("PlayerName"));
		if (txt)
		{
			txt.SetText("  X");
			txt.SetColor(Color.FromRGBA(255, 80, 80, 255));
		}
		
		// Recupere le bouton pour attacher le handler de suppression
		ButtonWidget btn = ButtonWidget.Cast(deleteEntry.FindAnyWidget("SelectButton"));
		if (btn)
		{
			PoliceDeleteHandler h = new PoliceDeleteHandler();
			h.m_Menu = this;
			h.m_Kind = kind;
			h.m_Index = index;
			btn.AddHandler(h);
			JobFocusHandler.Attach(btn);
		}
		return btn;
	}
	
	//------------------------------------------------------------------------------------------------
	// Formate une entree en texte lisible selon le kind
	//------------------------------------------------------------------------------------------------
	string FormatEntryLine(string kind, array<string> parts)
	{
		if (kind == "sentence")
		{
			// idx@@charge@@duration@@issued@@active@@issuer
			if (parts.Count() < 6) return "?";
			string charge = parts.Get(1);
			int duration = parts.Get(2).ToInt();
			bool active = (parts.Get(4) == "1");
			string issuer = parts.Get(5);
			string status = "PURGEE";
			if (active) status = "EN COURS";
			string durLbl = duration.ToString() + "j";
			if (duration <= 0) durLbl = "a vie";
			return string.Format("[%1] %2 (%3) - Par: %4", status, charge, durLbl, issuer);
		}
		else if (kind == "warrant")
		{
			// idx@@type@@motive@@issued@@expires@@active@@issuer
			if (parts.Count() < 7) return "?";
			int type = parts.Get(1).ToInt();
			string motive = parts.Get(2);
			bool active = (parts.Get(5) == "1");
			string issuer = parts.Get(6);
			string status = "EXECUTE";
			if (active) status = "ACTIF";
			string typeLbl = JobWarrantTypeHelper.GetLabel(type);
			return string.Format("[%1] %2 - %3 - Par: %4", status, typeLbl, motive, issuer);
		}
		else if (kind == "note")
		{
			// idx@@text@@timestamp@@author
			if (parts.Count() < 4) return "?";
			string text = parts.Get(1);
			string author = parts.Get(3);
			return string.Format("[%1] %2", author, text);
		}
		else if (kind == "infraction")
		{
			// idx@@gravity@@level@@amount@@issued@@paid@@issuer@@evidence
			if (parts.Count() < 8) return "?";
			int gravity = parts.Get(1).ToInt();
			int amount = parts.Get(3).ToInt();
			bool paid = (parts.Get(5) == "1");
			string issuer = parts.Get(6);
			string evidence = parts.Get(7);
			string paidLbl = "IMPAYEE";
			if (paid) paidLbl = "PAYEE";
			string gravityLbl = JobInfractionGravityHelper.GetLabel(gravity);
			string colorTag = JobInfractionGravityHelper.GetColorTag(gravity);
			string line = string.Format("%1 [%2] [%3] %4 caps - Par: %5",
				colorTag, paidLbl, gravityLbl, amount.ToString(), issuer);
			if (evidence != "")
				line = line + string.Format(" | Preuve: %1", evidence);
			return line;
		}
		return "?";
	}
	
	//------------------------------------------------------------------------------------------------
	// Split simple par un delimiteur multi-caracteres (Enforce n a pas string.Split)
	//------------------------------------------------------------------------------------------------
	void SplitByDelim(string source, string delim, out array<string> outResult)
	{
		if (source == "") return;
		int dlen = delim.Length();
		int pos = 0;
		while (true)
		{
			int idx = source.IndexOf(delim);
			if (idx < 0)
			{
				outResult.Insert(source);
				return;
			}
			outResult.Insert(source.Substring(0, idx));
			source = source.Substring(idx + dlen, source.Length() - idx - dlen);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Suppression d une entree (appele depuis le handler)
	//------------------------------------------------------------------------------------------------
	void OnDeleteEntry(string kind, int index)
	{
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		if (kind == "sentence")
			jpc.ClientAskPoliceRemoveSentence(m_SelectedUID, index);
		else if (kind == "warrant")
			jpc.ClientAskPoliceRemoveWarrant(m_SelectedUID, index);
		else if (kind == "note")
			jpc.ClientAskPoliceRemoveNote(m_SelectedUID, index);
	}
	
	string GetStatusDetail()
	{
		if (!m_StatusDetailInput)
			return "";
		return m_StatusDetailInput.GetText();
	}
	
	//------------------------------------------------------------------------------------------------
	void CloseMenuInternal()
	{
		GetGame().GetMenuManager().CloseMenu(this);
	}
}

//------------------------------------------------------------------------------------------------
// Handler generique pour les boutons du menu (actions par string)
//------------------------------------------------------------------------------------------------
class PoliceMenuHandler : ScriptedWidgetEventHandler
{
	JobPoliceRecordMenu m_Menu;
	string m_Action;
	
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu)
			m_Menu.OnButtonClicked(m_Action);
		return true;
	}
}

//------------------------------------------------------------------------------------------------
// Handler dedie aux resultats de recherche (chaque bouton porte son UID + nom)
//------------------------------------------------------------------------------------------------
class PoliceSearchResultHandler : ScriptedWidgetEventHandler
{
	JobPoliceRecordMenu m_Menu;
	string m_UID;
	string m_Name;
	
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu)
			m_Menu.OpenFicheFor(m_UID, m_Name);
		return true;
	}
}

//------------------------------------------------------------------------------------------------
// Handler pour la suppression d une entree (peine/mandat/note)
//------------------------------------------------------------------------------------------------
class PoliceDeleteHandler : ScriptedWidgetEventHandler
{
	JobPoliceRecordMenu m_Menu;
	string m_Kind;
	int m_Index;
	
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu)
			m_Menu.OnDeleteEntry(m_Kind, m_Index);
		return true;
	}
}
