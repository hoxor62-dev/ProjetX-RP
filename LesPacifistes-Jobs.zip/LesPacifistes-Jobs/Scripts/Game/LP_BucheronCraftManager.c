//------------------------------------------------------------------------------------------------
// LP_BucheronCraftManager.c
// Singleton SERVEUR pour le craft du bucheron (meme pattern que LP_EpicerieCraftManager).
//------------------------------------------------------------------------------------------------

class LP_BucheronCraftQueueEntry
{
	int m_EntryId;
	int m_RecipeId;
	int m_ReadyAtUnix;
	
	void LP_BucheronCraftQueueEntry(int entryId, int recipeId, int readyAt)
	{
		m_EntryId = entryId;
		m_RecipeId = recipeId;
		m_ReadyAtUnix = readyAt;
	}
	
	bool IsReady()
	{
		return System.GetUnixTime() >= m_ReadyAtUnix;
	}
	
	int SecondsRemaining()
	{
		int rem = m_ReadyAtUnix - System.GetUnixTime();
		if (rem < 0) return 0;
		return rem;
	}
}

class LP_BucheronCraftPlayerQueue
{
	int m_PlayerId;
	int m_NextEntryId = 1;
	ref array<ref LP_BucheronCraftQueueEntry> m_Entries = new array<ref LP_BucheronCraftQueueEntry>();
}

class LP_BucheronCraftManager
{
	static ref LP_BucheronCraftManager s_Instance;
	
	ref map<int, ref LP_BucheronCraftPlayerQueue> m_Queues = new map<int, ref LP_BucheronCraftPlayerQueue>();
	bool m_TickerStarted = false;
	
	//------------------------------------------------------------------------------------------------
	static LP_BucheronCraftManager GetInstance()
	{
		if (!s_Instance) s_Instance = new LP_BucheronCraftManager();
		return s_Instance;
	}
	
	//------------------------------------------------------------------------------------------------
	protected void EnsureTicker()
	{
		if (m_TickerStarted) return;
		m_TickerStarted = true;
		GetGame().GetCallqueue().CallLater(TickAllQueues, 1000, true);
	}
	
	//------------------------------------------------------------------------------------------------
	protected LP_BucheronCraftPlayerQueue GetOrCreateQueue(int playerId)
	{
		LP_BucheronCraftPlayerQueue q = m_Queues.Get(playerId);
		if (!q)
		{
			q = new LP_BucheronCraftPlayerQueue();
			q.m_PlayerId = playerId;
			m_Queues.Set(playerId, q);
		}
		return q;
	}
	
	//------------------------------------------------------------------------------------------------
	// Retourne 0=OK, 1=metier invalide, 2=recette invalide, 3=ingredients manquants, 4=erreur
	//------------------------------------------------------------------------------------------------
	int AddToQueue(int playerId, IEntity playerEnt, int recipeId)
	{
		if (!Replication.IsServer()) return 4;
		if (!playerEnt) return 4;
		
		JobCharacterJobComponent jcjc = JobCharacterJobComponent.Cast(
			playerEnt.FindComponent(JobCharacterJobComponent));
		if (!jcjc || jcjc.GetJob() != EJobType.BUCHERON) return 1;
		
		LP_BucheronCraftRecipe recipe = LP_BucheronCraftData.GetRecipeById(recipeId);
		if (!recipe) return 2;
		
		if (!HasAllIngredients(playerEnt, recipe)) return 3;
		if (!ConsumeIngredients(playerEnt, recipe)) return 4;
		
		LP_BucheronCraftPlayerQueue q = GetOrCreateQueue(playerId);
		int now = System.GetUnixTime();
		int startTime = now;
		
		if (q.m_Entries.Count() > 0)
		{
			LP_BucheronCraftQueueEntry lastEntry = q.m_Entries[q.m_Entries.Count() - 1];
			if (lastEntry && lastEntry.m_ReadyAtUnix > now)
				startTime = lastEntry.m_ReadyAtUnix;
		}
		
		int readyAt = startTime + LP_BucheronCraftData.CRAFT_DURATION_S;
		LP_BucheronCraftQueueEntry entry = new LP_BucheronCraftQueueEntry(q.m_NextEntryId, recipeId, readyAt);
		q.m_NextEntryId = q.m_NextEntryId + 1;
		q.m_Entries.Insert(entry);
		
		EnsureTicker();
		PushQueueUpdate(playerId, playerEnt);
		
		Print(string.Format("[LP_BucheronCraft] Joueur %1 ajoute recette %2 (entryId=%3, readyAt=%4)",
			playerId.ToString(), recipeId.ToString(), entry.m_EntryId.ToString(),
			readyAt.ToString()), LogLevel.NORMAL);
		return 0;
	}
	
	//------------------------------------------------------------------------------------------------
	// Retourne 0=OK, 1=entree introuvable, 2=pas encore prete, 3=erreur spawn
	//------------------------------------------------------------------------------------------------
	int CollectFromQueue(int playerId, IEntity playerEnt, int entryId)
	{
		if (!Replication.IsServer()) return 3;
		if (!playerEnt) return 3;
		
		LP_BucheronCraftPlayerQueue q = m_Queues.Get(playerId);
		if (!q) return 1;
		
		int idx = -1;
		for (int i = 0; i < q.m_Entries.Count(); i++)
		{
			if (q.m_Entries[i] && q.m_Entries[i].m_EntryId == entryId)
			{
				idx = i;
				break;
			}
		}
		if (idx < 0) return 1;
		
		LP_BucheronCraftQueueEntry entry = q.m_Entries[idx];
		if (!entry.IsReady()) return 2;
		
		LP_BucheronCraftRecipe recipe = LP_BucheronCraftData.GetRecipeById(entry.m_RecipeId);
		if (!recipe) return 3;
		
		SCR_InventoryStorageManagerComponent inv = SCR_InventoryStorageManagerComponent.Cast(
			playerEnt.FindComponent(SCR_InventoryStorageManagerComponent));
		if (!inv) return 3;
		
		ResourceName rn = recipe.m_ResultPrefab;
		bool ok = inv.TrySpawnPrefabToStorage(rn);
		if (!ok) return 3;
		
		q.m_Entries.Remove(idx);
		PushQueueUpdate(playerId, playerEnt);
		
		Print(string.Format("[LP_BucheronCraft] Joueur %1 recupere entry %2 (recette %3)",
			playerId.ToString(), entryId.ToString(), entry.m_RecipeId.ToString()),
			LogLevel.NORMAL);
		return 0;
	}
	
	//------------------------------------------------------------------------------------------------
	void GetQueueSnapshot(int playerId, out array<int> outEntryIds, out array<int> outRecipeIds,
		out array<int> outSecondsRemaining)
	{
		LP_BucheronCraftPlayerQueue q = m_Queues.Get(playerId);
		if (!q) return;
		foreach (LP_BucheronCraftQueueEntry e : q.m_Entries)
		{
			if (!e) continue;
			outEntryIds.Insert(e.m_EntryId);
			outRecipeIds.Insert(e.m_RecipeId);
			outSecondsRemaining.Insert(e.SecondsRemaining());
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void TickAllQueues()
	{
		foreach (int pid, LP_BucheronCraftPlayerQueue q : m_Queues)
		{
			if (!q || q.m_Entries.Count() == 0) continue;
			IEntity playerEnt = GetGame().GetPlayerManager().GetPlayerControlledEntity(pid);
			if (!playerEnt) continue;
			PushQueueUpdate(pid, playerEnt);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	protected void PushQueueUpdate(int playerId, IEntity playerEnt)
	{
		if (!playerEnt) return;
		PlayerController pc = GetGame().GetPlayerManager().GetPlayerController(playerId);
		if (!pc) return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		
		array<int> entryIds = new array<int>();
		array<int> recipeIds = new array<int>();
		array<int> secondsRem = new array<int>();
		GetQueueSnapshot(playerId, entryIds, recipeIds, secondsRem);
		
		jpc.ServerBucheronCraftPushQueue(entryIds, recipeIds, secondsRem);
	}
	
	//------------------------------------------------------------------------------------------------
	protected int CountItemInInventory(IEntity playerEnt, string prefabName)
	{
		SCR_InventoryStorageManagerComponent inv = SCR_InventoryStorageManagerComponent.Cast(
			playerEnt.FindComponent(SCR_InventoryStorageManagerComponent));
		if (!inv) return 0;
		
		array<IEntity> items = new array<IEntity>();
		inv.GetItems(items);
		
		int count = 0;
		foreach (IEntity item : items)
		{
			if (!item) continue;
			EntityPrefabData pd = item.GetPrefabData();
			if (!pd) continue;
			if (pd.GetPrefabName() == prefabName)
				count = count + 1;
		}
		return count;
	}
	
	//------------------------------------------------------------------------------------------------
	protected bool HasAllIngredients(IEntity playerEnt, LP_BucheronCraftRecipe recipe)
	{
		foreach (LP_BucheronCraftIngredient ing : recipe.m_Ingredients)
		{
			if (!ing) continue;
			if (CountItemInInventory(playerEnt, ing.m_Prefab) < ing.m_Quantity)
				return false;
		}
		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	protected bool ConsumeIngredients(IEntity playerEnt, LP_BucheronCraftRecipe recipe)
	{
		SCR_InventoryStorageManagerComponent inv = SCR_InventoryStorageManagerComponent.Cast(
			playerEnt.FindComponent(SCR_InventoryStorageManagerComponent));
		if (!inv) return false;
		
		foreach (LP_BucheronCraftIngredient ing : recipe.m_Ingredients)
		{
			if (!ing) continue;
			int toRemove = ing.m_Quantity;
			array<IEntity> items = new array<IEntity>();
			inv.GetItems(items);
			
			foreach (IEntity item : items)
			{
				if (toRemove <= 0) break;
				if (!item) continue;
				EntityPrefabData pd = item.GetPrefabData();
				if (!pd) continue;
				if (pd.GetPrefabName() == ing.m_Prefab)
				{
					SCR_EntityHelper.DeleteEntityAndChildren(item);
					toRemove = toRemove - 1;
				}
			}
			if (toRemove > 0)
			{
				Print(string.Format("[LP_BucheronCraft] ATTENTION : conso incomplete %1 manquant(s) pour %2",
					toRemove.ToString(), ing.m_Prefab), LogLevel.WARNING);
			}
		}
		return true;
	}
}
