//------------------------------------------------------------------------------------------------
// JobHospitalDoorComponent.c
// Component a attacher sur chaque porte de l hopital.
// Stocke l etat (verrouille / deverrouille) via RplProp pour qu il soit visible
// par tous les clients (pour qu ils voient l action contextuelle correcte).
//
// Logique :
//   - L action serveur "Verrouiller" set m_Locked = true et bloque la porte
//   - L action serveur "Deverrouiller" set m_Locked = false et debloque
//   - L etat est replique a tous les clients via RplProp
//
// Architecture separee de JobPoliceDoorComponent pour avoir un filtrage metier
// independant (seuls les MEDECINS peuvent interagir avec).
//------------------------------------------------------------------------------------------------

class JobHospitalDoorComponentClass : ScriptComponentClass
{
}

class JobHospitalDoorComponent : ScriptComponent
{
	// Etat de verrouillage replique a tous les clients
	[RplProp()]
	bool m_Locked = false;
	
	//------------------------------------------------------------------------------------------------
	bool IsLocked()
	{
		return m_Locked;
	}
	
	//------------------------------------------------------------------------------------------------
	// SERVEUR : verrouille ou deverrouille la porte (set le state replicated).
	// Le blocage effectif de l ouverture est gere par JobModdedDoorUserAction qui
	// cache l action vanilla "Open" quand m_Locked = true. Pas besoin de manipuler
	// le DoorComponent ici (l API publique ne permet pas d ecrire l etat directement).
	//------------------------------------------------------------------------------------------------
	void ServerSetLocked(bool locked)
	{
		if (!Replication.IsServer())
			return;
		m_Locked = locked;
		Replication.BumpMe();
	}
}