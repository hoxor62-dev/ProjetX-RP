//------------------------------------------------------------------------------------------------
// JobCompanyRecruitMenu.c
// Menu pour recruter un nouvel employe. Affiche la liste paginee (10/page) des joueurs
// connectes (sauf moi-meme, sauf employes/patron de mon entreprise).
//
// Au clic sur un joueur -> RPC ClientAskRecruitEmployee(uid) -> recrutement direct
// (le joueur recoit juste une notif chat sans demande d acceptation).
//------------------------------------------------------------------------------------------------

class JobCompanyRecruitMenu : ChimeraMenuBase
{
	const string ENTRY_LAYOUT_PATH = "{9D68BEB73DF970D8}UI/layouts/JobSmsEntry.layout";
	const int ITEMS_PER_PAGE = 10;
	const int PAGE_CHANGE_COOLDOWN_MS = 300;
	
	Widget m_RootWidget;
	Widget m_ListContainer;
	TextWidget m_TitleText;
	TextWidget m_EmptyText;
	TextWidget m_PageLabel;
	ButtonWidget m_BtnPrevPage;
	ButtonWidget m_BtnNextPage;
	ButtonWidget m_BtnBack;
	
	static ref array<string> s_PendingUIDs = new array<string>();
	static ref array<string> s_PendingNames = new array<string>();
	
	int m_CurrentPage = 0;
	int m_LastPageChangeTime = 0;
	
	static JobCompanyRecruitMenu s_Instance;
	
	//------------------------------------------------------------------------------------------------
	static void SetPendingData(array<string> uids, array<string> names)
	{
		s_PendingUIDs.Clear();
		s_PendingNames.Clear();
		foreach (string u : uids)
			s_PendingUIDs.Insert(u);
		foreach (string n : names)
			s_PendingNames.Insert(n);
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuOpen()
	{
		super.OnMenuOpen();
		s_Instance = this;
		JobFocusHandler.ClearRegistry();
		
		m_RootWidget = GetRootWidget();
		if (!m_RootWidget) return;
		
		m_ListContainer = m_RootWidget.FindAnyWidget("ListContainer");
		m_TitleText = TextWidget.Cast(m_RootWidget.FindAnyWidget("TitleText"));
		m_EmptyText = TextWidget.Cast(m_RootWidget.FindAnyWidget("EmptyText"));
		m_PageLabel = TextWidget.Cast(m_RootWidget.FindAnyWidget("PageLabel"));
		m_BtnPrevPage = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnPrevPage"));
		m_BtnNextPage = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnNextPage"));
		m_BtnBack = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnBack"));
		
		if (m_TitleText)
			m_TitleText.SetText("Recruter un employe");
		
		if (m_BtnPrevPage)
		{
			RecruitPrevHandler h = new RecruitPrevHandler();
			h.m_Menu = this;
			m_BtnPrevPage.AddHandler(h);
			JobFocusHandler.Attach(m_BtnPrevPage);
		}
		if (m_BtnNextPage)
		{
			RecruitNextHandler h = new RecruitNextHandler();
			h.m_Menu = this;
			m_BtnNextPage.AddHandler(h);
			JobFocusHandler.Attach(m_BtnNextPage);
		}
		if (m_BtnBack)
		{
			RecruitBackHandler h = new RecruitBackHandler();
			h.m_Menu = this;
			m_BtnBack.AddHandler(h);
			JobFocusHandler.Attach(m_BtnBack);
			GetGame().GetWorkspace().SetFocusedWidget(m_BtnBack);
		}
		
		m_CurrentPage = 0;
		BuildList();
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuClose()
	{
		if (s_Instance == this)
			s_Instance = null;
		super.OnMenuClose();
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuUpdate(float tDelta)
	{
		super.OnMenuUpdate(tDelta);
		if (GetGame().GetInputManager().GetActionValue("MenuBack") > 0.5)
			CloseMenuInternal();
		if (GetGame().GetInputManager().GetActionValue("MenuTabLeft") > 0.5)
			OnPrevClicked();
		if (GetGame().GetInputManager().GetActionValue("MenuTabRight") > 0.5)
			OnNextClicked();
	}
	
	//------------------------------------------------------------------------------------------------
	int GetTotalPages()
	{
		int total = (s_PendingUIDs.Count() + ITEMS_PER_PAGE - 1) / ITEMS_PER_PAGE;
		if (total < 1) total = 1;
		return total;
	}
	
	//------------------------------------------------------------------------------------------------
	void BuildList()
	{
		if (!m_ListContainer) return;
		
		// Reset focus + container
		JobFocusHandler.ClearRegistry();
		if (m_BtnPrevPage) JobFocusHandler.Attach(m_BtnPrevPage);
		if (m_BtnNextPage) JobFocusHandler.Attach(m_BtnNextPage);
		if (m_BtnBack) JobFocusHandler.Attach(m_BtnBack);
		
		Widget child = m_ListContainer.GetChildren();
		while (child)
		{
			Widget next = child.GetSibling();
			child.RemoveFromHierarchy();
			child = next;
		}
		
		int totalPages = GetTotalPages();
		if (m_CurrentPage < 0) m_CurrentPage = 0;
		if (m_CurrentPage >= totalPages) m_CurrentPage = totalPages - 1;
		
		if (s_PendingUIDs.Count() == 0)
		{
			if (m_EmptyText)
			{
				m_EmptyText.SetText("Aucun joueur disponible pour recrutement.");
				m_EmptyText.SetVisible(true);
			}
			UpdatePaginationUI(totalPages);
			return;
		}
		if (m_EmptyText)
			m_EmptyText.SetVisible(false);
		
		WorkspaceWidget ws = GetGame().GetWorkspace();
		int startIdx = m_CurrentPage * ITEMS_PER_PAGE;
		int endIdx = startIdx + ITEMS_PER_PAGE;
		if (endIdx > s_PendingUIDs.Count())
			endIdx = s_PendingUIDs.Count();
		
		for (int i = startIdx; i < endIdx; i++)
		{
			string uid = s_PendingUIDs.Get(i);
			string name = s_PendingNames.Get(i);
			
			Widget entry = ws.CreateWidgets(ENTRY_LAYOUT_PATH, m_ListContainer);
			if (!entry) continue;
			
			TextWidget nameW = TextWidget.Cast(entry.FindAnyWidget("PlayerName"));
			if (nameW) nameW.SetText(name);
			
			ButtonWidget btn = ButtonWidget.Cast(entry.FindAnyWidget("SelectButton"));
			if (btn)
			{
				RecruitSelectHandler sh = new RecruitSelectHandler();
				sh.m_Menu = this;
				sh.m_TargetUID = uid;
				sh.m_TargetName = name;
				btn.AddHandler(sh);
				JobFocusHandler.Attach(btn);
			}
		}
		
		UpdatePaginationUI(totalPages);
	}
	
	//------------------------------------------------------------------------------------------------
	void UpdatePaginationUI(int totalPages)
	{
		if (m_PageLabel)
			m_PageLabel.SetText(string.Format("Page %1 / %2", (m_CurrentPage + 1).ToString(), totalPages.ToString()));
		if (m_BtnPrevPage)
			m_BtnPrevPage.SetEnabled(m_CurrentPage > 0);
		if (m_BtnNextPage)
			m_BtnNextPage.SetEnabled(m_CurrentPage < totalPages - 1);
	}
	
	//------------------------------------------------------------------------------------------------
	void OnPrevClicked()
	{
		int now = System.GetTickCount();
		if (now - m_LastPageChangeTime < PAGE_CHANGE_COOLDOWN_MS) return;
		m_LastPageChangeTime = now;
		if (m_CurrentPage <= 0) return;
		m_CurrentPage--;
		BuildList();
	}
	
	void OnNextClicked()
	{
		int now = System.GetTickCount();
		if (now - m_LastPageChangeTime < PAGE_CHANGE_COOLDOWN_MS) return;
		m_LastPageChangeTime = now;
		if (m_CurrentPage >= GetTotalPages() - 1) return;
		m_CurrentPage++;
		BuildList();
	}
	
	//------------------------------------------------------------------------------------------------
	void OnPlayerSelected(string targetUID, string targetName)
	{
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		jpc.ClientAskRecruitEmployee(targetUID);
		CloseMenuInternal();
	}
	
	void CloseMenuInternal()
	{
		GetGame().GetMenuManager().CloseMenu(this);
	}
	
	static JobCompanyRecruitMenu GetOpenMenu() { return s_Instance; }
}

//------------------------------------------------------------------------------------------------
class RecruitBackHandler : ScriptedWidgetEventHandler
{
	JobCompanyRecruitMenu m_Menu;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.CloseMenuInternal();
		return true;
	}
}

//------------------------------------------------------------------------------------------------
class RecruitPrevHandler : ScriptedWidgetEventHandler
{
	JobCompanyRecruitMenu m_Menu;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.OnPrevClicked();
		return true;
	}
}

//------------------------------------------------------------------------------------------------
class RecruitNextHandler : ScriptedWidgetEventHandler
{
	JobCompanyRecruitMenu m_Menu;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.OnNextClicked();
		return true;
	}
}

//------------------------------------------------------------------------------------------------
class RecruitSelectHandler : ScriptedWidgetEventHandler
{
	JobCompanyRecruitMenu m_Menu;
	string m_TargetUID;
	string m_TargetName;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.OnPlayerSelected(m_TargetUID, m_TargetName);
		return true;
	}
}
