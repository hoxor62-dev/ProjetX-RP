//------------------------------------------------------------------------------------------------
// JobCharacterJobComponent.c
// Component minimaliste a attacher au PREFAB CHARACTER du joueur (BaseChimeraCharacter).
//
// Objectif : exposer le metier du joueur a TOUS les clients qui voient ce character,
// pas seulement au PlayerController owner. C est necessaire pour que les actions
// type "Payer une amende" puissent filtrer leur visibilite selon le metier de la cible
// directement cote client (sans passer par une RPC).
//
// Le serveur synchronise ce component via le helper SetJobOnCharacter qui doit etre
// appele par le JobPlayerComponent lorsque le metier change.
//
// Architecture :
//   - JobPlayerComponent (sur PlayerController) : source de verite serveur du metier
//   - JobCharacterJobComponent (sur character entity) : RplProp visible par tous les clients
//------------------------------------------------------------------------------------------------

class JobCharacterJobComponentClass : ScriptComponentClass
{
}

class JobCharacterJobComponent : ScriptComponent
{
	// Metier replique a TOUS les clients via RplProp
	// (contrairement aux components sur PlayerController qui ne sont accessibles que par leur owner)
	[RplProp()]
	int m_JobInt = EJobType.NONE;
	
	//------------------------------------------------------------------------------------------------
	// Lecture du metier (utilisable cote serveur ET cote client)
	//------------------------------------------------------------------------------------------------
	EJobType GetJob()
	{
		return m_JobInt;
	}
	
	//------------------------------------------------------------------------------------------------
	// SERVEUR uniquement : met a jour le metier et le pousse aux clients via RplProp
	//------------------------------------------------------------------------------------------------
	void ServerSetJob(EJobType job)
	{
		if (!Replication.IsServer())
			return;
		m_JobInt = job;
		Replication.BumpMe();
	}
}
