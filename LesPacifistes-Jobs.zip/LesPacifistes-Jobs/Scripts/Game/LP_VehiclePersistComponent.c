//------------------------------------------------------------------------------------------------
// LP_VehiclePersistComponent.c
// Composant a ajouter via workbench sur TOUS les prefabs vehicules du mod (voitures,
// motos, camions). Porte l identite stable du vehicule.
//
// REGLE STRICTE : ce composant NE GENERE JAMAIS un UUID. L UUID est genere UNIQUEMENT
// par JobVirtualGarageManager.RegisterNewPurchase au moment du premier spawn (achat shop).
// Puis l UUID est reecrit a chaque spawn du vehicule (retrait du garage virtuel, reconciliation
// au reboot). Le composant n est qu un cache local sur l entite, la vraie source de verite
// est le JSON du manager serveur (active_vehicles.json).
//
// Au reboot serveur :
//   - Si le save-world natif Enfusion est actif, les vehicules reviennent avec le composant
//     dans son etat avant crash (UUID+OwnerUID preserves)
//   - Sinon, le manager fait le matching par position+prefab et reecrit UUID+OwnerUID
//
// Un vehicule sans UUID (string vide) est traite comme libre d acces (spawn admin, workbench,
// mod tiers).
//------------------------------------------------------------------------------------------------

[ComponentEditorProps(category: "LesPacifistes", description: "Persist vehicle UUID + owner across reboot/crash")]
class LP_VehiclePersistComponentClass : ScriptComponentClass
{
}

class LP_VehiclePersistComponent : ScriptComponent
{
	// UUID stable du vehicule, cree UNIQUEMENT par JobVirtualGarageManager.RegisterNewPurchase
	// "" = vehicule non enregistre (spawn hors shop)
	protected string m_VehicleUUID = "";

	// UID Bohemia du proprietaire courant
	// "" = pas de proprietaire (vehicule libre)
	protected string m_OwnerUID = "";

	//------------------------------------------------------------------------------------------------
	void SetVehicleUUID(string uuid)
	{
		m_VehicleUUID = uuid;
	}

	string GetVehicleUUID()
	{
		return m_VehicleUUID;
	}

	//------------------------------------------------------------------------------------------------
	void SetOwnerUID(string ownerUID)
	{
		m_OwnerUID = ownerUID;
	}

	string GetOwnerUID()
	{
		return m_OwnerUID;
	}

	//------------------------------------------------------------------------------------------------
	// true si ce vehicule a bien ete enregistre par le manager (UUID non vide)
	//------------------------------------------------------------------------------------------------
	bool IsRegistered()
	{
		return m_VehicleUUID != "";
	}

	//------------------------------------------------------------------------------------------------
	// true si le joueur est le proprietaire courant
	//------------------------------------------------------------------------------------------------
	bool IsOwnedBy(string playerUID)
	{
		if (m_OwnerUID == "" || playerUID == "")
			return false;
		return m_OwnerUID == playerUID;
	}
}
