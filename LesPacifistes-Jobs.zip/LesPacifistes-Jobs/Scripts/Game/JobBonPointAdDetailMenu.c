//------------------------------------------------------------------------------------------------
// JobBonPointAdDetailMenu.c
// Fiche produit d une annonce. Affiche :
//   - Titre
//   - Description
//   - Prix
//   - Vendeur (Prenom Nom RP)
//   - Bouton Acheter (cache si l acheteur est le vendeur)
//   - Bouton Retour
//
// Le chat 1-to-1 viendra en Session 3 (placeholder pour l instant).
//------------------------------------------------------------------------------------------------

class JobBonPointAdDetailMenu : ChimeraMenuBase
{
	Widget m_RootWidget;
	TextWidget m_TitleText;
	TextWidget m_SellerText;
	TextWidget m_PriceText;
	TextWidget m_DescriptionText;
	TextWidget m_PrefabText;
	ItemPreviewWidget m_PreviewWidget;
	ItemPreviewManagerEntity m_PreviewManager;
	ButtonWidget m_BtnBuy;
	ButtonWidget m_BtnChat;
	ButtonWidget m_BtnBack;
	
	// Donnees pre-chargees
	static int s_AdId;
	static string s_Title;
	static string s_Description;
	static int s_Price;
	static string s_SellerName;
	static string s_PrefabName;
	static bool s_IsMyAd;  // si vrai, on n affiche pas le bouton Acheter
	
	static JobBonPointAdDetailMenu s_Instance;
	
	//------------------------------------------------------------------------------------------------
	static void SetPendingData(int adId, string title, string description, int price,
		string sellerName, string prefabName, bool isMyAd)
	{
		s_AdId = adId;
		s_Title = title;
		s_Description = description;
		s_Price = price;
		s_SellerName = sellerName;
		s_PrefabName = prefabName;
		s_IsMyAd = isMyAd;
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuOpen()
	{
		super.OnMenuOpen();
		s_Instance = this;
		JobFocusHandler.ClearRegistry();
		
		m_RootWidget = GetRootWidget();
		if (!m_RootWidget) return;
		
		m_TitleText = TextWidget.Cast(m_RootWidget.FindAnyWidget("TitleText"));
		m_SellerText = TextWidget.Cast(m_RootWidget.FindAnyWidget("SellerText"));
		m_PriceText = TextWidget.Cast(m_RootWidget.FindAnyWidget("PriceText"));
		m_DescriptionText = TextWidget.Cast(m_RootWidget.FindAnyWidget("DescriptionText"));
		m_PrefabText = TextWidget.Cast(m_RootWidget.FindAnyWidget("PrefabText"));
		m_PreviewWidget = ItemPreviewWidget.Cast(m_RootWidget.FindAnyWidget("PreviewWidget"));
		m_BtnBuy = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnBuy"));
		m_BtnChat = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnChat"));
		m_BtnBack = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnBack"));
		
		if (m_TitleText) m_TitleText.SetText(s_Title);
		if (m_SellerText) m_SellerText.SetText(string.Format("Vendeur : %1", s_SellerName));
		if (m_PriceText) m_PriceText.SetText(string.Format("Prix : %1 capsules", s_Price.ToString()));
		if (m_DescriptionText)
		{
			string desc = s_Description;
			if (desc == "")
				desc = "(Pas de description)";
			m_DescriptionText.SetText(desc);
		}
		if (m_PrefabText)
		{
			// Extraction du nom de l item depuis le prefab path
			string itemName = ExtractItemName(s_PrefabName);
			m_PrefabText.SetText(string.Format("Item : %1", itemName));
		}
		
		// Preview 3D
		if (m_PreviewWidget)
		{
			ItemPreviewManagerEntity manager = GetPreviewManager();
			if (manager)
			{
				ResourceName prefab = s_PrefabName;
				manager.SetPreviewItemFromPrefab(m_PreviewWidget, prefab, null, false);
			}
		}
		
		// Cache le bouton Acheter si c est notre annonce
		if (m_BtnBuy)
		{
			m_BtnBuy.SetVisible(!s_IsMyAd);
			BonPointDetailHandler h = new BonPointDetailHandler();
			h.m_Menu = this;
			h.m_Action = "buy";
			m_BtnBuy.AddHandler(h);
			JobFocusHandler.Attach(m_BtnBuy);
		}
		
		// Le bouton Chat est visible pour tout le monde :
		// - Acheteur : ouvre sa conversation directement
		// - Vendeur : ouvre la liste des acheteurs qui lui ont parle (gere via OnAction)
		if (m_BtnChat)
		{
			m_BtnChat.SetVisible(true);
			BonPointDetailHandler h = new BonPointDetailHandler();
			h.m_Menu = this;
			h.m_Action = "chat";
			m_BtnChat.AddHandler(h);
			JobFocusHandler.Attach(m_BtnChat);
		}
		
		if (m_BtnBack)
		{
			BonPointDetailHandler h = new BonPointDetailHandler();
			h.m_Menu = this;
			h.m_Action = "back";
			m_BtnBack.AddHandler(h);
			JobFocusHandler.Attach(m_BtnBack);
			GetGame().GetWorkspace().SetFocusedWidget(m_BtnBack);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	string ExtractItemName(string prefab)
	{
		int lastSlash = -1;
		for (int i = prefab.Length() - 1; i >= 0; i--)
		{
			if (prefab.Get(i) == "/")
			{
				lastSlash = i;
				break;
			}
		}
		string name;
		if (lastSlash >= 0 && lastSlash + 1 < prefab.Length())
			name = prefab.Substring(lastSlash + 1, prefab.Length() - lastSlash - 1);
		else
			name = prefab;
		if (name.Length() > 3)
		{
			string suffix = name.Substring(name.Length() - 3, 3);
			if (suffix == ".et")
				name = name.Substring(0, name.Length() - 3);
		}
		return name;
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuClose()
	{
		if (s_Instance == this) s_Instance = null;
		super.OnMenuClose();
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuUpdate(float tDelta)
	{
		super.OnMenuUpdate(tDelta);
		if (GetGame().GetInputManager().GetActionValue("MenuBack") > 0.5)
			CloseMenuInternal();
	}
	
	//------------------------------------------------------------------------------------------------
	void OnAction(string action)
	{
		if (action == "back")
		{
			CloseMenuInternal();
			return;
		}
		if (action == "buy")
		{
			PlayerController pc = GetGame().GetPlayerController();
			if (!pc) return;
			JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
			if (!jpc) return;
			jpc.ClientAskBuyBonPointAd(s_AdId);
			CloseMenuInternal();
			return;
		}
		if (action == "chat")
		{
			PlayerController pc = GetGame().GetPlayerController();
			if (!pc) return;
			JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
			if (!jpc) return;
			
			if (s_IsMyAd)
			{
				// Vendeur : ouvre la liste des acheteurs qui lui ont parle
				jpc.ClientAskListBonPointBuyers(s_AdId, s_Title);
			}
			else
			{
				// Acheteur : ouvre sa propre conversation
				jpc.ClientAskOpenBonPointChat(s_AdId, s_SellerName, s_Title);
			}
			CloseMenuInternal();
			return;
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void CloseMenuInternal()
	{
		GetGame().GetMenuManager().CloseMenu(this);
	}
	
	//------------------------------------------------------------------------------------------------
	// Helper : retrouve le manager de preview 3D dans la scene
	ItemPreviewManagerEntity GetPreviewManager()
	{
		if (m_PreviewManager)
			return m_PreviewManager;
		BaseWorld world = GetGame().GetWorld();
		if (!world)
			return null;
		IEntity entity = world.FindEntityByName("ItemPreviewManagerEntity");
		if (entity)
			m_PreviewManager = ItemPreviewManagerEntity.Cast(entity);
		return m_PreviewManager;
	}
}

//------------------------------------------------------------------------------------------------
class BonPointDetailHandler : ScriptedWidgetEventHandler
{
	JobBonPointAdDetailMenu m_Menu;
	string m_Action;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.OnAction(m_Action);
		return true;
	}
}
