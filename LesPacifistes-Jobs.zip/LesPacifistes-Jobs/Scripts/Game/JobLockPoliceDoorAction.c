//------------------------------------------------------------------------------------------------
// JobLockPoliceDoorAction.c
// Action UserAction "Verrouiller" sur les portes du batiment de police.
// Visible uniquement si :
//   - Le joueur local est POLICIER ou MILITAIRE (via JobCharacterJobComponent)
//   - La porte est actuellement DEVERROUILLEE (via JobPoliceDoorComponent.m_Locked)
//
// Le verrouillage se fait cote serveur via JobPoliceDoorComponent.ServerSetLocked(true).
//------------------------------------------------------------------------------------------------

class JobLockPoliceDoorAction : ScriptedUserAction
{
	//------------------------------------------------------------------------------------------------
	override bool CanBeShownScript(IEntity user)
	{
		if (!user)
			return false;
		
		// Verifie le metier du joueur LOCAL via JobCharacterJobComponent (sur son character)
		JobCharacterJobComponent localJobComp = JobCharacterJobComponent.Cast(
			user.FindComponent(JobCharacterJobComponent));
		if (!localJobComp)
		{
			Print("[LockDoor.CanBeShown] JobCharacterJobComponent absent sur user - vois pas l action", LogLevel.WARNING);
			return false;
		}
		EJobType localJob = localJobComp.GetJob();
		Print(string.Format("[LockDoor.CanBeShown] localJob=%1", JobData.JobToString(localJob)), LogLevel.NORMAL);
		if (localJob != EJobType.POLICIER && localJob != EJobType.MILITAIRE)
			return false;
		
		// Verifie l etat de la porte : visible UNIQUEMENT si deverrouillee
		IEntity door = GetOwner();
		if (!door)
			return false;
		JobPoliceDoorComponent doorComp = JobPoliceDoorComponent.Cast(
			door.FindComponent(JobPoliceDoorComponent));
		if (!doorComp)
			return false;
		return !doorComp.IsLocked();
	}
	
	//------------------------------------------------------------------------------------------------
	override bool CanBePerformedScript(IEntity user)
	{
		return CanBeShownScript(user);
	}
	
	//------------------------------------------------------------------------------------------------
	override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
	{
		if (!pOwnerEntity)
			return;
		
		// La logique de verrouillage tourne cote serveur. Sur dedicated server, PerformAction
		// s execute cote client donc on doit envoyer une RPC au serveur via le JobPlayerComponent.
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc)
			return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc)
			return;
		
		RplComponent rpl = RplComponent.Cast(pOwnerEntity.FindComponent(RplComponent));
		if (!rpl)
			return;
		jpc.ClientAskTogglePoliceDoor(rpl.Id(), true);  // true = lock
	}
	
	//------------------------------------------------------------------------------------------------
	override bool GetActionNameScript(out string outName)
	{
		outName = "Verrouiller la porte";
		return true;
	}
}
