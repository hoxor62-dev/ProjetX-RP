//------------------------------------------------------------------------------------------------
// LP_CannabisPlayerComponent.c
// Component a placer sur le prefab PlayerController.
// Passerelle RPC pour le THC + ralentissement cote client via SetDynamicSpeed.
//------------------------------------------------------------------------------------------------

class LP_CannabisPlayerComponentClass : ScriptComponentClass
{
}

class LP_CannabisPlayerComponent : ScriptComponent
{
	protected float m_ClientThcLevel = 0;
	
	//------------------------------------------------------------------------------------------------
	static LP_CannabisPlayerComponent GetLocal()
	{
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return null;
		return LP_CannabisPlayerComponent.Cast(pc.FindComponent(LP_CannabisPlayerComponent));
	}
	
	//------------------------------------------------------------------------------------------------
	float GetLocalLevel() { return m_ClientThcLevel; }
	
	//------------------------------------------------------------------------------------------------
	void ServerPushLevel(float level)
	{
		if (!Replication.IsServer()) return;
		Rpc(RpcDo_PushLevel, level);
	}
	
	//------------------------------------------------------------------------------------------------
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	protected void RpcDo_PushLevel(float level)
	{
		m_ClientThcLevel = level;
		
		LP_CannabisHUD hud = LP_CannabisHUD.GetInstance();
		if (hud) hud.UpdateLevel(level);
		
		// Ralentit walk via SetDynamicSpeed
		ApplyMovementSpeedEffect(level);
	}
	
	//------------------------------------------------------------------------------------------------
	// Cap walk speed via SetDynamicSpeed (valeur plus basse = plus lent)
	//------------------------------------------------------------------------------------------------
	protected void ApplyMovementSpeedEffect(float thcLevel)
	{
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return;
		IEntity character = pc.GetControlledEntity();
		if (!character) return;
		
		SCR_CharacterControllerComponent ccc = SCR_CharacterControllerComponent.Cast(
			character.FindComponent(SCR_CharacterControllerComponent));
		if (!ccc) return;
		
		float dynamicSpeed = 0;  // 0 = pas de cap
		
		if (thcLevel >= 90.0)
			dynamicSpeed = 0.25;
		else if (thcLevel >= 70.0)
			dynamicSpeed = 0.45;
		else if (thcLevel >= 50.0)
			dynamicSpeed = 0.65;
		else if (thcLevel >= 25.0)
			dynamicSpeed = 0.85;
		
		ccc.SetDynamicSpeed(dynamicSpeed);
	}
}
