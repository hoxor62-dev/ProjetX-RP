//------------------------------------------------------------------------------------------------
// JobCompanyChatMenu.c
// Chat interne de l entreprise (tous les membres peuvent lire/ecrire).
//
// Affichage : les 30 derniers messages dans un seul TextWidget.
// Envoi : editbox + bouton Envoyer -> RPC + refresh.
// Auto-refresh : CallLater toutes les 5 secondes pour interroger le serveur.
//
// Format texte dans le TextWidget :
//   [HH:MM] NomAuteur: message
//   [HH:MM] NomAuteur: message
//   ...
//------------------------------------------------------------------------------------------------

class JobCompanyChatMenu : ChimeraMenuBase
{
	const int REFRESH_INTERVAL_MS = 5000;  // auto-refresh toutes les 5s
	
	Widget m_RootWidget;
	TextWidget m_TitleText;
	TextWidget m_MessagesText;
	EditBoxWidget m_MsgInput;
	ButtonWidget m_BtnSend;
	ButtonWidget m_BtnBack;
	
	// Pre-chargee par RpcDo_ReceiveChatMessages : texte deja formate (sep "\n")
	static string s_PendingMessagesText = "";
	
	bool m_IsRefreshActive = false;
	
	static JobCompanyChatMenu s_Instance;
	
	//------------------------------------------------------------------------------------------------
	static void SetPendingMessagesText(string txt)
	{
		s_PendingMessagesText = txt;
		// Si le menu est ouvert, met a jour directement
		if (s_Instance)
			s_Instance.ApplyPendingMessages();
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuOpen()
	{
		super.OnMenuOpen();
		s_Instance = this;
		JobFocusHandler.ClearRegistry();
		
		m_RootWidget = GetRootWidget();
		if (!m_RootWidget) return;
		
		m_TitleText = TextWidget.Cast(m_RootWidget.FindAnyWidget("TitleText"));
		m_MessagesText = TextWidget.Cast(m_RootWidget.FindAnyWidget("MessagesText"));
		m_MsgInput = EditBoxWidget.Cast(m_RootWidget.FindAnyWidget("MsgInput"));
		m_BtnSend = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnSend"));
		m_BtnBack = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnBack"));
		
		if (m_TitleText)
			m_TitleText.SetText("Chat entreprise");
		
		if (m_BtnSend)
		{
			ChatSendHandler sh = new ChatSendHandler();
			sh.m_Menu = this;
			m_BtnSend.AddHandler(sh);
			JobFocusHandler.Attach(m_BtnSend);
		}
		if (m_BtnBack)
		{
			ChatBackHandler bh = new ChatBackHandler();
			bh.m_Menu = this;
			m_BtnBack.AddHandler(bh);
			JobFocusHandler.Attach(m_BtnBack);
			GetGame().GetWorkspace().SetFocusedWidget(m_BtnBack);
		}
		
		ApplyPendingMessages();
		
		// Demarre l auto-refresh
		m_IsRefreshActive = true;
		GetGame().GetCallqueue().CallLater(AutoRefresh, REFRESH_INTERVAL_MS, true);
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuClose()
	{
		// Stop l auto-refresh
		m_IsRefreshActive = false;
		GetGame().GetCallqueue().Remove(AutoRefresh);
		
		if (s_Instance == this)
			s_Instance = null;
		super.OnMenuClose();
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuUpdate(float tDelta)
	{
		super.OnMenuUpdate(tDelta);
		if (GetGame().GetInputManager().GetActionValue("MenuBack") > 0.5)
			CloseMenuInternal();
	}
	
	//------------------------------------------------------------------------------------------------
	// Appele toutes les 5 secondes (et a l ouverture du menu)
	//------------------------------------------------------------------------------------------------
	void AutoRefresh()
	{
		if (!m_IsRefreshActive) return;
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		jpc.ClientAskRefreshCompanyChat();
	}
	
	//------------------------------------------------------------------------------------------------
	void ApplyPendingMessages()
	{
		if (m_MessagesText)
		{
			if (s_PendingMessagesText == "")
				m_MessagesText.SetText("Aucun message pour le moment.");
			else
				m_MessagesText.SetText(s_PendingMessagesText);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void OnSendClicked()
	{
		if (!m_MsgInput) return;
		string text = m_MsgInput.GetText();
		if (text == "") return;
		
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		jpc.ClientAskSendCompanyChatMessage(text);
		
		// Reset l input et force un refresh imminent pour voir notre msg apparaitre
		m_MsgInput.SetText("");
		GetGame().GetCallqueue().CallLater(AutoRefresh, 200, false);
	}
	
	//------------------------------------------------------------------------------------------------
	void CloseMenuInternal()
	{
		GetGame().GetMenuManager().CloseMenu(this);
	}
	
	static JobCompanyChatMenu GetOpenMenu() { return s_Instance; }
}

//------------------------------------------------------------------------------------------------
class ChatBackHandler : ScriptedWidgetEventHandler
{
	JobCompanyChatMenu m_Menu;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.CloseMenuInternal();
		return true;
	}
}

//------------------------------------------------------------------------------------------------
class ChatSendHandler : ScriptedWidgetEventHandler
{
	JobCompanyChatMenu m_Menu;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.OnSendClicked();
		return true;
	}
}
