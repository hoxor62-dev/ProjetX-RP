//------------------------------------------------------------------------------------------------
// JobInsuranceManager.c
//
// Systeme d'assurance vehicule LIE A L INSTANCE (pas au prefab).
//
// Chaque vehicule assure recoit un UUID unique persistant qui reste attache a l instance
// vehicule meme entre les sorties/rentrees du garage virtuel. L assurance ne se termine que
// quand le vehicule est DETRUIT (destruction physique via SCR_VehicleDamageManagerComponent).
//
// Flux :
//   1. Joueur va chez le PNJ assureur avec son vehicule proche (rayon 10m)
//   2. Paie le prix -> UUID genere -> associe au vehicule (via un composant custom ou
//      une map runtime + persistance)
//   3. Le vehicule assure conserve son UUID entre sortie/rentree garage
//   4. En cas de destruction detectee : l assurance est consommee, le vehicule est
//      auto-respawn dans le garage virtuel (pret a etre sorti a nouveau)
//
// Persistance : $profile:LesPacifistesJobs/vehicle_insurances.json
//   Format : { count, entries[i]_uid, entries[i]_uuid, entries[i]_prefab, ... }
//------------------------------------------------------------------------------------------------

class InsuredVehicle
{
	string m_InstanceUUID;         // ID unique de l instance vehicule (persistant)
	string m_OwnerUID;             // UID du proprietaire (denormalise pour recherche rapide)
	ResourceName m_Prefab;         // Prefab du vehicule (pour affichage + auto-respawn)
	string m_PrefabDisplayName;    // Nom affichable
	int m_PurchasedAt;             // Timestamp achat
	int m_ExpiresAt;               // Timestamp fin (0 = illimite / lifetime jusqu a destruction)
	
	void InsuredVehicle()
	{
		m_InstanceUUID = "";
		m_OwnerUID = "";
		m_Prefab = "";
		m_PrefabDisplayName = "";
		m_PurchasedAt = 0;
		m_ExpiresAt = 0;
	}
}

class JobInsuranceManager
{
	static ref JobInsuranceManager s_Instance;
	
	const string SAVE_PATH = "$profile:LesPacifistesJobs/vehicle_insurances.json";
	const int LIFETIME_INSURANCE = 0;  // 0 dans m_ExpiresAt = jamais d expiration temporelle
	
	// === COMPAT ANCIEN SYSTEME ===
	// Constante du cout d assurance (utilisee par le RPC RpcAsk_InsureAndRetrieveVehicle)
	static const int INSURANCE_COST = 250;
	// Cooldown 3h entre chaque assurance (anti-spam / anti-abus)
	const int COOLDOWN_SECONDS = 10800;  // 3 heures
	// map<uid, timestamp_dernier_achat> pour le cooldown (volatile au reboot, acceptable)
	ref map<string, int> m_CooldownsByUID;
	
	// === STORAGE ===
	// map<UUID_instance, InsuredVehicle> : lookup O(1) par UUID
	ref map<string, ref InsuredVehicle> m_InsurancesByUUID;
	
	// map<RplId_string, UUID> : lookup runtime pour retrouver l UUID d un vehicule spawne
	// (volatile, reconstruite au retrait du garage)
	ref map<string, string> m_RuntimeUUIDByRplId;

	// === DEBOUNCE SAVE ===
	// Evite d ecrire le fichier vehicle_insurances.json (722KB) a chaque modification.
	// Toutes les mutations appellent MarkSaveDirty() au lieu de SaveToDisk() direct.
	// Le flush reel se fait 5s plus tard, et une seule fois meme si plusieurs
	// MarkSaveDirty se succedent (ex : plusieurs assurances achetees d un coup).
	const int SAVE_DEBOUNCE_MS = 5000;
	bool m_bSaveDirty = false;
	bool m_bSaveScheduled = false;

	static JobInsuranceManager GetInstance()
	{
		if (!s_Instance)
		{
			s_Instance = new JobInsuranceManager();
			s_Instance.Init();
		}
		return s_Instance;
	}
	
	void Init()
	{
		m_InsurancesByUUID = new map<string, ref InsuredVehicle>();
		m_RuntimeUUIDByRplId = new map<string, string>();
		m_CooldownsByUID = new map<string, int>();
		LoadFromDisk();
		Print(string.Format("[JobInsuranceManager] Init OK (%1 assurances chargees)",
			m_InsurancesByUUID.Count()), LogLevel.NORMAL);
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== COMPAT ANCIEN SYSTEME (cooldown + track/mark) =====
	//------------------------------------------------------------------------------------------------
	
	//------------------------------------------------------------------------------------------------
	// Verifie le cooldown 3h. Retourne les secondes restantes, 0 si OK.
	//------------------------------------------------------------------------------------------------
	int CheckCooldown(string uid)
	{
		if (uid == "") return 0;
		int lastTime;
		if (!m_CooldownsByUID.Find(uid, lastTime))
			return 0;
		int now = System.GetUnixTime();
		int elapsed = now - lastTime;
		if (elapsed >= COOLDOWN_SECONDS)
			return 0;
		return COOLDOWN_SECONDS - elapsed;
	}
	
	//------------------------------------------------------------------------------------------------
	// Marque le UID comme ayant utilise son achat (demarre le cooldown 3h)
	//------------------------------------------------------------------------------------------------
	void MarkInsured(string uid)
	{
		if (uid == "") return;
		int now = System.GetUnixTime();
		m_CooldownsByUID.Set(uid, now);
	}
	
	//------------------------------------------------------------------------------------------------
	// Adaptateur pour l ancien code : TrackVehicle -> InsureVehicleInstance
	// Le vieux code appelait TrackVehicle apres RetrieveVehicleByIndex pour marquer le
	// vehicule frais spawn comme assure. Ca reste valide mais on utilise notre UUID system.
	//------------------------------------------------------------------------------------------------
	string TrackVehicle(IEntity vehicle, string ownerUID, ResourceName prefab)
	{
		return InsureVehicleInstance(ownerUID, vehicle);
	}
	
	//------------------------------------------------------------------------------------------------
	// Alias pour compat : UntrackVehicle appele dans JobVirtualGarageManager au stockage
	//------------------------------------------------------------------------------------------------
	void UntrackVehicle(IEntity vehicle)
	{
		ClearRuntimeMapping(vehicle);
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== HELPERS UUID =====
	//------------------------------------------------------------------------------------------------
	
	//------------------------------------------------------------------------------------------------
	// Genere un UUID quasi-unique base sur : UID joueur + timestamp + random
	// Format : "V_<uid_hash>_<timestamp>_<rand>"
	// Assez unique pour eviter les collisions dans un contexte de jeu multi-joueurs.
	//------------------------------------------------------------------------------------------------
	string GenerateUUID(string ownerUID)
	{
		int now = System.GetUnixTime();
		int rnd = Math.RandomInt(100000, 999999);
		// Hash simple du UID (somme des chars) pour raccourcir
		int hash = 0;
		int len = ownerUID.Length();
		for (int i = 0; i < len; i++)
		{
			hash = hash + ownerUID.ToAscii(i);
		}
		return string.Format("V_%1_%2_%3", hash.ToString(), now.ToString(), rnd.ToString());
	}
	
	//------------------------------------------------------------------------------------------------
	// Associe un vehicule spawne dans le monde a un UUID d assurance.
	// Utilise la map runtime pour lien RplId <-> UUID.
	// A appeler apres le spawn (retrait garage ou achat frais).
	//------------------------------------------------------------------------------------------------
	void SetVehicleInstanceId(IEntity vehicle, string uuid)
	{
		if (!vehicle || uuid == "")
			return;
		RplComponent rpl = RplComponent.Cast(vehicle.FindComponent(RplComponent));
		if (!rpl)
			return;
		string rplKey = rpl.Id().ToString();
		m_RuntimeUUIDByRplId.Set(rplKey, uuid);
		Print(string.Format("[JobInsuranceManager] SetVehicleInstanceId : rplId=%1 uuid=%2",
			rplKey, uuid), LogLevel.NORMAL);
	}
	
	//------------------------------------------------------------------------------------------------
	// Recupere l UUID d assurance d un vehicule dans le monde.
	// Retourne "" si le vehicule n est pas assure.
	//------------------------------------------------------------------------------------------------
	string GetVehicleInstanceId(IEntity vehicle)
	{
		if (!vehicle)
			return "";
		RplComponent rpl = RplComponent.Cast(vehicle.FindComponent(RplComponent));
		if (!rpl)
			return "";
		string rplKey = rpl.Id().ToString();
		string uuid;
		if (m_RuntimeUUIDByRplId.Find(rplKey, uuid))
			return uuid;
		return "";
	}
	
	//------------------------------------------------------------------------------------------------
	// Vide l entree runtime pour un RplId (a appeler avant de detruire l entite ou de la stocker)
	//------------------------------------------------------------------------------------------------
	void ClearRuntimeMapping(IEntity vehicle)
	{
		if (!vehicle) return;
		RplComponent rpl = RplComponent.Cast(vehicle.FindComponent(RplComponent));
		if (!rpl) return;
		string rplKey = rpl.Id().ToString();
		if (m_RuntimeUUIDByRplId.Contains(rplKey))
			m_RuntimeUUIDByRplId.Remove(rplKey);
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== ACHAT D ASSURANCE =====
	//------------------------------------------------------------------------------------------------
	
	//------------------------------------------------------------------------------------------------
	// Assure un vehicule specifique (identifie par son entite).
	// Genere un UUID pour cette instance, la stocke, l associe au vehicule via la map runtime.
	//
	// Retourne :
	//   ""  = echec (vehicule invalide, prefab illisible)
	//   UUID = OK, l UUID genere pour cette instance
	//------------------------------------------------------------------------------------------------
	string InsureVehicleInstance(string ownerUID, IEntity vehicle)
	{
		if (!vehicle || ownerUID == "")
			return "";
		
		// Verifie que ce vehicule n a pas deja une assurance active
		string existingUUID = GetVehicleInstanceId(vehicle);
		if (existingUUID != "" && m_InsurancesByUUID.Contains(existingUUID))
		{
			Print("[JobInsuranceManager] Vehicule deja assure, refus", LogLevel.WARNING);
			return "";
		}
		
		EntityPrefabData pd = vehicle.GetPrefabData();
		if (!pd)
			return "";
		ResourceName prefab = pd.GetPrefabName();
		if (prefab == "" || prefab == ResourceName.Empty)
			return "";
		
		string uuid = GenerateUUID(ownerUID);
		int now = System.GetUnixTime();
		
		InsuredVehicle ins = new InsuredVehicle();
		ins.m_InstanceUUID = uuid;
		ins.m_OwnerUID = ownerUID;
		ins.m_Prefab = prefab;
		ins.m_PrefabDisplayName = ExtractDisplayName(prefab);
		ins.m_PurchasedAt = now;
		ins.m_ExpiresAt = LIFETIME_INSURANCE;  // 0 = jusqu a destruction
		
		m_InsurancesByUUID.Set(uuid, ins);
		SetVehicleInstanceId(vehicle, uuid);
		MarkSaveDirty();

		Print(string.Format("[JobInsuranceManager] Assurance creee : uuid=%1 owner=%2 prefab=%3",
			uuid, ownerUID, prefab), LogLevel.NORMAL);
		return uuid;
	}
	
	//------------------------------------------------------------------------------------------------
	// Enregistre un UUID existant (par exemple depuis le garage lors du retrait).
	// Utilise pour re-lier une assurance persistee a un nouveau spawn vehicule.
	//------------------------------------------------------------------------------------------------
	void ReattachExistingUUID(IEntity vehicle, string uuid)
	{
		if (!vehicle || uuid == "" || !m_InsurancesByUUID.Contains(uuid))
			return;
		SetVehicleInstanceId(vehicle, uuid);
		Print(string.Format("[JobInsuranceManager] UUID re-attache apres retrait garage : %1",
			uuid), LogLevel.NORMAL);
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== VERIFICATION =====
	//------------------------------------------------------------------------------------------------
	
	// Retourne true si l UUID a une assurance active
	bool IsUUIDInsured(string uuid)
	{
		if (uuid == "")
			return false;
		return m_InsurancesByUUID.Contains(uuid);
	}
	
	// Retourne true si le vehicule (dans le monde) a une assurance active
	bool IsVehicleInsured(IEntity vehicle)
	{
		string uuid = GetVehicleInstanceId(vehicle);
		return IsUUIDInsured(uuid);
	}
	
	// Retourne l InsuredVehicle par UUID (null si absent)
	InsuredVehicle GetInsuranceByUUID(string uuid)
	{
		InsuredVehicle ins;
		if (m_InsurancesByUUID.Find(uuid, ins))
			return ins;
		return null;
	}
	
	//------------------------------------------------------------------------------------------------
	// Retourne toutes les assurances actives d un joueur
	//------------------------------------------------------------------------------------------------
	array<ref InsuredVehicle> GetInsurancesForPlayer(string ownerUID)
	{
		array<ref InsuredVehicle> result = new array<ref InsuredVehicle>();
		if (ownerUID == "")
			return result;
		
		// Enforce n a pas GetKeyArray sur map. On itere par index.
		int cnt = m_InsurancesByUUID.Count();
		for (int i = 0; i < cnt; i++)
		{
			InsuredVehicle ins = m_InsurancesByUUID.GetElement(i);
			if (ins && ins.m_OwnerUID == ownerUID)
				result.Insert(ins);
		}
		return result;
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== DESTRUCTION / CONSOMMATION =====
	//------------------------------------------------------------------------------------------------
	
	//------------------------------------------------------------------------------------------------
	// Appele quand un vehicule assure est detruit.
	// Supprime l entree d assurance et retourne les infos pour l auto-respawn dans le garage.
	//
	// Retourne l InsuredVehicle qui vient d etre supprime (pour le caller qui peut ainsi
	// re-spawn le vehicule dans le garage virtuel avec le meme prefab).
	//------------------------------------------------------------------------------------------------
	InsuredVehicle ConsumeInsurance(string uuid)
	{
		InsuredVehicle ins;
		if (!m_InsurancesByUUID.Find(uuid, ins))
			return null;
		m_InsurancesByUUID.Remove(uuid);
		MarkSaveDirty();
		Print(string.Format("[JobInsuranceManager] Assurance consommee (vehicule detruit) : uuid=%1",
			uuid), LogLevel.NORMAL);
		return ins;
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== PERSISTANCE =====
	//------------------------------------------------------------------------------------------------

	//------------------------------------------------------------------------------------------------
	// Marque le fichier comme dirty et programme un flush debounce dans SAVE_DEBOUNCE_MS.
	// Si plusieurs MarkSaveDirty arrivent dans la fenetre, un seul SaveToDisk est fait a la fin.
	//------------------------------------------------------------------------------------------------
	void MarkSaveDirty()
	{
		m_bSaveDirty = true;
		if (!m_bSaveScheduled)
		{
			m_bSaveScheduled = true;
			GetGame().GetCallqueue().CallLater(FlushSave, SAVE_DEBOUNCE_MS, false);
		}
	}

	//------------------------------------------------------------------------------------------------
	// Appele par le callqueue : si dirty, ecrit effectivement sur disque et log si > 50ms.
	//------------------------------------------------------------------------------------------------
	void FlushSave()
	{
		m_bSaveScheduled = false;
		if (!m_bSaveDirty)
			return;
		m_bSaveDirty = false;
		int t0 = System.GetTickCount();
		SaveToDisk();
		int elapsed = System.GetTickCount() - t0;
		if (elapsed > 50)
			Print(string.Format("[JobInsuranceManager] FlushSave : ecriture disque = %1 ms (%2 assurances)",
				elapsed, m_InsurancesByUUID.Count()), LogLevel.WARNING);
	}

	void SaveToDisk()
	{
		if (!m_InsurancesByUUID)
			return;
		SCR_JsonSaveContext ctx = new SCR_JsonSaveContext();
		int count = m_InsurancesByUUID.Count();
		ctx.WriteValue("entry_count", count);
		for (int i = 0; i < count; i++)
		{
			InsuredVehicle ins = m_InsurancesByUUID.GetElement(i);
			if (!ins) continue;
			string ep = "entry_" + i.ToString() + "_";
			ctx.WriteValue(ep + "uuid", ins.m_InstanceUUID);
			ctx.WriteValue(ep + "owner", ins.m_OwnerUID);
			ctx.WriteValue(ep + "prefab", ins.m_Prefab);
			ctx.WriteValue(ep + "displayName", ins.m_PrefabDisplayName);
			ctx.WriteValue(ep + "purchasedAt", ins.m_PurchasedAt);
			ctx.WriteValue(ep + "expiresAt", ins.m_ExpiresAt);
		}
		ctx.SaveToFile(SAVE_PATH);
	}
	
	void LoadFromDisk()
	{
		SCR_JsonLoadContext ctx = new SCR_JsonLoadContext();
		if (!ctx.LoadFromFile(SAVE_PATH))
			return;
		int count = 0;
		ctx.ReadValue("entry_count", count);
		for (int i = 0; i < count; i++)
		{
			string ep = "entry_" + i.ToString() + "_";
			InsuredVehicle ins = new InsuredVehicle();
			ctx.ReadValue(ep + "uuid", ins.m_InstanceUUID);
			ctx.ReadValue(ep + "owner", ins.m_OwnerUID);
			ctx.ReadValue(ep + "prefab", ins.m_Prefab);
			ctx.ReadValue(ep + "displayName", ins.m_PrefabDisplayName);
			ctx.ReadValue(ep + "purchasedAt", ins.m_PurchasedAt);
			ctx.ReadValue(ep + "expiresAt", ins.m_ExpiresAt);
			if (ins.m_InstanceUUID != "" && ins.m_OwnerUID != "")
				m_InsurancesByUUID.Set(ins.m_InstanceUUID, ins);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== HELPERS =====
	//------------------------------------------------------------------------------------------------
	
	//------------------------------------------------------------------------------------------------
	// Extrait un nom lisible du prefab (partie apres le dernier '/' avant l extension)
	// Ex: "{GUID}Prefabs/Vehicles/Cars/Kamaz.et" -> "Kamaz"
	//------------------------------------------------------------------------------------------------
	string ExtractDisplayName(ResourceName rn)
	{
		string s = rn;
		int lastSlash = -1;
		int lenS = s.Length();
		for (int i = lenS - 1; i >= 0; i--)
		{
			if (s.Get(i) == "/")
			{
				lastSlash = i;
				break;
			}
		}
		string name;
		if (lastSlash >= 0)
			name = s.Substring(lastSlash + 1, lenS - lastSlash - 1);
		else
			name = s;
		// Retire l extension .et
		int dotIdx = name.IndexOf(".");
		if (dotIdx > 0)
			name = name.Substring(0, dotIdx);
		return name;
	}
}
