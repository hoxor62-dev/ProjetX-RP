//------------------------------------------------------------------------------------------------
// JobFuelPumpMenu.c
// Menu CLIENT affichant l animation de remplissage essence.
//
// Workflow :
//   1. Le client clique "Mettre de l essence" sur un vehicule
//   2. ClientAskFuelVehicle(rpl) -> serveur
//   3. Le serveur fait TOUTE la transaction (debite caps, remplit vehicule, deplete station)
//      en un appel atomique, puis renvoie les resultats via RpcDo_OpenFuelPumpResult
//   4. Le menu s ouvre avec les resultats pre-charges et joue l animation :
//      liters monte de 0 a totalLiters sur ANIMATION_MS, pareil pour les capsules
//
// L animation est purement visuelle. La transaction est deja finalisee cote serveur
// au moment ou le menu s ouvre.
//------------------------------------------------------------------------------------------------

class JobFuelPumpMenu : ChimeraMenuBase
{
	const int ANIMATION_MS = 5000; // Duree totale de l animation (5s)
	const int TICK_MS = 50;         // Rafraichissement toutes les 50ms

	// === DONNEES PRE-CHARGEES (set par RpcDo_OpenFuelPumpResult AVANT OpenMenu) ===
	static float s_PendingLiters = 0;       // litres a verser pendant l animation
	static int s_PendingPrice = 0;          // capsules a debiter
	static float s_PendingStationFuel = 0;  // reserve station APRES transaction (pour info)
	static int s_PendingResultCode = 0;     // 0 = OK, 1 = pas de station, 2 = station vide,
	                                        // 3 = reservoir plein, 4 = pas assez caps, 5 = pas de reservoir
	static string s_PendingStatusMessage = ""; // message a afficher dans StatusText

	Widget m_RootWidget;
	TextWidget m_LitersText;
	TextWidget m_PriceText;
	TextWidget m_StationFuelText;
	TextWidget m_StatusText;
	ImageWidget m_ProgressFill;
	ButtonWidget m_BtnClose;

	// === Etat animation runtime ===
	float m_TargetLiters;
	int m_TargetPrice;
	float m_AnimElapsedMs = 0;
	bool m_AnimationDone = false;

	//------------------------------------------------------------------------------------------------
	// Pre-charge les donnees avant OpenMenu (depuis le serveur via RpcDo_OpenFuelPumpResult)
	//------------------------------------------------------------------------------------------------
	static void SetPendingData(float liters, int price, float stationFuel, int resultCode, string status)
	{
		s_PendingLiters = liters;
		s_PendingPrice = price;
		s_PendingStationFuel = stationFuel;
		s_PendingResultCode = resultCode;
		s_PendingStatusMessage = status;
	}

	//------------------------------------------------------------------------------------------------
	override void OnMenuOpen()
	{
		super.OnMenuOpen();
		JobFocusHandler.ClearRegistry();

		m_RootWidget = GetRootWidget();
		if (!m_RootWidget) return;

		m_LitersText = TextWidget.Cast(m_RootWidget.FindAnyWidget("LitersText"));
		m_PriceText = TextWidget.Cast(m_RootWidget.FindAnyWidget("PriceText"));
		m_StationFuelText = TextWidget.Cast(m_RootWidget.FindAnyWidget("StationFuelText"));
		m_StatusText = TextWidget.Cast(m_RootWidget.FindAnyWidget("StatusText"));
		m_ProgressFill = ImageWidget.Cast(m_RootWidget.FindAnyWidget("ProgressFill"));
		m_BtnClose = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnClose"));

		if (m_BtnClose)
		{
			FuelPumpCloseHandler h = new FuelPumpCloseHandler();
			h.m_Menu = this;
			m_BtnClose.AddHandler(h);
			JobFocusHandler.Attach(m_BtnClose);
		}

		// Reserve station affichee immediatement (prix calcule depuis les donnees serveur
		// pour refleter un changement admin : prix/L = priceToPay / liters, fallback 3)
		if (m_StationFuelText)
		{
			int stationLitersInt = s_PendingStationFuel;
			int pricePerLiter = 3;
			if (s_PendingLiters > 0.01)
				pricePerLiter = Math.Round(s_PendingPrice / s_PendingLiters);
			if (pricePerLiter < 1) pricePerLiter = 1;
			if (pricePerLiter > 5) pricePerLiter = 5;
			m_StationFuelText.SetText(string.Format("Reserve station : %1 / 300 L   -   Prix: %2 caps/L",
				stationLitersInt.ToString(), pricePerLiter.ToString()));
		}

		// === CAS D ERREUR : pas d animation, affiche juste le message ===
		if (s_PendingResultCode != 0)
		{
			if (m_LitersText) m_LitersText.SetText("--- L");
			if (m_PriceText) m_PriceText.SetText("--- capsules");
			if (m_StatusText)
			{
				m_StatusText.SetText(s_PendingStatusMessage);
				m_StatusText.SetColor(Color.FromRGBA(255, 120, 120, 255)); // rouge
			}
			m_AnimationDone = true;
			return;
		}

		// === CAS OK : lance l animation ===
		m_TargetLiters = s_PendingLiters;
		m_TargetPrice = s_PendingPrice;
		m_AnimElapsedMs = 0;
		m_AnimationDone = false;

		if (m_StatusText)
		{
			m_StatusText.SetText("Remplissage en cours...");
			m_StatusText.SetColor(Color.FromRGBA(220, 220, 220, 255));
		}

		UpdateAnimation();
		GetGame().GetCallqueue().CallLater(UpdateAnimation, TICK_MS, true);
	}

	//------------------------------------------------------------------------------------------------
	// Tick animation : interpole liters + prix de 0 a target sur ANIMATION_MS
	//------------------------------------------------------------------------------------------------
	void UpdateAnimation()
	{
		if (m_AnimationDone) return;

		m_AnimElapsedMs = m_AnimElapsedMs + TICK_MS;
		float ratio = m_AnimElapsedMs / ANIMATION_MS;
		if (ratio >= 1.0)
		{
			ratio = 1.0;
			m_AnimationDone = true;
			GetGame().GetCallqueue().Remove(UpdateAnimation);

			if (m_StatusText)
			{
				m_StatusText.SetText("Remplissage termine.");
				m_StatusText.SetColor(Color.FromRGBA(140, 240, 140, 255)); // vert
			}
		}

		float currentLiters = m_TargetLiters * ratio;
		int currentPrice = Math.Round(m_TargetPrice * ratio);

		// Affiche les textes
		if (m_LitersText)
		{
			m_LitersText.SetText(string.Format("%1 / %2 L",
				FormatOneDecimal(currentLiters),
				FormatOneDecimal(m_TargetLiters)));
		}
		if (m_PriceText)
		{
			m_PriceText.SetText(string.Format("%1 / %2 capsules",
				currentPrice.ToString(),
				m_TargetPrice.ToString()));
		}

		// Barre de progression (480px de large)
		if (m_ProgressFill)
		{
			int w = Math.Round(480 * ratio);
			m_ProgressFill.SetSize(w, 22);
		}
	}

	//------------------------------------------------------------------------------------------------
	// Format "12.3" avec 1 decimale (Enforce n a pas de %.1f natif propre)
	//------------------------------------------------------------------------------------------------
	string FormatOneDecimal(float value)
	{
		int whole = value;
		int decimalPart = Math.AbsFloat((value - whole) * 10);
		return whole.ToString() + "." + decimalPart.ToString();
	}

	//------------------------------------------------------------------------------------------------
	override void OnMenuClose()
	{
		GetGame().GetCallqueue().Remove(UpdateAnimation);
		super.OnMenuClose();
	}

	//------------------------------------------------------------------------------------------------
	override void OnMenuUpdate(float tDelta)
	{
		super.OnMenuUpdate(tDelta);
		if (GetGame().GetInputManager().GetActionValue("MenuBack") > 0.5)
			CloseMenuInternal();
	}

	//------------------------------------------------------------------------------------------------
	void CloseMenuInternal()
	{
		GetGame().GetMenuManager().CloseMenu(this);
	}
}

//------------------------------------------------------------------------------------------------
class FuelPumpCloseHandler : ScriptedWidgetEventHandler
{
	JobFuelPumpMenu m_Menu;

	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.CloseMenuInternal();
		return true;
	}
}
