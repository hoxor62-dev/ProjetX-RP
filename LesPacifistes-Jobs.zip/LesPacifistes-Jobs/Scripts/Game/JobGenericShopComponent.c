//------------------------------------------------------------------------------------------------
// JobGenericShopComponent.c
// Composant a placer sur les PNJ de shops publics (vendeur vetements, nourriture, loueur).
// Contrairement a JobNPCComponent qui est lie a un metier specifique, ce composant
// ouvre directement le shop du type configure, accessible a TOUS les joueurs.
//------------------------------------------------------------------------------------------------

class JobGenericShopComponentClass : ScriptComponentClass {}

class JobGenericShopComponent : ScriptComponent
{
	[Attribute("30", UIWidgets.ComboBox, "Type de shop public",
		"", ParamEnumArray.FromEnum(EJobType))]
	int m_ShopType;
	
	//------------------------------------------------------------------------------------------------
	EJobType GetShopType()
	{
		return m_ShopType;
	}
}
