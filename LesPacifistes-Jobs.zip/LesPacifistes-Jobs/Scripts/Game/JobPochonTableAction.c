//------------------------------------------------------------------------------------------------
// JobPochonTableAction.c
// UserAction "Transformer sac en pochons" a placer sur la table.
// Envoie le RplId de la table au serveur qui verifie tout (metier voyou/gang, sac dispo, distance).
//------------------------------------------------------------------------------------------------

class JobPochonTableAction : ScriptedUserAction
{
	override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
	{
		PlayerController pc = PlayerController.Cast(GetGame().GetPlayerController());
		if (!pc) return;
		if (pUserEntity != pc.GetControlledEntity()) return;
		
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		
		RplComponent rpl = RplComponent.Cast(pOwnerEntity.FindComponent(RplComponent));
		if (!rpl) return;
		jpc.ClientAskStartPochonTransform(rpl.Id());
	}
	
	override bool CanBePerformedScript(IEntity user)
	{
		return true;
	}
	
	override bool CanBeShownScript(IEntity user)
	{
		return true;
	}
}
