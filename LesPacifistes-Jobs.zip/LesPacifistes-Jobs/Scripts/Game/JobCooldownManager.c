//------------------------------------------------------------------------------------------------
// JobCooldownManager.c
// Singleton serveur gerant les cooldowns separes pour les services metier :
//   - Cooldown EQUIPEMENT : 30 min apres avoir pris le vetement de service
//   - Cooldown VEHICULE   : 30 min apres avoir pris le vehicule de service
//
// Comportement :
//   - Les 2 cooldowns sont INDEPENDANTS (un joueur peut prendre le vetement puis
//     le vehicule a la suite, et il aura 2 cooldowns de 30min qui tournent en parallele)
//   - En memoire uniquement (PAS de persistance JSON) : reset au reboot serveur
//   - Stockage par UID joueur (resiste a la deconnexion/reconnexion sur la meme session serveur)
//
// Utilisation cote serveur (avant de donner equipement/vehicule) :
//   JobCooldownManager mgr = JobCooldownManager.GetInstance();
//   int remaining = mgr.GetEquipmentCooldownRemaining(uid);
//   if (remaining > 0) {
//       NotifyPlayerChat(playerId, "Cooldown : encore X min");
//       return;
//   }
//   // ... donner equipement ...
//   mgr.StartEquipmentCooldown(uid);
//------------------------------------------------------------------------------------------------

class JobCooldownManager
{
	static ref JobCooldownManager s_Instance;
	
	const int COOLDOWN_SECONDS = 1800;  // 30 minutes
	
	// Cooldowns par UID joueur : UID -> unix timestamp de fin
	ref map<string, int> m_EquipmentCooldowns;
	ref map<string, int> m_VehicleCooldowns;
	ref map<string, int> m_AmmoCooldowns;
	
	//------------------------------------------------------------------------------------------------
	void JobCooldownManager()
	{
		m_EquipmentCooldowns = new map<string, int>();
		m_VehicleCooldowns = new map<string, int>();
		m_AmmoCooldowns = new map<string, int>();
	}
	
	//------------------------------------------------------------------------------------------------
	static JobCooldownManager GetInstance()
	{
		if (!s_Instance)
			s_Instance = new JobCooldownManager();
		return s_Instance;
	}
	
	//------------------------------------------------------------------------------------------------
	// === COOLDOWN EQUIPEMENT ===
	//------------------------------------------------------------------------------------------------
	
	// Retourne le nombre de secondes restantes (0 si pas de cooldown actif)
	int GetEquipmentCooldownRemaining(string uid)
	{
		int cdEnd;
		if (!m_EquipmentCooldowns.Find(uid, cdEnd))
			return 0;
		int now = System.GetUnixTime();
		if (now >= cdEnd)
		{
			// Expire : on nettoie
			m_EquipmentCooldowns.Remove(uid);
			return 0;
		}
		return cdEnd - now;
	}
	
	// Demarre un cooldown equipement de 30min
	void StartEquipmentCooldown(string uid)
	{
		int cdEnd = System.GetUnixTime() + COOLDOWN_SECONDS;
		m_EquipmentCooldowns.Set(uid, cdEnd);
	}
	
	//------------------------------------------------------------------------------------------------
	// === COOLDOWN VEHICULE ===
	//------------------------------------------------------------------------------------------------
	
	// Retourne le nombre de secondes restantes (0 si pas de cooldown actif)
	int GetVehicleCooldownRemaining(string uid)
	{
		int cdEnd;
		if (!m_VehicleCooldowns.Find(uid, cdEnd))
			return 0;
		int now = System.GetUnixTime();
		if (now >= cdEnd)
		{
			m_VehicleCooldowns.Remove(uid);
			return 0;
		}
		return cdEnd - now;
	}
	
	// Demarre un cooldown vehicule de 30min
	void StartVehicleCooldown(string uid)
	{
		int cdEnd = System.GetUnixTime() + COOLDOWN_SECONDS;
		m_VehicleCooldowns.Set(uid, cdEnd);
	}
	
	//------------------------------------------------------------------------------------------------
	// === COOLDOWN MUNITIONS ===
	//------------------------------------------------------------------------------------------------
	
	// Retourne le nombre de secondes restantes (0 si pas de cooldown actif)
	int GetAmmoCooldownRemaining(string uid)
	{
		int cdEnd;
		if (!m_AmmoCooldowns.Find(uid, cdEnd))
			return 0;
		int now = System.GetUnixTime();
		if (now >= cdEnd)
		{
			m_AmmoCooldowns.Remove(uid);
			return 0;
		}
		return cdEnd - now;
	}
	
	// Demarre un cooldown munitions de 30min
	void StartAmmoCooldown(string uid)
	{
		int cdEnd = System.GetUnixTime() + COOLDOWN_SECONDS;
		m_AmmoCooldowns.Set(uid, cdEnd);
	}
	
	//------------------------------------------------------------------------------------------------
	// Helper : formate "X min Y sec restantes" pour les notifs chat
	//------------------------------------------------------------------------------------------------
	static string FormatRemaining(int seconds)
	{
		int min = seconds / 60;
		int sec = seconds % 60;
		if (min > 0)
			return string.Format("%1 min %2 sec", min, sec);
		return string.Format("%1 sec", sec);
	}
}
