//------------------------------------------------------------------------------------------------
// LP_PoliceRaidManager.c
// Singleton SERVEUR qui gere les perquisitions policieres en cours.
// - 3 policiers/militaires requis a moins de 10m de la porte pour declencher
// - Bélier requis dans l inventaire du declencheur (verifie au clic)
// - Timer 60s : a l issue, porte deverrouillee automatiquement
// - HUD envoye a tous les policier/militaire qui restent a moins de 10m pendant l action (dynamique)
//------------------------------------------------------------------------------------------------

class LP_PoliceRaidManager
{
	static ref LP_PoliceRaidManager s_Instance;
	
	// Constantes
	const int RAID_DURATION_MS = 60000;      // 1 minute
	const float RAID_RADIUS = 10.0;          // 10 metres
	const float RAID_RADIUS_SQ = 100.0;      // 10^2
	const int MIN_OFFICERS = 3;              // 3 policier/militaire minimum
	const int HUD_TICK_MS = 1000;            // 1s : refresh HUD + check joueurs presents
	
	// GUID du prefab belier - a remplacer par le vrai GUID (fourni par boss)
	// Pour trouver : chercher dans le mod par nom "belier" ou remplacer plus tard.
	static string BELIER_PREFAB = "{CFB9CC7270F8CEC4}Prefabs/Items/Equipment/Accessories/ETool_ALICE/belier.et"; // TODO : mettre vrai GUID
	
	// Raids en cours : cle = rplId.ToString() de la porte
	ref map<string, ref LP_ActiveRaid> m_ActiveRaids = new map<string, ref LP_ActiveRaid>();
	
	//------------------------------------------------------------------------------------------------
	static LP_PoliceRaidManager GetInstance()
	{
		if (!s_Instance) s_Instance = new LP_PoliceRaidManager();
		return s_Instance;
	}
	
	//------------------------------------------------------------------------------------------------
	// Un raid est-il deja en cours sur cette porte ?
	bool IsRaidActive(string doorRplIdStr)
	{
		return m_ActiveRaids.Contains(doorRplIdStr);
	}
	
	//------------------------------------------------------------------------------------------------
	// Compte les policier/militaire dans un rayon autour d une position (inclut le declencheur)
	int CountOfficersNearby(vector doorPos)
	{
		int count = 0;
		array<int> allIds = new array<int>();
		GetGame().GetPlayerManager().GetPlayers(allIds);
		foreach (int pid : allIds)
		{
			if (!IsOfficer(pid)) continue;
			IEntity ent = GetGame().GetPlayerManager().GetPlayerControlledEntity(pid);
			if (!ent) continue;
			if (vector.DistanceSq(ent.GetOrigin(), doorPos) > RAID_RADIUS_SQ) continue;
			count = count + 1;
		}
		return count;
	}
	
	//------------------------------------------------------------------------------------------------
	// True si le joueur a le metier POLICIER ou MILITAIRE
	bool IsOfficer(int playerId)
	{
		JobPlayerData data = JobManager.GetInstance().GetPlayerData(playerId);
		if (!data) return false;
		return (data.m_Job == EJobType.POLICIER || data.m_Job == EJobType.MILITAIRE);
	}
	
	//------------------------------------------------------------------------------------------------
	// Verifie que le joueur a un belier dans son inventaire (mains ou sac)
	bool PlayerHasBelier(int playerId)
	{
		PlayerController pc = GetGame().GetPlayerManager().GetPlayerController(playerId);
		if (!pc) return false;
		IEntity character = pc.GetControlledEntity();
		if (!character) return false;
		
		SCR_InventoryStorageManagerComponent invMgr = SCR_InventoryStorageManagerComponent.Cast(
			character.FindComponent(SCR_InventoryStorageManagerComponent));
		if (!invMgr) return false;
		
		array<IEntity> items = new array<IEntity>();
		invMgr.GetItems(items);
		
		foreach (IEntity item : items)
		{
			if (!item) continue;
			EntityPrefabData pd = item.GetPrefabData();
			if (!pd) continue;
			string rn = pd.GetPrefabName();
			if (rn == BELIER_PREFAB) return true;
		}
		return false;
	}
	
	//------------------------------------------------------------------------------------------------
	// SERVEUR : demarre une perquisition (appele par RpcAsk_StartRaid de JobPlayerComponent)
	// Retourne un code : 0 = OK, 1 = deja en cours, 2 = pas assez d officers, 3 = pas de belier,
	//                    4 = porte pas vendue, 5 = erreur
	int TryStartRaid(int triggerPlayerId, RplId doorRplId)
	{
		if (!Replication.IsServer()) return 5;
		
		string doorKey = doorRplId.ToString();
		
		// Check deja en cours
		if (IsRaidActive(doorKey)) return 1;
		
		// Check metier
		if (!IsOfficer(triggerPlayerId)) return 5;
		
		// Recupere l entite porte
		RplComponent doorRpl = RplComponent.Cast(Replication.FindItem(doorRplId));
		if (!doorRpl) return 5;
		IEntity doorEntity = doorRpl.GetEntity();
		if (!doorEntity) return 5;
		
		// Check porte a un proprio
		LP_DoorData door = LP_DoorManager.GetInstance().GetDoorByRplId(doorRplId);
		if (!door) return 4;
		
		// Check belier dans inventaire
		if (!PlayerHasBelier(triggerPlayerId)) return 3;
		
		// Check 3 officers a moins de 10m
		vector doorPos = doorEntity.GetOrigin();
		int officerCount = CountOfficersNearby(doorPos);
		if (officerCount < MIN_OFFICERS) return 2;
		
		// OK : cree le raid
		LP_ActiveRaid raid = new LP_ActiveRaid();
		raid.m_DoorRplId = doorRplId;
		raid.m_DoorRplIdStr = doorKey;
		raid.m_DoorPos = doorPos;
		raid.m_TriggerPlayerId = triggerPlayerId;
		raid.m_StartTimeMs = GetGame().GetWorld().GetWorldTime();
		raid.m_EndTimeMs = raid.m_StartTimeMs + RAID_DURATION_MS;
		m_ActiveRaids.Set(doorKey, raid);
		
		// Marque la porte "raid in progress" (RplProp) pour cacher les autres actions
		LP_DoorAccessComponent access = LP_DoorAccessComponent.Cast(
			doorEntity.FindComponent(LP_DoorAccessComponent));
		if (access) access.ServerSetRaidInProgress(true);
		
		// Tick immediat pour envoyer le HUD aux officers presents + verifie fin
		GetGame().GetCallqueue().CallLater(TickRaid, HUD_TICK_MS, true, doorKey);
		TickRaid(doorKey); // premier tick immediat
		
		Print(string.Format("[LP_PoliceRaid] Perquisition demarree sur %1 par playerId=%2 (%3 officers presents)",
			doorKey, triggerPlayerId, officerCount), LogLevel.NORMAL);
		return 0;
	}
	
	//------------------------------------------------------------------------------------------------
	// SERVEUR : appele toutes les 1s pour un raid en cours
	// - Refresh le HUD des officers dans le rayon (show/hide dynamique)
	// - Verifie si le timer est ecoule -> deverrouille + termine
	void TickRaid(string doorKey)
	{
		if (!Replication.IsServer()) return;
		
		LP_ActiveRaid raid = m_ActiveRaids.Get(doorKey);
		if (!raid)
		{
			// Raid supprime, stop les callbacks
			GetGame().GetCallqueue().Remove(TickRaid);
			return;
		}
		
		float now = GetGame().GetWorld().GetWorldTime();
		int remainingMs = raid.m_EndTimeMs - now;
		
		// Termine si timer ecoule
		if (remainingMs <= 0)
		{
			EndRaid(raid);
			return;
		}
		
		// Recupere les officers actuellement dans le rayon
		array<int> currentOfficerIds = new array<int>();
		array<int> allIds = new array<int>();
		GetGame().GetPlayerManager().GetPlayers(allIds);
		foreach (int pid : allIds)
		{
			if (!IsOfficer(pid)) continue;
			IEntity ent = GetGame().GetPlayerManager().GetPlayerControlledEntity(pid);
			if (!ent) continue;
			if (vector.DistanceSq(ent.GetOrigin(), raid.m_DoorPos) > RAID_RADIUS_SQ) continue;
			currentOfficerIds.Insert(pid);
		}
		
		// Show HUD aux nouveaux entrants
		foreach (int pid : currentOfficerIds)
		{
			bool alreadyHud = false;
			foreach (int prevPid : raid.m_OfficersWithHud)
			{
				if (prevPid == pid) { alreadyHud = true; break; }
			}
			if (!alreadyHud)
				ShowHudForPlayer(pid, remainingMs);
		}
		
		// Hide HUD aux sortants
		foreach (int prevPid : raid.m_OfficersWithHud)
		{
			bool stillPresent = false;
			foreach (int pid : currentOfficerIds)
			{
				if (pid == prevPid) { stillPresent = true; break; }
			}
			if (!stillPresent)
				HideHudForPlayer(prevPid);
		}
		
		// Update la liste
		raid.m_OfficersWithHud.Clear();
		foreach (int pid : currentOfficerIds)
			raid.m_OfficersWithHud.Insert(pid);
	}
	
	//------------------------------------------------------------------------------------------------
	// SERVEUR : termine un raid (timer ecoule)
	protected void EndRaid(LP_ActiveRaid raid)
	{
		if (!raid) return;
		if (!Replication.IsServer()) return;
		
		string doorKey = raid.m_DoorRplIdStr;
		
		// Deverrouille la porte
		RplComponent doorRpl = RplComponent.Cast(Replication.FindItem(raid.m_DoorRplId));
		if (doorRpl)
		{
			IEntity doorEntity = doorRpl.GetEntity();
			if (doorEntity)
			{
				LP_DoorAccessComponent access = LP_DoorAccessComponent.Cast(
					doorEntity.FindComponent(LP_DoorAccessComponent));
				if (access)
				{
					access.ServerSetLocked(false);
					access.ServerSetRaidInProgress(false);
				}
			}
		}
		
		// Hide le HUD chez tous les officers qui l ont
		foreach (int pid : raid.m_OfficersWithHud)
			HideHudForPlayer(pid);
		
		// Notif chat aux officers
		foreach (int pid : raid.m_OfficersWithHud)
		{
			JobManager.GetInstance().NotifyPlayerChat(pid, "[Perquisition] Terminee - porte deverrouillee.");
		}
		
		// Nettoyage
		m_ActiveRaids.Remove(doorKey);
		
		// Stop le callback si plus aucun raid actif
		if (m_ActiveRaids.Count() == 0)
			GetGame().GetCallqueue().Remove(TickRaid);
		
		Print(string.Format("[LP_PoliceRaid] Perquisition terminee sur %1", doorKey), LogLevel.NORMAL);
	}
	
	//------------------------------------------------------------------------------------------------
	// SERVEUR : envoie le HUD au client (via son JobPlayerComponent)
	protected void ShowHudForPlayer(int playerId, int remainingMs)
	{
		PlayerController pc = GetGame().GetPlayerManager().GetPlayerController(playerId);
		if (!pc) return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (jpc) jpc.LP_ServerSendShowRaidHud(remainingMs);
	}
	
	//------------------------------------------------------------------------------------------------
	protected void HideHudForPlayer(int playerId)
	{
		PlayerController pc = GetGame().GetPlayerManager().GetPlayerController(playerId);
		if (!pc) return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (jpc) jpc.LP_ServerSendHideRaidHud();
	}
}

//------------------------------------------------------------------------------------------------
// Struct : un raid en cours
//------------------------------------------------------------------------------------------------
class LP_ActiveRaid
{
	RplId m_DoorRplId;
	string m_DoorRplIdStr;
	vector m_DoorPos;
	int m_TriggerPlayerId;
	float m_StartTimeMs;
	float m_EndTimeMs;
	ref array<int> m_OfficersWithHud = new array<int>(); // playerIds qui voient actuellement le HUD
}
