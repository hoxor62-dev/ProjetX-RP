//------------------------------------------------------------------------------------------------
// JobBonPointAccessMenu.c
// Menu d accueil du systeme LeBonPoint. 3 boutons :
//   - Acheter : ouvre la liste des annonces (Session 2)
//   - Vendre : ouvre la liste de l inventaire pour choisir un item a vendre
//   - Mon Profil : stats + mes annonces + mes achats (Session 2)
//------------------------------------------------------------------------------------------------

class JobBonPointAccessMenu : ChimeraMenuBase
{
	Widget m_RootWidget;
	TextWidget m_TitleText;
	TextWidget m_SubtitleText;
	ButtonWidget m_BtnBuy;
	ButtonWidget m_BtnSell;
	ButtonWidget m_BtnProfile;
	ButtonWidget m_BtnClose;
	
	static JobBonPointAccessMenu s_Instance;
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuOpen()
	{
		super.OnMenuOpen();
		s_Instance = this;
		JobFocusHandler.ClearRegistry();
		
		m_RootWidget = GetRootWidget();
		if (!m_RootWidget) return;
		
		m_TitleText = TextWidget.Cast(m_RootWidget.FindAnyWidget("TitleText"));
		m_SubtitleText = TextWidget.Cast(m_RootWidget.FindAnyWidget("SubtitleText"));
		m_BtnBuy = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnBuy"));
		m_BtnSell = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnSell"));
		m_BtnProfile = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnProfile"));
		m_BtnClose = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnClose"));
		
		if (m_TitleText)
			m_TitleText.SetText("LE BON POINT");
		if (m_SubtitleText)
			m_SubtitleText.SetText("Achetez et vendez en toute liberte");
		
		BindBtn(m_BtnBuy, "buy");
		BindBtn(m_BtnSell, "sell");
		BindBtn(m_BtnProfile, "profile");
		BindBtn(m_BtnClose, "close");
		
		if (m_BtnClose)
			GetGame().GetWorkspace().SetFocusedWidget(m_BtnClose);
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuClose()
	{
		if (s_Instance == this)
			s_Instance = null;
		super.OnMenuClose();
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuUpdate(float tDelta)
	{
		super.OnMenuUpdate(tDelta);
		if (GetGame().GetInputManager().GetActionValue("MenuBack") > 0.5)
			CloseMenuInternal();
	}
	
	//------------------------------------------------------------------------------------------------
	void BindBtn(ButtonWidget btn, string action)
	{
		if (!btn)
			return;
		BonPointAccessHandler h = new BonPointAccessHandler();
		h.m_Menu = this;
		h.m_Action = action;
		btn.AddHandler(h);
		JobFocusHandler.Attach(btn);
	}
	
	//------------------------------------------------------------------------------------------------
	void OnAction(string action)
	{
		if (action == "close")
		{
			CloseMenuInternal();
			return;
		}
		
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		
		if (action == "sell")
		{
			// Demande au serveur la liste des items dans l inventaire (eligibles a la vente)
			jpc.ClientAskListInventoryForBonPoint();
			CloseMenuInternal();
			return;
		}
		if (action == "buy")
		{
			// Demande au serveur la liste des annonces
			jpc.ClientAskListBonPointAds();
			CloseMenuInternal();
			return;
		}
		if (action == "profile")
		{
			// Demande au serveur les donnees du profil
			jpc.ClientAskOpenBonPointProfile();
			CloseMenuInternal();
			return;
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// (Placeholder NotifyComingSoon retire - tous les onglets sont actifs)
	
	//------------------------------------------------------------------------------------------------
	void CloseMenuInternal()
	{
		GetGame().GetMenuManager().CloseMenu(this);
	}
	
	static JobBonPointAccessMenu GetOpenMenu() { return s_Instance; }
}

//------------------------------------------------------------------------------------------------
class BonPointAccessHandler : ScriptedWidgetEventHandler
{
	JobBonPointAccessMenu m_Menu;
	string m_Action;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.OnAction(m_Action);
		return true;
	}
}
