//------------------------------------------------------------------------------------------------
// LP_BucheronCraftMenu.c
// Menu de craft du bucheron (meme pattern que LP_EpicerieCraftMenu).
// Accessible uniquement au metier BUCHERON.
//------------------------------------------------------------------------------------------------

class LP_BucheronCraftMenu : ChimeraMenuBase
{
	static LP_BucheronCraftMenu s_Instance;
	static LP_BucheronCraftMenu GetOpenMenu() { return s_Instance; }
	
	Widget m_Root;
	Widget m_RecipeListContainer;
	Widget m_QueueContainer;
	TextWidget m_TitleText;
	TextWidget m_PreviewName;
	TextWidget m_PreviewIngredients;
	ItemPreviewWidget m_PreviewWidget;
	ButtonWidget m_BtnCraft;
	ButtonWidget m_BtnClose;
	
	int m_SelectedRecipeId = -1;
	
	// Focus manette : reference au premier bouton de recette (pour focus initial)
	ButtonWidget m_FirstRecipeButton;
	
	// Etat file d attente (recu par push du serveur)
	ref array<int> m_QueueEntryIds = new array<int>();
	ref array<int> m_QueueRecipeIds = new array<int>();
	ref array<int> m_QueueSecondsRemaining = new array<int>();
	
	// Cache boutons recettes -> recipeId
	ref map<ButtonWidget, int> m_RecipeButtonToId = new map<ButtonWidget, int>();
	// Cache boutons queue -> entryId
	ref map<ButtonWidget, int> m_QueueButtonToEntryId = new map<ButtonWidget, int>();
	
	// Reference au manager de preview 3D (cache)
	ItemPreviewManagerEntity m_PreviewManager;
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuOpen()
	{
		super.OnMenuOpen();
		s_Instance = this;
		JobFocusHandler.ClearRegistry();
		m_Root = GetRootWidget();
		if (!m_Root) return;
		
		m_RecipeListContainer  = m_Root.FindAnyWidget("RecipeListContainer");
		m_QueueContainer       = m_Root.FindAnyWidget("QueueContainer");
		m_TitleText            = TextWidget.Cast(m_Root.FindAnyWidget("TitleText"));
		m_PreviewName          = TextWidget.Cast(m_Root.FindAnyWidget("PreviewName"));
		m_PreviewIngredients   = TextWidget.Cast(m_Root.FindAnyWidget("PreviewIngredients"));
		m_PreviewWidget        = ItemPreviewWidget.Cast(m_Root.FindAnyWidget("PreviewWidget"));
		m_BtnCraft             = ButtonWidget.Cast(m_Root.FindAnyWidget("BtnCraft"));
		m_BtnClose             = ButtonWidget.Cast(m_Root.FindAnyWidget("BtnClose"));
		
		if (m_TitleText) m_TitleText.SetText("Craft Bucheron");
		if (m_PreviewName) m_PreviewName.SetText("");
		if (m_PreviewIngredients) m_PreviewIngredients.SetText("");
		
		if (m_BtnCraft)
		{
			LP_BucheronCraftClickHandler h = new LP_BucheronCraftClickHandler();
			h.m_Menu = this;
			h.m_Kind = "craft";
			m_BtnCraft.AddHandler(h);
			JobFocusHandler.Attach(m_BtnCraft);
			m_BtnCraft.SetEnabled(false);
			m_BtnCraft.SetVisible(true);
		}
		if (m_BtnClose)
		{
			LP_BucheronCraftClickHandler h = new LP_BucheronCraftClickHandler();
			h.m_Menu = this;
			h.m_Kind = "close";
			m_BtnClose.AddHandler(h);
			JobFocusHandler.Attach(m_BtnClose);
		}
		
		// Bouton Fermer secondaire (dans la colonne droite pour navigation manette facile)
		ButtonWidget btnCloseSecondary = ButtonWidget.Cast(m_Root.FindAnyWidget("BtnCloseSecondary"));
		if (btnCloseSecondary)
		{
			LP_BucheronCraftClickHandler h = new LP_BucheronCraftClickHandler();
			h.m_Menu = this;
			h.m_Kind = "close";
			btnCloseSecondary.AddHandler(h);
			JobFocusHandler.Attach(btnCloseSecondary);
		}
		
		BuildRecipeList();
		RefreshQueueUI();
		
		if (m_FirstRecipeButton)
			GetGame().GetCallqueue().CallLater(SetInitialFocus, 50, false);
		
		PlayerController pc = GetGame().GetPlayerController();
		if (pc)
		{
			JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
			if (jpc) jpc.ClientAskBucheronCraftQueueRefresh();
		}
	}
	
	//------------------------------------------------------------------------------------------------
	protected void SetInitialFocus()
	{
		if (m_FirstRecipeButton)
			GetGame().GetWorkspace().SetFocusedWidget(m_FirstRecipeButton);
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuClose()
	{
		s_Instance = null;
		JobFocusHandler.ClearRegistry();
		super.OnMenuClose();
	}
	
	//------------------------------------------------------------------------------------------------
	// Tick chaque frame : ecoute le bouton MenuBack (B manette / Echap clavier) pour fermer
	//------------------------------------------------------------------------------------------------
	override void OnMenuUpdate(float tDelta)
	{
		super.OnMenuUpdate(tDelta);
		if (GetGame().GetInputManager().GetActionValue("MenuBack") > 0.5)
		{
			OnCloseClicked();
			return;
		}
	}
	
	//------------------------------------------------------------------------------------------------
	protected void BuildRecipeList()
	{
		if (!m_RecipeListContainer) return;
		m_FirstRecipeButton = null;
		
		array<ref LP_BucheronCraftRecipe> recipes = LP_BucheronCraftData.GetAllRecipes();
		foreach (LP_BucheronCraftRecipe r : recipes)
		{
			if (!r) continue;
			Widget btnWidget = GetGame().GetWorkspace().CreateWidgets(
				"UI/layouts/LP_EpicerieCraftEntry.layout", m_RecipeListContainer);
			if (!btnWidget) continue;
			
			TextWidget label = TextWidget.Cast(btnWidget.FindAnyWidget("EntryLabel"));
			if (label) label.SetText(r.m_DisplayName);
			
			ButtonWidget btn = ButtonWidget.Cast(btnWidget.FindAnyWidget("EntryButton"));
			if (btn)
			{
				m_RecipeButtonToId.Set(btn, r.m_RecipeId);
				LP_BucheronCraftClickHandler h = new LP_BucheronCraftClickHandler();
				h.m_Menu = this;
				h.m_Kind = "select_recipe";
				h.m_ButtonRef = btn;
				btn.AddHandler(h);
				JobFocusHandler.Attach(btn);
				if (!m_FirstRecipeButton)
					m_FirstRecipeButton = btn;
			}
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void OnRecipeSelected(int recipeId)
	{
		m_SelectedRecipeId = recipeId;
		LP_BucheronCraftRecipe recipe = LP_BucheronCraftData.GetRecipeById(recipeId);
		if (!recipe) return;
		
		if (m_BtnCraft)
			m_BtnCraft.SetEnabled(true);
		
		if (m_PreviewName)
			m_PreviewName.SetText(recipe.m_DisplayName);
		
		string ingText = "Ingredients requis :\n";
		foreach (LP_BucheronCraftIngredient ing : recipe.m_Ingredients)
		{
			if (!ing) continue;
			ingText = ingText + "- " + ing.m_DisplayName + " x" + ing.m_Quantity.ToString() + "\n";
		}
		if (m_PreviewIngredients)
			m_PreviewIngredients.SetText(ingText);
		
		if (m_PreviewWidget)
		{
			ItemPreviewManagerEntity manager = GetPreviewManager();
			if (manager)
			{
				ResourceName prefab = recipe.m_ResultPrefab;
				manager.SetPreviewItemFromPrefab(m_PreviewWidget, prefab, null, false);
			}
		}
		
		// FIX NAVIGATION MANETTE : force le focus sur le bouton Craft apres selection recette
		if (m_BtnCraft)
			GetGame().GetCallqueue().CallLater(FocusCraftButton, 50, false);
	}
	
	//------------------------------------------------------------------------------------------------
	protected void FocusCraftButton()
	{
		if (m_BtnCraft)
			GetGame().GetWorkspace().SetFocusedWidget(m_BtnCraft);
	}
	
	//------------------------------------------------------------------------------------------------
	protected ItemPreviewManagerEntity GetPreviewManager()
	{
		if (m_PreviewManager) return m_PreviewManager;
		BaseWorld world = GetGame().GetWorld();
		if (!world) return null;
		IEntity entity = world.FindEntityByName("ItemPreviewManagerEntity");
		if (entity)
			m_PreviewManager = ItemPreviewManagerEntity.Cast(entity);
		return m_PreviewManager;
	}
	
	//------------------------------------------------------------------------------------------------
	void OnCraftClicked()
	{
		if (m_SelectedRecipeId < 0) return;
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		jpc.ClientAskBucheronCraftAdd(m_SelectedRecipeId);
	}
	
	//------------------------------------------------------------------------------------------------
	void OnQueueCollectClicked(int entryId)
	{
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		jpc.ClientAskBucheronCraftCollect(entryId);
	}
	
	//------------------------------------------------------------------------------------------------
	void OnCloseClicked()
	{
		GetGame().GetMenuManager().CloseMenu(this);
	}
	
	//------------------------------------------------------------------------------------------------
	void UpdateQueue(array<int> entryIds, array<int> recipeIds, array<int> secondsRemaining)
	{
		m_QueueEntryIds.Clear();
		m_QueueRecipeIds.Clear();
		m_QueueSecondsRemaining.Clear();
		
		foreach (int id : entryIds) m_QueueEntryIds.Insert(id);
		foreach (int rid : recipeIds) m_QueueRecipeIds.Insert(rid);
		foreach (int sec : secondsRemaining) m_QueueSecondsRemaining.Insert(sec);
		
		RefreshQueueUI();
	}
	
	//------------------------------------------------------------------------------------------------
	protected void RefreshQueueUI()
	{
		if (!m_QueueContainer) return;
		
		m_QueueButtonToEntryId.Clear();
		Widget child = m_QueueContainer.GetChildren();
		while (child)
		{
			Widget next = child.GetSibling();
			child.RemoveFromHierarchy();
			child = next;
		}
		
		for (int i = 0; i < m_QueueEntryIds.Count(); i++)
		{
			int entryId = m_QueueEntryIds[i];
			int recipeId = m_QueueRecipeIds[i];
			int secLeft = m_QueueSecondsRemaining[i];
			
			LP_BucheronCraftRecipe recipe = LP_BucheronCraftData.GetRecipeById(recipeId);
			if (!recipe) continue;
			
			Widget entryWidget = GetGame().GetWorkspace().CreateWidgets(
				"UI/layouts/LP_EpicerieCraftQueueEntry.layout", m_QueueContainer);
			if (!entryWidget) continue;
			
			TextWidget nameLabel = TextWidget.Cast(entryWidget.FindAnyWidget("QueueName"));
			TextWidget timeLabel = TextWidget.Cast(entryWidget.FindAnyWidget("QueueTime"));
			ButtonWidget btnCollect = ButtonWidget.Cast(entryWidget.FindAnyWidget("BtnCollect"));
			
			if (nameLabel) nameLabel.SetText(recipe.m_DisplayName);
			if (timeLabel)
			{
				if (secLeft > 0)
					timeLabel.SetText("En cours : " + secLeft.ToString() + "s");
				else
					timeLabel.SetText("Pret !");
			}
			
			if (btnCollect)
			{
				if (secLeft > 0)
				{
					btnCollect.SetEnabled(false);
					btnCollect.SetColor(Color.FromRGBA(80, 80, 80, 200));
				}
				else
				{
					btnCollect.SetEnabled(true);
					btnCollect.SetColor(Color.FromRGBA(80, 180, 80, 255));
				}
				
				m_QueueButtonToEntryId.Set(btnCollect, entryId);
				LP_BucheronCraftClickHandler h = new LP_BucheronCraftClickHandler();
				h.m_Menu = this;
				h.m_Kind = "collect";
				h.m_ButtonRef = btnCollect;
				btnCollect.AddHandler(h);
				
				if (secLeft <= 0)
					JobFocusHandler.Attach(btnCollect);
			}
		}
	}
}

//------------------------------------------------------------------------------------------------
class LP_BucheronCraftClickHandler : ScriptedWidgetEventHandler
{
	LP_BucheronCraftMenu m_Menu;
	string m_Kind;
	ButtonWidget m_ButtonRef;
	
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (!m_Menu) return false;
		
		if (m_Kind == "craft")
		{
			m_Menu.OnCraftClicked();
			return true;
		}
		if (m_Kind == "close")
		{
			m_Menu.OnCloseClicked();
			return true;
		}
		if (m_Kind == "select_recipe" && m_ButtonRef)
		{
			int recipeId = m_Menu.m_RecipeButtonToId.Get(m_ButtonRef);
			if (recipeId > 0) m_Menu.OnRecipeSelected(recipeId);
			return true;
		}
		if (m_Kind == "collect" && m_ButtonRef)
		{
			int entryId = m_Menu.m_QueueButtonToEntryId.Get(m_ButtonRef);
			if (entryId > 0) m_Menu.OnQueueCollectClicked(entryId);
			return true;
		}
		return false;
	}
}
