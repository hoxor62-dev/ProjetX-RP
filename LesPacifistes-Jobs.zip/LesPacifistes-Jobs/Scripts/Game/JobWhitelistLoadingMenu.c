//------------------------------------------------------------------------------------------------
// JobWhitelistLoadingMenu.c
// Layout affiche cote client apres validation whitelist reussie.
// Reste ouvert 5 secondes avec une barre de progression animee puis se ferme automatiquement.
// Le joueur ne peut pas fermer manuellement (aucun bouton, MenuBack desactive).
//------------------------------------------------------------------------------------------------

class JobWhitelistLoadingMenu : ChimeraMenuBase
{
	// Duree totale d affichage (ms) - doit coincider avec la sensation de chargement
	const int DISPLAY_DURATION_MS = 15000;
	
	// Frequence de rafraichissement de la barre (ms) - 50ms = 20 fps
	const int TICK_INTERVAL_MS = 150;
	
	// Largeur totale de la barre (doit correspondre au layout - WidthOverride 700)
	const int BAR_MAX_WIDTH = 700;
	
	Widget m_RootWidget;
	ImageWidget m_BarFill;
	
	int m_StartTimeMs = 0;
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuOpen()
	{
		super.OnMenuOpen();
		m_RootWidget = GetRootWidget();
		if (!m_RootWidget) return;
		
		m_BarFill = ImageWidget.Cast(m_RootWidget.FindAnyWidget("BarFill"));
		m_StartTimeMs = System.GetTickCount();
		
		// Anime la barre a chaque tick
		GetGame().GetCallqueue().CallLater(TickBar, TICK_INTERVAL_MS, true);
		
		// Auto-fermeture apres 5 secondes
		GetGame().GetCallqueue().CallLater(AutoClose, DISPLAY_DURATION_MS, false);
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuClose()
	{
		GetGame().GetCallqueue().Remove(TickBar);
		GetGame().GetCallqueue().Remove(AutoClose);
		super.OnMenuClose();
	}
	
	//------------------------------------------------------------------------------------------------
	// Bloque l input MenuBack pour empecher la fermeture manuelle par le joueur
	//------------------------------------------------------------------------------------------------
	override void OnMenuUpdate(float tDelta)
	{
		super.OnMenuUpdate(tDelta);
		// Ne pas ecouter MenuBack : le menu doit rester ouvert 5s complets
	}
	
	//------------------------------------------------------------------------------------------------
	// Met a jour la barre de progression pour donner un effet visuel de chargement
	//------------------------------------------------------------------------------------------------
	void TickBar()
	{
		if (!m_BarFill) return;
		int nowMs = System.GetTickCount();
		int elapsedMs = nowMs - m_StartTimeMs;
		if (elapsedMs < 0) elapsedMs = 0;
		if (elapsedMs > DISPLAY_DURATION_MS) elapsedMs = DISPLAY_DURATION_MS;
		
		float ratio = (float)elapsedMs / (float)DISPLAY_DURATION_MS;
		if (ratio > 1) ratio = 1;
		float width = BAR_MAX_WIDTH * ratio;
		m_BarFill.SetSize(width, 14);
	}
	
	//------------------------------------------------------------------------------------------------
	void AutoClose()
	{
		GetGame().GetMenuManager().CloseMenu(this);
	}
}
