//------------------------------------------------------------------------------------------------
// JobPoliceRecordManager.c
//
// Singleton serveur qui gere les "dossiers judiciaires avances" des joueurs
// (SEPARE de JobCriminalManager, ne remplace pas la fiche criminelle existante).
//
// Fonctionnalites :
//   - Get/Create dossier par UID
//   - CRUD peines (SentenceRecord)
//   - CRUD mandats (WarrantRecord)
//   - CRUD notes officiers (OfficerNote)
//   - Statut manuel (EJudicialStatus + detail libre)
//   - Rehabilitation automatique : derniere condamnation + REHAB_YEARS annees
//
// Persistance : $profile:LesPacifistesJobs/police_records.json
//------------------------------------------------------------------------------------------------

class JobPoliceRecordManager
{
	static ref JobPoliceRecordManager s_Instance;
	
	// Constantes
	const int REHAB_YEARS = 3;                    // Rehabilitation apres derniere condamnation + 3 ans
	const int SECONDS_PER_YEAR = 31536000;        // 365 * 86400
	
	const string SAVE_PATH = "$profile:LesPacifistesJobs/police_records.json";
	
	// Map UID -> record
	ref map<string, ref PoliceRecord> m_Records;
	
	//------------------------------------------------------------------------------------------------
	void JobPoliceRecordManager()
	{
		m_Records = new map<string, ref PoliceRecord>();
	}
	
	//------------------------------------------------------------------------------------------------
	static JobPoliceRecordManager GetInstance()
	{
		if (!s_Instance)
		{
			s_Instance = new JobPoliceRecordManager();
			s_Instance.LoadFromDisk();
		}
		return s_Instance;
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== ACCES DOSSIERS =====
	//------------------------------------------------------------------------------------------------
	
	PoliceRecord GetOrCreateRecord(string uid, string playerName)
	{
		if (uid == "")
			return null;
		PoliceRecord rec = m_Records.Get(uid);
		if (!rec)
		{
			rec = new PoliceRecord();
			rec.m_PlayerUID = uid;
			rec.m_PlayerName = playerName;
			m_Records.Set(uid, rec);
			SaveToDisk();
		}
		else if (playerName != "" && playerName != rec.m_PlayerName)
		{
			// Met a jour le nom si change
			rec.m_PlayerName = playerName;
			SaveToDisk();
		}
		return rec;
	}
	
	PoliceRecord GetRecord(string uid)
	{
		if (uid == "")
			return null;
		return m_Records.Get(uid);
	}
	
	//------------------------------------------------------------------------------------------------
	// Retourne tous les records dont le nom OU l UID contient la sous-chaine (case-insensitive
	// sur le nom seulement, l UID est case-sensitive).
	// Retourne max maxResults resultats pour ne pas surcharger le RPC.
	//------------------------------------------------------------------------------------------------
	void SearchRecords(string query, int maxResults, out array<ref PoliceRecord> outResults)
	{
		if (!outResults)
			return;
		if (query == "")
		{
			// Sans query, retourne les X premiers dossiers connus (utile a l ouverture initiale)
			int cnt = m_Records.Count();
			int limit = maxResults;
			if (limit > cnt)
				limit = cnt;
			for (int i = 0; i < limit; i++)
			{
				PoliceRecord rec = m_Records.GetElement(i);
				if (rec)
					outResults.Insert(rec);
			}
			return;
		}
		
		string queryLower = query;
		queryLower.ToLower();
		int total = m_Records.Count();
		for (int i = 0; i < total && outResults.Count() < maxResults; i++)
		{
			PoliceRecord rec = m_Records.GetElement(i);
			if (!rec)
				continue;
			
			string nameLower = rec.m_PlayerName;
			nameLower.ToLower();
			
			if (nameLower.Contains(queryLower) || rec.m_PlayerUID.Contains(query))
				outResults.Insert(rec);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== STATUT =====
	//------------------------------------------------------------------------------------------------
	
	void SetStatus(string uid, EJudicialStatus status, string detail)
	{
		PoliceRecord rec = GetRecord(uid);
		if (!rec)
			return;
		rec.m_Status = status;
		rec.m_StatusDetail = detail;
		SaveToDisk();
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== PEINES (SentenceRecord) =====
	//------------------------------------------------------------------------------------------------
	
	// Ajoute une peine. Retourne l index dans le tableau.
	int AddSentence(string uid, string charge, int durationDays, string issuerName, string issuerUID)
	{
		if (uid == "" || charge == "")
			return -1;
		PoliceRecord rec = GetRecord(uid);
		if (!rec)
			return -1;
		
		SentenceRecord s = new SentenceRecord();
		s.m_Charge = charge;
		s.m_IssuedTimestamp = System.GetUnixTime();
		s.m_DurationDays = durationDays;
		s.m_Active = true;
		s.m_IssuerName = issuerName;
		s.m_IssuerUID = issuerUID;
		rec.m_Sentences.Insert(s);
		
		// Met a jour le timestamp derniere condamnation pour le calcul rehabilitation
		rec.m_LastConvictionTimestamp = s.m_IssuedTimestamp;
		
		SaveToDisk();
		return rec.m_Sentences.Count() - 1;
	}
	
	// Marque une peine comme purgee (active = false)
	bool MarkSentencePurged(string uid, int sentenceIndex)
	{
		PoliceRecord rec = GetRecord(uid);
		if (!rec)
			return false;
		if (sentenceIndex < 0 || sentenceIndex >= rec.m_Sentences.Count())
			return false;
		SentenceRecord s = rec.m_Sentences.Get(sentenceIndex);
		if (!s)
			return false;
		s.m_Active = false;
		SaveToDisk();
		return true;
	}
	
	// Supprime une peine (utile pour correction erreur)
	bool RemoveSentence(string uid, int sentenceIndex)
	{
		PoliceRecord rec = GetRecord(uid);
		if (!rec)
			return false;
		if (sentenceIndex < 0 || sentenceIndex >= rec.m_Sentences.Count())
			return false;
		rec.m_Sentences.Remove(sentenceIndex);
		SaveToDisk();
		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== MANDATS (WarrantRecord) =====
	//------------------------------------------------------------------------------------------------
	
	// Ajoute un mandat. durationDays = 0 = pas d expiration.
	int AddWarrant(string uid, EWarrantType type, string motive, int durationDays,
		string issuerName, string issuerUID)
	{
		if (uid == "")
			return -1;
		PoliceRecord rec = GetRecord(uid);
		if (!rec)
			return -1;
		
		WarrantRecord w = new WarrantRecord();
		w.m_Type = type;
		w.m_Motive = motive;
		w.m_IssuedTimestamp = System.GetUnixTime();
		if (durationDays > 0)
			w.m_ExpiresTimestamp = w.m_IssuedTimestamp + (durationDays * 86400);
		else
			w.m_ExpiresTimestamp = 0;
		w.m_Active = true;
		w.m_IssuerName = issuerName;
		w.m_IssuerUID = issuerUID;
		rec.m_Warrants.Insert(w);
		SaveToDisk();
		return rec.m_Warrants.Count() - 1;
	}
	
	// Marque un mandat comme execute/annule
	bool MarkWarrantExecuted(string uid, int warrantIndex)
	{
		PoliceRecord rec = GetRecord(uid);
		if (!rec)
			return false;
		if (warrantIndex < 0 || warrantIndex >= rec.m_Warrants.Count())
			return false;
		WarrantRecord w = rec.m_Warrants.Get(warrantIndex);
		if (!w)
			return false;
		w.m_Active = false;
		SaveToDisk();
		return true;
	}
	
	bool RemoveWarrant(string uid, int warrantIndex)
	{
		PoliceRecord rec = GetRecord(uid);
		if (!rec)
			return false;
		if (warrantIndex < 0 || warrantIndex >= rec.m_Warrants.Count())
			return false;
		rec.m_Warrants.Remove(warrantIndex);
		SaveToDisk();
		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== NOTES OFFICIERS =====
	//------------------------------------------------------------------------------------------------
	
	int AddNote(string uid, string text, string authorName, string authorUID)
	{
		if (uid == "" || text == "")
			return -1;
		PoliceRecord rec = GetRecord(uid);
		if (!rec)
			return -1;
		
		OfficerNote n = new OfficerNote();
		n.m_Text = text;
		n.m_Timestamp = System.GetUnixTime();
		n.m_AuthorName = authorName;
		n.m_AuthorUID = authorUID;
		rec.m_Notes.Insert(n);
		SaveToDisk();
		return rec.m_Notes.Count() - 1;
	}
	
	bool RemoveNote(string uid, int noteIndex)
	{
		PoliceRecord rec = GetRecord(uid);
		if (!rec)
			return false;
		if (noteIndex < 0 || noteIndex >= rec.m_Notes.Count())
			return false;
		rec.m_Notes.Remove(noteIndex);
		SaveToDisk();
		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== REHABILITATION =====
	// La date de rehabilitation = derniere condamnation + REHAB_YEARS.
	// 0 = jamais eu de condamnation (donc pas de rehab necessaire).
	//------------------------------------------------------------------------------------------------
	
	int GetRehabTimestamp(string uid)
	{
		PoliceRecord rec = GetRecord(uid);
		if (!rec)
			return 0;
		if (rec.m_LastConvictionTimestamp <= 0)
			return 0;
		return rec.m_LastConvictionTimestamp + (REHAB_YEARS * SECONDS_PER_YEAR);
	}
	
	// True si la date de rehab est passee (peut potentiellement effacer le casier)
	bool IsRehabEligible(string uid, int now)
	{
		int rehab = GetRehabTimestamp(uid);
		if (rehab == 0)
			return false;
		return now >= rehab;
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== PERSISTANCE JSON =====
	//------------------------------------------------------------------------------------------------
	
	void SaveToDisk()
	{
		if (!m_Records)
		{
			Print("[JobPoliceRecordManager] SaveToDisk : m_Records null, annule",
				LogLevel.WARNING);
			return;
		}
		SCR_JsonSaveContext ctx = new SCR_JsonSaveContext();
		int count = m_Records.Count();
		ctx.WriteValue("record_count", count);
		
		for (int i = 0; i < count; i++)
		{
			PoliceRecord rec = m_Records.GetElement(i);
			if (!rec)
				continue;
			
			string rp = "rec_" + i.ToString() + "_";
			ctx.WriteValue(rp + "uid", rec.m_PlayerUID);
			ctx.WriteValue(rp + "name", rec.m_PlayerName);
			ctx.WriteValue(rp + "status", rec.m_Status);
			ctx.WriteValue(rp + "status_detail", rec.m_StatusDetail);
			ctx.WriteValue(rp + "last_conviction", rec.m_LastConvictionTimestamp);
			
			// Peines
			int sCount = rec.m_Sentences.Count();
			ctx.WriteValue(rp + "sentence_count", sCount);
			for (int j = 0; j < sCount; j++)
			{
				SentenceRecord s = rec.m_Sentences.Get(j);
				if (!s) continue;
				string sp = rp + "s_" + j.ToString() + "_";
				ctx.WriteValue(sp + "charge", s.m_Charge);
				ctx.WriteValue(sp + "issued", s.m_IssuedTimestamp);
				ctx.WriteValue(sp + "duration", s.m_DurationDays);
				ctx.WriteValue(sp + "active", s.m_Active);
				ctx.WriteValue(sp + "issuer_name", s.m_IssuerName);
				ctx.WriteValue(sp + "issuer_uid", s.m_IssuerUID);
			}
			
			// Mandats
			int wCount = rec.m_Warrants.Count();
			ctx.WriteValue(rp + "warrant_count", wCount);
			for (int j = 0; j < wCount; j++)
			{
				WarrantRecord w = rec.m_Warrants.Get(j);
				if (!w) continue;
				string wp = rp + "w_" + j.ToString() + "_";
				ctx.WriteValue(wp + "type", w.m_Type);
				ctx.WriteValue(wp + "motive", w.m_Motive);
				ctx.WriteValue(wp + "issued", w.m_IssuedTimestamp);
				ctx.WriteValue(wp + "expires", w.m_ExpiresTimestamp);
				ctx.WriteValue(wp + "active", w.m_Active);
				ctx.WriteValue(wp + "issuer_name", w.m_IssuerName);
				ctx.WriteValue(wp + "issuer_uid", w.m_IssuerUID);
			}
			
			// Notes
			int nCount = rec.m_Notes.Count();
			ctx.WriteValue(rp + "note_count", nCount);
			for (int j = 0; j < nCount; j++)
			{
				OfficerNote n = rec.m_Notes.Get(j);
				if (!n) continue;
				string np = rp + "n_" + j.ToString() + "_";
				ctx.WriteValue(np + "text", n.m_Text);
				ctx.WriteValue(np + "timestamp", n.m_Timestamp);
				ctx.WriteValue(np + "author_name", n.m_AuthorName);
				ctx.WriteValue(np + "author_uid", n.m_AuthorUID);
			}
		}
		
		ctx.SaveToFile(SAVE_PATH);
	}
	
	void LoadFromDisk()
	{
		SCR_JsonLoadContext ctx = new SCR_JsonLoadContext();
		if (!ctx.LoadFromFile(SAVE_PATH))
		{
			Print("[JobPoliceRecordManager] Aucun fichier existant, demarrage propre",
				LogLevel.NORMAL);
			return;
		}
		
		int count = 0;
		ctx.ReadValue("record_count", count);
		
		for (int i = 0; i < count; i++)
		{
			PoliceRecord rec = new PoliceRecord();
			string rp = "rec_" + i.ToString() + "_";
			ctx.ReadValue(rp + "uid", rec.m_PlayerUID);
			ctx.ReadValue(rp + "name", rec.m_PlayerName);
			int statusVal = 0;
			ctx.ReadValue(rp + "status", statusVal);
			rec.m_Status = statusVal;
			ctx.ReadValue(rp + "status_detail", rec.m_StatusDetail);
			ctx.ReadValue(rp + "last_conviction", rec.m_LastConvictionTimestamp);
			
			// Peines
			int sCount = 0;
			ctx.ReadValue(rp + "sentence_count", sCount);
			for (int j = 0; j < sCount; j++)
			{
				SentenceRecord s = new SentenceRecord();
				string sp = rp + "s_" + j.ToString() + "_";
				ctx.ReadValue(sp + "charge", s.m_Charge);
				ctx.ReadValue(sp + "issued", s.m_IssuedTimestamp);
				ctx.ReadValue(sp + "duration", s.m_DurationDays);
				ctx.ReadValue(sp + "active", s.m_Active);
				ctx.ReadValue(sp + "issuer_name", s.m_IssuerName);
				ctx.ReadValue(sp + "issuer_uid", s.m_IssuerUID);
				rec.m_Sentences.Insert(s);
			}
			
			// Mandats
			int wCount = 0;
			ctx.ReadValue(rp + "warrant_count", wCount);
			for (int j = 0; j < wCount; j++)
			{
				WarrantRecord w = new WarrantRecord();
				string wp = rp + "w_" + j.ToString() + "_";
				int typeVal = 0;
				ctx.ReadValue(wp + "type", typeVal);
				w.m_Type = typeVal;
				ctx.ReadValue(wp + "motive", w.m_Motive);
				ctx.ReadValue(wp + "issued", w.m_IssuedTimestamp);
				ctx.ReadValue(wp + "expires", w.m_ExpiresTimestamp);
				ctx.ReadValue(wp + "active", w.m_Active);
				ctx.ReadValue(wp + "issuer_name", w.m_IssuerName);
				ctx.ReadValue(wp + "issuer_uid", w.m_IssuerUID);
				rec.m_Warrants.Insert(w);
			}
			
			// Notes
			int nCount = 0;
			ctx.ReadValue(rp + "note_count", nCount);
			for (int j = 0; j < nCount; j++)
			{
				OfficerNote n = new OfficerNote();
				string np = rp + "n_" + j.ToString() + "_";
				ctx.ReadValue(np + "text", n.m_Text);
				ctx.ReadValue(np + "timestamp", n.m_Timestamp);
				ctx.ReadValue(np + "author_name", n.m_AuthorName);
				ctx.ReadValue(np + "author_uid", n.m_AuthorUID);
				rec.m_Notes.Insert(n);
			}
			
			if (rec.m_PlayerUID != "")
				m_Records.Set(rec.m_PlayerUID, rec);
		}
		
		Print(string.Format("[JobPoliceRecordManager] Charge %1 dossiers judiciaires",
			m_Records.Count()), LogLevel.NORMAL);
	}
}
