//------------------------------------------------------------------------------------------------
// JobWhitelistHandler.c
// Hook sur le GameMode pour intercepter les connexions de joueurs et verifier
// la whitelist.
//
// NOUVEAU COMPORTEMENT (prison au lieu de kick) :
//   Si le joueur n est pas autorise :
//     1. Teleporte le joueur dans la "prison" (1 des 5 coords aleatoires)
//     2. Ouvre le menu overlay (message 60s puis se ferme tout seul)
//     3. Lance un tick de surveillance :
//        - Si joueur depasse 100m du point d ancrage -> teleport back + hint HUD
//        - Si joueur est maintenant whitelist (via admin in-game ou reload JSON)
//          -> libere + ouvre le menu "Bienvenue" (JobWhitelistLoadingMenu)
//
// Pattern : modded class SCR_BaseGameMode + override OnPlayerConnected
//------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------------------
// Entree de prison : coordonnee d ancrage + timestamp d entree
//------------------------------------------------------------------------------------------------
class JobPrisonEntry
{
	vector m_Anchor;
	int m_EnterTime; // unix time, pour debug
}

modded class SCR_BaseGameMode
{
	// Les 5 coordonnees de prison (choisies aleatoirement)
	static const vector PRISON_COORD_0 = "3394.562 24.542 4651.505";
	static const vector PRISON_COORD_1 = "3402.148 24.57 4669.559";
	static const vector PRISON_COORD_2 = "3412.73 24.646 4667.053";
	static const vector PRISON_COORD_3 = "3430.841 24.683 4657.229";
	static const vector PRISON_COORD_4 = "3423.159 24.727 4647.323";

	// Rayon max autorise autour du point d ancrage (metres)
	const float PRISON_RADIUS = 150.0;

	// Frequence de check de position + verif whitelist (ms)
	const int PRISON_WATCH_TICK_MS = 1000;

	// Map des joueurs actuellement en prison : playerId -> JobPrisonEntry
	ref map<int, ref JobPrisonEntry> m_PrisonAnchors = new map<int, ref JobPrisonEntry>();

	// True si le tick global est actif
	bool m_PrisonWatchActive = false;

	//------------------------------------------------------------------------------------------------
	override void OnPlayerConnected(int playerId)
	{
		super.OnPlayerConnected(playerId);

		// Cote serveur uniquement
		if (!Replication.IsServer())
			return;

		// Verifie la whitelist apres un court delai pour laisser le temps a Bohemia
		// de fournir l identite du joueur (l UID n est pas toujours dispo immediatement)
		GetGame().GetCallqueue().CallLater(CheckWhitelistForPlayer, 1000, false, playerId);
	}

	//------------------------------------------------------------------------------------------------
	void CheckWhitelistForPlayer(int playerId)
	{
		if (!Replication.IsServer())
			return;

		PlayerManager pm = GetGame().GetPlayerManager();
		if (!pm)
			return;

		// Recupere l UID Bohemia persistant
		string uid = "";
		PlayerController pc = pm.GetPlayerController(playerId);
		if (pc)
		{
			uid = JobManager.GetInstance().GetPersistentUID(playerId);
		}

		// Si on n a pas reussi a recuperer l UID, on retente dans 2 secondes
		if (uid == "")
		{
			Print(string.Format("[JobWhitelist] UID introuvable pour player=%1, retry...",
				playerId.ToString()), LogLevel.WARNING);
			GetGame().GetCallqueue().CallLater(CheckWhitelistForPlayer, 2000, false, playerId);
			return;
		}

		bool allowed = JobWhitelistManager.GetInstance().IsAllowed(uid);
		if (allowed)
		{
			Print(string.Format("[JobWhitelist] OK : player=%1 uid=%2", playerId.ToString(), uid),
				LogLevel.NORMAL);

			// Envoie au client l ordre d ouvrir le layout "Whitelist validee - Chargement ..."
			ShowLoadingMenuOnClient(playerId);
			return;
		}

		// NON AUTORISE : teleport en prison + message 60s
		Print(string.Format("[JobWhitelist] REFUS : player=%1 uid=%2 (teleport prison)",
			playerId.ToString(), uid), LogLevel.WARNING);

		TeleportPlayerToPrison(playerId);
	}

	//------------------------------------------------------------------------------------------------
	// Teleporte un joueur a une position (pattern valide en prod, meme que JobCriminalManager).
	// SetOrigin cote serveur seul ne REPLIQUE PAS sur le client du joueur controle. Il faut
	// passer par CapsulePlayerComponent.Svr_TeleportToPosition qui fait : SetOrigin serveur
	// + RPC vers client owner pour SetOrigin local + correction hauteur.
	//------------------------------------------------------------------------------------------------
	void TeleportPlayerEntity(PlayerController pc, IEntity playerEnt, vector pos)
	{
		if (!pc || !playerEnt)
			return;

		CapsulePlayerComponent caps = CapsulePlayerComponent.Cast(pc.FindComponent(CapsulePlayerComponent));
		if (caps)
		{
			caps.Svr_TeleportToPosition(pos[0], pos[1], pos[2]);
			return;
		}

		// Fallback (ne replique pas forcement mais mieux que rien)
		playerEnt.SetOrigin(pos);
		playerEnt.Update();
	}

	//------------------------------------------------------------------------------------------------
	// Choisit une coordonnee de prison aleatoire parmi les 5
	//------------------------------------------------------------------------------------------------
	vector PickRandomPrisonCoord()
	{
		int idx = Math.RandomInt(0, 5);
		switch (idx)
		{
			case 0: return PRISON_COORD_0;
			case 1: return PRISON_COORD_1;
			case 2: return PRISON_COORD_2;
			case 3: return PRISON_COORD_3;
			case 4: return PRISON_COORD_4;
		}
		return PRISON_COORD_0;
	}

	//------------------------------------------------------------------------------------------------
	// Teleporte le joueur a un point de prison aleatoire + ouvre le menu message
	// Si l entite du joueur n est pas encore prete, retry dans 1s
	//------------------------------------------------------------------------------------------------
	void TeleportPlayerToPrison(int playerId)
	{
		if (!Replication.IsServer())
			return;

		PlayerManager pm = GetGame().GetPlayerManager();
		if (!pm)
			return;
		PlayerController pc = pm.GetPlayerController(playerId);
		if (!pc)
			return;

		IEntity playerEnt = pc.GetControlledEntity();
		if (!playerEnt)
		{
			// Entite pas encore prete, retry
			GetGame().GetCallqueue().CallLater(TeleportPlayerToPrison, 1000, false, playerId);
			return;
		}

		// Choix aleatoire d un des 5 points
		vector target = PickRandomPrisonCoord();
		TeleportPlayerEntity(pc, playerEnt, target);

		// Enregistre dans la map
		JobPrisonEntry pe = new JobPrisonEntry();
		pe.m_Anchor = target;
		pe.m_EnterTime = System.GetUnixTime();
		m_PrisonAnchors.Set(playerId, pe);

		// Ouvre le menu message 60s cote client
		ShowWhitelistMenuOnClient(playerId);

		// Demarre le tick global si pas deja actif
		if (!m_PrisonWatchActive)
		{
			m_PrisonWatchActive = true;
			GetGame().GetCallqueue().CallLater(TickPrisonWatch, PRISON_WATCH_TICK_MS, true);
			Print("[JobWhitelist] Tick de surveillance prison demarre", LogLevel.NORMAL);
		}

		Print(string.Format("[JobWhitelist] Player=%1 teleporte en prison a %2",
			playerId.ToString(), target.ToString()), LogLevel.NORMAL);
	}

	//------------------------------------------------------------------------------------------------
	// Tick global : parcourt les joueurs en prison, verifie whitelist + distance au point ancre
	//------------------------------------------------------------------------------------------------
	void TickPrisonWatch()
	{
		if (!Replication.IsServer())
			return;

		int count = m_PrisonAnchors.Count();
		if (count == 0)
		{
			// Plus personne en prison : arrete le tick
			GetGame().GetCallqueue().Remove(TickPrisonWatch);
			m_PrisonWatchActive = false;
			Print("[JobWhitelist] Tick de surveillance prison arrete (plus personne)", LogLevel.NORMAL);
			return;
		}

		PlayerManager pm = GetGame().GetPlayerManager();
		if (!pm)
			return;

		// Collecte les joueurs a liberer (deconnectes ou maintenant whitelist)
		array<int> toRelease = new array<int>();

		for (int i = 0; i < count; i++)
		{
			int playerId = m_PrisonAnchors.GetKey(i);
			JobPrisonEntry pe = m_PrisonAnchors.GetElement(i);
			if (!pe)
			{
				toRelease.Insert(playerId);
				continue;
			}

			PlayerController pc = pm.GetPlayerController(playerId);
			if (!pc)
			{
				// Joueur deconnecte
				toRelease.Insert(playerId);
				continue;
			}

			// Verifie si le joueur est maintenant whitelist (admin a ajoute son UID entre-temps)
			string uid = JobManager.GetInstance().GetPersistentUID(playerId);
			if (uid != "" && JobWhitelistManager.GetInstance().IsAllowed(uid))
			{
				// Libere : ouvre le menu "Bienvenue" (JobWhitelistLoadingMenu) 5s
				Print(string.Format("[JobWhitelist] Player=%1 maintenant whitelist, liberation",
					playerId.ToString()), LogLevel.NORMAL);
				ShowLoadingMenuOnClient(playerId);
				toRelease.Insert(playerId);
				continue;
			}

			// Verifie la distance au point d ancrage
			IEntity playerEnt = pc.GetControlledEntity();
			if (!playerEnt)
				continue; // retry prochain tick

			vector curPos = playerEnt.GetOrigin();
			float dist = vector.Distance(curPos, pe.m_Anchor);
			if (dist > PRISON_RADIUS)
			{
				// Hors zone : teleport back + hint HUD
				TeleportPlayerEntity(pc, playerEnt, pe.m_Anchor);
				JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
				if (jpc)
					jpc.ServerShowHint("Vous ne pouvez pas sortir de la prison tant que vous n etes pas whitelist.");
			}
		}

		// Libere les joueurs collectes
		foreach (int pid : toRelease)
			m_PrisonAnchors.Remove(pid);
	}

	//------------------------------------------------------------------------------------------------
	// Envoie l ordre au client d ouvrir le menu whitelist (message prison 60s)
	//------------------------------------------------------------------------------------------------
	void ShowWhitelistMenuOnClient(int playerId)
	{
		PlayerManager pm = GetGame().GetPlayerManager();
		if (!pm) return;
		PlayerController pc = pm.GetPlayerController(playerId);
		if (!pc) return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		jpc.ServerSendOpenWhitelistMenu();
	}

	//------------------------------------------------------------------------------------------------
	// Envoie l ordre au client d ouvrir le menu "Whitelist validee - Chargement..."
	//------------------------------------------------------------------------------------------------
	void ShowLoadingMenuOnClient(int playerId)
	{
		PlayerManager pm = GetGame().GetPlayerManager();
		if (!pm) return;
		PlayerController pc = pm.GetPlayerController(playerId);
		if (!pc) return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		jpc.ServerSendOpenWhitelistLoadingMenu();
	}

	//------------------------------------------------------------------------------------------------
	// Nettoyage si le joueur se deconnecte
	//------------------------------------------------------------------------------------------------
	override void OnPlayerDisconnected(int playerId, KickCauseCode cause, int timeout)
	{
		super.OnPlayerDisconnected(playerId, cause, timeout);
		if (m_PrisonAnchors.Contains(playerId))
			m_PrisonAnchors.Remove(playerId);
	}
}
