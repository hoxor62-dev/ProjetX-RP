//------------------------------------------------------------------------------------------------
// JobRobAtmAction.c
// Action F sur un ATM "Braquer le distributeur".
// Visible uniquement pour le metier VOYOU.
//
// Le serveur fait toutes les verifications (cooldown, distance, deconnexion, etc.)
//------------------------------------------------------------------------------------------------

class JobRobAtmAction : ScriptedUserAction
{
	//------------------------------------------------------------------------------------------------
	override bool CanBeShownScript(IEntity user)
	{
		// IMPORTANT : CanBeShownScript est evalue COTE CLIENT.
		// JobManager.GetPlayerData() retourne null cote client (cache vide cote client).
		// On ne peut donc pas verifier le metier ici de facon fiable.
		//
		// Solution : on affiche toujours l action, et le serveur fait le check de metier
		// dans RpcAsk_StartRobbery. Si un joueur non-voyou essaie, il recoit
		// le message "[BRAQUAGE] Reserve aux voyous" en chat.
		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	override bool CanBePerformedScript(IEntity user)
	{
		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	override bool GetActionNameScript(out string outName)
	{
		outName = "Braquer le distributeur";
		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
	{
		if (!pOwnerEntity || !pUserEntity)
			return;
		
		PlayerController localPC = GetGame().GetPlayerController();
		if (!localPC)
			return;
		IEntity localEntity = localPC.GetControlledEntity();
		if (localEntity != pUserEntity)
			return;
		
		// Recupere le RplId de l ATM
		RplComponent rpl = RplComponent.Cast(pOwnerEntity.FindComponent(RplComponent));
		if (!rpl)
			return;
		
		JobPlayerComponent jpc = JobPlayerComponent.Cast(localPC.FindComponent(JobPlayerComponent));
		if (!jpc)
			return;
		jpc.ClientAskStartRobbery(rpl.Id());
	}
}
