//------------------------------------------------------------------------------------------------
// JobRpFicheMenu.c
// Fiche RP du joueur refondue avec sidebar + pages switchables (meme style que l admin panel).
//
// Pages :
//   0 - Mon personnage : identite + etat + metier + gang + autres + stats
//   1 - Mon garage virtuel : liste des vehicules du joueur avec etat (fuel/degats/items)
//   2 - Mes finances : argent sur soi + banque + fines impayees
//   3 - Mon casier judiciaire : prison + mentions avec commentaires
//   4 - Mes residences : liste des portes achetees avec lieu/prix/code
//   5 - Dossier medical partage : hospitalisations + soins + allergies etc.
//   6 - Preferences HUD : toggle carte joueur
//
// Hors sidebar : bouton Panneau Admin (visible si admin), bouton Fermer.
// Mode admin viewing : si s_PendingAdminFicheData est set, affiche cette fiche dans
// la page Mon personnage et desactive les boutons gang / toggle / admin / autres pages.
//------------------------------------------------------------------------------------------------

class JobRpFicheMenu : ChimeraMenuBase
{
	const string ROW_LAYOUT_PATH = "{4C675B899ADF8C84}UI/layouts/JobAdminRowEntry.layout";

	// === WIDGETS COMMUNS ===
	Widget m_RootWidget;
	TextWidget m_PageTitle;
	TextWidget m_PageSubtitle;
	TextWidget m_SidebarRpName;
	ButtonWidget m_BtnClose;

	// === NAVIGATION ===
	ButtonWidget m_NavPersonnage;
	ButtonWidget m_NavGarage;
	ButtonWidget m_NavFinances;
	ButtonWidget m_NavCasier;
	ButtonWidget m_NavResidences;
	ButtonWidget m_NavMedical;
	ButtonWidget m_NavPrefs;
	ButtonWidget m_BtnAdmin;

	// === PAGES ===
	Widget m_PagePersonnage;
	Widget m_PageGarage;
	Widget m_PageFinances;
	Widget m_PageCasier;
	Widget m_PageResidences;
	Widget m_PageMedical;
	Widget m_PagePrefs;

	// === PAGE GARAGE PREVIEW ===
	ItemPreviewWidget m_GaragePreviewWidget;
	TextWidget m_GarageSelectedTitle;
	TextWidget m_GarageSelectedInfo;
	ItemPreviewManagerEntity m_PreviewManagerCache;

	// === PAGES RESIDENCES / MEDICAL (avec pagination 9 entrees par page) ===
	const int ENTRIES_PER_PAGE = 9;
	TextWidget m_ResidencesText;
	TextWidget m_MedicalText;
	TextWidget m_ResidencesPageLabel;
	TextWidget m_MedicalPageLabel;
	ButtonWidget m_BtnResidencesPrev;
	ButtonWidget m_BtnResidencesNext;
	ButtonWidget m_BtnMedicalPrev;
	ButtonWidget m_BtnMedicalNext;
	string m_ResidencesHeader = "";
	ref array<string> m_ResidencesEntries = new array<string>();
	int m_ResidencesPage = 0;
	string m_MedicalHeader = "";
	ref array<string> m_MedicalEntries = new array<string>();
	int m_MedicalPage = 0;

	// === PAGE PERSONNAGE ===
	TextWidget m_InfoText; // conserve pour compat admin viewing (fallback), peut etre null
	Widget m_InfoCardsContainer;
	ItemPreviewWidget m_CharacterPreviewWidget;
	TextWidget m_CharacterSubtitle;
	ButtonWidget m_BtnLeaveGang;
	ButtonWidget m_BtnDissolveGang;

	// === CARTES SECTIONS (page personnage) ===
	Widget m_CardIdentite; TextWidget m_CardIdentiteBody;
	Widget m_CardEtat; TextWidget m_CardEtatBody;
	Widget m_CardJob; TextWidget m_CardJobBody;
	Widget m_CardGang; TextWidget m_CardGangBody;
	Widget m_CardPermis; TextWidget m_CardPermisBody;
	Widget m_CardAutres; TextWidget m_CardAutresBody;
	Widget m_CardStats; TextWidget m_CardStatsBody;

	// === PAGE GARAGE ===
	Widget m_GarageContainer;
	TextWidget m_GarageStatusText;

	// === PAGE FINANCES / CASIER ===
	TextWidget m_FinancesText;
	TextWidget m_CasierText;

	// === PAGE PREFS ===
	ButtonWidget m_BtnTogglePlayerCard;
	TextWidget m_BtnTogglePlayerCardLabel;

	// === POPUP CONFIRMATION ===
	Widget m_ConfirmOverlay;
	TextWidget m_ConfirmText;
	ButtonWidget m_BtnConfirmYes;
	ButtonWidget m_BtnConfirmNo;
	string m_PendingConfirmAction = "";

	// === ETAT ===
	static JobRpFicheMenu s_Instance;
	int m_CurrentPage = 0;
	bool m_IsAdminViewing = false;

	// Donnees pre-recues
	static string s_PendingAdminFicheData = "";
	static string s_FicheRaw = ""; // dernier texte fiche recu du serveur, utilise pour parser

	// Donnees garage (recues via nouvelle RPC)
	static ref array<string> s_GarageModels = new array<string>();      // nom court affichage
	static ref array<string> s_GaragePrefabs = new array<string>();     // chemin complet pour preview 3D
	static ref array<int> s_GarageFuels = new array<int>();
	static ref array<int> s_GarageDamagedParts = new array<int>();
	static ref array<int> s_GarageItemsCount = new array<int>();
	static ref array<int> s_GarageInsured = new array<int>();

	//------------------------------------------------------------------------------------------------
	static void SetPendingAdminFicheData(string data) { s_PendingAdminFicheData = data; }

	//------------------------------------------------------------------------------------------------
	override void OnMenuOpen()
	{
		super.OnMenuOpen();
		s_Instance = this;
		JobFocusHandler.ClearRegistry();

		m_RootWidget = GetRootWidget();
		if (!m_RootWidget) return;

		// Communs
		m_PageTitle = TextWidget.Cast(m_RootWidget.FindAnyWidget("PageTitleText"));
		m_PageSubtitle = TextWidget.Cast(m_RootWidget.FindAnyWidget("PageSubtitleText"));
		m_SidebarRpName = TextWidget.Cast(m_RootWidget.FindAnyWidget("SidebarRpName"));
		m_BtnClose = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnClose"));

		// Nav
		m_NavPersonnage = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("NavPersonnage"));
		m_NavGarage = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("NavGarage"));
		m_NavFinances = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("NavFinances"));
		m_NavCasier = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("NavCasier"));
		m_NavResidences = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("NavResidences"));
		m_NavMedical = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("NavMedical"));
		m_NavPrefs = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("NavPrefs"));
		m_BtnAdmin = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnAdmin"));

		// Pages
		m_PagePersonnage = m_RootWidget.FindAnyWidget("PagePersonnage");
		m_PageGarage = m_RootWidget.FindAnyWidget("PageGarage");
		m_PageFinances = m_RootWidget.FindAnyWidget("PageFinances");
		m_PageCasier = m_RootWidget.FindAnyWidget("PageCasier");
		m_PageResidences = m_RootWidget.FindAnyWidget("PageResidences");
		m_PageMedical = m_RootWidget.FindAnyWidget("PageMedical");
		m_PagePrefs = m_RootWidget.FindAnyWidget("PagePrefs");

		// Preview garage
		m_GaragePreviewWidget = ItemPreviewWidget.Cast(m_RootWidget.FindAnyWidget("GaragePreviewWidget"));
		m_GarageSelectedTitle = TextWidget.Cast(m_RootWidget.FindAnyWidget("GarageSelectedTitle"));
		m_GarageSelectedInfo = TextWidget.Cast(m_RootWidget.FindAnyWidget("GarageSelectedInfo"));

		// Pages Residences / Medical + leur pagination
		m_ResidencesText = TextWidget.Cast(m_RootWidget.FindAnyWidget("ResidencesText"));
		m_MedicalText = TextWidget.Cast(m_RootWidget.FindAnyWidget("MedicalText"));
		m_ResidencesPageLabel = TextWidget.Cast(m_RootWidget.FindAnyWidget("ResidencesPageLabel"));
		m_MedicalPageLabel = TextWidget.Cast(m_RootWidget.FindAnyWidget("MedicalPageLabel"));
		m_BtnResidencesPrev = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnResidencesPrev"));
		m_BtnResidencesNext = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnResidencesNext"));
		m_BtnMedicalPrev = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnMedicalPrev"));
		m_BtnMedicalNext = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnMedicalNext"));

		// Personnage
		m_InfoText = TextWidget.Cast(m_RootWidget.FindAnyWidget("InfoText"));
		m_InfoCardsContainer = m_RootWidget.FindAnyWidget("InfoCardsContainer");
		m_CharacterPreviewWidget = ItemPreviewWidget.Cast(m_RootWidget.FindAnyWidget("CharacterPreviewWidget"));
		m_CharacterSubtitle = TextWidget.Cast(m_RootWidget.FindAnyWidget("CharacterSubtitle"));
		m_BtnLeaveGang = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnLeaveGang"));
		m_BtnDissolveGang = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnDissolveGang"));

		// Cartes sections
		m_CardIdentite = m_RootWidget.FindAnyWidget("CardIdentite");
		m_CardIdentiteBody = TextWidget.Cast(m_RootWidget.FindAnyWidget("CardIdentiteBody"));
		m_CardEtat = m_RootWidget.FindAnyWidget("CardEtat");
		m_CardEtatBody = TextWidget.Cast(m_RootWidget.FindAnyWidget("CardEtatBody"));
		m_CardJob = m_RootWidget.FindAnyWidget("CardJob");
		m_CardJobBody = TextWidget.Cast(m_RootWidget.FindAnyWidget("CardJobBody"));
		m_CardGang = m_RootWidget.FindAnyWidget("CardGang");
		m_CardGangBody = TextWidget.Cast(m_RootWidget.FindAnyWidget("CardGangBody"));
		m_CardPermis = m_RootWidget.FindAnyWidget("CardPermis");
		m_CardPermisBody = TextWidget.Cast(m_RootWidget.FindAnyWidget("CardPermisBody"));
		m_CardAutres = m_RootWidget.FindAnyWidget("CardAutres");
		m_CardAutresBody = TextWidget.Cast(m_RootWidget.FindAnyWidget("CardAutresBody"));
		m_CardStats = m_RootWidget.FindAnyWidget("CardStats");
		m_CardStatsBody = TextWidget.Cast(m_RootWidget.FindAnyWidget("CardStatsBody"));
		HideAllCards();

		// Garage
		m_GarageContainer = m_RootWidget.FindAnyWidget("GarageContainer");
		m_GarageStatusText = TextWidget.Cast(m_RootWidget.FindAnyWidget("GarageStatusText"));

		// Finances / casier
		m_FinancesText = TextWidget.Cast(m_RootWidget.FindAnyWidget("FinancesText"));
		m_CasierText = TextWidget.Cast(m_RootWidget.FindAnyWidget("CasierText"));

		// Prefs
		m_BtnTogglePlayerCard = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnTogglePlayerCard"));
		m_BtnTogglePlayerCardLabel = TextWidget.Cast(m_RootWidget.FindAnyWidget("BtnTogglePlayerCardText"));

		// Popup
		m_ConfirmOverlay = m_RootWidget.FindAnyWidget("ConfirmOverlay");
		m_ConfirmText = TextWidget.Cast(m_RootWidget.FindAnyWidget("ConfirmText"));
		m_BtnConfirmYes = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnConfirmYes"));
		m_BtnConfirmNo = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnConfirmNo"));
		if (m_ConfirmOverlay) m_ConfirmOverlay.SetVisible(false);

		// Bind nav
		AttachNav(m_NavPersonnage, 0);
		AttachNav(m_NavGarage, 1);
		AttachNav(m_NavFinances, 2);
		AttachNav(m_NavCasier, 3);
		AttachNav(m_NavResidences, 4);
		AttachNav(m_NavMedical, 5);
		AttachNav(m_NavPrefs, 6);

		// Bind actions
		AttachAction(m_BtnClose, "close");
		AttachAction(m_BtnLeaveGang, "leave_gang");
		AttachAction(m_BtnDissolveGang, "dissolve_gang");
		AttachAction(m_BtnAdmin, "open_admin");
		AttachAction(m_BtnTogglePlayerCard, "toggle_player_card");
		AttachAction(m_BtnConfirmYes, "confirm_yes");
		AttachAction(m_BtnConfirmNo, "confirm_no");
		AttachAction(m_BtnResidencesPrev, "res_prev");
		AttachAction(m_BtnResidencesNext, "res_next");
		AttachAction(m_BtnMedicalPrev, "med_prev");
		AttachAction(m_BtnMedicalNext, "med_next");

		// Masque les boutons gang par defaut (RefreshGangButtons les reaffichera selon statut)
		if (m_BtnLeaveGang) m_BtnLeaveGang.SetVisible(false);
		if (m_BtnDissolveGang) m_BtnDissolveGang.SetVisible(false);

		// Mode admin viewing : affiche directement les donnees fournies, desactive nav + boutons
		if (s_PendingAdminFicheData != "")
		{
			m_IsAdminViewing = true;
			s_FicheRaw = s_PendingAdminFicheData;
			if (m_InfoText) m_InfoText.SetText(s_PendingAdminFicheData);
			if (m_SidebarRpName) m_SidebarRpName.SetText("Mode admin");
			s_PendingAdminFicheData = "";
			// Cache les autres pages de nav (uniquement personnage visible)
			if (m_NavGarage) m_NavGarage.SetVisible(false);
			if (m_NavFinances) m_NavFinances.SetVisible(false);
			if (m_NavCasier) m_NavCasier.SetVisible(false);
			if (m_NavResidences) m_NavResidences.SetVisible(false);
			if (m_NavMedical) m_NavMedical.SetVisible(false);
			if (m_NavPrefs) m_NavPrefs.SetVisible(false);
			if (m_BtnAdmin) m_BtnAdmin.SetVisible(false);
			if (m_BtnTogglePlayerCard) m_BtnTogglePlayerCard.SetVisible(false);
			ParseGangStatusAndShowButtons(false);
			// Construit les cartes directement depuis les donnees admin
			BuildPersonnageCards(s_FicheRaw);
			DistributeFicheToPages();
		}
		else
		{
			m_IsAdminViewing = false;
			if (m_InfoText) m_InfoText.SetText("Chargement de votre fiche...");
			if (m_SidebarRpName) m_SidebarRpName.SetText("Chargement...");
			if (m_CharacterSubtitle) m_CharacterSubtitle.SetText("Chargement...");

			PlayerController pc = GetGame().GetPlayerController();
			if (pc)
			{
				JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
				if (jpc) jpc.ClientAskFicheData();
			}

			// Bouton Admin selon statut
			if (m_BtnAdmin)
			{
				bool isAdmin = false;
				if (pc)
				{
					JobPlayerComponent jpc2 = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
					if (jpc2) isAdmin = jpc2.IsClientAdmin();
				}
				m_BtnAdmin.SetVisible(isAdmin);
			}
			RefreshTogglePlayerCardLabel();
		}

		SwitchToPage(0);

		// Preview 3D du personnage : utilise le prefab du character controle par le joueur
		LoadCharacterPreview();

		// Focus initial = premier bouton de la sidebar (ou le prochain visible si cache en admin viewing).
		// Permet aux joueurs manette de descendre la sidebar avec DPad bas puis d aller a droite
		// vers le contenu / le bouton Fermer. Si on mettait le focus sur BtnClose comme avant,
		// la nav manette ne retrouvait pas la sidebar car trop eloignee spatialement.
		Widget initialFocus = FindFirstVisibleSidebarButton();
		if (!initialFocus) initialFocus = m_BtnClose;
		if (initialFocus)
			GetGame().GetWorkspace().SetFocusedWidget(initialFocus);
	}

	//------------------------------------------------------------------------------------------------
	// Trouve le premier bouton de nav sidebar visible dans l ordre d affichage.
	// En admin viewing certains boutons sont caches (NavGarage/Finances/Casier/Prefs/Admin),
	// donc on parcourt dans l ordre et on prend le premier visible.
	//------------------------------------------------------------------------------------------------
	//------------------------------------------------------------------------------------------------
	// Pousse le focus manette vers le premier bouton actionnable de la page cible.
	// Appele par le nav handler apres SwitchToPage pour que la nav manette reste fluide.
	//------------------------------------------------------------------------------------------------
	void FocusFirstPageButton(int page)
	{
		Widget target = null;
		if (page == 0)
		{
			if (m_BtnLeaveGang && m_BtnLeaveGang.IsVisible()) target = m_BtnLeaveGang;
			else if (m_BtnDissolveGang && m_BtnDissolveGang.IsVisible()) target = m_BtnDissolveGang;
		}
		else if (page == 4 && m_BtnResidencesPrev) target = m_BtnResidencesPrev;
		else if (page == 5 && m_BtnMedicalPrev) target = m_BtnMedicalPrev;
		else if (page == 6 && m_BtnTogglePlayerCard) target = m_BtnTogglePlayerCard;

		if (target && target.IsVisible())
			GetGame().GetWorkspace().SetFocusedWidget(target);
	}

	Widget FindFirstVisibleSidebarButton()
	{
		if (m_NavPersonnage && m_NavPersonnage.IsVisible()) return m_NavPersonnage;
		if (m_NavGarage && m_NavGarage.IsVisible()) return m_NavGarage;
		if (m_NavFinances && m_NavFinances.IsVisible()) return m_NavFinances;
		if (m_NavCasier && m_NavCasier.IsVisible()) return m_NavCasier;
		if (m_NavResidences && m_NavResidences.IsVisible()) return m_NavResidences;
		if (m_NavMedical && m_NavMedical.IsVisible()) return m_NavMedical;
		if (m_NavPrefs && m_NavPrefs.IsVisible()) return m_NavPrefs;
		if (m_BtnAdmin && m_BtnAdmin.IsVisible()) return m_BtnAdmin;
		return null;
	}

	//------------------------------------------------------------------------------------------------
	// Charge le preview 3D du personnage dans le widget Portrait.
	// IMPORTANT : on utilise SetPreviewItem(entity) et NON SetPreviewItemFromPrefab(prefab)
	// pour que le preview reflete la vraie apparence actuelle (equipement, vetements, etc.).
	// SetPreviewItemFromPrefab renvoie le prefab BRUT du spawn, qui au deco/reco est l apparence
	// par defaut, pas celle que le joueur a actuellement.
	//------------------------------------------------------------------------------------------------
	void LoadCharacterPreview()
	{
		if (!m_CharacterPreviewWidget) return;
		if (m_IsAdminViewing) return; // en admin viewing on affiche pas son propre perso
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return;
		IEntity ch = pc.GetControlledEntity();
		if (!ch) return;

		ItemPreviewManagerEntity mgr = GetPreviewManager();
		if (!mgr) return;
		mgr.SetPreviewItem(m_CharacterPreviewWidget, ch, null, false);
	}

	//------------------------------------------------------------------------------------------------
	// Cache toutes les cartes de la page personnage (etat initial)
	//------------------------------------------------------------------------------------------------
	void HideAllCards()
	{
		if (m_CardIdentite) m_CardIdentite.SetVisible(false);
		if (m_CardEtat) m_CardEtat.SetVisible(false);
		if (m_CardJob) m_CardJob.SetVisible(false);
		if (m_CardGang) m_CardGang.SetVisible(false);
		if (m_CardPermis) m_CardPermis.SetVisible(false);
		if (m_CardAutres) m_CardAutres.SetVisible(false);
		if (m_CardStats) m_CardStats.SetVisible(false);
	}

	//------------------------------------------------------------------------------------------------
	// Lit soif et faim depuis le SurvivalHUDManager local (celui qui alimente deja le HUD)
	// et les ajoute en fin du corps ETAT. En admin viewing on ne les ajoute pas (ce n est pas
	// la soif de la cible, c est celle de l admin local).
	//------------------------------------------------------------------------------------------------
	string AppendSoifFaim(string etatBody)
	{
		if (m_IsAdminViewing) return etatBody;
		SurvivalHUDManager hud = SurvivalHUDManager.GetInstance();
		if (!hud) return etatBody;

		int thirst = Math.Round(hud.GetThirst());
		int hunger = Math.Round(hud.GetHunger());
		string extra = "";
		extra = extra + "Faim (satiete)        : " + hunger.ToString() + " %\n";
		extra = extra + "Soif (hydratation)    : " + thirst.ToString() + " %";

		if (etatBody == "") return extra;
		return etatBody + "\n" + extra;
	}

	//------------------------------------------------------------------------------------------------
	// Helper : affiche une carte et met son texte, cache si vide
	//------------------------------------------------------------------------------------------------
	void SetCardText(Widget card, TextWidget body, string text)
	{
		if (!card || !body) return;
		if (text == "")
		{
			card.SetVisible(false);
			return;
		}
		body.SetText(text);
		card.SetVisible(true);
	}

	//------------------------------------------------------------------------------------------------
	// Parse la fiche en sections (headers "--- NAME ---") et rempli les cartes stylisees.
	// Les sections inconnues (non Identite/Etat/Job/Gang/Permis, et non Finances/Casier/Stats
	// qui ont leur propre page) vont dans la carte "AUTRES INFORMATIONS".
	//------------------------------------------------------------------------------------------------
	void BuildPersonnageCards(string full)
	{
		HideAllCards();
		if (full == "") return;

		array<string> names = new array<string>();
		array<string> bodies = new array<string>();
		ParseAllSections(full, names, bodies);

		string autresBuf = "";
		int sc = names.Count();
		for (int i = 0; i < sc; i++)
		{
			string rawName = names.Get(i);
			string nm = ToLowerQuick(rawName);
			string body = bodies.Get(i);
			if (body == "") continue;

			if (nm.IndexOf("identit") == 0)
				SetCardText(m_CardIdentite, m_CardIdentiteBody, body);
			else if (nm.IndexOf("etat") == 0)
				SetCardText(m_CardEtat, m_CardEtatBody, AppendSoifFaim(body));
			else if (nm.IndexOf("job") == 0 || nm.IndexOf("metier") == 0)
				SetCardText(m_CardJob, m_CardJobBody, body);
			else if (nm.IndexOf("gang") == 0)
				SetCardText(m_CardGang, m_CardGangBody, body);
			else if (nm.IndexOf("permis") == 0 || nm.IndexOf("licence") == 0)
				SetCardText(m_CardPermis, m_CardPermisBody, body);
			else if (nm.IndexOf("stat") == 0)
				SetCardText(m_CardStats, m_CardStatsBody, body);
			else if (nm.IndexOf("finance") == 0 || nm.IndexOf("casier") == 0
				|| nm.IndexOf("amende") == 0 || nm.IndexOf("prison") == 0)
			{
				// FINANCES et CASIER vont sur leurs pages dediees (via Extract...) -> ignores ici
			}
			else
			{
				if (autresBuf != "") autresBuf = autresBuf + "\n\n";
				autresBuf = autresBuf + "[ " + rawName + " ]\n" + body;
			}
		}

		if (autresBuf != "")
			SetCardText(m_CardAutres, m_CardAutresBody, autresBuf);

		// Si rien du tout n a ete rempli (aucune section connue trouvee), fallback : balance la fiche brute dans Autres
		bool anyShown = false;
		if (m_CardIdentite && m_CardIdentite.IsVisible()) anyShown = true;
		if (m_CardEtat && m_CardEtat.IsVisible()) anyShown = true;
		if (m_CardJob && m_CardJob.IsVisible()) anyShown = true;
		if (m_CardGang && m_CardGang.IsVisible()) anyShown = true;
		if (m_CardPermis && m_CardPermis.IsVisible()) anyShown = true;
		if (m_CardAutres && m_CardAutres.IsVisible()) anyShown = true;
		if (m_CardStats && m_CardStats.IsVisible()) anyShown = true;
		if (!anyShown)
			SetCardText(m_CardAutres, m_CardAutresBody, full);

		UpdateCharacterSubtitle(full);
	}

	//------------------------------------------------------------------------------------------------
	// Scan le texte pour extraire TOUTES les sections "--- NAME ---" avec leur corps.
	// Rempli les arrays passes en reference.
	//------------------------------------------------------------------------------------------------
	void ParseAllSections(string full, array<string> outNames, array<string> outBodies)
	{
		int pos = 0;
		int flen = full.Length();
		while (pos < flen)
		{
			int hdrStart = IndexOfFrom(full, "--- ", pos);
			if (hdrStart < 0) break;
			int nameStart = hdrStart + 4;
			int nameEnd = IndexOfFrom(full, " ---", nameStart);
			if (nameEnd < 0) break;
			string name = full.Substring(nameStart, nameEnd - nameStart);
			// trim
			while (name.Length() > 0 && name.Substring(0, 1) == " ")
				name = name.Substring(1, name.Length() - 1);

			int bodyStart = nameEnd + 4;
			while (bodyStart < flen)
			{
				string c = full.Substring(bodyStart, 1);
				if (c == "\n" || c == "\r") bodyStart = bodyStart + 1;
				else break;
			}
			int bodyEnd = IndexOfFrom(full, "--- ", bodyStart);
			if (bodyEnd < 0) bodyEnd = flen;
			// recule sur retours chariot
			while (bodyEnd > bodyStart)
			{
				string c2 = full.Substring(bodyEnd - 1, 1);
				if (c2 == "\n" || c2 == "\r" || c2 == " ") bodyEnd = bodyEnd - 1;
				else break;
			}
			string body = "";
			if (bodyEnd > bodyStart) body = full.Substring(bodyStart, bodyEnd - bodyStart);
			outNames.Insert(name);
			outBodies.Insert(body);
			pos = bodyEnd;
			if (pos <= hdrStart) pos = hdrStart + 1; // garde-fou anti-boucle
		}
	}

	//------------------------------------------------------------------------------------------------
	// Extrait la valeur apres "Key :" (jusqu a la fin de ligne). Retourne "" si pas trouve.
	//------------------------------------------------------------------------------------------------
	string ExtractValueByKey(string text, string key)
	{
		int idx = text.IndexOf(key);
		if (idx < 0) return "";
		int colonIdx = IndexOfFrom(text, ":", idx);
		if (colonIdx < 0) return "";
		int endIdx = IndexOfFrom(text, "\n", colonIdx);
		if (endIdx < 0) endIdx = text.Length();
		string val = text.Substring(colonIdx + 1, endIdx - colonIdx - 1);
		while (val.Length() > 0)
		{
			string c = val.Substring(0, 1);
			if (c == " " || c == "\t") val = val.Substring(1, val.Length() - 1);
			else break;
		}
		while (val.Length() > 0)
		{
			string c2 = val.Substring(val.Length() - 1, 1);
			if (c2 == " " || c2 == "\t" || c2 == "\r") val = val.Substring(0, val.Length() - 1);
			else break;
		}
		return val;
	}

	//------------------------------------------------------------------------------------------------
	// Rempli le sous-titre sous le portrait : "Prenom Nom - Metier" et le nom dans la sidebar
	//------------------------------------------------------------------------------------------------
	void UpdateCharacterSubtitle(string full)
	{
		string prenom = ExtractValueByKey(full, "Prenom");
		string nom = ExtractValueByKey(full, "Nom");
		string metier = ExtractValueByKey(full, "Metier");
		if (metier == "") metier = ExtractValueByKey(full, "Job");

		string displayName = "";
		if (prenom != "" && nom != "") displayName = prenom + " " + nom;
		else if (prenom != "") displayName = prenom;
		else if (nom != "") displayName = nom;

		string subtitle = displayName;
		if (metier != "")
		{
			if (subtitle != "") subtitle = subtitle + " - " + metier;
			else subtitle = metier;
		}

		if (m_CharacterSubtitle) m_CharacterSubtitle.SetText(subtitle);
		if (m_SidebarRpName && displayName != "" && !m_IsAdminViewing)
			m_SidebarRpName.SetText(displayName);
	}

	//------------------------------------------------------------------------------------------------
	void AttachNav(ButtonWidget btn, int page)
	{
		if (!btn) return;
		RpFicheNavHandler h = new RpFicheNavHandler();
		h.m_Menu = this;
		h.m_Page = page;
		btn.AddHandler(h);
		JobFocusHandler.Attach(btn);
	}

	void AttachAction(ButtonWidget btn, string action)
	{
		if (!btn) return;
		RpFicheActionHandler h = new RpFicheActionHandler();
		h.m_Menu = this;
		h.m_Action = action;
		btn.AddHandler(h);
		JobFocusHandler.Attach(btn);
	}

	//------------------------------------------------------------------------------------------------
	void SwitchToPage(int page)
	{
		m_CurrentPage = page;

		if (m_PagePersonnage) m_PagePersonnage.SetVisible(page == 0);
		if (m_PageGarage) m_PageGarage.SetVisible(page == 1);
		if (m_PageFinances) m_PageFinances.SetVisible(page == 2);
		if (m_PageCasier) m_PageCasier.SetVisible(page == 3);
		if (m_PageResidences) m_PageResidences.SetVisible(page == 4);
		if (m_PageMedical) m_PageMedical.SetVisible(page == 5);
		if (m_PagePrefs) m_PagePrefs.SetVisible(page == 6);

		SetNavActive(m_NavPersonnage, page == 0);
		SetNavActive(m_NavGarage, page == 1);
		SetNavActive(m_NavFinances, page == 2);
		SetNavActive(m_NavCasier, page == 3);
		SetNavActive(m_NavResidences, page == 4);
		SetNavActive(m_NavMedical, page == 5);
		SetNavActive(m_NavPrefs, page == 6);

		if (m_PageTitle && m_PageSubtitle)
		{
			if (page == 0)
			{
				m_PageTitle.SetText("MON PERSONNAGE");
				m_PageSubtitle.SetText("Identite RP, metier, gang, statistiques personnelles.");
			}
			else if (page == 1)
			{
				m_PageTitle.SetText("MON GARAGE VIRTUEL");
				m_PageSubtitle.SetText("Liste de vos vehicules enregistres (etat, carburant, contenu coffre).");
			}
			else if (page == 2)
			{
				m_PageTitle.SetText("MES FINANCES");
				m_PageSubtitle.SetText("Argent sur soi, en banque et amendes impayees.");
			}
			else if (page == 3)
			{
				m_PageTitle.SetText("MON CASIER JUDICIAIRE");
				m_PageSubtitle.SetText("Mentions, commentaires des forces de l ordre et statut prison.");
			}
			else if (page == 4)
			{
				m_PageTitle.SetText("MES RESIDENCES");
				m_PageSubtitle.SetText("Portes achetees : lieu, prix d achat et codes.");
			}
			else if (page == 5)
			{
				m_PageTitle.SetText("DOSSIER MEDICAL PARTAGE");
				m_PageSubtitle.SetText("Hospitalisations, soins et notes medicales a votre dossier.");
			}
			else if (page == 6)
			{
				m_PageTitle.SetText("PREFERENCES HUD");
				m_PageSubtitle.SetText("Reglages d affichage de votre interface.");
			}
		}

		if (page == 1) RequestGarageList();
		if (page == 4) RequestResidences();
		if (page == 5) RequestMedical();
	}

	//------------------------------------------------------------------------------------------------
	// Resout le manager de preview (singleton world "ItemPreviewManagerEntity")
	//------------------------------------------------------------------------------------------------
	ItemPreviewManagerEntity GetPreviewManager()
	{
		if (m_PreviewManagerCache) return m_PreviewManagerCache;
		BaseWorld world = GetGame().GetWorld();
		if (!world) return null;
		IEntity entity = world.FindEntityByName("ItemPreviewManagerEntity");
		if (entity) m_PreviewManagerCache = ItemPreviewManagerEntity.Cast(entity);
		return m_PreviewManagerCache;
	}

	//------------------------------------------------------------------------------------------------
	// Affiche le vehicule selectionne dans le ItemPreviewWidget
	//------------------------------------------------------------------------------------------------
	void SelectGarageVehicle(int index)
	{
		if (index < 0 || index >= s_GaragePrefabs.Count()) return;
		string prefab = s_GaragePrefabs.Get(index);
		string model = s_GarageModels.Get(index);

		if (m_GarageSelectedTitle)
			m_GarageSelectedTitle.SetText(model);

		if (m_GarageSelectedInfo)
		{
			int fuel = s_GarageFuels.Get(index);
			int dmg = s_GarageDamagedParts.Get(index);
			int items = s_GarageItemsCount.Get(index);
			int ins = s_GarageInsured.Get(index);
			string insTxt = "Non assure";
			if (ins == 1) insTxt = "Assure";
			string fuelTxt = "? L";
			if (fuel >= 0) fuelTxt = fuel.ToString() + " L";
			m_GarageSelectedInfo.SetText(string.Format(
				"Carburant %1  |  %2 zone(s) endommagee(s)\nItems coffre : %3  |  %4",
				fuelTxt, dmg.ToString(), items.ToString(), insTxt));
		}

		if (m_GaragePreviewWidget && prefab != "")
		{
			ItemPreviewManagerEntity mgr = GetPreviewManager();
			if (mgr)
				mgr.SetPreviewItemFromPrefab(m_GaragePreviewWidget, prefab, null, false);
		}
	}

	//------------------------------------------------------------------------------------------------
	// Requete serveur : liste des portes achetees par le joueur. Resultat recu via DisplayResidencesData.
	//------------------------------------------------------------------------------------------------
	void RequestResidences()
	{
		if (m_IsAdminViewing)
		{
			if (m_ResidencesText) m_ResidencesText.SetText("Non disponible en mode admin viewing.");
			return;
		}
		if (m_ResidencesText) m_ResidencesText.SetText("Chargement de vos residences...");
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		jpc.ClientAskMyResidences();
	}

	//------------------------------------------------------------------------------------------------
	// Requete serveur : dossier medical du joueur. Resultat recu via DisplayMedicalData.
	//------------------------------------------------------------------------------------------------
	void RequestMedical()
	{
		if (m_IsAdminViewing)
		{
			if (m_MedicalText) m_MedicalText.SetText("Non disponible en mode admin viewing.");
			return;
		}
		if (m_MedicalText) m_MedicalText.SetText("Chargement de votre dossier medical...");
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		jpc.ClientAskMyMedicalRecord();
	}

	//------------------------------------------------------------------------------------------------
	//------------------------------------------------------------------------------------------------
	// Parse une reponse serveur du format "header~~~ENTRY~~~entry1~~~ENTRY~~~entry2..."
	// Rempli l array d entries (passee par reference), retourne le header en valeur.
	//------------------------------------------------------------------------------------------------
	string ParseEntriesIntoArray(string raw, string delim, array<string> outEntries)
	{
		outEntries.Clear();
		if (raw == "") return "";
		int firstIdx = raw.IndexOf(delim);
		if (firstIdx < 0) return raw;
		string hdr = raw.Substring(0, firstIdx);
		int pos = firstIdx + delim.Length();
		int rlen = raw.Length();
		int dlen = delim.Length();
		while (pos < rlen)
		{
			int nextIdx = IndexOfFrom(raw, delim, pos);
			if (nextIdx < 0)
			{
				outEntries.Insert(raw.Substring(pos, rlen - pos));
				break;
			}
			outEntries.Insert(raw.Substring(pos, nextIdx - pos));
			pos = nextIdx + dlen;
		}
		return hdr;
	}

	//------------------------------------------------------------------------------------------------
	void DisplayResidencesData(string formatted)
	{
		m_ResidencesHeader = ParseEntriesIntoArray(formatted, "~~~ENTRY~~~", m_ResidencesEntries);
		m_ResidencesPage = 0;
		RenderResidencesPage();
	}

	void DisplayMedicalData(string formatted)
	{
		m_MedicalHeader = ParseEntriesIntoArray(formatted, "~~~ENTRY~~~", m_MedicalEntries);
		m_MedicalPage = 0;
		RenderMedicalPage();
	}

	//------------------------------------------------------------------------------------------------
	// Rendu de la page courante : header + slice d entries + label "Page X/Y"
	//------------------------------------------------------------------------------------------------
	void RenderResidencesPage()
	{
		int total = m_ResidencesEntries.Count();
		int totalPages = (total + ENTRIES_PER_PAGE - 1) / ENTRIES_PER_PAGE;
		if (totalPages < 1) totalPages = 1;
		if (m_ResidencesPage < 0) m_ResidencesPage = 0;
		if (m_ResidencesPage >= totalPages) m_ResidencesPage = totalPages - 1;

		string txt = m_ResidencesHeader;
		int start = m_ResidencesPage * ENTRIES_PER_PAGE;
		int end = start + ENTRIES_PER_PAGE;
		if (end > total) end = total;
		int i;
		for (i = start; i < end; i++)
			txt = txt + "\n\n" + m_ResidencesEntries.Get(i);

		if (m_ResidencesText) m_ResidencesText.SetText(txt);
		if (m_ResidencesPageLabel)
			m_ResidencesPageLabel.SetText("Page " + (m_ResidencesPage + 1).ToString() + " / " + totalPages.ToString());
	}

	void RenderMedicalPage()
	{
		int total = m_MedicalEntries.Count();
		int totalPages = (total + ENTRIES_PER_PAGE - 1) / ENTRIES_PER_PAGE;
		if (totalPages < 1) totalPages = 1;
		if (m_MedicalPage < 0) m_MedicalPage = 0;
		if (m_MedicalPage >= totalPages) m_MedicalPage = totalPages - 1;

		string txt = m_MedicalHeader;
		int start = m_MedicalPage * ENTRIES_PER_PAGE;
		int end = start + ENTRIES_PER_PAGE;
		if (end > total) end = total;
		int i;
		for (i = start; i < end; i++)
			txt = txt + "\n\n" + m_MedicalEntries.Get(i);

		if (m_MedicalText) m_MedicalText.SetText(txt);
		if (m_MedicalPageLabel)
			m_MedicalPageLabel.SetText("Page " + (m_MedicalPage + 1).ToString() + " / " + totalPages.ToString());
	}

	void SetNavActive(ButtonWidget btn, bool active)
	{
		if (!btn) return;
		if (active) btn.SetColor(Color.FromRGBA(36, 28, 66, 255));
		else btn.SetColor(Color.FromRGBA(20, 25, 40, 255));
	}

	//------------------------------------------------------------------------------------------------
	void RequestGarageList()
	{
		if (m_IsAdminViewing) return;
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		jpc.ClientAskMyGarageList();
	}

	//------------------------------------------------------------------------------------------------
	void RefreshTogglePlayerCardLabel()
	{
		if (!m_BtnTogglePlayerCardLabel) return;
		LP_PlayerIdentityHud hud = LP_PlayerIdentityHud.GetInstance();
		if (!hud) return;
		if (hud.IsPlayerCardVisible())
			m_BtnTogglePlayerCardLabel.SetText("Masquer carte joueur");
		else
			m_BtnTogglePlayerCardLabel.SetText("Afficher carte joueur");
	}

	//------------------------------------------------------------------------------------------------
	// Parse le texte de la fiche (format BuildFicheString) pour afficher les bons boutons gang
	// et extraire les sections finances/casier a repartir sur les autres pages.
	//------------------------------------------------------------------------------------------------
	void ParseGangStatusAndShowButtons(bool enable)
	{
		if (m_BtnLeaveGang) m_BtnLeaveGang.SetVisible(false);
		if (m_BtnDissolveGang) m_BtnDissolveGang.SetVisible(false);
		if (!enable || s_FicheRaw == "") return;
		if (s_FicheRaw.IndexOf("Aucun gang") >= 0) return;
		if (m_BtnLeaveGang) m_BtnLeaveGang.SetVisible(true);
		if (s_FicheRaw.IndexOf("Statut      : Chef") >= 0 || s_FicheRaw.IndexOf("Statut : Chef") >= 0)
			if (m_BtnDissolveGang) m_BtnDissolveGang.SetVisible(true);
	}

	//------------------------------------------------------------------------------------------------
	// Rempli les pages Finances / Casier en extrayant les sections de la fiche.
	// On fait du parsing simple : les sections sont separees par des titres connus.
	//------------------------------------------------------------------------------------------------
	void DistributeFicheToPages()
	{
		if (m_FinancesText) m_FinancesText.SetText(ExtractSectionsForFinances(s_FicheRaw));
		if (m_CasierText) m_CasierText.SetText(ExtractSectionsForCasier(s_FicheRaw));
		// La sidebar RP name est deja mise a jour par BuildPersonnageCards > UpdateCharacterSubtitle
	}

	// Helper : IndexOf a partir d un offset (Enforce string.IndexOf ne prend qu 1 param)
	int IndexOfFrom(string full, string needle, int startPos)
	{
		if (startPos < 0) startPos = 0;
		int flen = full.Length();
		if (startPos >= flen) return -1;
		string tail = full.Substring(startPos, flen - startPos);
		int rel = tail.IndexOf(needle);
		if (rel < 0) return -1;
		return startPos + rel;
	}

	string ExtractOneLine(string full, string keyword)
	{
		int idx = full.IndexOf(keyword);
		if (idx < 0) return "";
		int endIdx = IndexOfFrom(full, "\n", idx);
		if (endIdx < 0) endIdx = full.Length();
		return full.Substring(idx, endIdx - idx);
	}

	// Extrait le corps d une section dediee par son nom de header "--- NAME ---".
	// Utilise pour les pages Finances et Casier qui ont leur section dediee cote serveur.
	string ExtractSectionBodyByName(string full, string sectionNameUpper)
	{
		if (full == "") return "";
		string header = "--- " + sectionNameUpper + " ---";
		int start = full.IndexOf(header);
		if (start < 0) return "";
		start = start + header.Length();
		int flen = full.Length();
		// skip leading newlines
		while (start < flen)
		{
			string c = full.Substring(start, 1);
			if (c == "\n" || c == "\r") start = start + 1;
			else break;
		}
		int end = IndexOfFrom(full, "--- ", start);
		if (end < 0) end = flen;
		while (end > start)
		{
			string c2 = full.Substring(end - 1, 1);
			if (c2 == "\n" || c2 == "\r" || c2 == " ") end = end - 1;
			else break;
		}
		if (end <= start) return "";
		return full.Substring(start, end - start);
	}

	string ExtractSectionsForFinances(string full)
	{
		if (full == "") return "Chargement...";
		string body = ExtractSectionBodyByName(full, "FINANCES");
		if (body == "") return "Aucune donnee financiere trouvee.";
		return body;
	}

	string ExtractSectionsForCasier(string full)
	{
		if (full == "") return "Chargement...";
		string body = ExtractSectionBodyByName(full, "CASIER JUDICIAIRE");
		if (body == "") return "Casier vierge. Aucune mention.";
		return body;
	}

	// Lowercase ASCII rapide
	string ToLowerQuick(string s)
	{
		string r = "";
		int slen = s.Length();
		for (int i = 0; i < slen; i++)
		{
			string c = s.Substring(i, 1);
			if (c == "A") r = r + "a"; else if (c == "B") r = r + "b"; else if (c == "C") r = r + "c";
			else if (c == "D") r = r + "d"; else if (c == "E") r = r + "e"; else if (c == "F") r = r + "f";
			else if (c == "G") r = r + "g"; else if (c == "H") r = r + "h"; else if (c == "I") r = r + "i";
			else if (c == "J") r = r + "j"; else if (c == "K") r = r + "k"; else if (c == "L") r = r + "l";
			else if (c == "M") r = r + "m"; else if (c == "N") r = r + "n"; else if (c == "O") r = r + "o";
			else if (c == "P") r = r + "p"; else if (c == "Q") r = r + "q"; else if (c == "R") r = r + "r";
			else if (c == "S") r = r + "s"; else if (c == "T") r = r + "t"; else if (c == "U") r = r + "u";
			else if (c == "V") r = r + "v"; else if (c == "W") r = r + "w"; else if (c == "X") r = r + "x";
			else if (c == "Y") r = r + "y"; else if (c == "Z") r = r + "z";
			else r = r + c;
		}
		return r;
	}

	//------------------------------------------------------------------------------------------------
	// GARAGE : affiche les vehicules recus du serveur
	//------------------------------------------------------------------------------------------------
	void ApplyGarageData()
	{
		if (!m_GarageContainer) return;
		Widget child = m_GarageContainer.GetChildren();
		while (child) { Widget next = child.GetSibling(); child.RemoveFromHierarchy(); child = next; }

		WorkspaceWidget ws = GetGame().GetWorkspace();
		if (!ws) return;

		int n = s_GarageModels.Count();
		if (n == 0)
		{
			if (m_GarageStatusText) m_GarageStatusText.SetText("Vous n avez aucun vehicule enregistre.");
			return;
		}
		if (m_GarageStatusText) m_GarageStatusText.SetText(n.ToString() + " vehicule(s) enregistre(s)");

		for (int i = 0; i < n; i++)
		{
			Widget row = ws.CreateWidgets(ROW_LAYOUT_PATH, m_GarageContainer);
			if (!row) continue;

			int fuel = s_GarageFuels.Get(i);
			int dmg = s_GarageDamagedParts.Get(i);
			int items = s_GarageItemsCount.Get(i);
			int insured = s_GarageInsured.Get(i);

			string fuelStr;
			if (fuel < 0) fuelStr = "Carburant: ?";
			else fuelStr = "Carburant: " + fuel.ToString() + " L";

			string dmgStr;
			if (dmg == 0) dmgStr = "Etat: Intact";
			else dmgStr = "Degats: " + dmg.ToString() + " zone(s)";

			string insStr = "";
			if (insured == 1) insStr = " - Assure";

			int rank = i + 1;
			string colMiddle = string.Format("%1  |  %2  |  Items coffre: %3%4",
				fuelStr, dmgStr, items.ToString(), insStr);

			TextWidget ti = TextWidget.Cast(row.FindAnyWidget("ColId"));
			TextWidget tn = TextWidget.Cast(row.FindAnyWidget("ColName"));
			TextWidget tm = TextWidget.Cast(row.FindAnyWidget("ColMiddle"));
			TextWidget tr = TextWidget.Cast(row.FindAnyWidget("ColRight"));
			if (ti) ti.SetText(rank.ToString());
			if (tn) tn.SetText(s_GarageModels.Get(i));
			if (tm) tm.SetText(colMiddle);
			if (tr) tr.SetText("Voir");

			// Clic sur une ligne -> change le preview 3D a gauche
			ButtonWidget rowBtn = ButtonWidget.Cast(row.FindAnyWidget("RowButton"));
			if (rowBtn)
			{
				RpFicheGarageRowHandler gh = new RpFicheGarageRowHandler();
				gh.m_Menu = this;
				gh.m_Index = i;
				rowBtn.AddHandler(gh);
				JobFocusHandler.Attach(rowBtn);
			}
		}

		// Auto-selection du premier vehicule au chargement
		if (n > 0)
			SelectGarageVehicle(0);
	}

	//------------------------------------------------------------------------------------------------
	// POPUP CONFIRM
	//------------------------------------------------------------------------------------------------
	void ShowConfirmPopup(string action)
	{
		m_PendingConfirmAction = action;
		string msg = "Etes-vous sur ?";
		if (action == "leave") msg = "Voulez-vous vraiment quitter votre gang ?";
		else if (action == "dissolve") msg = "Voulez-vous vraiment DISSOUDRE votre gang ?\nCette action est irreversible.";
		if (m_ConfirmText) m_ConfirmText.SetText(msg);
		if (m_ConfirmOverlay) m_ConfirmOverlay.SetVisible(true);
		if (m_BtnConfirmNo) GetGame().GetWorkspace().SetFocusedWidget(m_BtnConfirmNo);
	}

	void HideConfirmPopup()
	{
		if (m_ConfirmOverlay) m_ConfirmOverlay.SetVisible(false);
		m_PendingConfirmAction = "";
		if (m_BtnClose) GetGame().GetWorkspace().SetFocusedWidget(m_BtnClose);
	}

	//------------------------------------------------------------------------------------------------
	void OnActionClicked(string action)
	{
		if (action == "close") { CloseMenuInternal(); return; }
		if (action == "leave_gang") { ShowConfirmPopup("leave"); return; }
		if (action == "dissolve_gang") { ShowConfirmPopup("dissolve"); return; }
		if (action == "open_admin")
		{
			PlayerController pc = GetGame().GetPlayerController();
			if (!pc) return;
			JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
			if (!jpc) return;
			jpc.ClientAskOpenAdminMenu();
			CloseMenuInternal();
			return;
		}
		if (action == "toggle_player_card")
		{
			LP_PlayerIdentityHud hud = LP_PlayerIdentityHud.GetInstance();
			if (hud) hud.TogglePlayerCardVisible();
			RefreshTogglePlayerCardLabel();
			return;
		}
		if (action == "res_prev") { m_ResidencesPage = m_ResidencesPage - 1; RenderResidencesPage(); return; }
		if (action == "res_next") { m_ResidencesPage = m_ResidencesPage + 1; RenderResidencesPage(); return; }
		if (action == "med_prev") { m_MedicalPage = m_MedicalPage - 1; RenderMedicalPage(); return; }
		if (action == "med_next") { m_MedicalPage = m_MedicalPage + 1; RenderMedicalPage(); return; }
		if (action == "confirm_no") { HideConfirmPopup(); return; }
		if (action == "confirm_yes")
		{
			string pending = m_PendingConfirmAction;
			HideConfirmPopup();
			PlayerController pc = GetGame().GetPlayerController();
			if (!pc) return;
			JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
			if (!jpc) return;
			if (pending == "leave") jpc.ClientAskLeaveGang();
			else if (pending == "dissolve") jpc.ClientAskDissolveGang();
			GetGame().GetCallqueue().CallLater(CloseMenuInternal, 400, false);
		}
	}

	//------------------------------------------------------------------------------------------------
	override void OnMenuClose()
	{
		if (s_Instance == this) s_Instance = null;
		super.OnMenuClose();
	}

	override void OnMenuUpdate(float tDelta)
	{
		super.OnMenuUpdate(tDelta);
		if (GetGame().GetInputManager().GetActionValue("MenuBack") > 0.5)
		{
			if (m_ConfirmOverlay && m_ConfirmOverlay.IsVisible()) { HideConfirmPopup(); return; }
			CloseMenuInternal();
		}
	}

	void CloseMenuInternal()
	{
		GetGame().GetMenuManager().CloseMenu(this);
	}

	//------------------------------------------------------------------------------------------------
	// Reception de la fiche RP (RpcDo_ReceiveFicheData -> DisplayFicheData)
	//------------------------------------------------------------------------------------------------
	void DisplayFicheData(string formattedData)
	{
		s_FicheRaw = formattedData;
		if (m_InfoText) m_InfoText.SetText(formattedData);
		BuildPersonnageCards(formattedData);
		ParseGangStatusAndShowButtons(!m_IsAdminViewing);
		DistributeFicheToPages();
	}

	//------------------------------------------------------------------------------------------------
	// Garage data (set par RPC avant NotifyGarageReady)
	//------------------------------------------------------------------------------------------------
	static void SetGaragePending(array<string> models, array<string> prefabs, array<int> fuels, array<int> dmg, array<int> items, array<int> insured)
	{
		s_GarageModels.Clear(); s_GaragePrefabs.Clear(); s_GarageFuels.Clear();
		s_GarageDamagedParts.Clear(); s_GarageItemsCount.Clear(); s_GarageInsured.Clear();
		if (models) foreach (string m : models) s_GarageModels.Insert(m);
		if (prefabs) foreach (string p : prefabs) s_GaragePrefabs.Insert(p);
		if (fuels) foreach (int f : fuels) s_GarageFuels.Insert(f);
		if (dmg) foreach (int d : dmg) s_GarageDamagedParts.Insert(d);
		if (items) foreach (int it : items) s_GarageItemsCount.Insert(it);
		if (insured) foreach (int ii : insured) s_GarageInsured.Insert(ii);
	}

	static void NotifyGarageReady()
	{
		if (s_Instance) s_Instance.ApplyGarageData();
	}

	static JobRpFicheMenu GetOpenMenu() { return s_Instance; }
}

//------------------------------------------------------------------------------------------------
// Clic sur une ligne vehicule garage -> affiche son preview 3D a gauche
//------------------------------------------------------------------------------------------------
class RpFicheGarageRowHandler : ScriptedWidgetEventHandler
{
	JobRpFicheMenu m_Menu;
	int m_Index;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.SelectGarageVehicle(m_Index);
		return true;
	}
}

//------------------------------------------------------------------------------------------------
class RpFicheNavHandler : ScriptedWidgetEventHandler
{
	JobRpFicheMenu m_Menu;
	int m_Page;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu)
		{
			m_Menu.SwitchToPage(m_Page);
			// Sur manette : apres le switch, pousse le focus sur le premier bouton
			// actionnable de la page de destination pour que DPad continue a fonctionner.
			m_Menu.FocusFirstPageButton(m_Page);
		}
		return true;
	}
}

//------------------------------------------------------------------------------------------------
// Handler actions (anti-rebond : OnClick + OnMouseButtonDown peuvent se declencher tous les 2)
//------------------------------------------------------------------------------------------------
class RpFicheActionHandler : ScriptedWidgetEventHandler
{
	JobRpFicheMenu m_Menu;
	string m_Action;
	protected bool m_FireLocked = false;

	protected bool TryFire()
	{
		if (m_FireLocked) return false;
		m_FireLocked = true;
		GetGame().GetCallqueue().CallLater(UnlockFire, 150, false);
		return true;
	}
	protected void UnlockFire() { m_FireLocked = false; }

	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu && TryFire()) m_Menu.OnActionClicked(m_Action);
		return true;
	}
	override bool OnMouseButtonDown(Widget w, int x, int y, int button)
	{
		if (m_Menu && TryFire()) m_Menu.OnActionClicked(m_Action);
		return true;
	}
}

//------------------------------------------------------------------------------------------------
// Alias du handler pour compatibilite avec l ancien close
//------------------------------------------------------------------------------------------------
class RpFicheCloseHandler : ScriptedWidgetEventHandler
{
	JobRpFicheMenu m_Menu;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.CloseMenuInternal();
		return true;
	}
	override bool OnMouseButtonDown(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.CloseMenuInternal();
		return true;
	}
}
