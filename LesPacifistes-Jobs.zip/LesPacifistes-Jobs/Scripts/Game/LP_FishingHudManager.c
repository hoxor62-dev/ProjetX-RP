//------------------------------------------------------------------------------------------------
// LP_FishingHudManager.c
// Singleton CLIENT qui affiche le HUD de peche.
//   - Barre de progression (5 min total)
//   - Compteur de poissons peches
//   - Texte : "Peche en cours..." OU "!!! UN POISSON MORD !!!" pendant fenetre 3s
//------------------------------------------------------------------------------------------------

class LP_FishingHudManager
{
	static ref LP_FishingHudManager s_Instance;
	static string LAYOUT_PATH = "UI/layouts/LP_FishingHud.layout";
	
	const int TICK_MS = 200; // rafraichissement fluide de la barre
	
	Widget m_Root;
	TextWidget m_TitleText;
	ImageWidget m_BarFill;    // barre = ImageWidget dont on change la largeur (pattern raid)
	TextWidget m_FishCountText;
	TextWidget m_StatusText;
	
	// Largeur max de la barre en pixels (correspond au Size dans le layout : 456)
	const float BAR_MAX_WIDTH = 456.0;
	
	int m_TotalSeconds = 300;      // 5 min par defaut
	int m_SecondsRemaining = 0;
	int m_LastServerUpdateUnix = 0; // timestamp Unix du dernier push serveur (pour interpol locale)
	int m_FishCaught = 0;
	bool m_IsBiting = false;
	bool m_Shown = false;
	
	//------------------------------------------------------------------------------------------------
	static LP_FishingHudManager GetInstance()
	{
		if (!s_Instance) s_Instance = new LP_FishingHudManager();
		return s_Instance;
	}
	
	//------------------------------------------------------------------------------------------------
	void Show(int secondsRemaining, int fishCaught, bool biting)
	{
		m_SecondsRemaining = secondsRemaining;
		m_LastServerUpdateUnix = System.GetUnixTime(); // pour interpolation locale
		m_FishCaught = fishCaught;
		m_IsBiting = biting;
		
		if (!m_Shown)
		{
			CreateWidget();
			GetGame().GetCallqueue().CallLater(TickAnimate, TICK_MS, true);
			m_Shown = true;
		}
		RefreshLabels();
	}
	
	//------------------------------------------------------------------------------------------------
	void Hide()
	{
		if (!m_Shown) return;
		m_Shown = false;
		GetGame().GetCallqueue().Remove(TickAnimate);
		if (m_Root)
		{
			m_Root.RemoveFromHierarchy();
			m_Root = null;
		}
		m_TitleText = null;
		m_BarFill = null;
		m_FishCountText = null;
		m_StatusText = null;
	}
	
	//------------------------------------------------------------------------------------------------
	protected void CreateWidget()
	{
		WorkspaceWidget ws = GetGame().GetWorkspace();
		if (!ws) return;
		m_Root = ws.CreateWidgets(LAYOUT_PATH);
		if (!m_Root) return;
		
		m_TitleText     = TextWidget.Cast(m_Root.FindAnyWidget("TitleText"));
		m_BarFill       = ImageWidget.Cast(m_Root.FindAnyWidget("BarFill"));
		m_FishCountText = TextWidget.Cast(m_Root.FindAnyWidget("FishCountText"));
		m_StatusText    = TextWidget.Cast(m_Root.FindAnyWidget("StatusText"));
	}
	
	//------------------------------------------------------------------------------------------------
	protected void RefreshLabels()
	{
		if (!m_Root) return;
		
		if (m_TitleText)
		{
			if (m_IsBiting)
				m_TitleText.SetText("!!! UN POISSON MORD !!!");
			else
				m_TitleText.SetText("Peche en cours...");
		}
		
		if (m_StatusText)
		{
			int secLeft = GetInterpolatedSecondsRemaining();
			int mm = secLeft / 60;
			int ss = secLeft - (mm * 60);
			string sec = ss.ToString();
			if (ss < 10) sec = "0" + sec;
			m_StatusText.SetText(string.Format("Temps restant : %1:%2", mm.ToString(), sec));
		}
		
		if (m_FishCountText)
			m_FishCountText.SetText(string.Format("Poissons peches : %1 / 5", m_FishCaught.ToString()));
		
		if (m_BarFill && m_TotalSeconds > 0)
		{
			// Ratio 0.0 -> 1.0 : temps interpole restant / temps total
			float ratio = GetInterpolatedSecondsRemaining();
			ratio = ratio / m_TotalSeconds;
			if (ratio < 0) ratio = 0;
			if (ratio > 1) ratio = 1;
			// Change la largeur de la barre (pattern raid HUD)
			float width = BAR_MAX_WIDTH * ratio;
			m_BarFill.SetSize(width, 22);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Tick 200ms : decompte le timer localement pour un affichage fluide.
	// Le serveur push a intervalle irregulier (sur events), le client interpole entre les push.
	//------------------------------------------------------------------------------------------------
	void TickAnimate()
	{
		if (!m_Shown) return;
		RefreshLabels();
	}
	
	//------------------------------------------------------------------------------------------------
	// Retourne le nb de secondes restantes interpole localement.
	// Base : secondes restantes recues du serveur - secondes ecoulees depuis ce push.
	//------------------------------------------------------------------------------------------------
	protected int GetInterpolatedSecondsRemaining()
	{
		int now = System.GetUnixTime();
		int elapsedSinceUpdate = now - m_LastServerUpdateUnix;
		int remaining = m_SecondsRemaining - elapsedSinceUpdate;
		if (remaining < 0) remaining = 0;
		return remaining;
	}
}
