//------------------------------------------------------------------------------------------------
// JobFuelStationManager.c
// Singleton SERVEUR qui gere les stations essence du monde.
//
// Chaque station (prefab tankpistol) a sa propre jauge persistante (0 a 150 litres).
// - Les joueurs vident la station en remplissant leur vehicule a 3 caps/litre
// - Le metier POMPISTE remplit les stations contre 400 caps par refill
//
// CLE STABLE : prefab + XZ arrondi (pattern StorageSaveManager).
// PERSISTANCE : $profile:LesPacifistesJobs/fuel_stations.json
// DECOUVERTE : auto-scan via QueryEntitiesByAABB au boot (RestoreAll optionnel).
//------------------------------------------------------------------------------------------------

class JobFuelStationManager
{
	static ref JobFuelStationManager s_Instance;

	// Prefab de la station essence (tankpistol = la pompe)
	static const string STATION_PREFAB = "{A4D0B331414901A5}Prefabs/Structures/Commercial/FuelStations/FuelStation_E_01/HouseAddons/FuelStation_E_01_tankpistol.et";

	// Capacite max d une station
	const float STATION_MAX_FUEL = 300.0;

	// Distance max vehicule-station pour pouvoir utiliser la pompe
	const float USAGE_RADIUS = 8.0;

	// Prix du carburant (vendeur -> client).
	// Modifiable par admin via panel Economie (clamp 1-5), persiste dans fuel_stations.json
	float PRICE_PER_LITER = 3.0;
	const float PRICE_MIN = 1.0;
	const float PRICE_MAX = 5.0;
	const float PRICE_DEFAULT = 3.0;

	// Prix paye au pompiste PAR LITRE remplie (station a 80/300 remplie -> 220 capsules)
	const int POMPISTE_REWARD_PER_LITER = 1;

	// Capacite max du reservoir client (fallback si vehicule n a pas de FuelManager)
	const float VEHICLE_TANK_MAX = 80.0;

	const string SAVE_FILE = "$profile:LesPacifistesJobs/fuel_stations.json";

	// Jauge actuelle par station (cle stable -> litres)
	ref map<string, float> m_StationFuel = new map<string, float>();

	// Cache position par cle stable (pour FindNearestStation en RAM, pas de query monde)
	ref map<string, vector> m_StationPositions = new map<string, vector>();

	bool m_Loaded = false;

	// Collecteur temporaire pour QueryEntitiesByAABB
	ref array<IEntity> m_TmpFoundStations = new array<IEntity>();

	//------------------------------------------------------------------------------------------------
	static JobFuelStationManager GetInstance()
	{
		if (!s_Instance)
		{
			s_Instance = new JobFuelStationManager();
			s_Instance.LoadFromDisk();
		}
		return s_Instance;
	}

	//------------------------------------------------------------------------------------------------
	// Construit la cle stable prefab + XZ arrondi (meme pattern que StorageSaveManager).
	// LEGACY : conserve pour compat uniquement, pas utilise par Discover/Refill.
	//------------------------------------------------------------------------------------------------
	static string BuildKey(string prefabName, vector pos)
	{
		int x = pos[0];
		int z = pos[2];
		return prefabName + "@" + x.ToString() + "_" + z.ToString();
	}

	//------------------------------------------------------------------------------------------------
	// Cle de station : position XZ arrondie au metre pres.
	// La deduplication N EST PAS faite sur la cle (le bucketing en grille cree des frontieres
	// arbitraires qui separent des composants d une meme station OU confondent 2 stations
	// proches). Elle est faite dans DiscoverAllStations via clustering par distance reelle.
	//------------------------------------------------------------------------------------------------
	static string BuildStationKey(vector pos)
	{
		int x = pos[0];
		int z = pos[2];
		return "station@" + x.ToString() + "_" + z.ToString();
	}

	// Rayon de clustering physique : deux composants (toit + batiment + pompe) d une MEME
	// station sont tous dans un rayon de ~CLUSTER_RADIUS metres autour du centre. Deux
	// stations distinctes sont forcement a plus que ca.
	static const float CLUSTER_RADIUS = 10.0;

	//------------------------------------------------------------------------------------------------
	// Au boot : scan toutes les stations du monde et initialise leur jauge
	// (si pas deja dans le JSON, on part de 150L par defaut = station pleine).
	//------------------------------------------------------------------------------------------------
	// Compteur pour diagnostic : combien de prefabs "proches" (fuel/station/tank) rencontres
	int m_DiagnosticNearMatchCount = 0;

	void DiscoverAllStations()
	{
		if (!Replication.IsServer())
			return;

		BaseWorld world = GetGame().GetWorld();
		if (!world)
			return;

		m_TmpFoundStations.Clear();
		m_DiagnosticNearMatchCount = 0;

		// IMPORTANT : passer EQueryEntitiesFlags.ALL pour inclure les entites STATIQUES
		// (les pompes a essence sont des props de carte, pas des entites dynamiques).
		// Sans ce flag, elles sont ignorees. Signature complete :
		// QueryEntitiesByAABB(mins, maxs, callback, filter, flags)
		world.QueryEntitiesByAABB(
			"-99999 -99999 -99999",
			"99999 99999 99999",
			OnStationEntityFilter,
			null,
			EQueryEntitiesFlags.ALL);

		// Deduplication par CLUSTERING DISTANCE : pour chaque composant trouve, on cherche
		// un cluster existant (position deja enregistree a moins de CLUSTER_RADIUS). S il
		// existe, c est le meme building physique -> skip. Sinon, c est une nouvelle station.
		// Avantage : pas de frontieres arbitraires de grille. 2 stations proches a 15-20m
		// sont correctement separees, 1 station composee de plusieurs prefabs est groupee.
		float clusterRadiusSq = CLUSTER_RADIUS * CLUSTER_RADIUS;
		int newCount = 0;
		int idx = 0;
		foreach (IEntity station : m_TmpFoundStations)
		{
			vector pos = station.GetOrigin();

			// Cherche un cluster existant dans le rayon
			bool belongsToExisting = false;
			foreach (string existingKey, vector existingPos : m_StationPositions)
			{
				float dx = existingPos[0] - pos[0];
				float dz = existingPos[2] - pos[2];
				if (dx * dx + dz * dz < clusterRadiusSq)
				{
					belongsToExisting = true;
					break;
				}
			}

			if (belongsToExisting)
			{
				// Composant d une station deja enregistree, on skip
				continue;
			}

			// Nouvelle station physique : cle = position precise (1m)
			string key = BuildStationKey(pos);
			m_StationPositions.Set(key, pos);
			if (!m_StationFuel.Contains(key))
			{
				m_StationFuel.Set(key, STATION_MAX_FUEL);
				newCount = newCount + 1;
			}

			int px = pos[0];
			int pz = pos[2];
			Print(string.Format("[JobFuelStationManager]   #%1 [NEW] pos=(%2, %3)",
				idx.ToString(), px.ToString(), pz.ToString()), LogLevel.NORMAL);
			idx = idx + 1;
		}

		if (newCount > 0)
			SaveToDisk();

		Print(string.Format("[JobFuelStationManager] Decouverte : %1 entites matchees -> %2 stations uniques (%3 near-match diagnostiques)",
			m_TmpFoundStations.Count().ToString(),
			newCount.ToString(),
			m_DiagnosticNearMatchCount.ToString()), LogLevel.NORMAL);
	}

	//------------------------------------------------------------------------------------------------
	bool OnStationEntityFilter(IEntity entity)
	{
		if (!entity) return true;
		EntityPrefabData pd = entity.GetPrefabData();
		if (!pd) return true;
		string prefabName = pd.GetPrefabName();

		// Match sur TOUT composant qui marque une station essence physique.
		// Les stations dans la map Reforger sont faites de plusieurs prefabs :
		//   - FuelStation_E_01_V1.et                 (station complete en 1 bloc)
		//   - FuelStation_E_01_building_small.et     (petite station)
		//   - FuelStation_E_01_roof.et               (toit, 1 par station composee)
		//   - FuelStation_E_01_tankpistol.et         (la pompe, parfois exposee)
		//   - FuelTank_02_Pump_green/red/yellow.et   (pompes industrielles)
		// On matche tous ces prefabs et la dedup par position XZ regroupe les composants
		// d une meme station en une seule entree.
		if (prefabName.IndexOf("FuelStation_E_01_V1") >= 0
			|| prefabName.IndexOf("FuelStation_E_01_building_small") >= 0
			|| prefabName.IndexOf("FuelStation_E_01_roof") >= 0
			|| prefabName.IndexOf("tankpistol") >= 0
			|| prefabName.IndexOf("fuel_pump") >= 0
			|| prefabName.IndexOf("FuelPump") >= 0
			|| prefabName.IndexOf("FuelTank_02_Pump") >= 0)
		{
			m_TmpFoundStations.Insert(entity);
			Print(string.Format("[JobFuelStationManager] MATCH composant: '%1'",
				prefabName), LogLevel.NORMAL);
			return true;
		}

		// Diagnostic : prefabs qui PARAISSENT lies aux stations essence mais non matches.
		// Les murs (RetainingWallSection) sont volontairement exclus car ils apparaissent
		// aussi hors stations essence.
		if (prefabName.IndexOf("FuelStation") >= 0
			|| prefabName.IndexOf("fuel_station") >= 0
			|| prefabName.IndexOf("Pump_") >= 0)
		{
			m_DiagnosticNearMatchCount = m_DiagnosticNearMatchCount + 1;
			if (m_DiagnosticNearMatchCount <= 20) // cap pour ne pas spammer
			{
				Print(string.Format("[JobFuelStationManager] NEAR-MATCH prefab trouve: '%1'",
					prefabName), LogLevel.WARNING);
			}
		}
		return true;
	}

	//------------------------------------------------------------------------------------------------
	// Helper statique : vrai si le prefab est une station essence (match tolerant)
	//------------------------------------------------------------------------------------------------
	static bool IsFuelStationPrefabName(string prefabName)
	{
		if (prefabName.IndexOf("FuelStation_E_01_V1") >= 0) return true;
		if (prefabName.IndexOf("FuelStation_E_01_building_small") >= 0) return true;
		if (prefabName.IndexOf("FuelStation_E_01_roof") >= 0) return true;
		if (prefabName.IndexOf("tankpistol") >= 0) return true;
		if (prefabName.IndexOf("fuel_pump") >= 0) return true;
		if (prefabName.IndexOf("FuelPump") >= 0) return true;
		if (prefabName.IndexOf("FuelTank_02_Pump") >= 0) return true;
		return false;
	}

	//------------------------------------------------------------------------------------------------
	// Trouve la station la plus proche d une position dans un rayon donne.
	// Retourne la cle de station (ou "" si rien trouve).
	//------------------------------------------------------------------------------------------------
	string FindNearestStationKey(vector pos, float radius)
	{
		string bestKey = "";
		float bestDistSq = radius * radius;

		foreach (string key, vector stationPos : m_StationPositions)
		{
			float dx = stationPos[0] - pos[0];
			float dz = stationPos[2] - pos[2];
			float distSq = dx * dx + dz * dz;
			if (distSq < bestDistSq)
			{
				bestDistSq = distSq;
				bestKey = key;
			}
		}
		return bestKey;
	}

	//------------------------------------------------------------------------------------------------
	// Verifie si une station est proche d une position (pour CanBeShownScript client).
	// Note : cette methode est appelee cote SERVEUR via RPC pour validation.
	// Cote CLIENT, utilise FindNearestStationKey directement (le cache est bootstrap au boot).
	//------------------------------------------------------------------------------------------------
	bool IsStationNearby(vector pos)
	{
		return FindNearestStationKey(pos, USAGE_RADIUS) != "";
	}

	//------------------------------------------------------------------------------------------------
	// Retourne la jauge d une station (0 si inconnue)
	//------------------------------------------------------------------------------------------------
	float GetStationFuel(string key)
	{
		float fuel = 0;
		m_StationFuel.Find(key, fuel);
		return fuel;
	}

	//------------------------------------------------------------------------------------------------
	// Consomme X litres d une station (atomique). Retourne les litres effectivement
	// consommes (peut etre < requested si station presque vide).
	//------------------------------------------------------------------------------------------------
	float ConsumeFuel(string key, float requested)
	{
		float current = GetStationFuel(key);
		if (current <= 0 || requested <= 0)
			return 0;

		float consumed = requested;
		if (consumed > current)
			consumed = current;

		m_StationFuel.Set(key, current - consumed);
		SaveToDisk();
		return consumed;
	}

	//------------------------------------------------------------------------------------------------
	// Remplit la station a 150L. Retourne le nombre de litres rajoutes.
	//------------------------------------------------------------------------------------------------
	float RefillStation(string key)
	{
		if (!m_StationPositions.Contains(key))
			return 0; // station inconnue

		float current = GetStationFuel(key);
		float added = STATION_MAX_FUEL - current;
		if (added <= 0)
			return 0; // deja pleine

		m_StationFuel.Set(key, STATION_MAX_FUEL);
		SaveToDisk();
		return added;
	}

	//------------------------------------------------------------------------------------------------
	// Enregistre une station dans la cache (appele si on la rencontre pas pendant Discover,
	// ex: scenario spawn tardif).
	//------------------------------------------------------------------------------------------------
	void RegisterStationIfNew(IEntity station)
	{
		if (!station) return;
		EntityPrefabData pd = station.GetPrefabData();
		if (!pd) return;
		if (!IsFuelStationPrefabName(pd.GetPrefabName())) return;

		vector pos = station.GetOrigin();

		// Clustering distance : si une station existe deja dans le rayon, c est la meme
		if (FindNearestStationKey(pos, CLUSTER_RADIUS) != "")
			return;

		// Nouvelle station : enregistre avec cle = position precise
		string key = BuildStationKey(pos);
		m_StationPositions.Set(key, pos);
		if (!m_StationFuel.Contains(key))
			m_StationFuel.Set(key, STATION_MAX_FUEL);
	}

	//------------------------------------------------------------------------------------------------
	// PERSISTANCE JSON
	//------------------------------------------------------------------------------------------------
	void SaveToDisk()
	{
		SCR_JsonSaveContext ctx = new SCR_JsonSaveContext();
		ctx.WriteValue("count", m_StationFuel.Count());
		// Prix admin (ajout, retro-compatible : si absent au load on reste a defaut)
		ctx.WriteValue("pricePerLiter", PRICE_PER_LITER);

		int idx = 0;
		foreach (string key, float fuel : m_StationFuel)
		{
			string prefix = "stations/" + idx.ToString() + "/";
			ctx.WriteValue(prefix + "key", key);
			ctx.WriteValue(prefix + "fuel", fuel);
			// Sauve aussi la position pour reconstruire le cache au load
			vector pos;
			if (m_StationPositions.Find(key, pos))
			{
				ctx.WriteValue(prefix + "posX", pos[0]);
				ctx.WriteValue(prefix + "posY", pos[1]);
				ctx.WriteValue(prefix + "posZ", pos[2]);
			}
			idx = idx + 1;
		}
		ctx.SaveToFile(SAVE_FILE);
	}

	//------------------------------------------------------------------------------------------------
	void LoadFromDisk()
	{
		if (m_Loaded) return;
		m_Loaded = true;
		if (!FileIO.FileExists(SAVE_FILE)) return;

		SCR_JsonLoadContext ctx = new SCR_JsonLoadContext();
		if (!ctx.LoadFromFile(SAVE_FILE)) return;

		int count = 0;
		ctx.ReadValue("count", count);

		// Charge le prix admin si present (sinon reste a PRICE_DEFAULT via l init du champ)
		float loadedPrice = 0;
		if (ctx.ReadValue("pricePerLiter", loadedPrice) && loadedPrice >= PRICE_MIN && loadedPrice <= PRICE_MAX)
			PRICE_PER_LITER = loadedPrice;

		for (int i = 0; i < count; i++)
		{
			string prefix = "stations/" + i.ToString() + "/";
			string key = "";
			float fuel = 0;
			float px = 0, py = 0, pz = 0;

			ctx.ReadValue(prefix + "key", key);
			ctx.ReadValue(prefix + "fuel", fuel);
			ctx.ReadValue(prefix + "posX", px);
			ctx.ReadValue(prefix + "posY", py);
			ctx.ReadValue(prefix + "posZ", pz);

			if (key != "")
			{
				m_StationFuel.Set(key, fuel);
				if (px != 0 || pz != 0)
					m_StationPositions.Set(key, Vector(px, py, pz));
			}
		}
		Print(string.Format("[JobFuelStationManager] %1 stations chargees depuis disque.",
			count.ToString()), LogLevel.NORMAL);
	}
}
