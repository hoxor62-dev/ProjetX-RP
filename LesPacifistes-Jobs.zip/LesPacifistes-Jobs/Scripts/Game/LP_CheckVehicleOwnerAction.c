//------------------------------------------------------------------------------------------------
// LP_CheckVehicleOwnerAction.c
// Action "Verifier le proprietaire" visible UNIQUEMENT pour les metiers POLICIER / MILITAIRE.
// A placer via Workbench sur l ActionsManagerComponent des prefabs vehicules.
//
// Comportement :
//   - Le client fait l action -> envoie une RPC au serveur avec le RplId du vehicule
//   - Le serveur lit le composant LP_VehiclePersistComponent sur le vehicule
//   - Le serveur recupere le nom RP du proprietaire via JobIdentityManager
//   - Le serveur envoie un hint HUD au client avec le resultat
//------------------------------------------------------------------------------------------------

class LP_CheckVehicleOwnerAction : ScriptedUserAction
{
	//------------------------------------------------------------------------------------------------
	// Autorise l usage uniquement pour les metiers POLICIER et MILITAIRE
	//------------------------------------------------------------------------------------------------
	protected bool CanUseCheckOwner(IEntity user)
	{
		if (!user) return false;
		JobCharacterJobComponent jcjc = JobCharacterJobComponent.Cast(
			user.FindComponent(JobCharacterJobComponent));
		if (!jcjc) return false;
		EJobType job = jcjc.GetJob();
		return (job == EJobType.POLICIER || job == EJobType.MILITAIRE);
	}

	//------------------------------------------------------------------------------------------------
	override bool CanBeShownScript(IEntity user)
	{
		return CanUseCheckOwner(user);
	}

	//------------------------------------------------------------------------------------------------
	override bool CanBePerformedScript(IEntity user)
	{
		return CanUseCheckOwner(user);
	}

	//------------------------------------------------------------------------------------------------
	override bool GetActionNameScript(out string outName)
	{
		outName = "Verifier le proprietaire";
		return true;
	}

	//------------------------------------------------------------------------------------------------
	override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
	{
		PlayerController pc = PlayerController.Cast(GetGame().GetPlayerController());
		if (!pc) return;
		if (pUserEntity != pc.GetControlledEntity()) return;

		if (!CanUseCheckOwner(pUserEntity))
			return;

		// Recupere le RplId du vehicule (pOwnerEntity) pour envoi au serveur
		RplComponent rpl = RplComponent.Cast(pOwnerEntity.FindComponent(RplComponent));
		if (!rpl) return;

		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;

		jpc.ClientAskCheckVehicleOwner(rpl.Id());
	}
}
