//------------------------------------------------------------------------------------------------
// JobMarketManager.c
// Singleton serveur gerant le cours dynamique de 5 items :
//   - ROCK (Roche), WOOD (Planche), APPLE (Jus de pomme),
//   - CANNABIS (Cannabis traite), COCAINE (Cocaine traitee).
//
// Logique :
//   - Cours en pourcentage stocke par item (-50% / +100% bornes)
//   - A chaque vente : -1% sur l item vendu
//   - Toutes les heures : drift vers 0% de +/- 1% (regulation naturelle)
//   - Persistance JSON ($profile:LesPacifistesJobs/market.json)
//
// Prix de vente effectif = prix_base * (1 + cours/100)
//   Exemple : prix_base = 26, cours = -23 -> 26 * 0.77 = 20.02 = 20 capsules
//             prix_base = 26, cours = +50 -> 26 * 1.50 = 39 capsules
//------------------------------------------------------------------------------------------------

enum EMarketItem
{
	NONE = 0,
	ROCK = 1,
	WOOD = 2,
	APPLE = 3,
	CANNABIS = 4,
	COCAINE = 5,
	WHEAT = 6
}

class JobMarketManager
{
	static ref JobMarketManager s_Instance;
	
	const string SAVE_PATH = "$profile:LesPacifistesJobs/market.json";
	const int MIN_COURS = -50;   // -50% prix de vente min
	const int MAX_COURS = 100;   // +100% prix de vente max
	
	// Tick interne frequent : verifie toutes les 60 secondes si on doit faire un drift / un event
	// (au lieu d un seul CallLater de 1h ou 4h qui peut etre fragile)
	const int TICK_INTERVAL_MS = 60000;
	
	const int DRIFT_INTERVAL_SECONDS = 3600;        // drift naturel toutes les 1h (en secondes)
	const int EVENT_INTERVAL_SECONDS = 7200;       // evenement toutes les 4h (en secondes)
	const int SELL_DECREASE = 2; // -1% par vente
	
	// Drift random horaire (Idee 1) : tirage entre DRIFT_MIN et DRIFT_MAX
	// Legerement biaise vers le positif : -1 a +2 (moyenne theorique : +0.5%/h)
	const int DRIFT_MIN = -15;
	const int DRIFT_MAX = 20;
	
	// Evenements aleatoires (Idee 4)
	const float EVENT_CHANCE = 0.50;            // 25% qu un evenement se declenche
	const int EVENT_PENURIE_BONUS = 30;         // +30% pour "Penurie"
	const int EVENT_RECOLTE_PENALTY = -15;      // -15% pour "Recolte exceptionnelle"
	const int EVENT_RAID_PENALTY = -20;         // -20% pour "Saisie policiere"
	const int EVENT_MODE_BONUS = 20;            // +20% pour "Effet de mode"
	const int EVENT_CONTRABAND_BONUS = 25;      // +25% pour "Demande clandestine"
	
	// Timestamps internes pour declencher les ticks (en secondes unix)
	int m_LastDriftUnix;
	int m_LastEventUnix;
	
	// Cours actuels en pourcentage (-50 a +100)
	ref map<int, int> m_Cours;  // EMarketItem -> percent
	
	//------------------------------------------------------------------------------------------------
	void JobMarketManager()
	{
		m_Cours = new map<int, int>();
		// Initialise tous les items a 0%
		m_Cours.Set(EMarketItem.ROCK, 0);
		m_Cours.Set(EMarketItem.WOOD, 0);
		m_Cours.Set(EMarketItem.APPLE, 0);
		m_Cours.Set(EMarketItem.CANNABIS, 0);
		m_Cours.Set(EMarketItem.COCAINE, 0);
		m_Cours.Set(EMarketItem.WHEAT, 0);
	}
	
	//------------------------------------------------------------------------------------------------
	static JobMarketManager GetInstance()
	{
		if (!s_Instance)
		{
			s_Instance = new JobMarketManager();
			s_Instance.LoadFromDisk();
			// Tick frequent (60s) qui verifie en interne quand declencher drift / event
			// Plus robuste qu un CallLater de 1h/4h qui peut etre fragile
			GetGame().GetCallqueue().CallLater(s_Instance.Tick, TICK_INTERVAL_MS, true);
			Print("[JobMarketManager] Instance creee, tick lance toutes les 60 secondes", LogLevel.NORMAL);
		}
		return s_Instance;
	}
	
	//------------------------------------------------------------------------------------------------
	// Tick frequent appelé toutes les 60s : verifie si on doit declencher drift ou event
	//------------------------------------------------------------------------------------------------
	void Tick()
	{
		int now = System.GetUnixTime();
		
		// Initialisation des timestamps au premier tick
		if (m_LastDriftUnix == 0)
			m_LastDriftUnix = now;
		if (m_LastEventUnix == 0)
			m_LastEventUnix = now;
		
		// Drift horaire
		if (now - m_LastDriftUnix >= DRIFT_INTERVAL_SECONDS)
		{
			Print("[JobMarketManager] Tick : declenche drift random horaire", LogLevel.NORMAL);
			DoHourlyDrift();
			m_LastDriftUnix = now;
		}
		
		// Evenement aleatoire (4h)
		if (now - m_LastEventUnix >= EVENT_INTERVAL_SECONDS)
		{
			Print("[JobMarketManager] Tick : tirage evenement aleatoire", LogLevel.NORMAL);
			DoRandomEvent();
			m_LastEventUnix = now;
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Retourne le cours actuel d un item en %
	//------------------------------------------------------------------------------------------------
	int GetCours(EMarketItem item)
	{
		int val;
		if (m_Cours.Find(item, val))
			return val;
		return 0;
	}
	
	//------------------------------------------------------------------------------------------------
	// Setter direct utilise UNIQUEMENT cote client par RpcDo_ReceiveMarketCours pour
	// synchroniser le cache du client avec les vraies valeurs du serveur.
	// Ne PAS appeler cote serveur (ne sauvegarde pas sur disque, n applique pas les regles).
	//------------------------------------------------------------------------------------------------
	void ClientSetCours(EMarketItem item, int cours)
	{
		m_Cours.Set(item, ClampCours(cours));
	}
	
	//------------------------------------------------------------------------------------------------
	// Calcule le prix de vente effectif applique au prix de base, avec le cours actuel
	//------------------------------------------------------------------------------------------------
	int GetEffectivePrice(EMarketItem item, int basePrice)
	{
		int cours = GetCours(item);
		// prix_effectif = basePrice * (1 + cours/100)
		// On utilise une multiplication entiere pour eviter les float
		int adjusted = basePrice + (basePrice * cours) / 100;
		if (adjusted < 0)
			adjusted = 0;
		return adjusted;
	}
	
	//------------------------------------------------------------------------------------------------
	// Enregistre une vente : -1% sur le cours de l item (limite a MIN_COURS)
	//------------------------------------------------------------------------------------------------
	void RecordSale(EMarketItem item)
	{
		int current = GetCours(item);
		int newCours = current - SELL_DECREASE;
		if (newCours < MIN_COURS)
			newCours = MIN_COURS;
		m_Cours.Set(item, newCours);
		SaveToDisk();
	}
	
	//------------------------------------------------------------------------------------------------
	// Drift naturel horaire : chaque cours bouge aleatoirement entre DRIFT_MIN et DRIFT_MAX
	// Biais positif (-1 a +2) pour que les cours montent legerement sans activite
	//------------------------------------------------------------------------------------------------
	void DoHourlyDrift()
	{
		bool dirty = false;
		array<int> keys = new array<int>();
		foreach (int key, int val : m_Cours)
		{
			keys.Insert(key);
		}
		foreach (int key2 : keys)
		{
			int val2 = m_Cours.Get(key2);
			int drift = Math.RandomInt(DRIFT_MIN, DRIFT_MAX + 1);
			int newVal = ClampCours(val2 + drift);
			if (newVal != val2)
			{
				m_Cours.Set(key2, newVal);
				dirty = true;
				Print(string.Format("[JobMarketManager] Drift : %1 %2 -> %3 (delta %4)",
					GetItemLabel(key2), val2, newVal, drift), LogLevel.NORMAL);
			}
		}
		if (dirty)
			SaveToDisk();
	}
	
	//------------------------------------------------------------------------------------------------
	// Evenement aleatoire toutes les 4h - 25% de chance qu un evenement boost ou penalise un item
	// Notifie tous les joueurs via chat avec "[ALERTE BOURSE]"
	//------------------------------------------------------------------------------------------------
	void DoRandomEvent()
	{
		// Tirage de chance
		if (Math.RandomFloat01() > EVENT_CHANCE)
			return;
		
		// Selection aleatoire d un item (1 a 6 = ROCK, WOOD, APPLE, CANNABIS, COCAINE, WHEAT)
		int itemRoll = Math.RandomInt(1, 7); // [1, 6]
		EMarketItem item = itemRoll;
		string itemLabel = GetItemLabel(item);
		
		// Selection aleatoire d un evenement (5 events possibles, 0 a 4)
		int eventRoll = Math.RandomInt(0, 5); // [0, 4]
		int delta = 0;
		string eventMsg = "";
		
		switch (eventRoll)
		{
			case 0:
				// Penurie : forte hausse
				delta = EVENT_PENURIE_BONUS;
				eventMsg = string.Format(
					"[ALERTE BOURSE] Penurie de %1 detectee ! Les prix explosent (+%2%%)",
					itemLabel, delta);
				break;
			case 1:
				// Recolte exceptionnelle : baisse
				delta = EVENT_RECOLTE_PENALTY;
				eventMsg = string.Format(
					"[ALERTE BOURSE] Recolte exceptionnelle de %1 - le marche est sature (%2%%)",
					itemLabel, delta);
				break;
			case 2:
				// Saisie policiere : baisse (les acheteurs ont peur)
				delta = EVENT_RAID_PENALTY;
				eventMsg = string.Format(
					"[ALERTE BOURSE] Saisie policiere de %1 - la demande chute (%2%%)",
					itemLabel, delta);
				break;
			case 3:
				// Effet de mode : hausse moderee
				delta = EVENT_MODE_BONUS;
				eventMsg = string.Format(
					"[ALERTE BOURSE] %1 est tres demande en ville (+%2%%)",
					itemLabel, delta);
				break;
			case 4:
				// Demande clandestine : forte hausse
				delta = EVENT_CONTRABAND_BONUS;
				eventMsg = string.Format(
					"[ALERTE BOURSE] Demande clandestine pour %1 - les prix grimpent (+%2%%)",
					itemLabel, delta);
				break;
		}
		
		// Applique le delta
		int current = GetCours(item);
		int newVal = ClampCours(current + delta);
		m_Cours.Set(item, newVal);
		SaveToDisk();
		
		// Notif chat a TOUS les joueurs
		BroadcastEventNotification(eventMsg);
		
		Print(string.Format("[JobMarketManager] Evenement : %1 (%2 -> %3)",
			eventMsg, current, newVal), LogLevel.NORMAL);
	}
	
	//------------------------------------------------------------------------------------------------
	// Notifie tous les joueurs connectes via chat
	//------------------------------------------------------------------------------------------------
	void BroadcastEventNotification(string msg)
	{
		PlayerManager pm = GetGame().GetPlayerManager();
		if (!pm)
			return;
		array<int> allPlayers = new array<int>();
		pm.GetPlayers(allPlayers);
		foreach (int pid : allPlayers)
		{
			JobManager.GetInstance().NotifyPlayerChat(pid, msg);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Retourne le label d un item
	//------------------------------------------------------------------------------------------------
	static string GetItemLabel(EMarketItem item)
	{
		switch (item)
		{
			case EMarketItem.ROCK:     return "Roche";
			case EMarketItem.WOOD:     return "Planche";
			case EMarketItem.APPLE:    return "Jus de pomme";
			case EMarketItem.CANNABIS: return "Cannabis";
			case EMarketItem.COCAINE:  return "Cocaine";
			case EMarketItem.WHEAT:    return "Sac de farine";
		}
		return "";
	}
	
	//------------------------------------------------------------------------------------------------
	// Mapping EMineralType (minerais) -> EMarketItem
	//------------------------------------------------------------------------------------------------
	static EMarketItem FromMineralType(EMineralType m)
	{
		switch (m)
		{
			case EMineralType.ROCK:     return EMarketItem.ROCK;
			case EMineralType.WOOD:     return EMarketItem.WOOD;
			case EMineralType.APPLE:    return EMarketItem.APPLE;
			case EMineralType.CANNABIS: return EMarketItem.CANNABIS;
			case EMineralType.COCAINE:  return EMarketItem.COCAINE;
			case EMineralType.WHEAT:    return EMarketItem.WHEAT;
		}
		return EMarketItem.NONE;
	}
	
	//------------------------------------------------------------------------------------------------
	// Persistance JSON
	//------------------------------------------------------------------------------------------------
	void SaveToDisk()
	{
		SCR_JsonSaveContext ctx = new SCR_JsonSaveContext();
		ctx.WriteValue("rock", GetCours(EMarketItem.ROCK));
		ctx.WriteValue("wood", GetCours(EMarketItem.WOOD));
		ctx.WriteValue("apple", GetCours(EMarketItem.APPLE));
		ctx.WriteValue("cannabis", GetCours(EMarketItem.CANNABIS));
		ctx.WriteValue("cocaine", GetCours(EMarketItem.COCAINE));
		ctx.WriteValue("wheat", GetCours(EMarketItem.WHEAT));
		ctx.SaveToFile(SAVE_PATH);
	}
	
	void LoadFromDisk()
	{
		SCR_JsonLoadContext ctx = new SCR_JsonLoadContext();
		if (!ctx.LoadFromFile(SAVE_PATH))
			return;
		int rock = 0, wood = 0, apple = 0, cannabis = 0, cocaine = 0, wheat = 0;
		ctx.ReadValue("rock", rock);
		ctx.ReadValue("wood", wood);
		ctx.ReadValue("apple", apple);
		ctx.ReadValue("cannabis", cannabis);
		ctx.ReadValue("cocaine", cocaine);
		ctx.ReadValue("wheat", wheat);
		m_Cours.Set(EMarketItem.ROCK, ClampCours(rock));
		m_Cours.Set(EMarketItem.WOOD, ClampCours(wood));
		m_Cours.Set(EMarketItem.APPLE, ClampCours(apple));
		m_Cours.Set(EMarketItem.CANNABIS, ClampCours(cannabis));
		m_Cours.Set(EMarketItem.COCAINE, ClampCours(cocaine));
		m_Cours.Set(EMarketItem.WHEAT, ClampCours(wheat));
		Print("[JobMarketManager] Cours charges depuis disque", LogLevel.NORMAL);
	}
	
	int ClampCours(int val)
	{
		if (val < MIN_COURS) return MIN_COURS;
		if (val > MAX_COURS) return MAX_COURS;
		return val;
	}
}
