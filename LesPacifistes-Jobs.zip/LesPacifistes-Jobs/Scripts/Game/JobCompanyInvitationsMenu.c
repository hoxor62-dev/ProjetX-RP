//------------------------------------------------------------------------------------------------
// JobCompanyInvitationsMenu.c
// Menu "Mes invitations" - ouvert depuis le PNJ Maire quand le joueur a une invitation.
//
// V1 : une seule invitation max par joueur. Affiche les details et propose Accepter/Refuser.
// A l acceptation : le joueur devient employe + son metier devient celui de l entreprise.
//------------------------------------------------------------------------------------------------

class JobCompanyInvitationsMenu : ChimeraMenuBase
{
	Widget m_RootWidget;
	TextWidget m_TitleText;
	TextWidget m_InfoText;
	ButtonWidget m_BtnAccept;
	ButtonWidget m_BtnRefuse;
	ButtonWidget m_BtnBack;
	
	// Donnees pre-chargees par RpcDo_ReceiveInvitation
	static string s_CompanyName;
	static string s_OwnerName;
	static int s_JobType;
	static int s_CreatedAt;
	
	static JobCompanyInvitationsMenu s_Instance;
	
	//------------------------------------------------------------------------------------------------
	static void SetPendingData(string companyName, string ownerName, int jobType, int createdAt)
	{
		s_CompanyName = companyName;
		s_OwnerName = ownerName;
		s_JobType = jobType;
		s_CreatedAt = createdAt;
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuOpen()
	{
		super.OnMenuOpen();
		s_Instance = this;
		JobFocusHandler.ClearRegistry();
		
		m_RootWidget = GetRootWidget();
		if (!m_RootWidget) return;
		
		m_TitleText = TextWidget.Cast(m_RootWidget.FindAnyWidget("TitleText"));
		m_InfoText = TextWidget.Cast(m_RootWidget.FindAnyWidget("InfoText"));
		m_BtnAccept = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnAccept"));
		m_BtnRefuse = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnRefuse"));
		m_BtnBack = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnBack"));
		
		BuildText();
		
		if (m_BtnAccept)
		{
			InvitationsActionHandler h = new InvitationsActionHandler();
			h.m_Menu = this;
			h.m_Action = "accept";
			m_BtnAccept.AddHandler(h);
			JobFocusHandler.Attach(m_BtnAccept);
		}
		if (m_BtnRefuse)
		{
			InvitationsActionHandler h = new InvitationsActionHandler();
			h.m_Menu = this;
			h.m_Action = "refuse";
			m_BtnRefuse.AddHandler(h);
			JobFocusHandler.Attach(m_BtnRefuse);
		}
		if (m_BtnBack)
		{
			InvitationsActionHandler h = new InvitationsActionHandler();
			h.m_Menu = this;
			h.m_Action = "back";
			m_BtnBack.AddHandler(h);
			JobFocusHandler.Attach(m_BtnBack);
			GetGame().GetWorkspace().SetFocusedWidget(m_BtnBack);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuClose()
	{
		if (s_Instance == this)
			s_Instance = null;
		super.OnMenuClose();
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuUpdate(float tDelta)
	{
		super.OnMenuUpdate(tDelta);
		if (GetGame().GetInputManager().GetActionValue("MenuBack") > 0.5)
			CloseMenuInternal();
	}
	
	//------------------------------------------------------------------------------------------------
	void BuildText()
	{
		if (m_TitleText)
			m_TitleText.SetText("Mes invitations");
		
		if (m_InfoText)
		{
			string jobLabel = JobData.GetJobLabel(s_JobType);
			
			// Calcule le temps restant (24h - elapsed)
			int now = System.GetUnixTime();
			int elapsed = now - s_CreatedAt;
			int remainingSeconds = 86400 - elapsed;
			if (remainingSeconds < 0) remainingSeconds = 0;
			int remainingHours = remainingSeconds / 3600;
			int remainingMinutes = (remainingSeconds - remainingHours * 3600) / 60;
			
			string t = "";
			t = t + string.Format("Entreprise : %1\n", s_CompanyName);
			t = t + string.Format("Patron     : %1\n", s_OwnerName);
			t = t + string.Format("Metier     : %1\n", jobLabel);
			t = t + "\n";
			t = t + string.Format("Temps restant : %1h %2m\n", remainingHours.ToString(),
				remainingMinutes.ToString());
			t = t + "\n";
			t = t + "Si vous acceptez, votre metier deviendra automatiquement\n";
			t = t + "celui de l entreprise.";
			m_InfoText.SetText(t);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void OnAction(string action)
	{
		if (action == "back")
		{
			CloseMenuInternal();
			return;
		}
		
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		
		if (action == "accept")
		{
			jpc.ClientAskAcceptInvitation();
			CloseMenuInternal();
			return;
		}
		if (action == "refuse")
		{
			jpc.ClientAskRefuseInvitation();
			CloseMenuInternal();
			return;
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void CloseMenuInternal()
	{
		GetGame().GetMenuManager().CloseMenu(this);
	}
	
	static JobCompanyInvitationsMenu GetOpenMenu() { return s_Instance; }
}

//------------------------------------------------------------------------------------------------
class InvitationsActionHandler : ScriptedWidgetEventHandler
{
	JobCompanyInvitationsMenu m_Menu;
	string m_Action;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.OnAction(m_Action);
		return true;
	}
}
