//------------------------------------------------------------------------------------------------
// LP_NotificationManager.c
// Systeme de notifications HUD centre ecran, en remplacement des hints Bohemia.
//
// POURQUOI
// Toutes les notifications du mod passaient par SCR_HintManagerComponent.ShowCustomHint,
// qui affiche la petite bulle vanilla en haut de l ecran avec un style impose et un titre
// generique ("Emploi") pour absolument tout : amendes, paie, alertes, SMS...
//
// CE SYSTEME
//   - Un panneau centre ecran, fond sombre translucide, barre d accent coloree a gauche
//   - Le TITRE et la COULEUR sont deduits automatiquement du prefixe du message
//     ("[JUSTICE] Amende de 500 capsules" -> titre JUSTICE, barre rouge, corps sans prefixe)
//   - File d attente : les notifications s enchainent au lieu de s ecraser
//   - Fondu entree / sortie
//   - Les durees d affichage existantes sont conservees telles quelles
//
// POINT D ENTREE UNIQUE
//   LP_NotificationManager.Show(message, title, duration)
//   - title vide ""  -> le titre est deduit du prefixe du message
//   - title renseigne -> ce titre est utilise tel quel (cas ALERTE BRAQUAGE, TRESOR RARE...)
//   La signature est volontairement identique a ShowCustomHint pour que le remplacement
//   des appels existants soit mecanique.
//
// CLIENT ONLY : ce systeme manipule des widgets. Ne jamais l appeler cote serveur dedie.
//
// REGLAGE DE LA POSITION
//   La hauteur du panneau se regle dans LP_NotificationHUD.layout, sur la ligne
//   "Padding 0 0 0 220" du widget NotifRoot. Le panneau est centre verticalement puis
//   remonte de 220 px pour ne pas masquer le viseur. Mettre 0 pour un centrage exact,
//   augmenter la valeur pour le remonter davantage.
//------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------------------
// Une notification en attente d affichage
//------------------------------------------------------------------------------------------------
class LP_NotifEntry
{
	string m_Title;
	string m_Message;
	float m_Duration;
	int m_R;
	int m_G;
	int m_B;
}

//------------------------------------------------------------------------------------------------
class LP_NotificationManager
{
	protected static ref LP_NotificationManager s_Instance;

	protected const string LAYOUT_PATH = "UI/layouts/LP_NotificationHUD.layout";

	// Cadence d animation (~30 fps). Le ticker ne tourne QUE pendant un affichage.
	protected const int TICK_MS = 33;

	protected const float FADE_IN_SEC = 0.18;
	protected const float FADE_OUT_SEC = 0.40;

	// Au-dela, on jette les plus anciennes pour ne pas accumuler un retard absurde
	// (ex : rafale d amendes ou de ventes).
	protected const int MAX_QUEUE = 6;

	// DECOUPE DU TEXTE (correctif 11 nov 2026)
	// Le RichTextWidget ne passe pas a la ligne tout seul : un message long sortait du
	// panneau et se faisait couper au bord droit. Aucun mot-cle de wrap n existe dans les
	// layouts du mod, et un mot-cle inconnu casserait le parse du bloc entier. On decoupe
	// donc manuellement en inserant des retours a la ligne, comme le fait deja
	// JobSmsConversationMenu pour l historique des SMS.
	//
	// 64 caracteres : mesure sur le panneau de 640 de large en police 18. Environ 73
	// caracteres rentrent avant la coupure, on garde de la marge pour les lettres larges
	// (M, W, majuscules). A reduire si tu elargis la police, a augmenter si tu elargis
	// le panneau via WidthOverride dans le layout.
	protected const int WRAP_MAX_CHARS = 64;

	// Plafond de lignes affichees. Protege contre les messages tres longs (liste
	// d inventaire admin par exemple) qui feraient un panneau plus haut que l ecran.
	protected const int WRAP_MAX_LINES = 10;

	// Etats de la machine d affichage
	protected const int ST_IDLE = 0;
	protected const int ST_FADE_IN = 1;
	protected const int ST_HOLD = 2;
	protected const int ST_FADE_OUT = 3;

	protected Widget m_Root;
	protected Widget m_PanelW;
	protected ImageWidget m_AccentW;
	protected TextWidget m_TitleW;
	protected RichTextWidget m_TextW;

	protected ref array<ref LP_NotifEntry> m_Queue = new array<ref LP_NotifEntry>();

	protected int m_State = ST_IDLE;
	protected float m_Timer = 0;
	protected float m_HoldDuration = 0;
	protected bool m_TickRunning = false;
	protected bool m_LayoutFailed = false;

	//------------------------------------------------------------------------------------------------
	static LP_NotificationManager GetInstance()
	{
		if (!s_Instance)
			s_Instance = new LP_NotificationManager();
		return s_Instance;
	}

	//------------------------------------------------------------------------------------------------
	// POINT D ENTREE PRINCIPAL. Signature identique a ShowCustomHint.
	//   message  : texte, eventuellement prefixe par "[CATEGORIE] "
	//   title    : "" pour deduire le titre du prefixe, sinon titre impose
	//   duration : duree d affichage en secondes (hors fondus)
	//------------------------------------------------------------------------------------------------
	static void Show(string message, string title, float duration)
	{
		if (message == "")
			return;
		GetInstance().Enqueue(message, title, duration);
	}

	//------------------------------------------------------------------------------------------------
	// Variante courte : titre deduit, duree par defaut 6s (equivalent de l ancien hint "Emploi").
	//------------------------------------------------------------------------------------------------
	static void ShowAuto(string message)
	{
		Show(message, "", 6.0);
	}

	//------------------------------------------------------------------------------------------------
	void Enqueue(string message, string titleOverride, float duration)
	{
		// Pas de widgets cote serveur dedie : on sort silencieusement.
		if (!GetGame().GetWorkspace())
			return;
		if (m_LayoutFailed)
			return;

		string prefix = "";
		string body = message;
		ParsePrefix(message, prefix, body);

		string title = titleOverride;
		if (title == "")
			title = prefix;
		if (title == "")
			title = "INFORMATION";
		title.ToUpper();

		int r = 0;
		int g = 0;
		int b = 0;
		GetAccentColor(prefix, r, g, b);

		LP_NotifEntry e = new LP_NotifEntry();
		e.m_Title = title;
		e.m_Message = body;
		e.m_Duration = duration;
		if (e.m_Duration < 1.0)
			e.m_Duration = 1.0;
		e.m_R = r;
		e.m_G = g;
		e.m_B = b;

		m_Queue.Insert(e);

		// Garde-fou anti-accumulation : on sacrifie les plus anciennes.
		while (m_Queue.Count() > MAX_QUEUE)
			m_Queue.Remove(0);

		StartTick();
	}

	//------------------------------------------------------------------------------------------------
	// ===== PARSING DU PREFIXE =====
	//------------------------------------------------------------------------------------------------

	//------------------------------------------------------------------------------------------------
	// "[JUSTICE] Amende de 500 capsules" -> outPrefix="JUSTICE", outBody="Amende de 500 capsules"
	// Retourne false si le message n a pas de prefixe : outBody vaut alors le message entier.
	// Enforce n a pas de regex ni de Split, on parcourt les caracteres.
	//------------------------------------------------------------------------------------------------
	protected bool ParsePrefix(string message, out string outPrefix, out string outBody)
	{
		outPrefix = "";
		outBody = message;

		int len = message.Length();
		if (len < 3)
			return false;
		if (message.Get(0) != "[")
			return false;

		int close = -1;
		for (int i = 1; i < len; i++)
		{
			if (message.Get(i) == "]")
			{
				close = i;
				break;
			}
		}

		// "[]" ou crochet jamais ferme : on ne touche a rien
		if (close < 2)
			return false;

		outPrefix = message.Substring(1, close - 1);

		int bodyStart = close + 1;
		// Saute l espace de separation apres le crochet fermant
		if (bodyStart < len && message.Get(bodyStart) == " ")
			bodyStart = bodyStart + 1;

		// Substring crashe si start + length depasse : on borne systematiquement
		int avail = len - bodyStart;
		if (avail > 0)
			outBody = message.Substring(bodyStart, avail);
		else
			outBody = "";

		return true;
	}

	//------------------------------------------------------------------------------------------------
	// Couleur d accent selon la famille de notification.
	// Les prefixes proviennent du releve des messages reellement utilises dans le mod.
	//------------------------------------------------------------------------------------------------
	protected void GetAccentColor(string prefix, out int r, out int g, out int b)
	{
		// GAIN / ARGENT ENTRANT : vert emeraude
		if (prefix == "PAIE" || prefix == "BANQUE" || prefix == "ATM" || prefix == "VENTE"
		 || prefix == "RECOLTE" || prefix == "MINING" || prefix == "FONTE" || prefix == "TRESOR"
		 || prefix == "BONPOINT" || prefix == "VALIDE")
		{
			r = 64; g = 200; b = 128;
			return;
		}

		// DEPENSE / COMMERCE : or
		if (prefix == "BOUTIQUE" || prefix == "DEALER" || prefix == "S105 PURGER")
		{
			r = 230; g = 185; b = 70;
			return;
		}

		// SANCTION / JUSTICE : rouge
		if (prefix == "JUSTICE" || prefix == "CASIER" || prefix == "FOURRIERE"
		 || prefix == "VOL" || prefix == "AMENDE")
		{
			r = 228; g = 76; b = 76;
			return;
		}

		// ALERTE : orange
		if (prefix == "BRAQUAGE" || prefix == "ALERTE BOURSE" || prefix == "URGENCES")
		{
			r = 245; g = 140; b = 50;
			return;
		}

		// SANTE : rose
		if (prefix == "HOPITAL" || prefix == "SOIN")
		{
			r = 240; g = 110; b = 140;
			return;
		}

		// AUTORITE : violet
		if (prefix == "ADMIN" || prefix == "PRESIDENT" || prefix == "MAIRE")
		{
			r = 170; g = 120; b = 230;
			return;
		}

		// SOCIAL / COMMUNICATION : bleu
		if (prefix == "GANG" || prefix == "SMS" || prefix == "TELEPHONE" || prefix == "ENTREPRISE")
		{
			r = 90; g = 160; b = 240;
			return;
		}

		// VEHICULE : cyan
		if (prefix == "GARAGE" || prefix == "VEHICULE" || prefix == "LOCATION"
		 || prefix == "ASSURANCE" || prefix == "DEPANNEUSE" || prefix == "STATION")
		{
			r = 70; g = 200; b = 215;
			return;
		}

		// DEFAUT (EMPLOI, QUETE, INVENTAIRE, IDENTITE, MUNITIONS, inconnus) : bleu-gris clair
		r = 150; g = 172; b = 205;
	}

	//------------------------------------------------------------------------------------------------
	// ===== DECOUPE DU TEXTE =====
	// Portage de la logique eprouvee de JobSmsConversationMenu. Les classes Enforce ne
	// partagent pas leurs methodes, d ou cette copie locale plutot qu un appel croise.
	//------------------------------------------------------------------------------------------------

	//------------------------------------------------------------------------------------------------
	// Decoupe le texte a maxWidth caracteres par ligne, en respectant les retours a la
	// ligne deja presents, puis plafonne le nombre de lignes.
	//------------------------------------------------------------------------------------------------
	protected string WrapText(string text, int maxWidth)
	{
		if (text == "" || maxWidth < 20)
			return text;

		string result = "";
		int textLen = text.Length();
		int lineStart = 0;

		// Parcourt chaque ligne existante (delimiteur \n)
		for (int i = 0; i <= textLen; i++)
		{
			bool isEnd = (i == textLen);
			bool isNewline = false;
			if (!isEnd)
			{
				string c = text.Substring(i, 1);
				if (c == "\n")
					isNewline = true;
			}

			if (isNewline || isEnd)
			{
				int lineLen = i - lineStart;
				if (lineLen <= 0)
				{
					if (isNewline)
						result = result + "\n";
					lineStart = i + 1;
					continue;
				}
				string line = text.Substring(lineStart, lineLen);
				result = result + WrapSingleLine(line, maxWidth);
				if (isNewline)
					result = result + "\n";
				lineStart = i + 1;
			}
		}

		return ClampLines(result, WRAP_MAX_LINES);
	}

	//------------------------------------------------------------------------------------------------
	// Decoupe une ligne unique, en coupant de preference sur un espace.
	//------------------------------------------------------------------------------------------------
	protected string WrapSingleLine(string line, int maxWidth)
	{
		int len = line.Length();
		if (len <= maxWidth)
			return line;

		string result = "";
		int pos = 0;
		while (pos < len)
		{
			int remaining = len - pos;
			if (remaining <= maxWidth)
			{
				// La fin de ligne rentre
				result = result + line.Substring(pos, remaining);
				break;
			}

			// On doit couper : cherche l espace le plus proche avant pos+maxWidth
			int cutAt = pos + maxWidth;
			int bestCut = -1;
			int minSearch = cutAt - 20;
			if (minSearch < pos + 20)
				minSearch = pos + 20;  // ne coupe pas trop tot

			for (int j = cutAt; j >= minSearch; j--)
			{
				if (j >= len) continue;
				string c = line.Substring(j, 1);
				if (c == " ")
				{
					bestCut = j;
					break;
				}
			}

			int chunkLen;
			int nextPos;
			if (bestCut >= 0)
			{
				chunkLen = bestCut - pos;
				nextPos = bestCut + 1;  // saute l espace
			}
			else
			{
				// Pas d espace trouve : coupe brute
				chunkLen = maxWidth;
				nextPos = pos + maxWidth;
			}

			result = result + line.Substring(pos, chunkLen) + "\n";
			pos = nextPos;
		}
		return result;
	}

	//------------------------------------------------------------------------------------------------
	// Limite le nombre de lignes affichees et signale la troncature.
	//------------------------------------------------------------------------------------------------
	protected string ClampLines(string text, int maxLines)
	{
		if (text == "" || maxLines < 1)
			return text;

		int len = text.Length();
		int lines = 1;
		int cutIndex = -1;

		for (int i = 0; i < len; i++)
		{
			if (text.Substring(i, 1) == "\n")
			{
				lines = lines + 1;
				if (lines > maxLines)
				{
					cutIndex = i;
					break;
				}
			}
		}

		if (cutIndex < 0)
			return text;

		return text.Substring(0, cutIndex) + "\n...";
	}

	//------------------------------------------------------------------------------------------------
	// ===== WIDGETS =====
	//------------------------------------------------------------------------------------------------

	protected bool EnsureWidgets()
	{
		if (m_Root)
			return true;
		if (m_LayoutFailed)
			return false;

		WorkspaceWidget ws = GetGame().GetWorkspace();
		if (!ws)
			return false;

		m_Root = ws.CreateWidgets(LAYOUT_PATH);
		if (!m_Root)
		{
			Print("[LP_NotificationManager] Impossible de creer le layout " + LAYOUT_PATH, LogLevel.ERROR);
			m_LayoutFailed = true;
			return false;
		}

		m_PanelW = m_Root.FindAnyWidget("NotifRoot");
		m_AccentW = ImageWidget.Cast(m_Root.FindAnyWidget("AccentBar"));
		m_TitleW = TextWidget.Cast(m_Root.FindAnyWidget("NotifTitle"));
		m_TextW = RichTextWidget.Cast(m_Root.FindAnyWidget("NotifText"));

		if (!m_PanelW || !m_AccentW || !m_TitleW || !m_TextW)
		{
			Print("[LP_NotificationManager] Widgets introuvables dans le layout (NotifRoot / AccentBar / NotifTitle / NotifText)", LogLevel.ERROR);
			m_LayoutFailed = true;
			return false;
		}

		m_PanelW.SetVisible(false);
		return true;
	}

	protected void SetPanelOpacity(float a)
	{
		if (m_PanelW)
			m_PanelW.SetOpacity(a);
	}

	//------------------------------------------------------------------------------------------------
	// ===== MACHINE D AFFICHAGE =====
	//------------------------------------------------------------------------------------------------

	protected void StartTick()
	{
		if (m_TickRunning)
			return;
		m_TickRunning = true;
		GetGame().GetCallqueue().CallLater(Tick, TICK_MS, true);
	}

	protected void StopTick()
	{
		if (!m_TickRunning)
			return;
		m_TickRunning = false;
		GetGame().GetCallqueue().Remove(Tick);
	}

	//------------------------------------------------------------------------------------------------
	void Tick()
	{
		float dt = TICK_MS / 1000.0;

		if (m_State == ST_IDLE)
		{
			if (m_Queue.Count() > 0)
				StartNext();
			else
				StopTick();
			return;
		}

		m_Timer = m_Timer + dt;

		if (m_State == ST_FADE_IN)
		{
			float ain = m_Timer / FADE_IN_SEC;
			if (ain >= 1.0)
			{
				ain = 1.0;
				m_State = ST_HOLD;
				m_Timer = 0;
			}
			SetPanelOpacity(ain);
			return;
		}

		if (m_State == ST_HOLD)
		{
			// Si une autre notification attend, on raccourcit legerement l affichage
			// pour que la file ne prenne pas trop de retard.
			float hold = m_HoldDuration;
			if (m_Queue.Count() > 0 && hold > 2.5)
				hold = 2.5;

			if (m_Timer >= hold)
			{
				m_State = ST_FADE_OUT;
				m_Timer = 0;
			}
			return;
		}

		if (m_State == ST_FADE_OUT)
		{
			float aout = 1.0 - (m_Timer / FADE_OUT_SEC);
			if (aout <= 0)
			{
				aout = 0;
				m_State = ST_IDLE;
				m_Timer = 0;
				if (m_PanelW)
					m_PanelW.SetVisible(false);
			}
			SetPanelOpacity(aout);
			return;
		}
	}

	//------------------------------------------------------------------------------------------------
	protected void StartNext()
	{
		if (m_Queue.Count() == 0)
			return;

		LP_NotifEntry e = m_Queue.Get(0);
		m_Queue.Remove(0);
		if (!e)
			return;

		if (!EnsureWidgets())
		{
			// Layout casse : on vide la file pour ne pas boucler indefiniment
			m_Queue.Clear();
			StopTick();
			return;
		}

		m_TitleW.SetText(e.m_Title);
		// Decoupe manuelle : le widget ne passe pas a la ligne seul, un message long
		// sortirait du panneau et serait coupe au bord droit.
		m_TextW.SetText(WrapText(e.m_Message, WRAP_MAX_CHARS));

		Color accent = Color.FromRGBA(e.m_R, e.m_G, e.m_B, 255);
		m_AccentW.SetColor(accent);
		m_TitleW.SetColor(accent);

		m_HoldDuration = e.m_Duration;
		m_State = ST_FADE_IN;
		m_Timer = 0;

		m_PanelW.SetVisible(true);
		SetPanelOpacity(0);
	}

	//------------------------------------------------------------------------------------------------
	// Vide la file et masque immediatement le panneau (changement de monde, deconnexion...).
	//------------------------------------------------------------------------------------------------
	void ClearAll()
	{
		m_Queue.Clear();
		m_State = ST_IDLE;
		m_Timer = 0;
		if (m_PanelW)
			m_PanelW.SetVisible(false);
		StopTick();
	}
}
