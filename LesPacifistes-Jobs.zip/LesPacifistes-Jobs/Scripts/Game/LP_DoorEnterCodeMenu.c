//------------------------------------------------------------------------------------------------
// LP_DoorEnterCodeMenu.c
// Menu client pour non-proprio : entre le code 4 chiffres. Si correct -> whitelist permanente.
//------------------------------------------------------------------------------------------------

class LP_DoorEnterCodeMenu : ChimeraMenuBase
{
	Widget m_Root;
	EditBoxWidget m_CodeInput;
	TextWidget m_StatusText;
	ButtonWidget m_BtnValidate;
	ButtonWidget m_BtnClose;
	
	RplId m_DoorRplId = RplId.Invalid();
	
	static LP_DoorEnterCodeMenu s_Instance;
	
	static RplId s_PendingRplId = RplId.Invalid();
	static void SetPendingTarget(RplId rplId) { s_PendingRplId = rplId; }
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuOpen()
	{
		super.OnMenuOpen();
		s_Instance = this;
		JobFocusHandler.ClearRegistry();
		
		if (s_PendingRplId.IsValid())
		{
			m_DoorRplId = s_PendingRplId;
			s_PendingRplId = RplId.Invalid();
		}
		
		m_Root = GetRootWidget();
		if (!m_Root) return;
		
		m_CodeInput = EditBoxWidget.Cast(m_Root.FindAnyWidget("CodeInput"));
		m_StatusText = TextWidget.Cast(m_Root.FindAnyWidget("StatusText"));
		m_BtnValidate = ButtonWidget.Cast(m_Root.FindAnyWidget("BtnValidate"));
		m_BtnClose = ButtonWidget.Cast(m_Root.FindAnyWidget("BtnClose"));
		
		AttachBtn(m_BtnValidate, "validate");
		AttachBtn(m_BtnClose, "close");
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuClose()
	{
		if (s_Instance == this) s_Instance = null;
		super.OnMenuClose();
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuUpdate(float tDelta)
	{
		super.OnMenuUpdate(tDelta);
		if (GetGame().GetInputManager().GetActionValue("MenuBack") > 0.5)
			CloseMenuInternal();
	}
	
	//------------------------------------------------------------------------------------------------
	void AttachBtn(ButtonWidget btn, string action)
	{
		if (!btn) return;
		LP_DoorEnterCodeBtnHandler h = new LP_DoorEnterCodeBtnHandler();
		h.m_Menu = this;
		h.m_Action = action;
		btn.AddHandler(h);
		JobFocusHandler.Attach(btn);
	}
	
	//------------------------------------------------------------------------------------------------
	// RPC serveur -> client : resultat (0 = OK, 1 = mauvais code, 2 = pas de code, 3 = erreur)
	void OnValidationResult(int result)
	{
		if (!m_StatusText) return;
		if (result == 0)
		{
			m_StatusText.SetColor(Color.FromRGBA(50, 220, 80, 255));
			m_StatusText.SetText("Code accepte ! Vous avez maintenant acces a cette porte.");
			GetGame().GetCallqueue().CallLater(CloseMenuInternal, 1500, false);
		}
		else if (result == 1)
		{
			m_StatusText.SetColor(Color.FromRGBA(230, 60, 60, 255));
			m_StatusText.SetText("Code incorrect.");
		}
		else if (result == 2)
		{
			m_StatusText.SetColor(Color.FromRGBA(230, 180, 60, 255));
			m_StatusText.SetText("Aucun code n a ete defini sur cette porte.");
		}
		else
		{
			m_StatusText.SetColor(Color.FromRGBA(230, 60, 60, 255));
			m_StatusText.SetText("Erreur.");
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void OnButtonClicked(string action)
	{
		if (action == "close") { CloseMenuInternal(); return; }
		if (action == "validate")
		{
			string code = "";
			if (m_CodeInput) code = m_CodeInput.GetText();
			if (code.Length() != 4)
			{
				if (m_StatusText)
				{
					m_StatusText.SetColor(Color.FromRGBA(230, 180, 60, 255));
					m_StatusText.SetText("Le code doit contenir 4 chiffres.");
				}
				return;
			}
			PlayerController pc = GetGame().GetPlayerController();
			if (!pc) return;
			JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
			if (!jpc) return;
			jpc.ClientAskTryLpDoorCode(m_DoorRplId, code);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void CloseMenuInternal() { GetGame().GetMenuManager().CloseMenu(this); }
	static LP_DoorEnterCodeMenu GetOpenMenu() { return s_Instance; }
}

class LP_DoorEnterCodeBtnHandler : ScriptedWidgetEventHandler
{
	LP_DoorEnterCodeMenu m_Menu;
	string m_Action;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.OnButtonClicked(m_Action);
		return true;
	}
}
