//------------------------------------------------------------------------------------------------
// JobCompanyOrderListMenu.c
// Liste des bons de commande de l entreprise (ouvert depuis Acces entreprise).
//
// Deux usages :
//   - "pending"   : patron voit les bons EN ATTENTE (filtre serveur)
//   - "my_orders" : employe (ou patron) voit ses propres bons (en cours + historique)
//
// Donnees pre-chargees via SetPendingData. Au clic sur un bon, ouvre detail.
//------------------------------------------------------------------------------------------------

class JobCompanyOrderEntry
{
	int m_OrderId;
	int m_Status;
	int m_ProposedPrice;
	int m_FinalPrice;
	string m_AuthorName;
	int m_ItemCount;
}

class JobCompanyOrderListMenu : ChimeraMenuBase
{
	const string ENTRY_LAYOUT_PATH = "{9D68BEB73DF970D8}UI/layouts/JobSmsEntry.layout";
	
	Widget m_RootWidget;
	Widget m_ListContainer;
	TextWidget m_TitleText;
	TextWidget m_EmptyText;
	ButtonWidget m_BtnBack;
	
	static ref array<ref JobCompanyOrderEntry> s_PendingOrders = new array<ref JobCompanyOrderEntry>();
	static bool s_IsOwnerView = false;  // affecte titre + boutons disponibles dans detail
	
	static JobCompanyOrderListMenu s_Instance;
	
	//------------------------------------------------------------------------------------------------
	static void SetPendingData(array<ref JobCompanyOrderEntry> orders, bool ownerView)
	{
		s_PendingOrders.Clear();
		foreach (JobCompanyOrderEntry o : orders)
			s_PendingOrders.Insert(o);
		s_IsOwnerView = ownerView;
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuOpen()
	{
		super.OnMenuOpen();
		s_Instance = this;
		JobFocusHandler.ClearRegistry();
		
		m_RootWidget = GetRootWidget();
		if (!m_RootWidget)
			return;
		
		m_ListContainer = m_RootWidget.FindAnyWidget("ListContainer");
		m_TitleText = TextWidget.Cast(m_RootWidget.FindAnyWidget("TitleText"));
		m_EmptyText = TextWidget.Cast(m_RootWidget.FindAnyWidget("EmptyText"));
		m_BtnBack = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnBack"));
		
		if (m_TitleText)
		{
			if (s_IsOwnerView)
				m_TitleText.SetText("Bons en attente - Acceptez ou refusez");
			else
				m_TitleText.SetText("Mes bons de commande");
		}
		
		BuildList();
		
		if (m_BtnBack)
		{
			OrderListBackHandler bh = new OrderListBackHandler();
			bh.m_Menu = this;
			m_BtnBack.AddHandler(bh);
			JobFocusHandler.Attach(m_BtnBack);
			GetGame().GetWorkspace().SetFocusedWidget(m_BtnBack);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuClose()
	{
		if (s_Instance == this)
			s_Instance = null;
		super.OnMenuClose();
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuUpdate(float tDelta)
	{
		super.OnMenuUpdate(tDelta);
		if (GetGame().GetInputManager().GetActionValue("MenuBack") > 0.5)
			CloseMenuInternal();
	}
	
	//------------------------------------------------------------------------------------------------
	void BuildList()
	{
		if (!m_ListContainer)
			return;
		
		// Reset
		Widget child = m_ListContainer.GetChildren();
		while (child)
		{
			Widget next = child.GetSibling();
			child.RemoveFromHierarchy();
			child = next;
		}
		
		if (s_PendingOrders.Count() == 0)
		{
			if (m_EmptyText)
			{
				m_EmptyText.SetText("Aucun bon a afficher.");
				m_EmptyText.SetVisible(true);
			}
			return;
		}
		if (m_EmptyText)
			m_EmptyText.SetVisible(false);
		
		WorkspaceWidget ws = GetGame().GetWorkspace();
		for (int i = 0; i < s_PendingOrders.Count(); i++)
		{
			JobCompanyOrderEntry o = s_PendingOrders.Get(i);
			if (!o) continue;
			
			Widget entry = ws.CreateWidgets(ENTRY_LAYOUT_PATH, m_ListContainer);
			if (!entry) continue;
			
			TextWidget nameW = TextWidget.Cast(entry.FindAnyWidget("PlayerName"));
			if (nameW)
				nameW.SetText(FormatOrderLine(o));
			
			ButtonWidget btn = ButtonWidget.Cast(entry.FindAnyWidget("SelectButton"));
			if (btn)
			{
				OrderListItemHandler ih = new OrderListItemHandler();
				ih.m_Menu = this;
				ih.m_OrderId = o.m_OrderId;
				btn.AddHandler(ih);
				JobFocusHandler.Attach(btn);
			}
		}
	}
	
	//------------------------------------------------------------------------------------------------
	string FormatOrderLine(JobCompanyOrderEntry o)
	{
		string statusLabel;
		switch (o.m_Status)
		{
			case 0: statusLabel = "[ATTENTE]"; break;
			case 1: statusLabel = "[VALIDE]"; break;
			case 2: statusLabel = "[REFUSE]"; break;
			default: statusLabel = "[?]";
		}
		return string.Format("#%1 %2 - %3 - %4 items - %5c",
			o.m_OrderId.ToString(),
			statusLabel,
			o.m_AuthorName,
			o.m_ItemCount.ToString(),
			o.m_ProposedPrice.ToString());
	}
	
	//------------------------------------------------------------------------------------------------
	void OnOrderClicked(int orderId)
	{
		// Demande le detail du bon au serveur
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		jpc.ClientAskOrderDetail(orderId);
	}
	
	//------------------------------------------------------------------------------------------------
	void CloseMenuInternal()
	{
		GetGame().GetMenuManager().CloseMenu(this);
	}
	
	static JobCompanyOrderListMenu GetOpenMenu() { return s_Instance; }
	static bool IsOwnerView() { return s_IsOwnerView; }
}

//------------------------------------------------------------------------------------------------
class OrderListBackHandler : ScriptedWidgetEventHandler
{
	JobCompanyOrderListMenu m_Menu;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.CloseMenuInternal();
		return true;
	}
	override bool OnMouseButtonDown(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.CloseMenuInternal();
		return true;
	}
}

//------------------------------------------------------------------------------------------------
class OrderListItemHandler : ScriptedWidgetEventHandler
{
	JobCompanyOrderListMenu m_Menu;
	int m_OrderId;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.OnOrderClicked(m_OrderId);
		return true;
	}
	override bool OnMouseButtonDown(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.OnOrderClicked(m_OrderId);
		return true;
	}
}
