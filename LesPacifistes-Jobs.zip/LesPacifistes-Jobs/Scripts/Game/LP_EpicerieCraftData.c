//------------------------------------------------------------------------------------------------
// LP_EpicerieCraftData.c
// Definition des recettes de craft de l epicerie.
// Chaque recette contient :
//   - Un nom affichable
//   - Un prefab resultat
//   - Une liste d ingredients (prefab + quantite)
//------------------------------------------------------------------------------------------------

class LP_CraftIngredient
{
	string m_Prefab;
	int m_Quantity;
	string m_DisplayName; // pour affichage UI (ex : "Lait", "Oeuf")
	
	void LP_CraftIngredient(string prefab, int quantity, string displayName)
	{
		m_Prefab = prefab;
		m_Quantity = quantity;
		m_DisplayName = displayName;
	}
}

class LP_CraftRecipe
{
	int m_RecipeId;         // identifiant unique (utilise dans RPC pour designer la recette)
	string m_DisplayName;   // nom affichable dans l UI
	string m_ResultPrefab;  // prefab a spawner en resultat
	ref array<ref LP_CraftIngredient> m_Ingredients = new array<ref LP_CraftIngredient>();
}

class LP_EpicerieCraftData
{
	// Prefabs ingredients bruts
	static string LAIT_BRUT      = "{14B5AE4385CA2AC7}Prefabs/Weapons/Grenades/lait.et";
	static string POISSON1       = "{6C9D10B121D0B61E}Prefabs/Weapons/Grenades/poisson1.et";
	static string POISSON2       = "{00C924519D143930}Prefabs/Weapons/Grenades/poisson2.et";
	static string OEUF           = "{40DD771C1264953C}Prefabs/Weapons/Grenades/oeuf.et";
	static string FARINE         = "{3CE28F8799BE0AD6}Prefabs/Weapons/Grenades/farine.et";
	static string POMME          = "{E629212FF102070A}Prefabs/Weapons/Grenades/pomme.et";
	static string VIANDE         = "{3610E30E5946AD2B}Prefabs/Items/Food/MeatLeg_01.et";
	static string POULET         = "{D8AAF1F088605E7E}Prefabs/Weapons/Grenades/poulet.et";
	static string EAU            = "{F9C514AC996D4829}Prefabs/Items/Equipment/Radios/Water Bottle.et";
	static string BLE            = "{65669257F999337D}Prefabs/Weapons/Grenades/ble.et";
	
	// Prefabs resultats craft
	static string LAIT_PASTERISE = "{146D173B1CEBD017}Prefabs/Items/Equipment/Radios/laitok.et";
	static string BOITE_THON     = "{181ED76922490202}Prefabs/Items/Equipment/Radios/boitedethon.et";
	static string CROISSANT      = "{060D3CED33A555A9}Prefabs/Items/Equipment/Radios/croissant.et";
	static string CUPCAKE        = "{80DE0727A18AA558}Prefabs/Items/Equipment/Radios/cupcake.et";
	static string HAMBURGER      = "{DC643F43E4CA6D1C}Prefabs/Items/Equipment/Radios/hamburger.et";
	static string NUGGET         = "{2045868773168C9A}Prefabs/Items/Equipment/Radios/nugget.et";
	static string GAUFFRE        = "{CEC26D06FE3ADB9C}Prefabs/Items/Equipment/Radios/pancake.et";
	static string POISSON_GRILLE = "{BE8EE247DD42394A}Prefabs/Items/Equipment/Radios/poissongriller.et";
	static string VODKA          = "{1361AAED6F8090BE}Prefabs/Items/Equipment/Radios/Vodka.et";
	static string WHISKY         = "{8E54AA3016BAA2B7}Prefabs/Items/Equipment/Radios/American Whiskey.et";
	static string MODELO_NEGRA   = "{EBC70DC0B8E6B5EF}Prefabs/Items/Equipment/Radios/Modelo Negra.et";
	static string MODELO         = "{0E51AF35718E6F8E}Prefabs/Items/Equipment/Radios/Modelo.et";
	
	// Duree du craft en secondes
	const int CRAFT_DURATION_S = 30;
	
	// Cache statique des recettes (initialise 1 fois)
	static ref array<ref LP_CraftRecipe> s_Recipes;
	
	//------------------------------------------------------------------------------------------------
	// Retourne toutes les recettes (initialisees a la 1ere demande)
	//------------------------------------------------------------------------------------------------
	static array<ref LP_CraftRecipe> GetAllRecipes()
	{
		if (!s_Recipes)
		{
			s_Recipes = new array<ref LP_CraftRecipe>();
			InitRecipes();
		}
		return s_Recipes;
	}
	
	//------------------------------------------------------------------------------------------------
	static LP_CraftRecipe GetRecipeById(int recipeId)
	{
		array<ref LP_CraftRecipe> all = GetAllRecipes();
		foreach (LP_CraftRecipe r : all)
		{
			if (r && r.m_RecipeId == recipeId) return r;
		}
		return null;
	}
	
	//------------------------------------------------------------------------------------------------
	protected static void InitRecipes()
	{
		// 1. Lait entier pasterise : 1 lait brut
		LP_CraftRecipe r1 = new LP_CraftRecipe();
		r1.m_RecipeId = 1;
		r1.m_DisplayName = "Lait entier pasterise";
		r1.m_ResultPrefab = LAIT_PASTERISE;
		r1.m_Ingredients.Insert(new LP_CraftIngredient(LAIT_BRUT, 1, "Lait"));
		s_Recipes.Insert(r1);
		
		// 2. Boite de thon : 1 poisson (thon)
		LP_CraftRecipe r2 = new LP_CraftRecipe();
		r2.m_RecipeId = 2;
		r2.m_DisplayName = "Boite de thon";
		r2.m_ResultPrefab = BOITE_THON;
		r2.m_Ingredients.Insert(new LP_CraftIngredient(POISSON1, 1, "Poisson (thon)"));
		s_Recipes.Insert(r2);
		
		// 3. Croissant : 1 oeuf + 1 farine
		LP_CraftRecipe r3 = new LP_CraftRecipe();
		r3.m_RecipeId = 3;
		r3.m_DisplayName = "Croissant";
		r3.m_ResultPrefab = CROISSANT;
		r3.m_Ingredients.Insert(new LP_CraftIngredient(OEUF, 1, "Oeuf"));
		r3.m_Ingredients.Insert(new LP_CraftIngredient(FARINE, 1, "Farine"));
		s_Recipes.Insert(r3);
		
		// 4. Cupcake : 1 oeuf + 1 farine + 2 pommes
		LP_CraftRecipe r4 = new LP_CraftRecipe();
		r4.m_RecipeId = 4;
		r4.m_DisplayName = "Cupcake";
		r4.m_ResultPrefab = CUPCAKE;
		r4.m_Ingredients.Insert(new LP_CraftIngredient(OEUF, 1, "Oeuf"));
		r4.m_Ingredients.Insert(new LP_CraftIngredient(FARINE, 1, "Farine"));
		r4.m_Ingredients.Insert(new LP_CraftIngredient(POMME, 2, "Pomme"));
		s_Recipes.Insert(r4);
		
		// 5. Hamburger : 1 oeuf + 1 farine + 2 viandes
		LP_CraftRecipe r5 = new LP_CraftRecipe();
		r5.m_RecipeId = 5;
		r5.m_DisplayName = "Hamburger";
		r5.m_ResultPrefab = HAMBURGER;
		r5.m_Ingredients.Insert(new LP_CraftIngredient(OEUF, 1, "Oeuf"));
		r5.m_Ingredients.Insert(new LP_CraftIngredient(FARINE, 1, "Farine"));
		r5.m_Ingredients.Insert(new LP_CraftIngredient(VIANDE, 2, "Viande"));
		s_Recipes.Insert(r5);
		
		// 6. Nugget : 1 cuisse de poulet + 1 farine
		LP_CraftRecipe r6 = new LP_CraftRecipe();
		r6.m_RecipeId = 6;
		r6.m_DisplayName = "Nugget";
		r6.m_ResultPrefab = NUGGET;
		r6.m_Ingredients.Insert(new LP_CraftIngredient(POULET, 1, "Cuisse poulet"));
		r6.m_Ingredients.Insert(new LP_CraftIngredient(FARINE, 1, "Farine"));
		s_Recipes.Insert(r6);
		
		// 7. Gauffre : 1 oeuf + 1 farine
		LP_CraftRecipe r7 = new LP_CraftRecipe();
		r7.m_RecipeId = 7;
		r7.m_DisplayName = "Gauffre";
		r7.m_ResultPrefab = GAUFFRE;
		r7.m_Ingredients.Insert(new LP_CraftIngredient(OEUF, 1, "Oeuf"));
		r7.m_Ingredients.Insert(new LP_CraftIngredient(FARINE, 1, "Farine"));
		s_Recipes.Insert(r7);
		
		// 8. Poisson grille : 1 poisson (poisson2)
		LP_CraftRecipe r8 = new LP_CraftRecipe();
		r8.m_RecipeId = 8;
		r8.m_DisplayName = "Poisson grille";
		r8.m_ResultPrefab = POISSON_GRILLE;
		r8.m_Ingredients.Insert(new LP_CraftIngredient(POISSON2, 1, "Poisson"));
		s_Recipes.Insert(r8);
		
		// 9. Biere Modelo Negra : 1 eau + 2 ble
		LP_CraftRecipe r9 = new LP_CraftRecipe();
		r9.m_RecipeId = 9;
		r9.m_DisplayName = "Biere Modelo Negra";
		r9.m_ResultPrefab = MODELO_NEGRA;
		r9.m_Ingredients.Insert(new LP_CraftIngredient(EAU, 1, "Bouteille d eau"));
		r9.m_Ingredients.Insert(new LP_CraftIngredient(BLE, 2, "Ble"));
		s_Recipes.Insert(r9);
		
		// 10. Biere Modelo : 1 eau + 2 ble
		LP_CraftRecipe r10 = new LP_CraftRecipe();
		r10.m_RecipeId = 10;
		r10.m_DisplayName = "Biere Modelo";
		r10.m_ResultPrefab = MODELO;
		r10.m_Ingredients.Insert(new LP_CraftIngredient(EAU, 1, "Bouteille d eau"));
		r10.m_Ingredients.Insert(new LP_CraftIngredient(BLE, 2, "Ble"));
		s_Recipes.Insert(r10);
		
		// 11. Bouteille de Vodka : 4 pommes + 1 eau + 6 ble
		LP_CraftRecipe r11 = new LP_CraftRecipe();
		r11.m_RecipeId = 11;
		r11.m_DisplayName = "Bouteille de Vodka";
		r11.m_ResultPrefab = VODKA;
		r11.m_Ingredients.Insert(new LP_CraftIngredient(POMME, 4, "Pomme"));
		r11.m_Ingredients.Insert(new LP_CraftIngredient(EAU, 1, "Bouteille d eau"));
		r11.m_Ingredients.Insert(new LP_CraftIngredient(BLE, 6, "Ble"));
		s_Recipes.Insert(r11);
		
		// 12. Bouteille de Whisky : 4 pommes + 1 eau + 6 ble
		LP_CraftRecipe r12 = new LP_CraftRecipe();
		r12.m_RecipeId = 12;
		r12.m_DisplayName = "Bouteille de Whisky";
		r12.m_ResultPrefab = WHISKY;
		r12.m_Ingredients.Insert(new LP_CraftIngredient(POMME, 4, "Pomme"));
		r12.m_Ingredients.Insert(new LP_CraftIngredient(EAU, 1, "Bouteille d eau"));
		r12.m_Ingredients.Insert(new LP_CraftIngredient(BLE, 6, "Ble"));
		s_Recipes.Insert(r12);
	}
}
