//------------------------------------------------------------------------------------------------
// JobPhoneMenu.c
// Menu telephone avec 4 boutons d'appel SOS.
// Chaque clic envoie le type d'appel au serveur qui broadcast l'alerte aux agents.
//------------------------------------------------------------------------------------------------

class JobPhoneMenu : ChimeraMenuBase
{
	Widget m_RootWidget;
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuOpen()
	{
		super.OnMenuOpen();
		m_RootWidget = GetRootWidget();
		if (!m_RootWidget)
			return;
		
		AttachButton("CallPoliceButton", EPhoneCallType.POLICE);
		AttachButton("CallGendarmerieButton", EPhoneCallType.GENDARMERIE);
		AttachButton("CallUrgencesButton", EPhoneCallType.URGENCES);
		AttachButton("CallMecanicienButton", EPhoneCallType.MECANICIEN);
		AttachButton("CallUberButton", EPhoneCallType.UBER);
		AttachButton("CloseButton", EPhoneCallType.NONE);
		AttachButton("FloatingCloseButton", EPhoneCallType.NONE);
		
		// Boutons SMS (nouveaux)
		AttachSmsButton("BtnSendSms", "send");
		AttachSmsButton("BtnViewSms", "inbox");
		
		// Bouton Transfert d argent (ouvre le menu ATM)
		AttachSmsButton("BtnTransfer", "transfer");
		
		// Focus initial
		ButtonWidget firstBtn = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("CallPoliceButton"));
		if (firstBtn)
			GetGame().GetWorkspace().SetFocusedWidget(firstBtn);
	}
	
	//------------------------------------------------------------------------------------------------
	void AttachButton(string name, EPhoneCallType callType)
	{
		ButtonWidget btn = ButtonWidget.Cast(m_RootWidget.FindAnyWidget(name));
		if (!btn)
			return;
		PhoneMenuClickHandler h = new PhoneMenuClickHandler();
		h.m_Menu = this;
		h.m_CallType = callType;
		btn.AddHandler(h);
		JobFocusHandler.Attach(btn);
	}
	
	//------------------------------------------------------------------------------------------------
	void AttachSmsButton(string name, string smsAction)
	{
		ButtonWidget btn = ButtonWidget.Cast(m_RootWidget.FindAnyWidget(name));
		if (!btn)
			return;
		PhoneSmsButtonHandler h = new PhoneSmsButtonHandler();
		h.m_Menu = this;
		h.m_SmsAction = smsAction;
		btn.AddHandler(h);
		JobFocusHandler.Attach(btn);
	}
	
	//------------------------------------------------------------------------------------------------
	void OnSmsButtonClicked(string smsAction)
	{
		// Ferme d abord ce menu pour eviter la superposition
		CloseMenuInternal();
		
		if (smsAction == "send")
		{
			GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.JobSmsSendMenu);
		}
		else if (smsAction == "inbox")
		{
			GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.JobSmsInboxMenu);
		}
		else if (smsAction == "transfer")
		{
			// Ouvre le menu ATM (meme preset que l action ATM physique)
			JobAtmMenu atm = JobAtmMenu.Cast(
				GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.JobAtmMenu));
			if (atm)
				atm.Initialize();
		}
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuUpdate(float tDelta)
	{
		super.OnMenuUpdate(tDelta);
		if (GetGame().GetInputManager().GetActionValue("MenuBack") > 0.5)
		{
			CloseMenuInternal();
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void OnCallClicked(EPhoneCallType callType)
	{
		if (callType == EPhoneCallType.NONE)
		{
			CloseMenuInternal();
			return;
		}
		
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc)
		{
			CloseMenuInternal();
			return;
		}
		
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (jpc)
			jpc.ClientAskMakePhoneCall(callType);
		
		CloseMenuInternal();
	}
	
	//------------------------------------------------------------------------------------------------
	void CloseMenuInternal()
	{
		GetGame().GetMenuManager().CloseMenu(this);
	}
}

class PhoneMenuClickHandler : ScriptedWidgetEventHandler
{
	JobPhoneMenu m_Menu;
	EPhoneCallType m_CallType;
	
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu)
			m_Menu.OnCallClicked(m_CallType);
		return true;
	}
}

class PhoneSmsButtonHandler : ScriptedWidgetEventHandler
{
	JobPhoneMenu m_Menu;
	string m_SmsAction;
	
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu)
			m_Menu.OnSmsButtonClicked(m_SmsAction);
		return true;
	}
}
