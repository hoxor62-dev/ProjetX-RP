//------------------------------------------------------------------------------------------------
// LP_DoorSellMenu.c
// Menu client pour vendeur immo ou proprio revendeur : liste joueurs + prix.
//------------------------------------------------------------------------------------------------

class LP_DoorSellMenu : ChimeraMenuBase
{
	Widget m_Root;
	TextWidget m_TitleText;
	TextWidget m_CostInfoText;
	EditBoxWidget m_PriceInput;
	TextWidget m_StatusText;
	ButtonWidget m_BtnPropose;
	ButtonWidget m_BtnClose;
	FrameWidget m_PlayersFrame;
	ButtonWidget m_BtnPrevPage;
	ButtonWidget m_BtnNextPage;
	TextWidget m_PageLabel;
	
	RplId m_DoorRplId = RplId.Invalid();
	bool m_IsResell = false;
	ref array<int> m_PlayerIds = new array<int>();
	ref array<string> m_PlayerNames = new array<string>();
	int m_SelectedPlayerId = 0;
	
	ref array<Widget> m_EntryWidgets = new array<Widget>();
	const int ENTRY_HEIGHT = 45;
	const int ENTRY_WIDTH = 670;
	const int ITEMS_PER_PAGE = 10;
	int m_CurrentPage = 0;
	
	static LP_DoorSellMenu s_Instance;
	
	// Bridge static (set avant OpenMenu)
	static RplId s_PendingRplId = RplId.Invalid();
	static bool s_PendingIsResell = false;
	static void SetPendingTarget(RplId rplId, bool isResell)
	{
		s_PendingRplId = rplId;
		s_PendingIsResell = isResell;
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuOpen()
	{
		super.OnMenuOpen();
		s_Instance = this;
		JobFocusHandler.ClearRegistry();
		
		if (s_PendingRplId.IsValid())
		{
			m_DoorRplId = s_PendingRplId;
			m_IsResell = s_PendingIsResell;
			s_PendingRplId = RplId.Invalid();
			s_PendingIsResell = false;
		}
		
		m_Root = GetRootWidget();
		if (!m_Root) return;
		
		m_TitleText = TextWidget.Cast(m_Root.FindAnyWidget("TitleText"));
		m_CostInfoText = TextWidget.Cast(m_Root.FindAnyWidget("CostInfoText"));
		m_PriceInput = EditBoxWidget.Cast(m_Root.FindAnyWidget("PriceInput"));
		m_StatusText = TextWidget.Cast(m_Root.FindAnyWidget("StatusText"));
		m_BtnPropose = ButtonWidget.Cast(m_Root.FindAnyWidget("BtnPropose"));
		m_BtnClose = ButtonWidget.Cast(m_Root.FindAnyWidget("BtnClose"));
		m_PlayersFrame = FrameWidget.Cast(m_Root.FindAnyWidget("PlayersFrame"));
		m_BtnPrevPage = ButtonWidget.Cast(m_Root.FindAnyWidget("BtnPrevPage"));
		m_BtnNextPage = ButtonWidget.Cast(m_Root.FindAnyWidget("BtnNextPage"));
		m_PageLabel = TextWidget.Cast(m_Root.FindAnyWidget("PageLabel"));
		
		// Adapte le titre + info cout selon vente initiale ou revente
		if (m_IsResell)
		{
			if (m_TitleText) m_TitleText.SetText("Revendre l acces");
			if (m_CostInfoText)
				m_CostInfoText.SetText("Vente entre joueurs : vous touchez 100% du prix. Acheteurs a moins de 5m.");
			if (m_PriceInput) m_PriceInput.SetText("15000");
		}
		else
		{
			if (m_CostInfoText)
				m_CostInfoText.SetText("Cout de base : 15000 capsules. Vous gagnez (prix - 15000). Acheteurs a moins de 5m.");
			if (m_PriceInput) m_PriceInput.SetText("20000");
		}
		
		AttachBtn(m_BtnPropose, "propose");
		AttachBtn(m_BtnClose, "close");
		AttachBtn(m_BtnPrevPage, "page_prev");
		AttachBtn(m_BtnNextPage, "page_next");
		
		PlayerController pc = GetGame().GetPlayerController();
		if (pc)
		{
			JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
			if (jpc) jpc.ClientAskLpDoorSellInfo(m_DoorRplId);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuClose()
	{
		if (s_Instance == this) s_Instance = null;
		super.OnMenuClose();
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuUpdate(float tDelta)
	{
		super.OnMenuUpdate(tDelta);
		if (GetGame().GetInputManager().GetActionValue("MenuBack") > 0.5)
			CloseMenuInternal();
	}
	
	//------------------------------------------------------------------------------------------------
	void AttachBtn(ButtonWidget btn, string action)
	{
		if (!btn) return;
		LP_DoorSellBtnHandler h = new LP_DoorSellBtnHandler();
		h.m_Menu = this;
		h.m_Action = action;
		btn.AddHandler(h);
		JobFocusHandler.Attach(btn);
	}
	
	//------------------------------------------------------------------------------------------------
	// RPC serveur -> client : liste joueurs
	void DisplayPlayers(array<int> playerIds, array<string> playerNames)
	{
		m_PlayerIds.Clear();
		m_PlayerNames.Clear();
		foreach (int pid : playerIds) m_PlayerIds.Insert(pid);
		foreach (string pn : playerNames) m_PlayerNames.Insert(pn);
		m_CurrentPage = 0;
		BuildPlayersList();
	}
	
	//------------------------------------------------------------------------------------------------
	// Construit la liste avec pagination 10 joueurs par page
	void BuildPlayersList()
	{
		foreach (Widget w : m_EntryWidgets) { if (w) w.RemoveFromHierarchy(); }
		m_EntryWidgets.Clear();
		
		if (!m_PlayersFrame) return;
		WorkspaceWidget ws = GetGame().GetWorkspace();
		if (!ws) return;
		
		int totalItems = m_PlayerIds.Count();
		int totalPages = 1;
		if (totalItems > 0)
			totalPages = (totalItems + ITEMS_PER_PAGE - 1) / ITEMS_PER_PAGE;
		if (m_CurrentPage < 0) m_CurrentPage = 0;
		if (m_CurrentPage >= totalPages) m_CurrentPage = totalPages - 1;
		
		int pageStart = m_CurrentPage * ITEMS_PER_PAGE;
		int pageEnd = pageStart + ITEMS_PER_PAGE;
		if (pageEnd > totalItems) pageEnd = totalItems;
		
		int rowIndex = 0;
		for (int i = pageStart; i < pageEnd; i++)
		{
			int pid = m_PlayerIds.Get(i);
			string pname = m_PlayerNames.Get(i);
			
			Widget entry = ws.CreateWidgets("UI/layouts/LP_DoorSellPlayerEntry.layout", m_PlayersFrame);
			if (!entry) continue;
			
			FrameSlot.SetPos(entry, 0, rowIndex * ENTRY_HEIGHT);
			FrameSlot.SetSize(entry, ENTRY_WIDTH, ENTRY_HEIGHT - 3);
			
			TextWidget nameW = TextWidget.Cast(entry.FindAnyWidget("PlayerName"));
			if (nameW) nameW.SetText(pname);
			
			// Affiche le marqueur ">>" si ce joueur est deja selectionne
			TextWidget markW = TextWidget.Cast(entry.FindAnyWidget("SelectedMark"));
			if (markW)
			{
				if (pid == m_SelectedPlayerId) markW.SetText(">>");
				else markW.SetText("");
			}
			
			ButtonWidget selectBtn = ButtonWidget.Cast(entry.FindAnyWidget("SelectButton"));
			if (selectBtn)
			{
				LP_DoorSellSelectHandler h = new LP_DoorSellSelectHandler();
				h.m_Menu = this;
				h.m_PlayerId = pid;
				selectBtn.AddHandler(h);
				JobFocusHandler.Attach(selectBtn);
			}
			
			m_EntryWidgets.Insert(entry);
			rowIndex = rowIndex + 1;
		}
		
		UpdatePagination(totalPages);
	}
	
	//------------------------------------------------------------------------------------------------
	void UpdatePagination(int totalPages)
	{
		bool needPagination = totalPages > 1;
		
		if (m_BtnPrevPage)
		{
			m_BtnPrevPage.SetVisible(needPagination);
			m_BtnPrevPage.SetEnabled(m_CurrentPage > 0);
			if (m_CurrentPage > 0)
				m_BtnPrevPage.SetColor(Color.FromRGBA(46, 128, 56, 255));
			else
				m_BtnPrevPage.SetColor(Color.FromRGBA(89, 89, 102, 255));
		}
		if (m_BtnNextPage)
		{
			m_BtnNextPage.SetVisible(needPagination);
			m_BtnNextPage.SetEnabled(m_CurrentPage < totalPages - 1);
			if (m_CurrentPage < totalPages - 1)
				m_BtnNextPage.SetColor(Color.FromRGBA(46, 128, 56, 255));
			else
				m_BtnNextPage.SetColor(Color.FromRGBA(89, 89, 102, 255));
		}
		if (m_PageLabel)
		{
			m_PageLabel.SetVisible(needPagination);
			if (needPagination)
				m_PageLabel.SetText(string.Format("Page %1 / %2",
					(m_CurrentPage + 1).ToString(), totalPages.ToString()));
			else
				m_PageLabel.SetText("");
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void GoToNextPage()
	{
		int totalItems = m_PlayerIds.Count();
		int totalPages = 1;
		if (totalItems > 0)
			totalPages = (totalItems + ITEMS_PER_PAGE - 1) / ITEMS_PER_PAGE;
		if (m_CurrentPage < totalPages - 1)
		{
			m_CurrentPage = m_CurrentPage + 1;
			BuildPlayersList();
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void GoToPrevPage()
	{
		if (m_CurrentPage > 0)
		{
			m_CurrentPage = m_CurrentPage - 1;
			BuildPlayersList();
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void OnPlayerSelected(int playerId)
	{
		m_SelectedPlayerId = playerId;
		// Parcours uniquement les widgets de la page courante
		int pageStart = m_CurrentPage * ITEMS_PER_PAGE;
		for (int rowIdx = 0; rowIdx < m_EntryWidgets.Count(); rowIdx++)
		{
			Widget entry = m_EntryWidgets.Get(rowIdx);
			if (!entry) continue;
			TextWidget markW = TextWidget.Cast(entry.FindAnyWidget("SelectedMark"));
			if (!markW) continue;
			int globalIdx = pageStart + rowIdx;
			if (globalIdx < m_PlayerIds.Count() && m_PlayerIds.Get(globalIdx) == playerId)
				markW.SetText(">>");
			else
				markW.SetText("");
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void OnButtonClicked(string action)
	{
		if (action == "close") { CloseMenuInternal(); return; }
		if (action == "page_prev") { GoToPrevPage(); return; }
		if (action == "page_next") { GoToNextPage(); return; }
		if (action == "propose")
		{
			if (m_SelectedPlayerId <= 0)
			{
				if (m_StatusText) m_StatusText.SetText("Selectionnez un acheteur d abord.");
				return;
			}
			int price = 0;
			if (m_PriceInput) price = m_PriceInput.GetText().ToInt();
			if (price < 0)
			{
				if (m_StatusText) m_StatusText.SetText("Prix invalide.");
				return;
			}
			
			PlayerController pc = GetGame().GetPlayerController();
			if (!pc) return;
			JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
			if (!jpc) return;
			jpc.ClientAskProposeLpDoorSale(m_DoorRplId, m_SelectedPlayerId, price, m_IsResell);
			
			if (m_StatusText) m_StatusText.SetText("Proposition envoyee !");
			GetGame().GetCallqueue().CallLater(CloseMenuInternal, 800, false);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Serveur peut aussi renvoyer un message d erreur (prix insuffisant, etc.)
	void ShowServerError(string msg)
	{
		if (m_StatusText)
		{
			m_StatusText.SetColor(Color.FromRGBA(230, 60, 60, 255));
			m_StatusText.SetText(msg);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void CloseMenuInternal() { GetGame().GetMenuManager().CloseMenu(this); }
	static LP_DoorSellMenu GetOpenMenu() { return s_Instance; }
}

class LP_DoorSellBtnHandler : ScriptedWidgetEventHandler
{
	LP_DoorSellMenu m_Menu;
	string m_Action;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.OnButtonClicked(m_Action);
		return true;
	}
}

class LP_DoorSellSelectHandler : ScriptedWidgetEventHandler
{
	LP_DoorSellMenu m_Menu;
	int m_PlayerId;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.OnPlayerSelected(m_PlayerId);
		return true;
	}
}
