//------------------------------------------------------------------------------------------------
// JobIdentityManager.c
// Manager singleton server-side des identites roleplay des joueurs.
// Un joueur ne peut creer son identite qu'une seule fois (impossible a modifier ensuite).
//
// Persistance : un fichier JSON par joueur dans
//   $profile:LesPacifistesJobs/identities/identity_<UID>.json
// Cela permet au boss de supprimer manuellement une fiche d'identite specifique au besoin.
//------------------------------------------------------------------------------------------------

class JobRpIdentity
{
	string m_FirstName;     // Prenom RP
	string m_LastName;      // Nom RP
	string m_BirthDate;     // Date de naissance (texte libre)
	int m_CreatedTime;      // timestamp de creation (info)
	
	void JobRpIdentity()
	{
		m_FirstName = "";
		m_LastName = "";
		m_BirthDate = "";
		m_CreatedTime = 0;
	}
}

class JobIdentityManager
{
	static ref JobIdentityManager s_Instance;
	
	// Cache memoire SERVEUR : UID -> identite (pour eviter de relire le fichier a chaque check)
	ref map<string, ref JobRpIdentity> m_Cache;
	
	// Cache CLIENT : playerId -> displayName (Prenom Nom) pour les autres joueurs
	// Mis a jour via RPC du serveur lors de connexion ou creation identite
	ref map<int, string> m_ClientPlayerCache;
	
	const string IDENTITY_DIR = "$profile:LesPacifistesJobs/identities";
	
	//------------------------------------------------------------------------------------------------
	void JobIdentityManager()
	{
		m_Cache = new map<string, ref JobRpIdentity>();
		m_ClientPlayerCache = new map<int, string>();
	}
	
	//------------------------------------------------------------------------------------------------
	static JobIdentityManager GetInstance()
	{
		if (!s_Instance)
			s_Instance = new JobIdentityManager();
		return s_Instance;
	}
	
	//------------------------------------------------------------------------------------------------
	// CLIENT : Met a jour le cache local pour un joueur (appele par RPC depuis serveur)
	//------------------------------------------------------------------------------------------------
	void Client_SetIdentityForPlayer(int playerId, string displayName)
	{
		if (displayName == "")
			m_ClientPlayerCache.Remove(playerId);
		else
			m_ClientPlayerCache.Set(playerId, displayName);
	}
	
	//------------------------------------------------------------------------------------------------
	// CLIENT : Recupere le nom d affichage pour un joueur. Identite RP si dispo, sinon playername.
	//------------------------------------------------------------------------------------------------
	string Client_GetDisplayName(int playerId)
	{
		string cached = m_ClientPlayerCache.Get(playerId);
		if (cached != "")
			return cached;
		// Fallback : playername
		string pn = GetGame().GetPlayerManager().GetPlayerName(playerId);
		return pn;
	}
	
	//------------------------------------------------------------------------------------------------
	// Construit le chemin du fichier JSON pour un UID donne
	//------------------------------------------------------------------------------------------------
	string BuildPath(string uid)
	{
		return IDENTITY_DIR + "/identity_" + uid + ".json";
	}
	
	//------------------------------------------------------------------------------------------------
	// Verifie si un joueur a deja une identite enregistree
	//------------------------------------------------------------------------------------------------
	bool HasIdentity(string uid)
	{
		if (uid == "")
			return false;
		// Si en cache : oui
		if (m_Cache.Get(uid))
			return true;
		// Sinon tente de charger depuis disque
		JobRpIdentity loaded = LoadFromDisk(uid);
		if (loaded)
		{
			m_Cache.Set(uid, loaded);
			return true;
		}
		return false;
	}
	
	//------------------------------------------------------------------------------------------------
	// Recupere l'identite d'un joueur (null si pas d'identite)
	//------------------------------------------------------------------------------------------------
	JobRpIdentity GetIdentity(string uid)
	{
		if (uid == "")
			return null;
		JobRpIdentity cached = m_Cache.Get(uid);
		if (cached)
			return cached;
		JobRpIdentity loaded = LoadFromDisk(uid);
		if (loaded)
			m_Cache.Set(uid, loaded);
		return loaded;
	}
	
	//------------------------------------------------------------------------------------------------
	// Supprime l'identite RP d'un joueur (admin uniquement).
	// - Retire l'identite du cache memoire
	// - Ecrase le fichier JSON avec des champs vides (le LoadFromDisk renvoie null
	//   si tous les champs sont vides - validation deja en place)
	// - Renvoie true si une identite existait et a ete supprimee
	//------------------------------------------------------------------------------------------------
	bool RemoveIdentity(string uid)
	{
		if (uid == "")
			return false;
		
		JobRpIdentity existing = GetIdentity(uid);
		if (!existing)
			return false;
		
		// Vide le cache memoire
		m_Cache.Remove(uid);
		
		// Ecrase le fichier JSON avec des champs vides
		// (LoadFromDisk retourne null si tous les champs sont vides - voir la validation)
		string path = BuildPath(uid);
		SCR_JsonSaveContext ctx = new SCR_JsonSaveContext();
		ctx.WriteValue("first_name", "");
		ctx.WriteValue("last_name", "");
		ctx.WriteValue("birth_date", "");
		ctx.WriteValue("created_time", 0);
		ctx.SaveToFile(path);
		
		Print(string.Format("[JobIdentityManager] Identite supprimee pour UID=%1", uid),
			LogLevel.NORMAL);
		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	// Cree et enregistre une nouvelle identite. Retourne false si le joueur en a deja une.
	//------------------------------------------------------------------------------------------------
	bool CreateIdentity(string uid, string firstName, string lastName, string birthDate)
	{
		if (uid == "")
			return false;
		
		// Verif unicite
		if (HasIdentity(uid))
			return false;
		
		// Validation simple : 3 champs non vides (apres trim mental)
		if (firstName == "" || lastName == "" || birthDate == "")
			return false;
		
		JobRpIdentity id = new JobRpIdentity();
		id.m_FirstName = firstName;
		id.m_LastName = lastName;
		id.m_BirthDate = birthDate;
		id.m_CreatedTime = JobTimeUtils.GetNow();
		
		m_Cache.Set(uid, id);
		SaveToDisk(uid, id);
		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	// Helper pour formater l'identite en libelle lisible : "Nom Prenom (DD/MM/YYYY)"
	//------------------------------------------------------------------------------------------------
	string FormatIdentity(JobRpIdentity id)
	{
		if (!id)
			return "";
		return string.Format("%1 %2 (ne le %3)",
			id.m_LastName, id.m_FirstName, id.m_BirthDate);
	}
	
	//------------------------------------------------------------------------------------------------
	// Renvoie le nom complet pour les hints (Prenom Nom) ou "" si pas d'identite
	//------------------------------------------------------------------------------------------------
	string GetDisplayName(string uid)
	{
		JobRpIdentity id = GetIdentity(uid);
		if (!id)
			return "";
		return id.m_FirstName + " " + id.m_LastName;
	}
	
	//------------------------------------------------------------------------------------------------
	// Helper central : retourne l'identite RP si dispo, sinon le playername passe en fallback.
	// Utilise pour les hints (vol, atm, justice, etc.) ou on prefere afficher le nom RP.
	//------------------------------------------------------------------------------------------------
	string GetDisplayNameOrFallback(string uid, string fallbackPlayerName)
	{
		string rpName = GetDisplayName(uid);
		if (rpName != "")
			return rpName;
		return fallbackPlayerName;
	}
	
	//------------------------------------------------------------------------------------------------
	// Version qui prend directement un playerId : utilise pour les hints ou on a juste l ID
	// Resoud automatiquement l UID via JobManager.
	//------------------------------------------------------------------------------------------------
	string GetDisplayNameByPlayerId(int playerId)
	{
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		string rpName = GetDisplayName(uid);
		if (rpName != "")
			return rpName;
		// Fallback : playername
		string playerName = GetGame().GetPlayerManager().GetPlayerName(playerId);
		return playerName;
	}
	
	//------------------------------------------------------------------------------------------------
	void SaveToDisk(string uid, JobRpIdentity id)
	{
		if (!id || uid == "")
			return;
		
		SCR_JsonSaveContext ctx = new SCR_JsonSaveContext();
		ctx.WriteValue("first_name", id.m_FirstName);
		ctx.WriteValue("last_name", id.m_LastName);
		ctx.WriteValue("birth_date", id.m_BirthDate);
		ctx.WriteValue("created_time", id.m_CreatedTime);
		ctx.SaveToFile(BuildPath(uid));
		
		Print(string.Format("[JobIdentityManager] Identite enregistree pour UID=%1 : %2 %3",
			uid, id.m_FirstName, id.m_LastName));
	}
	
	//------------------------------------------------------------------------------------------------
	JobRpIdentity LoadFromDisk(string uid)
	{
		if (uid == "")
			return null;
		SCR_JsonLoadContext ctx = new SCR_JsonLoadContext();
		if (!ctx.LoadFromFile(BuildPath(uid)))
			return null;
		
		JobRpIdentity id = new JobRpIdentity();
		ctx.ReadValue("first_name", id.m_FirstName);
		ctx.ReadValue("last_name", id.m_LastName);
		ctx.ReadValue("birth_date", id.m_BirthDate);
		ctx.ReadValue("created_time", id.m_CreatedTime);
		
		// Validation : si tous les champs sont vides, fichier corrompu
		if (id.m_FirstName == "" && id.m_LastName == "" && id.m_BirthDate == "")
			return null;
		
		return id;
	}
}
