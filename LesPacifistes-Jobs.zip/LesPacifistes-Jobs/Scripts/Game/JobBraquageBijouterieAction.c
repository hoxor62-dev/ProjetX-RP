//------------------------------------------------------------------------------------------------
// JobBraquageBijouterieAction.c
// UserAction a placer sur l entity bijouterie (placee dans Workbench).
// Au clic : envoie une RPC au serveur pour demarrer le braquage.
// Le serveur fait toutes les verifs (items, cooldown, deja en cours).
//------------------------------------------------------------------------------------------------

class JobBraquageBijouterieAction : ScriptedUserAction
{
	override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
	{
		PlayerController pc = PlayerController.Cast(GetGame().GetPlayerController());
		if (!pc) return;
		// Filtre dedicated server : seul le client propre de l action declenche
		if (pUserEntity != pc.GetControlledEntity()) return;
		
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		
		// On envoie la position de la bijouterie au serveur via la RPC pour qu il puisse
		// faire le broadcast de la sirene + envoyer les alertes SOS aux forces de l ordre.
		vector bijouterieOrigin = pOwnerEntity.GetOrigin();
		jpc.ClientAskStartBraquage(bijouterieOrigin);
	}
	
	override bool CanBePerformedScript(IEntity user)
	{
		return true;
	}
	
	override bool CanBeShownScript(IEntity user)
	{
		// Action toujours visible (les conditions sont check serveur-side au clic)
		return true;
	}
}
