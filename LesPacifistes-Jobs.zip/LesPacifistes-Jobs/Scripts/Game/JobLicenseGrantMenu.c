//------------------------------------------------------------------------------------------------
// JobLicenseGrantMenu.c
// Menu du concessionnaire pour delivrer un permis de conduire a un joueur proche.
// Liste uniquement les joueurs a moins de 10m. Coute 500 capsules au concessionnaire.
//------------------------------------------------------------------------------------------------

class JobLicenseGrantMenu : ChimeraMenuBase
{
	const float NEAR_DISTANCE = 10.0;
	const string ENTRY_LAYOUT_PATH = "{38EB876AF9C737C8}UI/layouts/JobAtmPlayerEntry.layout";
	
	Widget m_RootWidget;
	Widget m_EntriesContainer;
	ref map<ButtonWidget, int> m_ButtonToPlayerId = new map<ButtonWidget, int>();
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuOpen()
	{
		super.OnMenuOpen();
		m_RootWidget = GetRootWidget();
		if (!m_RootWidget)
			return;
		
		m_EntriesContainer = m_RootWidget.FindAnyWidget("PlayersContainer");
		
		ButtonWidget close = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("CloseButton"));
		if (close)
		{
			LicenseGrantClickHandler h = new LicenseGrantClickHandler();
			h.m_Menu = this;
			h.m_PlayerId = -1;
			close.AddHandler(h);
			JobFocusHandler.Attach(close);
		}
		
		BuildPlayerList();
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuUpdate(float tDelta)
	{
		super.OnMenuUpdate(tDelta);
		if (GetGame().GetInputManager().GetActionValue("MenuBack") > 0.5)
		{
			CloseMenuInternal();
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void Initialize()
	{
		// rien de special
	}
	
	//------------------------------------------------------------------------------------------------
	void BuildPlayerList()
	{
		if (!m_EntriesContainer)
			return;
		
		WorkspaceWidget ws = GetGame().GetWorkspace();
		PlayerController localPC = GetGame().GetPlayerController();
		if (!localPC)
			return;
		
		IEntity localChar = localPC.GetControlledEntity();
		if (!localChar)
			return;
		
		vector localPos = localChar.GetOrigin();
		int localPlayerId = localPC.GetPlayerId();
		
		PlayerManager pm = GetGame().GetPlayerManager();
		if (!pm)
			return;
		array<int> allIds = new array<int>();
		pm.GetPlayers(allIds);
		
		const int ENTRY_HEIGHT = 60;
		const int ENTRY_PADDING = 8;
		int yPos = 0;
		ButtonWidget firstBtn = null;
		
		foreach (int pid : allIds)
		{
			if (pid == localPlayerId)
				continue;
			
			IEntity target = pm.GetPlayerControlledEntity(pid);
			if (!target)
				continue;
			
			float dist = vector.Distance(localPos, target.GetOrigin());
			if (dist > NEAR_DISTANCE)
				continue;
			
			string playerName = pm.GetPlayerName(pid);
			if (playerName == "")
				playerName = "Joueur " + pid.ToString();
			
			Widget entry = ws.CreateWidgets(ENTRY_LAYOUT_PATH, m_EntriesContainer);
			if (!entry)
				continue;
			
			FrameSlot.SetPos(entry, 0, yPos);
			FrameSlot.SetSize(entry, 500, ENTRY_HEIGHT);
			yPos += ENTRY_HEIGHT + ENTRY_PADDING;
			
			TextWidget nameW = TextWidget.Cast(entry.FindAnyWidget("PlayerName"));
			if (nameW)
				nameW.SetText(string.Format("%1 (%2m)", playerName, Math.Floor(dist)));
			
			ButtonWidget btn = ButtonWidget.Cast(entry.FindAnyWidget("SelectButton"));
			if (btn)
			{
				// Change le texte du bouton
				TextWidget btnText = TextWidget.Cast(btn.FindAnyWidget("SelectText"));
				if (btnText)
					btnText.SetText("Delivrer");
				
				m_ButtonToPlayerId.Set(btn, pid);
				LicenseGrantClickHandler h = new LicenseGrantClickHandler();
				h.m_Menu = this;
				h.m_PlayerId = pid;
				btn.AddHandler(h);
				JobFocusHandler.Attach(btn);
				
				if (!firstBtn)
					firstBtn = btn;
			}
		}
		
		if (firstBtn)
			GetGame().GetWorkspace().SetFocusedWidget(firstBtn);
	}
	
	//------------------------------------------------------------------------------------------------
	void OnGrantClicked(int playerId)
	{
		if (playerId <= 0)
		{
			CloseMenuInternal();
			return;
		}
		
		PlayerController pc = GetGame().GetPlayerController();
		if (pc)
		{
			JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
			if (jpc)
				jpc.ClientAskGrantLicense(playerId);
		}
		CloseMenuInternal();
	}
	
	//------------------------------------------------------------------------------------------------
	void CloseMenuInternal()
	{
		GetGame().GetMenuManager().CloseMenu(this);
	}
}

class LicenseGrantClickHandler : ScriptedWidgetEventHandler
{
	JobLicenseGrantMenu m_Menu;
	int m_PlayerId;
	
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu)
			m_Menu.OnGrantClicked(m_PlayerId);
		return true;
	}
}
