//------------------------------------------------------------------------------------------------
// Ancre de lockout prison longue : position centrale + playerId.
// Un joueur en prison longue est bloque dans un rayon de LONG_PRISON_RADIUS metres autour
// de l anchor jusqu a la fin de sa peine (ou liberation manuelle).
//------------------------------------------------------------------------------------------------
class JobLongPrisonLockout
{
	vector m_Anchor;
	int m_PlayerId;
}

class JobCriminalManager
{
	// Singleton
	static ref JobCriminalManager s_Instance;

	// Map UID -> record
	ref map<string, ref CriminalRecord> m_Records;

	// === LOCKOUT PRISON LONGUE (bloque dans un rayon pendant la peine) ===
	const float LONG_PRISON_RADIUS = 150.0;      // meme rayon que la prison whitelist
	const int LONG_PRISON_TICK_MS = 1000;        // check de distance toutes les 1s
	ref map<int, ref JobLongPrisonLockout> m_LongPrisonLockouts = new map<int, ref JobLongPrisonLockout>();
	bool m_LongPrisonTickActive = false;
	
	// Constantes configurables
	const int PRISON_AUTO_RELEASE_SECONDS = 900;    // 15 minutes (defaut si aucune duree specifiee)
	// Anciens : FINE_DEADLINE_SECONDS = 600 (prison auto apres 10min) - retire au profit du systeme de majoration
	// Nouveau systeme : 15min sans paiement -> majoration +15%, 30min -> 2eme majoration, 45min -> prelevement auto
	const int FINE_MAJORATION_DELAY_SECONDS = 600;  // 15 minutes entre chaque majoration
	const int FINE_MAJORATION_PERCENT = 15;         // +15% par majoration
	const int FINE_MAX_MAJORATIONS = 2;             // au bout de 2 majorations, prelevement automatique
	const int ROB_COOLDOWN_SECONDS = 1800;          // 30 minutes cooldown vol par couple
	const int ROB_MIN_PERCENT = 1;                  // % minimum du solde vole
	const int ROB_MAX_PERCENT = 3;                  // % maximum du solde vole
	const int LICENSE_PRICE = 500;                  // prix permis de conduire
	
	// Coordonnees prison courte / garde a vue (a modifier par le boss)
	const float PRISON_ENTRY_X = 4261.067;
	const float PRISON_ENTRY_Y = 46.927;
	const float PRISON_ENTRY_Z = 3232.707;
	const float PRISON_RELEASE_X = 4246.226;
	const float PRISON_RELEASE_Y = 47.251;
	const float PRISON_RELEASE_Z = 3240.877;

	// Coordonnees de liberation prison longue (differente de la gendarmerie)
	const float LONG_PRISON_RELEASE_X = 3412.133;
	const float LONG_PRISON_RELEASE_Y = 25.107;
	const float LONG_PRISON_RELEASE_Z = 4554.229;
	
	
	

	// Coordonnees prison longue (60/90/120 min). 5 points, tirage aleatoire.
	// Memes points que la prison "whitelist" (zone d incarceration dediee).
	static const vector LONG_PRISON_COORD_0 = "3394.562 24.542 4651.505";
	static const vector LONG_PRISON_COORD_1 = "3402.148 24.57 4669.559";
	static const vector LONG_PRISON_COORD_2 = "3412.73 24.646 4667.053";
	static const vector LONG_PRISON_COORD_3 = "3430.841 24.683 4657.229";
	static const vector LONG_PRISON_COORD_4 = "3423.159 24.727 4647.323";
	
	const string SAVE_PATH = "$profile:LesPacifistesJobs/criminal_records.json";
	
	//------------------------------------------------------------------------------------------------
	// === DEBOUNCE DES SAVES ===
	// criminal_records.json peut atteindre 1+ MB. Pour eviter les ecritures bloquantes
	// repetees (ex: Tick 10s qui majore 10 amendes = 10 SaveToDisk de 1 MB), on groupe
	// toutes les ecritures en 1 flush toutes les SAVE_DEBOUNCE_MS.
	const int SAVE_DEBOUNCE_MS = 5000;
	bool m_bSaveDirty = false;
	bool m_bSaveScheduled = false;

	void JobCriminalManager()
	{
		m_Records = new map<string, ref CriminalRecord>();
	}

	//------------------------------------------------------------------------------------------------
	// Marque le save disque comme dirty. L ecriture sera effectuee au prochain flush
	// (dans SAVE_DEBOUNCE_MS). Si plusieurs appels dans la fenetre, 1 seule ecriture.
	//------------------------------------------------------------------------------------------------
	void MarkSaveDirty()
	{
		m_bSaveDirty = true;
		if (!m_bSaveScheduled)
		{
			m_bSaveScheduled = true;
			GetGame().GetCallqueue().CallLater(FlushSave, SAVE_DEBOUNCE_MS, false);
		}
	}

	//------------------------------------------------------------------------------------------------
	// CORRECTIF CRITIQUE 11 nov 2026
	// Cette fonction appelait MarkSaveDirty() au lieu de SaveToDisk(), consequence d un
	// remplacement automatique trop large lors de la mise en place du debounce le 30 oct.
	// Resultat : FlushSave se reprogrammait indefiniment et SaveToDisk n etait JAMAIS appele.
	// criminal_records.json n a donc plus ete ecrit sur disque depuis cette date : permis,
	// amendes, prisons et mentions etaient perdus a chaque reboot.
	//------------------------------------------------------------------------------------------------
	void FlushSave()
	{
		m_bSaveScheduled = false;
		if (!m_bSaveDirty)
			return;
		m_bSaveDirty = false;
		int t0 = System.GetTickCount();
		SaveToDisk();
		int elapsed = System.GetTickCount() - t0;
		if (elapsed > 50)
			Print(string.Format("[JobCriminalManager] FlushSave : ecriture disque = %1 ms (%2 records)",
				elapsed, m_Records.Count()), LogLevel.WARNING);
	}

	//------------------------------------------------------------------------------------------------
	// Ecriture IMMEDIATE, sans attendre la fenetre de debounce.
	// Reservee aux operations critiques et peu frequentes dont la perte serait visible par le
	// joueur (permis accorde ou retire). Les operations a haute frequence du Tick continuent
	// d utiliser MarkSaveDirty pour ne pas recreer les pics CPU du 30 octobre.
	//------------------------------------------------------------------------------------------------
	void FlushSaveNow()
	{
		m_bSaveDirty = false;
		SaveToDisk();
	}
	
	//------------------------------------------------------------------------------------------------
	static JobCriminalManager GetInstance()
	{
		if (!s_Instance)
		{
			s_Instance = new JobCriminalManager();
			s_Instance.LoadFromDisk();
			// Tick a 10s (prisons en minutes, majorations toutes les 15 min : la precision 1s
			// etait un gaspillage CPU - gain ~90% sur ce manager, zero impact gameplay)
			GetGame().GetCallqueue().CallLater(TickCallback, 10000, true);
		}
		return s_Instance;
	}
	
	//------------------------------------------------------------------------------------------------
	// Tick global (server uniquement) - verifie prisons a liberer et amendes overdue
	//------------------------------------------------------------------------------------------------
	static void TickCallback()
	{
		if (!Replication.IsServer())
			return;
		if (!s_Instance)
			return;
		s_Instance.Tick();
	}
	
	//------------------------------------------------------------------------------------------------
	void Tick()
	{
		int now = JobTimeUtils.GetNow();
		
		array<string> keysToCheck = new array<string>();
		foreach (string uid, CriminalRecord rec : m_Records)
		{
			keysToCheck.Insert(uid);
		}
		
		foreach (string uid : keysToCheck)
		{
			CriminalRecord rec = m_Records.Get(uid);
			if (!rec)
				continue;
			
			// 1) Auto-liberation prison (robuste au reboot serveur)
			// Utilise la duree specifique du record (m_PrisonDurationSeconds) si > 0,
			// sinon fallback sur PRISON_AUTO_RELEASE_SECONDS (compat records anciens).
			if (rec.m_InPrison && rec.m_PrisonEntryTime > 0)
			{
				int releaseDuration = rec.m_PrisonDurationSeconds;
				if (releaseDuration <= 0)
					releaseDuration = PRISON_AUTO_RELEASE_SECONDS;
				
				// Detection reboot : si timestamp > now, on libere immediatement
				// (le joueur a deja "purge" sa peine puisque GetWorldTime a ete reset)
				if (rec.m_PrisonEntryTime > now)
				{
					ReleaseFromPrison(uid, true);
				}
				else if (now - rec.m_PrisonEntryTime >= releaseDuration)
				{
					ReleaseFromPrison(uid, true);
				}
			}
			
			// 2) Systeme de majoration / prelevement automatique des amendes
			//    Pour chaque amende impayee :
			//    - Apres 15min sans paiement -> +15% (1ere majoration)
			//    - Apres 30min sans paiement -> +15% supplementaire (2eme majoration)
			//    - Apres 45min sans paiement -> prelevement automatique
			ProcessFineMajorationsAndAutoCollection(uid, rec, now);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Pour chaque amende impayee : applique les majorations dues et fait le prelevement auto si delai expire
	//------------------------------------------------------------------------------------------------
	void ProcessFineMajorationsAndAutoCollection(string uid, CriminalRecord rec, int now)
	{
		if (!rec || !rec.m_Fines)
			return;
		
		bool dirty = false;
		
		foreach (FineRecord f : rec.m_Fines)
		{
			if (!f || f.m_Paid)
				continue;
			
			// Robustesse au reboot : si timestamp dans le futur, considere "frais"
			int issued = f.m_IssuedTimestamp;
			if (issued > now)
				continue;
			
			int elapsed = now - issued;
			
			// Calcule combien de majorations devraient avoir ete appliquees a ce stade
			// Note : on multiplie pour eviter une division qui truncate plus tard
			int dueMajorations = elapsed / FINE_MAJORATION_DELAY_SECONDS;
			if (dueMajorations > FINE_MAX_MAJORATIONS)
				dueMajorations = FINE_MAX_MAJORATIONS;
			
			// Applique les majorations manquantes une par une
			while (f.m_MajorationsApplied < dueMajorations)
			{
				// Majoration de m_Amount de +FINE_MAJORATION_PERCENT %
				int increase = (f.m_Amount * FINE_MAJORATION_PERCENT) / 100;
				if (increase < 1)
					increase = 1; // au moins +1 capsule pour eviter les amendes minuscules immobiles
				f.m_Amount = f.m_Amount + increase;
				f.m_MajorationsApplied = f.m_MajorationsApplied + 1;
				dirty = true;
				
				// Notif au joueur (s il est connecte)
				int delayLeft = FINE_MAJORATION_DELAY_SECONDS * (FINE_MAX_MAJORATIONS - f.m_MajorationsApplied + 1);
				int delayLeftMin = delayLeft / 60;
				
				string msg;
				if (f.m_MajorationsApplied >= FINE_MAX_MAJORATIONS)
				{
					msg = string.Format(
						"[JUSTICE] Majoration de votre amende impayee : nouveau montant %1 capsules. Prelevement automatique dans %2 minutes.",
						f.m_Amount, delayLeftMin);
				}
				else
				{
					msg = string.Format(
						"[JUSTICE] Majoration de votre amende impayee : nouveau montant %1 capsules. Payez avant prochaine majoration dans %2 minutes.",
						f.m_Amount, delayLeftMin);
				}
				NotifyPlayerByUID(uid, msg);
			}
			
			// Verifie si on doit faire le prelevement automatique
			// Conditions : 2 majorations appliquees ET delai de la 3eme echeance ecoule
			if (f.m_MajorationsApplied >= FINE_MAX_MAJORATIONS
				&& elapsed >= (FINE_MAJORATION_DELAY_SECONDS * (FINE_MAX_MAJORATIONS + 1)))
			{
				// Prelevement
				AutoCollectFine(uid, f, now);
				dirty = true;
			}
		}
		
		if (dirty)
			MarkSaveDirty();
	}

	//------------------------------------------------------------------------------------------------
	// Effectue le prelevement automatique d une amende :
	//  - Prend ce qu il peut (limite : capsules dispo)
	//  - Marque l amende comme payee
	//  - Notifie le joueur
	//------------------------------------------------------------------------------------------------
	void AutoCollectFine(string uid, FineRecord fine, int now)
	{
		CapsuleEconomyManager eco = CapsuleEconomyManager.GetInstance();
		if (!eco)
			return;
		
		int currentBalance = eco.GetCapsules(uid);
		int amountToCollect = fine.m_Amount;
		
		// Limite au solde disponible (le joueur reste a zero si insuffisant)
		int actuallyCollected = amountToCollect;
		if (currentBalance < amountToCollect)
			actuallyCollected = currentBalance;
		
		if (actuallyCollected > 0)
			eco.AddCapsules(uid, -actuallyCollected);
		
		// Marque l amende payee (peu importe si le prelevement a ete partiel)
		fine.m_Paid = true;
		fine.m_PaidTimestamp = now;
		fine.m_AutoCollected = true;
		
		// Notif au joueur
		if (actuallyCollected >= amountToCollect)
		{
			NotifyPlayerByUID(uid,
				string.Format(
					"[JUSTICE] Prelevement automatique : %1 capsules ont ete prelevees pour votre amende impayee.",
					actuallyCollected));
		}
		else if (actuallyCollected > 0)
		{
			NotifyPlayerByUID(uid,
				string.Format(
					"[JUSTICE] Prelevement automatique : %1 capsules prelevees (montant insuffisant - reste %2 capsules de dette annulees).",
					actuallyCollected, amountToCollect - actuallyCollected));
		}
		else
		{
			NotifyPlayerByUID(uid,
				string.Format(
					"[JUSTICE] Amende impayee annulee : vous n aviez aucune capsule a prelever (%1 capsules annulees).",
					amountToCollect));
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Acces / creation du record d'un joueur (server uniquement)
	//------------------------------------------------------------------------------------------------
	CriminalRecord GetOrCreateRecord(string uid, string playerName)
	{
		if (uid == "")
			return null;
		CriminalRecord rec = m_Records.Get(uid);
		if (!rec)
		{
			rec = new CriminalRecord();
			rec.m_PlayerUID = uid;
			rec.m_PlayerName = playerName;
			m_Records.Insert(uid, rec);
			MarkSaveDirty();
		}
		else
		{
			// Met a jour le nom connu
			if (playerName != "" && playerName != rec.m_PlayerName)
				rec.m_PlayerName = playerName;
		}
		return rec;
	}
	
	//------------------------------------------------------------------------------------------------
	CriminalRecord GetRecord(string uid)
	{
		if (uid == "")
			return null;
		return m_Records.Get(uid);
	}
	
	//------------------------------------------------------------------------------------------------
	// Emission d'une amende: renvoie false si impossible
	//------------------------------------------------------------------------------------------------
	bool IssueFine(string targetUID, string targetName, EFineLevel level,
		int issuerPlayerId, string issuerName)
	{
		if (level == EFineLevel.NONE)
			return false;
		
		CriminalRecord rec = GetOrCreateRecord(targetUID, targetName);
		if (!rec)
			return false;
		
		FineRecord f = new FineRecord();
		f.m_Level = level;
		f.m_Amount = JobFineAmounts.GetAmount(level);
		f.m_OriginalAmount = f.m_Amount;  // conserve le montant initial pour reference
		f.m_IssuedTimestamp = JobTimeUtils.GetNow();
		f.m_IssuerPlayerId = issuerPlayerId;
		f.m_IssuerName = issuerName;
		f.m_Paid = false;
		rec.m_Fines.Insert(f);
		
		MarkSaveDirty();
		
		// --- STATS RP : incremente le compteur infractions du joueur cible ---
		int targetPlayerId = GetPlayerIdFromUID(targetUID);
		if (targetPlayerId > 0)
		{
			JobPlayerData stats = JobManager.GetInstance().GetPlayerData(targetPlayerId);
			if (stats)
			{
				stats.m_TotalInfractions = stats.m_TotalInfractions + 1;
				JobManager.GetInstance().SavePlayerData(targetPlayerId);
			}
		}
		
		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	// Paiement d'une amende: retourne le montant a deduire (0 si aucune amende due)
	// La deduction de capsules doit etre faite par l'appelant via JobPlayerComponent
	//------------------------------------------------------------------------------------------------
	int GetDueFineAmount(string targetUID, int issuerPlayerId)
	{
		CriminalRecord rec = GetRecord(targetUID);
		if (!rec)
			return 0;
		FineRecord f = rec.GetOldestUnpaidFine(issuerPlayerId);
		if (!f)
			return 0;
		return f.m_Amount;
	}
	
	//------------------------------------------------------------------------------------------------
	// Marque l'amende la plus ancienne comme payee
	//------------------------------------------------------------------------------------------------
	bool MarkFinePaid(string targetUID, int issuerPlayerId)
	{
		CriminalRecord rec = GetRecord(targetUID);
		if (!rec)
			return false;
		FineRecord f = rec.GetOldestUnpaidFine(issuerPlayerId);
		if (!f)
			return false;
		f.m_Paid = true;
		f.m_PaidTimestamp = JobTimeUtils.GetNow();
		MarkSaveDirty();
		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	// Ajoute une mention manuelle au casier
	//------------------------------------------------------------------------------------------------
	void AddMention(string targetUID, string targetName, string text, string issuerName)
	{
		if (text == "")
			return;
		CriminalRecord rec = GetOrCreateRecord(targetUID, targetName);
		if (!rec)
			return;
		MentionRecord m = new MentionRecord();
		m.m_Text = text;
		m.m_IssuerName = issuerName;
		// IMPORTANT : Unix time (persistant) et NON JobTimeUtils.GetNow() qui reset au reboot
		// (sinon la fiche RP affiche "56 ans" apres un reboot car le formatter traite comme vieux unix time)
		m.m_Timestamp = System.GetUnixTime();
		rec.m_Mentions.Insert(m);
		MarkSaveDirty();
	}
	
	//------------------------------------------------------------------------------------------------
	// Permis de conduire
	//------------------------------------------------------------------------------------------------
	// Ecriture immediate : un permis accorde ou retiré doit survivre meme si le serveur
	// redemarre dans les secondes qui suivent. Operations rares, pas de risque CPU.
	void GrantLicense(string targetUID, string targetName)
	{
		CriminalRecord rec = GetOrCreateRecord(targetUID, targetName);
		if (!rec)
			return;
		rec.m_HasDrivingLicense = true;
		FlushSaveNow();
	}

	void RevokeLicense(string targetUID)
	{
		CriminalRecord rec = GetRecord(targetUID);
		if (!rec)
			return;
		rec.m_HasDrivingLicense = false;
		FlushSaveNow();
	}
	
	bool HasLicense(string uid)
	{
		CriminalRecord rec = GetRecord(uid);
		if (!rec)
			return false;
		return rec.m_HasDrivingLicense;
	}
	
	//------------------------------------------------------------------------------------------------
	// Prison : envoie un joueur en prison (teleport + enregistrement).
	// durationSeconds : duree specifique en secondes. Si <= 0 -> defaut PRISON_AUTO_RELEASE_SECONDS.
	//------------------------------------------------------------------------------------------------
	void SendToPrison(string uid, int durationSeconds = 0)
	{
		CriminalRecord rec = GetRecord(uid);
		if (!rec)
			return;
		rec.m_InPrison = true;
		rec.m_PrisonEntryTime = JobTimeUtils.GetNow();
		if (durationSeconds <= 0)
			durationSeconds = PRISON_AUTO_RELEASE_SECONDS;
		rec.m_PrisonDurationSeconds = durationSeconds;
		rec.m_IsLongPrison = false; // prison courte = gendarmerie
		MarkSaveDirty();
		
		// Auto-sync statut judiciaire : passe a IN_PRISON avec detail sur la duree
		int durationMin = durationSeconds / 60;
		string detail = string.Format("Peine de %1 minutes en cours", durationMin.ToString());
		JobPoliceRecordManager.GetInstance().GetOrCreateRecord(uid, rec.m_PlayerName);
		JobPoliceRecordManager.GetInstance().SetStatus(uid, EJudicialStatus.IN_PRISON, detail);
		
		// Teleport du joueur
		int playerId = GetPlayerIdFromUID(uid);
		if (playerId > 0)
		{
			TeleportPlayer(playerId, PRISON_ENTRY_X, PRISON_ENTRY_Y, PRISON_ENTRY_Z);
			NotifyPlayerById(playerId,
				string.Format("[JUSTICE] Vous avez ete emprisonne pour %1 minutes.", durationMin));
			
			// --- STATS RP : incremente le compteur fois en prison ---
			JobPlayerData stats = JobManager.GetInstance().GetPlayerData(playerId);
			if (stats)
			{
				stats.m_TimesJailed = stats.m_TimesJailed + 1;
				JobManager.GetInstance().SavePlayerData(playerId);
			}
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Prison LONGUE (60/90/120 min) : teleporte vers 1 des 5 points aleatoires.
	// Reutilise le record (m_InPrison + duration) pour que le tick d auto-release existant fonctionne.
	// La liberation reutilise ReleaseFromPrison standard (teleport vers PRISON_RELEASE).
	//------------------------------------------------------------------------------------------------
	void SendToLongPrison(string uid, int durationSeconds)
	{
		CriminalRecord rec = GetRecord(uid);
		if (!rec)
			return;
		rec.m_InPrison = true;
		rec.m_PrisonEntryTime = JobTimeUtils.GetNow();
		if (durationSeconds <= 0)
			durationSeconds = PRISON_AUTO_RELEASE_SECONDS;
		rec.m_PrisonDurationSeconds = durationSeconds;
		rec.m_IsLongPrison = true; // prison longue = liberation a LONG_PRISON_RELEASE
		MarkSaveDirty();

		int durationMin = durationSeconds / 60;
		string detail = string.Format("Peine longue de %1 minutes en cours", durationMin.ToString());
		JobPoliceRecordManager.GetInstance().GetOrCreateRecord(uid, rec.m_PlayerName);
		JobPoliceRecordManager.GetInstance().SetStatus(uid, EJudicialStatus.IN_PRISON, detail);

		int playerId = GetPlayerIdFromUID(uid);
		if (playerId > 0)
		{
			// Tirage aleatoire 1 des 5 points
			vector target;
			int idx = Math.RandomInt(0, 5);
			switch (idx)
			{
				case 0: target = LONG_PRISON_COORD_0; break;
				case 1: target = LONG_PRISON_COORD_1; break;
				case 2: target = LONG_PRISON_COORD_2; break;
				case 3: target = LONG_PRISON_COORD_3; break;
				case 4: target = LONG_PRISON_COORD_4; break;
				default: target = LONG_PRISON_COORD_0;
			}

			TeleportPlayer(playerId, target[0], target[1], target[2]);
			NotifyPlayerById(playerId,
				string.Format("[JUSTICE] Vous avez ete envoye en prison pour %1 minutes.", durationMin));

			// Active le lockout 150m autour du point d ancrage (tirage aleatoire ci-dessus)
			// Le joueur sera re-teleporte au centre s il essaie de sortir, jusqu a la fin de peine.
			AddLongPrisonLockout(playerId, target);

			// Stats RP : incremente le compteur fois en prison
			JobPlayerData stats = JobManager.GetInstance().GetPlayerData(playerId);
			if (stats)
			{
				stats.m_TimesJailed = stats.m_TimesJailed + 1;
				JobManager.GetInstance().SavePlayerData(playerId);
			}
		}
	}

	//------------------------------------------------------------------------------------------------
	// === LOCKOUT PRISON LONGUE ===
	// Ajoute un joueur a la map des joueurs bloques dans un rayon autour d un anchor.
	// Demarre le tick de surveillance si pas deja actif.
	//------------------------------------------------------------------------------------------------
	void AddLongPrisonLockout(int playerId, vector anchor)
	{
		JobLongPrisonLockout lo = new JobLongPrisonLockout();
		lo.m_Anchor = anchor;
		lo.m_PlayerId = playerId;
		m_LongPrisonLockouts.Set(playerId, lo);

		if (!m_LongPrisonTickActive)
		{
			m_LongPrisonTickActive = true;
			GetGame().GetCallqueue().CallLater(TickLongPrisonLockoutStatic, LONG_PRISON_TICK_MS, true);
			Print("[JobCriminalManager] Tick lockout prison longue demarre", LogLevel.NORMAL);
		}
		Print(string.Format("[JobCriminalManager] Lockout prison longue ajoute : playerId=%1 anchor=%2",
			playerId, anchor.ToString()), LogLevel.NORMAL);
	}

	//------------------------------------------------------------------------------------------------
	// Retire un joueur du lockout (appele a la liberation ou deconnexion).
	//------------------------------------------------------------------------------------------------
	void RemoveLongPrisonLockout(int playerId)
	{
		if (m_LongPrisonLockouts.Contains(playerId))
			m_LongPrisonLockouts.Remove(playerId);
	}

	//------------------------------------------------------------------------------------------------
	// Entry point static pour CallLater (singleton -> instance)
	//------------------------------------------------------------------------------------------------
	static void TickLongPrisonLockoutStatic()
	{
		if (!Replication.IsServer())
			return;
		if (!s_Instance)
			return;
		s_Instance.TickLongPrisonLockout();
	}

	//------------------------------------------------------------------------------------------------
	// Tick 1s : parcourt les joueurs sous lockout, re-teleport si > 150m de l anchor.
	// Nettoie les joueurs deconnectes. Arrete le tick si plus personne sous lockout.
	//------------------------------------------------------------------------------------------------
	void TickLongPrisonLockout()
	{
		int count = m_LongPrisonLockouts.Count();
		if (count == 0)
		{
			GetGame().GetCallqueue().Remove(TickLongPrisonLockoutStatic);
			m_LongPrisonTickActive = false;
			Print("[JobCriminalManager] Tick lockout prison longue arrete (plus personne)", LogLevel.NORMAL);
			return;
		}

		PlayerManager pm = GetGame().GetPlayerManager();
		if (!pm)
			return;

		array<int> toRemove = new array<int>();

		for (int i = 0; i < count; i++)
		{
			int playerId = m_LongPrisonLockouts.GetKey(i);
			JobLongPrisonLockout lo = m_LongPrisonLockouts.GetElement(i);
			if (!lo)
			{
				toRemove.Insert(playerId);
				continue;
			}

			PlayerController pc = pm.GetPlayerController(playerId);
			if (!pc)
			{
				// Joueur deconnecte : on retire du lockout. S il reconnecte pendant sa peine,
				// le Tick principal gere la fin, mais pas la re-position. Un hook OnPlayerConnected
				// pourrait relocker si besoin (TODO si demande).
				toRemove.Insert(playerId);
				continue;
			}

			IEntity ent = pc.GetControlledEntity();
			if (!ent)
				continue; // entite pas prete, retry prochain tick

			vector curPos = ent.GetOrigin();
			float dist = vector.Distance(curPos, lo.m_Anchor);
			if (dist > LONG_PRISON_RADIUS)
			{
				// Hors zone : re-teleport au centre
				CapsulePlayerComponent cpc = CapsulePlayerComponent.Cast(pc.FindComponent(CapsulePlayerComponent));
				if (cpc)
				{
					cpc.Svr_TeleportToPosition(lo.m_Anchor[0], lo.m_Anchor[1], lo.m_Anchor[2]);
				}
				else
				{
					ent.SetOrigin(lo.m_Anchor);
					ent.Update();
				}
				// Notif
				JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
				if (jpc)
					jpc.ServerShowHint("Vous ne pouvez pas sortir de la prison tant que votre peine n est pas purgee.");
			}
		}

		foreach (int pid : toRemove)
			m_LongPrisonLockouts.Remove(pid);
	}

	void ReleaseFromPrison(string uid, bool isAuto)
	{
		CriminalRecord rec = GetRecord(uid);
		if (!rec)
			return;
		rec.m_InPrison = false;
		rec.m_PrisonEntryTime = 0;
		rec.m_PrisonDurationSeconds = 0;
		MarkSaveDirty();
		
		// Auto-sync statut judiciaire : SI le statut actuel est IN_PRISON, repasse a FREE.
		// Sinon (ex: WANTED en attente d une autre affaire), ne touche pas au manuel.
		PoliceRecord policeRec = JobPoliceRecordManager.GetInstance().GetRecord(uid);
		if (policeRec && policeRec.m_Status == EJudicialStatus.IN_PRISON)
			JobPoliceRecordManager.GetInstance().SetStatus(uid, EJudicialStatus.FREE, "");
		
		int playerId = GetPlayerIdFromUID(uid);
		if (playerId > 0)
		{
			// Retire le lockout 150m si le joueur etait en prison longue
			RemoveLongPrisonLockout(playerId);

			// Position de liberation : longue vs courte selon le type de peine
			if (rec.m_IsLongPrison)
				TeleportPlayer(playerId, LONG_PRISON_RELEASE_X, LONG_PRISON_RELEASE_Y, LONG_PRISON_RELEASE_Z);
			else
				TeleportPlayer(playerId, PRISON_RELEASE_X, PRISON_RELEASE_Y, PRISON_RELEASE_Z);

			if (isAuto)
				NotifyPlayerById(playerId, "[JUSTICE] Peine purgee - vous etes libere");
			else
				NotifyPlayerById(playerId, "[JUSTICE] Vous avez ete libere par les forces de l'ordre");
		}

		// Reset du flag apres liberation (le record est reutilise pour la prochaine peine)
		rec.m_IsLongPrison = false;
	}
	
	//------------------------------------------------------------------------------------------------
	// Vol - verification de cooldown
	// Retourne 0 si OK, 1 si voleur en cooldown, 2 si victime en cooldown
	// Robuste au reboot serveur via JobTimeUtils.
	//------------------------------------------------------------------------------------------------
	int CanRob(string robberUID, string victimUID)
	{
		CriminalRecord robberRec = GetOrCreateRecord(robberUID, "");
		CriminalRecord victimRec = GetOrCreateRecord(victimUID, "");
		if (!robberRec || !victimRec)
			return 1;
		
		if (JobTimeUtils.IsInCooldown(robberRec.m_LastTimeIRobbed, ROB_COOLDOWN_SECONDS))
			return 1;
		if (JobTimeUtils.IsInCooldown(victimRec.m_LastTimeIWasRobbed, ROB_COOLDOWN_SECONDS))
			return 2;
		return 0;
	}
	
	//------------------------------------------------------------------------------------------------
	// Renvoie le temps restant en secondes du cooldown du voleur
	//------------------------------------------------------------------------------------------------
	int GetRobberCooldownRemaining(string robberUID)
	{
		CriminalRecord rec = GetRecord(robberUID);
		if (!rec)
			return 0;
		return JobTimeUtils.CooldownRemaining(rec.m_LastTimeIRobbed, ROB_COOLDOWN_SECONDS);
	}
	
	//------------------------------------------------------------------------------------------------
	// Renvoie le temps restant en secondes du cooldown de la victime
	//------------------------------------------------------------------------------------------------
	int GetVictimCooldownRemaining(string victimUID)
	{
		CriminalRecord rec = GetRecord(victimUID);
		if (!rec)
			return 0;
		return JobTimeUtils.CooldownRemaining(rec.m_LastTimeIWasRobbed, ROB_COOLDOWN_SECONDS);
	}
	
	//------------------------------------------------------------------------------------------------
	// Enregistre un vol : cooldowns sur les 2 joueurs
	//------------------------------------------------------------------------------------------------
	void RecordRob(string robberUID, string victimUID)
	{
		CriminalRecord robberRec = GetOrCreateRecord(robberUID, "");
		CriminalRecord victimRec = GetOrCreateRecord(victimUID, "");
		if (!robberRec || !victimRec)
			return;
		int now = JobTimeUtils.GetNow();
		robberRec.m_LastTimeIRobbed = now;
		victimRec.m_LastTimeIWasRobbed = now;
		MarkSaveDirty();
	}
	
	//------------------------------------------------------------------------------------------------
	// Helpers utilitaires
	//------------------------------------------------------------------------------------------------
	static int GetPlayerIdFromUID(string uid)
	{
		// Recupere le playerId en session a partir de l'UID persistant
		if (uid == "")
			return 0;
		PlayerManager pm = GetGame().GetPlayerManager();
		if (!pm)
			return 0;
		array<int> ids = new array<int>();
		pm.GetPlayers(ids);
		foreach (int id : ids)
		{
			string playerUID = GetGame().GetBackendApi().GetPlayerIdentityId(id);
			if (playerUID == uid)
				return id;
		}
		return 0;
	}
	
	static string GetUIDFromPlayerId(int playerId)
	{
		if (playerId <= 0)
			return "";
		return GetGame().GetBackendApi().GetPlayerIdentityId(playerId);
	}
	
	static string GetPlayerNameById(int playerId)
	{
		if (playerId <= 0)
			return "";
		PlayerManager pm = GetGame().GetPlayerManager();
		if (!pm)
			return "";
		return pm.GetPlayerName(playerId);
	}
	
	static void TeleportPlayer(int playerId, float x, float y, float z)
	{
		// IMPORTANT : SetOrigin cote serveur seul ne replique PAS sur les personnages joueurs.
		// On passe par CapsulePlayerComponent.Svr_TeleportToPosition (mod LesPacifistesShopEco)
		// qui fait : SetOrigin serveur + RPC vers client owner pour SetOrigin local + correction hauteur.
		PlayerManager pm = GetGame().GetPlayerManager();
		if (!pm)
			return;
		PlayerController pc = pm.GetPlayerController(playerId);
		if (!pc)
		{
			Print(string.Format("[JobCriminalManager] TeleportPlayer: PlayerController introuvable pour playerId=%1", playerId), LogLevel.WARNING);
			return;
		}
		
		CapsulePlayerComponent caps = CapsulePlayerComponent.Cast(pc.FindComponent(CapsulePlayerComponent));
		if (!caps)
		{
			Print(string.Format("[JobCriminalManager] TeleportPlayer: CapsulePlayerComponent introuvable pour playerId=%1 - fallback SetOrigin local", playerId), LogLevel.WARNING);
			// Fallback : tente SetOrigin direct (peut ne pas repliquer)
			IEntity player = pc.GetControlledEntity();
			if (player)
			{
				player.SetOrigin(Vector(x, y, z));
				player.Update();
			}
			return;
		}
		
		// Methode validee en prod : passe par le composant existant qui a un RPC owner fonctionnel
		caps.Svr_TeleportToPosition(x, y, z);
		Print(string.Format("[JobCriminalManager] TeleportPlayer: pid=%1 -> (%2, %3, %4) via CapsulePlayerComponent",
			playerId, x, y, z), LogLevel.NORMAL);
	}
	
	static void NotifyPlayerById(int playerId, string msg)
	{
		// Reutilise le systeme du JobManager
		if (JobManager.GetInstance())
			JobManager.GetInstance().NotifyPlayerChat(playerId, msg);
	}
	
	void NotifyPlayerByUID(string uid, string msg)
	{
		int pid = GetPlayerIdFromUID(uid);
		if (pid > 0)
			NotifyPlayerById(pid, msg);
	}
	
	//------------------------------------------------------------------------------------------------
	// Serialisation JSON (format simple, un record par ligne dans un container dedie)
	//------------------------------------------------------------------------------------------------
	void SaveToDisk()
	{
		SCR_JsonSaveContext ctx = new SCR_JsonSaveContext();
		
		array<string> allUIDs = new array<string>();
		foreach (string uid, CriminalRecord rec : m_Records)
		{
			if (rec)
				allUIDs.Insert(uid);
		}
		
		ctx.WriteValue("uids", allUIDs);
		
		foreach (string uid : allUIDs)
		{
			CriminalRecord rec = m_Records.Get(uid);
			if (!rec)
				continue;
			
			string prefix = "rec_" + uid + "_";
			ctx.WriteValue(prefix + "name", rec.m_PlayerName);
			ctx.WriteValue(prefix + "license", rec.m_HasDrivingLicense);
			ctx.WriteValue(prefix + "in_prison", rec.m_InPrison);
			ctx.WriteValue(prefix + "prison_time", rec.m_PrisonEntryTime);
			ctx.WriteValue(prefix + "prison_duration", rec.m_PrisonDurationSeconds);
			ctx.WriteValue(prefix + "is_long_prison", rec.m_IsLongPrison);
			ctx.WriteValue(prefix + "rob_robber", rec.m_LastTimeIRobbed);
			ctx.WriteValue(prefix + "rob_victim", rec.m_LastTimeIWasRobbed);
			ctx.WriteValue(prefix + "fines_count", rec.m_Fines.Count());
			ctx.WriteValue(prefix + "mentions_count", rec.m_Mentions.Count());
			
			// Amendes
			for (int i = 0; i < rec.m_Fines.Count(); i++)
			{
				FineRecord f = rec.m_Fines.Get(i);
				if (!f) continue;
				string fp = prefix + "fine_" + i.ToString() + "_";
				ctx.WriteValue(fp + "level", f.m_Level);
				ctx.WriteValue(fp + "amount", f.m_Amount);
				ctx.WriteValue(fp + "original_amount", f.m_OriginalAmount);
				ctx.WriteValue(fp + "issued", f.m_IssuedTimestamp);
				ctx.WriteValue(fp + "issuer_pid", f.m_IssuerPlayerId);
				ctx.WriteValue(fp + "issuer_name", f.m_IssuerName);
				ctx.WriteValue(fp + "paid", f.m_Paid);
				ctx.WriteValue(fp + "paid_time", f.m_PaidTimestamp);
				ctx.WriteValue(fp + "prison_trig", f.m_PrisonTriggered);
				ctx.WriteValue(fp + "majorations", f.m_MajorationsApplied);
				ctx.WriteValue(fp + "auto_collected", f.m_AutoCollected);
				ctx.WriteValue(fp + "gravity", f.m_Gravity);
				ctx.WriteValue(fp + "evidence", f.m_Evidence);
			}
			
			// Mentions
			for (int j = 0; j < rec.m_Mentions.Count(); j++)
			{
				MentionRecord m = rec.m_Mentions.Get(j);
				if (!m) continue;
				string mp = prefix + "mention_" + j.ToString() + "_";
				ctx.WriteValue(mp + "text", m.m_Text);
				ctx.WriteValue(mp + "timestamp", m.m_Timestamp);
				ctx.WriteValue(mp + "issuer", m.m_IssuerName);
			}
		}
		
		ctx.SaveToFile(SAVE_PATH);
	}
	
	//------------------------------------------------------------------------------------------------
	void LoadFromDisk()
	{
		SCR_JsonLoadContext ctx = new SCR_JsonLoadContext();
		if (!ctx.LoadFromFile(SAVE_PATH))
			return;
		
		array<string> allUIDs = new array<string>();
		ctx.ReadValue("uids", allUIDs);
		
		foreach (string uid : allUIDs)
		{
			CriminalRecord rec = new CriminalRecord();
			rec.m_PlayerUID = uid;
			
			string prefix = "rec_" + uid + "_";
			ctx.ReadValue(prefix + "name", rec.m_PlayerName);
			ctx.ReadValue(prefix + "license", rec.m_HasDrivingLicense);
			ctx.ReadValue(prefix + "in_prison", rec.m_InPrison);
			ctx.ReadValue(prefix + "prison_time", rec.m_PrisonEntryTime);
			// Champ nouveau : compat retroactive (0 = defaut PRISON_AUTO_RELEASE_SECONDS via Tick)
			ctx.ReadValue(prefix + "prison_duration", rec.m_PrisonDurationSeconds);
			// Compat retroactive : si l ancien save n a pas ce champ, m_IsLongPrison reste false (gendarmerie par defaut)
			ctx.ReadValue(prefix + "is_long_prison", rec.m_IsLongPrison);
			ctx.ReadValue(prefix + "rob_robber", rec.m_LastTimeIRobbed);
			ctx.ReadValue(prefix + "rob_victim", rec.m_LastTimeIWasRobbed);
			
			int finesCount = 0;
			int mentionsCount = 0;
			ctx.ReadValue(prefix + "fines_count", finesCount);
			ctx.ReadValue(prefix + "mentions_count", mentionsCount);
			
			for (int i = 0; i < finesCount; i++)
			{
				FineRecord f = new FineRecord();
				string fp = prefix + "fine_" + i.ToString() + "_";
				ctx.ReadValue(fp + "level", f.m_Level);
				ctx.ReadValue(fp + "amount", f.m_Amount);
				ctx.ReadValue(fp + "issued", f.m_IssuedTimestamp);
				ctx.ReadValue(fp + "issuer_pid", f.m_IssuerPlayerId);
				ctx.ReadValue(fp + "issuer_name", f.m_IssuerName);
				ctx.ReadValue(fp + "paid", f.m_Paid);
				ctx.ReadValue(fp + "paid_time", f.m_PaidTimestamp);
				ctx.ReadValue(fp + "prison_trig", f.m_PrisonTriggered);
				// Champs nouveaux : compat avec anciens fichiers JSON (defaut 0/false)
				ctx.ReadValue(fp + "original_amount", f.m_OriginalAmount);
				ctx.ReadValue(fp + "majorations", f.m_MajorationsApplied);
				ctx.ReadValue(fp + "auto_collected", f.m_AutoCollected);
				// Champs Phase 4 : compat retroactive (defaut 0 / "")
				ctx.ReadValue(fp + "gravity", f.m_Gravity);
				ctx.ReadValue(fp + "evidence", f.m_Evidence);
				// Si pas de montant original sauvegarde (ancien fichier), on prend le montant actuel
				if (f.m_OriginalAmount == 0)
					f.m_OriginalAmount = f.m_Amount;
				rec.m_Fines.Insert(f);
			}
			
			for (int j = 0; j < mentionsCount; j++)
			{
				MentionRecord m = new MentionRecord();
				string mp = prefix + "mention_" + j.ToString() + "_";
				ctx.ReadValue(mp + "text", m.m_Text);
				ctx.ReadValue(mp + "timestamp", m.m_Timestamp);
				ctx.ReadValue(mp + "issuer", m.m_IssuerName);
				rec.m_Mentions.Insert(m);
			}
			
			m_Records.Insert(uid, rec);
		}
		
		Print(string.Format("[JobCriminalManager] Charge %1 dossiers depuis %2",
			allUIDs.Count(), SAVE_PATH));	}
}
