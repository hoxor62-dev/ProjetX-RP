//------------------------------------------------------------------------------------------------
// JobRpcHandler.c
// Composant RPC attache aux PNJ metier (a cote de JobNPCComponent).
// Centralise toutes les RPC client -> serveur (choix metier, demande equipement, etc).
// Utilise RplRpc(Broadcast) avec targetPlayerId pour contourner les limitations de RplRcver.Owner.
//------------------------------------------------------------------------------------------------

[ComponentEditorProps(category: "LesPacifistesJobs", description: "Gestionnaire RPC pour PNJ metier")]
class JobRpcHandlerClass : ScriptComponentClass
{
}

//------------------------------------------------------------------------------------------------
class JobRpcHandler : ScriptComponent
{
	//------------------------------------------------------------------------------------------------
	// ============ WRAPPERS CLIENT (appeles depuis les menus UI) ============
	// Les menus ne peuvent pas faire Rpc() directement car ils ne sont pas ScriptComponent.
	// Ces methodes sont appelees cote client et delegient l'appel RPC au composant.
	//------------------------------------------------------------------------------------------------
	
	void ClientRequestSelectJob(int playerId, int jobInt)
	{
		Rpc(Rpc_SelectJob, playerId, jobInt);
	}
	
	void ClientRequestEquipment(int playerId, int jobInt)
	{
		Rpc(Rpc_RequestEquipment, playerId, jobInt);
	}
	
	void ClientRequestVehicle(int playerId, int vehicleIndex)
	{
		Rpc(Rpc_RequestVehicle, playerId, vehicleIndex);
	}
	
	void ClientRequestAcceptQuest(int playerId, int jobInt, int questIndex)
	{
		Rpc(Rpc_AcceptQuest, playerId, jobInt, questIndex);
	}
	
	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER: le joueur a selectionne un metier dans le menu
	//------------------------------------------------------------------------------------------------
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void Rpc_SelectJob(int playerId, int jobInt)
	{
		if (!Replication.IsServer())
			return;
		
		// Validation: le joueur doit etre bien connecte
		PlayerController pc = GetGame().GetPlayerManager().GetPlayerController(playerId);
		if (!pc)
			return;
		
		EJobType newJob = jobInt;
		
		// Validation: metier valide
		if (newJob == EJobType.NONE)
			return;
		
		JobManager.GetInstance().SetPlayerJob(playerId, newJob);
	}
	
	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER: demande d'equipement aupres du PNJ metier
	// Applique un cooldown de 30 minutes par UID joueur (en memoire, reset au reboot serveur)
	//------------------------------------------------------------------------------------------------
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void Rpc_RequestEquipment(int playerId, int jobInt)
	{
		if (!Replication.IsServer())
			return;
		
		PlayerController pc = GetGame().GetPlayerManager().GetPlayerController(playerId);
		if (!pc)
			return;
		
		EJobType requestedJob = jobInt;
		
		// Validation: le joueur doit avoir CE metier
		JobPlayerData data = JobManager.GetInstance().GetPlayerData(playerId);
		if (!data || data.m_Job != requestedJob)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[EMPLOI] Vous devez etre " + JobData.GetJobLabel(requestedJob) + " pour obtenir cet equipement.");
			return;
		}
		
		// Recupere l UID du joueur pour le cooldown
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "")
			return;
		
		// === CHECK COOLDOWN EQUIPEMENT 30 MIN ===
		// Note : cette RPC n est probablement pas utilisee (le menu actuel passe par
		// JobPlayerComponent.RpcAsk_Equipment qui a aussi son propre check cooldown).
		// On garde le check ici par defense en profondeur si un autre menu appelle ClientRequestEquipment.
		JobCooldownManager cdMgr = JobCooldownManager.GetInstance();
		int remaining = cdMgr.GetEquipmentCooldownRemaining(uid);
		if (remaining > 0)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				string.Format("[EMPLOI] Cooldown actif - veuillez patienter %1 avant de reprendre votre tenue de service.",
					JobCooldownManager.FormatRemaining(remaining)));
			return;
		}
		
		// Donne l'equipement
		JobEquipmentGiver.GiveEquipment(pc.GetControlledEntity(), requestedJob);
		
		// === DEMARRE LE COOLDOWN EQUIPEMENT ===
		cdMgr.StartEquipmentCooldown(uid);
		
		JobManager.GetInstance().NotifyPlayerChat(playerId,
			"[EMPLOI] Equipement et outils de service recus. Prochaine prise possible dans 30 minutes.");
	}
	
	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER: achat d'un article dans la boutique du metier
	// Utilise pour Voyou (armes illegales) ET Concessionnaire (vehicules)
	//------------------------------------------------------------------------------------------------
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void Rpc_RequestVehicle(int playerId, int vehicleIndex)
	{
		if (!Replication.IsServer())
			return;
		
		PlayerController pc = GetGame().GetPlayerManager().GetPlayerController(playerId);
		if (!pc)
			return;
		
		IEntity player = pc.GetControlledEntity();
		if (!player)
			return;
		
		// Recupere le metier du joueur
		JobPlayerData data = JobManager.GetInstance().GetPlayerData(playerId);
		if (!data)
			return;
		
		EJobType job = data.m_Job;
		
		// Validation: le joueur doit avoir un metier avec un shop
		if (!JobShopCatalog.HasShop(job))
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[BOUTIQUE] Votre metier n'a pas acces a une boutique.");
			return;
		}
		
		JobShopItem item = JobShopCatalog.GetItemByIndex(job, vehicleIndex);
		if (!item)
		{
			Print(string.Format("[JobRpcHandler] Article invalide: job=%1 index=%2",
				JobData.JobToString(job), vehicleIndex), LogLevel.WARNING);
			return;
		}
		
		// Verification du solde
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		CapsuleEconomyManager eco = CapsuleEconomyManager.GetInstance();
		if (!eco)
			return;
		
		int currentCapsules = eco.GetCapsules(uid);
		if (currentCapsules < item.m_Price)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				string.Format("[BOUTIQUE] Solde insuffisant. Besoin: %1 | Vous avez: %2",
					item.m_Price, currentCapsules));
			return;
		}
		
		// Deduction du prix
		eco.AddCapsules(uid, -item.m_Price);
		int newTotal = eco.GetCapsules(uid);
		
		// Sync HUD capsules
		CapsulePlayerComponent capsComp = CapsulePlayerComponent.Cast(
			pc.FindComponent(CapsulePlayerComponent));
		if (capsComp)
			capsComp.Svr_SendCapsules(newTotal);
		
		// Spawn selon le type
		bool success;
		if (item.m_IsVehicle)
			success = SpawnVehicleAt10m(player, item.m_Prefab, uid);
		else
			success = JobEquipmentGiver.SpawnAndGiveItem(player, item.m_Prefab);
		
		if (!success)
		{
			// Rembourse en cas d'echec
			eco.AddCapsules(uid, item.m_Price);
			if (capsComp)
				capsComp.Svr_SendCapsules(eco.GetCapsules(uid));
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[BOUTIQUE] Echec du spawn, achat rembourse.");
			return;
		}
		
		string msg = string.Format("[BOUTIQUE] %1 achete pour %2 capsules. Solde: %3",
			item.m_Name, item.m_Price, newTotal);
		JobManager.GetInstance().NotifyPlayerChat(playerId, msg);
		
		Print(string.Format("[JobRpcHandler] Achat: player=%1 job=%2 item=%3 prix=%4",
			playerId, JobData.JobToString(job), item.m_Name, item.m_Price), LogLevel.NORMAL);
	}
	
	//------------------------------------------------------------------------------------------------
	// Spawn un vehicule a 10m devant le joueur (evite le spawn DANS le joueur).
	// Si buyerUID != "", enregistre le vehicule dans le registre persistant du
	// JobVirtualGarageManager (genere UUID stable + ownership resistants au reboot/crash).
	//------------------------------------------------------------------------------------------------
	static bool SpawnVehicleAt10m(IEntity player, ResourceName prefabName, string buyerUID = "")
	{
		Resource res = Resource.Load(prefabName);
		if (!res || !res.IsValid())
		{
			Print(string.Format("[JobRpcHandler] Prefab vehicule invalide: %1", prefabName),
				LogLevel.WARNING);
			return false;
		}

		// Position: 10m devant le joueur dans la direction de son regard
		vector playerPos = player.GetOrigin();
		vector playerForward = player.GetTransformAxis(2); // axe Z = direction avant
		vector spawnPos = playerPos + (playerForward * 10.0);

		// Assure que le spawn est au niveau du sol
		vector groundPos;
		if (SCR_WorldTools.FindEmptyTerrainPosition(groundPos, spawnPos, 5.0))
			spawnPos = groundPos;

		EntitySpawnParams params = new EntitySpawnParams();
		params.TransformMode = ETransformMode.WORLD;
		params.Transform[3] = spawnPos;

		IEntity vehicle = GetGame().SpawnEntityPrefab(res, player.GetWorld(), params);
		if (!vehicle)
		{
			Print(string.Format("[JobRpcHandler] Spawn vehicule echoue: %1", prefabName),
				LogLevel.WARNING);
			return false;
		}

		// Enregistre le vehicule dans le registre persistant pour qu il garde son
		// proprietaire au reboot/crash (necessite LP_VehiclePersistComponent sur le prefab).
		if (buyerUID != "")
			JobVirtualGarageManager.GetInstance().RegisterNewPurchase(vehicle, buyerUID, prefabName);

		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER: accepte une quete
	//------------------------------------------------------------------------------------------------
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void Rpc_AcceptQuest(int playerId, int jobInt, int questIndex)
	{
		if (!Replication.IsServer())
			return;
		
		// Implementation en Phase 2 (quetes)
		Print(string.Format("[JobRpcHandler] Rpc_AcceptQuest recu: player=%1 job=%2 quest=%3",
			playerId, jobInt, questIndex), LogLevel.NORMAL);
	}
	
	//------------------------------------------------------------------------------------------------
	// === COOLDOWN VEHICULE DE SERVICE ===
	// Helper centralise a appeler AVANT de spawn le vehicule de service d un joueur
	// (police, militaire, medecin). Cooldown de 30 minutes par UID, en memoire.
	//
	// Usage cote serveur :
	//   if (!JobRpcHandler.CheckAndStartServiceVehicleCooldown(playerId)) return;
	//   ... spawn du vehicule ici ...
	//
	// Retourne true si OK (cooldown demarre, le caller peut spawn), false si refuse (cooldown actif).
	//------------------------------------------------------------------------------------------------
	static bool CheckAndStartServiceVehicleCooldown(int playerId)
	{
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "")
			return false;
		
		JobCooldownManager mgr = JobCooldownManager.GetInstance();
		int remaining = mgr.GetVehicleCooldownRemaining(uid);
		if (remaining > 0)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				string.Format("[VEHICULE] Cooldown actif - veuillez patienter %1 avant de reprendre votre vehicule de service.",
					JobCooldownManager.FormatRemaining(remaining)));
			return false;
		}
		
		// Demarre le cooldown apres le check OK
		mgr.StartVehicleCooldown(uid);
		JobManager.GetInstance().NotifyPlayerChat(playerId,
			"[VEHICULE] Vehicule de service genere. Prochaine prise possible dans 30 minutes.");
		return true;
	}
	
}
