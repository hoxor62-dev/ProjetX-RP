//------------------------------------------------------------------------------------------------
// JobMiningData.c
// Definitions du systeme mining/transformation/vente
//
// 3 types de ressources :
//  - ROCK         : roche (extraction MINEUR uniquement, vente PNJ Mineur)
//  - CANNABIS     : cannabis (extraction tous joueurs, vente DrugDealer)
//  - COCAINE      : cocaine (extraction tous joueurs, vente DrugDealer)
//
// Etats des ressources :
//  - RAW          : extrait brut (a transformer)
//  - PROCESSED    : transforme (a vendre)
//------------------------------------------------------------------------------------------------

enum EMineralType
{
	NONE = 0,
	ROCK = 1,
	CANNABIS = 2,
	COCAINE = 3,
	WOOD = 4,           // Bois (extraction BUCHERON, transformation en planches, vente PNJ Bucheron)
	APPLE = 5,          // Pomme (extraction AGRICULTEUR, transformation en jus de pomme, vente PNJ Agriculteur)
	WHEAT = 6           // Ble (extraction AGRICULTEUR, transformation en farine, vente PNJ Agriculteur)
}

enum EMineralState
{
	RAW = 0,        // brut
	PROCESSED = 1   // transforme
}

class JobMiningData
{
	// Constantes globales
	const int CYCLE_DURATION_SECONDS = 10;     // 10 secondes par item extrait
	const int CYCLE_COUNT_MAX = 30;            // 30 items max par session
	const float MAX_DISTANCE_METERS = 10.0;    // distance max au prefab
	const int RESPAWN_COOLDOWN_SECONDS = 300;  // 5 minutes apres 30/30 sur la meme source
	
	// Prix de vente unitaire des items transformes
	const int PRICE_ROCK = 13;
	const int PRICE_CANNABIS = 23;
	const int PRICE_COCAINE = 35;
	const int PRICE_WOOD = 13;       // Planche - meme valeur que la roche
	const int PRICE_APPLE = 10;      // Jus de pomme - meme valeur que la roche
	const int PRICE_WHEAT = 10;      // Farine - meme valeur que la pomme
	
	//------------------------------------------------------------------------------------------------
	// Renvoie le metier requis pour extraire/transformer cette ressource
	// EJobType.NONE signifie "tout le monde peut le faire"
	//------------------------------------------------------------------------------------------------
	static EJobType GetRequiredJob(EMineralType type)
	{
		switch (type)
		{
			case EMineralType.ROCK:     return EJobType.MINEUR;
			case EMineralType.CANNABIS: return EJobType.NONE;  // tous
			case EMineralType.COCAINE:  return EJobType.NONE;  // tous
			case EMineralType.WOOD:     return EJobType.BUCHERON;
			case EMineralType.APPLE:    return EJobType.AGRICULTEUR;
			case EMineralType.WHEAT:    return EJobType.AGRICULTEUR;
		}
		return EJobType.NONE;
	}
	
	//------------------------------------------------------------------------------------------------
	// Prix de vente unitaire de l'item transforme
	//------------------------------------------------------------------------------------------------
	static int GetSellPrice(EMineralType type)
	{
		switch (type)
		{
			case EMineralType.ROCK:     return PRICE_ROCK;
			case EMineralType.CANNABIS: return PRICE_CANNABIS;
			case EMineralType.COCAINE:  return PRICE_COCAINE;
			case EMineralType.WOOD:     return PRICE_WOOD;
			case EMineralType.APPLE:    return PRICE_APPLE;
			case EMineralType.WHEAT:    return PRICE_WHEAT;
		}
		return 0;
	}
	
	//------------------------------------------------------------------------------------------------
	// Libelle d'affichage du type
	//------------------------------------------------------------------------------------------------
	static string GetMineralLabel(EMineralType type, EMineralState state)
	{
		string baseName = "";
		switch (type)
		{
			case EMineralType.ROCK:     baseName = "Roche"; break;
			case EMineralType.CANNABIS: baseName = "Cannabis"; break;
			case EMineralType.COCAINE:  baseName = "Cocaine"; break;
			case EMineralType.WOOD:     baseName = "Bois"; break;
			case EMineralType.APPLE:    baseName = "Pomme"; break;
			case EMineralType.WHEAT:    baseName = "Ble"; break;
		}
		
		// WOOD : "Bois brut" -> "Planche"
		if (type == EMineralType.WOOD)
		{
			if (state == EMineralState.RAW)
				return "Bois brut";
			else
				return "Planche";
		}
		// APPLE : "Pomme" -> "Jus de pomme"
		if (type == EMineralType.APPLE)
		{
			if (state == EMineralState.RAW)
				return "Pomme";
			else
				return "Jus de pomme";
		}
		// WHEAT : "Ble" -> "Sac de farine"
		if (type == EMineralType.WHEAT)
		{
			if (state == EMineralState.RAW)
				return "Ble";
			else
				return "Sac de farine";
		}
		
		if (state == EMineralState.RAW)
			return baseName + " brute";
		else
			return baseName + " transformee";
	}
	
	//------------------------------------------------------------------------------------------------
	// Action verbe (pour les hints)
	//------------------------------------------------------------------------------------------------
	static string GetActionVerb(EMineralType type, EMineralState targetState)
	{
		// targetState = ce qu on PRODUIT
		// RAW = on extrait, PROCESSED = on transforme
		if (targetState == EMineralState.RAW)
		{
			switch (type)
			{
				case EMineralType.ROCK:     return "Roche extraite";
				case EMineralType.CANNABIS: return "Cannabis recolte";
				case EMineralType.COCAINE:  return "Coca recoltee";
				case EMineralType.WOOD:     return "Bois coupe";
				case EMineralType.APPLE:    return "Pomme cueillie";
				case EMineralType.WHEAT:    return "Ble recolte";
			}
		}
		else
		{
			switch (type)
			{
				case EMineralType.ROCK:     return "Roche transformee";
				case EMineralType.CANNABIS: return "Cannabis seche";
				case EMineralType.COCAINE:  return "Cocaine raffinee";
				case EMineralType.WOOD:     return "Planche fabriquee";
				case EMineralType.APPLE:    return "Jus de pomme produit";
				case EMineralType.WHEAT:    return "Farine produite";
			}
		}
		return "Item produit";
	}
	
	//------------------------------------------------------------------------------------------------
	// Resource du prefab a spawner dans l'inventaire selon le type/etat
	// A REMPLIR PAR LE BOSS avec les vrais GUID prefab (dans Workbench)
	//------------------------------------------------------------------------------------------------
	static ResourceName GetItemPrefab(EMineralType type, EMineralState state)
	{
		string path = "";
		if (state == EMineralState.RAW)
		{
			switch (type)
			{
				case EMineralType.ROCK:     path = "{16ED337A2A7E87A5}Prefabs/Weapons/Grenades/ROCK.et"; break;
				case EMineralType.CANNABIS: path = "{C3D01F32432A1FF1}Prefabs/Weapons/Grenades/cannabis-frais.et"; break;
				case EMineralType.COCAINE:  path = "{76BD00F7988BC108}Prefabs/Weapons/Grenades/Cock.et"; break;
				case EMineralType.WOOD:     path = "{8597A239C7AB5E14}Prefabs/Weapons/Grenades/bois.et"; break;
				case EMineralType.APPLE:    path = "{E629212FF102070A}Prefabs/Weapons/Grenades/pomme.et"; break;
				case EMineralType.WHEAT:    path = "{65669257F999337D}Prefabs/Weapons/Grenades/ble.et"; break;
			}
		}
		else
		{
			switch (type)
			{
				case EMineralType.ROCK:     path = "{F0A9B1F935F3268F}Prefabs/Weapons/Grenades/ROCK2.et"; break;
				case EMineralType.CANNABIS: path = "{29CAED9E186127A1}Prefabs/Items/InventoryItems/Contraband/WeedBag.et"; break;
				case EMineralType.COCAINE:  path = "{FB1CC21B8E56BCEC}Prefabs/Items/InventoryItems/Contraband/CocaineBag.et"; break;
				case EMineralType.WOOD:     path = "{06F1E252DC029B8C}Prefabs/Props/Civilian/Plank.et"; break;
				case EMineralType.APPLE:    path = "{80922B9A9B594699}Prefabs/Weapons/Grenades/jusdepomme.et"; break;
				case EMineralType.WHEAT:    path = "{3CE28F8799BE0AD6}Prefabs/Weapons/Grenades/farine.et"; break;
			}
		}
		ResourceName r = path;
		return r;
	}
}
