//------------------------------------------------------------------------------------------------
// JobBraquageManager.c
// Manager singleton SERVEUR du systeme de braquage bijouterie.
//
// Fonctionnalites :
//  - Track les braquages actifs (par playerId)
//  - Tick 1s pour : verifier l etat du joueur (vie/inconscient), crediter 25 capsules/s
//  - Tick 30s pour spawner un item au sol autour du joueur
//  - Stop le braquage si joueur meurt/inconscient/deconnecte/timer ecoule
//  - Cooldown 1h par joueur entre 2 braquages
//  - Liste les items spawnes au sol pour les supprimer si non ramasses a la fin
//
// L action 'Braquer la bijouterie' fait son propre check serveur via ClientAskStartBraquage.
//------------------------------------------------------------------------------------------------

class JobBraquageActiveSession
{
	int m_PlayerId;
	string m_PlayerUID;
	int m_StartTime;              // timestamp unix
	int m_NextItemSpawnTime;      // timestamp prochain spawn
	ref array<EntityID> m_SpawnedLootIds = new array<EntityID>();
	// Position de la bijouterie (pour les alertes SOS et le son sirene)
	vector m_BijouterieOrigin;
}

class JobBraquageManager
{
	static ref JobBraquageManager s_Instance;
	
	// Braquages actifs : cle = playerId
	ref map<int, ref JobBraquageActiveSession> m_ActiveSessions;
	
	// Cooldowns : cle = UID joueur, valeur = timestamp unix de fin de braquage
	ref map<string, int> m_Cooldowns;
	
	const int TICK_INTERVAL_MS = 1000;  // 1 seconde
	
	//------------------------------------------------------------------------------------------------
	void JobBraquageManager()
	{
		m_ActiveSessions = new map<int, ref JobBraquageActiveSession>();
		m_Cooldowns = new map<string, int>();
	}
	
	//------------------------------------------------------------------------------------------------
	static JobBraquageManager GetInstance()
	{
		if (!s_Instance)
		{
			s_Instance = new JobBraquageManager();
			s_Instance.Init();
		}
		return s_Instance;
	}
	
	//------------------------------------------------------------------------------------------------
	void Init()
	{
		Print("[JobBraquageManager] Initialisation", LogLevel.NORMAL);
		if (Replication.IsServer())
			GetGame().GetCallqueue().CallLater(Tick, TICK_INTERVAL_MS, true);
	}
	
	//------------------------------------------------------------------------------------------------
	// Compte le nombre total de joueurs POLICIER + MILITAIRE actuellement connectes.
	// Utilise pour valider que le braquage est possible (mini 4 forces de l ordre)
	//------------------------------------------------------------------------------------------------
	int CountConnectedForces()
	{
		PlayerManager pm = GetGame().GetPlayerManager();
		if (!pm)
			return 0;
		array<int> ids = new array<int>();
		pm.GetPlayers(ids);
		int count = 0;
		foreach (int pid : ids)
		{
			JobPlayerData data = JobManager.GetInstance().GetPlayerData(pid);
			if (!data) continue;
			if (data.m_Job == EJobType.POLICIER || data.m_Job == EJobType.MILITAIRE)
				count++;
		}
		return count;
	}
	
	//------------------------------------------------------------------------------------------------
	// Verifie si un joueur a un braquage actif
	bool HasActiveBraquage(int playerId)
	{
		return m_ActiveSessions.Contains(playerId);
	}
	
	//------------------------------------------------------------------------------------------------
	// Verifie le cooldown d un joueur.
	// Retourne 0 si OK, sinon nombre de secondes restantes.
	int CheckCooldown(string playerUID)
	{
		if (playerUID == "")
			return 1;
		int endTime;
		if (!m_Cooldowns.Find(playerUID, endTime))
			return 0;
		int now = System.GetUnixTime();
		if (now >= endTime)
			return 0;
		return endTime - now;
	}
	
	//------------------------------------------------------------------------------------------------
	// Verifie si le joueur a les 2 items requis dans son inventaire.
	// Note : on cherche par ResourceName du prefab.
	//------------------------------------------------------------------------------------------------
	bool HasRequiredItems(int playerId)
	{
		PlayerController pc = GetGame().GetPlayerManager().GetPlayerController(playerId);
		if (!pc)
			return false;
		IEntity playerEntity = pc.GetControlledEntity();
		if (!playerEntity)
			return false;
		
		SCR_InventoryStorageManagerComponent invMgr = SCR_InventoryStorageManagerComponent.Cast(
			playerEntity.FindComponent(SCR_InventoryStorageManagerComponent));
		if (!invMgr)
			return false;
		
		array<IEntity> items = new array<IEntity>();
		invMgr.GetItems(items);
		
		bool hasA = false;
		bool hasB = false;
		foreach (IEntity item : items)
		{
			if (!item) continue;
			EntityPrefabData pd = item.GetPrefabData();
			if (!pd) continue;
			string rn = pd.GetPrefabName();
			if (rn == JobBraquageData.REQUIRED_ITEM_A)
				hasA = true;
			if (rn == JobBraquageData.REQUIRED_ITEM_B)
				hasB = true;
			if (hasA && hasB)
				return true;
		}
		return (hasA && hasB);
	}
	
	//------------------------------------------------------------------------------------------------
	// Tente de demarrer un braquage. Retourne :
	//   0 = OK demarre
	//   1 = deja un braquage actif pour ce joueur
	//   2 = cooldown en cours (X secondes restantes)
	//   3 = items requis manquants
	//   4 = autre erreur (joueur introuvable, etc.)
	//   5 = metier non Voyou
	//   6 = pas assez de forces de l ordre connectees (mini 4)
	//------------------------------------------------------------------------------------------------
	int StartBraquage(int playerId, vector bijouterieOrigin, out int outCooldownRemaining)
	{
		outCooldownRemaining = 0;
		if (!Replication.IsServer())
			return 4;
		
		// Verif metier : seul le metier VOYOU peut braquer
		JobPlayerData data = JobManager.GetInstance().GetPlayerData(playerId);
		if (!data || data.m_Job != EJobType.VOYOU)
			return 5;
		
		// Verif forces de l ordre : minimum 4 POLICIER + MILITAIRE connectes au total
		if (CountConnectedForces() < 4)
			return 6;
		
		// Verif deja en cours
		if (HasActiveBraquage(playerId))
			return 1;
		
		// Verif cooldown
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "")
			return 4;
		int cdRemaining = CheckCooldown(uid);
		if (cdRemaining > 0)
		{
			outCooldownRemaining = cdRemaining;
			return 2;
		}
		
		// Verif items
		if (!HasRequiredItems(playerId))
			return 3;
		
		// Cree la session
		int now = System.GetUnixTime();
		JobBraquageActiveSession session = new JobBraquageActiveSession();
		session.m_PlayerId = playerId;
		session.m_PlayerUID = uid;
		session.m_StartTime = now;
		session.m_NextItemSpawnTime = now + JobBraquageData.ITEM_SPAWN_INTERVAL_SECONDS;
		session.m_BijouterieOrigin = bijouterieOrigin;
		m_ActiveSessions.Set(playerId, session);
		
		// Envoie au client : HUD progression + son sirene
		PlayerController pc = GetGame().GetPlayerManager().GetPlayerController(playerId);
		if (pc)
		{
			JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
			if (jpc)
				jpc.ServerStartBraquageHud(JobBraquageData.BRAQUAGE_DURATION_SECONDS, bijouterieOrigin);
		}
		
		// Demarre la sirene globale (audible dans un rayon de 500m autour de la bijouterie)
		BroadcastSirenStart(bijouterieOrigin);
		
		// Envoie l alerte SOS aux Police + Gendarmerie
		SendSosAlerts(playerId, bijouterieOrigin);
		
		Print(string.Format("[JobBraquageManager] Braquage demarre : player=%1 uid=%2",
			playerId, uid), LogLevel.NORMAL);
		
		return 0;
	}
	
	//------------------------------------------------------------------------------------------------
	// Tick serveur : pour chaque braquage actif, credite capsules + spawn items + check state
	//------------------------------------------------------------------------------------------------
	void Tick()
	{
		if (!Replication.IsServer())
			return;
		if (m_ActiveSessions.Count() == 0)
			return;
		
		int now = System.GetUnixTime();
		array<int> toEnd = new array<int>();
		
		foreach (int playerId, JobBraquageActiveSession session : m_ActiveSessions)
		{
			if (!session)
			{
				toEnd.Insert(playerId);
				continue;
			}
			
			// Verif fin de duree
			int elapsed = now - session.m_StartTime;
			if (elapsed >= JobBraquageData.BRAQUAGE_DURATION_SECONDS)
			{
				toEnd.Insert(playerId);
				continue;
			}
			
			// Verif joueur encore connecte / vivant / conscient
			PlayerController pc = GetGame().GetPlayerManager().GetPlayerController(playerId);
			if (!pc)
			{
				// Joueur deconnecte
				toEnd.Insert(playerId);
				continue;
			}
			IEntity playerEntity = pc.GetControlledEntity();
			if (!playerEntity)
			{
				toEnd.Insert(playerId);
				continue;
			}
			
			// Verif vie / inconscience via le ChimeraCharacter
			ChimeraCharacter ch = ChimeraCharacter.Cast(playerEntity);
			if (ch)
			{
				CharacterControllerComponent ccc = ch.GetCharacterController();
				if (ccc)
				{
					ECharacterLifeState ls = ccc.GetLifeState();
					if (ls == ECharacterLifeState.DEAD || ls == ECharacterLifeState.INCAPACITATED)
					{
						JobManager.GetInstance().NotifyPlayerChat(playerId,
							"[BRAQUAGE] Vous etes hors-jeu : le braquage est interrompu.");
						toEnd.Insert(playerId);
						continue;
					}
				}
			}
			
			// Verif distance avec la bijouterie : si trop loin, annulation
			float dist = vector.Distance(playerEntity.GetOrigin(), session.m_BijouterieOrigin);
			if (dist > JobBraquageData.MAX_DISTANCE_FROM_BIJOUTERIE)
			{
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					string.Format("[BRAQUAGE] Vous etes trop eloigne (%1m) : le braquage est annule.",
						Math.Floor(dist).ToString()));
				toEnd.Insert(playerId);
				continue;
			}
			
			// Tout va bien : credite 25 capsules
			CapsuleEconomyManager eco = CapsuleEconomyManager.GetInstance();
			if (eco)
			{
				eco.AddCapsules(session.m_PlayerUID, JobBraquageData.CAPSULES_PER_SECOND);
				int newTotal = eco.GetCapsules(session.m_PlayerUID);
				
				// Sync HUD capsules
				CapsulePlayerComponent capsComp = CapsulePlayerComponent.Cast(
					pc.FindComponent(CapsulePlayerComponent));
				if (capsComp)
					capsComp.Svr_SendCapsules(newTotal);
			}
			
			// Verif spawn item (toutes les 30s)
			if (now >= session.m_NextItemSpawnTime)
			{
				Print(string.Format("[JobBraquageManager] Tick : tentative spawn item (now=%1 next=%2)",
					now, session.m_NextItemSpawnTime), LogLevel.NORMAL);
				SpawnLootNearPlayer(session, playerEntity);
				session.m_NextItemSpawnTime = now + JobBraquageData.ITEM_SPAWN_INTERVAL_SECONDS;
			}
		}
		
		// Termine les braquages a stopper
		foreach (int pid : toEnd)
			EndBraquage(pid, true);
	}
	
	//------------------------------------------------------------------------------------------------
	// Spawn un item au sol autour du joueur
	//------------------------------------------------------------------------------------------------
	void SpawnLootNearPlayer(JobBraquageActiveSession session, IEntity playerEntity)
	{
		if (!session)
		{
			Print("[JobBraquageManager] SpawnLoot ABORT : session null", LogLevel.WARNING);
			return;
		}
		if (!playerEntity)
		{
			Print("[JobBraquageManager] SpawnLoot ABORT : playerEntity null", LogLevel.WARNING);
			return;
		}
		
		// Choisit un prefab au hasard dans la liste
		array<string> prefabs = JobBraquageData.GetLootPrefabs();
		if (prefabs.Count() == 0)
		{
			Print("[JobBraquageManager] SpawnLoot ABORT : aucun prefab dans GetLootPrefabs()", LogLevel.WARNING);
			return;
		}
		int idx = Math.RandomInt(0, prefabs.Count());
		string prefabName = prefabs.Get(idx);
		if (prefabName == "")
		{
			Print("[JobBraquageManager] SpawnLoot ABORT : prefabName vide", LogLevel.WARNING);
			return;
		}
		
		Print(string.Format("[JobBraquageManager] SpawnLoot : tente Load de '%1'", prefabName),
			LogLevel.NORMAL);
		
		Resource res = Resource.Load(prefabName);
		if (!res || !res.IsValid())
		{
			Print(string.Format("[JobBraquageManager] SpawnLoot ABORT : Resource.Load invalide pour '%1'",
				prefabName), LogLevel.WARNING);
			return;
		}
		
		// Position aleatoire dans un rayon autour du joueur
		vector playerPos = playerEntity.GetOrigin();
		float angle = Math.RandomFloat(0, Math.PI2);
		float distance = Math.RandomFloat(0.5, JobBraquageData.ITEM_SPAWN_RADIUS);
		vector spawnPos = playerPos;
		spawnPos[0] = playerPos[0] + Math.Cos(angle) * distance;
		spawnPos[2] = playerPos[2] + Math.Sin(angle) * distance;
		// Ajuste a la hauteur du sol
		float terrainY = GetGame().GetWorld().GetSurfaceY(spawnPos[0], spawnPos[2]);
		spawnPos[1] = terrainY + 0.2;
		
		EntitySpawnParams params = new EntitySpawnParams();
		params.TransformMode = ETransformMode.WORLD;
		params.Transform[3] = spawnPos;
		
		IEntity item = GetGame().SpawnEntityPrefab(res, GetGame().GetWorld(), params);
		if (!item)
		{
			Print(string.Format("[JobBraquageManager] SpawnLoot ABORT : SpawnEntityPrefab a retourne null pour '%1' a %2",
				prefabName, spawnPos.ToString()), LogLevel.WARNING);
			return;
		}
		
		session.m_SpawnedLootIds.Insert(item.GetID());
		Print(string.Format("[JobBraquageManager] SpawnLoot OK : prefab=%1 pos=%2",
			prefabName, spawnPos.ToString()), LogLevel.NORMAL);
	}
	
	//------------------------------------------------------------------------------------------------
	// Termine un braquage : nettoie la session, stop la sirene cote client, supprime les items
	// non ramasses, met le cooldown.
	//------------------------------------------------------------------------------------------------
	void EndBraquage(int playerId, bool applyCooldown)
	{
		JobBraquageActiveSession session;
		if (!m_ActiveSessions.Find(playerId, session))
			return;
		
		// Supprime UNIQUEMENT les items au sol non ramasses.
		// Un item ramasse par un joueur a un parent (storage component du perso),
		// alors qu un item au sol n a pas de parent. On utilise IEntity.GetParent() pour ca :
		// - parent == null  -> item au sol, on peut supprimer
		// - parent != null  -> item dans un inventaire, on NE TOUCHE PAS
		if (session.m_SpawnedLootIds)
		{
			BaseWorld world = GetGame().GetWorld();
			int deleted = 0;
			int kept = 0;
			foreach (EntityID id : session.m_SpawnedLootIds)
			{
				IEntity ent = world.FindEntityByID(id);
				if (!ent)
					continue;
				// Si l item a un parent, c est qu il a ete ramasse -> ne pas toucher
				IEntity parent = ent.GetParent();
				if (parent)
				{
					kept++;
					continue;
				}
				// Pas de parent = toujours au sol -> on supprime
				SCR_EntityHelper.DeleteEntityAndChildren(ent);
				deleted++;
			}
			Print(string.Format("[JobBraquageManager] Cleanup loot : %1 items supprimes (au sol), %2 items conserves (ramasses)",
				deleted, kept), LogLevel.NORMAL);
		}
		
		// Cooldown
		if (applyCooldown && session.m_PlayerUID != "")
		{
			int now = System.GetUnixTime();
			m_Cooldowns.Set(session.m_PlayerUID, now + JobBraquageData.BRAQUAGE_COOLDOWN_SECONDS);
		}
		
		// Stoppe HUD + sirene chez le client
		PlayerController pc = GetGame().GetPlayerManager().GetPlayerController(playerId);
		if (pc)
		{
			JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
			if (jpc)
				jpc.ServerEndBraquageHud();
		}
		
		// Stoppe la sirene globale
		BroadcastSirenStop(session.m_BijouterieOrigin);
		
		// Notif joueur
		JobManager.GetInstance().NotifyPlayerChat(playerId,
			"[BRAQUAGE] Braquage termine. Cooldown 24h avant le prochain.");
		
		// Cleanup
		m_ActiveSessions.Remove(playerId);
		
		Print(string.Format("[JobBraquageManager] Braquage termine : player=%1", playerId),
			LogLevel.NORMAL);
	}
	
	//------------------------------------------------------------------------------------------------
	// Broadcast : demarre la sirene pour tous les joueurs dans un rayon de 500m de la bijouterie
	//------------------------------------------------------------------------------------------------
	void BroadcastSirenStart(vector bijouterieOrigin)
	{
		PlayerManager pm = GetGame().GetPlayerManager();
		if (!pm) return;
		array<int> ids = new array<int>();
		pm.GetPlayers(ids);
		foreach (int pid : ids)
		{
			PlayerController pc = pm.GetPlayerController(pid);
			if (!pc) continue;
			IEntity pe = pc.GetControlledEntity();
			if (!pe) continue;
			float dist = vector.Distance(pe.GetOrigin(), bijouterieOrigin);
			if (dist > JobBraquageData.SIREN_AUDIBLE_RADIUS)
				continue;
			JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
			if (jpc)
				jpc.ServerStartBraquageSiren(bijouterieOrigin);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Broadcast : stoppe la sirene pour tous les joueurs
	//------------------------------------------------------------------------------------------------
	void BroadcastSirenStop(vector bijouterieOrigin)
	{
		PlayerManager pm = GetGame().GetPlayerManager();
		if (!pm) return;
		array<int> ids = new array<int>();
		pm.GetPlayers(ids);
		foreach (int pid : ids)
		{
			PlayerController pc = pm.GetPlayerController(pid);
			if (!pc) continue;
			JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
			if (jpc)
				jpc.ServerStopBraquageSiren();
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Envoie l alerte SOS aux Police + Gendarmerie (pattern phone call)
	//------------------------------------------------------------------------------------------------
	void SendSosAlerts(int braqueurPlayerId, vector bijouterieOrigin)
	{
		PlayerManager pm = GetGame().GetPlayerManager();
		if (!pm) return;
		array<int> ids = new array<int>();
		pm.GetPlayers(ids);
		
		int notifiedCount = 0;
		
		foreach (int pid : ids)
		{
			if (pid == braqueurPlayerId)
				continue;
			JobPlayerData data = JobManager.GetInstance().GetPlayerData(pid);
			if (!data)
				continue;
			// Cible : POLICIER ou MILITAIRE
			if (data.m_Job != EJobType.POLICIER && data.m_Job != EJobType.MILITAIRE)
				continue;
			
			PlayerController pc = pm.GetPlayerController(pid);
			if (!pc) continue;
			JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
			if (jpc)
			{
				// 1. Envoie le hint d alerte au client (sans nom du suspect)
				jpc.ServerSendBraquageAlert(bijouterieOrigin,
					"BRAQUAGE BIJOUTERIE en cours ! Position sur la carte.");
				// 2. Cree le marker sur la carte (pattern serveur -> client comme les quetes)
				jpc.ServerSetQuestMarker(bijouterieOrigin, "BRAQUAGE BIJOUTERIE");
				// 3. Auto-supprime le marker apres 10 min (cote serveur, qui renverra une RPC remove)
				// On utilise une capture statique via CallLater + reference au jpc
				JobBraquageMarkerCleanup cleanup = new JobBraquageMarkerCleanup();
				cleanup.m_Jpc = jpc;
				GetGame().GetCallqueue().CallLater(cleanup.Execute, 600000, false);
				notifiedCount++;
			}
		}
		
		Print(string.Format("[JobBraquageManager] SOS braquage envoye a %1 forces de l ordre",
			notifiedCount), LogLevel.NORMAL);
	}
	
	//------------------------------------------------------------------------------------------------
	// Cleanup au disconnect (au cas ou le tick ne l a pas encore vu)
	//------------------------------------------------------------------------------------------------
	void OnPlayerDisconnected(int playerId)
	{
		if (HasActiveBraquage(playerId))
			EndBraquage(playerId, false);  // pas de cooldown si deconnexion
	}
}

//------------------------------------------------------------------------------------------------
// Helper de cleanup du marker de braquage cote serveur.
// Enforce Script ne supporte pas les closures, donc on encapsule le ref jpc dans une classe.
//------------------------------------------------------------------------------------------------
class JobBraquageMarkerCleanup
{
	JobPlayerComponent m_Jpc;
	
	void Execute()
	{
		if (m_Jpc)
			m_Jpc.ServerRemoveQuestMarker();
	}
}
