//------------------------------------------------------------------------------------------------
// JobShopCatalog.c
// Catalogues d'articles achetables par metier/shop:
//  - VOYOU: armes de contrebande (marche noir)
//  - CONCESSIONNAIRE: vehicules + accessoires
//  - VENDEUR_IMMOBILIER: materiaux de construction et plans
//  - SHOP_VETEMENTS: vendeur de vetements public (8-15 caps)
//  - SHOP_NOURRITURE: vendeur de nourriture public (2-5 caps)
//  - SHOP_LOCATION: loueur de vehicules public (a remplir)
//
// Les prix "random" sont tires avec une seed fixe pour etre stables.
//------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------------------
// Structure d'un article achetable
//------------------------------------------------------------------------------------------------
class JobShopItem
{
	string m_Name;          // Nom affiche dans le menu
	ResourceName m_Prefab;  // GUID du prefab a spawn
	int m_Price;            // Prix en capsules (ou en lingots d or si m_PaidInGold = true)
	bool m_IsVehicle;       // true = vehicule (spawn au sol a 10m), false = item (inventaire)
	int m_Quantity;         // Quantite (ignore pour les vehicules)
	bool m_PaidInGold;      // false (defaut) = paiement en capsules, true = paiement en lingots d or
	string m_Category;      // Categorie logique dans la liste ("" = sans categorie)
	
	void JobShopItem(string name, ResourceName prefab, int price, bool isVehicle, int quantity)
	{
		m_Name = name;
		m_Prefab = prefab;
		m_Price = price;
		m_IsVehicle = isVehicle;
		m_Quantity = quantity;
		m_PaidInGold = false;
		m_Category = "";
	}
	
	//------------------------------------------------------------------------------------------------
	// Helper static pour creer un item paye en lingots d or.
	// Utilise pour les shops Voyou en or.
	//------------------------------------------------------------------------------------------------
	static JobShopItem MakeGold(string name, ResourceName prefab, int priceInGold, bool isVehicle, int quantity)
	{
		JobShopItem item = new JobShopItem(name, prefab, priceInGold, isVehicle, quantity);
		item.m_PaidInGold = true;
		return item;
	}
	
	//------------------------------------------------------------------------------------------------
	// Helper static pour creer un item avec categorie en une expression.
	// Utilisation : items.Insert(JobShopItem.NewCat("Nom", "prefab", price, false, 1, "Categorie"));
	//------------------------------------------------------------------------------------------------
	static JobShopItem NewCat(string name, ResourceName prefab, int price, bool isVehicle, int quantity, string category)
	{
		JobShopItem item = new JobShopItem(name, prefab, price, isVehicle, quantity);
		item.m_Category = category;
		return item;
	}
}

//------------------------------------------------------------------------------------------------
// GUID du lingot d or (constante centrale pour eviter duplication)
//------------------------------------------------------------------------------------------------
class JobGoldCurrency
{
	static const string LINGOT_OR_PREFAB = "{CD7E4794F5D40A0B}Prefabs/Items/Equipment/bargold/bargold.et";
}

//------------------------------------------------------------------------------------------------
// Catalogue statique par type de shop
//------------------------------------------------------------------------------------------------
class JobShopCatalog
{
	//------------------------------------------------------------------------------------------------
	// Retourne la liste unique des categories pour un metier/shop.
	// Ordre : ordre d apparition dans le catalogue (garanti stable).
	// Si aucun item n a de categorie (m_Category == "") -> tableau vide -> mode SANS categorie.
	//------------------------------------------------------------------------------------------------
	static array<string> GetCategoriesForJob(EJobType job)
	{
		array<string> cats = new array<string>();
		array<ref JobShopItem> items = GetItemsForJob(job);
		if (!items) return cats;
		foreach (JobShopItem it : items)
		{
			if (!it) continue;
			if (it.m_Category == "") continue;
			if (cats.Find(it.m_Category) >= 0) continue;
			cats.Insert(it.m_Category);
		}
		return cats;
	}
	
	//------------------------------------------------------------------------------------------------
	// Retourne les items d un metier/shop appartenant a la categorie donnee.
	// Si category == "" -> retourne TOUS les items (comportement equivalent a GetItemsForJob).
	//------------------------------------------------------------------------------------------------
	static array<ref JobShopItem> GetItemsForJobAndCategory(EJobType job, string category)
	{
		array<ref JobShopItem> all = GetItemsForJob(job);
		if (!all || category == "")
			return all;
		array<ref JobShopItem> filtered = new array<ref JobShopItem>();
		foreach (JobShopItem it : all)
		{
			if (!it) continue;
			if (it.m_Category == category)
				filtered.Insert(it);
		}
		return filtered;
	}
	
	//------------------------------------------------------------------------------------------------
	// Retourne la liste des articles achetables pour un metier/shop
	//------------------------------------------------------------------------------------------------
	static array<ref JobShopItem> GetItemsForJob(EJobType job)
	{
		array<ref JobShopItem> items = new array<ref JobShopItem>();
		
		switch (job)
		{
			case EJobType.VOYOU:
			{
				// Marche noir: armes illegales
				items.Insert(new JobShopItem("Joint en bouche", "{F723BDF891EFECAE}Prefabs/Items/Smokeables/Smokeable_Joint.et", 150, false, 1));
				items.Insert(new JobShopItem("Gilet par balles", "{A70C73FCF1EDCEC5}Prefabs/Characters/Vests/Vest_PASGT/ERA Vest Black.et", 5000, false, 1));
				
				items.Insert(new JobShopItem(
					"Bomb Vest 60m",
					"{A08F37CFC822FC4E}Prefabs/Weapons/Explosives/DemoBlock_M112/Bomb Vest 60m.et",
					75000, false, 1));
  // --- NOUVEAUX ITEMS (MARCHE NOIR) ---
    items.Insert(new JobShopItem(
        "Menottes ZipCuffs",
        "{200873F3186B0923}Prefabs/Items/ZipTieItem.et",
        1000, false, 1));
    items.Insert(new JobShopItem(
        "Blackbag",
        "{5FDCD167D09C6377}Prefabs/Characters/HeadGear/Hat_Panama_Soviet/Blackbag.et",
        300, false, 1));
				

				
				items.Insert(new JobShopItem(
    "Cagoule GUCCI Noir",
    "{EFFE823A087130EF}Prefabs/Characters/HeadGear/Hat_TruckerCap_01/CAGOULE_GUCCINOIR.et",
    400, false, 1));
				
								items.Insert(new JobShopItem(
    "Cagoule GUCCI",
    "{53C709972B0BD551}Prefabs/Characters/HeadGear/Hat_TruckerCap_01/CAGOULE_GUCCI.et",
    400, false, 1));
				
												items.Insert(new JobShopItem(
    "Cagoule Dior",
    "{2D6560DE7EE0B0FC}Prefabs/Characters/HeadGear/Hat_TruckerCap_01/CAGOULE_DIOR.et",
    400, false, 1));
				
																items.Insert(new JobShopItem(
    "Cagoule ",
    "{02DA0B9FB97A17FE}Prefabs/Characters/HeadGear/Hat_TruckerCap_01/CAGOULE.et",
    400, false, 1));
				
				
								items.Insert(new JobShopItem(
					"Balaclava",
					"{751A4E78D1ABD22B}Prefabs/Clothing/Balaclava.et",
					300, false, 1));
	items.Insert(new JobShopItem(
					"Masque Dallas",
					"{98295D3B9D655BE4}Prefabs/Clothing/Dallas_Mask.et",
					200, false, 1));
				items.Insert(new JobShopItem(
					"Masque Ghost",
					"{A57BFDA4CC2AF871}Prefabs/Clothing/Ghost_Mask.et",
					200, false, 1));
				items.Insert(new JobShopItem(
    "Bandana Noir",
    "{6A29497C649E96CF}Prefabs/Clothing/Black Bandana.et",
    200, false, 1));

items.Insert(new JobShopItem(
    "Bandana Marron",
    "{ACB2C5968745442C}Prefabs/Clothing/Brown Bandana.et",
    200, false, 1));

items.Insert(new JobShopItem(
    "Bandana Vert",
    "{786E02F187E4E25D}Prefabs/Clothing/Green Bandana.et",
    200, false, 1));

items.Insert(new JobShopItem(
    "Bandana Gris",
    "{082B1586D824FDB9}Prefabs/Clothing/Grey Bandana.et",
    200, false, 1));

items.Insert(new JobShopItem(
    "Bandana Marron Clair",
    "{46F064A152042F41}Prefabs/Clothing/Light Brown Bandana.et",
    200, false, 1));

items.Insert(new JobShopItem(
    "Bandana Gris Clair",
    "{F0D58985B0CB45D0}Prefabs/Clothing/Light Grey Bandana.et",
    200, false, 1));

items.Insert(new JobShopItem(
    "Bandana Orange",
    "{A52CD03692F99AB3}Prefabs/Clothing/Orange Bandana.et",
    200, false, 1));

items.Insert(new JobShopItem(
    "Bandana Violet",
    "{BCF1CCC1C975F1D5}Prefabs/Clothing/Purple Bandana.et",
    200, false, 1));

items.Insert(new JobShopItem(
    "Bandana Rouge",
    "{AFB709D5F21B084B}Prefabs/Clothing/Red Bandana.et",
    200, false, 1));

items.Insert(new JobShopItem(
    "Bandana Tête de Mort",
    "{D96EF59A943165F4}Prefabs/Clothing/Skull Bandana.et",
    200, false, 1));

items.Insert(new JobShopItem(
    "Bandana TFD",
    "{1879F32C3730B712}Prefabs/Clothing/TFD Bandana.et",
    200, false, 1));

items.Insert(new JobShopItem(
    "Bandana Blanc",
    "{7788061212C512A1}Prefabs/Clothing/White Bandana.et",
    200, false, 1));

				items.Insert(new JobShopItem(
					"Masque Ghost v2",
					"{7723F4C3BFD231F4}Prefabs/Clothing/Ghost_Mask_2.et",
					300, false, 1));
				items.Insert(new JobShopItem(
					"Masque Jester",
					"{E8C6F03FA1B9DCDB}Prefabs/Clothing/Jester_Mask.et",
					280, false, 1));
				items.Insert(new JobShopItem(
					"Masque Joker",
					"{348CE4C9AF54F364}Prefabs/Clothing/Joker_Mask.et",
					240, false, 1));
				items.Insert(new JobShopItem(
					"Masque Joker v2",
					"{9E8B35A80B6B5166}Prefabs/Clothing/Joker_Mask_2.et",
					202, false, 1));
				items.Insert(new JobShopItem(
					"Masque Oni",
					"{8CF57965FC291F35}Prefabs/Clothing/Oni_Mask.et",
					260, false, 1));
				items.Insert(new JobShopItem(
					"Masque Clown",
					"{C977AF4AB2703956}Prefabs/Clothing/Clown_Mask.et",
					230, false, 1));
				items.Insert(new JobShopItem(
					"Masque Demon",
					"{7D455A7D21913BF4}Prefabs/Clothing/Demon_Mask.et",
					220, false, 1));
				items.Insert(new JobShopItem(
					"Masque Riot Clown",
					"{398EA32AF466E428}Prefabs/Clothing/RiotClown_Mask.et",
					236, false, 1));
				items.Insert(new JobShopItem(
					"Masque Unknown",
					"{BC0804DBCBEDE3A7}Prefabs/Clothing/Unknown_Mask.et",
					226, false, 1));
				items.Insert(new JobShopItem(
					"Masque Loup",
					"{89EF041334B24D0D}Prefabs/Clothing/Wolf_Mask.et",
					228, false, 1));
				items.Insert(new JobShopItem("Perceuse pour braquage", "{E0E0AF73D81202D2}Prefabs/Items/Equipment/Accessories/ETool_ALICE/grinder.et", 10000, false, 1));			
break;
}
	
			case EJobType.CONCESSIONNAIRE:
			{
				// Accessoires (inventaire)
				items.Insert(new JobShopItem(
					"Cle de voiture",
					"{CCFD8AA837B9611A}Prefabs/Items/CarKey/CarKey.et",
					10, false, 1));
								items.Insert(new JobShopItem(
					"Casque 69 1",
					"{C46984DDCB26926D}Prefabs/Characters/HeadGear/Helmet_M1_01/casque.et",
					100, false, 1));
								items.Insert(new JobShopItem(
					"Casque 69 2",
					"{BB3D4AE5398D53A4}Prefabs/Characters/HeadGear/Helmet_M1_01/casque2.et",
					100, false, 1));

								items.Insert(new JobShopItem(
					"Casque Allemand",
					"{402DA394A243655B}Prefabs/Characters/HeadGear/BikerHelmets/GermanHelmet.et",
					100, false, 1));
								items.Insert(new JobShopItem(
					"Casque Vintage",
					"{18CED2DCE7C20AEE}Prefabs/Characters/HeadGear/BikerHelmets/VintageHelmet.et",
					100, false, 1));
												items.Insert(new JobShopItem(
					"Casque Negro",
					"{D5BF1666DBA59822}Prefabs/Characters/HeadGear/Cascos Moto/Casco_NegroM.et",
					100, false, 1));
												items.Insert(new JobShopItem(
					"Casque Blanc",
					"{92073C3A5E9BA801}Prefabs/Characters/HeadGear/Cascos Moto/Casco_Blanco_M.et",
					100, false, 1));
																items.Insert(new JobShopItem(
					"Casque PNC",
					"{353CA6577BEA5518}Prefabs/Characters/HeadGear/Cascos Moto/Casco_PNC.et",
					100, false, 1));
				// Vehicules (spawn a 10m)
				items.Insert(new JobShopItem(
					"TRX 4x4 Gris (M998)",
					"{F70FB6122E594631}Prefabs/Vehicles/Wheeled/M998/TRX G.et",
					30000, true, 1));
				
				// --- Nouveaux vehicules (prix 700-2000 random) ---
				
				
				items.Insert(new JobShopItem("Camion Entreprise Agriculture", "{40F382BE5D06DAE7}Prefabs/Vehicles/Wheeled/M923A1/CAMION_AGRICULTURE.et", 40000, false, 1));
				items.Insert(new JobShopItem("Camion Entreprise Bucheron", "{54ADFF42D80F00CF}Prefabs/Vehicles/Wheeled/M923A1/CAMION_BUCHERON.et", 40000, false, 1));
				items.Insert(new JobShopItem("Camion Entreprise Mineur", "{5EF825F6AD212AA8}Prefabs/Vehicles/Wheeled/M923A1/CAMION_MINER.et", 40000, false, 1));
				items.Insert(new JobShopItem("Camion Entreprise Fonderie", "{0374E111DA224408}Prefabs/Vehicles/Wheeled/M923A1/CAMION_FONDERIE.et", 40000, false, 1));
				items.Insert(new JobShopItem("Camion Entreprise Pecheur", "{D8EE0BECCC3A65C5}Prefabs/Vehicles/Wheeled/M923A1/CAMION_PECHEUR.et", 40000, false, 1));
				items.Insert(new JobShopItem("504 Bledar", "{18C552AD61649195}Prefabs/Vehicles/Wheeled/SampleCar_01/504.et", 2000, false, 1));
				items.Insert(new JobShopItem("Honda Civic Noir", "{4EDE39F9D2809377}Prefabs/Vehicles/Wheeled/SampleCar_01/HONDACIVIC.et", 7000, false, 1));
				items.Insert(new JobShopItem("Smart Rouge", "{33C6BE45CC607C2C}Prefabs/Vehicles/Wheeled/SampleCar_01/AMI.et", 4000, false, 1));
				items.Insert(new JobShopItem("Golf GTI halloween", "{B28D0765B62AEF70}Prefabs/Vehicles/Wheeled/SampleCar_01/GOLFGTI_HALLOWEEN.et", 45000, false, 1));
				items.Insert(new JobShopItem("Golf GTI Noir", "{14ED968E40E322C0}Prefabs/Vehicles/Wheeled/SampleCar_01/GOLFGTI_NOIR.et", 45000, false, 1));
				items.Insert(new JobShopItem("Golf GTI Rouge", "{C5D538112D120F07}Prefabs/Vehicles/Wheeled/SampleCar_01/GOLFGTI_ROUGE.et", 45000, false, 1));
				items.Insert(new JobShopItem("Golf GTI Bleu", "{BC3FFE7076094082}Prefabs/Vehicles/Wheeled/SampleCar_01/GOLFGTI_BLEU.et", 45000, false, 1));
				items.Insert(new JobShopItem("508 Gendarmerie Vert", "{1116DE04D3A9E7E0}Prefabs/Vehicles/Wheeled/SampleCar_01/508_GENDARMERIE_VERT.et", 1000, false, 1));
				items.Insert(new JobShopItem("508 Gendarmerie Noir", "{E1C938615008F050}Prefabs/Vehicles/Wheeled/SampleCar_01/508_GENDARMERIE_NOIR.et", 1000, false, 1));
				items.Insert(new JobShopItem("508 Gendarmerie Bleu", "{A81E5820F81644B8}Prefabs/Vehicles/Wheeled/SampleCar_01/508_GENDARMERIE_BLEU.et", 1000, false, 1));
				items.Insert(new JobShopItem("508 Bleu", "{EB6560C43B9C9BBE}Prefabs/Vehicles/Wheeled/SampleCar_01/508_BLEU.et", 20000, false, 1));
				items.Insert(new JobShopItem("508 Noir", "{A44B0AB602604E89}Prefabs/Vehicles/Wheeled/SampleCar_01/508_NOIR.et", 20000, false, 1));
				items.Insert(new JobShopItem("508 Vert", "{B591E46C1F358F93}Prefabs/Vehicles/Wheeled/SampleCar_01/508_VERT.et", 20000, false, 1));
				items.Insert(new JobShopItem("Subaru Origine", "{5B7133B0A1C00360}Prefabs/Vehicles/Wheeled/SampleCar_01/SUBARU.et", 40000, false, 1));
				items.Insert(new JobShopItem("Subaru Noir", "{AF201B4D9B63E1B7}Prefabs/Vehicles/Wheeled/SampleCar_01/SUBARU_NOIR.et", 40000, false, 1));
				items.Insert(new JobShopItem("Lambo", "{F4A1AB57F8EEAA15}Prefabs/Vehicles/Wheeled/SampleCar_01/LAMBO.et", 100000, false, 1));
				items.Insert(new JobShopItem("Ferrari Rouge", "{631B5626A54BC5EE}Prefabs/Vehicles/Wheeled/SampleCar_01/FERRARIE.et", 100000, false, 1));
				items.Insert(new JobShopItem("FORDCOURIER KNN", "{FB43D7FFF978BEF8}Prefabs/Vehicles/Wheeled/SampleCar_01/FORDCOURIER_ENTRPRISEKNN.et", 8000, false, 1));
				items.Insert(new JobShopItem("FORDCOURIER_Noir", "{8370D5121C3D33A2}Prefabs/Vehicles/Wheeled/SampleCar_01/FORDCOURIER_NOIR.et", 8000, false, 1));
				items.Insert(new JobShopItem("FORDCOURIER_ROUGE", "{CB564D869010425E}Prefabs/Vehicles/Wheeled/SampleCar_01/FORDCOURIER_ROUGE.et", 8000, false, 1));
				items.Insert(new JobShopItem("FORDCOURIER GRIS", "{EE782C3B9FF0CDFC}Prefabs/Vehicles/Wheeled/SampleCar_01/FORDCOURIER_GRIS.et", 8000, false, 1));
				items.Insert(new JobShopItem("CHEVROLET Bleu", "{5DDE03BDDC931499}Prefabs/Vehicles/Wheeled/SampleCar_01/CHEVROLET_BLEU.et", 55000, false, 1));
				items.Insert(new JobShopItem("CHEVROLET Rouge", "{5DDE03BDDC931499}Prefabs/Vehicles/Wheeled/SampleCar_01/CHEVROLET_ROUGE.et", 55000, false, 1));
				items.Insert(new JobShopItem("CHEVROLET NOIR", "{23D80FB617DA598D}Prefabs/Vehicles/Wheeled/SampleCar_01/CHEVROLET_NOIR.et", 55000, false, 1));
				items.Insert(new JobShopItem("A45AMG2023", "{474A2B4788037205}Prefabs/Vehicles/Wheeled/SampleCar_01/A45AMG2023.et", 50000, false, 1));
				items.Insert(new JobShopItem("E190MERCEDES", "{C106078ED9DB7013}Prefabs/Vehicles/Wheeled/SampleCar_01/E190MERCEDES.et", 9000, false, 1));
				items.Insert(new JobShopItem("JEEPSUV Noir", "{933D6C180F8808B9}Prefabs/Vehicles/Wheeled/SampleCar_01/JEEPSUV.et", 40000, false, 1));
				items.Insert(new JobShopItem("LANDROVER", "{5809A1B541510D93}Prefabs/Vehicles/Wheeled/SampleCar_01/LANDROVER.et", 55000, false, 1));
				items.Insert(new JobShopItem("Clio 3 blanche Autoecole", "{3C26E4BA0EC230F7}Prefabs/Vehicles/Wheeled/SampleCar_01/CLIO3-autoecole.et", 1000, false, 1));		
				items.Insert(new JobShopItem("Golf 2 Rouge", "{7C4CB3D4E12F7E4D}Prefabs/Vehicles/Wheeled/SampleCar_01/GOLF2.et", 3500, false, 1));
				items.Insert(new JobShopItem("Golf 2 Blanc", "{B19664BF7867691A}Prefabs/Vehicles/Wheeled/SampleCar_01/GOLF2BLANC.et", 3500, false, 1));
				items.Insert(new JobShopItem("Clio 3 Noir", "{83C1C2D84CAACB46}Prefabs/Vehicles/Wheeled/SampleCar_01/CLIO3.et", 3500, false, 1));
				items.Insert(new JobShopItem("A45 AMG Noir", "{7B5716B8D8F61485}Prefabs/Vehicles/Wheeled/SampleCar_01/A45AMGNOIR.et", 54000, false, 1));
				items.Insert(new JobShopItem("A45 AMG Blanc", "{FA75C318C3ACCF0C}Prefabs/Vehicles/Wheeled/SampleCar_01/A45AMG.et", 54000, false, 1));
				items.Insert(new JobShopItem("Brabus 800 Blanc", "{81DAA87B03080B6C}Prefabs/Vehicles/Wheeled/SampleCar_01/BRABUS800_BLANC.et", 45000, false, 1));
				items.Insert(new JobShopItem("Brabus 800 Noir", "{F16B3617BBB5CDE7}Prefabs/Vehicles/Wheeled/SampleCar_01/BRABUS800.et", 70000, false, 1));
				items.Insert(new JobShopItem("Porsche Macanne Noir", "{EC08BAD12C10C869}Prefabs/Vehicles/Wheeled/SampleCar_01/PORCHESMACANNE.et", 65000, false, 1));
				items.Insert(new JobShopItem("Jaguar bleu", "{38C0540BCCA3A866}Prefabs/Vehicles/Wheeled/SampleCar_01/JAGUARD.et", 65000, false, 1));
				items.Insert(new JobShopItem("M4G82 Competition grise", "{209DB7994AC4E5F6}Prefabs/Vehicles/Wheeled/SampleCar_01/M4G82COMPETITION.et", 69000, false, 1));
				items.Insert(new JobShopItem("Alpha rouge", "{E81766A78923CB74}Prefabs/Vehicles/Wheeled/SampleCar_01/ALFA.et", 55000, false, 1));
				items.Insert(new JobShopItem("Cabriolet BMW Noir", "{A33CAB8BD442C8B8}Prefabs/Vehicles/Wheeled/SampleCar_01/DECAPOTABLEPROPULTION.et", 40000, false, 1));
				items.Insert(new JobShopItem("M5 Propultion Noir", "{C59978EC151076D2}Prefabs/Vehicles/Wheeled/SampleCar_01/M5PROPULTION.et", 22000, false, 1));
				items.Insert(new JobShopItem("Urus Noir 4x4", "{B1FAD54FAD9ADF58}Prefabs/Vehicles/Wheeled/SampleCar_01/URUS.et", 65000, false, 1));
				items.Insert(new JobShopItem("Rs6 Propultion Noir", "{26C7386813E54BF4}Prefabs/Vehicles/Wheeled/SampleCar_01/RS6ABTPROPULTION_NOIR.et", 60000, false, 1));
				items.Insert(new JobShopItem("Rs6 Propultion Blanc", "{7AD7102115D1D44C}Prefabs/Vehicles/Wheeled/SampleCar_01/RS6ABTPROPULTION.et", 60000, false, 1));
				items.Insert(new JobShopItem("Motocross Jaune et grise", "{6AC310BE50471280}Prefabs/Vehicles/Wheeled/SampleCar_01/motocross.et", 15000, false, 1));
				items.Insert(new JobShopItem("M3 Breack Grise Propultion", "{32F630B3EA2E3A8C}Prefabs/Vehicles/Wheeled/SampleCar_01/M3PROPULTION.et", 60000, false, 1));
				items.Insert(new JobShopItem("Jeep Propultion Rouge", "{286DED71B1B22BC6}Prefabs/Vehicles/Wheeled/SampleCar_01/jeeppropultion.et", 36000, false, 1));
				items.Insert(new JobShopItem("Iveco Camion Benne Blanc", "{4D580EA601037237}Prefabs/Vehicles/Wheeled/SampleCar_01/IVECO.et(blanc)", 18000, false, 1));
				items.Insert(new JobShopItem("Brabus ClassG Noir", "{E6FAEF5CFC3F1427}Prefabs/Vehicles/Wheeled/SampleCar_01/CLASSG4ROUE.et", 66000, false, 1));
				items.Insert(new JobShopItem("C63AMG Noir", "{384E98BE13EB007E}Prefabs/Vehicles/Wheeled/SampleCar_01/C63AMG.et", 50000, false, 1));
				items.Insert(new JobShopItem("560BENZ Verte", "{1FB75B92A6158042}Prefabs/Vehicles/Wheeled/SampleCar_01/560BENZ.et", 10000, false, 1));
				items.Insert(new JobShopItem("HyundaiTucsonGT (police uniquement)", "{2DB4E75BBAD34C0F}Prefabs/Vehicles/Wheeled/SampleCar_01/ HyundaiTucsonGT.et", 1000, false, 1));
				items.Insert(new JobShopItem("2CV", "{C4DAB817CA00C6FA}Prefabs/Vehicles/Wheeled/2CV/2cv.et", 1800, false, 1));
				items.Insert(new JobShopItem("5008", "{758AF083764883D7}Prefabs/Vehicles/Wheeled/5008civil/5008civil.et", 8000, false, 1));
				items.Insert(new JobShopItem("Porsche 718", "{F310B376AEA329ED}Prefabs/Vehicles/Wheeled/Porsche718/Porsche718.et", 28000, false, 1));
				items.Insert(new JobShopItem("205 Rouge", "{8BA4A3D4F74251AE}Prefabs/Vehicles/Wheeled/205/205.et", 3500, false, 1));
				items.Insert(new JobShopItem("205 Blanc", "{1D0C23683D26C8A4}Prefabs/Vehicles/Wheeled/205/205blanche.et", 3500, false, 1));
				items.Insert(new JobShopItem("205 Noir", "{1BF55A9EDCB6E280}Prefabs/Vehicles/Wheeled/205/205Noir.et", 3500, false, 1));
				items.Insert(new JobShopItem("Tmax 500 Gris", "{9B73565BCF79C725}Prefabs/Vehicles/moto/tmax/tmax2.et", 6000, false, 1));
				items.Insert(new JobShopItem("Tmax 500 Bleu", "{45EF92A354CF3FE2}Prefabs/Vehicles/moto/tmax/tmax2bleu.et", 6000, false, 1));
				items.Insert(new JobShopItem("Tmax 500 Rouge", "{CEB2980A02C232E8}Prefabs/Vehicles/moto/tmax/tmax2Rouge.et", 6000, false, 1));
				items.Insert(new JobShopItem("Tmax 2022 Gris", "{88C8042FD280BF5C}Prefabs/Vehicles/Wheeled/Tmax2022/TMAX2021.et", 6500, false, 1));
				items.Insert(new JobShopItem("Tmax 2022 Bleu", "{CCCA3016A7614691}Prefabs/Vehicles/Wheeled/Tmax2022/TMAX2021Bleu.et", 6500, false, 1));
				items.Insert(new JobShopItem("Scooter booster", "{79256F22ABF7389F}Prefabs/Vehicles/Wheeled/Booster/boosteur.et", 3000, false, 1));
				items.Insert(new JobShopItem("Scooter booster Noir", "{24DB7D93F5A2C860}Prefabs/Vehicles/Wheeled/Booster/boosteurNoir.et", 3000, false, 1));
				items.Insert(new JobShopItem("Pocket Bike Bleu", "{ED25193A9369455B}Prefabs/Vehicles/Wheeled/DirtyBike/minibike.et", 2500, false, 1));
				items.Insert(new JobShopItem("Pocket Bike Verte", "{839798E55ED922E0}Prefabs/Vehicles/Wheeled/DirtyBike/minibikevert.et", 2500, false, 1));
				items.Insert(new JobShopItem("Buggy Bleu", "{EAA1EF09BF77FF19}Prefabs/Vehicles/Wheeled/Buggy/buggy.et", 8000, false, 1));
				items.Insert(new JobShopItem("Buggy Rouge", "{9216D8BC5DD58E85}Prefabs/Vehicles/Wheeled/Buggy/buggyRouge.et", 8000, false, 1));
				items.Insert(new JobShopItem("BMW M2 Rouge", "{2DDDB72D9EB66CDD}Prefabs/Vehicles/Wheeled/BMWM2/M2.et", 27000, false, 1));
				items.Insert(new JobShopItem("BMW M2 Gris", "{138C7FA5088990C4}Prefabs/Vehicles/Wheeled/BMWM2/M2gris.et", 27000, false, 1));
				items.Insert(new JobShopItem("Audi RS3 Verte", "{58982DA61C487CA1}Prefabs/Vehicles/Wheeled/RS3/RS3.et", 32000, false, 1));
				items.Insert(new JobShopItem("Audi RS3 Blanche", "{B12CEF2DD92563FC}Prefabs/Vehicles/Wheeled/RS3/RS3Blanche.et", 32000, false, 1));
				items.Insert(new JobShopItem("Tiguan Noir voyage (hoxor pas vendre)", "{49385CA7A390FB84}Prefabs/Vehicles/Wheeled/tiguan/tiguanBlackremorq.et", 32000, false, 1));
				items.Insert(new JobShopItem("Depanneuse mecano", "{D81804162008D1FB}Prefabs/Vehicles/Wheeled/depaneuse/DEPANEUSEIVECO.et", 4000, false, 1));
				

				items.Insert(new JobShopItem(
					"GGT Noire",
					"{E8BE84C4BDE5016E}Prefabs/Vehicles/Core/GGT_Black.et",
					15000, true, 1));
				items.Insert(new JobShopItem(
					"GGT Pearl",
					"{9DE588D1E14049BF}Prefabs/Vehicles/Core/GGT_Pearl.et",
					15000, true, 1));
				items.Insert(new JobShopItem(
					"Javelin Noire",
					"{CF26BC30E038E2E5}Prefabs/Vehicles/Core/Javelin_Black.et",
					17000, true, 1));
				items.Insert(new JobShopItem(
					"Javelin Magenta",
					"{DA1D0C14007DC3B1}Prefabs/Vehicles/Core/Javelin_Magenta.et",
					17000, true, 1));
				items.Insert(new JobShopItem(
					"Javelin Orange",
					"{237D1D1B360C0711}Prefabs/Vehicles/Core/Javelin_Orange.et",
					17000, true, 1));
				items.Insert(new JobShopItem(
					"Javelin Violette",
					"{8740D99B0919C52B}Prefabs/Vehicles/Core/Javelin_Purple.et",
					17000, true, 1));
				items.Insert(new JobShopItem(
					"Renault Twingo 1993",
					"{D7437B1D3D93B287}Prefabs/Vehicles/Wheeled/twingo/twingo.et",
					3500, true, 1));
								items.Insert(new JobShopItem(
					"Tiguan Noir",
					"{CADEFFBF7BDC06C4}Prefabs/Vehicles/Wheeled/tiguan/tiguanBlack.et",
					30000, true, 1));
					items.Insert(new JobShopItem(
					"Seat Leon Noir",
					"{7C8B0AD86354F77B}Prefabs/Vehicles/Wheeled/SeatL/leon.et",
					20000, true, 1));
					items.Insert(new JobShopItem(
					"Mercedes Brabus",
					"{EDD6425F79E70B06}Prefabs/Vehicles/Wheeled/Brabus/brabus.et",
					40000, true, 1));
					items.Insert(new JobShopItem(
					"Dodge Chargeur SRT",
					"{C9B00A825F2A28AE}Prefabs/Vehicles/Wheeled/DutchChargerSRT/DodgeSRT.et",
					50000, true, 1));
								items.Insert(new JobShopItem(
					"Tiguan Gris",
					"{B5BB05A0206AB907}Prefabs/Vehicles/Wheeled/tiguan/tiguanGrise.et",
					30000, true, 1));
								items.Insert(new JobShopItem(
					"Tiguan Rose",
					"{455B2B6F742B9BE9}Prefabs/Vehicles/Wheeled/tiguan/tiguanRose.et",
					30000, true, 1));
												items.Insert(new JobShopItem(
					"SUV SMUR",
					"{DF4C50D0323EDC81}Prefabs/Vehicles/Wheeled/5008smur/5008smur.et",
					1000, true, 1));
				
				items.Insert(new JobShopItem(
					"Lunia Gamma Base",
					"{259CEE4F868F0BD5}Prefabs/Vehicles/Core/Lunia_Gamma_base.et",
					12000, true, 1));
				items.Insert(new JobShopItem(
					"Lunia Gamma Noire",
					"{D499ED40846E07DB}Prefabs/Vehicles/Core/Lunia_Gamma_Black.et",
					12000, true, 1));
				items.Insert(new JobShopItem(
					"Lunia Gamma Bleue",
					"{98097FEB4EAA38BD}Prefabs/Vehicles/Core/Lunia_Gamma_Blue.et",
					12000, true, 1));
				items.Insert(new JobShopItem(
					"Lunia Gamma Violette",
					"{0B5B3FB629A6FCCF}Prefabs/Vehicles/Core/Lunia_Gamma_Purple.et",
					12000, true, 1));
				items.Insert(new JobShopItem(
					"Ford Transit (van blanc)",
					"{ABD54AC9328F36F6}Prefabs/Transit_V1.et",
					12500, true, 1));
				items.Insert(new JobShopItem(
					"Ford Transit (van noir)",
					"{C7817E298E4BB9D8}Prefabs/Transit_V2.et",
					12500, true, 1));
			

				// === Nouveaux vehicules (ajout boss) ===
				items.Insert(new JobShopItem("Maverick XR Camo", "{170CC90EC2BCDF36}Prefabs/Vehicles/Wheeled/Maverick_XR_Camo.et", 6500, true, 1));
				items.Insert(new JobShopItem("Maverick XR Base", "{D9D1187340B0B963}Prefabs/Vehicles/Wheeled/Maverick_XR_base.et", 6500, true, 1));
				items.Insert(new JobShopItem("Maverick XR Noir", "{5B73B4AD06E216D1}Prefabs/Vehicles/Wheeled/Maverick_XR_Black.et", 6500, true, 1));
				items.Insert(new JobShopItem("Maverick XR Verte", "{5D9B4329096A3178}Prefabs/Vehicles/Wheeled/Maverick_XR_Green.et", 6500, true, 1));
				items.Insert(new JobShopItem("Alpine(gendarmerie)", "{2DAA93B31D39F619}Prefabs/Vehicles/Wheeled/alpine/alpine_01.et", 1000, true, 1));
				items.Insert(new JobShopItem("G300 Sable", "{A827856DA0C8BF14}Prefabs/Vehicles/Wheeled/G300/G300_CIV_sand.et", 25000, true, 1));
				items.Insert(new JobShopItem("G300", "{0EDDE9FB10B7D918}Prefabs/Vehicles/Wheeled/G300/G300_CIV.et", 25000, true, 1));
				items.Insert(new JobShopItem("Taxi Uber de service", "{B9BC7EAB1BE1AAE6}Prefabs/Vehicles/Wheeled/taxi/taxigolf.et", 1000, true, 1));
				items.Insert(new JobShopItem("Nissan Noir 4x4", "{CF8A18BF2BE9A6D2}Prefabs/Vehicles/Wheeled/nissan/nisaan.et", 10000, true, 1));
				items.Insert(new JobShopItem("Audi Rs6 Noir", "{C5E6B770C66222D1}Prefabs/Vehicles/Wheeled/audirs6/audirs6.et", 14000, true, 1));
				items.Insert(new JobShopItem("Audi Rs6 Blanc", "{4F33838F848D9359}Prefabs/Vehicles/Wheeled/audirs6/audirs6blanc.et", 14000, true, 1));
				items.Insert(new JobShopItem("Audi Rs6 Rouge", "{F68739DE1373CB4F}Prefabs/Vehicles/Wheeled/audirs6/audirs6Rouge.et", 14000, true, 1));
				items.Insert(new JobShopItem("C3 aircross Gris", "{190B9B87F9F31486}Prefabs/Vehicles/Wheeled/aircross/Aircross.et", 6000, true, 1));
				items.Insert(new JobShopItem("C3 aircross Vert", "{F7DB40D9E85BE601}Prefabs/Vehicles/Wheeled/aircross/AircrossVert.et", 6000, true, 1));
				items.Insert(new JobShopItem("C3 aircross Violet", "{8136ABA01A8EB983}Prefabs/Vehicles/Wheeled/aircross/AircrossViolet.et", 6000, true, 1));
				items.Insert(new JobShopItem("Bugatti Tourbillion 2024", "{F4C72A278BAFE18A}Prefabs/Vehicles/Wheeled/bugatti/bugatti.et", 60000, true, 1));
break;
			}
			
			case EJobType.VENDEUR_IMMOBILIER:
			{
				// Materiaux de construction et plans
				items.Insert(new JobShopItem(
					"Planches (x20)",
					"{06F1E252DC029B8C}Prefabs/Props/Civilian/Plank.et",
					3500, false, 20));
				items.Insert(new JobShopItem(
					"Clous",
					"{344BEBA1D2C8095C}Prefabs/Props/Civilian/Nails.et",
					3500, false, 1));
				items.Insert(new JobShopItem(
					"Nouveaux plans de base",
					"{703F2DB693C60ABF}Prefabs/Props/Civilian/NewBasePlans.et",
					5000, false, 1));
				items.Insert(new JobShopItem(
					"Plans de drapeau",
					"{535141D3EBC36D1E}Prefabs/BaseBuilding/Flag/FlagPlans.et",
					2000, false, 1));
				break;
			}
			
   case EJobType.SHOP_VETEMENTS:
{
    // Shop public vetements (8-15 capsules random, tri par categorie: tops/pants/footwear/headgear/fullbody/outerwear/jewelry/masks)
    items.Insert(JobShopItem.NewCat(
        "Adik TrackSuit",
        "{B32F419D8FDAD767}Prefabs/Uniforms/Tops/Adik_TrackSuit_Top_Prefab/Adik_TrackSuit_Top_Prefab.et",
        18, false, 1, "T-shirts"));
    items.Insert(JobShopItem.NewCat(
        "Mayka",
        "{5B5A32BB2B001E37}Prefabs/Uniforms/Tops/Mayka/Mayka.et",
        16, false, 1, "T-shirts"));
    items.Insert(JobShopItem.NewCat(
        "Mayka v2",
        "{8CBD9062378CC3AA}Prefabs/Uniforms/Tops/Maykav2/Maykav2.et",
        24, false, 1, "T-shirts"));
    items.Insert(JobShopItem.NewCat(
        "Mayka VDV",
        "{69BBCAA2756E759D}Prefabs/Uniforms/Tops/Mayka/Maykavdv.et",
        22, false, 1, "T-shirts"));
    items.Insert(JobShopItem.NewCat(
        "Tech 2021 Noir",
        "{C28DBC76B31BCFB9}Prefabs/Uniforms/Tops/Tech2021_Top/Tech2021_Black.et",
        22, false, 1, "T-shirts"));
    items.Insert(JobShopItem.NewCat(
        "Tech 2021 Gris",
        "{23809724188D7916}Prefabs/Uniforms/Tops/Tech2021_Top/Tech2021_Grey.et",
        20, false, 1, "T-shirts"));
    items.Insert(JobShopItem.NewCat(
        "T-shirt Nike Noir",
        "{01B00E6085AB7F62}Prefabs/Uniforms/Tops/Tshirt/Tshirt_NikeBlack.et",
        18, false, 1, "T-shirts"));
    items.Insert(JobShopItem.NewCat(
        "T-shirt Nike Gris",
        "{B7BA272883A83309}Prefabs/Uniforms/Tops/Tshirt/Tshirt_NikeGrey.et",
        28, false, 1, "T-shirts"));
    items.Insert(JobShopItem.NewCat(
        "T-shirt Trapstar Noir",
        "{52D2EEBAD7B55681}Prefabs/Uniforms/Tops/Tshirt/Tshirt_TrapstarBlack.et",
        16, false, 1, "T-shirts"));
    items.Insert(JobShopItem.NewCat(
        "T-shirt Trapstar Gris",
        "{9A32EC4812CC164B}Prefabs/Uniforms/Tops/Tshirt/Tshirt_TrapstarGrey.et",
        16, false, 1, "T-shirts"));
    items.Insert(JobShopItem.NewCat(
        "Jeans",
        "{217EAB99948D58C6}Prefabs/Uniforms/Pants/Jeans/Jeans.et",
        18, false, 1, "Pantalons"));
    items.Insert(JobShopItem.NewCat(
        "Jeans Skinny Noir",
        "{26D5620833E35FA9}Prefabs/Uniforms/Pants/Jeans_skinny/Jeans_BLC.et",
        22, false, 1, "Pantalons"));
    items.Insert(JobShopItem.NewCat(
        "Jeans Skinny Bleu",
        "{048F588D4F92EC7A}Prefabs/Uniforms/Pants/Jeans_skinny/Jeans_BLUE.et",
        22, false, 1, "Pantalons"));
    items.Insert(JobShopItem.NewCat(
        "Jeans LV2 Noir",
        "{7F4B708A80B0E1C2}Prefabs/Uniforms/Pants/JeansLV2/JeansLV2_BLACK.et",
        16, false, 1, "Pantalons"));
    items.Insert(JobShopItem.NewCat(
        "Jeans LV2 Bleu",
        "{B0B36F20705850AF}Prefabs/Uniforms/Pants/JeansLV2/JeansLV2_BLUE.et",
        22, false, 1, "Pantalons"));
    items.Insert(JobShopItem.NewCat(
        "Slim Pants 2",
        "{E3ABB650A6058174}Prefabs/Uniforms/Pants/Slim_pants2/Slim_Pants2.et",
        28, false, 1, "Pantalons"));
    items.Insert(JobShopItem.NewCat(
        "Slimfit Jeans",
        "{7CDD795E4561BA59}Prefabs/Uniforms/Pants/slimfitjeans/Slimfitjeans.et",
        22, false, 1, "Pantalons"));
    items.Insert(JobShopItem.NewCat(
        "Slimfit Jeans v2",
        "{2E91AB399704A811}Prefabs/Uniforms/Pants/Slimfit_jeans2/Slimfitjeans2.et",
        30, false, 1, "Pantalons"));
    items.Insert(JobShopItem.NewCat(
        "Slimfit Jeans Bleu",
        "{8FE755CD01698EAB}Prefabs/Uniforms/Pants/slimfitjeans/Slimfitjeans_blue.et",
        24, false, 1, "Pantalons"));
    items.Insert(JobShopItem.NewCat(
        "Slim Pants",
        "{29507BC8C1B417F4}Prefabs/Uniforms/Pants/slimpants/slimpants.et",
        16, false, 1, "Pantalons"));
    items.Insert(JobShopItem.NewCat(
        "Tech Joggers Noir",
        "{715965B35DB0DF3A}Prefabs/Uniforms/Pants/Tech_fleece_2019/Tech2019_Joggers_Blc.et",
        20, false, 1, "Pantalons"));
    items.Insert(JobShopItem.NewCat(
        "Tech Joggers Noir/Gris",
        "{80B497F3CDDA1F9F}Prefabs/Uniforms/Pants/Tech_fleece_2019/Tech2019_Joggers_Blc_grey.et",
        28, false, 1, "Pantalons"));
    items.Insert(JobShopItem.NewCat(
        "Tech Joggers Noir L",
        "{C91324A2D9149445}Prefabs/Uniforms/Pants/TF_LOWER/Tech2019_Joggers_Blc_L.et",
        26, false, 1, "Pantalons"));
    items.Insert(JobShopItem.NewCat(
        "Tech Joggers N/G L",
        "{CC1B274E455312F1}Prefabs/Uniforms/Pants/TF_LOWER/Tech2019_Joggers_Blcgry_L.et",
        24, false, 1, "Pantalons"));
    items.Insert(JobShopItem.NewCat(
        "Tech Joggers Gris",
        "{A147B63D50E60140}Prefabs/Uniforms/Pants/Tech_fleece_2019/Tech2019_Joggers_Grey.et",
        20, false, 1, "Pantalons"));
    items.Insert(JobShopItem.NewCat(
        "Tech Joggers Gris L",
        "{CC68092E70865F63}Prefabs/Uniforms/Pants/TF_LOWER/Tech2019_Joggers_Grey_L.et",
        22, false, 1, "Pantalons"));
    items.Insert(JobShopItem.NewCat(
        "AF1 Blanc",
        "{A81022B1019BF921}Prefabs/Footwear/AF1/AF1.et",
        26, false, 1, "Chaussures"));
    items.Insert(JobShopItem.NewCat(
        "AF1 Noir",
        "{72FC15E92093C1B5}Prefabs/Footwear/AF1/AF1BLC.et",
        18, false, 1, "Chaussures"));
    items.Insert(JobShopItem.NewCat(
        "Jordan 4 Noir",
        "{BF5959308824880F}Prefabs/Footwear/Jordan4/Jordan4_Black.et",
        18, false, 1, "Chaussures"));
    items.Insert(JobShopItem.NewCat(
        "Jordan 4 Bleu",
        "{977EFBD7CD4E8B5C}Prefabs/Footwear/Jordan4/Jordan4_Blue.et",
        28, false, 1, "Chaussures"));
    items.Insert(JobShopItem.NewCat(
        "Jordan 4 Military",
        "{E80A67B3534C08C2}Prefabs/Footwear/Jordan4/Jordan4_MilBlack.et",
        18, false, 1, "Chaussures"));
    items.Insert(JobShopItem.NewCat(
        "Jordan 4 Red Thunder",
        "{25812702E403A14F}Prefabs/Footwear/Jordan4/Jordan4_RedThunder.et",
        26, false, 1, "Chaussures"));
    items.Insert(JobShopItem.NewCat(
        "Jordan 4 Travis",
        "{F0C1424E37116B76}Prefabs/Footwear/Jordan4/Jordan4_Travis.et",
        26, false, 1, "Chaussures"));
    items.Insert(JobShopItem.NewCat(
        "Timberland",
        "{33C8338F6C238362}Prefabs/Footwear/Timberland/Timberland.et",
        24, false, 1, "Chaussures"));
    items.Insert(JobShopItem.NewCat(
        "TN Noir",
        "{C7923961D7235D71}Prefabs/Footwear/TNs/TN_Black.et",
        16, false, 1, "Chaussures"));
    items.Insert(JobShopItem.NewCat(
        "TN OG",
        "{D7766350D6C87B96}Prefabs/Footwear/TNs/TN_OG.et",
        30, false, 1, "Chaussures"));
    items.Insert(JobShopItem.NewCat(
        "Lunettes Moto",
        "{60C3CF88B62596D3}Prefabs/HeadGear/MotoGoggles/Motocross_goggles.et",
        18, false, 1, "Lunettes"));
    items.Insert(JobShopItem.NewCat(
        "Lunettes Moto Noires",
        "{FA8171458ADBCCD7}Prefabs/HeadGear/MotoGoggles/Motocross_goggles_Black.et",
        28, false, 1, "Lunettes"));
    items.Insert(JobShopItem.NewCat(
        "Lunettes Moto Bleues",
        "{6CE8EC7FDB8CB341}Prefabs/HeadGear/MotoGoggles/Motocross_goggles_Blue.et",
        18, false, 1, "Lunettes"));
    items.Insert(JobShopItem.NewCat(
        "Lunettes Moto Blanches",
        "{326173B74FA28C1D}Prefabs/HeadGear/MotoGoggles/Motocross_goggles_white.et",
        24, false, 1, "Lunettes"));
    items.Insert(JobShopItem.NewCat(
        "Turban V1",
        "{BE2B4A6E078724E1}Prefabs/Head/TurbanV1.et",
        26, false, 1, "Casquettes/Chapeaux"));
    items.Insert(JobShopItem.NewCat(
        "Kleidung 1",
        "{76A9D76101ECCC60}Prefabs/FullBody/Kleidung1.et",
        22, false, 1, "Vestes"));
    items.Insert(JobShopItem.NewCat(
        "Kleidung 2",
        "{05A6E4B3183B99F7}Prefabs/FullBody/Kleidung2.et",
        18, false, 1, "Vestes"));
    items.Insert(JobShopItem.NewCat(
        "Robe 1",
        "{A82152976A7FFEB1}Prefabs/FullBody/Robe1.et",
        16, false, 1, "Vestes"));
    items.Insert(JobShopItem.NewCat(
        "Gewand",
        "{7D1F4B5CA52FD2CD}Prefabs/FullBody/Gewand.et",
        24, false, 1, "Vestes"));
    items.Insert(JobShopItem.NewCat(
        "Robe de Moine",
        "{403711BF159B7B8C}MonkRobe/MonkRobe.et",
        18, false, 1, "Vestes"));
    items.Insert(JobShopItem.NewCat(
        "Robe de Moine URSS",
        "{2D3C56CE19A1F4EE}MonkRobe/MonkRobeUSSR.et",
        22, false, 1, "Vestes"));
    items.Insert(JobShopItem.NewCat(
        "Doudoune",
        "{AFD14B8019398D83}Puffer/Puffer.et",
        18, false, 1, "Vestes"));
    items.Insert(JobShopItem.NewCat(
        "Doudoune v2",
        "{BDA5216AA200D530}Puffer/Puffer2.et",
        28, false, 1, "Vestes"));

    // === Items ajoutes (categories TOPS/OUTERWEAR/HANDWEAR/FOOTWEAR/HEADGEAR/VESTS/EXTRA/BACKPACKS) ===
    // --- TOPS ---
    items.Insert(JobShopItem.NewCat("Jersey CIV", "{6501FBC0CF4569BE}Prefabs/Characters/Jackets/Jersey CIV.et", 18, false, 1, "Vestes"));
    items.Insert(JobShopItem.NewCat("Jersey ERA", "{FA4D39E3B6E483AF}Prefabs/Characters/Jackets/Jersey ERA.et", 16, false, 1, "Vestes"));
    items.Insert(JobShopItem.NewCat("Jersey RUS", "{662AF94FA8E09220}Prefabs/Characters/Jackets/Jersey RUS.et", 24, false, 1, "Vestes"));
    items.Insert(JobShopItem.NewCat("Jersey US", "{566E1F2C85C64360}Prefabs/Characters/Jackets/Jersey US.et", 22, false, 1, "Vestes"));
    // --- OUTERWEAR ---
    items.Insert(JobShopItem.NewCat("Adidas Jacket Blue", "{AFC09E495B296056}Prefabs/Characters/Jackets/Adidas Jacket (Blue).et", 22, false, 1, "Vestes"));
    items.Insert(JobShopItem.NewCat("Adidas Jacket NeonGreen", "{0647915C9B69A62F}Prefabs/Characters/Jackets/Adidas Jacket (NeonGreen).et", 20, false, 1, "Vestes"));
    items.Insert(JobShopItem.NewCat("Adidas Jacket Orange", "{37C80092445CE69E}Prefabs/Characters/Jackets/Adidas Jacket (Orange).et", 18, false, 1, "Vestes"));
    items.Insert(JobShopItem.NewCat("Adidas Jacket Red", "{5FA7FEC06E2CF9F5}Prefabs/Characters/Jackets/Adidas Jacket (Red).et", 18, false, 1, "Vestes"));
    items.Insert(JobShopItem.NewCat("Tommy Jacket", "{DAEEE2603088744B}Prefabs/Characters/Jackets/Tommy Jacket.et", 28, false, 1, "Vestes"));
    items.Insert(JobShopItem.NewCat("Tommy Jacket Blue", "{D9D38FA33735D0FA}Prefabs/Characters/Jackets/Tommy Jacket (Blue).et", 16, false, 1, "Vestes"));
    items.Insert(JobShopItem.NewCat("Tommy Jacket Red", "{D3FC429E8B2F1004}Prefabs/Characters/Jackets/Tommy Jacket (Red).et", 16, false, 1, "Vestes"));

    // --- FOOTWEAR ---
    items.Insert(JobShopItem.NewCat("Black Mid-Top Sneakers", "{D3019D99C844E740}Prefabs/Characters/Footwear/Black Mid-Top Sneakers.et", 22, false, 1, "Chaussures"));
    // --- HEADGEAR ---
    items.Insert(JobShopItem.NewCat("Cowboy Hat", "{C1AF56DD77A1C6B6}Prefabs/Characters/HeadGear/Hat_Panama_Soviet/Cowboy Hat.et", 22, false, 1, "Casquettes/Chapeaux"));
    items.Insert(JobShopItem.NewCat("Casque PASGT", "{10CB9BAC2E0B3070}Prefabs/Characters/HeadGear/Helmet_PASGT_01/1.et", 30, false, 1, "Casquettes/Chapeaux"));
    // --- VESTS ---
    items.Insert(JobShopItem.NewCat("Hi Vis Vest", "{43EFD5CAC897C0D4}Prefabs/Characters/Vests/Vest_NAZ/Hi Vis Vest.et", 16, false, 1, "Vestes"));
    // --- EXTRA ---

    // --- BACKPACKS ---
    items.Insert(JobShopItem.NewCat("Sac M5 Black", "{7E5E5D092CD279CF}Prefabs/Items/Equipment/Backpacks/Backpack_M5_Black.et", 28, false, 1, "Sacs/Divers"));
    items.Insert(JobShopItem.NewCat("Sac M5 Olive", "{28E3DCD97FA32F8D}Prefabs/Items/Equipment/Backpacks/Backpack_M5_Olive.et", 28, false, 1, "Sacs/Divers"));
    items.Insert(JobShopItem.NewCat("Sac M5 Tan", "{A28DC80496802BA5}Prefabs/Items/Equipment/Backpacks/Backpack_M5_Tan.et", 28, false, 1, "Sacs/Divers"));
    items.Insert(JobShopItem.NewCat("Sac M5 White", "{83ADFD77E338E064}Prefabs/Items/Equipment/Backpacks/Backpack_M5_White.et", 28, false, 1, "Sacs/Divers"));
    items.Insert(JobShopItem.NewCat("Sac medical sovietique", "{AC298BA8A7D27007}Prefabs/Items/Equipment/Backpacks/Backpack_Medical_Soviet_NoCross_01.et", 16, false, 1, "Sacs/Divers"));
    // --- EYEWEAR ---
    items.Insert(JobShopItem.NewCat("Gatorz Magnum", "{1615D4BB9E21B0E7}Prefabs/Characters/Eyewear/GATORZ_Magnum/GATORZ_Magnum_Base.et", 16, false, 1, "Lunettes"));
    items.Insert(JobShopItem.NewCat("Gatorz Magnum Bleu Miroir", "{DCA06A153A2D0243}Prefabs/Characters/Eyewear/GATORZ_Magnum/GATORZ_Magnum_Blue_Mirror_Polarized.et", 18, false, 1, "Lunettes"));
    items.Insert(JobShopItem.NewCat("Gatorz Magnum Brun", "{6DB36F5887EABBDB}Prefabs/Characters/Eyewear/GATORZ_Magnum/GATORZ_Magnum_Brown_Polarized.et", 16, false, 1, "Lunettes"));
    items.Insert(JobShopItem.NewCat("Gatorz Magnum Clair", "{F5E8C7D6551B7BDE}Prefabs/Characters/Eyewear/GATORZ_Magnum/GATORZ_Magnum_Clear.et", 14, false, 1, "Lunettes"));
    items.Insert(JobShopItem.NewCat("Gatorz Magnum Or Miroir", "{8B1464A553CC3C85}Prefabs/Characters/Eyewear/GATORZ_Magnum/GATORZ_Magnum_Gold_Mirror_Polarized.et", 18, false, 1, "Lunettes"));
    items.Insert(JobShopItem.NewCat("Gatorz Magnum Sunburst", "{6358BBE1FE596F2E}Prefabs/Characters/Eyewear/GATORZ_Magnum/GATORZ_Magnum_Sunburst_Mirror_Polarized.et", 18, false, 1, "Lunettes"));
    items.Insert(JobShopItem.NewCat("Gatorz Magnum Tan", "{DED6307D009BF689}Prefabs/Characters/Eyewear/GATORZ_Magnum/GATORZ_Magnum_Tan.et", 14, false, 1, "Lunettes"));
    items.Insert(JobShopItem.NewCat("Gatorz Magnum Tan Bleu Miroir", "{6DF8094E62D207B9}Prefabs/Characters/Eyewear/GATORZ_Magnum/GATORZ_Magnum_Tan_Blue_Mirror_Polarized.et", 18, false, 1, "Lunettes"));
    items.Insert(JobShopItem.NewCat("Gatorz Magnum Tan Brun", "{276A229A72AA36C7}Prefabs/Characters/Eyewear/GATORZ_Magnum/GATORZ_Magnum_Tan_Brown_Polarized.et", 16, false, 1, "Lunettes"));
    items.Insert(JobShopItem.NewCat("Gatorz Magnum Tan Clair", "{3D6F2FC58E64E1EE}Prefabs/Characters/Eyewear/GATORZ_Magnum/GATORZ_Magnum_Tan_Clear.et", 14, false, 1, "Lunettes"));
    items.Insert(JobShopItem.NewCat("Gatorz Magnum Tan Or Miroir", "{3A4C07FE0B33397F}Prefabs/Characters/Eyewear/GATORZ_Magnum/GATORZ_Magnum_Tan_Gold_Mirror_Polarized.et", 18, false, 1, "Lunettes"));
    items.Insert(JobShopItem.NewCat("Gatorz Magnum Tan Sunburst", "{ECD1DDE192958132}Prefabs/Characters/Eyewear/GATORZ_Magnum/GATORZ_Magnum_Tan_Sunburst_Mirror_Polarized.et", 18, false, 1, "Lunettes"));
    items.Insert(JobShopItem.NewCat("Oakley Holbrook", "{38DDCDBA1CD27E6C}Prefabs/Characters/Eyewear/Oakley_Holbrook/Oakley_Holbrook_Base.et", 16, false, 1, "Lunettes"));
    items.Insert(JobShopItem.NewCat("Oakley Holbrook Bleu Miroir", "{9F6BC0183F6A2EF7}Prefabs/Characters/Eyewear/Oakley_Holbrook/Oakley_Holbrook_Blue_Mirror_Polarized.et", 18, false, 1, "Lunettes"));
    items.Insert(JobShopItem.NewCat("Oakley Holbrook Brun", "{F31F210EA2D2906F}Prefabs/Characters/Eyewear/Oakley_Holbrook/Oakley_Holbrook_Brown_Polarized.et", 16, false, 1, "Lunettes"));
    items.Insert(JobShopItem.NewCat("Oakley Holbrook Clair", "{9A93C041B40C2638}Prefabs/Characters/Eyewear/Oakley_Holbrook/Oakley_Holbrook_Clear.et", 14, false, 1, "Lunettes"));
    items.Insert(JobShopItem.NewCat("Oakley Holbrook Or Miroir", "{C8DFCEA8568B1031}Prefabs/Characters/Eyewear/Oakley_Holbrook/Oakley_Holbrook_Gold_Mirror_Polarized.et", 18, false, 1, "Lunettes"));
    items.Insert(JobShopItem.NewCat("Oakley Holbrook Sunburst", "{5F31920535523A62}Prefabs/Characters/Eyewear/Oakley_Holbrook/Oakley_Holbrook_Sunburst_Mirror_Polarized.et", 18, false, 1, "Lunettes"));

    // === Nouveaux vetements (ajout boss) ===
    items.Insert(JobShopItem.NewCat("Vest M69 press", "{1626B8B9F7552036}Prefabs/Characters/Vests/Vest_M69/Vest_M69_press.et", 24, false, 1, "Vestes"));
    items.Insert(JobShopItem.NewCat("TrackSuit blue", "{C41E26F1CF0135F5}Prefabs/Characters/Uniforms/Track_suit/TrackSuit_blue.et", 24, false, 1, "T-shirts"));
    items.Insert(JobShopItem.NewCat("TrackSuit Stasi", "{C0876F3EC7349D9C}Prefabs/Characters/Uniforms/Track_suit/TrackSuit_Stasi.et", 20, false, 1, "T-shirts"));
    items.Insert(JobShopItem.NewCat("Track Suit Pants", "{3071DFCF7E4D2216}Prefabs/Characters/Uniforms/Track_suit_pants/Track_Suit_Pants.et", 24, false, 1, "T-shirts"));
    items.Insert(JobShopItem.NewCat("Track Suit Pants Stasi", "{AE67A46BE7105455}Prefabs/Characters/Uniforms/Track_suit_pants/Track_Suit_Pants_Stasi.et", 28, false, 1, "T-shirts"));
    items.Insert(JobShopItem.NewCat("Hawaii shirt01", "{C132489E4B3C0745}Prefabs/Shirts_prefab/Hawaii_shirt01.et", 28, false, 1, "T-shirts"));
    items.Insert(JobShopItem.NewCat("Hawaii shirt02", "{D6BFCFC7D1420454}Prefabs/Shirts_prefab/Hawaii_shirt02.et", 20, false, 1, "T-shirts"));
    items.Insert(JobShopItem.NewCat("Hawaii shirt03", "{3323833EDDA7933F}Prefabs/Shirts_prefab/Hawaii_shirt03.et", 22, false, 1, "T-shirts"));
    items.Insert(JobShopItem.NewCat("Hawaii shirt04", "{0E17A606A8CB1A08}Prefabs/Shirts_prefab/Hawaii_shirt04.et", 24, false, 1, "T-shirts"));
    items.Insert(JobShopItem.NewCat("Hawaii shirt05", "{EB8BEAFFA42E8D63}Prefabs/Shirts_prefab/Hawaii_shirt05.et", 26, false, 1, "T-shirts"));
    items.Insert(JobShopItem.NewCat("Hawaii shirt06", "{87DFDE1F18EA024D}Prefabs/Shirts_prefab/Hawaii_shirt06.et", 28, false, 1, "T-shirts"));
    items.Insert(JobShopItem.NewCat("Hawaii shirt07", "{624392E6140F9526}Prefabs/Shirts_prefab/Hawaii_shirt07.et", 20, false, 1, "T-shirts"));
    items.Insert(JobShopItem.NewCat("Hawaii shirt08", "{FDB7946FF2331023}Prefabs/Shirts_prefab/Hawaii_shirt08.et", 22, false, 1, "T-shirts"));
    items.Insert(JobShopItem.NewCat("Hawaii shirt09", "{182BD896FED68748}Prefabs/Shirts_prefab/Hawaii_shirt09.et", 24, false, 1, "T-shirts"));
    items.Insert(JobShopItem.NewCat("G3 shorts1", "{4FE8D1C23A81B42D}Prefabs/Shorts_prefab/G3_shorts1.et", 26, false, 1, "Shorts"));
    items.Insert(JobShopItem.NewCat("G3 shorts10", "{86EBD54B22B08214}Prefabs/Shorts_prefab/G3_shorts10.et", 24, false, 1, "Shorts"));
    items.Insert(JobShopItem.NewCat("G3 shorts2", "{BF16BB8ECED93E57}Prefabs/Shorts_prefab/G3_shorts2.et", 28, false, 1, "Shorts"));
    items.Insert(JobShopItem.NewCat("G3 shorts3", "{5A8AF777C23CA93C}Prefabs/Shorts_prefab/G3_shorts3.et", 20, false, 1, "Shorts"));
    items.Insert(JobShopItem.NewCat("G3 shorts4", "{82229EB6BBB5B760}Prefabs/Shorts_prefab/G3_shorts4.et", 22, false, 1, "Shorts"));
    items.Insert(JobShopItem.NewCat("G3 shorts5", "{67BED24FB750200B}Prefabs/Shorts_prefab/G3_shorts5.et", 24, false, 1, "Shorts"));
    items.Insert(JobShopItem.NewCat("G3 shorts6", "{0BEAE6AF0B94AF25}Prefabs/Shorts_prefab/G3_shorts6.et", 26, false, 1, "Shorts"));
    items.Insert(JobShopItem.NewCat("G3 shorts7", "{EE76AA560771384E}Prefabs/Shorts_prefab/G3_shorts7.et", 28, false, 1, "Shorts"));
    items.Insert(JobShopItem.NewCat("G3 shorts8", "{7182ACDFE14DBD4B}Prefabs/Shorts_prefab/G3_shorts8.et", 20, false, 1, "Shorts"));
    items.Insert(JobShopItem.NewCat("G3 shorts9", "{941EE026EDA82A20}Prefabs/Shorts_prefab/G3_shorts9.et", 22, false, 1, "Shorts"));
    items.Insert(JobShopItem.NewCat("Chinelo", "{6B7AB6C87940E991}Prefabs/Chinelo/Chinelo.et", 24, false, 1, "Chaussures"));
    items.Insert(JobShopItem.NewCat("ChineloBlack", "{E6A22A586C9A92BC}Prefabs/Chinelo/ChineloBlack.et", 24, false, 1, "Chaussures"));
    items.Insert(JobShopItem.NewCat("JuliAzul", "{5E215A166B380901}Prefabs/Oculos/JuliAzul.et", 26, false, 1, "Lunettes"));
    items.Insert(JobShopItem.NewCat("JuliGold", "{933D672B6CCB871C}Prefabs/Oculos/JuliGold.et", 22, false, 1, "Lunettes"));
    items.Insert(JobShopItem.NewCat("JuliPrata", "{96C9A8EA60C688B4}Prefabs/Oculos/JuliPrata.et", 22, false, 1, "Lunettes"));
    items.Insert(JobShopItem.NewCat("JuliVerde", "{E041317305991C7A}Prefabs/Oculos/JuliVerde.et", 28, false, 1, "Lunettes"));
    items.Insert(JobShopItem.NewCat("JuliVermelho", "{394A30BA6DF9CC50}Prefabs/Oculos/JuliVermelho.et", 22, false, 1, "Lunettes"));
    items.Insert(JobShopItem.NewCat("JuliRoxo", "{85BBA1573DE02415}Prefabs/Oculos/JuliRoxo.et", 20, false, 1, "Lunettes"));
    items.Insert(JobShopItem.NewCat("ShortsBrasil", "{1A259F861544088F}Prefabs/Bermuda/ShortsBrasil.et", 24, false, 1, "Shorts"));
    items.Insert(JobShopItem.NewCat("ShortsCaveiraFloral", "{559DCCB2D3E28A80}Prefabs/Bermuda/ShortsCaveiraFloral.et", 20, false, 1, "Shorts"));
    items.Insert(JobShopItem.NewCat("SilverBraceletLeft", "{E9F1A1D2969E2C92}Prefabs/Bracelet/SilverBraceletLeft.et", 22, false, 1, "Bijoux"));
    items.Insert(JobShopItem.NewCat("T-ShirtBotafogo", "{777E24ACE740E047}Prefabs/Camisa/T-ShirtBotafogo.et", 20, false, 1, "T-shirts"));
    items.Insert(JobShopItem.NewCat("T-ShirtBrasil", "{01B45452D5A77146}Prefabs/Camisa/T-ShirtBrasil.et", 28, false, 1, "T-shirts"));
    items.Insert(JobShopItem.NewCat("T-ShirtFlamengo", "{A391F7D41CB736DD}Prefabs/Camisa/T-ShirtFlamengo.et", 24, false, 1, "T-shirts"));
    items.Insert(JobShopItem.NewCat("T-ShirtFluminense", "{963DB72AE966259F}Prefabs/Camisa/T-ShirtFluminense.et", 24, false, 1, "T-shirts"));
    items.Insert(JobShopItem.NewCat("T-ShirtVasco", "{5B7B3D70B28F2E45}Prefabs/Camisa/T-ShirtVasco.et", 28, false, 1, "T-shirts"));
    items.Insert(JobShopItem.NewCat("Bandana Blk", "{5364B85EE0B5B5A7}Prefabs/Characters/HeadGear/BandanaHead/Bandana_Blk.et", 26, false, 1, "Casquettes/Chapeaux"));
    items.Insert(JobShopItem.NewCat("Bandana Blue", "{D2FA56860695DE21}Prefabs/Characters/HeadGear/BandanaHead/Bandana_Blue.et", 26, false, 1, "Casquettes/Chapeaux"));
    items.Insert(JobShopItem.NewCat("Bandana Red", "{683C8B1394143FDD}Prefabs/Characters/HeadGear/BandanaHead/Bandana_Red.et", 20, false, 1, "Casquettes/Chapeaux"));
    items.Insert(JobShopItem.NewCat("FlipBill BlkBlk", "{520C46AF98F43750}Prefabs/Characters/HeadGear/Snapbacks/FlipBill_BlkBlk.et", 26, false, 1, "Casquettes/Chapeaux"));
    items.Insert(JobShopItem.NewCat("FlipBill BlkBlue", "{3711376EA955A5F8}Prefabs/Characters/HeadGear/Snapbacks/FlipBill_BlkBlue.et", 22, false, 1, "Casquettes/Chapeaux"));
    items.Insert(JobShopItem.NewCat("FlipBill BlkRed", "{B78FE665A554B918}Prefabs/Characters/HeadGear/Snapbacks/FlipBill_BlkRed.et", 20, false, 1, "Casquettes/Chapeaux"));
    items.Insert(JobShopItem.NewCat("FlipBill BlueBlk", "{40A451EA66B96340}Prefabs/Characters/HeadGear/Snapbacks/FlipBill_BlueBlk.et", 22, false, 1, "Casquettes/Chapeaux"));
    items.Insert(JobShopItem.NewCat("FlipBill BlueBlue", "{114D921A7FC992A8}Prefabs/Characters/HeadGear/Snapbacks/FlipBill_BlueBlue.et", 24, false, 1, "Casquettes/Chapeaux"));
    items.Insert(JobShopItem.NewCat("FlipBill BlueRed", "{8BD8A8E31E21C094}Prefabs/Characters/HeadGear/Snapbacks/FlipBill_BlueRed.et", 26, false, 1, "Casquettes/Chapeaux"));
    items.Insert(JobShopItem.NewCat("FlipBill RedBlk", "{D8AADCC562E04D4A}Prefabs/Characters/HeadGear/Snapbacks/FlipBill_RedBlk.et", 20, false, 1, "Casquettes/Chapeaux"));
    items.Insert(JobShopItem.NewCat("FlipBill RedBlue", "{1D61ECABD7B1B034}Prefabs/Characters/HeadGear/Snapbacks/FlipBill_RedBlue.et", 20, false, 1, "Casquettes/Chapeaux"));
    items.Insert(JobShopItem.NewCat("FlipBill RedRed", "{13D625CC1A78EE9E}Prefabs/Characters/HeadGear/Snapbacks/FlipBill_RedRed.et", 24, false, 1, "Casquettes/Chapeaux"));
    items.Insert(JobShopItem.NewCat("GermanHelmet", "{402DA394A243655B}Prefabs/Characters/HeadGear/BikerHelmets/GermanHelmet.et", 28, false, 1, "Casquettes/Chapeaux"));
    items.Insert(JobShopItem.NewCat("VintageHelmet", "{18CED2DCE7C20AEE}Prefabs/Characters/HeadGear/BikerHelmets/VintageHelmet.et", 24, false, 1, "Casquettes/Chapeaux"));
    items.Insert(JobShopItem.NewCat("FlannelShirt", "{12D14EEF0A98A685}Prefabs/Characters/Uniforms/FlannelShirt/FlannelShirt.et", 24, false, 1, "T-shirts"));
    items.Insert(JobShopItem.NewCat("FlannelShirt2", "{7F20924CBCDA52E5}Prefabs/Characters/Uniforms/FlannelShirt/FlannelShirt2.et", 28, false, 1, "T-shirts"));
    items.Insert(JobShopItem.NewCat("FlannelShirt3", "{9ABCDEB5B03FC58E}Prefabs/Characters/Uniforms/FlannelShirt/FlannelShirt3.et", 20, false, 1, "T-shirts"));
    items.Insert(JobShopItem.NewCat("FlannelShirt4", "{A788FB8DC5534CB9}Prefabs/Characters/Uniforms/FlannelShirt/FlannelShirt4.et", 22, false, 1, "T-shirts"));
    items.Insert(JobShopItem.NewCat("FlannelShirt5", "{4214B774C9B6DBD2}Prefabs/Characters/Uniforms/FlannelShirt/FlannelShirt5.et", 24, false, 1, "T-shirts"));
    items.Insert(JobShopItem.NewCat("Pant JeansBlk", "{93AF8B27153AB0C9}Prefabs/Characters/Uniforms/Pants_Trousers_01/Pant_JeansBlk.et", 20, false, 1, "Pantalons"));
    items.Insert(JobShopItem.NewCat("Pant JeansBlue", "{9744E27F019B9010}Prefabs/Characters/Uniforms/Pants_Trousers_01/Pant_JeansBlue.et", 28, false, 1, "Pantalons"));
    items.Insert(JobShopItem.NewCat("Pant JeansGry", "{0F24162699982186}Prefabs/Characters/Uniforms/Pants_Trousers_01/Pant_JeansGry.et", 20, false, 1, "Pantalons"));
    items.Insert(JobShopItem.NewCat("Pant Leather", "{EB30D0279C2AF4C1}Prefabs/Characters/Uniforms/Pants_Trousers_01/Pant_Leather.et", 22, false, 1, "Pantalons"));
    items.Insert(JobShopItem.NewCat("Pant LeatherTuck", "{083BA546735C5C69}Prefabs/Characters/Uniforms/Pants_Trousers_01/Pant_LeatherTuck.et", 28, false, 1, "Pantalons"));
    items.Insert(JobShopItem.NewCat("LeatherVest Base", "{E4255957816F96B6}Prefabs/Characters/Vests/LeatherMC/LeatherVest_Base.et", 24, false, 1, "Vestes"));
    items.Insert(JobShopItem.NewCat("LeatherVest Entropy", "{D08BF7B0E63551B9}Prefabs/Characters/Vests/LeatherMC/LeatherVest_Entropy.et", 22, false, 1, "Vestes"));
    items.Insert(JobShopItem.NewCat("LeatherVest Kingston", "{95B0BE428AAD43BC}Prefabs/Characters/Vests/LeatherMC/LeatherVest_Kingston.et", 20, false, 1, "Vestes"));
    items.Insert(JobShopItem.NewCat("LeatherVest Mayans", "{A7A7B2AF4B616469}Prefabs/Characters/Vests/LeatherMC/LeatherVest_Mayans.et", 22, false, 1, "Vestes"));
    items.Insert(JobShopItem.NewCat("LeatherVest TFMC", "{36881E56D2FD2BC3}Prefabs/Characters/Vests/LeatherMC/LeatherVest_TFMC.et", 22, false, 1, "Vestes"));
    items.Insert(JobShopItem.NewCat("WOLF Jacket", "{D7623B1461BEA094}Prefabs/Characters/Uniforms/WOLF_JACKET.et", 16, false, 1, "Vestes"));
    items.Insert(JobShopItem.NewCat("Woobie AOR1", "{8D88E794E7D17131}Prefabs/Characters/Uniforms/Shirt_Turtleneck_01/Woobie_AOR1.et", 16, false, 1, "T-shirts"));
    items.Insert(JobShopItem.NewCat("Woobie BLK", "{FDEB355B305C0353}Prefabs/Characters/Uniforms/Shirt_Turtleneck_01/Woobie_BLK.et", 16, false, 1, "T-shirts"));
    items.Insert(JobShopItem.NewCat("Woobie DNC", "{0CEF957C3552CD9F}Prefabs/Characters/Uniforms/Shirt_Turtleneck_01/Woobie_DNC.et", 16, false, 1, "T-shirts"));
    items.Insert(JobShopItem.NewCat("Woobie M81", "{47AE943044807822}Prefabs/Characters/Uniforms/Shirt_Turtleneck_01/Woobie_M81.et", 16, false, 1, "T-shirts"));
    items.Insert(JobShopItem.NewCat("Woobie M81 Winter", "{5617BB7D3D6285C2}Prefabs/Characters/Uniforms/Shirt_Turtleneck_01/Woobie_M81_WINTER.et", 16, false, 1, "T-shirts"));
    items.Insert(JobShopItem.NewCat("Woobie Marpat Winter", "{FE9BFB7102287E12}Prefabs/Characters/Uniforms/Shirt_Turtleneck_01/Woobie_MARPAT_WINTER.et", 16, false, 1, "T-shirts"));
  items.Insert(JobShopItem.NewCat("Woobie OD", "{D32658E5067DB51A}Prefabs/Characters/Uniforms/Shirt_Turtleneck_01/Woobie_OD.et", 16, false, 1, "T-shirts"));
    items.Insert(JobShopItem.NewCat("Woobie Tiger", "{B67251AB7AC7973E}Prefabs/Characters/Uniforms/Shirt_Turtleneck_01/Woobie_Tiger.et", 16, false, 1, "T-shirts"));
    items.Insert(JobShopItem.NewCat("Duffle Sac", "{72234C5272D6DF3C}Robber/Duffle.et", 5000, false, 1, "Sacs/Divers"));

    // === Nouveaux items ajoutes (batch footwear/tshirts/caps/vest/jeans) ===
    // --- FOOTWEAR ---
    items.Insert(JobShopItem.NewCat("Chaussures 3", "{A8B6226570C09ACA}Prefabs/Characters/Footwear/3.et", 20, false, 1, "Chaussures"));
    items.Insert(JobShopItem.NewCat("Alexandre McKeen", "{37ECE867F7F4E02A}Prefabs/Characters/Footwear/Alexandre_McKeen.et", 28, false, 1, "Chaussures"));
    items.Insert(JobShopItem.NewCat("Balentino Shoes", "{658433EBCB0204FD}Prefabs/Characters/Footwear/Balentino_Shoes.et", 30, false, 1, "Chaussures"));
    items.Insert(JobShopItem.NewCat("Bamba", "{6F55F4BD37D40FDF}Prefabs/Characters/Footwear/Bamba.et", 22, false, 1, "Chaussures"));
    items.Insert(JobShopItem.NewCat("Sandalias", "{26699321DD291312}Prefabs/Characters/Footwear/Sandalias.et", 16, false, 1, "Chaussures"));

    // --- T-SHIRTS / DESIGNER TEES ---
    items.Insert(JobShopItem.NewCat("Designer T-Shirt", "{BBBBB5D7AE32A05A}Prefabs/Characters/Uniforms/Jacket_KZS/Desingner_T_Shirt.et", 24, false, 1, "T-shirts"));
    items.Insert(JobShopItem.NewCat("Designer T-Shirt 3", "{A29FD3552FDD9B99}Prefabs/Characters/Uniforms/Jacket_KZS/Desingner_T_Shirt_3.et", 24, false, 1, "T-shirts"));
    items.Insert(JobShopItem.NewCat("Designer T-Shirt 4", "{7A37BA94565485C5}Prefabs/Characters/Uniforms/Jacket_KZS/Desingner_T_Shirt_4.et", 24, false, 1, "T-shirts"));
    items.Insert(JobShopItem.NewCat("Designer T-Shirt 5", "{9FABF66D5AB112AE}Prefabs/Characters/Uniforms/Jacket_KZS/Desingner_T_Shirt_5.et", 24, false, 1, "T-shirts"));
    items.Insert(JobShopItem.NewCat("Designer T-Shirt 6", "{F3FFC28DE6759D80}Prefabs/Characters/Uniforms/Jacket_KZS/Desingner_T_Shirt_6.et", 24, false, 1, "T-shirts"));
    items.Insert(JobShopItem.NewCat("Designer T-Shirt 7", "{16638E74EA900AEB}Prefabs/Characters/Uniforms/Jacket_KZS/Desingner_T_Shirt_7.et", 24, false, 1, "T-shirts"));
    items.Insert(JobShopItem.NewCat("Designer T-Shirt 8", "{899788FD0CAC8FEE}Prefabs/Characters/Uniforms/Jacket_KZS/Desingner_T_Shirt_8.et", 24, false, 1, "T-shirts"));
    items.Insert(JobShopItem.NewCat("Designer T-Shirt 9", "{6C0BC40400491885}Prefabs/Characters/Uniforms/Jacket_KZS/Desingner_T_Shirt_9.et", 24, false, 1, "T-shirts"));

    // --- POLO VOSS ---
    items.Insert(JobShopItem.NewCat("Polo Voss", "{5BB90ED3FEBFBF48}Prefabs/Characters/Uniforms/Jacket_KZS/Polo_Voss.et", 20, false, 1, "T-shirts"));
    items.Insert(JobShopItem.NewCat("Polo Voss 10", "{18F107C2604219B2}Prefabs/Characters/Uniforms/Jacket_KZS/Polo_Voss_10.et", 20, false, 1, "T-shirts"));
    items.Insert(JobShopItem.NewCat("Polo Voss 11", "{FD6D4B3B6CA78ED9}Prefabs/Characters/Uniforms/Jacket_KZS/Polo_Voss_11.et", 20, false, 1, "T-shirts"));
    items.Insert(JobShopItem.NewCat("Polo Voss 3", "{1C75306A443D03E8}Prefabs/Characters/Uniforms/Jacket_KZS/Polo_Voss_3.et", 20, false, 1, "T-shirts"));
    items.Insert(JobShopItem.NewCat("Polo Voss 4", "{2141155231518ADF}Prefabs/Characters/Uniforms/Jacket_KZS/Polo_Voss_4.et", 20, false, 1, "T-shirts"));
    items.Insert(JobShopItem.NewCat("Polo Voss 5", "{C4DD59AB3DB41DB4}Prefabs/Characters/Uniforms/Jacket_KZS/Polo_Voss_5.et", 20, false, 1, "T-shirts"));
    items.Insert(JobShopItem.NewCat("Polo Voss 6", "{A8896D4B8170929A}Prefabs/Characters/Uniforms/Jacket_KZS/Polo_Voss_6.et", 20, false, 1, "T-shirts"));
    items.Insert(JobShopItem.NewCat("Polo Voss 7", "{4D1521B28D9505F1}Prefabs/Characters/Uniforms/Jacket_KZS/Polo_Voss_7.et", 20, false, 1, "T-shirts"));
    items.Insert(JobShopItem.NewCat("Polo Voss 8", "{D2E1273B6BA980F4}Prefabs/Characters/Uniforms/Jacket_KZS/Polo_Voss_8.et", 20, false, 1, "T-shirts"));
    items.Insert(JobShopItem.NewCat("Polo Voss 9", "{377D6BC2674C179F}Prefabs/Characters/Uniforms/Jacket_KZS/Polo_Voss_9.et", 20, false, 1, "T-shirts"));

    // --- LONGSLEEVES (T-SHIRTS) ---
    items.Insert(JobShopItem.NewCat("Long Sleeves Tactical", "{0FDD7B08D6DBE898}Prefabs/Characters/Uniforms/Jacket_KZS/LongSleevesTactical.et", 18, false, 1, "T-shirts"));

    // --- T-SHIRT DG ---
    items.Insert(JobShopItem.NewCat("T-Shirt DG", "{E01B8FB8CA2BF031}Prefabs/Characters/Uniforms/Jacket_KZS/T_Shirt_DG.et", 22, false, 1, "T-shirts"));
    items.Insert(JobShopItem.NewCat("T-Shirt DG 10", "{F6FF9F0C35E28AEC}Prefabs/Characters/Uniforms/Jacket_KZS/T_Shirt_DG_10.et", 22, false, 1, "T-shirts"));
    items.Insert(JobShopItem.NewCat("T-Shirt DG 1", "{669CEBDF082C71D8}Prefabs/Characters/Uniforms/Jacket_KZS/T_Shirt_DG_1.et", 22, false, 1, "T-shirts"));

    // --- CASQUETTES/CHAPEAUX ---
    items.Insert(JobShopItem.NewCat("Fucci Cap", "{679C4F4016C2BFBF}Prefabs/Clothing/Fucci_Cap.et", 26, false, 1, "Casquettes/Chapeaux"));
    items.Insert(JobShopItem.NewCat("LA Cap", "{4745B518BBC6404A}Prefabs/Clothing/LA_Cap.et", 22, false, 1, "Casquettes/Chapeaux"));
    items.Insert(JobShopItem.NewCat("NY Cap", "{D1D7A26337DAF3AA}Prefabs/Clothing/NY_Cap.et", 22, false, 1, "Casquettes/Chapeaux"));

    // --- VESTES ---
    items.Insert(JobShopItem.NewCat("Glorious Gangsta Vest", "{FD6B970AC3A55078}Prefabs/Characters/Vests/Vest_NAZ/Glorious _Gangsta _Vest.et", 28, false, 1, "Vestes"));

    // --- PANTALONS ---
    items.Insert(JobShopItem.NewCat("Jeans KZS", "{23AC997BA4F46D3A}Prefabs/Characters/Uniforms/Pants_KZS/Jeans.et", 18, false, 1, "Pantalons"));
    items.Insert(JobShopItem.NewCat("Skinny Jeans KZS", "{5ECD95EB124CCCE8}Prefabs/Characters/Uniforms/Pants_KZS/Skinny_Jeans.et", 20, false, 1, "Pantalons"));
    break;
}

			
			case EJobType.MECANICIEN:
			{
				// Catalogue Mecanicien - A REMPLIR PAR LE BOSS
				// Pour l instant catalogue placeholder (vide). Le menu shop s ouvrira correctement
				// avec un message "Aucun article disponible".
				// Boss : ajoute ici tes items (outils, pieces detachees, etc.)
				// Exemple : 
				// items.Insert(JobShopItem.NewCat("Cle a molette", "{XXX}Prefabs/.../Wrench.et", 50, false, 1, "Sacs/Divers"));
								items.Insert(JobShopItem.NewCat(
					"Cle a molette",
					"{4AF9664BEE9263A4}Prefabs/Items/Equipment/Kits/RepairKit_01/RepairKit_01_base.et",
					500, false, 1, "Sacs/Divers"));
												items.Insert(JobShopItem.NewCat(
					"JerryCan",
					"{E7DF31108D38A8A8}Prefabs/Items/Fuel/Jerrycan_01/Jerrycan_01_item_base.et",
					200, false, 1, "Sacs/Divers"));
				
				
				break;
			}
			
			case EJobType.JOURNALISTE:
			{
				// Catalogue Journaliste - A REMPLIR PAR LE BOSS
				// Pour l instant catalogue placeholder (vide). Le menu shop s ouvrira correctement
				// avec un message "Aucun article disponible".
				// Boss : ajoute ici tes items (appareils photo, micros, etc.)
				// Exemple : 
				// items.Insert(JobShopItem.NewCat("Appareil photo", "{XXX}Prefabs/.../Camera.et", 500, false, 1, "Sacs/Divers"));
				items.Insert(JobShopItem.NewCat(
					"Microphone",
					"{ED55D0DFEC11E9E6}Prefabs/Items/Equipment/Press/HandheldMicrophone/HandheldMicrophone.et",
					300, false, 1, "Sacs/Divers"));
				items.Insert(JobShopItem.NewCat(
					"Camera",
					"{B26A0E5BB25F0CC9}Prefabs/Weapons/Cameras/Camcorder/Camcorder.et",
					600, false, 1, "Sacs/Divers"));
				items.Insert(JobShopItem.NewCat(
					"Gilet Press",
					"{1626B8B9F7552036}Prefabs/Characters/Vests/Vest_M69/Vest_M69_press.et",
					200, false, 1, "Vestes"));
								items.Insert(JobShopItem.NewCat(
					"Badge Press",
					"{A7A31CCBCEAF536D}Prefabs/Characters/Misc/Press_ID/Press_ID.et",
					50, false, 1, "Sacs/Divers"));
				break;
			}
			
			case EJobType.SHOP_NOURRITURE:
			{
				// Shop public nourriture (2-5 capsules random)

				
				// === Boissons et nourriture ajoutees ===
				items.Insert(new JobShopItem("Ration MRE ERA", "{AF9A99FE8671303D}Prefabs/Items/Equipment/Radios/ERA MRE 1.et", 20, false, 1));
				items.Insert(new JobShopItem("Bouteille d'eau", "{F9C514AC996D4829}Prefabs/Items/Equipment/Radios/Water Bottle.et", 16, false, 1));
				
				break;
			}
			
			case EJobType.SHOP_LOCATION:
			{
				// Shop public location de vehicules - a remplir par le boss
				// (laisse vide pour l'instant)
				break;
			}
			
			case EJobType.SHOP_COIFFURE:
			{
				// Shop public coiffeur (15-25 capsules random, tri par categorie: cheveux/perruques/barbes/moustaches/autre)
				// --- CHEVEUX ---
				items.Insert(JobShopItem.NewCat("Cheveux Femme2 Blond", "{CADB94BF7B5E40B0}Prefabs/Characters/HeadGear/Hat_TruckerCap_01/CHEVEUXFEMME.et", 21, false, 1, "Cheveux"));
				items.Insert(JobShopItem.NewCat("Cheveux Femme Blond", "{48B7D373A9109463}Prefabs/Characters/HeadGear/Hat_Knitted_01/Cheveuxblond.et", 21, false, 1, "Cheveux"));
				items.Insert(JobShopItem.NewCat("Cheveux Femme Brune", "{5E6887DE6E159932}Prefabs/Characters/HeadGear/Hat_Knitted_01/CheveuxNoir.et", 21, false, 1, "Cheveux"));
				items.Insert(JobShopItem.NewCat("Coupe 1", "{3A673F9B9A29B39E}Prefabs/Characters/Hair/Hair-1.et", 21, false, 1, "Cheveux"));
				items.Insert(JobShopItem.NewCat("Coupe 2", "{05E1D0CDFEADBE8C}Prefabs/Characters/Hair/Hair-2.et", 23, false, 1, "Cheveux"));
				items.Insert(JobShopItem.NewCat("Coupe 3", "{E07D9C34F24829E7}Prefabs/Characters/Hair/Hair-3.et", 23, false, 1, "Cheveux"));
				items.Insert(JobShopItem.NewCat("Coupe 4", "{DD49B90C8724A0D0}Prefabs/Characters/Hair/Hair-4.et", 16, false, 1, "Cheveux"));
				items.Insert(JobShopItem.NewCat("Coupe 5", "{38D5F5F58BC137BB}Prefabs/Characters/Hair/Hair-5.et", 17, false, 1, "Cheveux"));
				items.Insert(JobShopItem.NewCat("Coupe 6", "{5481C1153705B895}Prefabs/Characters/Hair/Hair-6.et", 21, false, 1, "Cheveux"));
				items.Insert(JobShopItem.NewCat("Coupe 7", "{B11D8DEC3BE02FFE}Prefabs/Characters/Hair/Hair-7.et", 18, false, 1, "Cheveux"));
				items.Insert(JobShopItem.NewCat("Coupe 8", "{2EE98B65DDDCAAFB}Prefabs/Characters/Hair/Hair-8.et", 19, false, 1, "Cheveux"));
				items.Insert(JobShopItem.NewCat("Hair Type 2", "{DD2CED8EA9F3898F}Prefabs/Characters/HeadGear/Hat_Knitted_01/Hair Type 2.et", 15, false, 1, "Cheveux"));
				items.Insert(JobShopItem.NewCat("Hair Type 3", "{ADAEE29A361FCE00}Prefabs/Characters/HeadGear/Hat_Knitted_01/Hair Type 3.et", 18, false, 1, "Cheveux"));
				items.Insert(JobShopItem.NewCat("Mohawk", "{BE19A15F1073E7BE}Prefabs/Characters/HeadGear/Hat_Knitted_01/Mohawk.et", 16, false, 1, "Cheveux"));
// --- LIFTEDS HAIR PACK (NOUVELLE VERSION) ---

// Dreads
items.Insert(JobShopItem.NewCat("Dreads Noir", "{68E288A405AE7124}Prefabs/Characters/LiftedsHairPack/Hair/DredsHair/DredsHair_Black.et", 18, false, 1, "Cheveux"));
items.Insert(JobShopItem.NewCat("Dreads Blond", "{7987EF853EDB9F91}Prefabs/Characters/LiftedsHairPack/Hair/DredsHair/DredsHair_Blonde.et", 18, false, 1, "Cheveux"));
items.Insert(JobShopItem.NewCat("Dreads Brun", "{6E44B898D5918DB2}Prefabs/Characters/LiftedsHairPack/Hair/DredsHair/DredsHair_Blrown.et", 18, false, 1, "Cheveux"));
items.Insert(JobShopItem.NewCat("Dreads Roux", "{AEC6410F5D567AC6}Prefabs/Characters/LiftedsHairPack/Hair/DredsHair/DredsHair_Ginger.et", 18, false, 1, "Cheveux"));

// Grampa
items.Insert(JobShopItem.NewCat("Grampa Noir", "{1FD81164D525826A}Prefabs/Characters/LiftedsHairPack/Hair/GrampaHair/GrampaHair_Black.et", 17, false, 1, "Cheveux"));
items.Insert(JobShopItem.NewCat("Grampa Gris", "{533A1359265791EB}Prefabs/Characters/LiftedsHairPack/Hair/GrampaHair/GrampaHair_Gray.et", 17, false, 1, "Cheveux"));

// Greeser
items.Insert(JobShopItem.NewCat("Greeser Noir", "{635F9BBEB298825F}Prefabs/Characters/LiftedsHairPack/Hair/GreeserHair/GreeserHair_Black.et", 18, false, 1, "Cheveux"));
items.Insert(JobShopItem.NewCat("Greeser Blond", "{94F94429B3E610CF}Prefabs/Characters/LiftedsHairPack/Hair/GreeserHair/GreeserHair_Blonde.et", 18, false, 1, "Cheveux"));
items.Insert(JobShopItem.NewCat("Greeser Brun", "{833A133458AC02EC}Prefabs/Characters/LiftedsHairPack/Hair/GreeserHair/GreeserHair_Brown.et", 18, false, 1, "Cheveux"));
items.Insert(JobShopItem.NewCat("Greeser Roux", "{43B8EAA3D06BF598}Prefabs/Characters/LiftedsHairPack/Hair/GreeserHair/GreeserHair_Ginger.et", 18, false, 1, "Cheveux"));

// Hair + Beard
items.Insert(JobShopItem.NewCat("Cheveux + Barbe Noir", "{7339E6857D77F84F}Prefabs/Characters/LiftedsHairPack/Hair/Hair_Beard/Hair_Beard_Black.et", 20, false, 1, "Barbes"));
items.Insert(JobShopItem.NewCat("Cheveux + Barbe Blond", "{C9D39BAEC631C620}Prefabs/Characters/LiftedsHairPack/Hair/Hair_Beard/Hair_Beard_Blonde.et", 20, false, 1, "Barbes"));
items.Insert(JobShopItem.NewCat("Cheveux + Barbe Brun", "{676245E3F1FE6501}Prefabs/Characters/LiftedsHairPack/Hair/Hair_Beard/Hair_Beard_Brown.et", 20, false, 1, "Barbes"));
items.Insert(JobShopItem.NewCat("Cheveux + Barbe Roux", "{1E923524A5BC2377}Prefabs/Characters/LiftedsHairPack/Hair/Hair_Beard/Hair_Beard_Ginger.et", 20, false, 1, "Barbes"));

// Messy
items.Insert(JobShopItem.NewCat("Coiffure Decoiffee Noir", "{8FFE391877C906BB}Prefabs/Characters/LiftedsHairPack/Hair/MessyHair/MessyHair_Black.et", 18, false, 1, "Cheveux"));
items.Insert(JobShopItem.NewCat("Coiffure Decoiffee Blond", "{CBAC2A32DA1A273A}Prefabs/Characters/LiftedsHairPack/Hair/MessyHair/MessyHair_Blonde.et", 18, false, 1, "Cheveux"));
items.Insert(JobShopItem.NewCat("Coiffure Decoiffee Brun", "{85055E87900707D3}Prefabs/Characters/LiftedsHairPack/Hair/MessyHair/MessyHair_Brown.et", 18, false, 1, "Cheveux"));
items.Insert(JobShopItem.NewCat("Coiffure Decoiffee Roux", "{1CED84B8B997C26D}Prefabs/Characters/LiftedsHairPack/Hair/MessyHair/MessyHair_Ginger.et", 18, false, 1, "Cheveux"));

// Ponytail
items.Insert(JobShopItem.NewCat("Queue de cheval Noir", "{7A26C84E69A06699}Prefabs/Characters/LiftedsHairPack/Hair/PonyTailHair/PoneyTailHair_Black.et", 19, false, 1, "Cheveux"));
items.Insert(JobShopItem.NewCat("Queue de cheval Blond", "{FFF0B1A221550B17}Prefabs/Characters/LiftedsHairPack/Hair/PonyTailHair/PoneyTailHair_Blonde.et", 19, false, 1, "Cheveux"));
items.Insert(JobShopItem.NewCat("Queue de cheval Brun", "{8CE1943161492710}Prefabs/Characters/LiftedsHairPack/Hair/PonyTailHair/PoneyTailHair_Brown.et", 19, false, 1, "Cheveux"));
items.Insert(JobShopItem.NewCat("Queue de cheval Roux", "{28B11F2842D8EE40}Prefabs/Characters/LiftedsHairPack/Hair/PonyTailHair/PoneyTailHair_Ginger.et", 19, false, 1, "Cheveux"));

// Short cut
items.Insert(JobShopItem.NewCat("Coupe courte Noir", "{B7B6267161F61DF2}Prefabs/Characters/LiftedsHairPack/Hair/ShortCutHair/ShortCutHair_Black.et", 17, false, 1, "Cheveux"));
items.Insert(JobShopItem.NewCat("Coupe courte Blond", "{890AA75671938D23}Prefabs/Characters/LiftedsHairPack/Hair/ShortCutHair/ShortCutHair_Blonde.et", 17, false, 1, "Cheveux"));
items.Insert(JobShopItem.NewCat("Coupe courte Brun", "{0AAD4667C7394563}Prefabs/Characters/LiftedsHairPack/Hair/ShortCutHair/ShortCutHair_Brown.et", 17, false, 1, "Cheveux"));
items.Insert(JobShopItem.NewCat("Coupe courte Roux", "{5E4B09DC121E6874}Prefabs/Characters/LiftedsHairPack/Hair/ShortCutHair/ShortCutHair_Ginger.et", 17, false, 1, "Cheveux"));

// Slick back
items.Insert(JobShopItem.NewCat("Slick Back Noir", "{3CFB80AB972BB25E}Prefabs/Characters/LiftedsHairPack/Hair/SlickBack/SlickBackHair_Black.et", 18, false, 1, "Cheveux"));
items.Insert(JobShopItem.NewCat("Slick Back Blond", "{52838CA0EC32DD36}Prefabs/Characters/LiftedsHairPack/Hair/SlickBack/SlickBackHair_Blonde.et", 18, false, 1, "Cheveux"));
items.Insert(JobShopItem.NewCat("Slick Back Brun", "{7153FA299219111E}Prefabs/Characters/LiftedsHairPack/Hair/SlickBack/SlickBackHair_Brown.et", 18, false, 1, "Cheveux"));
items.Insert(JobShopItem.NewCat("Slick Back Roux", "{85C2222A8FBF3861}Prefabs/Characters/LiftedsHairPack/Hair/SlickBack/SlickBackHair_Ginger.et", 18, false, 1, "Cheveux"));

// Smooth back
items.Insert(JobShopItem.NewCat("Smooth Back Noir", "{2299BBCAD55A8431}Prefabs/Characters/LiftedsHairPack/Hair/SmoothBack/SmoothBack_Hair_Black.et", 18, false, 1, "Cheveux"));
items.Insert(JobShopItem.NewCat("Smooth Back Blond", "{886A0A15E5215C9E}Prefabs/Characters/LiftedsHairPack/Hair/SmoothBack/SmoothBack_Hair_Blonde.et", 18, false, 1, "Cheveux"));
items.Insert(JobShopItem.NewCat("Smooth Back Brun", "{6FB19ABEC0C1F042}Prefabs/Characters/LiftedsHairPack/Hair/SmoothBack/SmoothBack_Hair_Brown.et", 18, false, 1, "Cheveux"));
items.Insert(JobShopItem.NewCat("Smooth Back Roux", "{5F2BA49F86ACB9C9}Prefabs/Characters/LiftedsHairPack/Hair/SmoothBack/SmoothBack_Hair_Ginger.et", 18, false, 1, "Cheveux"));

// Spike
items.Insert(JobShopItem.NewCat("Spike Noir", "{28E0BAAE90F768AC}Prefabs/Characters/LiftedsHairPack/Hair/Spike Hair/SpikeHair_Black.et", 18, false, 1, "Cheveux"));
items.Insert(JobShopItem.NewCat("Spike Blond", "{9C199BD01FE69CB9}Prefabs/Characters/LiftedsHairPack/Hair/Spike Hair/SpikeHair_Blonde.et", 18, false, 1, "Cheveux"));
items.Insert(JobShopItem.NewCat("Spike Brun", "{49A5417B68476208}Prefabs/Characters/LiftedsHairPack/Hair/Spike Hair/SpikeHair_Brown.et", 18, false, 1, "Cheveux"));
items.Insert(JobShopItem.NewCat("Spike Roux", "{4B58355A7C6B79EE}Prefabs/Characters/LiftedsHairPack/Hair/Spike Hair/SpikeHair_Ginger.et", 18, false, 1, "Cheveux"));

// Wick
items.Insert(JobShopItem.NewCat("Wick Noir", "{6D42F208682C09B7}Prefabs/Characters/LiftedsHairPack/Hair/Wick_Hair/WickHair_Black.et", 18, false, 1, "Cheveux"));
items.Insert(JobShopItem.NewCat("Wick Blond", "{CFA5BD56419B2068}Prefabs/Characters/LiftedsHairPack/Hair/Wick_Hair/WickHair_Blonde.et", 18, false, 1, "Cheveux"));
items.Insert(JobShopItem.NewCat("Wick Brun", "{F07AD61C4F6060A1}Prefabs/Characters/LiftedsHairPack/Hair/Wick_Hair/WickHair_Brown.et", 18, false, 1, "Cheveux"));
items.Insert(JobShopItem.NewCat("Wick Roux", "{18E413DC2216C53F}Prefabs/Characters/LiftedsHairPack/Hair/Wick_Hair/WickHair_Ginger.et", 18, false, 1, "Cheveux"));

				// --- PERRUQUES ---
				items.Insert(JobShopItem.NewCat("Perruque 1.2", "{CB3F3317B5E17B06}Prefabs/Characters/HeadGear/Disguise/Hair/1/Hair_1_2.et", 15, false, 1, "Perruques"));
				items.Insert(JobShopItem.NewCat("Perruque 1.3", "{2EA37FEEB904EC6D}Prefabs/Characters/HeadGear/Disguise/Hair/1/Hair_1_3.et", 16, false, 1, "Perruques"));
				items.Insert(JobShopItem.NewCat("Perruque 1.4", "{13975AD6CC68655A}Prefabs/Characters/HeadGear/Disguise/Hair/1/Hair_1_4.et", 17, false, 1, "Perruques"));
				items.Insert(JobShopItem.NewCat("Perruque 2.1", "{B9229C128CBD8920}Prefabs/Characters/HeadGear/Disguise/Hair/2/Hair_2_1.et", 23, false, 1, "Perruques"));
				items.Insert(JobShopItem.NewCat("Perruque 2.2", "{D576A8F23079060E}Prefabs/Characters/HeadGear/Disguise/Hair/2/Hair_2_2.et", 19, false, 1, "Perruques"));
				items.Insert(JobShopItem.NewCat("Perruque 2.3", "{30EAE40B3C9C9165}Prefabs/Characters/HeadGear/Disguise/Hair/2/Hair_2_3.et", 25, false, 1, "Perruques"));
				items.Insert(JobShopItem.NewCat("Perruque 2.4", "{0DDEC13349F01852}Prefabs/Characters/HeadGear/Disguise/Hair/2/Hair_2_4.et", 21, false, 1, "Perruques"));
				items.Insert(JobShopItem.NewCat("Perruque 3.1", "{72B5B5E8976C4FA9}Prefabs/Characters/HeadGear/Disguise/Hair/3/Hair_3_1.et", 24, false, 1, "Perruques"));
				items.Insert(JobShopItem.NewCat("Perruque 3.2", "{1EE181082BA8C087}Prefabs/Characters/HeadGear/Disguise/Hair/3/Hair_3_2.et", 21, false, 1, "Perruques"));
				items.Insert(JobShopItem.NewCat("Perruque 3.3", "{FB7DCDF1274D57EC}Prefabs/Characters/HeadGear/Disguise/Hair/3/Hair_3_3.et", 25, false, 1, "Perruques"));
				items.Insert(JobShopItem.NewCat("Perruque 3.4", "{C649E8C95221DEDB}Prefabs/Characters/HeadGear/Disguise/Hair/3/Hair_3_4.et", 20, false, 1, "Perruques"));
				items.Insert(JobShopItem.NewCat("Perruque 4.1", "{3B6DA0F7E5AA3BC3}Prefabs/Characters/HeadGear/Disguise/Hair/4/Hair_4_1.et", 20, false, 1, "Perruques"));
				items.Insert(JobShopItem.NewCat("Perruque 4.2", "{E9E59F393B49FC1E}Prefabs/Characters/HeadGear/Disguise/Hair/4/Hair_4_2.et", 16, false, 1, "Perruques"));
				items.Insert(JobShopItem.NewCat("Perruque 4.3", "{0C79D3C037AC6B75}Prefabs/Characters/HeadGear/Disguise/Hair/4/Hair_4_3.et", 20, false, 1, "Perruques"));
				items.Insert(JobShopItem.NewCat("Perruque 4.4", "{314DF6F842C0E242}Prefabs/Characters/HeadGear/Disguise/Hair/4/Hair_4_4.et", 19, false, 1, "Perruques"));
				// --- BARBES ---
				items.Insert(JobShopItem.NewCat("Barbe 1.1", "{D8BC09D15566C209}Prefabs/Characters/HeadGear/Disguise/Beard/1/Beard_1_1.et", 24, false, 1, "Barbes"));
				items.Insert(JobShopItem.NewCat("Barbe 1.2", "{6CA1298F035843A2}Prefabs/Characters/HeadGear/Disguise/Beard/1/Beard_1_2.et", 17, false, 1, "Barbes"));
				items.Insert(JobShopItem.NewCat("Barbe 1.3", "{893D65760FBDD4C9}Prefabs/Characters/HeadGear/Disguise/Beard/1/Beard_1_3.et", 16, false, 1, "Barbes"));
				items.Insert(JobShopItem.NewCat("Barbe 1.4", "{B409404E7AD15DFE}Prefabs/Characters/HeadGear/Disguise/Beard/1/Beard_1_4.et", 23, false, 1, "Barbes"));
				items.Insert(JobShopItem.NewCat("Barbe 2.1", "{25AA9003FF8E64AC}Prefabs/Characters/HeadGear/Disguise/Beard/2/Beard_2_1.et", 16, false, 1, "Barbes"));
				items.Insert(JobShopItem.NewCat("Barbe 2.2", "{49FEA4E3434AEB82}Prefabs/Characters/HeadGear/Disguise/Beard/2/Beard_2_2.et", 24, false, 1, "Barbes"));
				items.Insert(JobShopItem.NewCat("Barbe 2.3", "{AC62E81A4FAF7CE9}Prefabs/Characters/HeadGear/Disguise/Beard/2/Beard_2_3.et", 16, false, 1, "Barbes"));
				items.Insert(JobShopItem.NewCat("Barbe 2.4", "{9156CD223AC3F5DE}Prefabs/Characters/HeadGear/Disguise/Beard/2/Beard_2_4.et", 19, false, 1, "Barbes"));
				items.Insert(JobShopItem.NewCat("Barbe 3.1", "{F8CFB47EA726113D}Prefabs/Characters/HeadGear/Disguise/Beard/3/Beard_3_1.et", 20, false, 1, "Barbes"));
				items.Insert(JobShopItem.NewCat("Barbe 3.2", "{949B809E1BE29E13}Prefabs/Characters/HeadGear/Disguise/Beard/3/Beard_3_2.et", 16, false, 1, "Barbes"));
				items.Insert(JobShopItem.NewCat("Barbe 3.3", "{7107CC6717070978}Prefabs/Characters/HeadGear/Disguise/Beard/3/Beard_3_3.et", 25, false, 1, "Barbes"));
				items.Insert(JobShopItem.NewCat("Barbe 3.4", "{4C33E95F626B804F}Prefabs/Characters/HeadGear/Disguise/Beard/3/Beard_3_4.et", 19, false, 1, "Barbes"));
				items.Insert(JobShopItem.NewCat("Barbe 4.1", "{6F158ADB7FAB34EC}Prefabs/Characters/HeadGear/Disguise/Beard/4/Beard_4_1.et", 15, false, 1, "Barbes"));
				items.Insert(JobShopItem.NewCat("Barbe 4.2", "{0341BE3BC36FBBC2}Prefabs/Characters/HeadGear/Disguise/Beard/4/Beard_4_2.et", 20, false, 1, "Barbes"));
				items.Insert(JobShopItem.NewCat("Barbe 4.3", "{E6DDF2C2CF8A2CA9}Prefabs/Characters/HeadGear/Disguise/Beard/4/Beard_4_3.et", 21, false, 1, "Barbes"));
				items.Insert(JobShopItem.NewCat("Barbe 4.4", "{DBE9D7FABAE6A59E}Prefabs/Characters/HeadGear/Disguise/Beard/4/Beard_4_4.et", 16, false, 1, "Barbes"));
				items.Insert(JobShopItem.NewCat("Barbe 5.1", "{B270AEA62703417D}Prefabs/Characters/HeadGear/Disguise/Beard/5/Beard_5_1.et", 22, false, 1, "Barbes"));
				items.Insert(JobShopItem.NewCat("Barbe 5.2", "{DE249A469BC7CE53}Prefabs/Characters/HeadGear/Disguise/Beard/5/Beard_5_2.et", 22, false, 1, "Barbes"));
				items.Insert(JobShopItem.NewCat("Barbe 5.3", "{3BB8D6BF97225938}Prefabs/Characters/HeadGear/Disguise/Beard/5/Beard_5_3.et", 18, false, 1, "Barbes"));
				items.Insert(JobShopItem.NewCat("Barbe 5.4", "{068CF387E24ED00F}Prefabs/Characters/HeadGear/Disguise/Beard/5/Beard_5_4.et", 18, false, 1, "Barbes"));
				items.Insert(JobShopItem.NewCat("Barbe 6.1", "{972F23CA6711E95D}Prefabs/Characters/HeadGear/Disguise/Beard/6/Beard_6_1.et", 17, false, 1, "Barbes"));
				items.Insert(JobShopItem.NewCat("Barbe 6.2", "{FB7B172ADBD56673}Prefabs/Characters/HeadGear/Disguise/Beard/6/Beard_6_2.et", 19, false, 1, "Barbes"));
				items.Insert(JobShopItem.NewCat("Barbe 6.3", "{1EE75BD3D730F118}Prefabs/Characters/HeadGear/Disguise/Beard/6/Beard_6_3.et", 18, false, 1, "Barbes"));
				items.Insert(JobShopItem.NewCat("Barbe 6.4", "{23D37EEBA25C782F}Prefabs/Characters/HeadGear/Disguise/Beard/6/Beard_6_4.et", 15, false, 1, "Barbes"));
				items.Insert(JobShopItem.NewCat("Barbe 7.1", "{4A4A07B73FB99CCC}Prefabs/Characters/HeadGear/Disguise/Beard/7/Beard_7_1.et", 15, false, 1, "Barbes"));
				items.Insert(JobShopItem.NewCat("Barbe 7.2", "{261E3357837D13E2}Prefabs/Characters/HeadGear/Disguise/Beard/7/Beard_7_2.et", 25, false, 1, "Barbes"));
				items.Insert(JobShopItem.NewCat("Barbe 7.3", "{C3827FAE8F988489}Prefabs/Characters/HeadGear/Disguise/Beard/7/Beard_7_3.et", 25, false, 1, "Barbes"));
				items.Insert(JobShopItem.NewCat("Barbe 7.4", "{FEB65A96FAF40DBE}Prefabs/Characters/HeadGear/Disguise/Beard/7/Beard_7_4.et", 21, false, 1, "Barbes"));
				items.Insert(JobShopItem.NewCat("Barbe 8.1", "{FA6BBF6A7FE1946C}Prefabs/Characters/HeadGear/Disguise/Beard/8/Beard_8_1.et", 15, false, 1, "Barbes"));
				items.Insert(JobShopItem.NewCat("Barbe 8.2", "{963F8B8AC3251B42}Prefabs/Characters/HeadGear/Disguise/Beard/8/Beard_8_2.et", 25, false, 1, "Barbes"));
				items.Insert(JobShopItem.NewCat("Barbe 8.3", "{73A3C773CFC08C29}Prefabs/Characters/HeadGear/Disguise/Beard/8/Beard_8_3.et", 20, false, 1, "Barbes"));
				items.Insert(JobShopItem.NewCat("Barbe 8.4", "{4E97E24BBAAC051E}Prefabs/Characters/HeadGear/Disguise/Beard/8/Beard_8_4.et", 20, false, 1, "Barbes"));
				items.Insert(JobShopItem.NewCat("Barbe 9.1", "{D306DC8F2A948989}Prefabs/Characters/HeadGear/Disguise/Beard/9/Beard_9_1.et", 22, false, 1, "Barbes"));
				items.Insert(JobShopItem.NewCat("Barbe 9.2", "{BF52E86F965006A7}Prefabs/Characters/HeadGear/Disguise/Beard/9/Beard_9_2.et", 25, false, 1, "Barbes"));
				items.Insert(JobShopItem.NewCat("Barbe 9.3", "{5ACEA4969AB591CC}Prefabs/Characters/HeadGear/Disguise/Beard/9/Beard_9_3.et", 22, false, 1, "Barbes"));
				items.Insert(JobShopItem.NewCat("Barbe 9.4", "{67FA81AEEFD918FB}Prefabs/Characters/HeadGear/Disguise/Beard/9/Beard_9_4.et", 24, false, 1, "Barbes"));
				// --- MOUSTACHES ---
				items.Insert(JobShopItem.NewCat("Moustache 1.1", "{BB4F4666CAD1FE57}Prefabs/Characters/HeadGear/Disguise/Mustache/1/Mustache_1_1.et", 23, false, 1, "Moustaches"));
				items.Insert(JobShopItem.NewCat("Moustache 1.2", "{D71B728676157179}Prefabs/Characters/HeadGear/Disguise/Mustache/1/Mustache_1_2.et", 17, false, 1, "Moustaches"));
				items.Insert(JobShopItem.NewCat("Moustache 1.3", "{32873E7F7AF0E612}Prefabs/Characters/HeadGear/Disguise/Mustache/1/Mustache_1_3.et", 18, false, 1, "Moustaches"));
				items.Insert(JobShopItem.NewCat("Moustache 1.4", "{0FB31B470F9C6F25}Prefabs/Characters/HeadGear/Disguise/Mustache/1/Mustache_1_4.et", 22, false, 1, "Moustaches"));
				items.Insert(JobShopItem.NewCat("Moustache 2.1", "{366C26CD03A5EC4A}Prefabs/Characters/HeadGear/Disguise/Mustache/2/Mustache_2_1.et", 22, false, 1, "Moustaches"));
				items.Insert(JobShopItem.NewCat("Moustache 2.2", "{5A38122DBF616364}Prefabs/Characters/HeadGear/Disguise/Mustache/2/Mustache_2_2.et", 25, false, 1, "Moustaches"));
				items.Insert(JobShopItem.NewCat("Moustache 2.3", "{BFA45ED4B384F40F}Prefabs/Characters/HeadGear/Disguise/Mustache/2/Mustache_2_3.et", 20, false, 1, "Moustaches"));
				items.Insert(JobShopItem.NewCat("Moustache 2.4", "{82907BECC6E87D38}Prefabs/Characters/HeadGear/Disguise/Mustache/2/Mustache_2_4.et", 24, false, 1, "Moustaches"));
				items.Insert(JobShopItem.NewCat("Moustache 3.1", "{8CDD59F2DC2FF030}Prefabs/Characters/HeadGear/Disguise/Mustache/3/Mustache_3_1.et", 15, false, 1, "Moustaches"));
				items.Insert(JobShopItem.NewCat("Moustache 3.2", "{E0896D1260EB7F1E}Prefabs/Characters/HeadGear/Disguise/Mustache/3/Mustache_3_2.et", 19, false, 1, "Moustaches"));
				items.Insert(JobShopItem.NewCat("Moustache 3.3", "{051521EB6C0EE875}Prefabs/Characters/HeadGear/Disguise/Mustache/3/Mustache_3_3.et", 17, false, 1, "Moustaches"));
				items.Insert(JobShopItem.NewCat("Moustache 3.4", "{382104D319626142}Prefabs/Characters/HeadGear/Disguise/Mustache/3/Mustache_3_4.et", 15, false, 1, "Moustaches"));
				// --- AUTRE ---
				items.Insert(JobShopItem.NewCat("Glue barbes-coiffures", "{C2E6B26D971C2E43}Prefabs/Characters/HeadGear/Disguise/Head_base.et", 18, false, 1, "Autre"));
				break;
			}
			
			case EJobType.SHOP_DROGERIE:
			{
				// Shop public Drogerie - prix fixes
				items.Insert(new JobShopItem("Cigarette en bouche", "{28E9A160CC0727F0}Prefabs/Characters/Extra 2/Cig in Mouth.et", 10, false, 1));
				items.Insert(new JobShopItem("Pipe en bouche", "{ABBDC560BB0BD2C7}Prefabs/Characters/Extra 2/Pipe in Mouth.et", 25, false, 1));
				items.Insert(new JobShopItem("iPhone 15", "{F01C74E1B289DFF2}Prefabs/Items/InventoryItems/Electronics/Iphone15.et", 300, false, 1));
				items.Insert(new JobShopItem("Lampe de poche MX991", "{3A421547BC29F679}Prefabs/Items/Equipment/Flashlights/Flashlight_MX991/Flashlight_MX991.et", 20, false, 1));
				items.Insert(new JobShopItem("Lampe de poche Sovietique", "{575EA58E67448C2A}Prefabs/Items/Equipment/Flashlights/Flashlight_Soviet_01/Flashlight_Soviet_01.et", 15, false, 1));
				// --- OUTILS ---
				items.Insert(new JobShopItem("Pioche", "{CFB03731B536D8A4}Prefabs/Items/Equipment/Accessories/ETool_ALICE/Pick2.et", 150, false, 1));
				items.Insert(new JobShopItem("Hache", "{10066BA2DCD677D3}Prefabs/Items/Equipment/Accessories/ETool_ALICE/Hache.et", 150, false, 1));
				// === Nouveaux items drogerie (ajout boss) ===
				items.Insert(new JobShopItem("Cigare", "{E513AC48A65855AA}Prefabs/Items/Smokeables/Smokeable_Cigar.et", 18, false, 1));
				items.Insert(new JobShopItem("Cigarette", "{494F9EF9C6700796}Prefabs/Items/Smokeables/Smokeable_Cigarette.et", 10, false, 1));
				items.Insert(new JobShopItem("Pipe", "{2FFE53CDF0E55D3A}Prefabs/Items/Smokeables/Smokeable_Pipe.et", 25, false, 1));
				
break;
			}
			
						case EJobType.SHOP_BIJOUTERIE:
			{
				// Shop public Bijouterie : 9 chaines en or et bracelets
				// Prix raisonnables (bijoux de luxe). Prefabs alignes avec les chaines fondables.
				items.Insert(new JobShopItem("Chaine Gold Cordao", "{4BD92C5231A3940D}Prefabs/Cordao/GoldChain2.et", 10000, false, 1));
				items.Insert(new JobShopItem("Chaine simple", "{E25E88CA0B28A408}Prefabs/Clothing/Chain.et", 9000, false, 1));
				items.Insert(new JobShopItem("Scapulaire BME", "{1CD36D3E3CDA7ADB}Prefabs/Clothing/BME_Scapulario.et", 11000, false, 1));
				items.Insert(new JobShopItem("Chaine Chucky", "{B660612952B6B5D8}Prefabs/Clothing/Chucky_Chain.et", 12000, false, 1));
				items.Insert(new JobShopItem("Croix Cubaine", "{61E261CDE10A07BD}Prefabs/Clothing/Cuban_Cross_Chain.et", 11500, false, 1));
				items.Insert(new JobShopItem("Chaine Demon Time", "{C95ADA51AB7B9644}Prefabs/Clothing/Demon_Time_Chain.et", 12000, false, 1));
				items.Insert(new JobShopItem("Chaine Jesus", "{D2DAF01768448970}Prefabs/Clothing/Jesus_Chain.et", 11500, false, 1));
				items.Insert(new JobShopItem("Trap Queen", "{11C09AB21D527236}Prefabs/Clothing/Trap_Queen.et", 9500, false, 1));
				items.Insert(new JobShopItem("Bracelet en or", "{20DC0843CA50A484}Prefabs/Bracelet/GoldBraceletLeft.et", 8500, false, 1));
				break;
			}
			case EJobType.SHOP_VOYOU_CAC:
			{
				// Marche noir - Armes de corps a corps (paye en lingots d or)
				// A REMPLIR PAR LE BOSS : ajoute tes items avec JobShopItem.MakeGold(nom, prefab, prix_lingots, false, qty)
				// Exemple :
				// items.Insert(JobShopItem.MakeGold("Couteau de combat", "{XXX}Prefabs/.../Knife.et", 3, false, 1));
				// items.Insert(JobShopItem.MakeGold("Machette", "{XXX}Prefabs/.../Machete.et", 5, false, 1));

				break;
			}
			
			case EJobType.SHOP_VOYOU_POINT:
			{
				// Marche noir - Armes de point / pistolets (paye en lingots d or)
				// A REMPLIR PAR LE BOSS
				// Exemple :
				// items.Insert(JobShopItem.MakeGold("Glock 18C", "{XXX}Prefabs/.../Glock18C.et", 10, false, 1));
				// items.Insert(JobShopItem.MakeGold("Magnum 357", "{XXX}Prefabs/.../Magnum357.et", 15, false, 1));
				items.Insert(new JobShopItem("Pistolet M9", "{1353C6EAD1DCFE43}Prefabs/Weapons/Handguns/M9/Handgun_M9.et", 20000, false, 1));
				items.Insert(new JobShopItem("Chargeur M9 9x19 (8 balles)", "{9C05543A503DB80E}Prefabs/Weapons/Magazines/Magazine_9x19_M9_15rnd_Ball.et", 5000, false, 1));
				break;
			}
			
			case EJobType.SHOP_VOYOU_FUSIL:
			{
				// Marche noir - Fusils (paye en lingots d or)
				// A REMPLIR PAR LE BOSS {0A84AA5A3884176F}Prefabs/Weapons/Magazines/Magazine_545x39_AK_30rnd_Last_5Tracer.et
				// Exemple :
				items.Insert(JobShopItem.MakeGold("Double Barrel 610mm", "{3D3758C525994D3A}Prefabs/Weapons/Shotguns/Double Barrel/BC_Shotgun_Double_Barrel_610mm.et", 40, false, 1));
				items.Insert(JobShopItem.MakeGold("Double Barrel 760mm", "{3C4FB3D9D54B46DF}Prefabs/Weapons/Shotguns/Double Barrel/BC_Shotgun_Double_Barrel_760mm.et", 40, false, 1));
				items.Insert(JobShopItem.MakeGold("Double Barrel Sawn Off", "{E7A3BA1F06C057FF}Prefabs/Weapons/Shotguns/Double Barrel/BC_Shotgun_Double_Barrel_Sawn_Off.et", 40, false, 1));
				items.Insert(JobShopItem.MakeGold("Ithaca 37", "{9655CB851205DF47}Prefabs/Weapons/Shotguns/Ithaca 37/BC_Shotgun_Ithaca_37.et", 70, false, 1));
				items.Insert(JobShopItem.MakeGold("Ithaca 37 Sawed", "{34B2434D37E3FF16}Prefabs/Weapons/Shotguns/Ithaca 37/BC_Shotgun_Ithaca_37_Sawed.et", 70, false, 1));
				items.Insert(JobShopItem.MakeGold("Buckshot 12ga", "{B0DFDF7AAA9C5D39}Prefabs/Weapons/Magazines/BC_Shell_12ga_Buckshot.et", 3, false, 1));
				break;
			}
			
			case EJobType.SHOP_VOYOU_MITRAILLETTE:
			{
				// Marche noir - Mitraillettes (paye en lingots d or)
				// A REMPLIR PAR LE BOSS
				// Exemple :
				items.Insert(JobShopItem.MakeGold("Chargeur AKS74U", "{0A84AA5A3884176F}Prefabs/Weapons/Magazines/Magazine_545x39_AK_30rnd_Last_5Tracer.et", 7, false, 1));
				items.Insert(JobShopItem.MakeGold("AKS74U Or", "{A9F072E6A79A9E8A}Prefabs/Weapons/Rifles/AKS74U/Rifle_AKS74U_Gold.et", 60, false, 1));
				items.Insert(JobShopItem.MakeGold("Mac 10", "{DC56CD2774334B52}Prefabs/Weapons/Handguns/M9/mac 10 2.et", 40, false, 1));
				items.Insert(JobShopItem.MakeGold("Mac 10 Chargeur", "{B238255016DA2576}Prefabs/Weapons/Magazines/mag10 2.et", 5, false, 1));
				break;
			}

			case EJobType.VENDEUR_VETEMENTS:
			{
				// ========================================================================
				// Boutique Vendeur de Vetements RP (metier prive, acces reserve via
				// LP_VendeurVetementsShopAction).
				// Vestes KZS : 50 capsules | Pantalons KZS : 45 capsules
				// 6 categories : Vestes Gang / Militaire / Style, Pantalons Gang / Militaire / Style
				// ========================================================================

				// --- VESTES - GANG (4 vestes - gang colors) ---
				items.Insert(JobShopItem.NewCat("Veste Gang Bleu",
					"{7A65BBEB96261BD0}Prefabs/Characters/Uniforms/Jacket_KZS/JACKET_GANGBLEU.et",
					50, false, 1, "Vestes Gang"));
				items.Insert(JobShopItem.NewCat("Veste Gang Original",
					"{4D6E42719C22EB29}Prefabs/Characters/Uniforms/Jacket_KZS/JACKET_GANGORIGINAL.et",
					50, false, 1, "Vestes Gang"));
				items.Insert(JobShopItem.NewCat("Veste Gang Rouge",
					"{F298D13BB23DE00D}Prefabs/Characters/Uniforms/Jacket_KZS/JACKET_GANGROUGE.et",
					50, false, 1, "Vestes Gang"));
				items.Insert(JobShopItem.NewCat("Veste Gang Vert",
					"{C36D3DCFBD99B888}Prefabs/Characters/Uniforms/Jacket_KZS/JACKET_GANGVERT.et",
					50, false, 1, "Vestes Gang"));

				// --- VESTES - MILITAIRE (4 vestes - style militaire/tactique) ---
				items.Insert(JobShopItem.NewCat("Veste AK1",
					"{EDAB5B3FA798F16B}Prefabs/Characters/Uniforms/Jacket_KZS/JACKET_AK1.et",
					50, false, 1, "Vestes Militaire"));
				items.Insert(JobShopItem.NewCat("Veste AK2",
					"{81FF6FDF1B5C7E45}Prefabs/Characters/Uniforms/Jacket_KZS/JACKET_AK2.et",
					50, false, 1, "Vestes Militaire"));
				items.Insert(JobShopItem.NewCat("Veste Aquatique",
					"{B9A5648C3F3E3C0F}Prefabs/Characters/Uniforms/Jacket_KZS/JACKET_AQUATIQUE.et",
					50, false, 1, "Vestes Militaire"));
				items.Insert(JobShopItem.NewCat("Veste Terminator",
					"{1EA1694AE3398B31}Prefabs/Characters/Uniforms/Jacket_KZS/JACKET_TERMINATOR.et",
					50, false, 1, "Vestes Militaire"));

				// --- VESTES - STYLE (15 vestes - thematique urbaine / mafia / film) ---
				items.Insert(JobShopItem.NewCat("Veste Noire",
					"{42104D6EA4A41C9E}Prefabs/Characters/Uniforms/Jacket_KZS/JACKET_NOIR.et",
					50, false, 1, "Vestes Style"));
				items.Insert(JobShopItem.NewCat("Veste ProjetX",
					"{8D4CBA340E13FF5F}Prefabs/Characters/Uniforms/Jacket_KZS/Jacket_PROJETX.et",
					50, false, 1, "Vestes Style"));
				items.Insert(JobShopItem.NewCat("Veste Graffiti",
					"{D8BA5643121CA3EB}Prefabs/Characters/Uniforms/Jacket_KZS/JACKET_GRAFFITI.et",
					50, false, 1, "Vestes Style"));
				items.Insert(JobShopItem.NewCat("Veste Scotch",
					"{CFCA5F089F26BCEE}Prefabs/Characters/Uniforms/Jacket_KZS/JACKET_SCOTCH.et",
					50, false, 1, "Vestes Style"));
				items.Insert(JobShopItem.NewCat("Veste Sang",
					"{2F2E1413071F79BD}Prefabs/Characters/Uniforms/Jacket_KZS/JACKET_SANG.et",
					50, false, 1, "Vestes Style"));
				items.Insert(JobShopItem.NewCat("Veste Tete de Mort",
					"{B88A29119D500CBB}Prefabs/Characters/Uniforms/Jacket_KZS/JACKET_TETEDEMORT.et",
					50, false, 1, "Vestes Style"));
				items.Insert(JobShopItem.NewCat("Veste Punisher",
					"{F022EF957A0DE990}Prefabs/Characters/Uniforms/Jacket_KZS/JACKET_PUNISHER.et",
					50, false, 1, "Vestes Style"));
				items.Insert(JobShopItem.NewCat("Veste San Andreas",
					"{10635A7CE5BFECA9}Prefabs/Characters/Uniforms/Jacket_KZS/JACKET_SANADREAS.et",
					50, false, 1, "Vestes Style"));
				items.Insert(JobShopItem.NewCat("Veste Mecanique",
					"{06DF5338E26E8CF3}Prefabs/Characters/Uniforms/Jacket_KZS/JACKET_MECANIQUE.et",
					50, false, 1, "Vestes Style"));
				items.Insert(JobShopItem.NewCat("Veste Mafieu",
					"{BAFD8044479CB344}Prefabs/Characters/Uniforms/Jacket_KZS/JACKET_MAFIEU.et",
					50, false, 1, "Vestes Style"));
				items.Insert(JobShopItem.NewCat("Veste Sombra",
					"{63DD3F606E4D6EEA}Prefabs/Characters/Uniforms/Jacket_KZS/JACKET_SOMBRA.et",
					50, false, 1, "Vestes Style"));
				items.Insert(JobShopItem.NewCat("Veste Sultan",
					"{BA6C8D452CE3E6B4}Prefabs/Characters/Uniforms/Jacket_KZS/JACKET_SULTAN.et",
					50, false, 1, "Vestes Style"));
				items.Insert(JobShopItem.NewCat("Veste Latino",
					"{1FD9028146DED7FD}Prefabs/Characters/Uniforms/Jacket_KZS/JACKET_LATINO.et",
					50, false, 1, "Vestes Style"));
				items.Insert(JobShopItem.NewCat("Veste India Bleu",
					"{C869D2AB7F0AAA0F}Prefabs/Characters/Uniforms/Jacket_KZS/JACKET_INDIABLEU.et",
					50, false, 1, "Vestes Style"));
				items.Insert(JobShopItem.NewCat("Veste India Noir",
					"{60BBBA5549E0C84D}Prefabs/Characters/Uniforms/Jacket_KZS/JACKET_INDIANOIR.et",
					50, false, 1, "Vestes Style"));
				items.Insert(JobShopItem.NewCat("Veste Cocoste",
					"{F223BA64C87F4840}Prefabs/Characters/Uniforms/Jacket_KZS/JACKET_COCOSTE.et",
					50, false, 1, "Vestes Style"));
				items.Insert(JobShopItem.NewCat("Veste Cocoste Noire",
					"{137A457D8FCBD518}Prefabs/Characters/Uniforms/Jacket_KZS/JACKET_COCOSTE_NOIR.et",
					50, false, 1, "Vestes Style"));
				items.Insert(JobShopItem.NewCat("Veste Gucci",
					"{6C63C13FED634E2C}Prefabs/Characters/Uniforms/Jacket_KZS/JACKET_gucci.et",
					50, false, 1, "Vestes Style"));
				items.Insert(JobShopItem.NewCat("Veste Gucci",
					"{0DFD569316BB55EE}Prefabs/Characters/Uniforms/Jacket_KZS/JACKET_guccioriginal.et",
					50, false, 1, "Vestes Style"));
				items.Insert(JobShopItem.NewCat("Veste Dior",
					"{B0D26C9DFDF97C21}Prefabs/Characters/Uniforms/Jacket_KZS/JACKET_dior.et",
					50, false, 1, "Vestes Style"));




				// --- PANTALONS - GANG (5 pantalons - gang colors) ---
				items.Insert(JobShopItem.NewCat("Pantalon Gang Bleu",
					"{10FFD7404A48F5ED}Prefabs/Characters/Uniforms/Pants_KZS/ET/PANT_GANGBLEU.et",
					45, false, 1, "Pantalons Gang"));
				items.Insert(JobShopItem.NewCat("Pantalon Gang Jaune",
					"{1BC199B1321AB43A}Prefabs/Characters/Uniforms/Pants_KZS/ET/PANT_GANGJAUNE.et",
					45, false, 1, "Pantalons Gang"));
				items.Insert(JobShopItem.NewCat("Pantalon Gang Original",
					"{2B3D0DF7C417D2EB}Prefabs/Characters/Uniforms/Pants_KZS/ET/PANT_GANGORIGINAL.et",
					45, false, 1, "Pantalons Gang"));
				items.Insert(JobShopItem.NewCat("Pantalon Gang Rouge",
					"{690C8650582D4364}Prefabs/Characters/Uniforms/Pants_KZS/ET/PANT_GANGROUGE.et",
					45, false, 1, "Pantalons Gang"));
				items.Insert(JobShopItem.NewCat("Pantalon Gang Vert",
					"{A9F7516461F756B5}Prefabs/Characters/Uniforms/Pants_KZS/ET/PANT_GANGVERT.et",
					45, false, 1, "Pantalons Gang"));

				// --- PANTALONS - MILITAIRE (4 pantalons - style militaire/tactique) ---
				items.Insert(JobShopItem.NewCat("Pantalon AK1",
					"{20A9C2EB9C753D6C}Prefabs/Characters/Uniforms/Pants_KZS/ET/PANT_AK1.et",
					45, false, 1, "Pantalons Militaire"));
				items.Insert(JobShopItem.NewCat("Pantalon AK2",
					"{4CFDF60B20B1B242}Prefabs/Characters/Uniforms/Pants_KZS/ET/PANT_AK2.et",
					45, false, 1, "Pantalons Militaire"));
				items.Insert(JobShopItem.NewCat("Pantalon Aquatique",
					"{223133E7D52E9F66}Prefabs/Characters/Uniforms/Pants_KZS/ET/PANT_AQUATIQUE.et",
					45, false, 1, "Pantalons Militaire"));
				items.Insert(JobShopItem.NewCat("Pantalon Terminator",
					"{4F467129F8F29118}Prefabs/Characters/Uniforms/Pants_KZS/ET/PANT_TERMINATOR.et",
					45, false, 1, "Pantalons Militaire"));

				// --- PANTALONS - STYLE (12 pantalons - thematique urbaine / mafia / film) ---
				items.Insert(JobShopItem.NewCat("Pantalon Noir",
					"{F5D335A4651B4D8E}Prefabs/Characters/Uniforms/Pants_KZS/ET/PANT_NOIR.et",
					45, false, 1, "Pantalons Style"));
				items.Insert(JobShopItem.NewCat("Pantalon Graffiti",
					"{B2203AE8CE724DD6}Prefabs/Characters/Uniforms/Pants_KZS/ET/PANT_GRAFFITI.et",
					45, false, 1, "Pantalons Style"));
				items.Insert(JobShopItem.NewCat("Pantalon Scotch",
					"{0CE5BE9B9B709992}Prefabs/Characters/Uniforms/Pants_KZS/ET/PANT_SCOTCH.et",
					45, false, 1, "Pantalons Style"));
				items.Insert(JobShopItem.NewCat("Pantalon Tete de Mort",
					"{E96D3172869B1692}Prefabs/Characters/Uniforms/Pants_KZS/ET/PANT_TETEDEMORT.et",
					45, false, 1, "Pantalons Style"));
				items.Insert(JobShopItem.NewCat("Pantalon San Andreas",
					"{8BF70D170FAF4FC0}Prefabs/Characters/Uniforms/Pants_KZS/ET/PANT_SANADREAS.et",
					45, false, 1, "Pantalons Style"));
				items.Insert(JobShopItem.NewCat("Pantalon Mecanique",
					"{9D4B0453087E2F9A}Prefabs/Characters/Uniforms/Pants_KZS/ET/PANT_MECANIQUE.et",
					45, false, 1, "Pantalons Style"));
				items.Insert(JobShopItem.NewCat("Pantalon Mafieux",
					"{5C27A92A8AF1A273}Prefabs/Characters/Uniforms/Pants_KZS/ET/PANT_MAFIEUX.et",
					45, false, 1, "Pantalons Style"));
				items.Insert(JobShopItem.NewCat("Pantalon Sombra",
					"{A0F2DEF36A1B4B96}Prefabs/Characters/Uniforms/Pants_KZS/ET/PANT_SOMBRA.et",
					45, false, 1, "Pantalons Style"));
				items.Insert(JobShopItem.NewCat("Pantalon Sultan",
					"{3FA3723AA08A9273}Prefabs/Characters/Uniforms/Pants_KZS/ET/PANT_SULTAN.et",
					45, false, 1, "Pantalons Style"));
				items.Insert(JobShopItem.NewCat("Pantalon Latino",
					"{DCF6E3124288F281}Prefabs/Characters/Uniforms/Pants_KZS/ET/PANT_LATINO.et",
					45, false, 1, "Pantalons Style"));
				items.Insert(JobShopItem.NewCat("Pantalon India Bleu",
					"{53FD85C0951A0966}Prefabs/Characters/Uniforms/Pants_KZS/ET/PANT_INDIABLEU.et",
					45, false, 1, "Pantalons Style"));
				items.Insert(JobShopItem.NewCat("Pantalon India Noir",
					"{FB2FED3EA3F06B24}Prefabs/Characters/Uniforms/Pants_KZS/ET/PANT_INDIANOIR.et",
					45, false, 1, "Pantalons Style"));
				items.Insert(JobShopItem.NewCat("Pantalon Cocoste",
					"{FAFCAC17AFCDD93F}Prefabs/Characters/Uniforms/Pants_KZS/ET/PANT_cocoste.et",
					45, false, 1, "Pantalons Style"));
				items.Insert(JobShopItem.NewCat("Pantalon Cocoste Noir",
					"{0A696F8CE9F15A72}Prefabs/Characters/Uniforms/Pants_KZS/ET/PANT_COCOSTE_NOIR.et",
					45, false, 1, "Pantalons Style"));
				items.Insert(JobShopItem.NewCat("Pantalon Gucci",
					"{674A15196C2CDB95}Prefabs/Characters/Uniforms/Pants_KZS/ET/PANT_GUCCI.et",
					45, false, 1, "Pantalons Style"));
				items.Insert(JobShopItem.NewCat("Pantalon Gucci",
					"{A87CF26B09BA552C}Prefabs/Characters/Uniforms/Pants_KZS/ET/PANT_guccioriginal.et",
					45, false, 1, "Pantalons Style"));
				items.Insert(JobShopItem.NewCat("Pantalon Dior",
					"{47D1DF6377AA33D8}Prefabs/Characters/Uniforms/Pants_KZS/ET/PANT_dior.et",
					45, false, 1, "Pantalons Style"));

				// --- CASQUETTES ---
				items.Insert(JobShopItem.NewCat("Casquette Dior",
					"{9AB600F97F2F39D7}Prefabs/Characters/HeadGear/Hat_TruckerCap_01/casquetteprojetx_DIOR.et",
					40, false, 1, "Casquettes"));
				items.Insert(JobShopItem.NewCat("Casquette Dior Classique",
					"{2271188E3E5B6A5E}Prefabs/Characters/HeadGear/Hat_TruckerCap_01/casquette_DIOR.et",
					40, false, 1, "Casquettes"));
				items.Insert(JobShopItem.NewCat("Casquette Gucci Original",
					"{B3A1B1564DF63D80}Prefabs/Characters/HeadGear/Hat_TruckerCap_01/casquette_GUCCIORIGINAL.et",
					40, false, 1, "Casquettes"));
				items.Insert(JobShopItem.NewCat("Casquette Gucci Noir",
					"{AB21D95AC8DA11DA}Prefabs/Characters/HeadGear/Hat_TruckerCap_01/casquette_GUCCIORINOIR.et",
					40, false, 1, "Casquettes"));


				// ============================================================
				// --- SACS A DOS (27 items a 70 capsules) ---
				// ============================================================
				items.Insert(JobShopItem.NewCat("Sac 9MM",
					"{6EB1D8D49F1B125B}Prefabs/Items/Equipment/Backpacks/sac_9MM.et",
					4000, false, 1, "Sacs a Dos"));
				items.Insert(JobShopItem.NewCat("Sac ADIX",
					"{718CC291203891CC}Prefabs/Items/Equipment/Backpacks/sac_ADIX.et",
					4000, false, 1, "Sacs a Dos"));
				items.Insert(JobShopItem.NewCat("Sac Algeri",
					"{F92EF784F5FF051A}Prefabs/Items/Equipment/Backpacks/sac_algeri.et",
					4000, false, 1, "Sacs a Dos"));
				items.Insert(JobShopItem.NewCat("Sac Cartel",
					"{8F300883839E46AB}Prefabs/Items/Equipment/Backpacks/sac_cartel.et",
					4000, false, 1, "Sacs a Dos"));
				items.Insert(JobShopItem.NewCat("Sac Cartel 2",
					"{6DC3F80E8D8E3680}Prefabs/Items/Equipment/Backpacks/sac_cartel2.et",
					4000, false, 1, "Sacs a Dos"));
				items.Insert(JobShopItem.NewCat("Sac Escobar",
					"{6D3D22DB3BD35202}Prefabs/Items/Equipment/Backpacks/sac_escobar.et",
					4000, false, 1, "Sacs a Dos"));
				items.Insert(JobShopItem.NewCat("Sac Bronx",
					"{02B62C336BB6F8A1}Prefabs/Items/Equipment/Backpacks/sac_bronx.et",
					4000, false, 1, "Sacs a Dos"));
				items.Insert(JobShopItem.NewCat("Sac Favelas",
					"{8D0159B2F1CAD3A6}Prefabs/Items/Equipment/Backpacks/sac_favelas.et",
					4000, false, 1, "Sacs a Dos"));
				items.Insert(JobShopItem.NewCat("Sac Girl",
					"{E756C533AC666938}Prefabs/Items/Equipment/Backpacks/sac_girl.et",
					4000, false, 1, "Sacs a Dos"));
				items.Insert(JobShopItem.NewCat("Sac Mexico",
					"{F5B833392B267CDC}Prefabs/Items/Equipment/Backpacks/sac_mexico.et",
					4000, false, 1, "Sacs a Dos"));
				items.Insert(JobShopItem.NewCat("Sac NICE",
					"{1CFEBFE57B5187EE}Prefabs/Items/Equipment/Backpacks/sac_NICE.et",
					4000, false, 1, "Sacs a Dos"));
				items.Insert(JobShopItem.NewCat("Sac Gold",
					"{094D8C5133724CF8}Prefabs/Items/Equipment/Backpacks/sac_gold.et",
					4000, false, 1, "Sacs a Dos"));
				items.Insert(JobShopItem.NewCat("Sac Montagne",
					"{2562973D8F0231F5}Prefabs/Items/Equipment/Backpacks/sac_montagne.et",
					4000, false, 1, "Sacs a Dos"));
				items.Insert(JobShopItem.NewCat("Sac Noir",
					"{4940FC5E59B2486B}Prefabs/Items/Equipment/Backpacks/sac_noir.et",
					4000, false, 1, "Sacs a Dos"));
				items.Insert(JobShopItem.NewCat("Sac Bucheron",
					"{1E324A32399911FE}Prefabs/Items/Equipment/Backpacks/sac_bucheron.et",
					4000, false, 1, "Sacs a Dos"));
				items.Insert(JobShopItem.NewCat("Sac Criminel",
					"{5FC98EB1EC323BF8}Prefabs/Items/Equipment/Backpacks/sac_criminel.et",
					4000, false, 1, "Sacs a Dos"));
				items.Insert(JobShopItem.NewCat("Sac France",
					"{452C2F6C7067CFCD}Prefabs/Items/Equipment/Backpacks/sac_france.et",
					4000, false, 1, "Sacs a Dos"));
				items.Insert(JobShopItem.NewCat("Sac Cannabis",
					"{E5B98626E4948C87}Prefabs/Items/Equipment/Backpacks/sac_canabis.et",
					4000, false, 1, "Sacs a Dos"));
				items.Insert(JobShopItem.NewCat("Sac DZ",
					"{99F29B0B6EAB9EF0}Prefabs/Items/Equipment/Backpacks/sac_DZ.et",
					4000, false, 1, "Sacs a Dos"));
				items.Insert(JobShopItem.NewCat("Sac Gangster",
					"{0869A7A0E9348AA6}Prefabs/Items/Equipment/Backpacks/sac_gangster.et",
					4000, false, 1, "Sacs a Dos"));
				items.Insert(JobShopItem.NewCat("Sac Mafieux",
					"{C5E498B8B71FF715}Prefabs/Items/Equipment/Backpacks/sac_mafieux.et",
					4000, false, 1, "Sacs a Dos"));
				items.Insert(JobShopItem.NewCat("Sac Montana",
					"{460F4AD18CC98451}Prefabs/Items/Equipment/Backpacks/sac_montana.et",
					4000, false, 1, "Sacs a Dos"));
				items.Insert(JobShopItem.NewCat("Sac Punisher",
					"{ADEA6CA16D3EAA22}Prefabs/Items/Equipment/Backpacks/sac_punisher.et",
					4000, false, 1, "Sacs a Dos"));
				items.Insert(JobShopItem.NewCat("Sac Mecanique",
					"{EBC156E1108D99C1}Prefabs/Items/Equipment/Backpacks/sac_mecanique.et",
					4000, false, 1, "Sacs a Dos"));
				items.Insert(JobShopItem.NewCat("Sac MS13",
					"{908B64C484F82B05}Prefabs/Items/Equipment/Backpacks/sac_MS13.et",
					4000, false, 1, "Sacs a Dos"));
				items.Insert(JobShopItem.NewCat("Sac Rayon X",
					"{B18E4E3188CED779}Prefabs/Items/Equipment/Backpacks/sac_rayonX.et",
					4000, false, 1, "Sacs a Dos"));
				items.Insert(JobShopItem.NewCat("Sac Squelette",
					"{957E0E35746F0FFC}Prefabs/Items/Equipment/Backpacks/sac_squelette.et",
					4000, false, 1, "Sacs a Dos"));
				items.Insert(JobShopItem.NewCat("Sac Dior",
					"{F8FEF84B115DA25A}Prefabs/Items/Equipment/Backpacks/SAC_DIOR.et",
					4000, false, 1, "Sacs a Dos"));
				items.Insert(JobShopItem.NewCat("Sac Gucci Noir",
					"{09C96E3F76F1CC08}Prefabs/Items/Equipment/Backpacks/SAC_GUCCINOIR.et",
					4000, false, 1, "Sacs a Dos"));
				items.Insert(JobShopItem.NewCat("Sac Gucci Original",
					"{4940FC5E59B2486B}Prefabs/Items/Equipment/Backpacks/SAC_GUCCIORIGIN.et",
					4000, false, 1, "Sacs a Dos"));
				items.Insert(JobShopItem.NewCat("Sac Femme",
					"{0F66A88655FBCA17}Prefabs/Items/Equipment/Backpacks/SACFEMME.et",
					4000, false, 1, "Sacs a Dos"));

				// --- SACOCHES (5 items a 4000 capsules) ---
				items.Insert(JobShopItem.NewCat("Sacoche Dior",
					"{798403AE6CC12EC7}Prefabs/Items/Equipment/Backpacks/SACOCHE_DIOR.et",
					4000, false, 1, "Sacs a Dos"));
				items.Insert(JobShopItem.NewCat("Sacoche Gucci",
					"{C665381AF70012E3}Prefabs/Items/Equipment/Backpacks/SACOCHE_GUCCI.et",
					4000, false, 1, "Sacs a Dos"));
				items.Insert(JobShopItem.NewCat("Sacoche Gucci Noir",
					"{B1AE392CEF10BF22}Prefabs/Items/Equipment/Backpacks/SACOCHE_GUCCINOIR.et",
					4000, false, 1, "Sacs a Dos"));
				items.Insert(JobShopItem.NewCat("Sacoche Gucci Original",
					"{D20C52E5CEC9C725}Prefabs/Items/Equipment/Backpacks/SACOCHE_GUCCIORIG.et",
					4000, false, 1, "Sacs a Dos"));
				items.Insert(JobShopItem.NewCat("Sacoche LV",
					"{89E75BBCA66F0361}Prefabs/Items/Equipment/Backpacks/SACOCHE_LV.et",
					4000, false, 1, "Sacs a Dos"));

				// ============================================================
				// --- CASQUETTES (15 items a 30 capsules) ---
				// ============================================================
				items.Insert(JobShopItem.NewCat("Casquette",
					"{B3A1B1564DF63D80}Prefabs/Characters/HeadGear/Hat_TruckerCap_01/casquette.et",
					30, false, 1, "Casquettes"));
				items.Insert(JobShopItem.NewCat("Casquette Cartel ProjetX",
					"{F0BC9D8E661E1C48}Prefabs/Characters/HeadGear/Hat_TruckerCap_01/casquette_CARTELPROJETX.et",
					30, false, 1, "Casquettes"));
				items.Insert(JobShopItem.NewCat("Casquette ADIX",
					"{13C43A234E4A0A41}Prefabs/Characters/HeadGear/Hat_TruckerCap_01/casquetteprojetx_ADIX.et",
					30, false, 1, "Casquettes"));
				items.Insert(JobShopItem.NewCat("Casquette Graffiti",
					"{DDB3280B176CA435}Prefabs/Characters/HeadGear/Hat_TruckerCap_01/casquetteprojetx_graff.et",
					30, false, 1, "Casquettes"));
				items.Insert(JobShopItem.NewCat("Casquette Graffiti 2",
					"{D73AC9A756356166}Prefabs/Characters/HeadGear/Hat_TruckerCap_01/casquetteprojetx_graff2.et",
					30, false, 1, "Casquettes"));
				items.Insert(JobShopItem.NewCat("Casquette Bikelife",
					"{9BC6EF529CC56CCE}Prefabs/Characters/HeadGear/Hat_TruckerCap_01/casquetteprojetx_bikelife.et",
					30, false, 1, "Casquettes"));
				items.Insert(JobShopItem.NewCat("Casquette Mafieu",
					"{6B9E44CFB43C616C}Prefabs/Characters/HeadGear/Hat_TruckerCap_01/casquetteprojetx_mafieu.et",
					30, false, 1, "Casquettes"));
				items.Insert(JobShopItem.NewCat("Casquette NikeX",
					"{398F57842518154F}Prefabs/Characters/HeadGear/Hat_TruckerCap_01/casquetteprojetx_NIKEX.et",
					30, false, 1, "Casquettes"));
				items.Insert(JobShopItem.NewCat("Casquette Noire",
					"{6874210A26725968}Prefabs/Characters/HeadGear/Hat_TruckerCap_01/casquetteprojetx_noir.et",
					30, false, 1, "Casquettes"));
				items.Insert(JobShopItem.NewCat("Casquette Cocoste",
					"{99D54F56C6F886DE}Prefabs/Characters/HeadGear/Hat_TruckerCap_01/casquetteprojetx_COCOSTE.et",
					30, false, 1, "Casquettes"));
				items.Insert(JobShopItem.NewCat("Casquette Cocoste Noire",
					"{B676FD1F4A93F5BB}Prefabs/Characters/HeadGear/Hat_TruckerCap_01/casquetteprojetx_COCOSTE_NOIR.et",
					30, false, 1, "Casquettes"));
				items.Insert(JobShopItem.NewCat("Casquette Gucci",
					"{D3F25B1F55B4076A}Prefabs/Characters/HeadGear/Hat_TruckerCap_01/casquetteprojetx_gucci.et",
					30, false, 1, "Casquettes"));
				items.Insert(JobShopItem.NewCat("Casquette Mecanique",
					"{AC8EEAFC53E05643}Prefabs/Characters/HeadGear/Hat_TruckerCap_01/casquetteprojetx_mecanique.et",
					30, false, 1, "Casquettes"));
				items.Insert(JobShopItem.NewCat("Casquette Tete de Mort Or",
					"{641A33729D3647B4}Prefabs/Characters/HeadGear/Hat_TruckerCap_01/casquetteprojetx_mort_or.et",
					30, false, 1, "Casquettes"));
				items.Insert(JobShopItem.NewCat("Casquette Robot",
					"{F2E6C5461433503E}Prefabs/Characters/HeadGear/Hat_TruckerCap_01/casquetteprojetx_robot.et",
					30, false, 1, "Casquettes"));
				items.Insert(JobShopItem.NewCat("Casquette Tete de Mort",
					"{C434F6C2002A7730}Prefabs/Characters/HeadGear/Hat_TruckerCap_01/casquetteprojetx_tetedemort.et",
					30, false, 1, "Casquettes"));
				items.Insert(JobShopItem.NewCat("Casquette X Luxe",
					"{9F1601F685438F97}Prefabs/Characters/HeadGear/Hat_TruckerCap_01/casquetteprojetx_Xluxe.et",
					30, false, 1, "Casquettes"));
				items.Insert(JobShopItem.NewCat("Casquette X Luxe",
					"{3006A7C7B5C253B1}Prefabs/Characters/HeadGear/Hat_TruckerCap_01/casquetteprojetx_guccioriginal.et",
					30, false, 1, "Casquettes"));

				// ============================================================
				// --- CACHE COU (5 items a 30 capsules) ---
				// ============================================================
				items.Insert(JobShopItem.NewCat("Cache Cou Camouflage",
					"{3D48D26E26A1E39D}Prefabs/Clothing/CACHECOU_CAMOUFLAGE.et",
					30, false, 1, "Cache Cou"));
				items.Insert(JobShopItem.NewCat("Cache Cou Dior",
					"{7067031C85F95047}Prefabs/Clothing/CACHECOU_DIOR.et",
					30, false, 1, "Cache Cou"));
				items.Insert(JobShopItem.NewCat("Cache Cou Gucci Noir",
					"{6643ED440E3891A7}Prefabs/Clothing/CACHECOU_GGNOIR.et",
					30, false, 1, "Cache Cou"));
				items.Insert(JobShopItem.NewCat("Cache Cou Gucci Origin",
					"{D5AD28A910CD5910}Prefabs/Clothing/CACHECOU_GGORIGIN.et",
					30, false, 1, "Cache Cou"));
				items.Insert(JobShopItem.NewCat("Cache Cou Noir",
					"{5AA36A7CFE9C64B8}Prefabs/Clothing/CACHECOU_NOIR.et",
					30, false, 1, "Cache Cou"));

				// ============================================================
				// --- BONNETS (6 items a 30 capsules) ---
				// ============================================================
				items.Insert(JobShopItem.NewCat("Bonnet Boss",
					"{9FE4344E96B448D6}Prefabs/Characters/HeadGear/Hat_TruckerCap_01/BONNET_BOSS.et",
					30, false, 1, "Bonnets"));
				items.Insert(JobShopItem.NewCat("Bonnet Gucci",
					"{D7544561D484591B}Prefabs/Characters/HeadGear/Hat_TruckerCap_01/BONNET_GG.et",
					30, false, 1, "Bonnets"));
				items.Insert(JobShopItem.NewCat("Bonnet Hunder",
					"{715E8E05B4CD088E}Prefabs/Characters/HeadGear/Hat_TruckerCap_01/BONNET_HUNDER.et",
					30, false, 1, "Bonnets"));
				items.Insert(JobShopItem.NewCat("Bonnet LV Gris",
					"{0433B8AF26CFC2DC}Prefabs/Characters/HeadGear/Hat_TruckerCap_01/BONNET_LVGRIS.et",
					30, false, 1, "Bonnets"));
				items.Insert(JobShopItem.NewCat("Bonnet LV Noir",
					"{454DB7B84776006D}Prefabs/Characters/HeadGear/Hat_TruckerCap_01/BONNET_LVNOIR.et",
					30, false, 1, "Bonnets"));
				items.Insert(JobShopItem.NewCat("Bonnet Northface",
					"{E544FFA1AAA8CFAA}Prefabs/Characters/HeadGear/Hat_TruckerCap_01/BONNET_NORTHFACE.et",
					30, false, 1, "Bonnets"));

				// ============================================================
				// --- GANTS (7 items a 25 capsules) ---
				// ============================================================
				items.Insert(JobShopItem.NewCat("Gants 762",
					"{85BAFCE9A6D47768}Prefabs/Characters/Handwear/Gloves_Leather_01/GANTS_762.et",
					25, false, 1, "Gants"));
				items.Insert(JobShopItem.NewCat("Gants Black Market",
					"{358E59AE16F25767}Prefabs/Characters/Handwear/Gloves_Leather_01/GANTS_BLACKMARKET.et",
					25, false, 1, "Gants"));
				items.Insert(JobShopItem.NewCat("Gants Coke",
					"{CADF418524CB4109}Prefabs/Characters/Handwear/Gloves_Leather_01/GANTS_COKE.et",
					25, false, 1, "Gants"));
				items.Insert(JobShopItem.NewCat("Gants Crime",
					"{E54C558ACB1860EE}Prefabs/Characters/Handwear/Gloves_Leather_01/GANTS_CRIME.et",
					25, false, 1, "Gants"));
				items.Insert(JobShopItem.NewCat("Gants Mafia",
					"{72522DA927ACE574}Prefabs/Characters/Handwear/Gloves_Leather_01/GANTS_MAFIA.et",
					25, false, 1, "Gants"));
				items.Insert(JobShopItem.NewCat("Gants Mafia 2",
					"{10FBF75B227C31A1}Prefabs/Characters/Handwear/Gloves_Leather_01/GANTS_MAFIA2.et",
					25, false, 1, "Gants"));
				items.Insert(JobShopItem.NewCat("Gants Squelette",
					"{60007651D330A0B3}Prefabs/Characters/Handwear/Gloves_Leather_01/GANTS_SQUELETTE.et",
					25, false, 1, "Gants"));
				break;
			}
		}

		return items;
	}
	
	//------------------------------------------------------------------------------------------------
	// Retourne un article specifique par index
	//------------------------------------------------------------------------------------------------
	static JobShopItem GetItemByIndex(EJobType job, int index)
	{
		array<ref JobShopItem> items = GetItemsForJob(job);
		if (index < 0 || index >= items.Count())
			return null;
		return items.Get(index);
	}
	
	//------------------------------------------------------------------------------------------------
	// Retourne true si ce type/metier a un shop
	//------------------------------------------------------------------------------------------------
	static bool HasShop(EJobType job)
	{
		return (job == EJobType.VOYOU || job == EJobType.CONCESSIONNAIRE
			|| job == EJobType.VENDEUR_IMMOBILIER
			|| job == EJobType.MECANICIEN
			|| job == EJobType.JOURNALISTE
			|| job == EJobType.VENDEUR_VETEMENTS
			|| job == EJobType.SHOP_VETEMENTS
			|| job == EJobType.SHOP_NOURRITURE
			|| job == EJobType.SHOP_LOCATION
			|| job == EJobType.SHOP_COIFFURE
			|| job == EJobType.SHOP_DROGERIE
			|| job == EJobType.SHOP_BIJOUTERIE
			|| job == EJobType.SHOP_VOYOU_CAC
			|| job == EJobType.SHOP_VOYOU_POINT
			|| job == EJobType.SHOP_VOYOU_FUSIL
			|| job == EJobType.SHOP_VOYOU_MITRAILLETTE);
	}
	
	//------------------------------------------------------------------------------------------------
	// Label du bouton shop selon le metier (pour le menu PNJ)
	//------------------------------------------------------------------------------------------------
	static string GetShopButtonLabel(EJobType job)
	{
		switch (job)
		{
			case EJobType.VOYOU:              return "Marche noir (armes illegales)";
			case EJobType.CONCESSIONNAIRE:    return "Acheter un vehicule";
			case EJobType.VENDEUR_IMMOBILIER: return "Materiaux de construction";
			case EJobType.MECANICIEN:         return "Outils et pieces mecaniques";
			case EJobType.JOURNALISTE:        return "Materiel de reporter";
			case EJobType.VENDEUR_VETEMENTS:  return "Boutique Vetements RP";
			case EJobType.SHOP_VETEMENTS:     return "Vetements";
			case EJobType.SHOP_NOURRITURE:    return "Nourriture et boissons";
			case EJobType.SHOP_LOCATION:      return "Location de vehicules";
			case EJobType.SHOP_COIFFURE:      return "Coiffeur (cheveux & barbes)";
			case EJobType.SHOP_DROGERIE:      return "Drogerie";
			case EJobType.SHOP_BIJOUTERIE:    return "Bijoux et chaines en or";
			case EJobType.SHOP_VOYOU_CAC:          return "Armes corps a corps (lingots)";
			case EJobType.SHOP_VOYOU_POINT:        return "Armes de point (lingots)";
			case EJobType.SHOP_VOYOU_FUSIL:        return "Fusils (lingots)";
			case EJobType.SHOP_VOYOU_MITRAILLETTE: return "Mitraillettes (lingots)";
		}
		return "Boutique";
	}
}