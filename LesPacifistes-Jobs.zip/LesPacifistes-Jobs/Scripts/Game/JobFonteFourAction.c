//------------------------------------------------------------------------------------------------
// JobFonteFourAction.c
// UserAction a placer sur l entity Four.
// Au clic : envoie une RPC au serveur pour demarrer la fonte.
// Le serveur fait toutes les verifs (chaines presentes, fonte en cours).
//
// ACCES LIBRE (11 nov 2026) : la fonte est desormais accessible a TOUS les joueurs,
// le metier FONDEUR n est plus requis. Les checks metier ont ete retires cote client
// (CanBeShownScript / PerformAction) ET cote serveur (RpcAsk_StartFonte).
// Le serveur continue de verifier la distance au four et la presence des chaines.
//------------------------------------------------------------------------------------------------

class JobFonteFourAction : ScriptedUserAction
{
	//------------------------------------------------------------------------------------------------
	override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
	{
		PlayerController pc = PlayerController.Cast(GetGame().GetPlayerController());
		if (!pc) return;
		if (pUserEntity != pc.GetControlledEntity()) return;

		// Acces libre : plus aucun check de metier ici. Le serveur valide la distance
		// au four et la presence des chaines dans RpcAsk_StartFonte.
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;

		// Envoie la RplId du four au serveur pour resolution + check distance
		RplComponent rpl = RplComponent.Cast(pOwnerEntity.FindComponent(RplComponent));
		if (!rpl) return;
		jpc.ClientAskStartFonte(rpl.Id());
	}

	//------------------------------------------------------------------------------------------------
	override bool CanBePerformedScript(IEntity user)
	{
		return CanBeShownScript(user);
	}

	//------------------------------------------------------------------------------------------------
	// Visible pour TOUS les joueurs (le metier FONDEUR n est plus requis).
	//------------------------------------------------------------------------------------------------
	override bool CanBeShownScript(IEntity user)
	{
		if (!user) return false;
		return true;
	}

	//------------------------------------------------------------------------------------------------
	override bool GetActionNameScript(out string outName)
	{
		outName = "Lancer la fonte";
		return true;
	}
}
