//------------------------------------------------------------------------------------------------
// LP_DoorEnterCodeAction.c
// Action "Entrer un code" - visible si :
//   - porte a un proprio
//   - joueur local n est PAS le proprio
//   - joueur local ne connait PAS deja le code
//------------------------------------------------------------------------------------------------

class LP_DoorEnterCodeAction : ScriptedUserAction
{
	override bool CanBeShownScript(IEntity user)
	{
		if (!user) return false;
		
		IEntity door = GetOwner();
		if (!door) return false;
		LP_DoorAccessComponent access = LP_DoorAccessComponent.Cast(
			door.FindComponent(LP_DoorAccessComponent));
		if (!access || !access.HasOwner()) return false;
		
		int localPlayerId = SCR_PlayerController.GetLocalPlayerId();
		if (access.IsOwnerPlayerId(localPlayerId)) return false; // deja proprio
		if (access.KnowsCodePlayerId(localPlayerId)) return false; // deja connu
		return true;
	}
	
	override bool CanBePerformedScript(IEntity user) { return CanBeShownScript(user); }
	
	override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
	{
		PlayerController pc = PlayerController.Cast(GetGame().GetPlayerController());
		if (!pc) return;
		if (pUserEntity != pc.GetControlledEntity()) return;
		
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		
		RplComponent rpl = RplComponent.Cast(pOwnerEntity.FindComponent(RplComponent));
		if (!rpl) return;
		
		jpc.ClientAskOpenLpEnterCodeMenu(rpl.Id());
	}
}
