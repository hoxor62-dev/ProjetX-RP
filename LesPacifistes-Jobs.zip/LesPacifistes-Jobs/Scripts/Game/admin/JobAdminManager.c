//------------------------------------------------------------------------------------------------
// JobAdminManager.c
// Singleton serveur gerant la whitelist des admins.
//
// Whitelist stockee dans : $profile:LesPacifistesJobs/admins.json
// Format JSON :
//   {
//     "count": 2,
//     "uid_0": "abc123...",
//     "uid_1": "xyz789..."
//   }
//
// Pour ajouter un admin : edite le fichier manuellement ou utilise les helpers
// AddAdmin / RemoveAdmin (le boss peut les appeler depuis une console si besoin).
//------------------------------------------------------------------------------------------------

class JobAdminManager
{
	static ref JobAdminManager s_Instance;
	
	const string ADMIN_FILE = "$profile:LesPacifistesJobs/admins.json";
	
	ref array<string> m_AdminUIDs;
	bool m_Loaded;
	
	//------------------------------------------------------------------------------------------------
	void JobAdminManager()
	{
		m_AdminUIDs = new array<string>();
		m_Loaded = false;
	}
	
	//------------------------------------------------------------------------------------------------
	static JobAdminManager GetInstance()
	{
		if (!s_Instance)
		{
			s_Instance = new JobAdminManager();
			s_Instance.LoadFromDisk();
		}
		return s_Instance;
	}
	
	//------------------------------------------------------------------------------------------------
	bool IsAdmin(string uid)
	{
		if (uid == "")
			return false;
		if (!m_Loaded)
			LoadFromDisk();
		foreach (string adminUID : m_AdminUIDs)
		{
			if (adminUID == uid)
				return true;
		}
		return false;
	}
	
	//------------------------------------------------------------------------------------------------
	bool IsAdminPlayerId(int playerId)
	{
		if (playerId <= 0)
			return false;
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		return IsAdmin(uid);
	}
	
	//------------------------------------------------------------------------------------------------
	// Helpers pour ajouter/retirer des admins (utilisables depuis la console serveur si besoin)
	//------------------------------------------------------------------------------------------------
	void AddAdmin(string uid)
	{
		if (uid == "" || IsAdmin(uid))
			return;
		m_AdminUIDs.Insert(uid);
		SaveToDisk();
	}
	
	void RemoveAdmin(string uid)
	{
		int idx = m_AdminUIDs.Find(uid);
		if (idx >= 0)
		{
			m_AdminUIDs.Remove(idx);
			SaveToDisk();
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void LoadFromDisk()
	{
		m_AdminUIDs.Clear();
		SCR_JsonLoadContext ctx = new SCR_JsonLoadContext();
		if (!ctx.LoadFromFile(ADMIN_FILE))
		{
			// Pas de fichier : on cree un fichier vide
			Print("[JobAdminManager] Aucun fichier admin trouve - creation d un fichier vide", LogLevel.NORMAL);
			SaveToDisk();
			m_Loaded = true;
			return;
		}
		int count = 0;
		ctx.ReadValue("count", count);
		for (int i = 0; i < count; i++)
		{
			string key = "uid_" + i.ToString();
			string uid = "";
			ctx.ReadValue(key, uid);
			if (uid != "")
				m_AdminUIDs.Insert(uid);
		}
		m_Loaded = true;
		Print(string.Format("[JobAdminManager] %1 admin(s) charge(s)", m_AdminUIDs.Count()), LogLevel.NORMAL);
	}
	
	//------------------------------------------------------------------------------------------------
	void SaveToDisk()
	{
		SCR_JsonSaveContext ctx = new SCR_JsonSaveContext();
		ctx.WriteValue("count", m_AdminUIDs.Count());
		int idx = 0;
		foreach (string uid : m_AdminUIDs)
		{
			ctx.WriteValue("uid_" + idx.ToString(), uid);
			idx++;
		}
		ctx.SaveToFile(ADMIN_FILE);
	}
}
