//------------------------------------------------------------------------------------------------
// JobBanManager.c
// Singleton serveur gerant la blacklist des UID bannis.
// Persistance : $profile:LesPacifistesJobs/bans.json
//------------------------------------------------------------------------------------------------

class JobBanManager
{
	static ref JobBanManager s_Instance;
	
	const string BAN_FILE = "$profile:LesPacifistesJobs/bans.json";
	
	ref array<string> m_BannedUIDs;
	bool m_Loaded;
	
	//------------------------------------------------------------------------------------------------
	void JobBanManager()
	{
		m_BannedUIDs = new array<string>();
		m_Loaded = false;
	}
	
	//------------------------------------------------------------------------------------------------
	static JobBanManager GetInstance()
	{
		if (!s_Instance)
		{
			s_Instance = new JobBanManager();
			s_Instance.LoadFromDisk();
		}
		return s_Instance;
	}
	
	//------------------------------------------------------------------------------------------------
	bool IsBanned(string uid)
	{
		if (uid == "")
			return false;
		if (!m_Loaded)
			LoadFromDisk();
		foreach (string banned : m_BannedUIDs)
		{
			if (banned == uid)
				return true;
		}
		return false;
	}
	
	//------------------------------------------------------------------------------------------------
	void BanPlayer(string uid)
	{
		if (uid == "" || IsBanned(uid))
			return;
		m_BannedUIDs.Insert(uid);
		SaveToDisk();
	}
	
	//------------------------------------------------------------------------------------------------
	void Unban(string uid)
	{
		int idx = m_BannedUIDs.Find(uid);
		if (idx >= 0)
		{
			m_BannedUIDs.Remove(idx);
			SaveToDisk();
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void LoadFromDisk()
	{
		m_BannedUIDs.Clear();
		SCR_JsonLoadContext ctx = new SCR_JsonLoadContext();
		if (!ctx.LoadFromFile(BAN_FILE))
		{
			m_Loaded = true;
			return;
		}
		int count = 0;
		ctx.ReadValue("count", count);
		for (int i = 0; i < count; i++)
		{
			string uid = "";
			ctx.ReadValue("uid_" + i.ToString(), uid);
			if (uid != "")
				m_BannedUIDs.Insert(uid);
		}
		m_Loaded = true;
	}
	
	//------------------------------------------------------------------------------------------------
	void SaveToDisk()
	{
		SCR_JsonSaveContext ctx = new SCR_JsonSaveContext();
		ctx.WriteValue("count", m_BannedUIDs.Count());
		int idx = 0;
		foreach (string uid : m_BannedUIDs)
		{
			ctx.WriteValue("uid_" + idx.ToString(), uid);
			idx++;
		}
		ctx.SaveToFile(BAN_FILE);
	}
}
