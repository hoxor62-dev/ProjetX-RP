//------------------------------------------------------------------------------------------------
// JobAdminPlayerMenu.c
// Fiche admin d'un joueur : affiche infos + boutons d'actions (capsules, metier,
// reset amendes, liberer prison, donner permis, teleport, voir inventaire, bannir).
//------------------------------------------------------------------------------------------------

class JobAdminPlayerMenu : ChimeraMenuBase
{
	const string ENTRY_LAYOUT_PATH = "{9D68BEB73DF970D8}UI/layouts/JobSmsEntry.layout";
	
	Widget m_RootWidget;
	TextWidget m_TitleText;
	TextWidget m_InfoText;
	TextWidget m_StatusText;
	Widget m_JobsContainer;
	EditBoxWidget m_CapsulesAmount;
	ButtonWidget m_BtnAddCaps;
	ButtonWidget m_BtnRemoveCaps;
	EditBoxWidget m_BankAmount;      // Montant a ajouter/retirer sur le compte banque
	ButtonWidget m_BtnAddBank;
	ButtonWidget m_BtnRemoveBank;
	ButtonWidget m_BtnResetFines;
	ButtonWidget m_BtnReleasePrison;
	ButtonWidget m_BtnGiveLicense;
	ButtonWidget m_BtnValidateWL;
	ButtonWidget m_BtnRemoveWL;
	ButtonWidget m_BtnTeleport;
	ButtonWidget m_BtnTeleportToMe;
	ButtonWidget m_BtnInventory;
	ButtonWidget m_BtnRemoveIdentity;
	ButtonWidget m_BtnViewFullFiche;
	ButtonWidget m_BtnClearMentions;
	ButtonWidget m_BtnBan;
	ButtonWidget m_BtnClose;

	// === SPAWN ITEM (nouvelle section) ===
	EditBoxWidget m_SpawnQuantity;
	ButtonWidget m_BtnSpawnBelier;
	ButtonWidget m_BtnSpawnPepiteOr;
	ButtonWidget m_BtnSpawnPepiteFer;
	ButtonWidget m_BtnSpawnLingotOr;
	ButtonWidget m_BtnSpawnLingotFer;
	ButtonWidget m_BtnSpawnSafe;
	ButtonWidget m_BtnSpawnBois;
	ButtonWidget m_BtnSpawnPlanche;
	ButtonWidget m_BtnSpawnPomme;
	ButtonWidget m_BtnSpawnJusPomme;
	ButtonWidget m_BtnSpawnPierre;
	ButtonWidget m_BtnSpawnPierreT;
	ButtonWidget m_BtnSpawnBle;
	ButtonWidget m_BtnSpawnFarine;
	ButtonWidget m_BtnSpawnTenuePrison;
	ButtonWidget m_BtnSpawnWeedT;
	ButtonWidget m_BtnSpawnCannabis;
	ButtonWidget m_BtnSpawnCocaineT;
	ButtonWidget m_BtnSpawnCocaine;
	ButtonWidget m_BtnSpawnHerse;
	// Nourriture brute (ingredients de craft)
	ButtonWidget m_BtnSpawnLaitBrut;
	ButtonWidget m_BtnSpawnPoisson1;
	ButtonWidget m_BtnSpawnPoisson2;
	ButtonWidget m_BtnSpawnOeuf;
	ButtonWidget m_BtnSpawnViande;
	ButtonWidget m_BtnSpawnPoulet;
	ButtonWidget m_BtnSpawnEau;
	// Resultats de craft (nourriture preparee)
	ButtonWidget m_BtnSpawnLaitPasterise;
	ButtonWidget m_BtnSpawnBoiteThon;
	ButtonWidget m_BtnSpawnCroissant;
	ButtonWidget m_BtnSpawnCupcake;
	ButtonWidget m_BtnSpawnHamburger;
	ButtonWidget m_BtnSpawnNugget;
	ButtonWidget m_BtnSpawnGauffre;
	ButtonWidget m_BtnSpawnPoissonGrille;

	int m_TargetPlayerId = 0;
	string m_TargetDisplayName = "";
	
	static JobAdminPlayerMenu s_Instance;
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuOpen()
	{
		super.OnMenuOpen();
		s_Instance = this;
		JobFocusHandler.ClearRegistry();
		m_RootWidget = GetRootWidget();
		if (!m_RootWidget)
			return;
		
		m_TitleText = TextWidget.Cast(m_RootWidget.FindAnyWidget("TitleText"));
		m_InfoText = TextWidget.Cast(m_RootWidget.FindAnyWidget("InfoText"));
		m_StatusText = TextWidget.Cast(m_RootWidget.FindAnyWidget("StatusText"));
		m_JobsContainer = m_RootWidget.FindAnyWidget("JobsContainer");
		m_CapsulesAmount = EditBoxWidget.Cast(m_RootWidget.FindAnyWidget("CapsulesAmount"));
		m_BtnAddCaps = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnAddCaps"));
		m_BtnRemoveCaps = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnRemoveCaps"));
		m_BankAmount = EditBoxWidget.Cast(m_RootWidget.FindAnyWidget("BankAmount"));
		m_BtnAddBank = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnAddBank"));
		m_BtnRemoveBank = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnRemoveBank"));
		m_BtnResetFines = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnResetFines"));
		m_BtnReleasePrison = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnReleasePrison"));
		m_BtnGiveLicense = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnGiveLicense"));
		m_BtnValidateWL = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnValidateWL"));
		m_BtnRemoveWL = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnRemoveWL"));
		m_BtnTeleport = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnTeleport"));
		m_BtnTeleportToMe = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnTeleportToMe"));
		m_BtnInventory = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnInventory"));
		m_BtnRemoveIdentity = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnRemoveIdentity"));
		m_BtnViewFullFiche = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnViewFullFiche"));
		m_BtnClearMentions = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnClearMentions"));
		m_BtnBan = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnBan"));
		m_BtnClose = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnClose"));

		m_SpawnQuantity = EditBoxWidget.Cast(m_RootWidget.FindAnyWidget("SpawnQuantity"));
		m_BtnSpawnBelier = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnSpawnBelier"));
		m_BtnSpawnPepiteOr = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnSpawnPepiteOr"));
		m_BtnSpawnPepiteFer = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnSpawnPepiteFer"));
		m_BtnSpawnLingotOr = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnSpawnLingotOr"));
		m_BtnSpawnLingotFer = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnSpawnLingotFer"));
		m_BtnSpawnSafe = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnSpawnSafe"));
		m_BtnSpawnBois = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnSpawnBois"));
		m_BtnSpawnPlanche = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnSpawnPlanche"));
		m_BtnSpawnPomme = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnSpawnPomme"));
		m_BtnSpawnJusPomme = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnSpawnJusPomme"));
		m_BtnSpawnPierre = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnSpawnPierre"));
		m_BtnSpawnPierreT = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnSpawnPierreT"));
		m_BtnSpawnBle = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnSpawnBle"));
		m_BtnSpawnFarine = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnSpawnFarine"));
		m_BtnSpawnTenuePrison = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnSpawnTenuePrison"));
		m_BtnSpawnWeedT = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnSpawnWeedT"));
		m_BtnSpawnCannabis = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnSpawnCannabis"));
		m_BtnSpawnCocaineT = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnSpawnCocaineT"));
		// Nouveaux spawns nourriture (brute + craftee)
		m_BtnSpawnLaitBrut = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnSpawnLaitBrut"));
		m_BtnSpawnPoisson1 = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnSpawnPoisson1"));
		m_BtnSpawnPoisson2 = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnSpawnPoisson2"));
		m_BtnSpawnOeuf = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnSpawnOeuf"));
		m_BtnSpawnViande = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnSpawnViande"));
		m_BtnSpawnPoulet = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnSpawnPoulet"));
		m_BtnSpawnEau = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnSpawnEau"));
		m_BtnSpawnLaitPasterise = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnSpawnLaitPasterise"));
		m_BtnSpawnBoiteThon = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnSpawnBoiteThon"));
		m_BtnSpawnCroissant = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnSpawnCroissant"));
		m_BtnSpawnCupcake = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnSpawnCupcake"));
		m_BtnSpawnHamburger = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnSpawnHamburger"));
		m_BtnSpawnNugget = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnSpawnNugget"));
		m_BtnSpawnGauffre = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnSpawnGauffre"));
		m_BtnSpawnPoissonGrille = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnSpawnPoissonGrille"));
		m_BtnSpawnCocaine = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnSpawnCocaine"));
		m_BtnSpawnHerse = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnSpawnHerse"));

		AttachActionButton(m_BtnAddCaps, "addcaps");
		AttachActionButton(m_BtnRemoveCaps, "removecaps");
		AttachActionButton(m_BtnAddBank, "addbank");
		AttachActionButton(m_BtnRemoveBank, "removebank");
		AttachActionButton(m_BtnResetFines, "resetfines");
		AttachActionButton(m_BtnReleasePrison, "releaseprison");
		AttachActionButton(m_BtnGiveLicense, "givelicense");
		AttachActionButton(m_BtnValidateWL, "validatewl");
		AttachActionButton(m_BtnRemoveWL, "removewl");

		// Masque par defaut jusqu a reception du statut WL depuis le serveur
		// (SetWhitelistStatus affichera l un OU l autre selon le statut)
		if (m_BtnValidateWL)
			m_BtnValidateWL.SetVisible(false);
		if (m_BtnRemoveWL)
			m_BtnRemoveWL.SetVisible(false);
		AttachActionButton(m_BtnTeleport, "teleport");
		AttachActionButton(m_BtnTeleportToMe, "teleporttome");
		AttachActionButton(m_BtnInventory, "inventory");
		AttachActionButton(m_BtnRemoveIdentity, "removeidentity");
		AttachActionButton(m_BtnViewFullFiche, "viewfullfiche");
		AttachActionButton(m_BtnClearMentions, "clearmentions");
		AttachActionButton(m_BtnBan, "ban");
		AttachActionButton(m_BtnClose, "close");

		// Boutons spawn item : chaque bouton envoie une action distincte, prefab resolu dans OnActionClicked
		AttachActionButton(m_BtnSpawnBelier, "spawn_belier");
		AttachActionButton(m_BtnSpawnPepiteOr, "spawn_pepite_or");
		AttachActionButton(m_BtnSpawnPepiteFer, "spawn_pepite_fer");
		AttachActionButton(m_BtnSpawnLingotOr, "spawn_lingot_or");
		AttachActionButton(m_BtnSpawnLingotFer, "spawn_lingot_fer");
		AttachActionButton(m_BtnSpawnSafe, "spawn_safe");
		AttachActionButton(m_BtnSpawnBois, "spawn_bois");
		AttachActionButton(m_BtnSpawnPlanche, "spawn_planche");
		AttachActionButton(m_BtnSpawnPomme, "spawn_pomme");
		AttachActionButton(m_BtnSpawnJusPomme, "spawn_jus_pomme");
		AttachActionButton(m_BtnSpawnPierre, "spawn_pierre");
		AttachActionButton(m_BtnSpawnPierreT, "spawn_pierre_t");
		AttachActionButton(m_BtnSpawnBle, "spawn_ble");
		AttachActionButton(m_BtnSpawnFarine, "spawn_farine");
		AttachActionButton(m_BtnSpawnTenuePrison, "spawn_tenue_prison");
		AttachActionButton(m_BtnSpawnWeedT, "spawn_weed_t");
		AttachActionButton(m_BtnSpawnCannabis, "spawn_cannabis");
		AttachActionButton(m_BtnSpawnCocaineT, "spawn_cocaine_t");
		AttachActionButton(m_BtnSpawnCocaine, "spawn_cocaine");
		AttachActionButton(m_BtnSpawnHerse, "spawn_herse");
		// Nouveaux boutons spawn nourriture (brute + craftee)
		AttachActionButton(m_BtnSpawnLaitBrut, "spawn_lait_brut");
		AttachActionButton(m_BtnSpawnPoisson1, "spawn_poisson1");
		AttachActionButton(m_BtnSpawnPoisson2, "spawn_poisson2");
		AttachActionButton(m_BtnSpawnOeuf, "spawn_oeuf");
		AttachActionButton(m_BtnSpawnViande, "spawn_viande");
		AttachActionButton(m_BtnSpawnPoulet, "spawn_poulet");
		AttachActionButton(m_BtnSpawnEau, "spawn_eau");
		AttachActionButton(m_BtnSpawnLaitPasterise, "spawn_lait_pasterise");
		AttachActionButton(m_BtnSpawnBoiteThon, "spawn_boite_thon");
		AttachActionButton(m_BtnSpawnCroissant, "spawn_croissant");
		AttachActionButton(m_BtnSpawnCupcake, "spawn_cupcake");
		AttachActionButton(m_BtnSpawnHamburger, "spawn_hamburger");
		AttachActionButton(m_BtnSpawnNugget, "spawn_nugget");
		AttachActionButton(m_BtnSpawnGauffre, "spawn_gauffre");
		AttachActionButton(m_BtnSpawnPoissonGrille, "spawn_poisson_grille");

		if (m_InfoText)
			m_InfoText.SetText("Chargement...");
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuClose()
	{
		if (s_Instance == this)
			s_Instance = null;
		super.OnMenuClose();
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuUpdate(float tDelta)
	{
		super.OnMenuUpdate(tDelta);
		if (GetGame().GetInputManager().GetActionValue("MenuBack") > 0.5)
			CloseMenuInternal();
	}
	
	//------------------------------------------------------------------------------------------------
	void Initialize(int targetPlayerId, string displayName)
	{
		m_TargetPlayerId = targetPlayerId;
		m_TargetDisplayName = displayName;
		
		if (m_TitleText)
			m_TitleText.SetText("Admin : " + displayName);
		
		BuildJobsList();
		
		// Demande au serveur les infos du joueur cible
		PlayerController pc = GetGame().GetPlayerController();
		if (pc)
		{
			JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
			if (jpc)
			{
				jpc.ClientAskAdminPlayerInfo(targetPlayerId);
				// Demande aussi le statut whitelist pour decider d afficher ou masquer BtnValidateWL
				jpc.ClientAskAdminCheckWhitelist(targetPlayerId);
			}
		}
	}

	//------------------------------------------------------------------------------------------------
	// Callback appele par la RPC RpcDo_AdminWhitelistStatus pour masquer/afficher le bouton
	// "Valider WL" selon le statut du joueur cible.
	//------------------------------------------------------------------------------------------------
	void SetWhitelistStatus(int targetPlayerId, bool isWhitelist)
	{
		// Ne pas confondre si une autre fiche admin a ete ouverte entre-temps
		if (targetPlayerId != m_TargetPlayerId)
			return;
		// Affiche Valider WL si pas encore WL, et Retirer WL si deja WL.
		if (m_BtnValidateWL)
			m_BtnValidateWL.SetVisible(!isWhitelist);
		if (m_BtnRemoveWL)
			m_BtnRemoveWL.SetVisible(isWhitelist);
	}
	
	//------------------------------------------------------------------------------------------------
	void DisplayPlayerInfo(string formatted)
	{
		if (m_InfoText)
			m_InfoText.SetText(formatted);
	}
	
	//------------------------------------------------------------------------------------------------
	void BuildJobsList()
	{
		if (!m_JobsContainer)
			return;
		
		// Reset
		Widget child = m_JobsContainer.GetChildren();
		while (child)
		{
			Widget next = child.GetSibling();
			child.RemoveFromHierarchy();
			child = next;
		}
		
		WorkspaceWidget ws = GetGame().GetWorkspace();
		
		// Liste tous les metiers possibles (sauf NONE)
		array<EJobType> allJobs = new array<EJobType>();
		allJobs.Insert(EJobType.CHOMEUR);
		allJobs.Insert(EJobType.MINEUR);
		allJobs.Insert(EJobType.UBER);
		allJobs.Insert(EJobType.CUISINIER);
		allJobs.Insert(EJobType.BUCHERON);
		allJobs.Insert(EJobType.AGRICULTEUR);
		allJobs.Insert(EJobType.MEDECIN);
		allJobs.Insert(EJobType.POLICIER);
		allJobs.Insert(EJobType.CONCESSIONNAIRE);
		allJobs.Insert(EJobType.MILITAIRE);
		allJobs.Insert(EJobType.VOYOU);
		allJobs.Insert(EJobType.VENDEUR_IMMOBILIER);
		allJobs.Insert(EJobType.MECANICIEN);
		allJobs.Insert(EJobType.JOURNALISTE);
		allJobs.Insert(EJobType.PRESIDENT);
		allJobs.Insert(EJobType.AVOCAT);
		allJobs.Insert(EJobType.FERMIER);
		allJobs.Insert(EJobType.PROCUREUR);
		allJobs.Insert(EJobType.EPICIER);
		allJobs.Insert(EJobType.VENDEUR_VETEMENTS);
		allJobs.Insert(EJobType.FONDEUR);
		allJobs.Insert(EJobType.FOURRIERE);
		allJobs.Insert(EJobType.POMPISTE);

		foreach (EJobType job : allJobs)
		{
			Widget entry = ws.CreateWidgets(ENTRY_LAYOUT_PATH, m_JobsContainer);
			if (!entry)
				continue;
			
			TextWidget nameW = TextWidget.Cast(entry.FindAnyWidget("PlayerName"));
			if (nameW)
				nameW.SetText(JobData.GetJobLabel(job));
			
			ButtonWidget btn = ButtonWidget.Cast(entry.FindAnyWidget("SelectButton"));
			if (btn)
			{
				AdminJobSelectHandler jh = new AdminJobSelectHandler();
				jh.m_Menu = this;
				jh.m_Job = job;
				btn.AddHandler(jh);
				JobFocusHandler.Attach(btn);
			}
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void AttachActionButton(ButtonWidget btn, string action)
	{
		if (!btn)
			return;
		AdminActionButtonHandler h = new AdminActionButtonHandler();
		h.m_Menu = this;
		h.m_Action = action;
		btn.AddHandler(h);
		JobFocusHandler.Attach(btn);
	}
	
	//------------------------------------------------------------------------------------------------
	void OnActionClicked(string action)
	{
		if (action == "close")
		{
			CloseMenuInternal();
			return;
		}
		
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc)
			return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc)
			return;
		
		if (action == "addcaps")
		{
			int amt = GetCapsulesAmount();
			if (amt > 0)
			{
				jpc.ClientAskAdminAddCaps(m_TargetPlayerId, amt);
				SetStatus(string.Format("+%1 capsules envoyees", amt));
				ScheduleRefresh();
			}
		}
		else if (action == "removecaps")
		{
			int amt2 = GetCapsulesAmount();
			if (amt2 > 0)
			{
				jpc.ClientAskAdminAddCaps(m_TargetPlayerId, -amt2);
				SetStatus(string.Format("-%1 capsules retirees", amt2));
				ScheduleRefresh();
			}
		}
		else if (action == "addbank")
		{
			int amtB = GetBankAmount();
			if (amtB > 0)
			{
				jpc.ClientAskAdminAddBank(m_TargetPlayerId, amtB);
				SetStatus(string.Format("+%1 capsules ajoutees en banque", amtB));
				ScheduleRefresh();
			}
		}
		else if (action == "removebank")
		{
			int amtB2 = GetBankAmount();
			if (amtB2 > 0)
			{
				jpc.ClientAskAdminAddBank(m_TargetPlayerId, -amtB2);
				SetStatus(string.Format("-%1 capsules retirees de la banque", amtB2));
				ScheduleRefresh();
			}
		}
		else if (action == "resetfines")
		{
			jpc.ClientAskAdminResetFines(m_TargetPlayerId);
			SetStatus("Amendes reinitialisees");
			ScheduleRefresh();
		}
		else if (action == "releaseprison")
		{
			jpc.ClientAskAdminReleasePrison(m_TargetPlayerId);
			SetStatus("Joueur libere de prison");
			ScheduleRefresh();
		}
		else if (action == "givelicense")
		{
			jpc.ClientAskAdminGiveLicense(m_TargetPlayerId);
			SetStatus("Permis accorde");
			ScheduleRefresh();
		}
		else if (action == "validatewl")
		{
			jpc.ClientAskAdminValidateWL(m_TargetPlayerId);
			SetStatus("Whitelist validee");
			// Le bouton sera masque automatiquement a reception de RpcDo_AdminWhitelistStatus(true)
		}
		else if (action == "removewl")
		{
			jpc.ClientAskAdminRemoveWL(m_TargetPlayerId);
			SetStatus("Whitelist retiree - joueur teleporte en prison");
			// Le bouton sera masque automatiquement a reception de RpcDo_AdminWhitelistStatus(false)
		}
		else if (action == "teleport")
		{
			jpc.ClientAskAdminTeleport(m_TargetPlayerId);
			SetStatus("Teleportation en cours...");
		}
		else if (action == "teleporttome")
		{
			jpc.ClientAskAdminTeleportToMe(m_TargetPlayerId);
			SetStatus("Teleportation du joueur vers vous...");
		}
		else if (action == "inventory")
		{
			jpc.ClientAskAdminInventory(m_TargetPlayerId);
			SetStatus("Inventaire demande...");
		}
		else if (action == "removeidentity")
		{
			jpc.ClientAskAdminRemoveIdentity(m_TargetPlayerId);
			SetStatus("Identite RP supprimee");
			ScheduleRefresh();
		}
		else if (action == "viewfullfiche")
		{
			// Ouvre la fiche RP complete du joueur cible (donnees fetchees serveur)
			jpc.ClientAskAdminViewFiche(m_TargetPlayerId);
			SetStatus("Ouverture de la fiche RP...");
		}
		else if (action == "clearmentions")
		{
			// Vide toutes les mentions du casier (vidage direct, pas de confirmation)
			jpc.ClientAskAdminClearMentions(m_TargetPlayerId);
			SetStatus("Mentions du casier supprimees");
			ScheduleRefresh();
		}
		else if (action == "ban")
		{
			jpc.ClientAskAdminBan(m_TargetPlayerId);
			SetStatus("Joueur banni - le serveur le kickera");
			GetGame().GetCallqueue().CallLater(CloseMenuInternal, 1500, false);
		}
		else if (action == "spawn_belier")
			SpawnItemAction(jpc, "{CFB9CC7270F8CEC4}Prefabs/Items/Equipment/Accessories/ETool_ALICE/belier.et", "Belier");
		else if (action == "spawn_pepite_or")
			SpawnItemAction(jpc, "{C6D29778D28BA23A}Prefabs/Weapons/Grenades/pepiteor.et", "Pepite d or");
		else if (action == "spawn_pepite_fer")
			SpawnItemAction(jpc, "{B5C7F29EAB4BE9A7}Prefabs/Weapons/Grenades/pepitefer.et", "Pepite de fer");
		else if (action == "spawn_lingot_or")
			SpawnItemAction(jpc, "{CD7E4794F5D40A0B}Prefabs/Items/Equipment/bargold/bargold.et", "Lingot d or");
		else if (action == "spawn_lingot_fer")
			SpawnItemAction(jpc, "{BFAB2077C1F962CB}Prefabs/Items/Equipment/bargold/bariron.et", "Lingot de fer");
		else if (action == "spawn_safe")
			SpawnItemAction(jpc, "{D125E11C31A965AA}Prefabs/BaseBuilding/Storage/Safe/SafeBook.et", "Coffre blinde");
		else if (action == "spawn_bois")
			SpawnItemAction(jpc, "{8597A239C7AB5E14}Prefabs/Weapons/Grenades/bois.et", "Bois");
		else if (action == "spawn_planche")
			SpawnItemAction(jpc, "{06F1E252DC029B8C}Prefabs/Props/Civilian/Plank.et", "Planche");
		else if (action == "spawn_pomme")
			SpawnItemAction(jpc, "{E629212FF102070A}Prefabs/Weapons/Grenades/pomme.et", "Pomme");
		else if (action == "spawn_jus_pomme")
			SpawnItemAction(jpc, "{80922B9A9B594699}Prefabs/Weapons/Grenades/jusdepomme.et", "Jus de pomme");
		else if (action == "spawn_pierre")
			SpawnItemAction(jpc, "{16ED337A2A7E87A5}Prefabs/Weapons/Grenades/ROCK.et", "Pierre");
		else if (action == "spawn_pierre_t")
			SpawnItemAction(jpc, "{F0A9B1F935F3268F}Prefabs/Weapons/Grenades/ROCK2.et", "Pierre transformee");
		else if (action == "spawn_ble")
			SpawnItemAction(jpc, "{65669257F999337D}Prefabs/Weapons/Grenades/ble.et", "Ble");
		else if (action == "spawn_farine")
			SpawnItemAction(jpc, "{3CE28F8799BE0AD6}Prefabs/Weapons/Grenades/farine.et", "Farine");
		else if (action == "spawn_tenue_prison")
			SpawnItemAction(jpc, "{14AFA61E68CDDD65}Prefabs/Characters/Uniforms/Suit_Pilot_US_01/TENUE_PRISON.et", "Tenue prison");
		else if (action == "spawn_weed_t")
			SpawnItemAction(jpc, "{29CAED9E186127A1}Prefabs/Items/InventoryItems/Contraband/WeedBag.et", "Cannabis transforme");
		else if (action == "spawn_cannabis")
			SpawnItemAction(jpc, "{C3D01F32432A1FF1}Prefabs/Weapons/Grenades/cannabis-frais.et", "Cannabis frais");
		else if (action == "spawn_cocaine_t")
			SpawnItemAction(jpc, "{FB1CC21B8E56BCEC}Prefabs/Items/InventoryItems/Contraband/CocaineBag.et", "Cocaine transforme");
		else if (action == "spawn_cocaine")
			SpawnItemAction(jpc, "{76BD00F7988BC108}Prefabs/Weapons/Grenades/Cock.et", "Cocaine");
		else if (action == "spawn_herse")
			SpawnItemAction(jpc, "{DD554C7B64726776}Prefabs/Items/Item_SpikeStrip.et", "Herse");
		// === Nourriture brute (ingredients cuisine / epicerie) ===
		else if (action == "spawn_lait_brut")
			SpawnItemAction(jpc, "{14B5AE4385CA2AC7}Prefabs/Weapons/Grenades/lait.et", "Lait brut");
		else if (action == "spawn_poisson1")
			SpawnItemAction(jpc, "{6C9D10B121D0B61E}Prefabs/Weapons/Grenades/poisson1.et", "Poisson 1");
		else if (action == "spawn_poisson2")
			SpawnItemAction(jpc, "{00C924519D143930}Prefabs/Weapons/Grenades/poisson2.et", "Poisson 2");
		else if (action == "spawn_oeuf")
			SpawnItemAction(jpc, "{40DD771C1264953C}Prefabs/Weapons/Grenades/oeuf.et", "Oeuf");
		else if (action == "spawn_viande")
			SpawnItemAction(jpc, "{3610E30E5946AD2B}Prefabs/Items/Food/MeatLeg_01.et", "Viande");
		else if (action == "spawn_poulet")
			SpawnItemAction(jpc, "{D8AAF1F088605E7E}Prefabs/Weapons/Grenades/poulet.et", "Poulet");
		else if (action == "spawn_eau")
			SpawnItemAction(jpc, "{F9C514AC996D4829}Prefabs/Items/Equipment/Radios/Water Bottle.et", "Eau");
		// === Nourriture craftee (resultat cuisine / epicerie) ===
		else if (action == "spawn_lait_pasterise")
			SpawnItemAction(jpc, "{146D173B1CEBD017}Prefabs/Items/Equipment/Radios/laitok.et", "Lait pasterise");
		else if (action == "spawn_boite_thon")
			SpawnItemAction(jpc, "{181ED76922490202}Prefabs/Items/Equipment/Radios/boitedethon.et", "Boite de thon");
		else if (action == "spawn_croissant")
			SpawnItemAction(jpc, "{060D3CED33A555A9}Prefabs/Items/Equipment/Radios/croissant.et", "Croissant");
		else if (action == "spawn_cupcake")
			SpawnItemAction(jpc, "{80DE0727A18AA558}Prefabs/Items/Equipment/Radios/cupcake.et", "Cupcake");
		else if (action == "spawn_hamburger")
			SpawnItemAction(jpc, "{DC643F43E4CA6D1C}Prefabs/Items/Equipment/Radios/hamburger.et", "Hamburger");
		else if (action == "spawn_nugget")
			SpawnItemAction(jpc, "{2045868773168C9A}Prefabs/Items/Equipment/Radios/nugget.et", "Nugget");
		else if (action == "spawn_gauffre")
			SpawnItemAction(jpc, "{CEC26D06FE3ADB9C}Prefabs/Items/Equipment/Radios/pancake.et", "Gauffre");
		else if (action == "spawn_poisson_grille")
			SpawnItemAction(jpc, "{BE8EE247DD42394A}Prefabs/Items/Equipment/Radios/poissongriller.et", "Poisson grille");
	}

	//------------------------------------------------------------------------------------------------
	// Lit la quantite (clamp 1..100), envoie la RPC spawn au serveur, met le status.
	//------------------------------------------------------------------------------------------------
	void SpawnItemAction(JobPlayerComponent jpc, string prefab, string itemLabel)
	{
		int qty = 1;
		if (m_SpawnQuantity)
		{
			string s = m_SpawnQuantity.GetText();
			qty = s.ToInt();
		}
		if (qty < 1) qty = 1;
		if (qty > 100) qty = 100;
		jpc.ClientAskAdminSpawnItem(m_TargetPlayerId, prefab, qty);
		SetStatus(string.Format("Spawn x%1 : %2 (en inventaire ou au sol si plein)", qty, itemLabel));
	}
	
	//------------------------------------------------------------------------------------------------
	void OnJobSelected(EJobType job)
	{
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc)
			return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc)
			return;
		jpc.ClientAskAdminSetJob(m_TargetPlayerId, job);
		SetStatus(string.Format("Metier change : %1", JobData.GetJobLabel(job)));
		ScheduleRefresh();
	}
	
	//------------------------------------------------------------------------------------------------
	int GetCapsulesAmount()
	{
		if (!m_CapsulesAmount)
			return 0;
		string s = m_CapsulesAmount.GetText();
		int v = s.ToInt();
		if (v < 0)
			v = -v;
		return v;
	}
	
	//------------------------------------------------------------------------------------------------
	int GetBankAmount()
	{
		if (!m_BankAmount)
			return 0;
		string s = m_BankAmount.GetText();
		int v = s.ToInt();
		if (v < 0)
			v = -v;
		return v;
	}
	
	//------------------------------------------------------------------------------------------------
	void SetStatus(string s)
	{
		if (m_StatusText)
			m_StatusText.SetText(s);
	}
	
	//------------------------------------------------------------------------------------------------
	void ScheduleRefresh()
	{
		// Recharge la fiche apres un court delai pour laisser le serveur appliquer
		GetGame().GetCallqueue().CallLater(RefreshInfo, 600, false);
	}
	
	void RefreshInfo()
	{
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc)
			return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc)
			return;
		jpc.ClientAskAdminPlayerInfo(m_TargetPlayerId);
	}
	
	//------------------------------------------------------------------------------------------------
	void CloseMenuInternal()
	{
		GetGame().GetMenuManager().CloseMenu(this);
	}
	
	static JobAdminPlayerMenu GetOpenMenu()
	{
		return s_Instance;
	}
}

//------------------------------------------------------------------------------------------------
class AdminActionButtonHandler : ScriptedWidgetEventHandler
{
	JobAdminPlayerMenu m_Menu;
	string m_Action;
	
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu)
			m_Menu.OnActionClicked(m_Action);
		return true;
	}
}

//------------------------------------------------------------------------------------------------
class AdminJobSelectHandler : ScriptedWidgetEventHandler
{
	JobAdminPlayerMenu m_Menu;
	EJobType m_Job;
	
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu)
			m_Menu.OnJobSelected(m_Job);
		return true;
	}
}
