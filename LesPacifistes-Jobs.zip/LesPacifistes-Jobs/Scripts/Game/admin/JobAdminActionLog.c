//------------------------------------------------------------------------------------------------
// JobAdminActionLog.c
// Ring buffer serveur des 50 dernieres actions admin (toutes confondues).
//
// Chaque entree est une string formatee : "[HH:MM:SS] <AdminName> : <action>"
//   ex: "[14:32:17] Alexandre Dupont : Supprime vehicule #42 (proprio ABC123)"
//       "[14:34:02] Alexandre Dupont : Cours Roche : 10% -> 15%"
//
// Lecture via GetEntries() -> array<string> (plus recents en premier).
// Appel typique depuis les RPCs admin : JobAdminActionLog.GetInstance().Log(adminName, actionStr)
//------------------------------------------------------------------------------------------------

class JobAdminActionLog
{
	const int RING_SIZE = 50;

	static ref JobAdminActionLog s_Instance;

	// Buffer circulaire. m_Head pointe sur l index ou on ecrira la prochaine entree.
	ref array<string> m_Entries;
	int m_Head = 0;
	int m_Count = 0;

	//------------------------------------------------------------------------------------------------
	void JobAdminActionLog()
	{
		m_Entries = new array<string>();
		for (int i = 0; i < RING_SIZE; i++)
			m_Entries.Insert("");
	}

	//------------------------------------------------------------------------------------------------
	static JobAdminActionLog GetInstance()
	{
		if (!s_Instance)
			s_Instance = new JobAdminActionLog();
		return s_Instance;
	}

	//------------------------------------------------------------------------------------------------
	// Ajoute une entree au log avec timestamp automatique.
	//------------------------------------------------------------------------------------------------
	void Log(string adminName, string action)
	{
		int unix = System.GetUnixTime();
		int hour = (unix / 3600) % 24;
		int minute = (unix / 60) % 60;
		int sec = unix % 60;
		string hh = PadTwo(hour);
		string mm = PadTwo(minute);
		string ss = PadTwo(sec);

		string entry = string.Format("[%1:%2:%3] %4 : %5", hh, mm, ss, adminName, action);
		m_Entries.Set(m_Head, entry);
		m_Head = (m_Head + 1) % RING_SIZE;
		if (m_Count < RING_SIZE)
			m_Count = m_Count + 1;

		Print(string.Format("[JobAdminActionLog] %1", entry), LogLevel.NORMAL);
	}

	//------------------------------------------------------------------------------------------------
	// Remplit outEntries avec les entrees du log, plus RECENTES en premier.
	//------------------------------------------------------------------------------------------------
	void GetEntries(out array<string> outEntries)
	{
		if (!outEntries) return;
		outEntries.Clear();
		// Parcourt depuis la derniere ecrite en remontant
		for (int i = 0; i < m_Count; i++)
		{
			int idx = m_Head - 1 - i;
			if (idx < 0) idx = idx + RING_SIZE;
			string e = m_Entries.Get(idx);
			if (e != "")
				outEntries.Insert(e);
		}
	}

	//------------------------------------------------------------------------------------------------
	protected string PadTwo(int n)
	{
		if (n < 10) return "0" + n.ToString();
		return n.ToString();
	}
}
