//------------------------------------------------------------------------------------------------
// JobAdminMenu.c
// Panel admin complet avec sidebar + pages switchables :
//   - Tableau de bord : stats serveur + joueurs connectes + top 25 des plus riches
//   - Gestion des joueurs : liste detaillee des joueurs connectes (clic -> fiche)
//   - Gestion des vehicules : liste de TOUS les vehicules du garage virtuel (filtrable)
//   - Sanctions / Rapports / Economie / Tickets / Parametres : placeholders
//
// Flux de donnees :
//   OnMenuOpen -> ClientAskAdminDashboard() -> serveur agrege et envoie en RPC
//   -> RpcDo_AdminDashboardData -> JobAdminMenu.SetDashboardData() -> rendu UI
//------------------------------------------------------------------------------------------------

class JobAdminMenu : ChimeraMenuBase
{
	// Layout d entree multi-colonnes (ColId / ColName / ColMiddle / ColRight + RowButton).
	// Enregistre par l utilisateur dans Workbench.
	const string ROW_LAYOUT_PATH = "{4C675B899ADF8C84}UI/layouts/JobAdminRowEntry.layout";

	// === WIDGETS RACINE ===
	Widget m_RootWidget;
	TextWidget m_PageTitle;
	TextWidget m_PageSubtitle;
	ButtonWidget m_BtnClose;

	// Sidebar navigation
	ButtonWidget m_NavDashboard;
	ButtonWidget m_NavPlayers;
	ButtonWidget m_NavVehicles;
	ButtonWidget m_NavSanctions;
	ButtonWidget m_NavReports;
	ButtonWidget m_NavEconomy;
	ButtonWidget m_NavTickets;
	ButtonWidget m_NavSettings;

	// Pages
	Widget m_PageDashboard;
	Widget m_PagePlayers;
	Widget m_PageVehicles;
	Widget m_PageEconomy;
	Widget m_PageReports;
	Widget m_PagePlaceholder;
	TextWidget m_PlaceholderText;
	Widget m_EconomyRows;
	Widget m_ReportsLogContainer;
	TextWidget m_ReportsBodyText;

	// Stats cards (dashboard)
	TextWidget m_StatPlayersValue;
	TextWidget m_StatVehiclesValue;
	TextWidget m_StatMoneyValue;

	// Containers de listes
	Widget m_DashboardPlayers;
	Widget m_RichestContainer;
	Widget m_PlayersPage;
	Widget m_VehiclesPage;

	// Vehicle search + delete mode (dual-click confirmation)
	EditBoxWidget m_VehicleSearchBox;
	ButtonWidget m_BtnVehicleSearch;
	ButtonWidget m_BtnVehicleDeleteMode;
	TextWidget m_BtnVehicleDeleteModeLabel;
	TextWidget m_VehicleStatusText;
	bool m_DeleteModeOn = false;
	int m_PendingDeleteIndex = -1;  // index en attente de confirmation (-1 = aucun)

	// Recherche joueur (page Gestion des joueurs)
	EditBoxWidget m_PlayerSearchBox;
	ButtonWidget m_BtnPlayerSearch;
	ButtonWidget m_BtnPlayerClear;
	string m_PlayerFilter = "";  // filtre actuel (vide = tous les joueurs)

	// Pagination log admin (10 entrees par page)
	ButtonWidget m_BtnReportsPrev;
	ButtonWidget m_BtnReportsNext;
	TextWidget m_ReportsPageText;
	int m_ReportsCurrentPage = 0;
	const int REPORTS_PER_PAGE = 10;

	// Pagination gestion joueurs (14 par page)
	ButtonWidget m_BtnPlayersPrev;
	ButtonWidget m_BtnPlayersNext;
	TextWidget m_PlayersPageLabel;
	int m_PlayersCurrentPage = 0;
	const int PLAYERS_PER_PAGE = 14;

	// Pagination gestion vehicules (14 par page)
	ButtonWidget m_BtnVehiclesPrev;
	ButtonWidget m_BtnVehiclesNext;
	TextWidget m_VehiclesPageLabel;
	int m_VehiclesCurrentPage = 0;
	const int VEHICLES_PER_PAGE = 14;

	// Bourse widgets (6 items x 3 buttons + 1 value text each)
	TextWidget m_CoursTxt[6];
	ButtonWidget m_CoursBtnMinus[6];
	ButtonWidget m_CoursBtnPlus[6];
	ButtonWidget m_CoursBtnReset[6];

	// Prix essence (row dediee en bas de l economie)
	TextWidget m_FuelPriceText;
	ButtonWidget m_BtnFuelMinus;
	ButtonWidget m_BtnFuelPlus;
	ButtonWidget m_BtnFuelReset;

	// === DONNEES RECUES DU SERVEUR (set par SetXxxData avant/apres OpenMenu) ===
	static ref array<int> s_PendingOnlinePlayerIds = new array<int>();
	static ref array<string> s_PendingOnlineNames = new array<string>();
	static ref array<string> s_PendingOnlineJobs = new array<string>();
	static ref array<int> s_PendingOnlineCapsules = new array<int>();
	static ref array<string> s_PendingRichestNames = new array<string>();
	static ref array<int> s_PendingRichestAmount = new array<int>();
	static ref array<string> s_PendingVehiclePlates = new array<string>();
	static ref array<string> s_PendingVehicleOwners = new array<string>();
	static ref array<string> s_PendingVehicleModels = new array<string>();
	static int s_PendingPlayerCount = 0;
	static int s_PendingVehicleCount = 0;
	static int s_PendingTotalMoney = 0;

	// Cours des 6 bourses (ROCK, WOOD, APPLE, CANNABIS, COCAINE, WHEAT)
	static int s_PendingCoursRock = 0;
	static int s_PendingCoursWood = 0;
	static int s_PendingCoursApple = 0;
	static int s_PendingCoursCannabis = 0;
	static int s_PendingCoursCocaine = 0;
	static int s_PendingCoursWheat = 0;
	static int s_PendingFuelPrice = 3;

	// Page actuellement affichee
	int m_CurrentPage = 0; // 0=Dashboard, 1=Players, 2=Vehicles, 3=Sanctions, 4=Reports, 5=Economy, 6=Tickets, 7=Settings

	//------------------------------------------------------------------------------------------------
	override void OnMenuOpen()
	{
		super.OnMenuOpen();
		JobFocusHandler.ClearRegistry();
		m_RootWidget = GetRootWidget();
		if (!m_RootWidget)
			return;

		// --- Headers ---
		m_PageTitle = TextWidget.Cast(m_RootWidget.FindAnyWidget("PageTitleText"));
		m_PageSubtitle = TextWidget.Cast(m_RootWidget.FindAnyWidget("PageSubtitleText"));
		m_BtnClose = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnClose"));

		// --- Sidebar ---
		m_NavDashboard = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("NavDashboard"));
		m_NavPlayers = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("NavPlayers"));
		m_NavVehicles = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("NavVehicles"));
		m_NavSanctions = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("NavSanctions"));
		m_NavReports = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("NavReports"));
		m_NavEconomy = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("NavEconomy"));
		m_NavTickets = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("NavTickets"));
		m_NavSettings = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("NavSettings"));

		// --- Pages (visibility toggled) ---
		m_PageDashboard = m_RootWidget.FindAnyWidget("PageDashboard");
		m_PagePlayers = m_RootWidget.FindAnyWidget("PagePlayers");
		m_PageVehicles = m_RootWidget.FindAnyWidget("PageVehicles");
		m_PageEconomy = m_RootWidget.FindAnyWidget("PageEconomy");
		m_PageReports = m_RootWidget.FindAnyWidget("PageReports");
		m_PagePlaceholder = m_RootWidget.FindAnyWidget("PagePlaceholder");
		m_PlaceholderText = TextWidget.Cast(m_RootWidget.FindAnyWidget("PlaceholderText"));
		m_EconomyRows = m_RootWidget.FindAnyWidget("EconomyRowsContainer");
		m_ReportsLogContainer = m_RootWidget.FindAnyWidget("ReportsLogContainer");
		m_ReportsBodyText = TextWidget.Cast(m_RootWidget.FindAnyWidget("ReportsBodyText"));

		// --- Stat cards ---
		m_StatPlayersValue = TextWidget.Cast(m_RootWidget.FindAnyWidget("StatPlayersValue"));
		m_StatVehiclesValue = TextWidget.Cast(m_RootWidget.FindAnyWidget("StatVehiclesValue"));
		m_StatMoneyValue = TextWidget.Cast(m_RootWidget.FindAnyWidget("StatMoneyValue"));

		// --- Containers ---
		m_DashboardPlayers = m_RootWidget.FindAnyWidget("DashboardPlayersContainer");
		m_RichestContainer = m_RootWidget.FindAnyWidget("RichestContainer");
		m_PlayersPage = m_RootWidget.FindAnyWidget("PlayersPageContainer");
		m_VehiclesPage = m_RootWidget.FindAnyWidget("VehiclesPageContainer");

		m_VehicleSearchBox = EditBoxWidget.Cast(m_RootWidget.FindAnyWidget("VehicleSearchBox"));
		m_BtnVehicleSearch = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnVehicleSearch"));

		// Recherche joueur
		m_PlayerSearchBox = EditBoxWidget.Cast(m_RootWidget.FindAnyWidget("PlayerSearchBox"));
		m_BtnPlayerSearch = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnPlayerSearch"));
		m_BtnPlayerClear = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnPlayerClear"));
		if (m_BtnPlayerSearch)
		{
			AdminPlayerSearchHandler psh = new AdminPlayerSearchHandler();
			psh.m_Menu = this;
			psh.m_Clear = false;
			m_BtnPlayerSearch.AddHandler(psh);
			JobFocusHandler.Attach(m_BtnPlayerSearch);
		}
		if (m_BtnPlayerClear)
		{
			AdminPlayerSearchHandler psc = new AdminPlayerSearchHandler();
			psc.m_Menu = this;
			psc.m_Clear = true;
			m_BtnPlayerClear.AddHandler(psc);
			JobFocusHandler.Attach(m_BtnPlayerClear);
		}
		m_BtnVehicleDeleteMode = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnVehicleDeleteMode"));
		m_BtnVehicleDeleteModeLabel = TextWidget.Cast(m_RootWidget.FindAnyWidget("BtnVehicleDeleteModeLabel"));
		m_VehicleStatusText = TextWidget.Cast(m_RootWidget.FindAnyWidget("VehicleStatusText"));

		// Pagination log
		m_BtnReportsPrev = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnReportsPrev"));
		m_BtnReportsNext = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnReportsNext"));
		m_ReportsPageText = TextWidget.Cast(m_RootWidget.FindAnyWidget("ReportsPageText"));
		if (m_BtnReportsPrev)
		{
			AdminReportsPageHandler ph = new AdminReportsPageHandler();
			ph.m_Menu = this;
			ph.m_Direction = -1;
			m_BtnReportsPrev.AddHandler(ph);
			JobFocusHandler.Attach(m_BtnReportsPrev);
		}
		if (m_BtnReportsNext)
		{
			AdminReportsPageHandler nh = new AdminReportsPageHandler();
			nh.m_Menu = this;
			nh.m_Direction = 1;
			m_BtnReportsNext.AddHandler(nh);
			JobFocusHandler.Attach(m_BtnReportsNext);
		}

		// Pagination gestion joueurs
		m_BtnPlayersPrev = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnPlayersPrev"));
		m_BtnPlayersNext = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnPlayersNext"));
		m_PlayersPageLabel = TextWidget.Cast(m_RootWidget.FindAnyWidget("PlayersPageLabel"));
		if (m_BtnPlayersPrev)
		{
			AdminPlayersPageHandler pph = new AdminPlayersPageHandler();
			pph.m_Menu = this; pph.m_Direction = -1;
			m_BtnPlayersPrev.AddHandler(pph);
			JobFocusHandler.Attach(m_BtnPlayersPrev);
		}
		if (m_BtnPlayersNext)
		{
			AdminPlayersPageHandler ppn = new AdminPlayersPageHandler();
			ppn.m_Menu = this; ppn.m_Direction = 1;
			m_BtnPlayersNext.AddHandler(ppn);
			JobFocusHandler.Attach(m_BtnPlayersNext);
		}

		// Pagination gestion vehicules
		m_BtnVehiclesPrev = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnVehiclesPrev"));
		m_BtnVehiclesNext = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnVehiclesNext"));
		m_VehiclesPageLabel = TextWidget.Cast(m_RootWidget.FindAnyWidget("VehiclesPageLabel"));
		if (m_BtnVehiclesPrev)
		{
			AdminVehiclesPageHandler vph = new AdminVehiclesPageHandler();
			vph.m_Menu = this; vph.m_Direction = -1;
			m_BtnVehiclesPrev.AddHandler(vph);
			JobFocusHandler.Attach(m_BtnVehiclesPrev);
		}
		if (m_BtnVehiclesNext)
		{
			AdminVehiclesPageHandler vpn = new AdminVehiclesPageHandler();
			vpn.m_Menu = this; vpn.m_Direction = 1;
			m_BtnVehiclesNext.AddHandler(vpn);
			JobFocusHandler.Attach(m_BtnVehiclesNext);
		}

		// === Bourses : bind des 6 lignes (CoursXxxText + 3 boutons) ===
		m_CoursTxt[0] = TextWidget.Cast(m_RootWidget.FindAnyWidget("CoursRockText"));
		m_CoursTxt[1] = TextWidget.Cast(m_RootWidget.FindAnyWidget("CoursWoodText"));
		m_CoursTxt[2] = TextWidget.Cast(m_RootWidget.FindAnyWidget("CoursAppleText"));
		m_CoursTxt[3] = TextWidget.Cast(m_RootWidget.FindAnyWidget("CoursCannabisText"));
		m_CoursTxt[4] = TextWidget.Cast(m_RootWidget.FindAnyWidget("CoursCocaineText"));
		m_CoursTxt[5] = TextWidget.Cast(m_RootWidget.FindAnyWidget("CoursWheatText"));

		m_CoursBtnMinus[0] = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnRockMinus"));
		m_CoursBtnMinus[1] = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnWoodMinus"));
		m_CoursBtnMinus[2] = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnAppleMinus"));
		m_CoursBtnMinus[3] = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnCannabisMinus"));
		m_CoursBtnMinus[4] = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnCocaineMinus"));
		m_CoursBtnMinus[5] = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnWheatMinus"));

		m_CoursBtnPlus[0] = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnRockPlus"));
		m_CoursBtnPlus[1] = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnWoodPlus"));
		m_CoursBtnPlus[2] = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnApplePlus"));
		m_CoursBtnPlus[3] = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnCannabisPlus"));
		m_CoursBtnPlus[4] = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnCocainePlus"));
		m_CoursBtnPlus[5] = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnWheatPlus"));

		m_CoursBtnReset[0] = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnRockReset"));
		m_CoursBtnReset[1] = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnWoodReset"));
		m_CoursBtnReset[2] = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnAppleReset"));
		m_CoursBtnReset[3] = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnCannabisReset"));
		m_CoursBtnReset[4] = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnCocaineReset"));
		m_CoursBtnReset[5] = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnWheatReset"));

		// EMarketItem enum : NONE=0, ROCK=1, WOOD=2, APPLE=3, CANNABIS=4, COCAINE=5, WHEAT=6
		// Donc itemType = bi + 1 (bi=0 -> ROCK, bi=5 -> WHEAT)
		for (int bi = 0; bi < 6; bi++)
		{
			int enumVal = bi + 1;
			AttachCoursButton(m_CoursBtnMinus[bi], enumVal, -5);
			AttachCoursButton(m_CoursBtnPlus[bi], enumVal, 5);
			AttachCoursButton(m_CoursBtnReset[bi], enumVal, 0);
		}

		// Prix essence (row dediee)
		m_FuelPriceText = TextWidget.Cast(m_RootWidget.FindAnyWidget("FuelPriceText"));
		m_BtnFuelMinus = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnFuelMinus"));
		m_BtnFuelPlus = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnFuelPlus"));
		m_BtnFuelReset = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnFuelReset"));
		AttachFuelButton(m_BtnFuelMinus, -1);
		AttachFuelButton(m_BtnFuelPlus, 1);
		AttachFuelButton(m_BtnFuelReset, 0);

		// --- Bind handlers ---
		AttachNavButton(m_NavDashboard, 0);
		AttachNavButton(m_NavPlayers, 1);
		AttachNavButton(m_NavVehicles, 2);
		AttachNavButton(m_NavSanctions, 3);
		AttachNavButton(m_NavReports, 4);
		AttachNavButton(m_NavEconomy, 5);
		AttachNavButton(m_NavTickets, 6);
		AttachNavButton(m_NavSettings, 7);

		if (m_BtnClose)
		{
			AdminMenuCloseHandler ch = new AdminMenuCloseHandler();
			ch.m_Menu = this;
			m_BtnClose.AddHandler(ch);
			JobFocusHandler.Attach(m_BtnClose);
		}

		if (m_BtnVehicleSearch)
		{
			AdminVehicleSearchHandler sh = new AdminVehicleSearchHandler();
			sh.m_Menu = this;
			m_BtnVehicleSearch.AddHandler(sh);
			JobFocusHandler.Attach(m_BtnVehicleSearch);
		}
		if (m_BtnVehicleDeleteMode)
		{
			AdminVehicleDeleteModeToggleHandler dh = new AdminVehicleDeleteModeToggleHandler();
			dh.m_Menu = this;
			m_BtnVehicleDeleteMode.AddHandler(dh);
			JobFocusHandler.Attach(m_BtnVehicleDeleteMode);
		}

		// Affiche la page par defaut
		SwitchToPage(0);

		// Demande les donnees au serveur
		RequestDashboardData();

		// Focus initial sidebar pour la nav manette (DPad bas descend la sidebar, DPad droit entre dans le contenu)
		if (m_NavDashboard)
			GetGame().GetWorkspace().SetFocusedWidget(m_NavDashboard);
	}

	//------------------------------------------------------------------------------------------------
	override void OnMenuUpdate(float tDelta)
	{
		super.OnMenuUpdate(tDelta);
		if (GetGame().GetInputManager().GetActionValue("MenuBack") > 0.5)
			CloseMenuInternal();
	}

	//------------------------------------------------------------------------------------------------
	void AttachNavButton(ButtonWidget btn, int page)
	{
		if (!btn)
			return;
		AdminNavHandler h = new AdminNavHandler();
		h.m_Menu = this;
		h.m_PageIndex = page;
		btn.AddHandler(h);
		JobFocusHandler.Attach(btn);
	}

	//------------------------------------------------------------------------------------------------
	// Nav manette : apres un switch, pousse le focus sur le premier bouton actionnable de la nouvelle
	// page pour que DPad gauche/droite marche sans que le joueur reste coince sur la sidebar.
	//------------------------------------------------------------------------------------------------
	void FocusFirstPageButton(int page)
	{
		Widget target = null;
		if (page == 1 && m_BtnPlayerSearch) target = m_BtnPlayerSearch;      // Gestion joueurs
		else if (page == 2 && m_BtnVehicleSearch) target = m_BtnVehicleSearch; // Gestion vehicules
		else if (page == 4 && m_BtnReportsPrev) target = m_BtnReportsPrev;    // Rapports
		else if (page == 5 && m_BtnFuelMinus) target = m_BtnFuelMinus;        // Economie (premier bouton)
		else if (page == 0 && m_BtnClose) target = m_BtnClose;                // Dashboard : bouton Fermer
		if (target && target.IsVisible())
			GetGame().GetWorkspace().SetFocusedWidget(target);
	}

	//------------------------------------------------------------------------------------------------
	void SwitchToPage(int page)
	{
		m_CurrentPage = page;

		if (m_PageDashboard) m_PageDashboard.SetVisible(page == 0);
		if (m_PagePlayers) m_PagePlayers.SetVisible(page == 1);
		if (m_PageVehicles) m_PageVehicles.SetVisible(page == 2);
		if (m_PageEconomy) m_PageEconomy.SetVisible(page == 5);
		if (m_PageReports) m_PageReports.SetVisible(page == 4);

		// Placeholder : seulement pour Sanctions(3), Tickets(6), Parametres(7)
		bool isPlaceholder = (page == 3 || page == 6 || page == 7);
		if (m_PagePlaceholder) m_PagePlaceholder.SetVisible(isPlaceholder);

		// Reset couleurs sidebar
		SetNavActive(m_NavDashboard, page == 0);
		SetNavActive(m_NavPlayers, page == 1);
		SetNavActive(m_NavVehicles, page == 2);
		SetNavActive(m_NavSanctions, page == 3);
		SetNavActive(m_NavReports, page == 4);
		SetNavActive(m_NavEconomy, page == 5);
		SetNavActive(m_NavTickets, page == 6);
		SetNavActive(m_NavSettings, page == 7);

		// Titres
		if (m_PageTitle && m_PageSubtitle)
		{
			if (page == 0)
			{
				m_PageTitle.SetText("TABLEAU DE BORD");
				m_PageSubtitle.SetText("Vue d'ensemble du serveur.");
			}
			else if (page == 1)
			{
				m_PageTitle.SetText("GESTION DES JOUEURS");
				m_PageSubtitle.SetText("Liste detaillee des joueurs connectes. Cliquez pour ouvrir la fiche.");
			}
			else if (page == 2)
			{
				m_PageTitle.SetText("GESTION DES VEHICULES");
				m_PageSubtitle.SetText("Tous les vehicules dans les garages virtuels. Recherche par plaque, modele ou proprietaire.");
			}
			else if (page == 3)
			{
				m_PageTitle.SetText("GESTION DES SANCTIONS");
				m_PageSubtitle.SetText("Section a venir.");
				if (m_PlaceholderText)
					m_PlaceholderText.SetText("Section Sanctions en cours de developpement.");
			}
			else if (page == 4)
			{
				m_PageTitle.SetText("RAPPORTS & LOGS");
				m_PageSubtitle.SetText("Section a venir.");
				if (m_PlaceholderText)
					m_PlaceholderText.SetText("Section Rapports en cours de developpement.");
			}
			else if (page == 5)
			{
				m_PageTitle.SetText("ECONOMIE");
				m_PageSubtitle.SetText("Section a venir.");
				if (m_PlaceholderText)
					m_PlaceholderText.SetText("Section Economie en cours de developpement.");
			}
			else if (page == 6)
			{
				m_PageTitle.SetText("SUPPORT TICKETS");
				m_PageSubtitle.SetText("Section a venir.");
				if (m_PlaceholderText)
					m_PlaceholderText.SetText("Section Tickets en cours de developpement.");
			}
			else if (page == 7)
			{
				m_PageTitle.SetText("PARAMETRES");
				m_PageSubtitle.SetText("Section a venir.");
				if (m_PlaceholderText)
					m_PlaceholderText.SetText("Section Parametres en cours de developpement.");
			}
		}

		// Refresh de la page si besoin
		if (page == 2)
			RequestVehiclesList("");
		else if (page == 5)
			RequestCoursData();
		else if (page == 4)
			BuildReportsPage();
	}

	//------------------------------------------------------------------------------------------------
	void SetNavActive(ButtonWidget btn, bool active)
	{
		if (!btn)
			return;
		if (active)
			btn.SetColor(Color.FromRGBA(36, 28, 66, 255));
		else
			btn.SetColor(Color.FromRGBA(20, 25, 40, 255));
	}

	//------------------------------------------------------------------------------------------------
	void RequestDashboardData()
	{
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		jpc.ClientAskAdminDashboard();
	}

	//------------------------------------------------------------------------------------------------
	void RequestVehiclesList(string filter)
	{
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		jpc.ClientAskAdminVehiclesList(filter);
	}

	//------------------------------------------------------------------------------------------------
	void RequestCoursData()
	{
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		jpc.ClientAskAdminGetCours();
	}

	//------------------------------------------------------------------------------------------------
	// Attache un handler bouton bourse : (itemIndex, delta) -> envoi RPC
	//------------------------------------------------------------------------------------------------
	void AttachCoursButton(ButtonWidget btn, int itemIndex, int delta)
	{
		if (!btn) return;
		AdminCoursButtonHandler h = new AdminCoursButtonHandler();
		h.m_Menu = this;
		h.m_ItemIndex = itemIndex;
		h.m_Delta = delta;
		btn.AddHandler(h);
		JobFocusHandler.Attach(btn);
	}

	void AttachFuelButton(ButtonWidget btn, int delta)
	{
		if (!btn) return;
		AdminFuelPriceHandler h = new AdminFuelPriceHandler();
		h.m_Menu = this;
		h.m_Delta = delta;
		btn.AddHandler(h);
		JobFocusHandler.Attach(btn);
	}

	//------------------------------------------------------------------------------------------------
	// Rafraichit les 6 TextWidgets de cours + le prix essence avec les valeurs serveur
	//------------------------------------------------------------------------------------------------
	void ApplyCoursData()
	{
		int values[6];
		values[0] = s_PendingCoursRock;
		values[1] = s_PendingCoursWood;
		values[2] = s_PendingCoursApple;
		values[3] = s_PendingCoursCannabis;
		values[4] = s_PendingCoursCocaine;
		values[5] = s_PendingCoursWheat;

		for (int i = 0; i < 6; i++)
		{
			if (!m_CoursTxt[i]) continue;
			int v = values[i];
			string sign = "+";
			if (v < 0) sign = "";
			m_CoursTxt[i].SetText("Cours : " + sign + v.ToString() + "%");
		}

		if (m_FuelPriceText)
		{
			m_FuelPriceText.SetText(string.Format("Prix : %1 caps/L (min 1 - max 5)",
				s_PendingFuelPrice.ToString()));
		}
	}

	//------------------------------------------------------------------------------------------------
	// Envoye par les boutons essence
	//------------------------------------------------------------------------------------------------
	void SendFuelPriceChange(int delta)
	{
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		jpc.ClientAskAdminSetFuelPrice(delta);
	}

	//------------------------------------------------------------------------------------------------
	// Appele par le handler des boutons bourse : envoie l action au serveur
	//------------------------------------------------------------------------------------------------
	void SendCoursChange(int itemType, int delta)
	{
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		jpc.ClientAskAdminSetCours(itemType, delta);
	}

	//------------------------------------------------------------------------------------------------
	// Toggle du mode suppression dans la page Vehicules
	//------------------------------------------------------------------------------------------------
	void ToggleDeleteMode()
	{
		m_DeleteModeOn = !m_DeleteModeOn;
		if (m_BtnVehicleDeleteModeLabel)
		{
			if (m_DeleteModeOn)
				m_BtnVehicleDeleteModeLabel.SetText("Mode suppression : ON (clic sur un vehicule pour supprimer)");
			else
				m_BtnVehicleDeleteModeLabel.SetText("Mode suppression : OFF");
		}
		if (m_BtnVehicleDeleteMode)
		{
			if (m_DeleteModeOn)
				m_BtnVehicleDeleteMode.SetColor(Color.FromRGBA(180, 50, 50, 255));
			else
				m_BtnVehicleDeleteMode.SetColor(Color.FromRGBA(90, 90, 115, 255));
		}
	}

	bool IsDeleteModeOn() { return m_DeleteModeOn; }

	//------------------------------------------------------------------------------------------------
	// Clic sur un vehicule en mode suppression : premier clic = demande confirmation,
	// second clic (dans les 4s) sur le MEME vehicule = suppression effective.
	// Autre clic entre temps = annule la demande.
	//------------------------------------------------------------------------------------------------
	void RequestDeleteVehicle(int vehicleIndex, string ownerName, string model)
	{
		if (m_PendingDeleteIndex == vehicleIndex)
		{
			// Deuxieme clic sur le meme vehicule -> confirmation !
			SendDeleteVehicle(vehicleIndex);
			m_PendingDeleteIndex = -1;
			if (m_VehicleStatusText)
				m_VehicleStatusText.SetText(string.Format("Vehicule #%1 supprime.", vehicleIndex.ToString()));
			// Clear le message apres 3s
			GetGame().GetCallqueue().CallLater(ClearVehicleStatus, 3000, false);
			// Rafraichit la liste
			GetGame().GetCallqueue().CallLater(RefreshVehiclesList, 500, false);
		}
		else
		{
			// Premier clic -> demande confirmation
			m_PendingDeleteIndex = vehicleIndex;
			if (m_VehicleStatusText)
				m_VehicleStatusText.SetText(string.Format(
					"ATTENTION : Confirmer suppression de %1 (proprio %2) ? Cliquez une 2eme fois sur la meme ligne dans les 4 secondes.",
					model, ownerName));
			// Expire la confirmation apres 4s
			GetGame().GetCallqueue().CallLater(CancelPendingDelete, 4000, false);
		}
	}

	void CancelPendingDelete()
	{
		m_PendingDeleteIndex = -1;
		if (m_VehicleStatusText)
			m_VehicleStatusText.SetText("Confirmation expiree. Cliquez a nouveau pour recommencer.");
		GetGame().GetCallqueue().CallLater(ClearVehicleStatus, 2000, false);
	}

	void ClearVehicleStatus()
	{
		if (m_VehicleStatusText) m_VehicleStatusText.SetText("");
	}

	void RefreshVehiclesList()
	{
		string filter = "";
		if (m_VehicleSearchBox) filter = m_VehicleSearchBox.GetText();
		RequestVehiclesList(filter);
	}

	void SendDeleteVehicle(int vehicleIndex)
	{
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		jpc.ClientAskAdminDeleteVehicle(vehicleIndex);
	}

	//------------------------------------------------------------------------------------------------
	// Pagination : clic sur bouton Precedent / Suivant du journal admin
	//------------------------------------------------------------------------------------------------
	void OnReportsPageChange(int direction)
	{
		int total = s_PendingAdminLog.Count();
		int maxPage = (total - 1) / REPORTS_PER_PAGE;
		if (maxPage < 0) maxPage = 0;

		int newPage = m_ReportsCurrentPage + direction;
		if (newPage < 0) newPage = 0;
		if (newPage > maxPage) newPage = maxPage;
		m_ReportsCurrentPage = newPage;
		BuildReportsPage();
	}

	//------------------------------------------------------------------------------------------------
	// Journal d actions admin (serveur -> client)
	//------------------------------------------------------------------------------------------------
	static ref array<string> s_PendingAdminLog = new array<string>();

	static void SetAdminLogPending(array<string> entries)
	{
		s_PendingAdminLog.Clear();
		if (entries) foreach (string e : entries) s_PendingAdminLog.Insert(e);
	}

	static void NotifyAdminLogReady()
	{
		JobAdminMenu menu = GetOpenMenu();
		if (menu) menu.BuildReportsPage();
	}

	//------------------------------------------------------------------------------------------------
	// Page Rapports : stats globales serveur + journal des actions admin (ring buffer serveur)
	//------------------------------------------------------------------------------------------------
	void BuildReportsPage()
	{
		if (!m_ReportsBodyText) return;

		int onlineCount = s_PendingOnlinePlayerIds.Count();
		int vehCount = s_PendingVehicleCount;
		int totalMoney = s_PendingTotalMoney;
		int richestCount = s_PendingRichestNames.Count();

		string body = string.Format("Joueurs connectes : %1\nComptes bancaires persistes : %2\nVehicules dans garages virtuels : %3\nCapsules en circulation (liquide + banque) : %4",
			onlineCount.ToString(),
			richestCount.ToString(),
			vehCount.ToString(),
			FormatMoney(totalMoney));

		m_ReportsBodyText.SetText(body);

		// Demande au serveur les dernieres actions admin
		PlayerController pc = GetGame().GetPlayerController();
		if (pc)
		{
			JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
			if (jpc) jpc.ClientAskAdminGetActionLog();
		}

		// Affiche la PAGE courante du log (REPORTS_PER_PAGE entrees)
		if (m_ReportsLogContainer)
		{
			ClearChildren(m_ReportsLogContainer);
			WorkspaceWidget ws = GetGame().GetWorkspace();
			if (!ws) return;

			int logCount = s_PendingAdminLog.Count();
			if (logCount == 0)
			{
				Widget note = ws.CreateWidgets(ROW_LAYOUT_PATH, m_ReportsLogContainer);
				if (note) FillRowCols(note, "i", "Aucune action admin enregistree.", "", "");
				if (m_ReportsPageText) m_ReportsPageText.SetText("Page 1 / 1");
				return;
			}

			int totalPages = (logCount - 1) / REPORTS_PER_PAGE + 1;
			if (m_ReportsCurrentPage >= totalPages) m_ReportsCurrentPage = totalPages - 1;
			if (m_ReportsCurrentPage < 0) m_ReportsCurrentPage = 0;

			int startIdx = m_ReportsCurrentPage * REPORTS_PER_PAGE;
			int endIdx = startIdx + REPORTS_PER_PAGE;
			if (endIdx > logCount) endIdx = logCount;

			for (int li = startIdx; li < endIdx; li++)
			{
				Widget row = ws.CreateWidgets(ROW_LAYOUT_PATH, m_ReportsLogContainer);
				if (row)
				{
					int rankLog = li + 1;
					// Texte long -> ColMiddle (flex), ColName reste court pour pas clipper
					FillRowCols(row, rankLog.ToString(), "", s_PendingAdminLog.Get(li), "");
				}
			}

			if (m_ReportsPageText)
			{
				int displayPage = m_ReportsCurrentPage + 1;
				m_ReportsPageText.SetText(string.Format("Page %1 / %2",
					displayPage.ToString(), totalPages.ToString()));
			}
		}
	}

	//------------------------------------------------------------------------------------------------
	void OnVehicleSearchClicked()
	{
		string filter = "";
		if (m_VehicleSearchBox)
			filter = m_VehicleSearchBox.GetText();
		// Reset de la pagination quand un nouveau filtre est applique
		m_VehiclesCurrentPage = 0;
		RequestVehiclesList(filter);
	}

	//------------------------------------------------------------------------------------------------
	// Receive dashboard data from server and render all widgets
	//------------------------------------------------------------------------------------------------
	void ApplyDashboardData()
	{
		// Stat cards
		if (m_StatPlayersValue)
			m_StatPlayersValue.SetText(string.Format("%1 / 128", s_PendingPlayerCount.ToString()));
		if (m_StatVehiclesValue)
			m_StatVehiclesValue.SetText(s_PendingVehicleCount.ToString());
		if (m_StatMoneyValue)
			m_StatMoneyValue.SetText(FormatMoney(s_PendingTotalMoney));

		// Online players (dashboard quick view : top 10)
		BuildOnlinePlayersList(m_DashboardPlayers, 10, false);
		// Online players (full page)
		BuildOnlinePlayersList(m_PlayersPage, 128, true);

		// Top richest
		BuildRichestList();
	}

	//------------------------------------------------------------------------------------------------
	// Helper : rempli une row du layout JobAdminRowEntry (ColId / ColName / ColMiddle / ColRight)
	void FillRowCols(Widget row, string colId, string colName, string colMiddle, string colRight)
	{
		if (!row) return;
		TextWidget ti = TextWidget.Cast(row.FindAnyWidget("ColId"));
		TextWidget tn = TextWidget.Cast(row.FindAnyWidget("ColName"));
		TextWidget tm = TextWidget.Cast(row.FindAnyWidget("ColMiddle"));
		TextWidget tr = TextWidget.Cast(row.FindAnyWidget("ColRight"));
		if (ti) ti.SetText(colId);
		if (tn) tn.SetText(colName);
		if (tm) tm.SetText(colMiddle);
		if (tr) tr.SetText(colRight);
	}

	// applyFilter : true -> applique m_PlayerFilter (case-insensitive sur nom RP)
	// Si applyFilter == true, pagine aussi : PLAYERS_PER_PAGE lignes par page basees sur m_PlayersCurrentPage.
	void BuildOnlinePlayersList(Widget container, int maxRows, bool applyFilter)
	{
		if (!container)
			return;
		ClearChildren(container);
		WorkspaceWidget ws = GetGame().GetWorkspace();
		if (!ws)
			return;

		int totalCount = s_PendingOnlinePlayerIds.Count();
		string filterLow = "";
		if (applyFilter && m_PlayerFilter != "")
			filterLow = LowerAscii(m_PlayerFilter);

		// 1. Collecte les indices passant le filtre
		array<int> filteredIdx = new array<int>();
		for (int i = 0; i < totalCount; i++)
		{
			string nm = s_PendingOnlineNames.Get(i);
			if (filterLow != "")
			{
				string nmLow = LowerAscii(nm);
				if (nmLow.IndexOf(filterLow) < 0) continue;
			}
			filteredIdx.Insert(i);
		}

		int filteredCount = filteredIdx.Count();
		int startIdx = 0;
		int endIdx = filteredCount;

		// 2. Si on est sur la page pleine (applyFilter), applique la pagination
		if (applyFilter)
		{
			int totalPages = (filteredCount + PLAYERS_PER_PAGE - 1) / PLAYERS_PER_PAGE;
			if (totalPages < 1) totalPages = 1;
			if (m_PlayersCurrentPage >= totalPages) m_PlayersCurrentPage = totalPages - 1;
			if (m_PlayersCurrentPage < 0) m_PlayersCurrentPage = 0;
			startIdx = m_PlayersCurrentPage * PLAYERS_PER_PAGE;
			endIdx = startIdx + PLAYERS_PER_PAGE;
			if (endIdx > filteredCount) endIdx = filteredCount;
			if (m_PlayersPageLabel)
				m_PlayersPageLabel.SetText("Page " + (m_PlayersCurrentPage + 1).ToString() + " / " + totalPages.ToString());
		}
		else
		{
			// Dashboard quick view : garde l ancien comportement limite par maxRows
			if (endIdx > maxRows) endIdx = maxRows;
		}

		// 3. Construit les lignes du slice
		int rankNum = startIdx;
		for (int si = startIdx; si < endIdx; si++)
		{
			int realIdx = filteredIdx.Get(si);
			string nmR = s_PendingOnlineNames.Get(realIdx);
			Widget row = ws.CreateWidgets(ROW_LAYOUT_PATH, container);
			if (!row)
				continue;
			rankNum = rankNum + 1;
			FillRowCols(row,
				rankNum.ToString(),
				nmR,
				s_PendingOnlineJobs.Get(realIdx),
				FormatMoney(s_PendingOnlineCapsules.Get(realIdx)) + " caps");

			ButtonWidget rowBtn = ButtonWidget.Cast(row.FindAnyWidget("RowButton"));
			if (rowBtn)
			{
				AdminRowOpenPlayerHandler ph = new AdminRowOpenPlayerHandler();
				ph.m_PlayerId = s_PendingOnlinePlayerIds.Get(realIdx);
				ph.m_DisplayName = nmR;
				rowBtn.AddHandler(ph);
				JobFocusHandler.Attach(rowBtn);
			}
		}
	}

	//------------------------------------------------------------------------------------------------
	// Change la page de la gestion joueurs et rebuild la liste
	//------------------------------------------------------------------------------------------------
	void ChangePlayersPage(int direction)
	{
		m_PlayersCurrentPage = m_PlayersCurrentPage + direction;
		if (m_PlayersCurrentPage < 0) m_PlayersCurrentPage = 0;
		BuildOnlinePlayersList(m_PlayersPage, 128, true);
	}

	//------------------------------------------------------------------------------------------------
	// Helper : lowercase ASCII (Enforce n a pas de ToLower natif)
	//------------------------------------------------------------------------------------------------
	string LowerAscii(string s)
	{
		string r = "";
		int slen = s.Length();
		for (int li = 0; li < slen; li++)
		{
			string c = s.Substring(li, 1);
			if (c == "A") r = r + "a";
			else if (c == "B") r = r + "b";
			else if (c == "C") r = r + "c";
			else if (c == "D") r = r + "d";
			else if (c == "E") r = r + "e";
			else if (c == "F") r = r + "f";
			else if (c == "G") r = r + "g";
			else if (c == "H") r = r + "h";
			else if (c == "I") r = r + "i";
			else if (c == "J") r = r + "j";
			else if (c == "K") r = r + "k";
			else if (c == "L") r = r + "l";
			else if (c == "M") r = r + "m";
			else if (c == "N") r = r + "n";
			else if (c == "O") r = r + "o";
			else if (c == "P") r = r + "p";
			else if (c == "Q") r = r + "q";
			else if (c == "R") r = r + "r";
			else if (c == "S") r = r + "s";
			else if (c == "T") r = r + "t";
			else if (c == "U") r = r + "u";
			else if (c == "V") r = r + "v";
			else if (c == "W") r = r + "w";
			else if (c == "X") r = r + "x";
			else if (c == "Y") r = r + "y";
			else if (c == "Z") r = r + "z";
			else r = r + c;
		}
		return r;
	}

	//------------------------------------------------------------------------------------------------
	// Appele par les boutons "Rechercher" / "Reset" de la page Gestion des joueurs
	//------------------------------------------------------------------------------------------------
	void OnPlayerSearchClicked(bool clearFilter)
	{
		if (clearFilter)
		{
			m_PlayerFilter = "";
			if (m_PlayerSearchBox) m_PlayerSearchBox.SetText("");
		}
		else
		{
			if (m_PlayerSearchBox) m_PlayerFilter = m_PlayerSearchBox.GetText();
		}
		// Reset de la pagination quand le filtre change (sinon on peut etre sur une page qui n existe plus)
		m_PlayersCurrentPage = 0;
		BuildOnlinePlayersList(m_PlayersPage, 128, true);
	}

	//------------------------------------------------------------------------------------------------
	void BuildRichestList()
	{
		if (!m_RichestContainer)
			return;
		ClearChildren(m_RichestContainer);
		WorkspaceWidget ws = GetGame().GetWorkspace();
		if (!ws)
			return;

		int count = s_PendingRichestNames.Count();
		for (int i = 0; i < count; i++)
		{
			Widget row = ws.CreateWidgets(ROW_LAYOUT_PATH, m_RichestContainer);
			if (!row)
				continue;

			int rankR = i + 1;
			string nameAndAmount = string.Format("%1  -  %2 caps",
				s_PendingRichestNames.Get(i),
				FormatMoney(s_PendingRichestAmount.Get(i)));
			FillRowCols(row,
				rankR.ToString(),
				nameAndAmount,
				"",
				"");

			// Clic : si le joueur est connecte, ouvre sa fiche admin
			ButtonWidget rowBtn = ButtonWidget.Cast(row.FindAnyWidget("RowButton"));
			if (rowBtn)
			{
				AdminRichestRowHandler rh = new AdminRichestRowHandler();
				rh.m_DisplayName = s_PendingRichestNames.Get(i);
				rowBtn.AddHandler(rh);
				JobFocusHandler.Attach(rowBtn);
			}
		}
	}

	//------------------------------------------------------------------------------------------------
	void ApplyVehiclesData()
	{
		if (!m_VehiclesPage)
			return;
		ClearChildren(m_VehiclesPage);
		WorkspaceWidget ws = GetGame().GetWorkspace();
		if (!ws)
			return;

		int count = s_PendingVehiclePlates.Count();
		int totalPages = (count + VEHICLES_PER_PAGE - 1) / VEHICLES_PER_PAGE;
		if (totalPages < 1) totalPages = 1;
		if (m_VehiclesCurrentPage >= totalPages) m_VehiclesCurrentPage = totalPages - 1;
		if (m_VehiclesCurrentPage < 0) m_VehiclesCurrentPage = 0;

		int startIdx = m_VehiclesCurrentPage * VEHICLES_PER_PAGE;
		int endIdx = startIdx + VEHICLES_PER_PAGE;
		if (endIdx > count) endIdx = count;

		for (int i = startIdx; i < endIdx; i++)
		{
			Widget row = ws.CreateWidgets(ROW_LAYOUT_PATH, m_VehiclesPage);
			if (!row)
				continue;

			FillRowCols(row,
				s_PendingVehiclePlates.Get(i),
				s_PendingVehicleModels.Get(i),
				"Prop: " + s_PendingVehicleOwners.Get(i),
				"");

			// Clic sur ligne vehicule : si mode suppression ON -> delete, sinon -> fiche
			ButtonWidget rowBtn = ButtonWidget.Cast(row.FindAnyWidget("RowButton"));
			if (rowBtn)
			{
				AdminVehicleRowHandler vh = new AdminVehicleRowHandler();
				vh.m_Menu = this;
				vh.m_OwnerName = s_PendingVehicleOwners.Get(i);
				vh.m_VehicleModel = s_PendingVehicleModels.Get(i);
				vh.m_VehicleIndex = ExtractIndexFromPlate(s_PendingVehiclePlates.Get(i));
				rowBtn.AddHandler(vh);
				JobFocusHandler.Attach(rowBtn);
			}
		}

		if (m_VehiclesPageLabel)
			m_VehiclesPageLabel.SetText("Page " + (m_VehiclesCurrentPage + 1).ToString() + " / " + totalPages.ToString());
	}

	//------------------------------------------------------------------------------------------------
	// Change la page de la gestion vehicules et rebuild la liste
	//------------------------------------------------------------------------------------------------
	void ChangeVehiclesPage(int direction)
	{
		m_VehiclesCurrentPage = m_VehiclesCurrentPage + direction;
		if (m_VehiclesCurrentPage < 0) m_VehiclesCurrentPage = 0;
		ApplyVehiclesData();
	}

	//------------------------------------------------------------------------------------------------
	// Convertit "#42" en 42 (notre convention pour les plates vehicules)
	//------------------------------------------------------------------------------------------------
	int ExtractIndexFromPlate(string plate)
	{
		if (plate.Length() < 2) return -1;
		if (plate.Substring(0, 1) != "#") return -1;
		string num = plate.Substring(1, plate.Length() - 1);
		return num.ToInt();
	}

	//------------------------------------------------------------------------------------------------
	// Helpers
	//------------------------------------------------------------------------------------------------
	void ClearChildren(Widget container)
	{
		if (!container) return;
		Widget child = container.GetChildren();
		while (child)
		{
			Widget next = child.GetSibling();
			child.RemoveFromHierarchy();
			child = next;
		}
	}

	string FormatMoney(int amount)
	{
		if (amount < 1000)
			return amount.ToString();
		int k = amount / 1000;
		int rest = amount - (k * 1000);
		string restStr = rest.ToString();
		while (restStr.Length() < 3)
			restStr = "0" + restStr;
		return k.ToString() + "," + restStr;
	}

	//------------------------------------------------------------------------------------------------
	void CloseMenuInternal()
	{
		GetGame().GetMenuManager().CloseMenu(this);
	}

	//------------------------------------------------------------------------------------------------
	// Static entry points for server-pushed data
	//------------------------------------------------------------------------------------------------
	static void SetDashboardPendingData(int playerCount, int vehicleCount, int totalMoney)
	{
		s_PendingPlayerCount = playerCount;
		s_PendingVehicleCount = vehicleCount;
		s_PendingTotalMoney = totalMoney;
	}

	static void SetOnlinePlayersPendingData(array<int> ids, array<string> names, array<string> jobs, array<int> caps)
	{
		s_PendingOnlinePlayerIds.Clear();
		s_PendingOnlineNames.Clear();
		s_PendingOnlineJobs.Clear();
		s_PendingOnlineCapsules.Clear();
		if (ids) foreach (int pid : ids) s_PendingOnlinePlayerIds.Insert(pid);
		if (names) foreach (string n : names) s_PendingOnlineNames.Insert(n);
		if (jobs) foreach (string j : jobs) s_PendingOnlineJobs.Insert(j);
		if (caps) foreach (int c : caps) s_PendingOnlineCapsules.Insert(c);
	}

	static void SetRichestPendingData(array<string> names, array<int> amounts)
	{
		s_PendingRichestNames.Clear();
		s_PendingRichestAmount.Clear();
		if (names) foreach (string n : names) s_PendingRichestNames.Insert(n);
		if (amounts) foreach (int a : amounts) s_PendingRichestAmount.Insert(a);
	}

	static void SetVehiclesPendingData(array<string> plates, array<string> owners, array<string> models)
	{
		s_PendingVehiclePlates.Clear();
		s_PendingVehicleOwners.Clear();
		s_PendingVehicleModels.Clear();
		if (plates) foreach (string p : plates) s_PendingVehiclePlates.Insert(p);
		if (owners) foreach (string o : owners) s_PendingVehicleOwners.Insert(o);
		if (models) foreach (string m : models) s_PendingVehicleModels.Insert(m);
	}

	static void SetCoursPendingData(int rock, int wood, int apple, int cannabis, int cocaine, int wheat)
	{
		s_PendingCoursRock = rock;
		s_PendingCoursWood = wood;
		s_PendingCoursApple = apple;
		s_PendingCoursCannabis = cannabis;
		s_PendingCoursCocaine = cocaine;
		s_PendingCoursWheat = wheat;
	}

	static void NotifyCoursReady()
	{
		JobAdminMenu menu = GetOpenMenu();
		if (menu)
			menu.ApplyCoursData();
	}

	static void SetFuelPricePending(int price)
	{
		s_PendingFuelPrice = price;
	}

	//------------------------------------------------------------------------------------------------
	// Called from client-side RPC handlers after SetXxxPendingData
	//------------------------------------------------------------------------------------------------
	static JobAdminMenu GetOpenMenu()
	{
		MenuManager mm = GetGame().GetMenuManager();
		if (!mm) return null;
		return JobAdminMenu.Cast(mm.FindMenuByPreset(ChimeraMenuPreset.JobAdminMenu));
	}

	static void NotifyDashboardReady()
	{
		JobAdminMenu menu = GetOpenMenu();
		if (menu)
			menu.ApplyDashboardData();
	}

	static void NotifyVehiclesReady()
	{
		JobAdminMenu menu = GetOpenMenu();
		if (menu)
			menu.ApplyVehiclesData();
	}
}

//------------------------------------------------------------------------------------------------
class AdminMenuCloseHandler : ScriptedWidgetEventHandler
{
	JobAdminMenu m_Menu;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.CloseMenuInternal();
		return true;
	}
}

//------------------------------------------------------------------------------------------------
class AdminNavHandler : ScriptedWidgetEventHandler
{
	JobAdminMenu m_Menu;
	int m_PageIndex;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu)
		{
			m_Menu.SwitchToPage(m_PageIndex);
			// Nav manette : pousse le focus sur le premier bouton actionnable de la page cible
			m_Menu.FocusFirstPageButton(m_PageIndex);
		}
		return true;
	}
}

//------------------------------------------------------------------------------------------------
class AdminVehicleSearchHandler : ScriptedWidgetEventHandler
{
	JobAdminMenu m_Menu;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.OnVehicleSearchClicked();
		return true;
	}
}

//------------------------------------------------------------------------------------------------
class AdminRowOpenPlayerHandler : ScriptedWidgetEventHandler
{
	int m_PlayerId;
	string m_DisplayName;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		// Ouvre la fiche admin du joueur cible (reuse de l existant)
		JobAdminPlayerMenu menu = JobAdminPlayerMenu.Cast(
			GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.JobAdminPlayerMenu));
		if (menu)
			menu.Initialize(m_PlayerId, m_DisplayName);
		return true;
	}
}

//------------------------------------------------------------------------------------------------
// Handler bouton bourse : (itemIndex, delta) -> envoi au serveur
//------------------------------------------------------------------------------------------------
class AdminCoursButtonHandler : ScriptedWidgetEventHandler
{
	JobAdminMenu m_Menu;
	int m_ItemIndex;
	int m_Delta;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu)
			m_Menu.SendCoursChange(m_ItemIndex, m_Delta);
		return true;
	}
}

//------------------------------------------------------------------------------------------------
// Handler bouton prix essence : (delta) -> envoi au serveur
//------------------------------------------------------------------------------------------------
class AdminFuelPriceHandler : ScriptedWidgetEventHandler
{
	JobAdminMenu m_Menu;
	int m_Delta;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu)
			m_Menu.SendFuelPriceChange(m_Delta);
		return true;
	}
}

//------------------------------------------------------------------------------------------------
// Handler recherche joueur page Gestion des joueurs
//------------------------------------------------------------------------------------------------
class AdminPlayerSearchHandler : ScriptedWidgetEventHandler
{
	JobAdminMenu m_Menu;
	bool m_Clear;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.OnPlayerSearchClicked(m_Clear);
		return true;
	}
}

//------------------------------------------------------------------------------------------------
// Clic sur une ligne du Top 25 : si le joueur est connecte, ouvre sa fiche admin.
// Sinon affiche une notice dans la console (offline, pas de fiche possible).
//------------------------------------------------------------------------------------------------
class AdminRichestRowHandler : ScriptedWidgetEventHandler
{
	string m_DisplayName;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		PlayerManager pm = GetGame().GetPlayerManager();
		if (!pm) return true;
		array<int> all = new array<int>();
		pm.GetPlayers(all);
		foreach (int pid : all)
		{
			string rp = JobIdentityManager.GetInstance().Client_GetDisplayName(pid);
			if (rp == m_DisplayName)
			{
				JobAdminPlayerMenu menu = JobAdminPlayerMenu.Cast(
					GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.JobAdminPlayerMenu));
				if (menu)
					menu.Initialize(pid, rp);
				return true;
			}
		}
		Print(string.Format("[Admin] Joueur '%1' hors ligne, fiche indisponible.",
			m_DisplayName), LogLevel.NORMAL);
		return true;
	}
}

//------------------------------------------------------------------------------------------------
// Pagination du journal admin (Precedent / Suivant)
//------------------------------------------------------------------------------------------------
class AdminReportsPageHandler : ScriptedWidgetEventHandler
{
	JobAdminMenu m_Menu;
	int m_Direction;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.OnReportsPageChange(m_Direction);
		return true;
	}
}

//------------------------------------------------------------------------------------------------
// Prev/Next pagination gestion joueurs
//------------------------------------------------------------------------------------------------
class AdminPlayersPageHandler : ScriptedWidgetEventHandler
{
	JobAdminMenu m_Menu;
	int m_Direction;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.ChangePlayersPage(m_Direction);
		return true;
	}
}

//------------------------------------------------------------------------------------------------
// Prev/Next pagination gestion vehicules
//------------------------------------------------------------------------------------------------
class AdminVehiclesPageHandler : ScriptedWidgetEventHandler
{
	JobAdminMenu m_Menu;
	int m_Direction;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.ChangeVehiclesPage(m_Direction);
		return true;
	}
}

//------------------------------------------------------------------------------------------------
// Toggle du bouton "Mode suppression"
//------------------------------------------------------------------------------------------------
class AdminVehicleDeleteModeToggleHandler : ScriptedWidgetEventHandler
{
	JobAdminMenu m_Menu;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.ToggleDeleteMode();
		return true;
	}
}

//------------------------------------------------------------------------------------------------
// Clic sur une ligne vehicule :
//   - Mode suppression OFF -> ouvre la fiche admin du proprio (si connecte)
//   - Mode suppression ON  -> supprime le vehicule du garage virtuel
//------------------------------------------------------------------------------------------------
class AdminVehicleRowHandler : ScriptedWidgetEventHandler
{
	JobAdminMenu m_Menu;
	string m_OwnerName;
	string m_VehicleModel;
	int m_VehicleIndex;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (!m_Menu) return true;

		if (m_Menu.IsDeleteModeOn())
		{
			if (m_VehicleIndex >= 0)
				m_Menu.RequestDeleteVehicle(m_VehicleIndex, m_OwnerName, m_VehicleModel);
			return true;
		}

		// Mode normal : ouvre la fiche admin si proprio connecte
		PlayerManager pm = GetGame().GetPlayerManager();
		if (!pm) return true;
		array<int> all = new array<int>();
		pm.GetPlayers(all);
		foreach (int pid : all)
		{
			string rp = JobIdentityManager.GetInstance().Client_GetDisplayName(pid);
			if (rp == m_OwnerName)
			{
				JobAdminPlayerMenu menu = JobAdminPlayerMenu.Cast(
					GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.JobAdminPlayerMenu));
				if (menu)
					menu.Initialize(pid, rp);
				return true;
			}
		}
		Print(string.Format("[Admin] Proprietaire '%1' du vehicule '%2' est offline.",
			m_OwnerName, m_VehicleModel), LogLevel.NORMAL);
		return true;
	}
}
