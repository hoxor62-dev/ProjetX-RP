//------------------------------------------------------------------------------------------------
// JobAdminPanelAction.c
// UserAction "Ouvrir le panneau Administrateur" - sur un item tablet/laptop pose en jeu.
//
// Le check d'autorisation se fait cote SERVEUR au moment de l'ouverture du menu
// (le client envoie une RPC, le serveur verifie la whitelist UID, et autorise ou non).
// Cote action, on affiche/masque juste le label : si pas admin, l'action n est pas montree.
//
// A attacher via l'ActionsManagerComponent du prefab item (tablet, laptop, etc.) :
//------------------------------------------------------------------------------------------------

class JobAdminPanelAction : ScriptedUserAction
{
	//------------------------------------------------------------------------------------------------
	override bool CanBeShownScript(IEntity user)
	{
		// On affiche l action UNIQUEMENT si le joueur local est admin
		// CanBeShownScript est evalue cote client - on doit donc avoir une copie cliente
		// de la whitelist OU on accepte de la verifier cote serveur a l ouverture du menu
		// avec un message d erreur si pas admin.
		// Approche pragmatique : on affiche toujours l action, et le serveur refuse l ouverture
		// pour les non-admins via NotifyPlayerChat. Plus simple et fonctionnel.
		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	override bool CanBePerformedScript(IEntity user)
	{
		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	override bool GetActionNameScript(out string outName)
	{
		outName = "Ouvrir le panneau Administrateur";
		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
	{
		// Garde multijoueur : seul le joueur local execute la suite
		IEntity localPlayer = SCR_PlayerController.GetLocalControlledEntity();
		if (!localPlayer || pUserEntity != localPlayer)
			return;
		
		// Demande l ouverture au serveur (qui va valider la whitelist)
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc)
			return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc)
			return;
		jpc.ClientAskOpenAdminMenu();
	}
}
