//------------------------------------------------------------------------------------------------
// JobBraquageData.c
// Constantes et donnees du systeme de braquage bijouterie.
//------------------------------------------------------------------------------------------------

class JobBraquageData
{
	// ===== CONSTANTES =====
	
	// Duree totale du braquage en secondes (10 min)
	const int BRAQUAGE_DURATION_SECONDS = 600;
	
	// Capsules gagnees par seconde pendant le braquage
	const int CAPSULES_PER_SECOND = 25;
	
	// Interval entre 2 spawns d items au sol (30 secondes)
	const int ITEM_SPAWN_INTERVAL_SECONDS = 30;
	
	// Rayon de spawn des items autour du joueur (en metres)
	const float ITEM_SPAWN_RADIUS = 1;
	
	// Cooldown apres un braquage (par joueur) en secondes (1h = 3600)
	const int BRAQUAGE_COOLDOWN_SECONDS = 86400;
	
	// Rayon dans lequel les joueurs entendent la sirene (en metres)
	const float SIREN_AUDIBLE_RADIUS = 50.0;
	
	// Distance maximale entre le joueur et la bijouterie pendant le braquage.
	// Si depasse, le braquage est annule (cooldown + items au sol supprimes).
	const float MAX_DISTANCE_FROM_BIJOUTERIE = 15.0;
	
	// Items requis dans l inventaire pour declencher le braquage (a remplir avec ResourceName precises)
	// IMPORTANT : ces valeurs sont des placeholders, le boss devra les remplacer par les vraies
	// ResourceName des items requis.
	static const string REQUIRED_ITEM_A = "{72234C5272D6DF3C}Robber/Duffle.et";
	static const string REQUIRED_ITEM_B = "{E0E0AF73D81202D2}Prefabs/Items/Equipment/Accessories/ETool_ALICE/grinder.et";
	
	// Liste des prefabs d items qui spawnent au sol pendant le braquage.
	// Pour l instant, un seul prefab (a remplir par le boss). Le code support deja plusieurs
	// prefabs : il suffira d en ajouter dans la liste GetLootPrefabs().
	static const string LOOT_PREFAB_DEFAULT = "{4BD92C5231A3940D}Prefabs/Cordao/GoldChain2.et";
	
	// Son sirene (resource name) - a remplir par le boss
	static const string SIREN_SOUND_RESOURCE = "{F88FBF919B7F8CC7}Sounds/volsiren.wav";
	
	//------------------------------------------------------------------------------------------------
	// Retourne la liste des prefabs possibles pour le loot.
	// Le manager tire un random dans cette liste a chaque spawn.
	//------------------------------------------------------------------------------------------------
	static array<string> GetLootPrefabs()
	{
		array<string> prefabs = new array<string>();
		prefabs.Insert(LOOT_PREFAB_DEFAULT);
		// Le boss pourra ajouter d autres prefabs ici :
		prefabs.Insert("{61E261CDE10A07BD}Prefabs/Clothing/Cuban_Cross_Chain.et");
		prefabs.Insert("{D2DAF01768448970}Prefabs/Clothing/Jesus_Chain.et");
		prefabs.Insert("{B660612952B6B5D8}Prefabs/Clothing/Chucky_Chain.et");
		prefabs.Insert("{BBBB926DB67F9DE1}Prefabs/Clothing/Chrome_Hearts_Nun_Chain.et");
		prefabs.Insert("{C6D29778D28BA23A}Prefabs/Weapons/Grenades/pepiteor.et");
		return prefabs;
	}
}


