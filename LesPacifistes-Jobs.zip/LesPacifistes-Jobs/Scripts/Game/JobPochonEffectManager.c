//------------------------------------------------------------------------------------------------
// JobPochonEffectManager.c
// Singleton serveur qui gere les effets actifs des pochons utilises.
// - Applique un multiplicateur de degats recus (-50%)
// - Notifie le client pour effet visuel + vitesse boostee
// - Session expire apres 3 minutes
//------------------------------------------------------------------------------------------------

class JobPochonEffectSession
{
	int m_PlayerId;
	string m_UID;
	int m_EndUnix;
	
	void JobPochonEffectSession()
	{
		m_PlayerId = 0;
		m_UID = "";
		m_EndUnix = 0;
	}
}

class JobPochonEffectManager
{
	static ref JobPochonEffectManager s_Instance;
	
	ref array<ref JobPochonEffectSession> m_Sessions = new array<ref JobPochonEffectSession>();
	
	const int TICK_INTERVAL_MS = 1000;
	
	//------------------------------------------------------------------------------------------------
	static JobPochonEffectManager GetInstance()
	{
		if (!s_Instance)
		{
			s_Instance = new JobPochonEffectManager();
			s_Instance.Init();
		}
		return s_Instance;
	}
	
	//------------------------------------------------------------------------------------------------
	void Init()
	{
		if (!Replication.IsServer())
			return;
		GetGame().GetCallqueue().CallLater(Tick, TICK_INTERVAL_MS, true);
	}
	
	//------------------------------------------------------------------------------------------------
	// Verifie si un joueur est actuellement sous l effet d un pochon
	//------------------------------------------------------------------------------------------------
	bool HasActiveEffect(int playerId)
	{
		foreach (JobPochonEffectSession s : m_Sessions)
		{
			if (s && s.m_PlayerId == playerId)
				return true;
		}
		return false;
	}
	
	//------------------------------------------------------------------------------------------------
	// Demarre l effet pour un joueur (appele quand il utilise un pochon)
	//------------------------------------------------------------------------------------------------
	void StartEffect(int playerId)
	{
		if (playerId <= 0) return;
		
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "") return;
		
		int nowUnix = System.GetUnixTime();
		int newEnd = nowUnix + JobPochonData.EFFET_DUREE_S;
		
		// Si deja actif -> prolonge (max = end actuel)
		foreach (JobPochonEffectSession existing : m_Sessions)
		{
			if (existing && existing.m_PlayerId == playerId)
			{
				existing.m_EndUnix = newEnd;
				NotifyClientStart(playerId, JobPochonData.EFFET_DUREE_S);
				return;
			}
		}
		
		// Nouvelle session
		JobPochonEffectSession s = new JobPochonEffectSession();
		s.m_PlayerId = playerId;
		s.m_UID = uid;
		s.m_EndUnix = newEnd;
		m_Sessions.Insert(s);
		
		NotifyClientStart(playerId, JobPochonData.EFFET_DUREE_S);
	}
	
	//------------------------------------------------------------------------------------------------
	// Notifie le client pour demarrer les effets visuels + vitesse
	//------------------------------------------------------------------------------------------------
	void NotifyClientStart(int playerId, int duration)
	{
		PlayerController pc = GetGame().GetPlayerManager().GetPlayerController(playerId);
		if (!pc) return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (jpc)
			jpc.ServerStartPochonEffect(duration);
		JobManager.GetInstance().NotifyPlayerChat(playerId,
			"[Marchandise] Effet stimulant actif pendant 3 minutes !");
	}
	
	//------------------------------------------------------------------------------------------------
	// Notifie le client pour arreter les effets
	//------------------------------------------------------------------------------------------------
	void NotifyClientEnd(int playerId)
	{
		PlayerController pc = GetGame().GetPlayerManager().GetPlayerController(playerId);
		if (!pc) return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (jpc)
			jpc.ServerEndPochonEffect();
		JobManager.GetInstance().NotifyPlayerChat(playerId,
			"[Marchandise] Effet stimulant termine.");
	}
	
	//------------------------------------------------------------------------------------------------
	// Tick : verifie les timeouts
	//------------------------------------------------------------------------------------------------
	void Tick()
	{
		if (!Replication.IsServer())
			return;
		if (m_Sessions.IsEmpty())
			return;
		
		int nowUnix = System.GetUnixTime();
		for (int i = m_Sessions.Count() - 1; i >= 0; i--)
		{
			JobPochonEffectSession s = m_Sessions.Get(i);
			if (!s)
			{
				m_Sessions.Remove(i);
				continue;
			}
			if (nowUnix >= s.m_EndUnix)
			{
				NotifyClientEnd(s.m_PlayerId);
				m_Sessions.Remove(i);
			}
		}
	}
}
