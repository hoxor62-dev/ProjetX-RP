//------------------------------------------------------------------------------------------------
// LP_StartFishingAction.c
// Action "Demarrer la peche" a placer sur une entite au bord de l eau via Workbench.
//
// APPROCHE SIMPLIFIEE (comme les autres actions du mod qui marchent) :
//   - CanBeShownScript minimal : toujours visible pour le joueur local
//   - CanBePerformedScript : toujours true
//   - Verification prerequis dans PerformAction (client) + re-check serveur (anti-cheat)
//   - Notification chat si prerequis manquant
//------------------------------------------------------------------------------------------------

class LP_StartFishingAction : ScriptedUserAction
{
	//------------------------------------------------------------------------------------------------
	override bool CanBeShownScript(IEntity user)
	{
		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	override bool CanBePerformedScript(IEntity user)
	{
		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	override bool GetActionNameScript(out string outName)
	{
		outName = "Demarrer la peche";
		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
	{
		Print("[LP_Fishing] PerformAction StartFishing declenchee", LogLevel.NORMAL);
		
		PlayerController pc = PlayerController.Cast(GetGame().GetPlayerController());
		if (!pc) 
		{
			Print("[LP_Fishing] PC null", LogLevel.WARNING);
			return;
		}
		// Filtre dedicated server : seul le client propre de l action declenche le menu
		if (pUserEntity != pc.GetControlledEntity()) 
		{
			Print("[LP_Fishing] Pas le local player", LogLevel.NORMAL);
			return;
		}
		
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) 
		{
			Print("[LP_Fishing] JobPlayerComponent introuvable sur PlayerController", LogLevel.WARNING);
			return;
		}
		Print("[LP_Fishing] Appel ClientAskStartFishing", LogLevel.NORMAL);
		jpc.ClientAskStartFishing();
	}
}

//------------------------------------------------------------------------------------------------
// LP_FishingHookAction : action "Ferrer le poisson !" - visible en permanence sur l entite.
// La logique reelle est cote serveur : si aucune session active ou pas de poisson qui mord,
// le serveur ignore silencieusement le clic.
//------------------------------------------------------------------------------------------------

class LP_FishingHookAction : ScriptedUserAction
{
	//------------------------------------------------------------------------------------------------
	override bool CanBeShownScript(IEntity user)
	{
		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	override bool CanBePerformedScript(IEntity user)
	{
		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	override bool GetActionNameScript(out string outName)
	{
		outName = "Ferrer le poisson !";
		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
	{
		PlayerController pc = PlayerController.Cast(GetGame().GetPlayerController());
		if (!pc) return;
		if (pUserEntity != pc.GetControlledEntity()) return;
		
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		jpc.ClientAskFishingHook();
	}
}
