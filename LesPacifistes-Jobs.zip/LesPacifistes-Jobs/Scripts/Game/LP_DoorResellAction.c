//------------------------------------------------------------------------------------------------
// LP_DoorResellAction.c
// Action "Revendre l acces" - visible UNIQUEMENT pour le proprietaire (playerId).
//------------------------------------------------------------------------------------------------

class LP_DoorResellAction : ScriptedUserAction
{
	override bool CanBeShownScript(IEntity user)
	{
		if (!user) return false;
		
		IEntity door = GetOwner();
		if (!door) return false;
		LP_DoorAccessComponent access = LP_DoorAccessComponent.Cast(
			door.FindComponent(LP_DoorAccessComponent));
		if (!access || !access.HasOwner()) return false;
		
		int localPlayerId = SCR_PlayerController.GetLocalPlayerId();
		return access.IsOwnerPlayerId(localPlayerId);
	}
	
	override bool CanBePerformedScript(IEntity user) { return CanBeShownScript(user); }
	
	override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
	{
		PlayerController pc = PlayerController.Cast(GetGame().GetPlayerController());
		if (!pc) return;
		if (pUserEntity != pc.GetControlledEntity()) return;
		
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		
		RplComponent rpl = RplComponent.Cast(pOwnerEntity.FindComponent(RplComponent));
		if (!rpl) return;
		
		jpc.ClientAskOpenDoorSellMenu(rpl.Id(), true);
	}
}
