//------------------------------------------------------------------------------------------------
// JobGangManager.c
// Singleton serveur gerant tout le systeme de gang :
//   - Creation de gang (cout 30000 capsules)
//   - Gestion des membres (recruter / ejecter)
//   - Controle des zones d extraction (zoneId -> gangName)
//   - Taxation : 5% des ventes de drogue vont au gang qui controle la zone correspondante
//   - Benefices : cagnotte par gang, retrait par le chef uniquement
//   - Persistance JSON ($profile:LesPacifistesJobs/gangs.json)
//
// Mapping zone <-> drogue :
//   - Une zone d extraction a un EMarketItem (CANNABIS, COCAINE, etc.)
//   - Quand un joueur vend cette drogue, le gang qui controle LA zone de cette drogue
//     touche 5% de la vente.
//------------------------------------------------------------------------------------------------

class JobGangManager
{
	static ref JobGangManager s_Instance;
	
	const string SAVE_PATH = "$profile:LesPacifistesJobs/gangs.json";
	const int GANG_CREATION_COST = 30000;  // cout de creation d un gang
	const int TAX_PERCENT = 5;             // 5% des ventes vont au gang controlant la zone
	
	// Tous les gangs : nom -> JobGang
	ref map<string, ref JobGang> m_Gangs;
	
	// Zones controlees : EMarketItem (int) -> nom du gang qui la controle
	// (une zone = un type de drogue ; le gang qui controle la zone cannabis touche les taxes cannabis)
	ref map<int, string> m_ZoneControl;
	
	// Position monde des zones controlees (pour les marqueurs persistants)
	// EMarketItem (int) -> coordonnee X / Z
	ref map<int, float> m_ZonePosX;
	ref map<int, float> m_ZonePosZ;
	
	//------------------------------------------------------------------------------------------------
	void JobGangManager()
	{
		m_Gangs = new map<string, ref JobGang>();
		m_ZoneControl = new map<int, string>();
		m_ZonePosX = new map<int, float>();
		m_ZonePosZ = new map<int, float>();
	}
	
	//------------------------------------------------------------------------------------------------
	static JobGangManager GetInstance()
	{
		if (!s_Instance)
		{
			s_Instance = new JobGangManager();
			s_Instance.LoadFromDisk();
		}
		return s_Instance;
	}
	
	//------------------------------------------------------------------------------------------------
	// === RECHERCHE ===
	//------------------------------------------------------------------------------------------------
	
	// Retourne le gang dont l UID fait partie (chef ou membre), ou null
	JobGang GetGangOfPlayer(string uid)
	{
		foreach (string name, JobGang gang : m_Gangs)
		{
			if (gang && gang.Contains(uid))
				return gang;
		}
		return null;
	}
	
	// Retourne un gang par son nom (ou null)
	JobGang GetGangByName(string name)
	{
		return m_Gangs.Get(name);
	}
	
	// True si un gang avec ce nom existe deja
	bool GangNameExists(string name)
	{
		return m_Gangs.Contains(name);
	}
	
	//------------------------------------------------------------------------------------------------
	// === CREATION ===
	// Renvoie 0 = OK, sinon code erreur :
	//   1 = nom vide
	//   2 = nom deja pris
	//   3 = joueur deja dans un gang
	//   4 = solde insuffisant (30000 capsules)
	//------------------------------------------------------------------------------------------------
	int CreateGang(string uid, string displayName, string gangName)
	{
		if (gangName == "")
			return 1;
		if (GangNameExists(gangName))
			return 2;
		if (GetGangOfPlayer(uid))
			return 3;
		
		// Verifie le solde
		CapsuleEconomyManager eco = CapsuleEconomyManager.GetInstance();
		if (!eco)
			return 4;
		int balance = eco.GetCapsules(uid);
		if (balance < GANG_CREATION_COST)
			return 4;
		
		// Deduit le cout
		eco.AddCapsules(uid, -GANG_CREATION_COST);
		
		// Cree le gang
		JobGang gang = new JobGang();
		gang.m_Name = gangName;
		gang.m_ChefUID = uid;
		gang.m_ChefDisplayName = displayName;
		gang.m_Benefits = 0;
		m_Gangs.Set(gangName, gang);
		
		SaveToDisk();
		return 0;
	}
	
	//------------------------------------------------------------------------------------------------
	// === MEMBRES ===
	//------------------------------------------------------------------------------------------------
	
	// Recrute un membre. Renvoie 0 OK, code erreur sinon :
	//   1 = pas chef
	//   2 = cible deja dans un gang
	//   3 = gang introuvable
	int RecruitMember(string chefUID, string targetUID, string targetDisplayName)
	{
		JobGang gang = GetGangOfPlayer(chefUID);
		if (!gang)
			return 3;
		if (!gang.IsChef(chefUID))
			return 1;
		if (GetGangOfPlayer(targetUID))
			return 2;
		
		gang.AddMember(targetUID, targetDisplayName);
		SaveToDisk();
		return 0;
	}
	
	// Ejecte un membre. Renvoie 0 OK, code erreur sinon :
	//   1 = pas chef
	//   2 = cible pas dans le gang
	//   3 = gang introuvable
	int EjectMember(string chefUID, string targetUID)
	{
		JobGang gang = GetGangOfPlayer(chefUID);
		if (!gang)
			return 3;
		if (!gang.IsChef(chefUID))
			return 1;
		if (!gang.IsMember(targetUID))
			return 2;
		
		gang.RemoveMember(targetUID);
		SaveToDisk();
		return 0;
	}
	
	//------------------------------------------------------------------------------------------------
	// === QUITTER LE GANG (le joueur LUI-MEME quitte son gang) ===
	// Si le joueur est un membre simple : retrait standard.
	// Si le joueur est CHEF :
	//   - S il y a au moins un membre : transfert de la chefferie au membre le plus ancien
	//     (le premier dans m_Members), puis le joueur quitte.
	//   - Sinon (chef solo) : le gang est automatiquement dissous.
	// Renvoie un code resultat :
	//   0 = OK quitte (membre simple)
	//   1 = OK quitte + chefferie transferee
	//   2 = OK quitte + gang dissous (chef solo)
	//   -1 = pas dans un gang
	//------------------------------------------------------------------------------------------------
	int LeaveGang(string uid, out string outNewChefUID, out string outGangName)
	{
		outNewChefUID = "";
		outGangName = "";
		
		JobGang gang = GetGangOfPlayer(uid);
		if (!gang)
			return -1;
		
		outGangName = gang.m_Name;
		
		if (gang.IsChef(uid))
		{
			// Le joueur est le chef
			if (gang.m_Members.Count() == 0)
			{
				// Chef solo : dissolution complete du gang
				DissolveGangInternal(gang.m_Name);
				return 2;
			}
			
			// Transfert de la chefferie au premier membre (le plus ancien)
			JobGangMember newChefMember = gang.m_Members.Get(0);
			if (!newChefMember)
				return -1;
			outNewChefUID = newChefMember.m_UID;
			gang.m_ChefUID = newChefMember.m_UID;
			gang.m_ChefDisplayName = newChefMember.m_DisplayName;
			// Le nouveau chef sort de la liste membres (il est maintenant chef)
			gang.m_Members.Remove(0);
			SaveToDisk();
			return 1;
		}
		
		// Membre simple : retrait standard
		gang.RemoveMember(uid);
		SaveToDisk();
		return 0;
	}
	
	//------------------------------------------------------------------------------------------------
	// === DISSOUDRE UN GANG (action volontaire du chef) ===
	// Supprime entierement le gang + libere les zones controlees + recupere la liste
	// des membres pour notification cote serveur (renvoyee via outMemberUIDs).
	// Renvoie 0 OK, code erreur sinon :
	//   1 = pas chef
	//   3 = gang introuvable
	//------------------------------------------------------------------------------------------------
	int DissolveGang(string chefUID, out string outGangName, out array<string> outMemberUIDs)
	{
		outGangName = "";
		
		JobGang gang = GetGangOfPlayer(chefUID);
		if (!gang)
			return 3;
		if (!gang.IsChef(chefUID))
			return 1;
		
		outGangName = gang.m_Name;
		
		// Collecte les UIDs des membres pour que l appelant puisse les notifier
		// (on inclut PAS le chef car il a lance l action lui-meme)
		if (outMemberUIDs)
		{
			for (int i = 0; i < gang.m_Members.Count(); i++)
			{
				JobGangMember m = gang.m_Members.Get(i);
				if (m && m.m_UID != "")
					outMemberUIDs.Insert(m.m_UID);
			}
		}
		
		DissolveGangInternal(gang.m_Name);
		return 0;
	}
	
	//------------------------------------------------------------------------------------------------
	// Helper interne : supprime le gang et libere ses zones controlees.
	// Ne fait PAS de check de chef - les appelants doivent le faire en amont.
	//------------------------------------------------------------------------------------------------
	void DissolveGangInternal(string gangName)
	{
		if (gangName == "")
			return;
		
		// Libere les zones controlees par ce gang
		array<int> zonesToRelease = new array<int>();
		foreach (int marketItem, string controllerName : m_ZoneControl)
		{
			if (controllerName == gangName)
				zonesToRelease.Insert(marketItem);
		}
		foreach (int item : zonesToRelease)
		{
			m_ZoneControl.Remove(item);
			m_ZonePosX.Remove(item);
			m_ZonePosZ.Remove(item);
		}
		
		// Supprime le gang
		m_Gangs.Remove(gangName);
		SaveToDisk();
		
		Print(string.Format("[JobGangManager] Gang dissous : %1 (%2 zones liberees)",
			gangName, zonesToRelease.Count()), LogLevel.NORMAL);
	}
	
	//------------------------------------------------------------------------------------------------
	// === ZONES ===
	//------------------------------------------------------------------------------------------------
	
	// Le gang prend le controle d une zone (type de drogue)
	// Si une autre gang la controlait, il la perd automatiquement (ecrasement)
	// On stocke aussi la position monde de la zone pour les marqueurs persistants.
	void SetZoneControl(int marketItem, string gangName, float posX, float posZ)
	{
		m_ZoneControl.Set(marketItem, gangName);
		m_ZonePosX.Set(marketItem, posX);
		m_ZonePosZ.Set(marketItem, posZ);
		SaveToDisk();
	}
	
	// Retourne la position X d une zone controlee (0 si inconnue)
	float GetZonePosX(int marketItem)
	{
		float x;
		if (m_ZonePosX.Find(marketItem, x))
			return x;
		return 0;
	}
	
	// Retourne la position Z d une zone controlee (0 si inconnue)
	float GetZonePosZ(int marketItem)
	{
		float z;
		if (m_ZonePosZ.Find(marketItem, z))
			return z;
		return 0;
	}
	
	// Remplit les arrays avec toutes les zones controlees (pour renvoyer les marqueurs)
	void GetAllControlledZones(out array<int> outItems, out array<string> outGangs, out array<float> outX, out array<float> outZ)
	{
		foreach (int item, string gang : m_ZoneControl)
		{
			if (gang == "")
				continue;
			outItems.Insert(item);
			outGangs.Insert(gang);
			outX.Insert(GetZonePosX(item));
			outZ.Insert(GetZonePosZ(item));
		}
	}
	
	// Retourne le nom du gang qui controle une zone (ou "" si libre)
	string GetZoneController(int marketItem)
	{
		string gangName;
		if (m_ZoneControl.Find(marketItem, gangName))
			return gangName;
		return "";
	}
	
	//------------------------------------------------------------------------------------------------
	// === TAXATION ===
	// Appele depuis JobDrugSystem.ServerSellDrug quand un joueur vend de la drogue.
	// Si un gang controle la zone correspondante, il touche 5% du montant de la vente.
	// Retourne le montant taxe (pour info/logs).
	//------------------------------------------------------------------------------------------------
	int ApplyTaxOnSale(int marketItem, int saleAmount)
	{
		string gangName = GetZoneController(marketItem);
		if (gangName == "")
			return 0;  // zone non controlee, pas de taxe
		
		JobGang gang = GetGangByName(gangName);
		if (!gang)
			return 0;
		
		int tax = (saleAmount * TAX_PERCENT) / 100;
		if (tax <= 0)
			return 0;
		
		gang.m_Benefits = gang.m_Benefits + tax;
		SaveToDisk();
		return tax;
	}
	
	//------------------------------------------------------------------------------------------------
	// === BENEFICES ===
	// Le chef retire les benefices du gang vers son propre solde de capsules.
	// Renvoie le montant retire (0 si rien ou pas chef).
	//------------------------------------------------------------------------------------------------
	int WithdrawBenefits(string chefUID)
	{
		JobGang gang = GetGangOfPlayer(chefUID);
		if (!gang || !gang.IsChef(chefUID))
			return 0;
		
		int amount = gang.m_Benefits;
		if (amount <= 0)
			return 0;
		
		CapsuleEconomyManager eco = CapsuleEconomyManager.GetInstance();
		if (!eco)
			return 0;
		
		eco.AddCapsules(chefUID, amount);
		gang.m_Benefits = 0;
		SaveToDisk();
		return amount;
	}
	
	//------------------------------------------------------------------------------------------------
	// === PERSISTANCE JSON ===
	//------------------------------------------------------------------------------------------------
	void SaveToDisk()
	{
		SCR_JsonSaveContext ctx = new SCR_JsonSaveContext();
		
		// Sauve les gangs
		ctx.WriteValue("gang_count", m_Gangs.Count());
		int gIdx = 0;
		foreach (string name, JobGang gang : m_Gangs)
		{
			if (!gang) continue;
			string gp = "gang_" + gIdx.ToString() + "_";
			ctx.WriteValue(gp + "name", gang.m_Name);
			ctx.WriteValue(gp + "chef", gang.m_ChefUID);
			ctx.WriteValue(gp + "chefName", gang.m_ChefDisplayName);
			ctx.WriteValue(gp + "benefits", gang.m_Benefits);
			ctx.WriteValue(gp + "memberCount", gang.m_Members.Count());
			for (int i = 0; i < gang.m_Members.Count(); i++)
			{
				JobGangMember m = gang.m_Members.Get(i);
				if (!m) continue;
				ctx.WriteValue(gp + "member_" + i.ToString() + "_uid", m.m_UID);
				ctx.WriteValue(gp + "member_" + i.ToString() + "_name", m.m_DisplayName);
			}
			gIdx++;
		}
		
		// Sauve le controle des zones
		ctx.WriteValue("zone_count", m_ZoneControl.Count());
		int zIdx = 0;
		foreach (int marketItem, string gangName : m_ZoneControl)
		{
			ctx.WriteValue("zone_" + zIdx.ToString() + "_item", marketItem);
			ctx.WriteValue("zone_" + zIdx.ToString() + "_gang", gangName);
			ctx.WriteValue("zone_" + zIdx.ToString() + "_posX", GetZonePosX(marketItem));
			ctx.WriteValue("zone_" + zIdx.ToString() + "_posZ", GetZonePosZ(marketItem));
			zIdx++;
		}
		
		ctx.SaveToFile(SAVE_PATH);
	}
	
	void LoadFromDisk()
	{
		SCR_JsonLoadContext ctx = new SCR_JsonLoadContext();
		if (!ctx.LoadFromFile(SAVE_PATH))
			return;
		
		// Charge les gangs
		int gangCount = 0;
		ctx.ReadValue("gang_count", gangCount);
		for (int g = 0; g < gangCount; g++)
		{
			string gp = "gang_" + g.ToString() + "_";
			JobGang gang = new JobGang();
			ctx.ReadValue(gp + "name", gang.m_Name);
			ctx.ReadValue(gp + "chef", gang.m_ChefUID);
			ctx.ReadValue(gp + "chefName", gang.m_ChefDisplayName);
			ctx.ReadValue(gp + "benefits", gang.m_Benefits);
			int memberCount = 0;
			ctx.ReadValue(gp + "memberCount", memberCount);
			for (int i = 0; i < memberCount; i++)
			{
				JobGangMember m = new JobGangMember();
				ctx.ReadValue(gp + "member_" + i.ToString() + "_uid", m.m_UID);
				ctx.ReadValue(gp + "member_" + i.ToString() + "_name", m.m_DisplayName);
				if (m.m_UID != "")
					gang.m_Members.Insert(m);
			}
			if (gang.m_Name != "")
				m_Gangs.Set(gang.m_Name, gang);
		}
		
		// Charge le controle des zones
		int zoneCount = 0;
		ctx.ReadValue("zone_count", zoneCount);
		for (int z = 0; z < zoneCount; z++)
		{
			int marketItem = 0;
			string gangName = "";
			float posX = 0;
			float posZ = 0;
			ctx.ReadValue("zone_" + z.ToString() + "_item", marketItem);
			ctx.ReadValue("zone_" + z.ToString() + "_gang", gangName);
			ctx.ReadValue("zone_" + z.ToString() + "_posX", posX);
			ctx.ReadValue("zone_" + z.ToString() + "_posZ", posZ);
			if (marketItem != 0 && gangName != "")
			{
				m_ZoneControl.Set(marketItem, gangName);
				m_ZonePosX.Set(marketItem, posX);
				m_ZonePosZ.Set(marketItem, posZ);
			}
		}
		
		Print(string.Format("[JobGangManager] %1 gangs et %2 zones charges",
			m_Gangs.Count(), m_ZoneControl.Count()), LogLevel.NORMAL);
	}
}
