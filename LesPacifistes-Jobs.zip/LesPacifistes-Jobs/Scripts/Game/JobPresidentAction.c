//------------------------------------------------------------------------------------------------
// JobPresidentAction.c
// UserAction "Parler au President" - a attacher sur le PNJ President.
// Au clic : ouvre le menu President (le serveur verifiera ensuite que le joueur a bien
// le metier PRESIDENT avant d appliquer les modifications de taxes ou les retraits).
//------------------------------------------------------------------------------------------------

class JobPresidentAction : ScriptedUserAction
{
	override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
	{
		PlayerController pc = PlayerController.Cast(GetGame().GetPlayerController());
		if (!pc) return;
		if (pUserEntity != pc.GetControlledEntity()) return;
		
		// Verifie cote client que le joueur est bien President (juste pour message rapide).
		// Le serveur fera le check final dans les RPCs.
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		if (jpc.GetJob() != EJobType.PRESIDENT)
		{
			LP_NotificationManager.Show(
				"Seul le President peut acceder a ce menu.",
				"Accreditation refusee",
				4);
			return;
		}
		
		// Ouvre le menu - les valeurs initiales seront remplies par le serveur via RPC
		GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.JobPresidentMenu);
	}
	
	override bool CanBePerformedScript(IEntity user)
	{
		return true;
	}
	
	override bool CanBeShownScript(IEntity user)
	{
		// Action toujours visible : message d erreur cote client si pas President
		return true;
	}
	
	override bool GetActionNameScript(out string outName)
	{
		outName = "Parler au President";
		return true;
	}
}
