//------------------------------------------------------------------------------------------------
// JobFocusHandler.c
//
// Gestionnaire de focus pour surbrillance manette des boutons de menu.
// A attacher sur chaque ButtonWidget qui doit etre navigable a la manette.
//
// CORRECTIF v3 :
//  - Stocke les couleurs d'origine en composantes RGBA float (primitives) plutot que Color (ref type)
//    pour eviter les nullptr exceptions sur des Color qui auraient ete invalides entre 2 frames.
//  - Garde une trace de l'etat focused pour pouvoir restaurer proactivement.
//  - Le handler de focus suivant peut force-restorer le precedent au cas ou OnFocusLost
//    n'aurait pas ete declenche (bug observe avec navigation manette).
//------------------------------------------------------------------------------------------------

class JobFocusHandler : ScriptedWidgetEventHandler
{
	// Couleur d'origine du bouton stockee en composantes float (pas en objet Color ref)
	float m_OrigR;
	float m_OrigG;
	float m_OrigB;
	float m_OrigA;
	bool m_OriginalSaved;
	
	// Le widget que ce handler surveille
	Widget m_TargetWidget;
	
	// Registre static : tous les handlers actifs (pour restauration proactive)
	static ref array<ref JobFocusHandler> s_AllHandlers;
	
	//------------------------------------------------------------------------------------------------
	void JobFocusHandler()
	{
		m_OriginalSaved = false;
		m_OrigR = 1.0;
		m_OrigG = 1.0;
		m_OrigB = 1.0;
		m_OrigA = 1.0;
	}
	
	//------------------------------------------------------------------------------------------------
	// Restaure proactivement la couleur d'origine de TOUS les autres handlers
	// (sauf celui qui vient de prendre le focus). Utilise pour palier le bug de OnFocusLost
	// qui ne se declenche pas toujours avec la nav manette.
	//------------------------------------------------------------------------------------------------
	static void RestoreAllOthers(JobFocusHandler currentlyFocused)
	{
		if (!s_AllHandlers)
			return;
		foreach (JobFocusHandler h : s_AllHandlers)
		{
			if (!h || h == currentlyFocused)
				continue;
			h.RestoreOriginalColor();
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Restaure la couleur d'origine sur le widget de ce handler
	//------------------------------------------------------------------------------------------------
	void RestoreOriginalColor()
	{
		if (!m_TargetWidget)
			return;
		if (!m_OriginalSaved)
			return;
		
		// Cree fresh une Color a partir des composantes float (jamais null)
		Color origColor = Color.FromRGBA(
			(int)(m_OrigR * 255),
			(int)(m_OrigG * 255),
			(int)(m_OrigB * 255),
			(int)(m_OrigA * 255));
		if (!origColor)
			return;
		m_TargetWidget.SetColor(origColor);
	}
	
	//------------------------------------------------------------------------------------------------
	// Appele quand le widget prend le focus (stick/D-pad manette ou mouse hover + tab)
	override bool OnFocus(Widget w, int x, int y)
	{
		if (!w)
			return false;
		
		m_TargetWidget = w;
		
		// Sauvegarde la couleur d'origine la premiere fois (en composantes float)
		if (!m_OriginalSaved)
		{
			Color current = w.GetColor();
			if (current)
			{
				m_OrigR = current.R();
				m_OrigG = current.G();
				m_OrigB = current.B();
				m_OrigA = current.A();
				m_OriginalSaved = true;
			}
		}
		
		// Restauration proactive : tous les autres handlers retrouvent leur couleur d'origine
		// (palie au bug OnFocusLost qui ne se declenche pas toujours avec la manette)
		RestoreAllOthers(this);
		
		// Cree fresh la couleur jaune/or a chaque appel pour ne JAMAIS dependre d'un cache
		Color focusColor = Color.FromRGBA(242, 209, 51, 255);
		if (!focusColor)
			return false;
		
		w.SetColor(focusColor);
		return false;
	}
	
	//------------------------------------------------------------------------------------------------
	// Appele quand le widget perd le focus (peut ne pas etre fiable avec manette)
	override bool OnFocusLost(Widget w, int x, int y)
	{
		if (!w)
			return false;
		RestoreOriginalColor();
		return false;
	}
	
	//------------------------------------------------------------------------------------------------
	// Helper statique pour attacher le handler a un bouton en une ligne
	//------------------------------------------------------------------------------------------------
	static void Attach(Widget target)
	{
		if (!target)
			return;
		JobFocusHandler handler = new JobFocusHandler();
		handler.m_TargetWidget = target;
		target.AddHandler(handler);
		
		// Enregistre dans le registre static
		if (!s_AllHandlers)
			s_AllHandlers = new array<ref JobFocusHandler>();
		s_AllHandlers.Insert(handler);
	}
	
	//------------------------------------------------------------------------------------------------
	// Helper pour clear le registre quand un menu se ferme (a appeler dans OnMenuClose).
	// IMPORTANT : appele au moment ou le menu se ferme pour nettoyer les handlers obsoletes.
	//------------------------------------------------------------------------------------------------
	static void ClearRegistry()
	{
		if (s_AllHandlers)
			s_AllHandlers.Clear();
	}
}
