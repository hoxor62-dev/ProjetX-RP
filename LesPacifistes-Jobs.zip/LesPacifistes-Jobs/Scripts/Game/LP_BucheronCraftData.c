//------------------------------------------------------------------------------------------------
// LP_BucheronCraftData.c
// Definition des recettes de craft du bucheron.
//------------------------------------------------------------------------------------------------

class LP_BucheronCraftIngredient
{
	string m_Prefab;
	int m_Quantity;
	string m_DisplayName;
	
	void LP_BucheronCraftIngredient(string prefab, int quantity, string displayName)
	{
		m_Prefab = prefab;
		m_Quantity = quantity;
		m_DisplayName = displayName;
	}
}

class LP_BucheronCraftRecipe
{
	int m_RecipeId;
	string m_DisplayName;
	string m_ResultPrefab;
	ref array<ref LP_BucheronCraftIngredient> m_Ingredients = new array<ref LP_BucheronCraftIngredient>();
}

class LP_BucheronCraftData
{
	// Prefabs ingredients bruts
	static string BARIRON        = "{BFAB2077C1F962CB}Prefabs/Items/Equipment/bargold/bariron.et";
	static string PLANK          = "{06F1E252DC029B8C}Prefabs/Props/Civilian/Plank.et";
	static string PEPITE_FER     = "{B5C7F29EAB4BE9A7}Prefabs/Weapons/Grenades/pepitefer.et";
	static string BOIS           = "{8597A239C7AB5E14}Prefabs/Weapons/Grenades/bois.et";
	static string PEPITE_OR      = "{C6D29778D28BA23A}Prefabs/Weapons/Grenades/pepiteor.et";
	static string LINGOT_OR      = "{CD7E4794F5D40A0B}Prefabs/Items/Equipment/bargold/bargold.et";

	// Prefabs resultats craft
	static string PIOCHE_AMELIOREE = "{FDD8619861328520}Prefabs/Items/Equipment/Accessories/ETool_ALICE/Pioche2.et";
	static string CANNE_PECHE_1    = "{FDA3BBA905DF892C}Prefabs/Items/Equipment/Accessories/ETool_ALICE/canneapeche1.et";
	static string CANNE_PECHE_2    = "{0BD39A4AC4DB73B8}Prefabs/Items/Equipment/Accessories/ETool_ALICE/canneapeche2.et";
	static string BRIQUET          = "{3108621A936F0AE4}Prefabs/Items/Equipment/Lighter/Lighter.et";
	static string CLE_COFFRE       = "{3AA20990C37114B2}Prefabs/Items/Equipment/Accessories/ETool_ALICE/clecoffre.et";
	static string COFFRE_BLINDE    = "{D125E11C31A965AA}Prefabs/BaseBuilding/Storage/Safe/SafeBook.et";
	static string HACHE_AMELIOREE  = "{D723CC9DC095D176}Prefabs/Items/Equipment/Accessories/ETool_ALICE/Hache2.et";

	// Chaines et colliers (craft bijouterie bucheron)
	static string CHAINE_CANABIS   = "{D79600AABD2198A3}Prefabs/Clothing/CHAINECANABIS.et";
	static string CHAINE_PROJETX   = "{436319FF798563D6}Prefabs/Clothing/CHAINEPROJETX.et";
	static string CHAINE_PROJETX2  = "{C978C9EE13322B03}Prefabs/Clothing/CHAINEPROJETX2.et";
	static string CHAINE_PROJETX3  = "{2CE485171FD7BC68}Prefabs/Clothing/CHAINEPROJETX3.et";
	static string GRAIN_DE_CAFFE   = "{B3CA99E73F29B9AC}Prefabs/Clothing/GRAINDECAFFE.et";
	
	// Duree du craft en secondes (identique a l epicerie)
	const int CRAFT_DURATION_S = 30;
	
	// Cache statique des recettes
	static ref array<ref LP_BucheronCraftRecipe> s_Recipes;
	
	//------------------------------------------------------------------------------------------------
	static array<ref LP_BucheronCraftRecipe> GetAllRecipes()
	{
		if (!s_Recipes)
		{
			s_Recipes = new array<ref LP_BucheronCraftRecipe>();
			InitRecipes();
		}
		return s_Recipes;
	}
	
	//------------------------------------------------------------------------------------------------
	static LP_BucheronCraftRecipe GetRecipeById(int recipeId)
	{
		array<ref LP_BucheronCraftRecipe> all = GetAllRecipes();
		foreach (LP_BucheronCraftRecipe r : all)
		{
			if (r && r.m_RecipeId == recipeId) return r;
		}
		return null;
	}
	
	//------------------------------------------------------------------------------------------------
	protected static void InitRecipes()
	{
		// 1. Pioche amelioree : 2 bar iron + 2 planks
		LP_BucheronCraftRecipe r1 = new LP_BucheronCraftRecipe();
		r1.m_RecipeId = 1;
		r1.m_DisplayName = "Pioche amelioree";
		r1.m_ResultPrefab = PIOCHE_AMELIOREE;
		r1.m_Ingredients.Insert(new LP_BucheronCraftIngredient(BARIRON, 2, "Barre de fer"));
		r1.m_Ingredients.Insert(new LP_BucheronCraftIngredient(PLANK, 2, "Planche"));
		s_Recipes.Insert(r1);
		
		// 2. Canne a peche 1 : 3 pepites de fer + 1 bois
		LP_BucheronCraftRecipe r2 = new LP_BucheronCraftRecipe();
		r2.m_RecipeId = 2;
		r2.m_DisplayName = "Canne a peche";
		r2.m_ResultPrefab = CANNE_PECHE_1;
		r2.m_Ingredients.Insert(new LP_BucheronCraftIngredient(PEPITE_FER, 3, "Pepite de fer"));
		r2.m_Ingredients.Insert(new LP_BucheronCraftIngredient(BOIS, 1, "Bois"));
		s_Recipes.Insert(r2);
		
		// 3. Canne a peche 2 : 3 pepites de fer + 1 bois + 2 pepites d or
		LP_BucheronCraftRecipe r3 = new LP_BucheronCraftRecipe();
		r3.m_RecipeId = 3;
		r3.m_DisplayName = "Canne a peche 2";
		r3.m_ResultPrefab = CANNE_PECHE_2;
		r3.m_Ingredients.Insert(new LP_BucheronCraftIngredient(PEPITE_FER, 3, "Pepite de fer"));
		r3.m_Ingredients.Insert(new LP_BucheronCraftIngredient(BOIS, 1, "Bois"));
		r3.m_Ingredients.Insert(new LP_BucheronCraftIngredient(PEPITE_OR, 2, "Pepite d or"));
		s_Recipes.Insert(r3);

		// 4. Briquet : 3 barres de fer
		LP_BucheronCraftRecipe r4 = new LP_BucheronCraftRecipe();
		r4.m_RecipeId = 4;
		r4.m_DisplayName = "Briquet";
		r4.m_ResultPrefab = BRIQUET;
		r4.m_Ingredients.Insert(new LP_BucheronCraftIngredient(BARIRON, 3, "Barre de fer"));
		s_Recipes.Insert(r4);

		// 5. Cle de coffre : 10 lingots d or
		LP_BucheronCraftRecipe r5 = new LP_BucheronCraftRecipe();
		r5.m_RecipeId = 5;
		r5.m_DisplayName = "Cle de coffre";
		r5.m_ResultPrefab = CLE_COFFRE;
		r5.m_Ingredients.Insert(new LP_BucheronCraftIngredient(LINGOT_OR, 10, "Lingot d or"));
		s_Recipes.Insert(r5);

		// 6. Coffre fort blinde : 60 barres de fer
		LP_BucheronCraftRecipe r6 = new LP_BucheronCraftRecipe();
		r6.m_RecipeId = 6;
		r6.m_DisplayName = "Coffre fort blinde";
		r6.m_ResultPrefab = COFFRE_BLINDE;
		r6.m_Ingredients.Insert(new LP_BucheronCraftIngredient(BARIRON, 60, "Barre de fer"));
		s_Recipes.Insert(r6);

		// 7. Hache amelioree : 10 barres de fer (donne +25% de bois par cycle de coupe)
		LP_BucheronCraftRecipe r7 = new LP_BucheronCraftRecipe();
		r7.m_RecipeId = 7;
		r7.m_DisplayName = "Hache amelioree";
		r7.m_ResultPrefab = HACHE_AMELIOREE;
		r7.m_Ingredients.Insert(new LP_BucheronCraftIngredient(BARIRON, 10, "Barre de fer"));
		s_Recipes.Insert(r7);

		// === Chaines et colliers (bijouterie bucheron) : 2 lingots de fer + 5 lingots d or chacune ===

		// 8. Chaine Canabis
		LP_BucheronCraftRecipe r8 = new LP_BucheronCraftRecipe();
		r8.m_RecipeId = 8;
		r8.m_DisplayName = "Chaine Canabis";
		r8.m_ResultPrefab = CHAINE_CANABIS;
		r8.m_Ingredients.Insert(new LP_BucheronCraftIngredient(BARIRON, 2, "Lingot de fer"));
		r8.m_Ingredients.Insert(new LP_BucheronCraftIngredient(LINGOT_OR, 5, "Lingot d or"));
		s_Recipes.Insert(r8);

		// 9. Chaine ProjetX
		LP_BucheronCraftRecipe r9 = new LP_BucheronCraftRecipe();
		r9.m_RecipeId = 9;
		r9.m_DisplayName = "Chaine ProjetX";
		r9.m_ResultPrefab = CHAINE_PROJETX;
		r9.m_Ingredients.Insert(new LP_BucheronCraftIngredient(BARIRON, 2, "Lingot de fer"));
		r9.m_Ingredients.Insert(new LP_BucheronCraftIngredient(LINGOT_OR, 5, "Lingot d or"));
		s_Recipes.Insert(r9);

		// 10. Chaine ProjetX 2
		LP_BucheronCraftRecipe r10 = new LP_BucheronCraftRecipe();
		r10.m_RecipeId = 10;
		r10.m_DisplayName = "Chaine ProjetX 2";
		r10.m_ResultPrefab = CHAINE_PROJETX2;
		r10.m_Ingredients.Insert(new LP_BucheronCraftIngredient(BARIRON, 2, "Lingot de fer"));
		r10.m_Ingredients.Insert(new LP_BucheronCraftIngredient(LINGOT_OR, 5, "Lingot d or"));
		s_Recipes.Insert(r10);

		// 11. Chaine ProjetX 3
		LP_BucheronCraftRecipe r11 = new LP_BucheronCraftRecipe();
		r11.m_RecipeId = 11;
		r11.m_DisplayName = "Chaine ProjetX 3";
		r11.m_ResultPrefab = CHAINE_PROJETX3;
		r11.m_Ingredients.Insert(new LP_BucheronCraftIngredient(BARIRON, 2, "Lingot de fer"));
		r11.m_Ingredients.Insert(new LP_BucheronCraftIngredient(LINGOT_OR, 5, "Lingot d or"));
		s_Recipes.Insert(r11);

		// 12. Grain de Cafe
		LP_BucheronCraftRecipe r12 = new LP_BucheronCraftRecipe();
		r12.m_RecipeId = 12;
		r12.m_DisplayName = "Grain de Cafe";
		r12.m_ResultPrefab = GRAIN_DE_CAFFE;
		r12.m_Ingredients.Insert(new LP_BucheronCraftIngredient(BARIRON, 2, "Lingot de fer"));
		r12.m_Ingredients.Insert(new LP_BucheronCraftIngredient(LINGOT_OR, 5, "Lingot d or"));
		s_Recipes.Insert(r12);
	}
}
