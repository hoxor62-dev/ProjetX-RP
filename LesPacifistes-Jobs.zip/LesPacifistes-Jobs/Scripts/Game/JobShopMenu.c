//------------------------------------------------------------------------------------------------
// JobShopMenu.c
// Menu boutique utilise par Voyou (armes) et Concessionnaire (vehicules).
// Layout split : liste a gauche, preview 3D + bouton Acheter a droite.
//  - Clic sur une entree de liste -> affiche la preview 3D a droite
//  - Clic sur bouton "Acheter" -> achete l'item selectionne via RPC serveur
//------------------------------------------------------------------------------------------------

class JobShopMenu : ChimeraMenuBase
{
	const string LAYOUT_PATH = "{B2B221E1251C713E}UI/layouts/JobShopMenu.layout";
	const string ENTRY_LAYOUT_PATH = "{3C760B5F101F24F2}UI/layouts/JobShopEntry.layout";
	// Layout dedie aux boutons categorie (compact, sans prix ni bouton "Voir" separe).
	// Utilise un path relatif : Workbench le resoudra automatiquement.
	const string CATEGORY_LAYOUT_PATH = "UI/layouts/JobShopCategoryEntry.layout";
	
	Widget m_RootWidget;
	Widget m_EntriesContainer;
	TextWidget m_TitleText;
	TextWidget m_PreviewTitle;
	TextWidget m_PreviewPrice;
	ItemPreviewWidget m_PreviewWidget;
	ButtonWidget m_BuyButton;
	ButtonWidget m_CloseButton;
	ButtonWidget m_BtnTabBuy;
	ButtonWidget m_BtnTabSell;
	
	EJobType m_Job;
	RplId m_NpcRplId;
	
	// Mode courant : "buy" ou "sell"
	string m_Mode = "buy";
	
	// Cache des boutons crees (pour click handling)
	ref map<ButtonWidget, int> m_ButtonToIndex = new map<ButtonWidget, int>();
	
	// === CATEGORIES (Phase 3) ===
	// Conteneur vertical a gauche pour afficher les boutons de categorie
	Widget m_CategoriesContainer;
	// Liste des categories du shop courant (vide si shop sans categorie)
	ref array<string> m_Categories = new array<string>();
	// Categorie actuellement selectionnee (vide = mode sans categorie)
	string m_SelectedCategory = "";
	// Mapping bouton categorie -> nom categorie
	ref map<ButtonWidget, string> m_CatButtonToName = new map<ButtonWidget, string>();
	
	// === PAGINATION (fix scroll manette) ===
	// 10 items par page pour rester dans la zone visible sans scroll
	const int ITEMS_PER_PAGE = 10;
	// Page courante (0-indexed)
	int m_CurrentPage = 0;
	// Boutons pagination
	ButtonWidget m_BtnPrevPage;
	ButtonWidget m_BtnNextPage;
	TextWidget m_PageLabel;
	
	// Item actuellement selectionne pour la preview (index dans le catalogue)
	// -1 = aucun selectionne
	int m_SelectedIndex = -1;
	
	// Memorise la derniere entree de la liste qui a ete cliquee/focusee.
	// Utilise pour le retour vers la liste depuis BuyButton via la touche gauche manette.
	ButtonWidget m_LastFocusedEntry;
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuOpen()
	{
		super.OnMenuOpen();
		// Nettoie le registre du JobFocusHandler avant d enregistrer les nouveaux handlers
		// (sinon les anciens handlers d autres menus peuvent essayer de modifier des widgets morts)
		JobFocusHandler.ClearRegistry();
		m_RootWidget = GetRootWidget();
		if (!m_RootWidget)
			return;
		
		m_EntriesContainer = m_RootWidget.FindAnyWidget("EntriesContainer");
		m_CategoriesContainer = m_RootWidget.FindAnyWidget("CategoriesContainer");
		m_BtnPrevPage = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnPrevPage"));
		m_BtnNextPage = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnNextPage"));
		m_PageLabel = TextWidget.Cast(m_RootWidget.FindAnyWidget("PageLabel"));
		m_TitleText = TextWidget.Cast(m_RootWidget.FindAnyWidget("TitleText"));
		m_PreviewTitle = TextWidget.Cast(m_RootWidget.FindAnyWidget("PreviewTitle"));
		m_PreviewPrice = TextWidget.Cast(m_RootWidget.FindAnyWidget("PreviewPrice"));
		m_PreviewWidget = ItemPreviewWidget.Cast(m_RootWidget.FindAnyWidget("PreviewWidget"));
		m_BuyButton = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BuyButton"));
		m_CloseButton = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("CloseButton"));
		m_BtnTabBuy = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnTabBuy"));
		m_BtnTabSell = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnTabSell"));
		
		// Handlers des 2 onglets
		if (m_BtnTabBuy)
		{
			ShopClickHandler hBuyTab = new ShopClickHandler();
			hBuyTab.m_Menu = this;
			hBuyTab.m_Mode = "tab_buy";
			m_BtnTabBuy.AddHandler(hBuyTab);
			JobFocusHandler.Attach(m_BtnTabBuy);
		}
		if (m_BtnTabSell)
		{
			ShopClickHandler hSellTab = new ShopClickHandler();
			hSellTab.m_Menu = this;
			hSellTab.m_Mode = "tab_sell";
			m_BtnTabSell.AddHandler(hSellTab);
			JobFocusHandler.Attach(m_BtnTabSell);
		}
		
		// Handlers pagination
		if (m_BtnPrevPage)
		{
			ShopClickHandler hPrev = new ShopClickHandler();
			hPrev.m_Menu = this;
			hPrev.m_Mode = "page_prev";
			m_BtnPrevPage.AddHandler(hPrev);
			JobFocusHandler.Attach(m_BtnPrevPage);
		}
		if (m_BtnNextPage)
		{
			ShopClickHandler hNext = new ShopClickHandler();
			hNext.m_Menu = this;
			hNext.m_Mode = "page_next";
			m_BtnNextPage.AddHandler(hNext);
			JobFocusHandler.Attach(m_BtnNextPage);
		}
		
		// Fermeture
		if (m_CloseButton)
		{
			ShopClickHandler clickHandler = new ShopClickHandler();
			clickHandler.m_Menu = this;
			clickHandler.m_Mode = "close";
			m_CloseButton.AddHandler(clickHandler);
			JobFocusHandler.Attach(m_CloseButton);
		}
		
		ButtonWidget floatingClose = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("FloatingCloseButton"));
		if (floatingClose)
		{
			ShopClickHandler floatClose = new ShopClickHandler();
			floatClose.m_Menu = this;
			floatClose.m_Mode = "close";
			floatingClose.AddHandler(floatClose);
			JobFocusHandler.Attach(floatingClose);
		}
		
		// Bouton Acheter (sous la preview)
		if (m_BuyButton)
		{
			ShopClickHandler buyHandler = new ShopClickHandler();
			buyHandler.m_Menu = this;
			buyHandler.m_Mode = "buy";
			m_BuyButton.AddHandler(buyHandler);
			JobFocusHandler.Attach(m_BuyButton);
			
			// Reste visible des le debut pour que la nav manette le voit comme cible atteignable
			// (mais desactive tant qu'aucun item selectionne)
			m_BuyButton.SetEnabled(false);
			m_BuyButton.SetVisible(true);
		}
	}
	
	// Cooldown anti-rebond pour la touche gauche manette (sinon spam)
	float m_LeftPressCooldown = 0;
	float m_TabPressCooldown = 0;
	
	//------------------------------------------------------------------------------------------------
	// Support touche Echap pour fermer le menu + interception touche gauche depuis BuyButton
	//------------------------------------------------------------------------------------------------
	override void OnMenuUpdate(float tDelta)
	{
		super.OnMenuUpdate(tDelta);
		if (GetGame().GetInputManager().GetActionValue("MenuBack") > 0.5)
		{
			CloseMenuInternal();
			return;
		}
		
		// Decremente le cooldown
		if (m_LeftPressCooldown > 0)
			m_LeftPressCooldown -= tDelta;
		if (m_TabPressCooldown > 0)
			m_TabPressCooldown -= tDelta;
		
		// === NAVIGATION ONGLETS A LA MANETTE (boutons d epaule LB/RB) ===
		// Les joueurs manette ne peuvent pas atteindre les onglets Acheter/Vendre par la
		// navigation directionnelle. On mappe donc les gachettes d epaule pour switcher d onglet.
		// MenuTabLeft / MenuTabRight = LB / RB sur manette (et Q/E par defaut au clavier).
		if (m_TabPressCooldown <= 0)
		{
			InputManager im = GetGame().GetInputManager();
			if (im.GetActionValue("MenuTabRight") > 0.5)
			{
				// RB -> passe a l onglet Vendre
				if (m_Mode != "sell")
				{
					SwitchMode("sell");
					m_TabPressCooldown = 0.30;  // anti-rebond 300ms
				}
			}
			else if (im.GetActionValue("MenuTabLeft") > 0.5)
			{
				// LB -> revient a l onglet Acheter
				if (m_Mode != "buy")
				{
					SwitchMode("buy");
					m_TabPressCooldown = 0.30;
				}
			}
		}
		
		// Interception touche gauche : si le focus est sur BuyButton et le joueur va a gauche,
		// on bascule manuellement vers la derniere entree focusee (palie au bug nav spatiale
		// qui ne trouve pas les items 1-5 depuis Acheter, seulement l'item aligne).
		if (m_LeftPressCooldown <= 0 && GetGame().GetInputManager().GetActionValue("MenuLeft") > 0.5)
		{
			Widget focused = GetGame().GetWorkspace().GetFocusedWidget();
			if (focused == m_BuyButton && m_LastFocusedEntry)
			{
				GetGame().GetWorkspace().SetFocusedWidget(m_LastFocusedEntry);
				m_LeftPressCooldown = 0.25;  // 250ms anti-rebond
			}
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Initialisation depuis JobActionMenu
	//------------------------------------------------------------------------------------------------
	void Initialize(EJobType job, RplId npcRplId)
	{
		m_Job = job;
		m_NpcRplId = npcRplId;
		
		if (m_TitleText)
		{
			string title;
			switch (job)
			{
				case EJobType.VOYOU:
					title = "Marche noir - Armes de contrebande";
					break;
				case EJobType.CONCESSIONNAIRE:
					title = "Concessionnaire - Achat de vehicules";
					break;
				case EJobType.VENDEUR_IMMOBILIER:
					title = "Vendeur Immobilier - Materiaux";
					break;
				case EJobType.MECANICIEN:
					title = "Mecanicien - Outils et pieces";
					break;
				case EJobType.JOURNALISTE:
					title = "Journaliste - Materiel reporter";
					break;
				case EJobType.SHOP_BIJOUTERIE:
					title = "Bijouterie - Bijoux et chaines";
					break;
				case EJobType.SHOP_VOYOU_CAC:
					title = "Marche noir - Armes corps a corps";
					break;
				case EJobType.SHOP_VOYOU_POINT:
					title = "Marche noir - Armes de point";
					break;
				case EJobType.SHOP_VOYOU_FUSIL:
					title = "Marche noir - Fusils";
					break;
				case EJobType.SHOP_VOYOU_MITRAILLETTE:
					title = "Marche noir - Mitraillettes";
					break;
				case EJobType.SHOP_VETEMENTS:
					title = "Vendeur Vetements";
					break;
				case EJobType.SHOP_NOURRITURE:
					title = "Vendeur Nourriture";
					break;
				case EJobType.SHOP_LOCATION:
					title = "Loueur Vehicules";
					break;
				case EJobType.VENDEUR_VETEMENTS:
					title = "Boutique Vetements RP";
					break;
				default:
					title = "Boutique";
			}
			m_TitleText.SetText(title);
		}
		
		// Onglet "Acheter" actif par defaut (vert), "Vendre" gris
		if (m_BtnTabBuy)
			m_BtnTabBuy.SetColor(Color.FromRGBA(46, 128, 56, 255));
		if (m_BtnTabSell)
			m_BtnTabSell.SetColor(Color.FromRGBA(89, 89, 102, 255));
		
		// === Detection des categories du shop ===
		m_Categories = JobShopCatalog.GetCategoriesForJob(m_Job);
		if (m_Categories && m_Categories.Count() > 0)
			m_SelectedCategory = m_Categories.Get(0);
		else
			m_SelectedCategory = "";
		
		// Construit les boutons categories (masque le conteneur si aucune categorie)
		BuildCategories();
		
		BuildEntries();
	}
	
	//------------------------------------------------------------------------------------------------
	void BuildEntries()
	{
		if (!m_EntriesContainer)
			return;
		
		// Reset des enfants existants (au cas ou on switche d onglet)
		Widget child = m_EntriesContainer.GetChildren();
		while (child)
		{
			Widget next = child.GetSibling();
			child.RemoveFromHierarchy();
			child = next;
		}
		m_ButtonToIndex.Clear();
		
		// === Filtre par categorie si applicable ===
		// Si le shop a des categories -> utilise GetItemsForJobAndCategory
		// Sinon -> comportement d origine (GetItemsForJob)
		array<ref JobShopItem> items;
		if (m_Categories && m_Categories.Count() > 0 && m_SelectedCategory != "")
			items = JobShopCatalog.GetItemsForJobAndCategory(m_Job, m_SelectedCategory);
		else
			items = JobShopCatalog.GetItemsForJob(m_Job);
		if (!items || items.IsEmpty())
		{
			UpdatePagination(0);
			return;
		}
		
		// === PAGINATION ===
		// En mode "sell", filtre d abord les items possedes pour calculer la vraie liste
		// affichable (necessaire pour le calcul du nombre de pages).
		array<ref JobShopItem> displayable = new array<ref JobShopItem>();
		foreach (JobShopItem it : items)
		{
			if (!it) continue;
			if (m_Mode == "sell" && CountItemInInventory(it.m_Prefab) <= 0)
				continue;
			displayable.Insert(it);
		}
		
		int totalPages = 1;
		if (displayable.Count() > 0)
			totalPages = (displayable.Count() + ITEMS_PER_PAGE - 1) / ITEMS_PER_PAGE;
		if (m_CurrentPage < 0)
			m_CurrentPage = 0;
		if (m_CurrentPage >= totalPages)
			m_CurrentPage = totalPages - 1;
		
		UpdatePagination(totalPages);
		
		int pageStart = m_CurrentPage * ITEMS_PER_PAGE;
		int pageEnd = pageStart + ITEMS_PER_PAGE;
		if (pageEnd > displayable.Count())
			pageEnd = displayable.Count();
		
		WorkspaceWidget ws = GetGame().GetWorkspace();
		
		const int ENTRY_HEIGHT = 55;
		const int ENTRY_PADDING = 10;
		const int ENTRY_WIDTH = 540;
		
		ButtonWidget firstButton = null;
		int displayRow = 0;
		
		for (int i = pageStart; i < pageEnd; i++)
		{
			JobShopItem item = displayable.Get(i);
			if (!item)
				continue;
			
			int ownedCount = 0;
			
			// En mode "sell", on a deja pre-filtre au dessus dans "displayable"
			// Ici on recupere juste ownedCount pour l affichage
			if (m_Mode == "sell")
				ownedCount = CountItemInInventory(item.m_Prefab);
			
			Widget entry = ws.CreateWidgets(ENTRY_LAYOUT_PATH, m_EntriesContainer);
			if (!entry)
				continue;
			
			FrameSlot.SetPos(entry, 0, displayRow * (ENTRY_HEIGHT + ENTRY_PADDING));
			FrameSlot.SetSize(entry, ENTRY_WIDTH, ENTRY_HEIGHT);
			displayRow++;
			
			// Nom article (ajoute le compteur d items possedes en mode sell)
			TextWidget nameW = TextWidget.Cast(entry.FindAnyWidget("ItemName"));
			if (nameW)
			{
				if (m_Mode == "sell")
					nameW.SetText(string.Format("%1 (x%2)", item.m_Name, ownedCount));
				else
					nameW.SetText(item.m_Name);
			}
			
			// Prix : achat = m_Price, vente = m_Price / 3
			// Devise : capsules par defaut, lingots d or si m_PaidInGold
			TextWidget priceW = TextWidget.Cast(entry.FindAnyWidget("ItemPrice"));
			if (priceW)
			{
				string currency = "capsules";
				if (item.m_PaidInGold)
					currency = "lingots d or";
				
				if (m_Mode == "sell")
				{
					int sellPrice = item.m_Price / 3;
					priceW.SetText(string.Format("Prix vente: %1 %2", sellPrice, currency));
				}
				else
				{
					priceW.SetText(string.Format("Prix: %1 %2", item.m_Price, currency));
				}
			}
			
			// Bouton de l'entree (label "Voir" dans les 2 modes)
			ButtonWidget btn = ButtonWidget.Cast(entry.FindAnyWidget("BuyButton"));
			if (btn)
			{
				// Stocke l INDEX GLOBAL (dans GetItemsForJob complet), pas l index filtre.
				// Necessaire pour que ClientAskBuyShopItem/Sell renvoie le bon index au serveur.
				int globalIdx = i;
				if (m_Categories && m_Categories.Count() > 0 && m_SelectedCategory != "")
					globalIdx = GlobalIndexOf(item);
				m_ButtonToIndex.Set(btn, globalIdx);
				ShopClickHandler ch = new ShopClickHandler();
				ch.m_Menu = this;
				ch.m_Mode = "preview";
				btn.AddHandler(ch);
				
				JobFocusHandler.Attach(btn);
				
				TextWidget btnText = TextWidget.Cast(btn.FindAnyWidget("BuyText"));
				if (btnText)
					btnText.SetText("Voir");
				
				if (!firstButton)
					firstButton = btn;
			}
		}
		
		// Message si rien a vendre
		if (displayRow == 0 && m_Mode == "sell")
		{
			Widget empty = ws.CreateWidgets(ENTRY_LAYOUT_PATH, m_EntriesContainer);
			if (empty)
			{
				FrameSlot.SetPos(empty, 0, 0);
				FrameSlot.SetSize(empty, ENTRY_WIDTH, ENTRY_HEIGHT);
				TextWidget emptyW = TextWidget.Cast(empty.FindAnyWidget("ItemName"));
				if (emptyW)
					emptyW.SetText("Vous n'avez rien a vendre ici");
				TextWidget emptyP = TextWidget.Cast(empty.FindAnyWidget("ItemPrice"));
				if (emptyP)
					emptyP.SetText("");
				ButtonWidget emptyBtn = ButtonWidget.Cast(empty.FindAnyWidget("BuyButton"));
				if (emptyBtn)
					emptyBtn.SetVisible(false);
			}
			// Liste vide : on met le focus sur l onglet Vendre lui-meme pour que le joueur
			// manette puisse revenir a Acheter via LB (sinon il se retrouve sans focus = bloque)
			if (m_BtnTabSell)
				GetGame().GetWorkspace().SetFocusedWidget(m_BtnTabSell);
			return;
		}
		
		// Focus clavier/gamepad sur le premier bouton
		if (firstButton)
			GetGame().GetWorkspace().SetFocusedWidget(firstButton);
	}
	
	//------------------------------------------------------------------------------------------------
	// Clic sur une entree de la liste -> affiche la preview 3D
	//------------------------------------------------------------------------------------------------
	void OnEntryClicked(ButtonWidget btn)
	{
		int index;
		if (!m_ButtonToIndex.Find(btn, index))
			return;
		
		// Memorise ce bouton comme derniere entree focusee
		// (utilise pour le retour gauche depuis BuyButton)
		m_LastFocusedEntry = btn;
		
		ShowPreview(index);
	}
	
	// Reference au manager (trouve une fois dans le monde)
	ItemPreviewManagerEntity m_PreviewManager;
	
	//------------------------------------------------------------------------------------------------
	// Trouve (ou retrouve en cache) le manager de preview 3D
	// Le manager est un GenericEntity present dans la scene (pas accessible via un getter direct)
	//------------------------------------------------------------------------------------------------
	ItemPreviewManagerEntity GetPreviewManager()
	{
		if (m_PreviewManager)
			return m_PreviewManager;
		
		BaseWorld world = GetGame().GetWorld();
		if (!world)
			return null;
		
		IEntity entity = world.FindEntityByName("ItemPreviewManagerEntity");
		if (entity)
			m_PreviewManager = ItemPreviewManagerEntity.Cast(entity);
		
		return m_PreviewManager;
	}
	
	//------------------------------------------------------------------------------------------------
	// Met a jour la preview 3D avec l'item selectionne.
	// itemIndex = index GLOBAL dans le catalogue complet (GetItemsForJob).
	//------------------------------------------------------------------------------------------------
	void ShowPreview(int itemIndex)
	{
		array<ref JobShopItem> items = JobShopCatalog.GetItemsForJob(m_Job);
		if (!items || itemIndex < 0 || itemIndex >= items.Count())
			return;
		
		JobShopItem item = items.Get(itemIndex);
		if (!item)
			return;
		
		m_SelectedIndex = itemIndex;
		
		// Met a jour les textes
		if (m_PreviewTitle)
			m_PreviewTitle.SetText(item.m_Name);
		if (m_PreviewPrice)
		{
			string currency = "capsules";
			if (item.m_PaidInGold)
				currency = "lingots d or";
			
			if (m_Mode == "sell")
			{
				int sellPrice = item.m_Price / 3;
				m_PreviewPrice.SetText(string.Format("Prix de vente: %1 %2", sellPrice, currency));
			}
			else
			{
				m_PreviewPrice.SetText(string.Format("%1 %2", item.m_Price, currency));
			}
		}
		
		// Active le bouton Acheter
		if (m_BuyButton)
		{
			m_BuyButton.SetEnabled(true);
			m_BuyButton.SetVisible(true);
			
			// Force le focus sur Acheter apres un court delai (50ms = 1 frame).
			// Solution choisie pour l accessibilite manette : depuis n importe quel item, apres Voir
			// le focus saute auto sur Acheter quel que soit l alignement spatial.
			// Sans ca, les items qui ne sont pas alignes horizontalement avec Acheter sont injoignables.
			GetGame().GetCallqueue().CallLater(FocusBuyButtonDelayed, 50, false);
		}
		
		// Met a jour la preview 3D
		if (m_PreviewWidget)
		{
			ItemPreviewManagerEntity manager = GetPreviewManager();
			if (manager)
			{
				ResourceName prefab = item.m_Prefab;
				manager.SetPreviewItemFromPrefab(m_PreviewWidget, prefab, null, false);
			}
			else
			{
				Print("[JobShopMenu] ItemPreviewManagerEntity introuvable dans le monde - verifier que l'entite est placee dans la scene",
					LogLevel.WARNING);
			}
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Helper appele apres un court delai pour focus le BuyButton.
	// Necessaire pour que le moteur ait eu le temps de re-evaluer la nav apres SetEnabled.
	//------------------------------------------------------------------------------------------------
	void FocusBuyButtonDelayed()
	{
		if (m_BuyButton)
			GetGame().GetWorkspace().SetFocusedWidget(m_BuyButton);
	}
	
	//------------------------------------------------------------------------------------------------
	// Clic sur le gros bouton Acheter -> achat via RPC serveur
	//------------------------------------------------------------------------------------------------
	void OnBuyClicked()
	{
		if (m_SelectedIndex < 0)
			return;
		
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc)
			return;
		
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc)
		{
			Print("[JobShopMenu] JobPlayerComponent manquant sur le PlayerController local",
				LogLevel.WARNING);
			return;
		}
		
		jpc.ClientAskBuyShopItem(m_SelectedIndex, m_Job);
		
		// Pas de fermeture automatique, permet d'acheter plusieurs articles d'affilee
	}
	
	//------------------------------------------------------------------------------------------------
	// Clic sur le gros bouton (selon le mode) : achete ou vend selon m_Mode courant
	//------------------------------------------------------------------------------------------------
	void OnActionButtonClicked()
	{
		if (m_Mode == "sell")
			OnSellClicked();
		else
			OnBuyClicked();
	}
	
	//------------------------------------------------------------------------------------------------
	// Clic sur le gros bouton "Vendre" -> vente via RPC serveur
	//------------------------------------------------------------------------------------------------
	void OnSellClicked()
	{
		if (m_SelectedIndex < 0)
			return;
		
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc)
			return;
		
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc)
			return;
		
		jpc.ClientAskSellShopItem(m_SelectedIndex, m_Job);
	}
	
	//------------------------------------------------------------------------------------------------
	// Switche entre les 2 onglets - met a jour le visuel des onglets, le bouton, et rebuild la liste
	//------------------------------------------------------------------------------------------------
	void SwitchMode(string newMode)
	{
		if (newMode != "buy" && newMode != "sell")
			return;
		if (m_Mode == newMode)
			return;
		
		m_Mode = newMode;
		m_SelectedIndex = -1;
		
		// Met a jour les couleurs des onglets : actif = vert/violet, inactif = gris
		if (m_BtnTabBuy)
		{
			if (newMode == "buy")
				m_BtnTabBuy.SetColor(Color.FromRGBA(46, 128, 56, 255));
			else
				m_BtnTabBuy.SetColor(Color.FromRGBA(89, 89, 102, 255));
		}
		if (m_BtnTabSell)
		{
			if (newMode == "sell")
				m_BtnTabSell.SetColor(Color.FromRGBA(140, 56, 140, 255));
			else
				m_BtnTabSell.SetColor(Color.FromRGBA(89, 89, 102, 255));
		}
		
		// Met a jour le label du bouton d action (preview)
		if (m_BuyButton)
		{
			TextWidget btnText = TextWidget.Cast(m_BuyButton.FindAnyWidget("BuyButtonText"));
			if (!btnText)
			{
				// Si pas de child nomme BuyButtonText, on cherche le 1er TextWidget enfant
				Widget child = m_BuyButton.GetChildren();
				while (child && !btnText)
				{
					btnText = TextWidget.Cast(child);
					child = child.GetSibling();
				}
			}
			if (btnText)
			{
				if (newMode == "sell")
					btnText.SetText("Vendre");
				else
					btnText.SetText("Acheter");
			}
			m_BuyButton.SetEnabled(false);
		}
		
		// Reset preview
		if (m_PreviewTitle)
			m_PreviewTitle.SetText("");
		if (m_PreviewPrice)
			m_PreviewPrice.SetText("");
		
		// Reset page en changeant de mode
		m_CurrentPage = 0;
		
		// Rebuild categories (pour masquer/reafficher les vides en mode sell)
		BuildCategories();
		
		// Rebuild la liste avec le nouveau mode
		BuildEntries();
	}
	
	//------------------------------------------------------------------------------------------------
	// === PAGINATION ===
	// Met a jour l affichage des boutons Precedent/Suivant et le label "Page X / Y".
	// - totalPages = 0 ou 1 : masque les 3 widgets (pas besoin de pagination)
	// - totalPages > 1 : affiche + active/desactive Precedent/Suivant selon la page courante
	//------------------------------------------------------------------------------------------------
	void UpdatePagination(int totalPages)
	{
		bool needPagination = totalPages > 1;
		
		if (m_BtnPrevPage)
		{
			m_BtnPrevPage.SetVisible(needPagination);
			m_BtnPrevPage.SetEnabled(m_CurrentPage > 0);
			if (m_CurrentPage > 0)
				m_BtnPrevPage.SetColor(Color.FromRGBA(46, 128, 56, 255));
			else
				m_BtnPrevPage.SetColor(Color.FromRGBA(89, 89, 102, 255));
		}
		if (m_BtnNextPage)
		{
			m_BtnNextPage.SetVisible(needPagination);
			m_BtnNextPage.SetEnabled(m_CurrentPage < totalPages - 1);
			if (m_CurrentPage < totalPages - 1)
				m_BtnNextPage.SetColor(Color.FromRGBA(46, 128, 56, 255));
			else
				m_BtnNextPage.SetColor(Color.FromRGBA(89, 89, 102, 255));
		}
		if (m_PageLabel)
		{
			m_PageLabel.SetVisible(needPagination);
			if (needPagination)
				m_PageLabel.SetText(string.Format("Page %1 / %2", m_CurrentPage + 1, totalPages));
			else
				m_PageLabel.SetText("");
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Passe a la page suivante (si possible). Rebuild la liste.
	// Le focus manette est place sur le 1er item de la nouvelle page (via BuildEntries),
	// ce qui evite de coincer le joueur sur les boutons pagination en bas.
	//------------------------------------------------------------------------------------------------
	void GoToNextPage()
	{
		m_CurrentPage = m_CurrentPage + 1;
		m_SelectedIndex = -1;
		if (m_PreviewTitle) m_PreviewTitle.SetText("");
		if (m_PreviewPrice) m_PreviewPrice.SetText("");
		if (m_BuyButton) m_BuyButton.SetEnabled(false);
		BuildEntries();
	}
	
	//------------------------------------------------------------------------------------------------
	// Retourne a la page precedente (si possible). Rebuild la liste.
	// Le focus manette est place sur le 1er item de la nouvelle page (via BuildEntries).
	//------------------------------------------------------------------------------------------------
	void GoToPrevPage()
	{
		if (m_CurrentPage > 0)
			m_CurrentPage = m_CurrentPage - 1;
		m_SelectedIndex = -1;
		if (m_PreviewTitle) m_PreviewTitle.SetText("");
		if (m_PreviewPrice) m_PreviewPrice.SetText("");
		if (m_BuyButton) m_BuyButton.SetEnabled(false);
		BuildEntries();
	}
	
	//------------------------------------------------------------------------------------------------
	// === PHASE 3 - CATEGORIES ===
	//------------------------------------------------------------------------------------------------
	// Construit la colonne des boutons categories a gauche.
	// - Si le shop n a pas de categorie -> masque le conteneur
	// - Sinon cree un bouton par categorie, met en surbrillance la selectionnee
	// - En mode "sell", masque les categories qui n ont aucun item vendable dans l inventaire
	//------------------------------------------------------------------------------------------------
	void BuildCategories()
	{
		if (!m_CategoriesContainer)
			return;
		
		// Reset des enfants existants
		Widget child = m_CategoriesContainer.GetChildren();
		while (child)
		{
			Widget next = child.GetSibling();
			child.RemoveFromHierarchy();
			child = next;
		}
		m_CatButtonToName.Clear();
		
		// Aucune categorie -> masque le conteneur
		if (!m_Categories || m_Categories.Count() == 0)
		{
			m_CategoriesContainer.SetVisible(false);
			return;
		}
		m_CategoriesContainer.SetVisible(true);
		
		WorkspaceWidget ws = GetGame().GetWorkspace();
		if (!ws)
			return;
		
		const int CAT_HEIGHT = 42;
		const int CAT_PADDING = 5;
		const int CAT_WIDTH = 195;
		
		int row = 0;
		string firstVisibleCat = "";
		
		foreach (string cat : m_Categories)
		{
			// En mode "sell" : masque les categories sans item vendable
			if (m_Mode == "sell" && !HasSellableItemsInCategory(cat))
				continue;
			
			// Cree le bouton categorie via le nouveau layout dedie
			Widget catWidget = ws.CreateWidgets(CATEGORY_LAYOUT_PATH, m_CategoriesContainer);
			if (!catWidget)
				continue;
			
			FrameSlot.SetPos(catWidget, 0, row * (CAT_HEIGHT + CAT_PADDING));
			FrameSlot.SetSize(catWidget, CAT_WIDTH, CAT_HEIGHT);
			row++;
			
			// Bouton cliquable + texte
			ButtonWidget btn = ButtonWidget.Cast(catWidget.FindAnyWidget("CategoryButton"));
			if (btn)
			{
				m_CatButtonToName.Set(btn, cat);
				ShopClickHandler ch = new ShopClickHandler();
				ch.m_Menu = this;
				ch.m_Mode = "category";
				btn.AddHandler(ch);
				JobFocusHandler.Attach(btn);
				
				// Surbrillance de la categorie selectionnee
				if (cat == m_SelectedCategory)
					btn.SetColor(Color.FromRGBA(46, 128, 56, 255));
				else
					btn.SetColor(Color.FromRGBA(60, 60, 65, 255));
			}
			
			// Texte de la categorie (dans le TextWidget "CategoryText")
			TextWidget txt = TextWidget.Cast(catWidget.FindAnyWidget("CategoryText"));
			if (txt)
				txt.SetText(cat);
			
			if (firstVisibleCat == "")
				firstVisibleCat = cat;
		}
		
		// Si la categorie selectionnee n est plus visible (mode sell), on prend la 1ere disponible
		if (m_SelectedCategory != "" && firstVisibleCat != ""
			&& !HasSellableItemsInCategory(m_SelectedCategory) && m_Mode == "sell")
		{
			m_SelectedCategory = firstVisibleCat;
			// Rebuild pour appliquer la nouvelle surbrillance
			BuildCategories();
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Handler clic sur une categorie
	//------------------------------------------------------------------------------------------------
	void OnCategoryClicked(ButtonWidget btn)
	{
		string cat;
		if (!m_CatButtonToName.Find(btn, cat))
			return;
		if (cat == m_SelectedCategory)
			return;  // deja selectionnee
		
		m_SelectedCategory = cat;
		m_SelectedIndex = -1;
		m_CurrentPage = 0;  // Reset page en changeant de categorie
		
		// Reset preview
		if (m_PreviewTitle) m_PreviewTitle.SetText("");
		if (m_PreviewPrice) m_PreviewPrice.SetText("");
		if (m_BuyButton) m_BuyButton.SetEnabled(false);
		
		// Rebuild : catégories (pour surbrillance) + entries filtrees
		BuildCategories();
		BuildEntries();
	}
	
	//------------------------------------------------------------------------------------------------
	// Verifie si une categorie contient au moins 1 item vendable dans l inventaire du joueur.
	// Utilise pour masquer les categories vides en mode "sell".
	//------------------------------------------------------------------------------------------------
	bool HasSellableItemsInCategory(string category)
	{
		array<ref JobShopItem> items = JobShopCatalog.GetItemsForJobAndCategory(m_Job, category);
		if (!items) return false;
		foreach (JobShopItem it : items)
		{
			if (!it) continue;
			if (CountItemInInventory(it.m_Prefab) > 0)
				return true;
		}
		return false;
	}
	
	//------------------------------------------------------------------------------------------------
	// Retourne l index GLOBAL d un item dans le catalogue complet (via son prefab).
	// Utilise pour convertir un index filtre -> index global au moment du stockage.
	// -1 si l item n est pas trouve.
	//------------------------------------------------------------------------------------------------
	int GlobalIndexOf(JobShopItem target)
	{
		if (!target) return -1;
		array<ref JobShopItem> all = JobShopCatalog.GetItemsForJob(m_Job);
		if (!all) return -1;
		for (int i = 0; i < all.Count(); i++)
		{
			JobShopItem it = all.Get(i);
			if (!it) continue;
			if (it.m_Prefab == target.m_Prefab)
				return i;
		}
		return -1;
	}
	
	//------------------------------------------------------------------------------------------------
	// Compte combien d items du prefab donne sont presents dans l inventaire du joueur local
	// Renvoie 0 si pas d inventaire ou aucun item correspondant
	//------------------------------------------------------------------------------------------------
	int CountItemInInventory(ResourceName prefab)
	{
		if (prefab == "")
			return 0;
		
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc)
			return 0;
		IEntity localChar = pc.GetControlledEntity();
		if (!localChar)
			return 0;
		
		SCR_InventoryStorageManagerComponent inv = SCR_InventoryStorageManagerComponent.Cast(
			localChar.FindComponent(SCR_InventoryStorageManagerComponent));
		if (!inv)
			return 0;
		
		array<IEntity> items = new array<IEntity>();
		inv.GetItems(items);
		
		int count = 0;
		foreach (IEntity item : items)
		{
			if (!item) continue;
			EntityPrefabData pd = item.GetPrefabData();
			if (!pd) continue;
			if (pd.GetPrefabName() == prefab)
				count++;
		}
		return count;
	}
	
	//------------------------------------------------------------------------------------------------
	void CloseMenuInternal()
	{
		GetGame().GetMenuManager().CloseMenu(this);
	}
}

//------------------------------------------------------------------------------------------------
class ShopClickHandler : ScriptedWidgetEventHandler
{
	JobShopMenu m_Menu;
	string m_Mode;  // "close" | "preview" | "buy" | "tab_buy" | "tab_sell" | "category" | "page_prev" | "page_next"
	
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (!m_Menu)
			return false;
		
		if (m_Mode == "close")
		{
			m_Menu.CloseMenuInternal();
			return true;
		}
		
		if (m_Mode == "buy")
		{
			// Le bouton "buy" est en fait l action principale du mode courant
			// (achat OU vente selon m_Mode du menu)
			m_Menu.OnActionButtonClicked();
			return true;
		}
		
		if (m_Mode == "tab_buy")
		{
			m_Menu.SwitchMode("buy");
			return true;
		}
		
		if (m_Mode == "tab_sell")
		{
			m_Menu.SwitchMode("sell");
			return true;
		}
		
		if (m_Mode == "category")
		{
			ButtonWidget btn = ButtonWidget.Cast(w);
			if (btn)
				m_Menu.OnCategoryClicked(btn);
			return true;
		}
		
		if (m_Mode == "page_prev")
		{
			m_Menu.GoToPrevPage();
			return true;
		}
		if (m_Mode == "page_next")
		{
			m_Menu.GoToNextPage();
			return true;
		}
		
		if (m_Mode == "preview")
		{
			ButtonWidget btn = ButtonWidget.Cast(w);
			if (btn)
				m_Menu.OnEntryClicked(btn);
			return true;
		}
		
		return false;
	}
}