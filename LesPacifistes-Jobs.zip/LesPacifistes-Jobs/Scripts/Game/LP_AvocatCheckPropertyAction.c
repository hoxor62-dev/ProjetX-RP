//------------------------------------------------------------------------------------------------
// LP_AvocatCheckPropertyAction.c
// Action "Verification Propriete" a placer sur une entite dediee via Workbench (bureau avocat).
// Visible UNIQUEMENT si le joueur a le metier AVOCAT.
// Ouvre le menu LP_AvocatCheckPropertyMenu en lecture seule (aucune modification possible).
//------------------------------------------------------------------------------------------------

class LP_AvocatCheckPropertyAction : ScriptedUserAction
{
	//------------------------------------------------------------------------------------------------
	override bool CanBeShownScript(IEntity user)
	{
		if (!user) return false;
		
		JobCharacterJobComponent jcjc = JobCharacterJobComponent.Cast(
			user.FindComponent(JobCharacterJobComponent));
		if (!jcjc) return false;
		
		return jcjc.GetJob() == EJobType.AVOCAT;
	}
	
	//------------------------------------------------------------------------------------------------
	override bool CanBePerformedScript(IEntity user)
	{
		return CanBeShownScript(user);
	}
	
	//------------------------------------------------------------------------------------------------
	override bool GetActionNameScript(out string outName)
	{
		outName = "Verification Propriete";
		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
	{
		PlayerController pc = PlayerController.Cast(GetGame().GetPlayerController());
		if (!pc) return;
		if (pUserEntity != pc.GetControlledEntity()) return;
		
		JobCharacterJobComponent jcjc = JobCharacterJobComponent.Cast(
			pUserEntity.FindComponent(JobCharacterJobComponent));
		if (!jcjc || jcjc.GetJob() != EJobType.AVOCAT)
			return;
		
		GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.LP_AvocatCheckPropertyMenu);
	}
}
