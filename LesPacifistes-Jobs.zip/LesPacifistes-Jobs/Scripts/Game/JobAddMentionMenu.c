//------------------------------------------------------------------------------------------------
// JobAddMentionMenu.c
// Menu de saisie d'une mention manuelle a ajouter au casier d'un joueur
// Champ libre via EditBoxWidget
//------------------------------------------------------------------------------------------------

class JobAddMentionMenu : ChimeraMenuBase
{
	Widget m_RootWidget;
	EditBoxWidget m_Input;
	TextWidget m_TargetText;
	int m_TargetPlayerId;
	string m_TargetName;
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuOpen()
	{
		super.OnMenuOpen();
		m_RootWidget = GetRootWidget();
		if (!m_RootWidget)
			return;
		
		m_Input = EditBoxWidget.Cast(m_RootWidget.FindAnyWidget("MentionInput"));
		m_TargetText = TextWidget.Cast(m_RootWidget.FindAnyWidget("TargetText"));
		
		ButtonWidget valid = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("ValidateButton"));
		if (valid)
		{
			MentionMenuClickHandler h = new MentionMenuClickHandler();
			h.m_Menu = this;
			h.m_Action = "validate";
			valid.AddHandler(h);
			JobFocusHandler.Attach(valid);
		}
		
		ButtonWidget cancel = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("CancelButton"));
		if (cancel)
		{
			MentionMenuClickHandler h = new MentionMenuClickHandler();
			h.m_Menu = this;
			h.m_Action = "cancel";
			cancel.AddHandler(h);
			JobFocusHandler.Attach(cancel);
		}
		
		if (m_Input)
			GetGame().GetWorkspace().SetFocusedWidget(m_Input);
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuUpdate(float tDelta)
	{
		super.OnMenuUpdate(tDelta);
		if (GetGame().GetInputManager().GetActionValue("MenuBack") > 0.5)
		{
			CloseMenuInternal();
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void Initialize(int targetPlayerId, string targetName)
	{
		m_TargetPlayerId = targetPlayerId;
		m_TargetName = targetName;
		if (m_TargetText)
			m_TargetText.SetText("Cible: " + targetName);
	}
	
	//------------------------------------------------------------------------------------------------
	void OnActionClicked(string action)
	{
		if (action == "cancel")
		{
			CloseMenuInternal();
			return;
		}
		if (action != "validate")
			return;
		
		if (!m_Input)
		{
			CloseMenuInternal();
			return;
		}
		
		string text = m_Input.GetText();
		if (text == "")
		{
			LP_NotificationManager.Show(
				"Texte vide - mention non ajoutee",
				"Casier judiciaire",
				3);
			return;
		}
		
		PlayerController pc = GetGame().GetPlayerController();
		if (pc)
		{
			JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
			if (jpc)
				jpc.ClientAskAddMention(m_TargetPlayerId, text);
		}
		CloseMenuInternal();
	}
	
	//------------------------------------------------------------------------------------------------
	void CloseMenuInternal()
	{
		GetGame().GetMenuManager().CloseMenu(this);
	}
}

class MentionMenuClickHandler : ScriptedWidgetEventHandler
{
	JobAddMentionMenu m_Menu;
	string m_Action;
	
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu)
			m_Menu.OnActionClicked(m_Action);
		return true;
	}
}
