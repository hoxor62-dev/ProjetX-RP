//------------------------------------------------------------------------------------------------
// LP_TowVehicleAction.c
// Action "Remorquer vehicule" a placer sur les depanneuses via Workbench (ActionsManagerComponent).
// Visible pour les metiers MECANICIEN et FOURRIERE (les 2 ont besoin de la depanneuse).
//
// Comportement : cherche le vehicule le plus proche dans un rayon de 5m autour de la depanneuse
// et le teleporte sur son plateau. Le tick 100ms du LP_TowManager le maintient dessus quand
// la depanneuse se deplace.
//------------------------------------------------------------------------------------------------

class LP_TowVehicleAction : ScriptedUserAction
{
	//------------------------------------------------------------------------------------------------
	// Autorise l usage de la depanneuse pour MECANICIEN ou FOURRIERE
	//------------------------------------------------------------------------------------------------
	protected bool CanUseTowTruck(IEntity user)
	{
		if (!user) return false;
		JobCharacterJobComponent jcjc = JobCharacterJobComponent.Cast(
			user.FindComponent(JobCharacterJobComponent));
		if (!jcjc) return false;
		EJobType job = jcjc.GetJob();
		return (job == EJobType.MECANICIEN || job == EJobType.FOURRIERE);
	}

	//------------------------------------------------------------------------------------------------
	override bool CanBeShownScript(IEntity user)
	{
		return CanUseTowTruck(user);
	}

	//------------------------------------------------------------------------------------------------
	override bool CanBePerformedScript(IEntity user)
	{
		return CanUseTowTruck(user);
	}

	//------------------------------------------------------------------------------------------------
	override bool GetActionNameScript(out string outName)
	{
		outName = "Remorquer vehicule";
		return true;
	}

	//------------------------------------------------------------------------------------------------
	override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
	{
		PlayerController pc = PlayerController.Cast(GetGame().GetPlayerController());
		if (!pc) return;
		if (pUserEntity != pc.GetControlledEntity()) return;

		if (!CanUseTowTruck(pUserEntity))
			return;

		// Recupere le RplId de la depanneuse (pOwnerEntity) pour envoi au serveur
		RplComponent rpl = RplComponent.Cast(pOwnerEntity.FindComponent(RplComponent));
		if (!rpl) return;

		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;

		jpc.ClientAskTowVehicle(rpl.Id());
	}
}
