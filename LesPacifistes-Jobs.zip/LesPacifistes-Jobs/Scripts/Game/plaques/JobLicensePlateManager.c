//------------------------------------------------------------------------------------------------
// JobLicensePlateManager.c
// Singleton SERVEUR qui gere les plaques d immatriculation uniques par vehicule.
//
// FORMAT : AB-123-CD (FR moderne) - 2 lettres + 3 chiffres + 2 lettres
// UNICITE : garantie serveur-side (impossible qu un vehicule ait la plaque d un autre)
// PERSISTANCE : sauvee dans $profile:LesPacifistesJobs/license_plates.json
// LIAISON : via m_VehicleUUID du LP_VehiclePersistComponent (meme UUID que le garage virtuel)
//
// === INTEGRATION ===
// Dans JobVirtualGarageManager, appeler :
//   1) Dans RegisterNewPurchase (apres SetVehicleUUID), AVANT le MarkActiveSaveDirty :
//        JobLicensePlateManager.GetInstance().AssignPlateToVehicle(vehicle, uuid);
//
//   2) Dans RegisterRetrievedVehicle (meme endroit) :
//        JobLicensePlateManager.GetInstance().AssignPlateToVehicle(vehicle, uuid);
//
//   3) Dans ReconcileActiveVehiclesAtStartup (apres FindActiveVehicleByUUID reussi, par
//      vehicule retrouve) :
//        JobLicensePlateManager.GetInstance().AssignPlateToVehicle(vehicleEnt, data.m_VehicleUUID);
//------------------------------------------------------------------------------------------------

class JobLicensePlateManager
{
    protected static ref JobLicensePlateManager s_Instance;

    protected const string SAVE_PATH = "$profile:LesPacifistesJobs/license_plates.json";

    // Charset pour la generation
    protected const string LETTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

    // Map UUID vehicule -> plaque
    protected ref map<string, string> m_UUIDToPlate = new map<string, string>();

    // Set des plaques deja utilisees (pour verif unicite rapide)
    protected ref map<string, bool> m_UsedPlates = new map<string, bool>();

    // Debounce save (eviter d ecrire disque a chaque assignation)
    protected const int SAVE_DEBOUNCE_MS = 5000;
    protected bool m_bSaveDirty = false;
    protected bool m_bSaveScheduled = false;

    //------------------------------------------------------------------------------------------------
    static JobLicensePlateManager GetInstance()
    {
        if (!s_Instance)
        {
            s_Instance = new JobLicensePlateManager();
            s_Instance.LoadFromDisk();
        }
        return s_Instance;
    }

    //------------------------------------------------------------------------------------------------
    // POINT D ENTREE PRINCIPAL : assigne une plaque unique a un vehicule (via son UUID stable).
    // Si l UUID a deja une plaque enregistree, on la reutilise.
    // Sinon, on genere une nouvelle plaque unique.
    // Puis on applique la plaque sur le composant FC_LicensePlateComponent du vehicule si present.
    //------------------------------------------------------------------------------------------------
    void AssignPlateToVehicle(IEntity vehicle, string uuid)
    {
        if (!vehicle || uuid == "")
            return;

        string plate = GetOrCreatePlateForUUID(uuid);
        ApplyPlateToVehicle(vehicle, plate);
    }

    //------------------------------------------------------------------------------------------------
    // Retourne la plaque associee a un UUID (ou vide si inconnue).
    //------------------------------------------------------------------------------------------------
    string GetPlateForUUID(string uuid)
    {
        if (uuid == "")
            return "";
        string plate;
        if (m_UUIDToPlate.Find(uuid, plate))
            return plate;
        return "";
    }

    //------------------------------------------------------------------------------------------------
    // Lookup inverse : retourne l UUID du vehicule associe a une plaque (ou "" si inconnue).
    // Utilise par la recherche police par plaque d immatriculation.
    //------------------------------------------------------------------------------------------------
    string GetUUIDForPlate(string plate)
    {
        if (plate == "")
            return "";
        plate.ToUpper();
        int count = m_UUIDToPlate.Count();
        for (int i = 0; i < count; i++)
        {
            if (m_UUIDToPlate.GetElement(i) == plate)
                return m_UUIDToPlate.GetKey(i);
        }
        return "";
    }

    //------------------------------------------------------------------------------------------------
    // Retourne la plaque existante OU en genere une nouvelle unique si l UUID n en a pas.
    //------------------------------------------------------------------------------------------------
    string GetOrCreatePlateForUUID(string uuid)
    {
        if (uuid == "")
            return "";

        string existing;
        if (m_UUIDToPlate.Find(uuid, existing))
            return existing;

        // Pas de plaque enregistree : genere une nouvelle unique
        string newPlate = GenerateUniquePlate();
        m_UUIDToPlate.Set(uuid, newPlate);
        m_UsedPlates.Set(newPlate, true);
        MarkDirty();

        Print(string.Format("[JobLicensePlateManager] Nouvelle plaque : uuid=%1 plate=%2",
            uuid, newPlate), LogLevel.NORMAL);
        return newPlate;
    }

    //------------------------------------------------------------------------------------------------
    // Genere une plaque AB-123-CD unique. Boucle jusqu a trouver une non-utilisee.
    //------------------------------------------------------------------------------------------------
    string GenerateUniquePlate()
    {
        for (int attempt = 0; attempt < 1000; attempt++)
        {
            string plate = GenerateRandomPlate();
            if (!m_UsedPlates.Contains(plate))
                return plate;
        }
        // Theoriquement impossible d atteindre ici avec 457M combinaisons.
        Print("[JobLicensePlateManager] WARNING : impossible de generer une plaque unique apres 1000 tentatives !", LogLevel.ERROR);
        return GenerateRandomPlate();
    }

    //------------------------------------------------------------------------------------------------
    // Genere une plaque aleatoire AB-123-CD
    //------------------------------------------------------------------------------------------------
    protected string GenerateRandomPlate()
    {
        string plate = "";
        plate += RandomLetter();
        plate += RandomLetter();
        plate += "-";
        plate += Math.RandomInt(0, 10).ToString();
        plate += Math.RandomInt(0, 10).ToString();
        plate += Math.RandomInt(0, 10).ToString();
        plate += "-";
        plate += RandomLetter();
        plate += RandomLetter();
        return plate;
    }

    //------------------------------------------------------------------------------------------------
    protected string RandomLetter()
    {
        int idx = Math.RandomInt(0, LETTERS.Length());
        return LETTERS.Get(idx);
    }

    //------------------------------------------------------------------------------------------------
    // Applique la plaque sur le composant FC_LicensePlateComponent du vehicule (si present).
    //------------------------------------------------------------------------------------------------
    void ApplyPlateToVehicle(IEntity vehicle, string plate)
    {
        if (!vehicle || plate == "")
            return;
        FC_LicensePlateComponent plateComp = FC_LicensePlateComponent.Cast(
            vehicle.FindComponent(FC_LicensePlateComponent));
        if (plateComp)
            plateComp.SetPlate(plate);
    }

    //------------------------------------------------------------------------------------------------
    // === DEBOUNCE DES SAVES ===
    //------------------------------------------------------------------------------------------------
    protected void MarkDirty()
    {
        m_bSaveDirty = true;
        if (!m_bSaveScheduled)
        {
            m_bSaveScheduled = true;
            GetGame().GetCallqueue().CallLater(FlushSave, SAVE_DEBOUNCE_MS, false);
        }
    }

    protected void FlushSave()
    {
        m_bSaveScheduled = false;
        if (!m_bSaveDirty)
            return;
        m_bSaveDirty = false;
        SaveToDisk();
    }

    //------------------------------------------------------------------------------------------------
    void SaveToDisk()
    {
        SCR_JsonSaveContext ctx = new SCR_JsonSaveContext();
        int count = m_UUIDToPlate.Count();
        ctx.WriteValue("entry_count", count);
        for (int i = 0; i < count; i++)
        {
            string uuid = m_UUIDToPlate.GetKey(i);
            string plate = m_UUIDToPlate.GetElement(i);
            string prefix = "entry_" + i.ToString() + "_";
            ctx.WriteValue(prefix + "uuid", uuid);
            ctx.WriteValue(prefix + "plate", plate);
        }
        ctx.SaveToFile(SAVE_PATH);
        Print(string.Format("[JobLicensePlateManager] %1 plaques sauvees sur disque", count), LogLevel.NORMAL);
    }

    //------------------------------------------------------------------------------------------------
    void LoadFromDisk()
    {
        m_UUIDToPlate.Clear();
        m_UsedPlates.Clear();

        SCR_JsonLoadContext ctx = new SCR_JsonLoadContext();
        if (!ctx.LoadFromFile(SAVE_PATH))
        {
            Print("[JobLicensePlateManager] Pas de save de plaques (premier run)", LogLevel.NORMAL);
            return;
        }

        int count = 0;
        ctx.ReadValue("entry_count", count);
        for (int i = 0; i < count; i++)
        {
            string prefix = "entry_" + i.ToString() + "_";
            string uuid, plate;
            ctx.ReadValue(prefix + "uuid", uuid);
            ctx.ReadValue(prefix + "plate", plate);
            if (uuid != "" && plate != "")
            {
                m_UUIDToPlate.Set(uuid, plate);
                m_UsedPlates.Set(plate, true);
            }
        }
        Print(string.Format("[JobLicensePlateManager] %1 plaques chargees depuis le disque",
            m_UUIDToPlate.Count()), LogLevel.NORMAL);
    }

    //------------------------------------------------------------------------------------------------
    // Admin : liste toutes les plaques (debug)
    //------------------------------------------------------------------------------------------------
    void DebugListAll()
    {
        Print(string.Format("[JobLicensePlateManager] === %1 plaques enregistrees ===",
            m_UUIDToPlate.Count()), LogLevel.NORMAL);
        for (int i = 0; i < m_UUIDToPlate.Count(); i++)
        {
            Print(string.Format("  uuid=%1 plate=%2",
                m_UUIDToPlate.GetKey(i), m_UUIDToPlate.GetElement(i)), LogLevel.NORMAL);
        }
    }

    //------------------------------------------------------------------------------------------------
    // Admin : change manuellement la plaque d un vehicule (via UUID). Garantit l unicite.
    //------------------------------------------------------------------------------------------------
    bool AdminChangePlate(string uuid, string newPlate, IEntity vehicle = null)
    {
        if (uuid == "" || newPlate == "")
            return false;
        newPlate.ToUpper();
        if (m_UsedPlates.Contains(newPlate))
            return false; // deja utilisee

        // Retire l ancienne plaque du set
        string oldPlate;
        if (m_UUIDToPlate.Find(uuid, oldPlate))
            m_UsedPlates.Remove(oldPlate);

        m_UUIDToPlate.Set(uuid, newPlate);
        m_UsedPlates.Set(newPlate, true);
        MarkDirty();

        // Applique sur le vehicule physique si fourni
        if (vehicle)
            ApplyPlateToVehicle(vehicle, newPlate);

        Print(string.Format("[JobLicensePlateManager] AdminChangePlate : uuid=%1 old=%2 new=%3",
            uuid, oldPlate, newPlate), LogLevel.NORMAL);
        return true;
    }
}
