[ComponentEditorProps(category: "FrenchCore/Vehicles", description: "Plaque d'immatriculation : quads generes dont les UV pointent dans un atlas de caracteres")]
class FC_LicensePlateComponentClass : ScriptComponentClass
{
}

class FC_LicensePlateComponent : ScriptComponent
{
	// Taille fixe du maillage : les caracteres non utilises sont des quads aplatis (invisibles)
	protected static const int MAX_CHARS = 10;
	protected static const int MAX_VERTS = 40;		// MAX_CHARS * 4
	protected static const int MAX_INDICES = 60;	// MAX_CHARS * 6

	[Attribute("", UIWidgets.ResourcePickerThumbnail, "Materiau de l'atlas (alpha test)", params: "emat", category: "Plaque")]
	protected ResourceName m_sAtlasMaterial;

	[Attribute("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ- ", desc: "Caracteres de l'atlas, dans l'ordre (gauche->droite, haut->bas)", category: "Plaque")]
	protected string m_sCharset;

	[Attribute("8", desc: "Colonnes de l'atlas", category: "Plaque")]
	protected int m_iColumns;

	[Attribute("5", desc: "Lignes de l'atlas", category: "Plaque")]
	protected int m_iRows;

	[Attribute("0.002", desc: "Marge UV dans chaque case (evite le bavement des mipmaps)", category: "Plaque")]
	protected float m_fUVPadding;

	[Attribute("0.042 0.075 0", desc: "Taille d'un caractere en metres (largeur hauteur)", category: "Plaque")]
	protected vector m_vCharSize;

	[Attribute("0.047", desc: "Pas entre deux caracteres en metres", category: "Plaque")]
	protected float m_fAdvance;

	[Attribute("0 0.6 -2.3", desc: "Position locale sur le vehicule (devant le fond de plaque)", category: "Plaque")]
	protected vector m_vOffset;

	[Attribute("0 0 0", desc: "Rotation locale (les quads regardent vers -Z)", category: "Plaque")]
	protected vector m_vAngles;

	[Attribute("AB-123-CD", desc: "Plaque par defaut", category: "Plaque")]
	protected string m_sDefaultPlate;

	[RplProp(onRplName: "OnPlateChanged")]
	protected string m_sPlate;

	protected ref Resource m_MeshResource;
	protected MeshObject m_Mesh;
	protected IEntity m_PlateEntity;

	//------------------------------------------------------------------------------------------------
	//! A appeler cote serveur : change la plaque pour tout le monde
	void SetPlate(string text)
	{
		if (!Replication.IsServer())
			return;

		text.ToUpper();
		m_sPlate = text;
		Replication.BumpMe();
		OnPlateChanged(); // OnRpl n'est appele que sur les clients
	}

	//------------------------------------------------------------------------------------------------
	string GetPlate()
	{
		return m_sPlate;
	}

	//------------------------------------------------------------------------------------------------
	protected void OnPlateChanged()
	{
		if (m_Mesh)
			UpdatePlateMesh();
	}

	//------------------------------------------------------------------------------------------------
	override protected void OnPostInit(IEntity owner)
	{
		if (Replication.IsServer() && m_sPlate.IsEmpty())
			m_sPlate = m_sDefaultPlate;

		SetEventMask(owner, EntityEvent.INIT);
	}

	//------------------------------------------------------------------------------------------------
	override protected void EOnInit(IEntity owner)
	{
		if (System.IsConsoleApp())
			return; // serveur dedie : rien a afficher

		CreatePlateEntity(owner);
		UpdatePlateMesh();
	}

	//------------------------------------------------------------------------------------------------
	override protected void OnDelete(IEntity owner)
	{
		if (m_PlateEntity)
			SCR_EntityHelper.DeleteEntityAndChildren(m_PlateEntity);
	}

	//------------------------------------------------------------------------------------------------
	//! Entite locale (non repliquee) attachee au vehicule, qui porte le maillage genere
	protected void CreatePlateEntity(IEntity owner)
	{
		m_PlateEntity = GetGame().SpawnEntity(GenericEntity, owner.GetWorld());
		owner.AddChild(m_PlateEntity, -1);

		vector rot[3];
		Math3D.AnglesToMatrix(m_vAngles, rot);
		vector mat[4];
		mat[0] = rot[0];
		mat[1] = rot[1];
		mat[2] = rot[2];
		mat[3] = m_vOffset;
		m_PlateEntity.SetLocalTransform(mat);

		string materials[1] = {m_sAtlasMaterial};
		int numVerts[1] = {MAX_VERTS};
		int numIndices[1] = {MAX_INDICES};
		m_MeshResource = MeshObject.Create(1, numVerts, numIndices, materials, 0);
		m_Mesh = m_MeshResource.GetResource().ToMeshObject();
		m_PlateEntity.SetObject(m_Mesh, "");
	}

	//------------------------------------------------------------------------------------------------
	//! Le coeur du systeme : place un quad par caractere et cale ses UV sur la case de l'atlas
	protected void UpdatePlateMesh()
	{
		vector verts[MAX_VERTS];	// tout a zero = quads aplatis, donc invisibles
		float uvs[MAX_VERTS * 2];
		int indices[MAX_INDICES];

		int count = Math.Min(m_sPlate.Length(), MAX_CHARS);
		float cellU = 1.0 / m_iColumns;
		float cellV = 1.0 / m_iRows;
		float halfW = m_vCharSize[0] * 0.5;
		float halfH = m_vCharSize[1] * 0.5;
		float startX = -(count - 1) * m_fAdvance * 0.5; // texte centre sur l'origine

		for (int i = 0; i < count; i++)
		{
			int glyph = m_sCharset.IndexOf(m_sPlate.Get(i));
			if (glyph < 0)
				continue; // caractere absent de l'atlas : quad laisse aplati

			// Case du caractere dans l'atlas
			int col = glyph % m_iColumns;
			int row = glyph / m_iColumns;
			float u0 = col * cellU + m_fUVPadding;
			float u1 = (col + 1) * cellU - m_fUVPadding;
			float v0 = row * cellV + m_fUVPadding;
			float v1 = (row + 1) * cellV - m_fUVPadding;

			// Quad face a -Z, sens horaire comme SCR_GenericBoxEntity : haut-gauche, haut-droit, bas-droit, bas-gauche
			float x = startX + i * m_fAdvance;
			int v = i * 4;
			verts[v]     = Vector(x - halfW,  halfH, 0);
			verts[v + 1] = Vector(x + halfW,  halfH, 0);
			verts[v + 2] = Vector(x + halfW, -halfH, 0);
			verts[v + 3] = Vector(x - halfW, -halfH, 0);

			int t = v * 2;
			uvs[t]     = u0;	uvs[t + 1] = v0;
			uvs[t + 2] = u1;	uvs[t + 3] = v0;
			uvs[t + 4] = u1;	uvs[t + 5] = v1;
			uvs[t + 6] = u0;	uvs[t + 7] = v1;

			int k = i * 6;
			indices[k]     = v;		indices[k + 1] = v + 1;	indices[k + 2] = v + 2;
			indices[k + 3] = v + 2;	indices[k + 4] = v + 3;	indices[k + 5] = v;
		}

		m_Mesh.UpdateVerts(0, verts, uvs);
		m_Mesh.UpdateIndices(0, indices);
	}
}
