//------------------------------------------------------------------------------------------------
// JobTresorData.c
// Constantes et donnees du systeme de fouille de coffre au tresor sous-marin.
//
// Modele probabiliste : a chaque tirage (toutes les 30 secondes), chaque item est tire
// INDEPENDAMMENT selon sa probabilite. Plusieurs items peuvent etre obtenus en meme temps
// (ou aucun, si tous les tirages echouent).
//
// Items rares : tout item dont la proba est <= 15% est considere comme rare et declenche
// le hint "Vous avez obtenu un item rare".
//------------------------------------------------------------------------------------------------

class JobTresorLootEntry
{
	string m_PrefabName;     // ResourceName du prefab a spawn
	int m_ProbabilityPercent; // 0..100, probabilite independante a chaque tirage
	
	void JobTresorLootEntry(string prefab, int probaPercent)
	{
		m_PrefabName = prefab;
		m_ProbabilityPercent = probaPercent;
	}
}

class JobTresorData
{
	// ===== CONSTANTES =====
	
	// Duree totale d une recherche (en secondes)
	const int RECHERCHE_DURATION_SECONDS = 300;  // 5 minutes
	
	// Interval entre 2 tirages de loot (en secondes)
	const int LOOT_TICK_INTERVAL_SECONDS = 30;
	
	// Distance maximale entre le joueur et le coffre (en metres)
	const float MAX_DISTANCE_FROM_COFFRE = 15.0;
	
	// Cooldown apres une recherche COMPLETE (en secondes)
	const int COOLDOWN_SECONDS = 7200;
	
	// Seuil de probabilite pour qu un item soit considere comme rare
	const int RARITY_THRESHOLD_PERCENT = 15;
	
	// Items requis sur le joueur pour ouvrir le coffre
	static const string REQUIRED_ITEM_FINS = "{3AA20990C37114B2}Prefabs/Items/Equipment/Accessories/ETool_ALICE/clecoffre.et";
	static const string REQUIRED_ITEM_SCUBA = "{3AA20990C37114B2}Prefabs/Items/Equipment/Accessories/ETool_ALICE/clecoffre.et";
	
	//------------------------------------------------------------------------------------------------
	// Loot table : items potentiels + leurs probas independantes par tirage
	//------------------------------------------------------------------------------------------------
	static array<ref JobTresorLootEntry> GetLootTable()
	{
		array<ref JobTresorLootEntry> table = new array<ref JobTresorLootEntry>();
		// Chaines en or - rares (15%)
		table.Insert(new JobTresorLootEntry("{4BD92C5231A3940D}Prefabs/Cordao/GoldChain2.et", 15));
		table.Insert(new JobTresorLootEntry("{E25E88CA0B28A408}Prefabs/Clothing/Chain.et", 15));
		table.Insert(new JobTresorLootEntry("{1CD36D3E3CDA7ADB}Prefabs/Clothing/BME_Scapulario.et", 15));
		table.Insert(new JobTresorLootEntry("{B660612952B6B5D8}Prefabs/Clothing/Chucky_Chain.et", 15));
		table.Insert(new JobTresorLootEntry("{61E261CDE10A07BD}Prefabs/Clothing/Cuban_Cross_Chain.et", 15));
		table.Insert(new JobTresorLootEntry("{C95ADA51AB7B9644}Prefabs/Clothing/Demon_Time_Chain.et", 15));
		table.Insert(new JobTresorLootEntry("{D2DAF01768448970}Prefabs/Clothing/Jesus_Chain.et", 15));
		table.Insert(new JobTresorLootEntry("{11C09AB21D527236}Prefabs/Clothing/Trap_Queen.et", 15));
		table.Insert(new JobTresorLootEntry("{B660612952B6B5D8}Prefabs/Clothing/Chucky_Chain.et", 15));
		table.Insert(new JobTresorLootEntry("{BBBB926DB67F9DE1}Prefabs/Clothing/Chrome_Hearts_Nun_Chain.et", 15));
		


		// Lingot d or - tres rare (5%)
		table.Insert(new JobTresorLootEntry("{CD7E4794F5D40A0B}Prefabs/Items/Equipment/bargold/bargold.et", 5));
		table.Insert(new JobTresorLootEntry("{C6D29778D28BA23A}Prefabs/Weapons/Grenades/pepiteor.et", 5));
		// Items communs (>15%)
		table.Insert(new JobTresorLootEntry("{F0A9B1F935F3268F}Prefabs/Weapons/Grenades/ROCK2.et", 45));
		table.Insert(new JobTresorLootEntry("{10066BA2DCD677D3}Prefabs/Items/Equipment/Accessories/ETool_ALICE/Hache.et", 30));
		table.Insert(new JobTresorLootEntry("{CFB03731B536D8A4}Prefabs/Items/Equipment/Accessories/ETool_ALICE/Pick2.et", 30));
		return table;
	}
	
	//------------------------------------------------------------------------------------------------
	// Verifie si un item est considere comme rare (proba <= seuil)
	//------------------------------------------------------------------------------------------------
	static bool IsRareItem(int probaPercent)
	{
		return probaPercent <= RARITY_THRESHOLD_PERCENT;
	}
}
