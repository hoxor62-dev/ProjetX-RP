//------------------------------------------------------------------------------------------------
// JobPompisteRefillMenu.c
// Menu CLIENT affichant l animation de refill station cote POMPISTE.
//
// Workflow :
//   1. Pompiste clique "Remplir la station essence" sur une pompe
//   2. ClientAskPompisteRefillStation(rpl) -> serveur
//   3. Serveur refill la station (300L max), paye 1 cap/litre au pompiste
//   4. Serveur renvoie les resultats via RpcDo_OpenPompisteRefillResult
//   5. Le menu s ouvre avec animation : litres remplis monte de 0 a totalLitres,
//      capsules gagnees monte de 0 a totalCaps
//
// L animation est purement visuelle. Le refill et le paiement sont deja finalises
// cote serveur au moment ou le menu s ouvre.
//------------------------------------------------------------------------------------------------

class JobPompisteRefillMenu : ChimeraMenuBase
{
	const int ANIMATION_MS = 5000; // Duree totale (5s)
	const int TICK_MS = 50;         // Rafraichissement

	// === DONNEES PRE-CHARGEES (set par RpcDo_OpenPompisteRefillResult AVANT OpenMenu) ===
	static float s_PendingLiters = 0;       // litres rajoutes a la station
	static int s_PendingReward = 0;         // capsules gagnees
	static float s_PendingStationFuel = 0;  // reserve station APRES refill
	static int s_PendingResultCode = 0;     // 0 = OK, 1 = deja pleine
	static string s_PendingStatusMessage = "";

	Widget m_RootWidget;
	TextWidget m_LitersText;
	TextWidget m_RewardText;
	TextWidget m_StationFuelText;
	TextWidget m_StatusText;
	ImageWidget m_ProgressFill;
	ButtonWidget m_BtnClose;

	// === Etat animation runtime ===
	float m_TargetLiters;
	int m_TargetReward;
	float m_AnimElapsedMs = 0;
	bool m_AnimationDone = false;

	//------------------------------------------------------------------------------------------------
	static void SetPendingData(float liters, int reward, float stationFuel, int resultCode, string status)
	{
		s_PendingLiters = liters;
		s_PendingReward = reward;
		s_PendingStationFuel = stationFuel;
		s_PendingResultCode = resultCode;
		s_PendingStatusMessage = status;
	}

	//------------------------------------------------------------------------------------------------
	override void OnMenuOpen()
	{
		super.OnMenuOpen();
		JobFocusHandler.ClearRegistry();

		m_RootWidget = GetRootWidget();
		if (!m_RootWidget) return;

		m_LitersText = TextWidget.Cast(m_RootWidget.FindAnyWidget("LitersText"));
		m_RewardText = TextWidget.Cast(m_RootWidget.FindAnyWidget("RewardText"));
		m_StationFuelText = TextWidget.Cast(m_RootWidget.FindAnyWidget("StationFuelText"));
		m_StatusText = TextWidget.Cast(m_RootWidget.FindAnyWidget("StatusText"));
		m_ProgressFill = ImageWidget.Cast(m_RootWidget.FindAnyWidget("ProgressFill"));
		m_BtnClose = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnClose"));

		if (m_BtnClose)
		{
			PompisteRefillCloseHandler h = new PompisteRefillCloseHandler();
			h.m_Menu = this;
			m_BtnClose.AddHandler(h);
			JobFocusHandler.Attach(m_BtnClose);
		}

		// Reserve station affichee immediatement (apres refill)
		if (m_StationFuelText)
		{
			int stationLitersInt = s_PendingStationFuel;
			m_StationFuelText.SetText(string.Format("Reserve station : %1 / 300 L",
				stationLitersInt.ToString()));
		}

		// === CAS D ERREUR : pas d animation, affiche juste le message ===
		if (s_PendingResultCode != 0)
		{
			if (m_LitersText) m_LitersText.SetText("--- L remplis");
			if (m_RewardText) m_RewardText.SetText("--- capsules gagnees");
			if (m_StatusText)
			{
				m_StatusText.SetText(s_PendingStatusMessage);
				m_StatusText.SetColor(Color.FromRGBA(255, 120, 120, 255)); // rouge
			}
			m_AnimationDone = true;
			return;
		}

		// === CAS OK : lance l animation ===
		m_TargetLiters = s_PendingLiters;
		m_TargetReward = s_PendingReward;
		m_AnimElapsedMs = 0;
		m_AnimationDone = false;

		if (m_StatusText)
		{
			m_StatusText.SetText("Remplissage station en cours...");
			m_StatusText.SetColor(Color.FromRGBA(220, 220, 220, 255));
		}

		UpdateAnimation();
		GetGame().GetCallqueue().CallLater(UpdateAnimation, TICK_MS, true);
	}

	//------------------------------------------------------------------------------------------------
	// Tick animation : interpole litres + recompense de 0 a target sur ANIMATION_MS
	//------------------------------------------------------------------------------------------------
	void UpdateAnimation()
	{
		if (m_AnimationDone) return;

		m_AnimElapsedMs = m_AnimElapsedMs + TICK_MS;
		float ratio = m_AnimElapsedMs / ANIMATION_MS;
		if (ratio >= 1.0)
		{
			ratio = 1.0;
			m_AnimationDone = true;
			GetGame().GetCallqueue().Remove(UpdateAnimation);

			if (m_StatusText)
			{
				m_StatusText.SetText("Station remplie.");
				m_StatusText.SetColor(Color.FromRGBA(140, 240, 140, 255)); // vert
			}
		}

		float currentLiters = m_TargetLiters * ratio;
		int currentReward = Math.Round(m_TargetReward * ratio);

		// Affiche les textes
		if (m_LitersText)
		{
			m_LitersText.SetText(string.Format("%1 / %2 L remplis",
				FormatOneDecimal(currentLiters),
				FormatOneDecimal(m_TargetLiters)));
		}
		if (m_RewardText)
		{
			m_RewardText.SetText(string.Format("+%1 / +%2 capsules gagnees",
				currentReward.ToString(),
				m_TargetReward.ToString()));
		}

		// Barre de progression (480px de large)
		if (m_ProgressFill)
		{
			int w = Math.Round(480 * ratio);
			m_ProgressFill.SetSize(w, 22);
		}
	}

	//------------------------------------------------------------------------------------------------
	string FormatOneDecimal(float value)
	{
		int whole = value;
		int decimalPart = Math.AbsFloat((value - whole) * 10);
		return whole.ToString() + "." + decimalPart.ToString();
	}

	//------------------------------------------------------------------------------------------------
	override void OnMenuClose()
	{
		GetGame().GetCallqueue().Remove(UpdateAnimation);
		super.OnMenuClose();
	}

	//------------------------------------------------------------------------------------------------
	override void OnMenuUpdate(float tDelta)
	{
		super.OnMenuUpdate(tDelta);
		if (GetGame().GetInputManager().GetActionValue("MenuBack") > 0.5)
			CloseMenuInternal();
	}

	//------------------------------------------------------------------------------------------------
	void CloseMenuInternal()
	{
		GetGame().GetMenuManager().CloseMenu(this);
	}
}

//------------------------------------------------------------------------------------------------
class PompisteRefillCloseHandler : ScriptedWidgetEventHandler
{
	JobPompisteRefillMenu m_Menu;

	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.CloseMenuInternal();
		return true;
	}
}
