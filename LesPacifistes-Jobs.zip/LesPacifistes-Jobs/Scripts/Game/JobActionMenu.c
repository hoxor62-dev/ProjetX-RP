//------------------------------------------------------------------------------------------------
// JobActionMenu.c
// Menu ouvert quand le joueur parle a un PNJ specialise (PNJ mineur, policier, militaire, etc).
// Propose plusieurs actions selon le metier:
//  - "Voir les quetes" (metiers interim)
//  - "Recevoir equipement et outils de service" (tous sauf chomeur)
//  - "Acheter un vehicule" (concessionnaire uniquement)
//------------------------------------------------------------------------------------------------

class JobActionMenu : ChimeraMenuBase
{
	const string LAYOUT_PATH = "{1E379FD7D6F01B1B}UI/layouts/JobActionMenu.layout";
	
	Widget m_RootWidget;
	TextWidget m_TitleText;
	ButtonWidget m_TurnInButton;
	ButtonWidget m_QuestsButton;
	ButtonWidget m_EquipmentButton;
	ButtonWidget m_VehiclesButton;
	ButtonWidget m_ServiceVehicleButton;
	ButtonWidget m_AmmoButton;
	ButtonWidget m_DeliverLicenseButton;
	ButtonWidget m_GangButton;
	ButtonWidget m_CloseButton;
	
	EJobType m_Job;
	RplId m_NpcRplId;
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuOpen()
	{
		super.OnMenuOpen();
		m_RootWidget = GetRootWidget();
		if (!m_RootWidget)
			return;
		
		m_TitleText = TextWidget.Cast(m_RootWidget.FindAnyWidget("TitleText"));
		m_TurnInButton = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("TurnInButton"));
		m_QuestsButton = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("QuestsButton"));
		m_EquipmentButton = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("EquipmentButton"));
		m_VehiclesButton = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("VehiclesButton"));
		m_ServiceVehicleButton = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("ServiceVehicleButton"));
		m_AmmoButton = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("AmmoButton"));
		m_DeliverLicenseButton = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("DeliverLicenseButton"));
		m_GangButton = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("GangButton"));
		m_CloseButton = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("CloseButton"));
		
		ActionClickHandler closeHandler = new ActionClickHandler();
		closeHandler.m_Menu = this;
		closeHandler.m_Action = "close";
		if (m_CloseButton)
		{
			m_CloseButton.AddHandler(closeHandler);
			JobFocusHandler.Attach(m_CloseButton);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void Initialize(EJobType job, RplId npcRplId)
	{
		m_Job = job;
		m_NpcRplId = npcRplId;
		
		if (m_TitleText)
			m_TitleText.SetText("PNJ " + JobData.GetJobLabel(job));
		
		ButtonWidget firstVisible = null;
		
		// TurnInButton: visible seulement si quete READY_TO_TURN_IN et que ce PNJ correspond au metier de la quete
		bool canTurnIn = false;
		PlayerController pc = GetGame().GetPlayerController();
		if (pc)
		{
			JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
			if (jpc && jpc.IsClientQuestReadyToTurnIn())
			{
				int activeQuestInt = jpc.GetClientActiveQuestType();
				EQuestType activeQuest = activeQuestInt;
				JobQuest q = JobQuestData.GetQuest(activeQuest);
				// On accepte le turn in si ce PNJ est du meme metier que celui qui a donne la quete
				if (q && q.m_ForJob == job)
					canTurnIn = true;
			}
		}
		
		if (m_TurnInButton)
		{
			m_TurnInButton.SetEnabled(canTurnIn);
			m_TurnInButton.SetVisible(canTurnIn);
			ActionClickHandler turnInHandler = new ActionClickHandler();
			turnInHandler.m_Menu = this;
			turnInHandler.m_Action = "turn_in";
			m_TurnInButton.AddHandler(turnInHandler);
			JobFocusHandler.Attach(m_TurnInButton);
			if (canTurnIn)
				firstVisible = m_TurnInButton;
		}
		
		// Affichage conditionnel des boutons
		if (m_QuestsButton)
		{
			bool hasQuests = JobData.HasQuests(job);
			m_QuestsButton.SetEnabled(hasQuests);
			m_QuestsButton.SetVisible(hasQuests);
			ActionClickHandler ch = new ActionClickHandler();
			ch.m_Menu = this;
			ch.m_Action = "quests";
			m_QuestsButton.AddHandler(ch);
			JobFocusHandler.Attach(m_QuestsButton);
			if (hasQuests && !firstVisible)
				firstVisible = m_QuestsButton;
		}
		
		if (m_EquipmentButton)
		{
			bool hasEquip = JobData.HasEquipment(job);
			m_EquipmentButton.SetEnabled(hasEquip);
			m_EquipmentButton.SetVisible(hasEquip);
			ActionClickHandler ch = new ActionClickHandler();
			ch.m_Menu = this;
			ch.m_Action = "equipment";
			m_EquipmentButton.AddHandler(ch);
			JobFocusHandler.Attach(m_EquipmentButton);
			if (hasEquip && !firstVisible)
				firstVisible = m_EquipmentButton;
		}
		
		if (m_VehiclesButton)
		{
			bool hasShop = JobShopCatalog.HasShop(job);
			m_VehiclesButton.SetEnabled(hasShop);
			m_VehiclesButton.SetVisible(hasShop);
			
			// Label dynamique (Voyou = marche noir, Concessionnaire = vehicules)
			if (hasShop)
			{
				TextWidget txt = TextWidget.Cast(m_VehiclesButton.FindAnyWidget("VehiclesText"));
				if (txt)
					txt.SetText(JobShopCatalog.GetShopButtonLabel(job));
			}
			
			ActionClickHandler ch = new ActionClickHandler();
			ch.m_Menu = this;
			ch.m_Action = "vehicles";
			m_VehiclesButton.AddHandler(ch);
			JobFocusHandler.Attach(m_VehiclesButton);
			if (hasShop && !firstVisible)
				firstVisible = m_VehiclesButton;
		}
		
		if (m_ServiceVehicleButton)
		{
			bool hasServiceVeh = JobData.HasServiceVehicle(job);
			m_ServiceVehicleButton.SetEnabled(hasServiceVeh);
			m_ServiceVehicleButton.SetVisible(hasServiceVeh);
			
			ActionClickHandler ch = new ActionClickHandler();
			ch.m_Menu = this;
			ch.m_Action = "service_vehicle";
			m_ServiceVehicleButton.AddHandler(ch);
			JobFocusHandler.Attach(m_ServiceVehicleButton);
			if (hasServiceVeh && !firstVisible)
				firstVisible = m_ServiceVehicleButton;
		}
		
		// Bouton "Munitions supplementaires" - police et militaire uniquement
		if (m_AmmoButton)
		{
			bool hasAmmo = JobData.HasAmmoResupply(job);
			m_AmmoButton.SetEnabled(hasAmmo);
			m_AmmoButton.SetVisible(hasAmmo);
			
			ActionClickHandler ch = new ActionClickHandler();
			ch.m_Menu = this;
			ch.m_Action = "ammo";
			m_AmmoButton.AddHandler(ch);
			JobFocusHandler.Attach(m_AmmoButton);
			if (hasAmmo && !firstVisible)
				firstVisible = m_AmmoButton;
		}
		
		// Bouton "Delivrer un permis" - uniquement pour le concessionnaire
		if (m_DeliverLicenseButton)
		{
			bool isConces = (job == EJobType.CONCESSIONNAIRE);
			m_DeliverLicenseButton.SetEnabled(isConces);
			m_DeliverLicenseButton.SetVisible(isConces);
			
			ActionClickHandler ch = new ActionClickHandler();
			ch.m_Menu = this;
			ch.m_Action = "deliver_license";
			m_DeliverLicenseButton.AddHandler(ch);
			JobFocusHandler.Attach(m_DeliverLicenseButton);
			if (isConces && !firstVisible)
				firstVisible = m_DeliverLicenseButton;
		}
		
		// Bouton "Gerer mon Gang" - uniquement pour le VOYOU
		if (m_GangButton)
		{
			bool isVoyou = (job == EJobType.VOYOU);
			m_GangButton.SetEnabled(isVoyou);
			m_GangButton.SetVisible(isVoyou);
			
			ActionClickHandler ch = new ActionClickHandler();
			ch.m_Menu = this;
			ch.m_Action = "gang";
			m_GangButton.AddHandler(ch);
			JobFocusHandler.Attach(m_GangButton);
			if (isVoyou && !firstVisible)
				firstVisible = m_GangButton;
		}
		
		// Fallback: focus sur Fermer si aucun bouton d'action disponible
		if (!firstVisible)
			firstVisible = m_CloseButton;
		
		if (firstVisible)
			GetGame().GetWorkspace().SetFocusedWidget(firstVisible);
	}
	
	//------------------------------------------------------------------------------------------------
	void OnActionClicked(string action)
	{
		if (action == "close")
		{
			CloseMenuInternal();
			return;
		}
		
		if (action == "equipment")
		{
			RequestEquipment();
			return;
		}
		
		if (action == "quests")
		{
			OpenQuestMenu();
			return;
		}
		
		if (action == "vehicles")
		{
			// Ouvre la boutique (Voyou = armes, Concessionnaire = vehicules)
			OpenShopMenu();
			return;
		}
		
		if (action == "service_vehicle")
		{
			RequestServiceVehicle();
			return;
		}
		
		if (action == "ammo")
		{
			RequestAmmoResupply();
			return;
		}
		
		if (action == "deliver_license")
		{
			GetGame().GetMenuManager().CloseMenu(this);
			JobLicenseGrantMenu menu = JobLicenseGrantMenu.Cast(
				GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.JobLicenseGrantMenu));
			if (menu)
				menu.Initialize();
			return;
		}
		
		if (action == "turn_in")
		{
			TurnInQuest();
			return;
		}
		
		if (action == "gang")
		{
			OpenGangMenu();
			return;
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Ouvre le menu gang : demande au serveur l etat du gang du joueur,
	// la reponse RPC ouvrira le bon menu (creation ou gestion)
	//------------------------------------------------------------------------------------------------
	void OpenGangMenu()
	{
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc)
			return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc)
			return;
		
		jpc.ClientAskGangInfo();
		CloseMenuInternal();
	}
	
	//------------------------------------------------------------------------------------------------
	void TurnInQuest()
	{
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc)
			return;
		
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc)
			return;
		
		jpc.ClientAskTurnInQuest();
		CloseMenuInternal();
	}
	
	//------------------------------------------------------------------------------------------------
	void OpenQuestMenu()
	{
		JobQuestMenu qm = JobQuestMenu.Cast(GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.JobQuestMenu));
		if (qm)
			qm.Initialize(m_Job);
		CloseMenuInternal();
	}
	
	//------------------------------------------------------------------------------------------------
	void RequestServiceVehicle()
	{
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc)
			return;
		
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc)
			return;
		
		jpc.ClientAskServiceVehicle();
		CloseMenuInternal();
	}
	
	//------------------------------------------------------------------------------------------------
	void RequestAmmoResupply()
	{
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc)
			return;
		
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc)
			return;
		
		jpc.ClientAskAmmoResupply();
		CloseMenuInternal();
	}
	
	//------------------------------------------------------------------------------------------------
	void OpenShopMenu()
	{
		JobShopMenu shop = JobShopMenu.Cast(GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.JobShopMenu));
		if (shop)
			shop.Initialize(m_Job, m_NpcRplId);
		
		CloseMenuInternal();
	}
	
	//------------------------------------------------------------------------------------------------
	void RequestEquipment()
	{
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc)
			return;
		
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc)
		{
			Print("[JobActionMenu] JobPlayerComponent manquant sur le PlayerController local",
				LogLevel.WARNING);
			return;
		}
		
		jpc.ClientAskEquipment();
		
		CloseMenuInternal();
	}
	
	//------------------------------------------------------------------------------------------------
	void CloseMenuInternal()
	{
		GetGame().GetMenuManager().CloseMenu(this);
	}
}

//------------------------------------------------------------------------------------------------
class ActionClickHandler : ScriptedWidgetEventHandler
{
	JobActionMenu m_Menu;
	string m_Action;
	
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu)
			m_Menu.OnActionClicked(m_Action);
		return true;
	}
}
