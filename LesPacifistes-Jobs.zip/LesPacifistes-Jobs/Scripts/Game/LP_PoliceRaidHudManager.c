//------------------------------------------------------------------------------------------------
// LP_PoliceRaidHudManager.c
// Client-side : gere l affichage du HUD "Perquisition en cours" avec barre + timer.
// Singleton : Show(remainingMs) / Hide() / auto-tick pour update la barre.
//------------------------------------------------------------------------------------------------

class LP_PoliceRaidHudManager
{
	static ref LP_PoliceRaidHudManager s_Instance;
	
	Widget m_Root;
	ImageWidget m_BarFill;
	TextWidget m_TimerText;
	
	float m_EndTimeMs = 0;
	float m_TotalDurationMs = 60000; // 60s
	bool m_Visible = false;
	
	const int BAR_WIDTH_MAX = 416; // 420 - 2*2 padding
	const int BAR_HEIGHT = 22;
	
	//------------------------------------------------------------------------------------------------
	static LP_PoliceRaidHudManager GetInstance()
	{
		if (!s_Instance) s_Instance = new LP_PoliceRaidHudManager();
		return s_Instance;
	}
	
	//------------------------------------------------------------------------------------------------
	// Affiche le HUD avec le temps restant (ms)
	void Show(int remainingMs)
	{
		if (m_Visible)
		{
			// Deja affiche, juste update le end time
			UpdateEndTime(remainingMs);
			return;
		}
		
		WorkspaceWidget ws = GetGame().GetWorkspace();
		if (!ws) return;
		
		m_Root = ws.CreateWidgets("UI/layouts/LP_PoliceRaidHud.layout");
		if (!m_Root) return;
		
		m_BarFill = ImageWidget.Cast(m_Root.FindAnyWidget("BarFill"));
		m_TimerText = TextWidget.Cast(m_Root.FindAnyWidget("TimerText"));
		
		UpdateEndTime(remainingMs);
		m_Visible = true;
		
		// Tick 250ms pour animation fluide
		GetGame().GetCallqueue().Remove(TickHud);
		GetGame().GetCallqueue().CallLater(TickHud, 250, true);
	}
	
	//------------------------------------------------------------------------------------------------
	// Met a jour le end time base sur remainingMs
	protected void UpdateEndTime(int remainingMs)
	{
		float now = GetGame().GetWorld().GetWorldTime();
		m_EndTimeMs = now + remainingMs;
	}
	
	//------------------------------------------------------------------------------------------------
	// Cache le HUD
	void Hide()
	{
		if (!m_Visible) return;
		
		GetGame().GetCallqueue().Remove(TickHud);
		if (m_Root)
		{
			m_Root.RemoveFromHierarchy();
			m_Root = null;
		}
		m_BarFill = null;
		m_TimerText = null;
		m_Visible = false;
	}
	
	//------------------------------------------------------------------------------------------------
	// Refresh visuel : barre + timer
	protected void TickHud()
	{
		if (!m_Visible || !m_Root) return;
		
		float now = GetGame().GetWorld().GetWorldTime();
		float remainingMs = m_EndTimeMs - now;
		if (remainingMs < 0) remainingMs = 0;
		
		// Barre : remplit de 0 -> BAR_WIDTH_MAX au fur et a mesure que le temps s ecoule
		float progress = 1.0 - (remainingMs / m_TotalDurationMs);
		if (progress < 0) progress = 0;
		if (progress > 1) progress = 1;
		int barW = progress * BAR_WIDTH_MAX;
		if (m_BarFill) m_BarFill.SetSize(barW, BAR_HEIGHT);
		
		// Timer text : MM:SS
		int totalSec = remainingMs / 1000;
		int mn = totalSec / 60;
		int sec = totalSec - (mn * 60);
		string mnStr = mn.ToString();
		string secStr = sec.ToString();
		if (mn < 10) mnStr = "0" + mnStr;
		if (sec < 10) secStr = "0" + secStr;
		if (m_TimerText) m_TimerText.SetText(mnStr + ":" + secStr);
	}
}
