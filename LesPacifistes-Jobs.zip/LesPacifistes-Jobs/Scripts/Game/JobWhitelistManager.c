//------------------------------------------------------------------------------------------------
// JobWhitelistManager.c
// Manager singleton SERVEUR pour la whitelist des joueurs.
//
// Lit un fichier JSON simple : une liste d UIDs Bohemia autorises a se connecter.
// Format du fichier :
//   $profile:LesPacifistesJobs/whitelist.json
//   {
//     "uids": ["UID_1", "UID_2", "UID_3"]
//   }
//
// Les admins (ou un bot Discord externe) modifient ce JSON directement.
// Le manager le recharge a chaque demarrage serveur (et peut etre force a recharger).
//
// IMPORTANT : ce systeme est ISOLE des autres managers pour eviter tout risque
// d affecter le gameplay existant.
//------------------------------------------------------------------------------------------------

class JobWhitelistManager
{
	static ref JobWhitelistManager s_Instance;
	
	const string WHITELIST_PATH = "$profile:LesPacifistesJobs/whitelist.json";
	const int GRACE_PERIOD_SECONDS = 60;  // delai d affichage avant kick
	const int RELOAD_INTERVAL_MS = 300000;  // 5 minutes = 5 * 60 * 1000
	
	// Set des UIDs autorises (cle = UID, valeur = true)
	ref map<string, bool> m_AllowedUIDs;
	
	// True si le fichier de whitelist a ete charge avec succes au moins une fois.
	// Si false (fichier introuvable), on autorise TOUS les joueurs (safety failsafe :
	// evite de kicker tout le monde si un admin a oublie de creer le fichier).
	bool m_WhitelistLoaded = false;
	
	//------------------------------------------------------------------------------------------------
	void JobWhitelistManager()
	{
		m_AllowedUIDs = new map<string, bool>();
	}
	
	//------------------------------------------------------------------------------------------------
	static JobWhitelistManager GetInstance()
	{
		if (!s_Instance)
		{
			s_Instance = new JobWhitelistManager();
			s_Instance.LoadFromDisk();
			// Demarre le refresh automatique toutes les 5 minutes
			// (permet d ajouter des joueurs au JSON sans redemarrer le serveur)
			GetGame().GetCallqueue().CallLater(s_Instance.LoadFromDisk, RELOAD_INTERVAL_MS, true);
		}
		return s_Instance;
	}
	
	//------------------------------------------------------------------------------------------------
	// Verifie si un UID est autorise.
	// Si le fichier de whitelist n a pas pu etre charge (manquant ou corrompu),
	// retourne TRUE par defaut (failsafe) pour eviter de bloquer tous les joueurs.
	//------------------------------------------------------------------------------------------------
	bool IsAllowed(string uid)
	{
		if (uid == "")
			return false;
		// Failsafe : si pas de fichier whitelist, on laisse tout le monde entrer
		if (!m_WhitelistLoaded)
			return true;
		return m_AllowedUIDs.Contains(uid);
	}
	
	//------------------------------------------------------------------------------------------------
	// Recharge le fichier depuis le disque. Peut etre appele manuellement par un admin
	// (commande in-game future) ou periodiquement.
	//------------------------------------------------------------------------------------------------
	void LoadFromDisk()
	{
		m_AllowedUIDs.Clear();
		m_WhitelistLoaded = false;
		
		SCR_JsonLoadContext ctx = new SCR_JsonLoadContext();
		if (!ctx.LoadFromFile(WHITELIST_PATH))
		{
			Print(string.Format("[JobWhitelistManager] Fichier introuvable : %1 - WHITELIST DESACTIVEE (tous les joueurs sont autorises par defaut)",
				WHITELIST_PATH), LogLevel.WARNING);
			return;
		}
		
		array<string> uids = new array<string>();
		ctx.ReadValue("uids", uids);
		foreach (string uid : uids)
		{
			if (uid != "")
				m_AllowedUIDs.Set(uid, true);
		}
		
		m_WhitelistLoaded = true;
		Print(string.Format("[JobWhitelistManager] %1 UIDs charges depuis %2",
			m_AllowedUIDs.Count().ToString(), WHITELIST_PATH), LogLevel.NORMAL);
	}
	
	//------------------------------------------------------------------------------------------------
	// Ajoute un UID a la whitelist en memoire ET sur disque. Appele par le bouton
	// "Valider WL" du JobAdminPlayerMenu.
	// Retourne : true si ajout OK, false si deja whitelist ou UID vide.
	//------------------------------------------------------------------------------------------------
	bool AddUIDToWhitelist(string uid)
	{
		if (uid == "")
			return false;
		if (m_AllowedUIDs.Contains(uid))
			return false; // deja whitelist

		m_AllowedUIDs.Set(uid, true);
		m_WhitelistLoaded = true;  // au cas ou le failsafe etait actif

		// Reecrit le fichier JSON complet avec tous les UIDs connus
		SaveToDisk();

		Print(string.Format("[JobWhitelistManager] UID ajoute a la whitelist : %1 (total=%2)",
			uid, m_AllowedUIDs.Count().ToString()), LogLevel.NORMAL);
		return true;
	}

	//------------------------------------------------------------------------------------------------
	// Retire un UID de la whitelist en memoire ET sur disque. Appele par le bouton
	// "Retirer WL" du JobAdminPlayerMenu. Combine avec un teleport prison cote appelant.
	// Retourne : true si retrait OK, false si UID vide ou pas dans la WL.
	//------------------------------------------------------------------------------------------------
	bool RemoveUIDFromWhitelist(string uid)
	{
		if (uid == "")
			return false;
		if (!m_AllowedUIDs.Contains(uid))
			return false; // pas dans la WL

		m_AllowedUIDs.Remove(uid);
		SaveToDisk();

		Print(string.Format("[JobWhitelistManager] UID retire de la whitelist : %1 (total=%2)",
			uid, m_AllowedUIDs.Count().ToString()), LogLevel.NORMAL);
		return true;
	}

	//------------------------------------------------------------------------------------------------
	// Sauvegarde la whitelist courante sur disque. Reecrit le JSON entier.
	//------------------------------------------------------------------------------------------------
	void SaveToDisk()
	{
		SCR_JsonSaveContext ctx = new SCR_JsonSaveContext();
		array<string> uids = new array<string>();
		foreach (string uid, bool v : m_AllowedUIDs)
		{
			if (uid != "")
				uids.Insert(uid);
		}
		ctx.WriteValue("uids", uids);
		ctx.SaveToFile(WHITELIST_PATH);
		Print(string.Format("[JobWhitelistManager] Whitelist sauvegardee : %1 UIDs",
			uids.Count().ToString()), LogLevel.NORMAL);
	}

	//------------------------------------------------------------------------------------------------
	// Cree un fichier whitelist vide si inexistant. Appele a l init pour donner
	// un exemple a l admin.
	//------------------------------------------------------------------------------------------------
	void CreateExampleFileIfMissing()
	{
		SCR_JsonLoadContext loadCtx = new SCR_JsonLoadContext();
		if (loadCtx.LoadFromFile(WHITELIST_PATH))
			return;  // existe deja
		
		// Cree un exemple
		SCR_JsonSaveContext ctx = new SCR_JsonSaveContext();
		array<string> emptyList = new array<string>();
		emptyList.Insert("REPLACE_BY_ADMIN_UID_EXAMPLE");
		ctx.WriteValue("uids", emptyList);
		ctx.SaveToFile(WHITELIST_PATH);
		
		Print(string.Format("[JobWhitelistManager] Fichier exemple cree : %1", WHITELIST_PATH),
			LogLevel.NORMAL);
	}
}
