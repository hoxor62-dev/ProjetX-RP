//------------------------------------------------------------------------------------------------
// JobPochonSaleNpcAction.c
// UserAction "Vendre pochons" a placer sur le PNJ acheteur.
// Ouvre le menu JobPochonSaleMenu (verifications finales cote serveur).
//------------------------------------------------------------------------------------------------

class JobPochonSaleNpcAction : ScriptedUserAction
{
	override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
	{
		PlayerController pc = PlayerController.Cast(GetGame().GetPlayerController());
		if (!pc) return;
		if (pUserEntity != pc.GetControlledEntity()) return;
		
		GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.JobPochonSaleMenu);
	}
	
	override bool CanBePerformedScript(IEntity user)
	{
		return true;
	}
	
	override bool CanBeShownScript(IEntity user)
	{
		return true;
	}
}
