//------------------------------------------------------------------------------------------------
// JobBonPointProfileMenu.c
// Onglet Mon Profil :
//   - Stats : nb annonces actives, nb achats a recuperer
//   - Liste 'Mes annonces' avec boutons Modifier/Retirer
//   - Liste 'Mes achats' avec bouton Recuperer
//------------------------------------------------------------------------------------------------

class JobBonPointProfileMenu : ChimeraMenuBase
{
	const string MY_AD_ENTRY_PATH = "{0C208BA81014EBB0}UI/layouts/JobBonPointMyAdEntry.layout";
	const string MY_PURCHASE_ENTRY_PATH = "{8EEFCB24F11C067A}UI/layouts/JobBonPointMyPurchaseEntry.layout";
	
	Widget m_RootWidget;
	TextWidget m_TitleText;
	TextWidget m_StatsText;
	Widget m_AdsContainer;
	Widget m_PurchasesContainer;
	TextWidget m_NoAdsText;
	TextWidget m_NoPurchasesText;
	ButtonWidget m_BtnBack;
	
	// Donnees pre-chargees
	static ref array<int> s_PendingAdIds = new array<int>();
	static ref array<string> s_PendingAdTitles = new array<string>();
	static ref array<int> s_PendingAdPrices = new array<int>();
	static ref array<int> s_PendingAdChatCounts = new array<int>();  // nb d acheteurs qui ont discute
	static ref array<int> s_PendingPurchaseIds = new array<int>();
	static ref array<string> s_PendingPurchaseTitles = new array<string>();
	static ref array<string> s_PendingPurchaseSellerNames = new array<string>();
	
	static JobBonPointProfileMenu s_Instance;
	
	//------------------------------------------------------------------------------------------------
	static void SetPendingData(array<int> adIds, array<string> adTitles, array<int> adPrices,
		array<int> adChatCounts,
		array<int> purchaseIds, array<string> purchaseTitles, array<string> purchaseSellerNames)
	{
		s_PendingAdIds.Clear();
		s_PendingAdTitles.Clear();
		s_PendingAdPrices.Clear();
		s_PendingAdChatCounts.Clear();
		s_PendingPurchaseIds.Clear();
		s_PendingPurchaseTitles.Clear();
		s_PendingPurchaseSellerNames.Clear();
		foreach (int i : adIds) s_PendingAdIds.Insert(i);
		foreach (string t : adTitles) s_PendingAdTitles.Insert(t);
		foreach (int p : adPrices) s_PendingAdPrices.Insert(p);
		foreach (int c : adChatCounts) s_PendingAdChatCounts.Insert(c);
		foreach (int i : purchaseIds) s_PendingPurchaseIds.Insert(i);
		foreach (string t : purchaseTitles) s_PendingPurchaseTitles.Insert(t);
		foreach (string s : purchaseSellerNames) s_PendingPurchaseSellerNames.Insert(s);
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuOpen()
	{
		super.OnMenuOpen();
		s_Instance = this;
		JobFocusHandler.ClearRegistry();
		
		m_RootWidget = GetRootWidget();
		if (!m_RootWidget) return;
		
		m_TitleText = TextWidget.Cast(m_RootWidget.FindAnyWidget("TitleText"));
		m_StatsText = TextWidget.Cast(m_RootWidget.FindAnyWidget("StatsText"));
		m_AdsContainer = m_RootWidget.FindAnyWidget("AdsContainer");
		m_PurchasesContainer = m_RootWidget.FindAnyWidget("PurchasesContainer");
		m_NoAdsText = TextWidget.Cast(m_RootWidget.FindAnyWidget("NoAdsText"));
		m_NoPurchasesText = TextWidget.Cast(m_RootWidget.FindAnyWidget("NoPurchasesText"));
		m_BtnBack = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnBack"));
		
		if (m_TitleText)
			m_TitleText.SetText("Mon Profil");
		if (m_StatsText)
		{
			m_StatsText.SetText(string.Format(
				"Annonces actives : %1 / 5     -     Achats a recuperer : %2",
				s_PendingAdIds.Count().ToString(),
				s_PendingPurchaseIds.Count().ToString()));
		}
		
		// IMPORTANT : on attache BtnBack EN PREMIER pour qu il soit dans le registre du focus,
		// puis on construit les listes (qui attachent leurs propres boutons), et enfin on choisit
		// un focus initial pertinent en fonction du contenu :
		//   - S il y a des achats a recuperer, focus sur le premier bouton "Recuperer"
		//     (probleme manette : sans ca, les joueurs console sans annonce ne peuvent pas
		//     naviguer jusqu a leurs achats)
		//   - Sinon s il y a des annonces, focus sur le 1er bouton "Modifier"
		//   - Sinon focus sur "Retour"
		if (m_BtnBack)
		{
			BonPointProfileHandler h = new BonPointProfileHandler();
			h.m_Menu = this;
			h.m_Action = "back";
			m_BtnBack.AddHandler(h);
			JobFocusHandler.Attach(m_BtnBack);
		}
		
		BuildAdsList();
		BuildPurchasesList();
		
		// Focus initial intelligent (priorite : 1er achat > 1ere annonce > Retour)
		Widget targetFocus = null;
		if (m_PurchasesContainer && s_PendingPurchaseIds.Count() > 0)
		{
			// Cherche le premier BtnRecover dans le container
			Widget firstEntry = m_PurchasesContainer.GetChildren();
			if (firstEntry)
				targetFocus = firstEntry.FindAnyWidget("BtnRecover");
		}
		if (!targetFocus && m_AdsContainer && s_PendingAdIds.Count() > 0)
		{
			Widget firstEntry = m_AdsContainer.GetChildren();
			if (firstEntry)
				targetFocus = firstEntry.FindAnyWidget("BtnEdit");
		}
		if (!targetFocus)
			targetFocus = m_BtnBack;
		
		if (targetFocus)
			GetGame().GetWorkspace().SetFocusedWidget(targetFocus);
	}
	
	//------------------------------------------------------------------------------------------------
	void BuildAdsList()
	{
		if (!m_AdsContainer) return;
		Widget child = m_AdsContainer.GetChildren();
		while (child)
		{
			Widget next = child.GetSibling();
			child.RemoveFromHierarchy();
			child = next;
		}
		
		if (s_PendingAdIds.Count() == 0)
		{
			if (m_NoAdsText)
			{
				m_NoAdsText.SetText("Aucune annonce active.");
				m_NoAdsText.SetVisible(true);
			}
			return;
		}
		if (m_NoAdsText) m_NoAdsText.SetVisible(false);
		
		WorkspaceWidget ws = GetGame().GetWorkspace();
		for (int i = 0; i < s_PendingAdIds.Count(); i++)
		{
			int adId = s_PendingAdIds.Get(i);
			string title = s_PendingAdTitles.Get(i);
			int price = s_PendingAdPrices.Get(i);
			
			Widget entry = ws.CreateWidgets(MY_AD_ENTRY_PATH, m_AdsContainer);
			if (!entry) continue;
			
			TextWidget tw = TextWidget.Cast(entry.FindAnyWidget("AdTitle"));
			if (tw) tw.SetText(title);
			TextWidget pw = TextWidget.Cast(entry.FindAnyWidget("AdPrice"));
			if (pw) pw.SetText(string.Format("%1 c.", price.ToString()));
			
			ButtonWidget btnEdit = ButtonWidget.Cast(entry.FindAnyWidget("BtnEdit"));
			if (btnEdit)
			{
				BonPointMyAdHandler h = new BonPointMyAdHandler();
				h.m_Menu = this;
				h.m_AdId = adId;
				h.m_Action = "edit";
				h.m_CurrentPrice = price;
				btnEdit.AddHandler(h);
				JobFocusHandler.Attach(btnEdit);
			}
			
			// Bouton Discuter (X) : grise si 0 acheteur, actif sinon
			int chatCount = 0;
			if (i < s_PendingAdChatCounts.Count())
				chatCount = s_PendingAdChatCounts.Get(i);
			ButtonWidget btnDiscuss = ButtonWidget.Cast(entry.FindAnyWidget("BtnDiscuss"));
			TextWidget btnDiscussText = TextWidget.Cast(entry.FindAnyWidget("BtnDiscussText"));
			if (btnDiscuss)
			{
				if (btnDiscussText)
					btnDiscussText.SetText(string.Format("Discuter (%1)", chatCount.ToString()));
				if (chatCount <= 0)
				{
					// Grise et desactive
					btnDiscuss.SetEnabled(false);
					btnDiscuss.SetColor(Color.FromRGBA(85, 85, 90, 255));
				}
				else
				{
					btnDiscuss.SetEnabled(true);
					BonPointMyAdHandler h = new BonPointMyAdHandler();
					h.m_Menu = this;
					h.m_AdId = adId;
					h.m_Action = "discuss";
					h.m_AdTitle = title;
					btnDiscuss.AddHandler(h);
					JobFocusHandler.Attach(btnDiscuss);
				}
			}
			
			ButtonWidget btnRemove = ButtonWidget.Cast(entry.FindAnyWidget("BtnRemove"));
			if (btnRemove)
			{
				BonPointMyAdHandler h = new BonPointMyAdHandler();
				h.m_Menu = this;
				h.m_AdId = adId;
				h.m_Action = "remove";
				btnRemove.AddHandler(h);
				JobFocusHandler.Attach(btnRemove);
			}
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void BuildPurchasesList()
	{
		if (!m_PurchasesContainer) return;
		Widget child = m_PurchasesContainer.GetChildren();
		while (child)
		{
			Widget next = child.GetSibling();
			child.RemoveFromHierarchy();
			child = next;
		}
		
		if (s_PendingPurchaseIds.Count() == 0)
		{
			if (m_NoPurchasesText)
			{
				m_NoPurchasesText.SetText("Aucun achat a recuperer.");
				m_NoPurchasesText.SetVisible(true);
			}
			return;
		}
		if (m_NoPurchasesText) m_NoPurchasesText.SetVisible(false);
		
		WorkspaceWidget ws = GetGame().GetWorkspace();
		for (int i = 0; i < s_PendingPurchaseIds.Count(); i++)
		{
			int purchaseId = s_PendingPurchaseIds.Get(i);
			string title = s_PendingPurchaseTitles.Get(i);
			string sellerName = s_PendingPurchaseSellerNames.Get(i);
			
			Widget entry = ws.CreateWidgets(MY_PURCHASE_ENTRY_PATH, m_PurchasesContainer);
			if (!entry) continue;
			
			TextWidget tw = TextWidget.Cast(entry.FindAnyWidget("PurchaseTitle"));
			if (tw) tw.SetText(title);
			TextWidget sw = TextWidget.Cast(entry.FindAnyWidget("PurchaseSeller"));
			if (sw) sw.SetText(string.Format("De : %1", sellerName));
			
			ButtonWidget btn = ButtonWidget.Cast(entry.FindAnyWidget("BtnRecover"));
			if (btn)
			{
				BonPointMyPurchaseHandler h = new BonPointMyPurchaseHandler();
				h.m_Menu = this;
				h.m_PurchaseId = purchaseId;
				btn.AddHandler(h);
				JobFocusHandler.Attach(btn);
			}
		}
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuClose()
	{
		if (s_Instance == this) s_Instance = null;
		super.OnMenuClose();
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuUpdate(float tDelta)
	{
		super.OnMenuUpdate(tDelta);
		if (GetGame().GetInputManager().GetActionValue("MenuBack") > 0.5)
			CloseMenuInternal();
	}
	
	//------------------------------------------------------------------------------------------------
	void OnAction(string action)
	{
		if (action == "back")
		{
			CloseMenuInternal();
			return;
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void OnAdAction(int adId, string action, int currentPrice, string adTitle)
	{
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		
		if (action == "remove")
		{
			jpc.ClientAskRemoveBonPointAd(adId);
			CloseMenuInternal();
			return;
		}
		if (action == "edit")
		{
			JobBonPointEditAdMenu.SetPendingData(adId, currentPrice);
			GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.JobBonPointEditAdMenu);
			CloseMenuInternal();
			return;
		}
		if (action == "discuss")
		{
			// Ouvre la liste des acheteurs qui ont ecrit sur cette annonce
			jpc.ClientAskListBonPointBuyers(adId, adTitle);
			CloseMenuInternal();
			return;
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void OnPurchaseRecover(int purchaseId)
	{
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		jpc.ClientAskRecoverBonPointPurchase(purchaseId);
		CloseMenuInternal();
	}
	
	//------------------------------------------------------------------------------------------------
	void CloseMenuInternal()
	{
		GetGame().GetMenuManager().CloseMenu(this);
	}
}

//------------------------------------------------------------------------------------------------
class BonPointProfileHandler : ScriptedWidgetEventHandler
{
	JobBonPointProfileMenu m_Menu;
	string m_Action;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.OnAction(m_Action);
		return true;
	}
}

//------------------------------------------------------------------------------------------------
class BonPointMyAdHandler : ScriptedWidgetEventHandler
{
	JobBonPointProfileMenu m_Menu;
	int m_AdId;
	string m_Action;
	int m_CurrentPrice;
	string m_AdTitle;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.OnAdAction(m_AdId, m_Action, m_CurrentPrice, m_AdTitle);
		return true;
	}
}

//------------------------------------------------------------------------------------------------
class BonPointMyPurchaseHandler : ScriptedWidgetEventHandler
{
	JobBonPointProfileMenu m_Menu;
	int m_PurchaseId;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.OnPurchaseRecover(m_PurchaseId);
		return true;
	}
}