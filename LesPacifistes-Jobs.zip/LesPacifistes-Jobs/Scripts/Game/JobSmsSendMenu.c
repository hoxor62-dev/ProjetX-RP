//------------------------------------------------------------------------------------------------
// JobSmsSendMenu.c
// Menu d'envoi d'un SMS : selection destinataire + saisie message + envoi via RPC.
//
// Liste des joueurs : tous les joueurs connectes (excluant soi-meme), affiches avec leur
// identite RP si dispo, sinon playername (meme principe que l'ATM).
//------------------------------------------------------------------------------------------------

class JobSmsSendMenu : ChimeraMenuBase
{
	const string ENTRY_LAYOUT_PATH = "{9D68BEB73DF970D8}UI/layouts/JobSmsEntry.layout";
	
	// === PAGINATION ===
	const int PLAYERS_PER_PAGE = 10;
	int m_CurrentPage = 0;
	ref array<int> m_AllPlayerIds = new array<int>();
	ref array<string> m_AllPlayerNames = new array<string>();
	float m_TabPressCooldown = 0;
	
	Widget m_RootWidget;
	Widget m_PlayersContainer;
	EditBoxWidget m_MessageInput;
	TextWidget m_StatusText;
	ButtonWidget m_BtnSend;
	ButtonWidget m_BtnClose;
	ButtonWidget m_PrevPageButton;
	ButtonWidget m_NextPageButton;
	TextWidget m_PageLabel;
	
	// Selection courante
	int m_SelectedPlayerId = -1;
	string m_SelectedDisplayName = "";
	
	// Mapping bouton -> playerId pour highlight
	ref map<ButtonWidget, int> m_ButtonToPlayerId;
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuOpen()
	{
		super.OnMenuOpen();
		JobFocusHandler.ClearRegistry();
		m_RootWidget = GetRootWidget();
		if (!m_RootWidget)
			return;
		
		m_PlayersContainer = m_RootWidget.FindAnyWidget("PlayersContainer");
		m_MessageInput = EditBoxWidget.Cast(m_RootWidget.FindAnyWidget("MessageInput"));
		m_StatusText = TextWidget.Cast(m_RootWidget.FindAnyWidget("StatusText"));
		m_BtnSend = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnSend"));
		m_BtnClose = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnClose"));
		m_PrevPageButton = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("PrevPageButton"));
		m_NextPageButton = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("NextPageButton"));
		m_PageLabel = TextWidget.Cast(m_RootWidget.FindAnyWidget("PageLabel"));
		
		m_ButtonToPlayerId = new map<ButtonWidget, int>();
		
		if (m_PrevPageButton)
		{
			SmsSendButtonHandler hPrev = new SmsSendButtonHandler();
			hPrev.m_Menu = this;
			hPrev.m_Action = "prev_page";
			m_PrevPageButton.AddHandler(hPrev);
			JobFocusHandler.Attach(m_PrevPageButton);
		}
		if (m_NextPageButton)
		{
			SmsSendButtonHandler hNext = new SmsSendButtonHandler();
			hNext.m_Menu = this;
			hNext.m_Action = "next_page";
			m_NextPageButton.AddHandler(hNext);
			JobFocusHandler.Attach(m_NextPageButton);
		}
		
		if (m_BtnSend)
		{
			SmsSendButtonHandler hSend = new SmsSendButtonHandler();
			hSend.m_Menu = this;
			hSend.m_Action = "send";
			m_BtnSend.AddHandler(hSend);
			JobFocusHandler.Attach(m_BtnSend);
		}
		if (m_BtnClose)
		{
			SmsSendButtonHandler hClose = new SmsSendButtonHandler();
			hClose.m_Menu = this;
			hClose.m_Action = "close";
			m_BtnClose.AddHandler(hClose);
			JobFocusHandler.Attach(m_BtnClose);
		}
		
		BuildPlayersList();
		UpdateStatus();
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuUpdate(float tDelta)
	{
		super.OnMenuUpdate(tDelta);
		if (GetGame().GetInputManager().GetActionValue("MenuBack") > 0.5)
		{
			CloseMenuInternal();
			return;
		}
		
		// Navigation pagination manette (LB/RB)
		if (m_TabPressCooldown > 0)
			m_TabPressCooldown = m_TabPressCooldown - tDelta;
		else
		{
			if (GetGame().GetInputManager().GetActionValue("MenuTabLeft") > 0.5)
			{
				PrevPage();
				m_TabPressCooldown = 0.30;
			}
			else if (GetGame().GetInputManager().GetActionValue("MenuTabRight") > 0.5)
			{
				NextPage();
				m_TabPressCooldown = 0.30;
			}
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void BuildPlayersList()
	{
		if (!m_PlayersContainer)
			return;
		
		// === PHASE 1 : cache la liste complete ===
		m_AllPlayerIds.Clear();
		m_AllPlayerNames.Clear();
		m_CurrentPage = 0;
		
		PlayerManager pm = GetGame().GetPlayerManager();
		if (!pm)
			return;
		
		PlayerController localPC = GetGame().GetPlayerController();
		int localId = 0;
		if (localPC)
			localId = localPC.GetPlayerId();
		
		array<int> allPlayers = new array<int>();
		pm.GetPlayers(allPlayers);
		
		foreach (int pid : allPlayers)
		{
			if (pid == localId)
				continue;
			string displayName = JobIdentityManager.GetInstance().Client_GetDisplayName(pid);
			if (displayName == "")
				continue;
			m_AllPlayerIds.Insert(pid);
			m_AllPlayerNames.Insert(displayName);
		}
		
		RenderCurrentPage();
	}
	
	//------------------------------------------------------------------------------------------------
	void RenderCurrentPage()
	{
		if (!m_PlayersContainer)
			return;
		
		// Nettoie les entrees existantes
		Widget child = m_PlayersContainer.GetChildren();
		while (child)
		{
			Widget next = child.GetSibling();
			child.RemoveFromHierarchy();
			child = next;
		}
		m_ButtonToPlayerId.Clear();
		
		int totalPages = GetTotalPages();
		if (m_CurrentPage >= totalPages && totalPages > 0)
			m_CurrentPage = totalPages - 1;
		if (m_CurrentPage < 0)
			m_CurrentPage = 0;
		
		int startIdx = m_CurrentPage * PLAYERS_PER_PAGE;
		int endIdx = startIdx + PLAYERS_PER_PAGE;
		if (endIdx > m_AllPlayerIds.Count())
			endIdx = m_AllPlayerIds.Count();
		
		WorkspaceWidget ws = GetGame().GetWorkspace();
		ButtonWidget firstButton = null;
		
		for (int i = startIdx; i < endIdx; i++)
		{
			int pid = m_AllPlayerIds.Get(i);
			string displayName = m_AllPlayerNames.Get(i);
			
			Widget entry = ws.CreateWidgets(ENTRY_LAYOUT_PATH, m_PlayersContainer);
			if (!entry)
				continue;
			
			TextWidget nameW = TextWidget.Cast(entry.FindAnyWidget("PlayerName"));
			if (nameW)
				nameW.SetText(displayName);
			
			ButtonWidget btn = ButtonWidget.Cast(entry.FindAnyWidget("SelectButton"));
			if (btn)
			{
				SmsPlayerEntryHandler entryH = new SmsPlayerEntryHandler();
				entryH.m_Menu = this;
				entryH.m_PlayerId = pid;
				entryH.m_DisplayName = displayName;
				btn.AddHandler(entryH);
				JobFocusHandler.Attach(btn);
				m_ButtonToPlayerId.Set(btn, pid);
				if (!firstButton)
					firstButton = btn;
				
				// Re-applique couleur selectionnee si on revient sur la page du joueur deja choisi
				if (pid == m_SelectedPlayerId)
				{
					Widget entryRoot = btn.GetParent();
					if (entryRoot)
					{
						ImageWidget bg = ImageWidget.Cast(entryRoot.FindAnyWidget("EntryBackground"));
						if (bg)
							bg.SetColor(Color.FromRGBA(46, 128, 46, 230));
					}
				}
			}
		}
		
		UpdatePaginationUI();
		
		// Focus initial manette
		if (firstButton)
			GetGame().GetWorkspace().SetFocusedWidget(firstButton);
		else if (m_BtnClose)
			GetGame().GetWorkspace().SetFocusedWidget(m_BtnClose);
	}
	
	//------------------------------------------------------------------------------------------------
	int GetTotalPages()
	{
		int total = m_AllPlayerIds.Count();
		if (total == 0)
			return 1;
		return (total + PLAYERS_PER_PAGE - 1) / PLAYERS_PER_PAGE;
	}
	
	//------------------------------------------------------------------------------------------------
	void UpdatePaginationUI()
	{
		int totalPages = GetTotalPages();
		if (m_PageLabel)
			m_PageLabel.SetText(string.Format("Page %1 / %2", m_CurrentPage + 1, totalPages));
		if (m_PrevPageButton)
			m_PrevPageButton.SetEnabled(m_CurrentPage > 0);
		if (m_NextPageButton)
			m_NextPageButton.SetEnabled(m_CurrentPage < totalPages - 1);
	}
	
	//------------------------------------------------------------------------------------------------
	void PrevPage()
	{
		if (m_CurrentPage <= 0)
			return;
		m_CurrentPage--;
		RenderCurrentPage();
	}
	
	//------------------------------------------------------------------------------------------------
	void NextPage()
	{
		if (m_CurrentPage >= GetTotalPages() - 1)
			return;
		m_CurrentPage++;
		RenderCurrentPage();
	}
	
	//------------------------------------------------------------------------------------------------
	void OnPlayerSelected(int pid, string displayName)
	{
		m_SelectedPlayerId = pid;
		m_SelectedDisplayName = displayName;
		
		// Highlight visuel : ligne selectionnee = vert, autres = couleur de base
		// On cible le widget EntryBackground qui est dans le parent du bouton (l entry root)
		foreach (ButtonWidget btn, int id : m_ButtonToPlayerId)
		{
			Widget entryRoot = btn.GetParent();
			if (!entryRoot)
				continue;
			ImageWidget bg = ImageWidget.Cast(entryRoot.FindAnyWidget("EntryBackground"));
			if (!bg)
				continue;
			if (id == pid)
				bg.SetColor(Color.FromRGBA(46, 128, 46, 230));
			else
				bg.SetColor(Color.FromRGBA(30, 30, 38, 230));
		}
		
		UpdateStatus();
	}
	
	//------------------------------------------------------------------------------------------------
	void UpdateStatus()
	{
		if (!m_StatusText)
			return;
		if (m_SelectedPlayerId <= 0)
			m_StatusText.SetText("Selectionnez un destinataire");
		else
			m_StatusText.SetText(string.Format("Destinataire : %1", m_SelectedDisplayName));
	}
	
	//------------------------------------------------------------------------------------------------
	void OnButtonClicked(string action)
	{
		if (action == "close")
		{
			CloseMenuInternal();
			return;
		}
		if (action == "send")
		{
			DoSend();
			return;
		}
		if (action == "prev_page")
		{
			PrevPage();
			return;
		}
		if (action == "next_page")
		{
			NextPage();
			return;
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void DoSend()
	{
		if (m_SelectedPlayerId <= 0)
		{
			if (m_StatusText)
				m_StatusText.SetText("Veuillez selectionner un destinataire");
			return;
		}
		if (!m_MessageInput)
			return;
		string content = m_MessageInput.GetText();
		if (content == "")
		{
			if (m_StatusText)
				m_StatusText.SetText("Le message est vide");
			return;
		}
		if (content.Length() > 150)
		{
			if (m_StatusText)
				m_StatusText.SetText("Message trop long (150 max)");
			return;
		}
		
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc)
			return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc)
			return;
		jpc.ClientAskSendSms(m_SelectedPlayerId, content);
		
		// Confirmation visuelle puis fermeture
		if (m_StatusText)
			m_StatusText.SetText("Envoi en cours...");
		GetGame().GetCallqueue().CallLater(CloseAfterSend, 800, false);
	}
	
	//------------------------------------------------------------------------------------------------
	void CloseAfterSend()
	{
		CloseMenuInternal();
	}
	
	//------------------------------------------------------------------------------------------------
	void CloseMenuInternal()
	{
		GetGame().GetMenuManager().CloseMenu(this);
	}
}

//------------------------------------------------------------------------------------------------
class SmsSendButtonHandler : ScriptedWidgetEventHandler
{
	JobSmsSendMenu m_Menu;
	string m_Action;
	
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu)
			m_Menu.OnButtonClicked(m_Action);
		return true;
	}
}

//------------------------------------------------------------------------------------------------
class SmsPlayerEntryHandler : ScriptedWidgetEventHandler
{
	JobSmsSendMenu m_Menu;
	int m_PlayerId;
	string m_DisplayName;
	
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu)
			m_Menu.OnPlayerSelected(m_PlayerId, m_DisplayName);
		return true;
	}
}
