//------------------------------------------------------------------------------------------------
// LP_PoliceRaidAction.c
// Action "Perquisition" - visible UNIQUEMENT :
//   - joueur local a metier POLICIER ou MILITAIRE
//   - porte a un proprio (HasOwner)
//   - aucune perquisition deja en cours sur cette porte (m_RaidInProgress = false)
//
// Au clic : envoie le RplId au serveur qui verifie belier + 3 officers a 10m puis demarre.
//------------------------------------------------------------------------------------------------

class LP_PoliceRaidAction : ScriptedUserAction
{
	override bool CanBeShownScript(IEntity user)
	{
		if (!user) return false;
		
		// Metier local
		JobCharacterJobComponent jobComp = JobCharacterJobComponent.Cast(
			user.FindComponent(JobCharacterJobComponent));
		if (!jobComp) return false;
		EJobType localJob = jobComp.GetJob();
		if (localJob != EJobType.POLICIER && localJob != EJobType.MILITAIRE) return false;
		
		// Porte a un proprio + aucune perquisition en cours
		IEntity door = GetOwner();
		if (!door) return false;
		LP_DoorAccessComponent access = LP_DoorAccessComponent.Cast(
			door.FindComponent(LP_DoorAccessComponent));
		if (!access || !access.HasOwner()) return false;
		if (access.IsRaidInProgress()) return false;
		
		return true;
	}
	
	override bool CanBePerformedScript(IEntity user) { return CanBeShownScript(user); }
	
	override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
	{
		PlayerController pc = PlayerController.Cast(GetGame().GetPlayerController());
		if (!pc) return;
		if (pUserEntity != pc.GetControlledEntity()) return;
		
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		
		RplComponent rpl = RplComponent.Cast(pOwnerEntity.FindComponent(RplComponent));
		if (!rpl) return;
		
		jpc.ClientAskStartPoliceRaid(rpl.Id());
	}
}
