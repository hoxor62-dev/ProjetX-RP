//------------------------------------------------------------------------------------------------
// JobCaptureZoneAction.c
// UserAction "Taxer la zone par le gang" a ajouter sur le prefab d extraction de drogue
// (le meme prefab qui a JobDrugZoneComponent).
//
// Visible uniquement si le joueur local fait partie d un gang.
// Au clic : envoie une RPC au serveur pour lancer la capture (30 min sur place).
//------------------------------------------------------------------------------------------------

class JobCaptureZoneAction : ScriptedUserAction
{
	//------------------------------------------------------------------------------------------------
	// Visible uniquement si le joueur local est dans un gang (via JobCharacterJobComponent + check gang client)
	// Note : on ne peut pas verifier l appartenance au gang cote client facilement (manager serveur).
	// On affiche donc l action a tout le monde et le serveur refuse si pas de gang.
	// Pour un filtrage plus fin, on pourrait repliquer l info gang sur le character.
	//------------------------------------------------------------------------------------------------
	override bool CanBeShownScript(IEntity user)
	{
		// Affiche l action a tous ; le serveur valide l appartenance a un gang.
		// (Le filtrage cote client necessiterait de repliquer le gang sur le character,
		//  ce qu on evite pour rester simple - le serveur fait l autorite.)
		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	override bool CanBePerformedScript(IEntity user)
	{
		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
	{
		// PerformAction s execute cote client sur serveur dedie.
		// On recupere le RplId de la zone pour le passer au serveur via RPC.
		if (!pOwnerEntity)
			return;
		
		// SECURITE : ne lancer la RPC QUE si c est bien le joueur LOCAL qui interagit.
		// Sur serveur dedie, PerformAction est evaluee sur tous les clients qui voient
		// l action - sans ce filtre, TOUS les clients lancaient la capture (= hint a tout le monde).
		PlayerController localPc = GetGame().GetPlayerController();
		IEntity localChar = null;
		if (localPc) localChar = localPc.GetControlledEntity();
		if (pUserEntity != localChar)
			return;
		
		RplComponent rpl = RplComponent.Cast(pOwnerEntity.FindComponent(RplComponent));
		if (!rpl)
		{
			Print("[JobCaptureZoneAction] Pas de RplComponent sur la zone - capture impossible",
				LogLevel.WARNING);
			return;
		}
		
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc)
			return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc)
			return;
		
		jpc.ClientAskCaptureZone(rpl.Id());
	}
	
	//------------------------------------------------------------------------------------------------
	override bool GetActionNameScript(out string outName)
	{
		outName = "Taxer la zone par le gang";
		return true;
	}
}
