//------------------------------------------------------------------------------------------------
// JobDrugSystem.c
// Centralise toute la logique drogue:
//  - Enum des types de drogue
//  - GUIDs des items + prix de vente
//  - ServerSellDrug: vente au PNJ dealer
//  - ServerHarvestDrug: recolte sur une plante
//  - Gestion du compteur + cooldown 1h par type
//------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------------------
enum EDrugType
{
	NONE = 0,
	WEED = 1,
	COCAINE = 2
}

//------------------------------------------------------------------------------------------------
// Data d'un joueur pour le systeme drogue (harvest counter + cooldown)
//------------------------------------------------------------------------------------------------
class JobDrugPlayerData
{
	int m_WeedHarvested = 0;           // Nombre total recolte dans le cycle en cours
	int m_WeedCooldownUntil = 0;       // Unix time - 0 = pas de cooldown
	int m_CocaineHarvested = 0;
	int m_CocaineCooldownUntil = 0;
}

//------------------------------------------------------------------------------------------------
class JobDrugSystem
{
	static const int MAX_HARVEST_BEFORE_COOLDOWN = 15;
	static const int COOLDOWN_DURATION_SECONDS = 3600;  // 1h
	static const int HARVEST_MIN_QTY = 2;
	static const int HARVEST_MAX_QTY = 5;
	
	// Cache serveur: playerId -> data drogue
	static ref map<int, ref JobDrugPlayerData> s_DataCache = new map<int, ref JobDrugPlayerData>();
	
	// Registre des plantes detruites (persistance JSON entre restarts serveur)
	// Cle = RplId.ToString(), Valeur = 1 (presence dans la map = plante detruite)
	static ref map<string, int> s_DestroyedPlants = new map<string, int>();
	static bool s_DestroyedPlantsLoaded = false;
	static const string DESTROYED_PLANTS_PATH = "$profile:LesPacifistesJobs/destroyed_plants.json";
	
	//------------------------------------------------------------------------------------------------
	// SERVEUR: charge la liste des plantes detruites depuis le JSON
	//------------------------------------------------------------------------------------------------
	static void LoadDestroyedPlants()
	{
		if (s_DestroyedPlantsLoaded)
			return;
		s_DestroyedPlantsLoaded = true;
		
		SCR_JsonLoadContext ctx = new SCR_JsonLoadContext();
		if (!ctx.LoadFromFile(DESTROYED_PLANTS_PATH))
		{
			Print("[JobDrugSystem] Aucun fichier destroyed_plants.json - liste vide", LogLevel.NORMAL);
			return;
		}
		
		string serializedList;
		ctx.ReadValue("plants", serializedList);
		
		// Format: "rplid1|rplid2|rplid3..."
		if (serializedList == "")
			return;
		
		int count = 0;
		int start = 0;
		int len = serializedList.Length();
		for (int i = 0; i <= len; i++)
		{
			if (i == len || serializedList.Get(i) == "|")
			{
				int segLen = i - start;
				if (segLen > 0)
				{
					string rplIdStr = serializedList.Substring(start, segLen);
					s_DestroyedPlants.Set(rplIdStr, 1);
					count++;
				}
				start = i + 1;
			}
		}
		
		Print(string.Format("[JobDrugSystem] Charge %1 plantes detruites depuis JSON", count),
			LogLevel.NORMAL);
	}
	
	//------------------------------------------------------------------------------------------------
	// SERVEUR: sauvegarde la liste des plantes detruites
	//------------------------------------------------------------------------------------------------
	static void SaveDestroyedPlants()
	{
		SCR_JsonSaveContext ctx = new SCR_JsonSaveContext();
		
		// Serialise toutes les cles en une seule string separee par |
		string serialized = "";
		foreach (string rplIdStr, int v : s_DestroyedPlants)
		{
			if (serialized != "")
				serialized = serialized + "|";
			serialized = serialized + rplIdStr;
		}
		
		ctx.WriteValue("plants", serialized);
		ctx.SaveToFile(DESTROYED_PLANTS_PATH);
	}
	
	//------------------------------------------------------------------------------------------------
	// Retourne true si cette plante est deja detruite
	//------------------------------------------------------------------------------------------------
	static bool IsPlantDestroyed(RplId id)
	{
		LoadDestroyedPlants();
		string idStr = id.ToString();
		int val;
		return s_DestroyedPlants.Find(idStr, val);
	}
	
	//------------------------------------------------------------------------------------------------
	// Marque cette plante comme detruite et persiste
	//------------------------------------------------------------------------------------------------
	static void MarkPlantDestroyed(RplId id)
	{
		LoadDestroyedPlants();
		string idStr = id.ToString();
		s_DestroyedPlants.Set(idStr, 1);
		SaveDestroyedPlants();
	}
	
	//------------------------------------------------------------------------------------------------
	// Retourne le prefab d'un item de drogue
	//------------------------------------------------------------------------------------------------
	static ResourceName GetDrugPrefab(EDrugType type)
	{
		switch (type)
		{
			case EDrugType.WEED:
				return "{29CAED9E186127A1}Prefabs/Items/InventoryItems/Contraband/WeedBag.et";
			case EDrugType.COCAINE:
				return "{FB1CC21B8E56BCEC}Prefabs/Items/InventoryItems/Contraband/CocaineBag.et";
		}
		return "";
	}
	
	//------------------------------------------------------------------------------------------------
	// Retourne le prix de rachat au PNJ dealer
	//------------------------------------------------------------------------------------------------
	static int GetDrugPrice(EDrugType type)
	{
		switch (type)
		{
			case EDrugType.WEED:    return 17;
			case EDrugType.COCAINE: return 26;
		}
		return 0;
	}
	
	//------------------------------------------------------------------------------------------------
	// Retourne le nom affichable
	//------------------------------------------------------------------------------------------------
	static string GetDrugLabel(EDrugType type)
	{
		switch (type)
		{
			case EDrugType.WEED:    return "Weed";
			case EDrugType.COCAINE: return "Cocaine";
		}
		return "Inconnu";
	}
	
	//------------------------------------------------------------------------------------------------
	// Recupere ou cree les donnees drogue d'un joueur
	//------------------------------------------------------------------------------------------------
	static JobDrugPlayerData GetData(int playerId)
	{
		JobDrugPlayerData data;
		if (s_DataCache.Find(playerId, data))
			return data;
		data = new JobDrugPlayerData();
		s_DataCache.Set(playerId, data);
		return data;
	}
	
	//------------------------------------------------------------------------------------------------
	// SERVEUR: gere la recolte d'un item de drogue sur une plante
	// La plante est supprimee apres recolte (un seul usage par plante)
	//------------------------------------------------------------------------------------------------
	static void ServerHarvestDrug(int playerId, IEntity player, EDrugType drugType, IEntity plantEntity)
	{
		if (drugType == EDrugType.NONE)
			return;
		
		JobDrugPlayerData data = GetData(playerId);
		int now = System.GetUnixTime();
		
		// Check cooldown
		int cooldownUntil = GetCooldownUntil(data, drugType);
		if (cooldownUntil > now)
		{
			int remainingMin = (cooldownUntil - now) / 60;
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				string.Format("[RECOLTE] Cooldown actif: %1 min restantes avant de pouvoir recolter %2",
					remainingMin, GetDrugLabel(drugType)));
			return;
		}
		
		// Tirage aleatoire entre MIN et MAX
		int quantity = Math.RandomInt(HARVEST_MIN_QTY, HARVEST_MAX_QTY + 1);
		
		// Spawn et donne les items
		ResourceName prefab = GetDrugPrefab(drugType);
		if (prefab == "")
			return;
		
		JobEquipmentGiver.SpawnAndGiveItemQuantity(player, prefab, quantity);
		
		// Incrementer le compteur
		int newHarvested = GetHarvested(data, drugType) + quantity;
		SetHarvested(data, drugType, newHarvested);
		
		string drugLabel = GetDrugLabel(drugType);
		
		// Check si cooldown doit s'enclencher
		if (newHarvested >= MAX_HARVEST_BEFORE_COOLDOWN)
		{
			SetCooldownUntil(data, drugType, now + COOLDOWN_DURATION_SECONDS);
			SetHarvested(data, drugType, 0);  // Reset pour le prochain cycle
			
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				string.Format("[RECOLTE] +%1 %2 recoltes. Limite atteinte: cooldown 1h sur %2.",
					quantity, drugLabel));
		}
		else
		{
			int remaining = MAX_HARVEST_BEFORE_COOLDOWN - newHarvested;
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				string.Format("[RECOLTE] +%1 %2 recoltes. Reste %3 avant cooldown.",
					quantity, drugLabel, remaining));
		}
		
		Print(string.Format("[JobDrugSystem] Harvest: player=%1 drug=%2 quantity=%3 total=%4",
			playerId, drugLabel, quantity, newHarvested), LogLevel.NORMAL);
		
		// Supprimer la plante (usage unique par plante) + persister dans JSON
		if (plantEntity)
		{
			// Marque la plante comme detruite AVANT la suppression (pour ne pas perdre le RplId)
			RplComponent plantRpl = RplComponent.Cast(plantEntity.FindComponent(RplComponent));
			if (plantRpl)
			{
				MarkPlantDestroyed(plantRpl.Id());
			}
			
			GetGame().GetCallqueue().CallLater(DestroyPlantEntity, 500, false, plantEntity);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Helper: suppression differee de la plante pour eviter les race conditions
	//------------------------------------------------------------------------------------------------
	static void DestroyPlantEntity(IEntity plantEntity)
	{
		if (plantEntity)
			SCR_EntityHelper.DeleteEntityAndChildren(plantEntity);
	}
	
	//------------------------------------------------------------------------------------------------
	// SERVEUR: gere la vente d'une drogue au PNJ dealer
	//------------------------------------------------------------------------------------------------
	static void ServerSellDrug(int playerId, IEntity player, EDrugType drugType)
	{
		if (drugType == EDrugType.NONE)
			return;
		
		ResourceName prefab = GetDrugPrefab(drugType);
		int pricePerUnit = GetDrugPrice(drugType);
		string drugLabel = GetDrugLabel(drugType);
		
		// Cherche tous les items du prefab demande dans l'inventaire
		SCR_InventoryStorageManagerComponent inv = SCR_InventoryStorageManagerComponent.Cast(
			player.FindComponent(SCR_InventoryStorageManagerComponent));
		if (!inv)
			return;
		
		// Recupere tous les items de l'inventaire
		array<IEntity> allItems = new array<IEntity>();
		inv.GetItems(allItems);
		
		int soldCount = 0;
		foreach (IEntity item : allItems)
		{
			if (!item)
				continue;
			
			ResourceName itemPrefab = item.GetPrefabData().GetPrefab().GetResourceName();
			if (itemPrefab != prefab)
				continue;
			
			// Match: on retire l'item de l'inventaire + delete
			inv.TryRemoveItemFromInventory(item);
			SCR_EntityHelper.DeleteEntityAndChildren(item);
			soldCount++;
		}
		
		if (soldCount == 0)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				string.Format("[DEALER] Vous n'avez aucun %1 a vendre.", drugLabel));
			return;
		}
		
		// Applique le cours dynamique (JobMarketManager) au prix unitaire
		// WEED -> CANNABIS, COCAINE -> COCAINE
		EMarketItem marketItem = EMarketItem.NONE;
		if (drugType == EDrugType.WEED)
			marketItem = EMarketItem.CANNABIS;
		else if (drugType == EDrugType.COCAINE)
			marketItem = EMarketItem.COCAINE;
		
		if (marketItem != EMarketItem.NONE)
		{
			pricePerUnit = JobMarketManager.GetInstance().GetEffectivePrice(marketItem, pricePerUnit);
		}
		
		int totalPrice = soldCount * pricePerUnit;
		
		// Enregistre la vente -> -1% sur le cours (une fois par appel, peu importe la quantite)
		if (marketItem != EMarketItem.NONE)
			JobMarketManager.GetInstance().RecordSale(marketItem);
		
		// === TAXE GANG : si un gang controle la zone de cette drogue, il touche 5% ===
		if (marketItem != EMarketItem.NONE)
		{
			int gangTax = JobGangManager.GetInstance().ApplyTaxOnSale(marketItem, totalPrice);
			if (gangTax > 0)
			{
				string ctrlGang = JobGangManager.GetInstance().GetZoneController(marketItem);
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					string.Format("[GANG] %1 capsules de taxe (5%%) versees au gang %2 qui controle cette zone.",
						gangTax, ctrlGang));
			}
		}
		
		// Paiement via CapsuleEconomy
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		CapsuleEconomyManager eco = CapsuleEconomyManager.GetInstance();
		if (!eco)
			return;
		
		eco.AddCapsules(uid, totalPrice);
		int newTotal = eco.GetCapsules(uid);
		
		// Sync HUD capsules
		PlayerController pc = GetGame().GetPlayerManager().GetPlayerController(playerId);
		if (pc)
		{
			CapsulePlayerComponent capsComp = CapsulePlayerComponent.Cast(
				pc.FindComponent(CapsulePlayerComponent));
			if (capsComp)
				capsComp.Svr_SendCapsules(newTotal);
		}
		
		JobManager.GetInstance().NotifyPlayerChat(playerId,
			string.Format("[DEALER] %1 %2 vendus pour %3 capsules. Solde: %4",
				soldCount, drugLabel, totalPrice, newTotal));
		
		Print(string.Format("[JobDrugSystem] Sell: player=%1 drug=%2 count=%3 total=%4",
			playerId, drugLabel, soldCount, totalPrice), LogLevel.NORMAL);
	}
	
	//------------------------------------------------------------------------------------------------
	// Nettoyage cache quand un joueur se deconnecte
	//------------------------------------------------------------------------------------------------
	static void OnPlayerDisconnected(int playerId)
	{
		s_DataCache.Remove(playerId);
	}
	
	//------------------------------------------------------------------------------------------------
	// Helpers pour acceder aux champs selon le type de drogue
	//------------------------------------------------------------------------------------------------
	static int GetHarvested(JobDrugPlayerData data, EDrugType type)
	{
		if (type == EDrugType.WEED)
			return data.m_WeedHarvested;
		if (type == EDrugType.COCAINE)
			return data.m_CocaineHarvested;
		return 0;
	}
	
	static void SetHarvested(JobDrugPlayerData data, EDrugType type, int value)
	{
		if (type == EDrugType.WEED)
			data.m_WeedHarvested = value;
		else if (type == EDrugType.COCAINE)
			data.m_CocaineHarvested = value;
	}
	
	static int GetCooldownUntil(JobDrugPlayerData data, EDrugType type)
	{
		if (type == EDrugType.WEED)
			return data.m_WeedCooldownUntil;
		if (type == EDrugType.COCAINE)
			return data.m_CocaineCooldownUntil;
		return 0;
	}
	
	static void SetCooldownUntil(JobDrugPlayerData data, EDrugType type, int value)
	{
		if (type == EDrugType.WEED)
			data.m_WeedCooldownUntil = value;
		else if (type == EDrugType.COCAINE)
			data.m_CocaineCooldownUntil = value;
	}
}
