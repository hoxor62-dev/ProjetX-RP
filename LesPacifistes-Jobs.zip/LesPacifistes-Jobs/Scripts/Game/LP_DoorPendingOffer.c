//------------------------------------------------------------------------------------------------
// LP_DoorPendingOffer.c
// Registre serveur des offres de vente d acces de porte en cours.
// La cle utilise doorRplId.ToString() car les RplId ne peuvent pas etre cle de map<K,V>.
//------------------------------------------------------------------------------------------------

class LP_DoorPendingOffer
{
	string m_DoorRplIdStr;      // rplId.ToString() de la porte
	string m_SellerUID;
	int m_SellerId;
	string m_SellerName;
	string m_BuyerUID;
	int m_BuyerId;
	int m_Price;
	bool m_IsResell;
	int m_CreatedUnix;
	
	void LP_DoorPendingOffer()
	{
		m_CreatedUnix = System.GetUnixTime();
	}
	
	//------------------------------------------------------------------------------------------------
	// Retrouve l entite porte a partir du string RplId stocke.
	// (utilise a l acceptation d achat pour un achat initial : besoin de l entite
	// pour extraire prefab + position et creer la LP_DoorData avec cle stable)
	//------------------------------------------------------------------------------------------------
	IEntity GetDoorEntity()
	{
		RplId rid = GetDoorRplId();
		if (!rid.IsValid()) return null;
		RplComponent rpl = RplComponent.Cast(Replication.FindItem(rid));
		if (!rpl) return null;
		return rpl.GetEntity();
	}
	
	//------------------------------------------------------------------------------------------------
	// Reconstruit le RplId a partir du string stocke, via une lookup sur les entites repliquees.
	// Iteration ineluctable car il n existe pas de RplId.FromString en Enforce.
	// -> Alternative : stocker directement le RplId dans l offre. C est mieux.
	//------------------------------------------------------------------------------------------------
	RplId GetDoorRplId()
	{
		// Utilise le RplId cache (defini lors de la creation de l offre)
		return m_CachedRplId;
	}
	
	RplId m_CachedRplId = RplId.Invalid();
	
	void SetDoor(RplId rplId)
	{
		m_CachedRplId = rplId;
		m_DoorRplIdStr = rplId.ToString();
	}
	
	//------------------------------------------------------------------------------------------------
	// STATIC : registre des offres actives
	//------------------------------------------------------------------------------------------------
	static ref array<ref LP_DoorPendingOffer> s_Offers = new array<ref LP_DoorPendingOffer>();
	
	//------------------------------------------------------------------------------------------------
	static void RegisterOffer(LP_DoorPendingOffer offer)
	{
		if (!offer) return;
		LP_DoorPendingOffer existing = GetOffer(offer.m_DoorRplIdStr, offer.m_BuyerUID);
		if (existing) RemoveOffer(existing);
		s_Offers.Insert(offer);
	}
	
	static LP_DoorPendingOffer GetOffer(string doorRplIdStr, string buyerUID)
	{
		foreach (LP_DoorPendingOffer o : s_Offers)
		{
			if (o && o.m_DoorRplIdStr == doorRplIdStr && o.m_BuyerUID == buyerUID)
				return o;
		}
		return null;
	}
	
	static void RemoveOffer(LP_DoorPendingOffer offer)
	{
		if (!offer) return;
		int idx = s_Offers.Find(offer);
		if (idx >= 0) s_Offers.Remove(idx);
	}
	
	//------------------------------------------------------------------------------------------------
	// Helper : retrouve une LP_DoorData en n ayant que le rplId.ToString().
	// Utilise le meme mecanisme que GetDoorEntity : convertit string -> RplId via
	// la cache locale n est pas possible (pas de m_CachedRplId statique).
	// Utilise ONLY quand on connait la porte est repliquee sur le serveur.
	//------------------------------------------------------------------------------------------------
	static LP_DoorData GetDoorByRplIdStr(string doorRplIdStr)
	{
		if (doorRplIdStr == "") return null;
		// Cherche dans le cache runtime du manager directement
		return LP_DoorManager.GetInstance().GetDoorByRplIdStr(doorRplIdStr);
	}
}
