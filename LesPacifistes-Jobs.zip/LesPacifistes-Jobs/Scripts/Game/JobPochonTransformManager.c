//------------------------------------------------------------------------------------------------
// JobPochonTransformManager.c
// Singleton serveur qui gere les transformations de sac a pochon en 30 pochons.
// - Le joueur doit rester dans un rayon de 10m de la table pendant 5 minutes.
// - 1 pochon est spawne dans son inventaire toutes les 10 secondes.
// - Le sac est consomme au demarrage (pas de refund si le joueur s eloigne).
//------------------------------------------------------------------------------------------------

class JobPochonTransformSession
{
	int m_PlayerId;
	string m_UID;
	IEntity m_Table;             // entite table de reference (distance check)
	vector m_TableOrigin;
	int m_PochonsProduits = 0;   // combien deja donnes
	int m_TotalPochons;          // 30
	int m_NextPochonUnix;        // timestamp du prochain pochon
	int m_EndUnix;               // timestamp de fin (5 min apres le start)
	
	void JobPochonTransformSession()
	{
		m_PlayerId = 0;
		m_UID = "";
		m_Table = null;
		m_TableOrigin = "0 0 0";
		m_PochonsProduits = 0;
		m_TotalPochons = 0;
		m_NextPochonUnix = 0;
		m_EndUnix = 0;
	}
}

class JobPochonTransformManager
{
	static ref JobPochonTransformManager s_Instance;
	
	ref array<ref JobPochonTransformSession> m_Sessions = new array<ref JobPochonTransformSession>();
	
	const int TICK_INTERVAL_MS = 1000;
	
	//------------------------------------------------------------------------------------------------
	static JobPochonTransformManager GetInstance()
	{
		if (!s_Instance)
		{
			s_Instance = new JobPochonTransformManager();
			s_Instance.Init();
		}
		return s_Instance;
	}
	
	//------------------------------------------------------------------------------------------------
	void Init()
	{
		if (!Replication.IsServer())
			return;
		GetGame().GetCallqueue().CallLater(Tick, TICK_INTERVAL_MS, true);
	}
	
	//------------------------------------------------------------------------------------------------
	// Retourne la session active pour un joueur, ou null
	//------------------------------------------------------------------------------------------------
	JobPochonTransformSession GetSessionForPlayer(int playerId)
	{
		foreach (JobPochonTransformSession s : m_Sessions)
		{
			if (s && s.m_PlayerId == playerId)
				return s;
		}
		return null;
	}
	
	//------------------------------------------------------------------------------------------------
	// Retourne true si le joueur a deja une transformation en cours
	//------------------------------------------------------------------------------------------------
	bool HasActiveSession(int playerId)
	{
		return GetSessionForPlayer(playerId) != null;
	}
	
	//------------------------------------------------------------------------------------------------
	// Demarre une nouvelle transformation.
	// Retourne : 0 = OK, 1 = deja en cours, 2 = pas de sac dans inventaire, 3 = pas metier voyou/gang, 4 = table introuvable
	//------------------------------------------------------------------------------------------------
	int StartTransformation(int playerId, IEntity table)
	{
		if (playerId <= 0)
			return 3;
		if (!table)
			return 4;
		if (HasActiveSession(playerId))
			return 1;
		
		// Check metier voyou OU membre de gang
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "")
			return 3;
		JobPlayerData data = JobManager.GetInstance().GetPlayerData(playerId);
		if (!data)
			return 3;
		bool isVoyou = (data.m_Job == EJobType.VOYOU);
		bool isInGang = (JobGangManager.GetInstance().GetGangOfPlayer(uid) != null);
		if (!isVoyou && !isInGang)
			return 3;
		
		// Trouve le PlayerController + character pour lire l inventaire
		PlayerController pc = GetGame().GetPlayerManager().GetPlayerController(playerId);
		if (!pc) return 4;
		IEntity character = pc.GetControlledEntity();
		if (!character) return 4;
		
		// Verifie que le joueur a AU MOINS 1 sac a pochon dans l inventaire
		IEntity sacEntity = FindSacInInventory(character);
		if (!sacEntity)
			return 2;
		
		// Consomme le sac (suppression IMMEDIATE - pas de refund)
		SCR_EntityHelper.DeleteEntityAndChildren(sacEntity);
		
		// Cree la session
		JobPochonTransformSession session = new JobPochonTransformSession();
		session.m_PlayerId = playerId;
		session.m_UID = uid;
		session.m_Table = table;
		session.m_TableOrigin = table.GetOrigin();
		session.m_PochonsProduits = 0;
		session.m_TotalPochons = JobPochonData.POCHONS_PAR_SAC;
		int nowUnix = System.GetUnixTime();
		session.m_NextPochonUnix = nowUnix + JobPochonData.INTERVALLE_POCHON_S;
		session.m_EndUnix = nowUnix + JobPochonData.DUREE_TRANSFORMATION_S;
		m_Sessions.Insert(session);
		
		// Demarre le HUD chez le client
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (jpc)
			jpc.ServerStartPochonHud(session.m_TotalPochons, session.m_TableOrigin);
		
		JobManager.GetInstance().NotifyPlayerChat(playerId,
			"[Marchandise] Transformation demarree - reste dans les 10m de la table pendant 5 min.");
		
		return 0;
	}
	
	//------------------------------------------------------------------------------------------------
	// Cherche un sac a pochon dans l inventaire du personnage
	//------------------------------------------------------------------------------------------------
	IEntity FindSacInInventory(IEntity character)
	{
		if (!character) return null;
		SCR_InventoryStorageManagerComponent inv = SCR_InventoryStorageManagerComponent.Cast(
			character.FindComponent(SCR_InventoryStorageManagerComponent));
		if (!inv) return null;
		
		array<IEntity> items = new array<IEntity>();
		inv.GetItems(items);
		
		foreach (IEntity item : items)
		{
			if (!item) continue;
			string prefabName = item.GetPrefabData().GetPrefabName();
			if (StringContains(prefabName, JobPochonData.GUID_SAC_POCHON))
				return item;
		}
		return null;
	}
	
	//------------------------------------------------------------------------------------------------
	// Helper : Enforce Script n a pas de string.Contains
	//------------------------------------------------------------------------------------------------
	bool StringContains(string haystack, string needle)
	{
		int hlen = haystack.Length();
		int nlen = needle.Length();
		if (nlen == 0) return true;
		if (nlen > hlen) return false;
		int lastStart = hlen - nlen;
		for (int i = 0; i <= lastStart; i++)
		{
			if (haystack.Substring(i, nlen) == needle)
				return true;
		}
		return false;
	}
	
	//------------------------------------------------------------------------------------------------
	// Tick serveur : pour chaque session, verifie distance et avance la production
	//------------------------------------------------------------------------------------------------
	void Tick()
	{
		if (!Replication.IsServer())
			return;
		if (m_Sessions.IsEmpty())
			return;
		
		int nowUnix = System.GetUnixTime();
		array<int> toRemove = new array<int>();
		
		for (int i = 0; i < m_Sessions.Count(); i++)
		{
			JobPochonTransformSession s = m_Sessions.Get(i);
			if (!s)
			{
				toRemove.Insert(i);
				continue;
			}
			
			// Recupere le joueur
			PlayerController pc = GetGame().GetPlayerManager().GetPlayerController(s.m_PlayerId);
			if (!pc)
			{
				// Joueur deconnecte -> stop
				toRemove.Insert(i);
				continue;
			}
			IEntity character = pc.GetControlledEntity();
			if (!character)
			{
				toRemove.Insert(i);
				continue;
			}
			
			// Check distance a la table
			vector charPos = character.GetOrigin();
			float dist = vector.Distance(charPos, s.m_TableOrigin);
			if (dist > JobPochonData.MAX_DISTANCE_FROM_TABLE)
			{
				JobManager.GetInstance().NotifyPlayerChat(s.m_PlayerId,
					string.Format("[Marchandise] Trop loin de la table (%1m)! Transformation annulee.", dist.ToString()));
				JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
				if (jpc) jpc.ServerEndPochonHud();
				toRemove.Insert(i);
				continue;
			}
			
			// Check vie du personnage
			// - IsDestroyed sur SCR_CharacterDamageManagerComponent (mort)
			// - IsUnconscious sur CharacterControllerComponent (KO)
			bool isOutOfCombat = false;
			SCR_CharacterDamageManagerComponent dmg = SCR_CharacterDamageManagerComponent.Cast(
				character.FindComponent(SCR_CharacterDamageManagerComponent));
			if (dmg && dmg.IsDestroyed())
				isOutOfCombat = true;
			if (!isOutOfCombat)
			{
				CharacterControllerComponent cc = CharacterControllerComponent.Cast(
					character.FindComponent(CharacterControllerComponent));
				if (cc && cc.IsUnconscious())
					isOutOfCombat = true;
			}
			if (isOutOfCombat)
			{
				JobManager.GetInstance().NotifyPlayerChat(s.m_PlayerId,
					"[Marchandise] Vous etes hors combat. Transformation annulee.");
				JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
				if (jpc) jpc.ServerEndPochonHud();
				toRemove.Insert(i);
				continue;
			}
			
			// Check timeout / production de pochon
			if (nowUnix >= s.m_NextPochonUnix)
			{
				// Spawn 1 pochon dans l inventaire
				bool ok = SpawnPochonInInventory(character);
				if (ok)
				{
					s.m_PochonsProduits = s.m_PochonsProduits + 1;
					s.m_NextPochonUnix = nowUnix + JobPochonData.INTERVALLE_POCHON_S;
					
					// Sync HUD client
					JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
					if (jpc)
						jpc.ServerSyncPochonStats(s.m_PochonsProduits, s.m_TotalPochons);
					
					// Fin de production
					if (s.m_PochonsProduits >= s.m_TotalPochons)
					{
						JobManager.GetInstance().NotifyPlayerChat(s.m_PlayerId,
							string.Format("[Marchandise] Transformation terminee ! %1 pochons recus.",
								s.m_TotalPochons.ToString()));
						if (jpc) jpc.ServerEndPochonHud();
						toRemove.Insert(i);
						continue;
					}
				}
				else
				{
					// Inventaire plein
					JobManager.GetInstance().NotifyPlayerChat(s.m_PlayerId,
						"[Marchandise] Inventaire plein - le pochon n a pas pu etre cree. Reessai au prochain tick.");
					// Retry dans 3s
					s.m_NextPochonUnix = nowUnix + 3;
				}
			}
		}
		
		// Nettoyage a rebours pour ne pas casser l iteration
		for (int i = toRemove.Count() - 1; i >= 0; i--)
		{
			int idx = toRemove.Get(i);
			m_Sessions.Remove(idx);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Spawn un pochon dans l inventaire du personnage
	//------------------------------------------------------------------------------------------------
	bool SpawnPochonInInventory(IEntity character)
	{
		if (!character) return false;
		SCR_InventoryStorageManagerComponent inv = SCR_InventoryStorageManagerComponent.Cast(
			character.FindComponent(SCR_InventoryStorageManagerComponent));
		if (!inv) return false;
		
		ResourceName rn = JobPochonData.PREFAB_POCHON;
		return inv.TrySpawnPrefabToStorage(rn);
	}
	
	//------------------------------------------------------------------------------------------------
	// Arrete manuellement la session d un joueur (utilise si le joueur se deconnecte, etc.)
	//------------------------------------------------------------------------------------------------
	void StopSessionForPlayer(int playerId)
	{
		for (int i = m_Sessions.Count() - 1; i >= 0; i--)
		{
			JobPochonTransformSession s = m_Sessions.Get(i);
			if (s && s.m_PlayerId == playerId)
			{
				PlayerController pc = GetGame().GetPlayerManager().GetPlayerController(playerId);
				if (pc)
				{
					JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
					if (jpc) jpc.ServerEndPochonHud();
				}
				m_Sessions.Remove(i);
			}
		}
	}
}