//------------------------------------------------------------------------------------------------
// JobBonPointEditAdMenu.c
// Modification d une annonce existante (prix + description).
//------------------------------------------------------------------------------------------------

class JobBonPointEditAdMenu : ChimeraMenuBase
{
	Widget m_RootWidget;
	TextWidget m_TitleText;
	EditBoxWidget m_PriceInput;
	EditBoxWidget m_DescInput;
	ButtonWidget m_BtnConfirm;
	ButtonWidget m_BtnBack;
	
	static int s_AdId;
	static int s_CurrentPrice;
	
	static JobBonPointEditAdMenu s_Instance;
	
	//------------------------------------------------------------------------------------------------
	static void SetPendingData(int adId, int currentPrice)
	{
		s_AdId = adId;
		s_CurrentPrice = currentPrice;
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuOpen()
	{
		super.OnMenuOpen();
		s_Instance = this;
		JobFocusHandler.ClearRegistry();
		
		m_RootWidget = GetRootWidget();
		if (!m_RootWidget) return;
		
		m_TitleText = TextWidget.Cast(m_RootWidget.FindAnyWidget("TitleText"));
		m_PriceInput = EditBoxWidget.Cast(m_RootWidget.FindAnyWidget("PriceInput"));
		m_DescInput = EditBoxWidget.Cast(m_RootWidget.FindAnyWidget("DescInput"));
		m_BtnConfirm = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnConfirm"));
		m_BtnBack = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnBack"));
		
		if (m_TitleText)
			m_TitleText.SetText(string.Format("Modifier annonce #%1", s_AdId.ToString()));
		if (m_PriceInput)
			m_PriceInput.SetText(s_CurrentPrice.ToString());
		if (m_DescInput)
			m_DescInput.SetText("");
		
		if (m_BtnConfirm)
		{
			BonPointEditHandler h = new BonPointEditHandler();
			h.m_Menu = this;
			h.m_Action = "confirm";
			m_BtnConfirm.AddHandler(h);
			JobFocusHandler.Attach(m_BtnConfirm);
		}
		if (m_BtnBack)
		{
			BonPointEditHandler h = new BonPointEditHandler();
			h.m_Menu = this;
			h.m_Action = "back";
			m_BtnBack.AddHandler(h);
			JobFocusHandler.Attach(m_BtnBack);
			GetGame().GetWorkspace().SetFocusedWidget(m_BtnBack);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuClose()
	{
		if (s_Instance == this) s_Instance = null;
		super.OnMenuClose();
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuUpdate(float tDelta)
	{
		super.OnMenuUpdate(tDelta);
		if (GetGame().GetInputManager().GetActionValue("MenuBack") > 0.5)
			CloseMenuInternal();
	}
	
	//------------------------------------------------------------------------------------------------
	void OnAction(string action)
	{
		if (action == "back")
		{
			CloseMenuInternal();
			return;
		}
		if (action == "confirm")
		{
			if (!m_PriceInput || !m_DescInput) return;
			int newPrice = m_PriceInput.GetText().ToInt();
			if (newPrice <= 0) return;
			string newDesc = m_DescInput.GetText();
			
			PlayerController pc = GetGame().GetPlayerController();
			if (!pc) return;
			JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
			if (!jpc) return;
			jpc.ClientAskUpdateBonPointAd(s_AdId, newPrice, newDesc);
			CloseMenuInternal();
			return;
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void CloseMenuInternal()
	{
		GetGame().GetMenuManager().CloseMenu(this);
	}
}

//------------------------------------------------------------------------------------------------
class BonPointEditHandler : ScriptedWidgetEventHandler
{
	JobBonPointEditAdMenu m_Menu;
	string m_Action;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.OnAction(m_Action);
		return true;
	}
}
