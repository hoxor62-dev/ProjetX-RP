//------------------------------------------------------------------------------------------------
// JobCompanyCreateOrderMenu.c
// Menu de creation d un bon de commande (employe ou patron).
//
// Flow :
//   1. Serveur envoie la liste des items de l inventaire du joueur via SetPendingItems
//   2. Joueur voit liste paginee (10/page)
//   3. Joueur clique sur les items pour les selectionner (toggle, icon visuel)
//   4. Joueur tape un prix global propose dans l editbox
//   5. Clic "Creer le bon" -> RPC serveur
//   6. Serveur verifie items en inventaire -> retire -> stocke dans le bon -> notif chat
//
// Pagination : pattern ATM 10 items/page + Prev/Next + label "Page X / Y".
//------------------------------------------------------------------------------------------------

class JobCompanyCreateOrderMenu : ChimeraMenuBase
{
	const string ENTRY_LAYOUT_PATH = "{9D68BEB73DF970D8}UI/layouts/JobSmsEntry.layout";
	const int ITEMS_PER_PAGE = 10;
	const int PAGE_CHANGE_COOLDOWN_MS = 300;
	
	Widget m_RootWidget;
	Widget m_ItemsContainer;
	TextWidget m_TitleText;
	TextWidget m_EmptyText;
	TextWidget m_SelectionInfoText;
	TextWidget m_PageLabel;
	EditBoxWidget m_PriceInput;
	ButtonWidget m_BtnPrevPage;
	ButtonWidget m_BtnNextPage;
	ButtonWidget m_BtnCreate;
	ButtonWidget m_BtnCancel;
	
	// Donnees pre-chargees (envoyees par le serveur)
	// Format : 2 arrays paralleles : prefab + nom humain
	static ref array<string> s_PendingPrefabs = new array<string>();
	static ref array<string> s_PendingNames = new array<string>();
	
	// Etat
	int m_CurrentPage = 0;
	int m_LastPageChangeTime = 0;
	// Indices selectionnes dans s_PendingPrefabs (toggle on/off)
	ref array<int> m_SelectedIndices = new array<int>();
	// Map index -> button widget (pour update couleur)
	ref map<int, ButtonWidget> m_IndexToButton = new map<int, ButtonWidget>();
	
	static JobCompanyCreateOrderMenu s_Instance;
	
	const float SEL_R = 0.18; const float SEL_G = 0.45; const float SEL_B = 0.20;  // vert (selectionne)
	const float UNSEL_R = 0.20; const float UNSEL_G = 0.22; const float UNSEL_B = 0.28;  // gris (non)
	
	//------------------------------------------------------------------------------------------------
	static void SetPendingItems(array<string> prefabs, array<string> names)
	{
		s_PendingPrefabs.Clear();
		s_PendingNames.Clear();
		foreach (string p : prefabs)
			s_PendingPrefabs.Insert(p);
		foreach (string n : names)
			s_PendingNames.Insert(n);
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuOpen()
	{
		super.OnMenuOpen();
		s_Instance = this;
		JobFocusHandler.ClearRegistry();
		
		m_RootWidget = GetRootWidget();
		if (!m_RootWidget)
			return;
		
		m_ItemsContainer = m_RootWidget.FindAnyWidget("ItemsContainer");
		m_TitleText = TextWidget.Cast(m_RootWidget.FindAnyWidget("TitleText"));
		m_EmptyText = TextWidget.Cast(m_RootWidget.FindAnyWidget("EmptyText"));
		m_SelectionInfoText = TextWidget.Cast(m_RootWidget.FindAnyWidget("SelectionInfoText"));
		m_PageLabel = TextWidget.Cast(m_RootWidget.FindAnyWidget("PageLabel"));
		m_PriceInput = EditBoxWidget.Cast(m_RootWidget.FindAnyWidget("PriceInput"));
		m_BtnPrevPage = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnPrevPage"));
		m_BtnNextPage = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnNextPage"));
		m_BtnCreate = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnCreate"));
		m_BtnCancel = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnCancel"));
		
		if (m_TitleText)
			m_TitleText.SetText("Creer un bon de commande");
		
		// Bind handlers
		BindBtn(m_BtnPrevPage, "prev");
		BindBtn(m_BtnNextPage, "next");
		BindBtn(m_BtnCreate, "create");
		BindBtn(m_BtnCancel, "cancel");
		
		if (m_BtnCancel)
			GetGame().GetWorkspace().SetFocusedWidget(m_BtnCancel);
		
		m_CurrentPage = 0;
		m_SelectedIndices.Clear();
		BuildList();
	}
	
	void BindBtn(ButtonWidget btn, string action)
	{
		if (!btn) return;
		CreateOrderActionHandler h = new CreateOrderActionHandler();
		h.m_Menu = this;
		h.m_Action = action;
		btn.AddHandler(h);
		JobFocusHandler.Attach(btn);
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuClose()
	{
		if (s_Instance == this)
			s_Instance = null;
		super.OnMenuClose();
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuUpdate(float tDelta)
	{
		super.OnMenuUpdate(tDelta);
		if (GetGame().GetInputManager().GetActionValue("MenuBack") > 0.5)
			CloseMenuInternal();
		if (GetGame().GetInputManager().GetActionValue("MenuTabLeft") > 0.5)
			OnAction("prev");
		if (GetGame().GetInputManager().GetActionValue("MenuTabRight") > 0.5)
			OnAction("next");
	}
	
	//------------------------------------------------------------------------------------------------
	int GetTotalPages()
	{
		int total = (s_PendingPrefabs.Count() + ITEMS_PER_PAGE - 1) / ITEMS_PER_PAGE;
		if (total < 1) total = 1;
		return total;
	}
	
	//------------------------------------------------------------------------------------------------
	void BuildList()
	{
		if (!m_ItemsContainer)
			return;
		
		// Reset focus + container
		m_IndexToButton.Clear();
		Widget child = m_ItemsContainer.GetChildren();
		while (child)
		{
			Widget next = child.GetSibling();
			child.RemoveFromHierarchy();
			child = next;
		}
		
		int totalPages = GetTotalPages();
		if (m_CurrentPage < 0) m_CurrentPage = 0;
		if (m_CurrentPage >= totalPages) m_CurrentPage = totalPages - 1;
		
		if (s_PendingPrefabs.Count() == 0)
		{
			if (m_EmptyText)
			{
				m_EmptyText.SetText("Votre inventaire est vide.");
				m_EmptyText.SetVisible(true);
			}
			UpdateUI(totalPages);
			return;
		}
		
		if (m_EmptyText)
			m_EmptyText.SetVisible(false);
		
		WorkspaceWidget ws = GetGame().GetWorkspace();
		int startIdx = m_CurrentPage * ITEMS_PER_PAGE;
		int endIdx = startIdx + ITEMS_PER_PAGE;
		if (endIdx > s_PendingPrefabs.Count())
			endIdx = s_PendingPrefabs.Count();
		
		for (int i = startIdx; i < endIdx; i++)
		{
			string name = s_PendingNames.Get(i);
			Widget entry = ws.CreateWidgets(ENTRY_LAYOUT_PATH, m_ItemsContainer);
			if (!entry) continue;
			
			TextWidget nameW = TextWidget.Cast(entry.FindAnyWidget("PlayerName"));
			if (nameW)
				nameW.SetText(name);
			
			ButtonWidget btn = ButtonWidget.Cast(entry.FindAnyWidget("SelectButton"));
			if (btn)
			{
				m_IndexToButton.Set(i, btn);
				ApplySelectionColor(btn, IsIndexSelected(i));
				CreateOrderItemHandler ih = new CreateOrderItemHandler();
				ih.m_Menu = this;
				ih.m_ItemIndex = i;
				btn.AddHandler(ih);
				JobFocusHandler.Attach(btn);
			}
		}
		
		UpdateUI(totalPages);
	}
	
	//------------------------------------------------------------------------------------------------
	void UpdateUI(int totalPages)
	{
		if (m_PageLabel)
			m_PageLabel.SetText(string.Format("Page %1 / %2", (m_CurrentPage + 1).ToString(), totalPages.ToString()));
		if (m_BtnPrevPage)
			m_BtnPrevPage.SetEnabled(m_CurrentPage > 0);
		if (m_BtnNextPage)
			m_BtnNextPage.SetEnabled(m_CurrentPage < totalPages - 1);
		if (m_SelectionInfoText)
			m_SelectionInfoText.SetText(string.Format("Items selectionnes : %1", m_SelectedIndices.Count().ToString()));
	}
	
	//------------------------------------------------------------------------------------------------
	bool IsIndexSelected(int idx)
	{
		foreach (int i : m_SelectedIndices)
		{
			if (i == idx)
				return true;
		}
		return false;
	}
	
	void ApplySelectionColor(ButtonWidget btn, bool selected)
	{
		if (!btn) return;
		if (selected)
			btn.SetColor(Color.FromRGBA(SEL_R * 255, SEL_G * 255, SEL_B * 255, 255));
		else
			btn.SetColor(Color.FromRGBA(UNSEL_R * 255, UNSEL_G * 255, UNSEL_B * 255, 255));
	}
	
	//------------------------------------------------------------------------------------------------
	void OnItemClicked(int itemIndex)
	{
		// Toggle
		bool wasSelected = IsIndexSelected(itemIndex);
		if (wasSelected)
		{
			for (int i = m_SelectedIndices.Count() - 1; i >= 0; i--)
			{
				if (m_SelectedIndices.Get(i) == itemIndex)
					m_SelectedIndices.Remove(i);
			}
		}
		else
		{
			m_SelectedIndices.Insert(itemIndex);
		}
		
		ButtonWidget btn;
		if (m_IndexToButton.Find(itemIndex, btn))
			ApplySelectionColor(btn, !wasSelected);
		
		UpdateUI(GetTotalPages());
	}
	
	//------------------------------------------------------------------------------------------------
	void OnAction(string action)
	{
		if (action == "cancel")
		{
			CloseMenuInternal();
			return;
		}
		if (action == "prev")
		{
			int now = System.GetTickCount();
			if (now - m_LastPageChangeTime < PAGE_CHANGE_COOLDOWN_MS) return;
			m_LastPageChangeTime = now;
			if (m_CurrentPage > 0) { m_CurrentPage--; BuildList(); }
			return;
		}
		if (action == "next")
		{
			int now = System.GetTickCount();
			if (now - m_LastPageChangeTime < PAGE_CHANGE_COOLDOWN_MS) return;
			m_LastPageChangeTime = now;
			if (m_CurrentPage < GetTotalPages() - 1) { m_CurrentPage++; BuildList(); }
			return;
		}
		if (action == "create")
		{
			if (m_SelectedIndices.Count() == 0)
			{
				if (m_SelectionInfoText)
					m_SelectionInfoText.SetText("Veuillez selectionner au moins 1 item.");
				return;
			}
			if (!m_PriceInput) return;
			string priceStr = m_PriceInput.GetText();
			int price = priceStr.ToInt();
			if (price <= 0)
			{
				if (m_SelectionInfoText)
					m_SelectionInfoText.SetText("Veuillez entrer un prix valide (> 0).");
				return;
			}
			
			// Construire la liste des prefabs selectionnes
			array<string> selectedPrefabs = new array<string>();
			foreach (int idx : m_SelectedIndices)
			{
				if (idx >= 0 && idx < s_PendingPrefabs.Count())
					selectedPrefabs.Insert(s_PendingPrefabs.Get(idx));
			}
			
			// Serialise en string "prefab1###prefab2###..."
			string prefabsStr = "";
			for (int k = 0; k < selectedPrefabs.Count(); k++)
			{
				if (k > 0) prefabsStr = prefabsStr + "###";
				prefabsStr = prefabsStr + selectedPrefabs.Get(k);
			}
			
			PlayerController pc = GetGame().GetPlayerController();
			if (!pc) return;
			JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
			if (!jpc) return;
			jpc.ClientAskCreateCompanyOrder(prefabsStr, price);
			
			CloseMenuInternal();
			return;
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void CloseMenuInternal()
	{
		GetGame().GetMenuManager().CloseMenu(this);
	}
	
	static JobCompanyCreateOrderMenu GetOpenMenu() { return s_Instance; }
}

//------------------------------------------------------------------------------------------------
class CreateOrderItemHandler : ScriptedWidgetEventHandler
{
	JobCompanyCreateOrderMenu m_Menu;
	int m_ItemIndex;
	// IMPORTANT : on n implemente que OnClick (pas OnMouseButtonDown) car les 2 events sont
	// generes consecutivement par Enfusion ; avoir les 2 declenche un double toggle qui
	// remet la selection a zero. Le seul OnClick suffit pour les clics souris ET manette.
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.OnItemClicked(m_ItemIndex);
		return true;
	}
}

//------------------------------------------------------------------------------------------------
class CreateOrderActionHandler : ScriptedWidgetEventHandler
{
	JobCompanyCreateOrderMenu m_Menu;
	string m_Action;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.OnAction(m_Action);
		return true;
	}
	override bool OnMouseButtonDown(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.OnAction(m_Action);
		return true;
	}
}
