//------------------------------------------------------------------------------------------------
// JobWhitelistMenu.c
// Menu affiche au joueur non-whitelist a sa connexion.
//
// NOUVEAU COMPORTEMENT (prison au lieu de kick) :
//   - Affiche un message "Vous n etes pas Whitelister, vous etes en prison..."
//   - Pendant 60 secondes
//   - Se ferme TOUT SEUL apres 60s (pas de kick !)
//   - Non fermable manuellement par le joueur avant la fin
//
// IMPORTANT : le joueur est aussi teleporte dans la prison + maintenu dans un rayon de 100m
// par le JobWhitelistHandler cote serveur. Ce menu est purement visuel.
//------------------------------------------------------------------------------------------------

class JobWhitelistMenu : ChimeraMenuBase
{
	const int COUNTDOWN_SECONDS = 15;
	const int TICK_INTERVAL_MS = 1000;

	Widget m_RootWidget;
	TextWidget m_CountdownText;

	int m_SecondsRemaining = 15;

	//------------------------------------------------------------------------------------------------
	override void OnMenuOpen()
	{
		super.OnMenuOpen();

		m_RootWidget = GetRootWidget();
		if (!m_RootWidget) return;

		m_CountdownText = TextWidget.Cast(m_RootWidget.FindAnyWidget("CountdownText"));

		// Demarre le compte a rebours
		m_SecondsRemaining = COUNTDOWN_SECONDS;
		UpdateCountdownText();
		GetGame().GetCallqueue().CallLater(TickCountdown, TICK_INTERVAL_MS, true);

		// Auto-fermeture apres 60 secondes
		GetGame().GetCallqueue().CallLater(AutoClose, COUNTDOWN_SECONDS * 1000, false);
	}

	//------------------------------------------------------------------------------------------------
	override void OnMenuClose()
	{
		GetGame().GetCallqueue().Remove(TickCountdown);
		GetGame().GetCallqueue().Remove(AutoClose);
		super.OnMenuClose();
	}

	//------------------------------------------------------------------------------------------------
	// Bloque l input MenuBack pour empecher la fermeture manuelle du menu avant les 60s
	//------------------------------------------------------------------------------------------------
	override void OnMenuUpdate(float tDelta)
	{
		super.OnMenuUpdate(tDelta);
		// Pas d action sur MenuBack : le menu reste ouvert jusqu a la fin du compte a rebours
	}

	//------------------------------------------------------------------------------------------------
	void TickCountdown()
	{
		m_SecondsRemaining = m_SecondsRemaining - 1;
		if (m_SecondsRemaining < 0)
			m_SecondsRemaining = 0;
		UpdateCountdownText();
	}

	//------------------------------------------------------------------------------------------------
	void UpdateCountdownText()
	{
		if (!m_CountdownText)
			return;
		m_CountdownText.SetText(string.Format("Ce message disparait dans %1 secondes", m_SecondsRemaining.ToString()));
	}

	//------------------------------------------------------------------------------------------------
	// Appele automatiquement apres 60 secondes : ferme le menu, le joueur peut desormais
	// voir le monde (mais reste bloque dans le rayon 100m par le serveur)
	//------------------------------------------------------------------------------------------------
	void AutoClose()
	{
		GetGame().GetMenuManager().CloseMenu(this);
	}
}
