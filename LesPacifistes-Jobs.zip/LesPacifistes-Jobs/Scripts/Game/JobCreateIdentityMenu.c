//------------------------------------------------------------------------------------------------
// JobCreateIdentityMenu.c
// Menu de creation d'identite roleplay (3 champs : Nom, Prenom, Date de naissance).
// Validation : 3 champs non vides.
// Une seule fois par UID (verifie cote serveur).
//------------------------------------------------------------------------------------------------

class JobCreateIdentityMenu : ChimeraMenuBase
{
	Widget m_RootWidget;
	EditBoxWidget m_InputLastName;
	EditBoxWidget m_InputFirstName;
	EditBoxWidget m_InputBirthDate;
	TextWidget m_ErrorText;
	ButtonWidget m_BtnSave;
	ButtonWidget m_BtnCancel;
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuOpen()
	{
		super.OnMenuOpen();
		m_RootWidget = GetRootWidget();
		if (!m_RootWidget)
			return;
		
		m_InputLastName = EditBoxWidget.Cast(m_RootWidget.FindAnyWidget("InputLastName"));
		m_InputFirstName = EditBoxWidget.Cast(m_RootWidget.FindAnyWidget("InputFirstName"));
		m_InputBirthDate = EditBoxWidget.Cast(m_RootWidget.FindAnyWidget("InputBirthDate"));
		m_ErrorText = TextWidget.Cast(m_RootWidget.FindAnyWidget("ErrorText"));
		m_BtnSave = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnSave"));
		m_BtnCancel = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnCancel"));
		
		AttachButton(m_BtnSave, "save");
		AttachButton(m_BtnCancel, "cancel");
		
		// Focus sur le premier champ
		if (m_InputLastName)
			GetGame().GetWorkspace().SetFocusedWidget(m_InputLastName);
	}
	
	//------------------------------------------------------------------------------------------------
	void AttachButton(ButtonWidget btn, string action)
	{
		if (!btn)
			return;
		IdentityMenuClickHandler h = new IdentityMenuClickHandler();
		h.m_Menu = this;
		h.m_Action = action;
		btn.AddHandler(h);
		JobFocusHandler.Attach(btn);
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuUpdate(float tDelta)
	{
		super.OnMenuUpdate(tDelta);
		if (GetGame().GetInputManager().GetActionValue("MenuBack") > 0.5)
		{
			CloseMenuInternal();
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void OnButtonClicked(string action)
	{
		if (action == "cancel")
		{
			CloseMenuInternal();
			return;
		}
		
		if (action == "save")
		{
			DoSave();
			return;
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void DoSave()
	{
		string lastName = "";
		string firstName = "";
		string birthDate = "";
		
		if (m_InputLastName)
			lastName = m_InputLastName.GetText();
		if (m_InputFirstName)
			firstName = m_InputFirstName.GetText();
		if (m_InputBirthDate)
			birthDate = m_InputBirthDate.GetText();
		
		// Validation simple : 3 champs non vides
		if (lastName == "" || firstName == "" || birthDate == "")
		{
			ShowError("Tous les champs doivent etre remplis");
			return;
		}
		
		// Envoi au serveur
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc)
			return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc)
			return;
		
		jpc.ClientAskCreateIdentity(firstName, lastName, birthDate);
		CloseMenuInternal();
	}
	
	//------------------------------------------------------------------------------------------------
	void ShowError(string msg)
	{
		if (m_ErrorText)
			m_ErrorText.SetText(msg);
	}
	
	//------------------------------------------------------------------------------------------------
	void CloseMenuInternal()
	{
		GetGame().GetMenuManager().CloseMenu(this);
	}
}

class IdentityMenuClickHandler : ScriptedWidgetEventHandler
{
	JobCreateIdentityMenu m_Menu;
	string m_Action;
	
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu)
			m_Menu.OnButtonClicked(m_Action);
		return true;
	}
}
