//------------------------------------------------------------------------------------------------
// JobSellMineralsAction.c
// Action F sur les PNJ vendeurs de minerais (PNJ Mineur pour roche, DrugDealer pour drogues).
// A attacher via l'ActionsManagerComponent du PNJ.
//
// Configurer le type via le component JobMineralsBuyerComponent du PNJ.
//
// RESTRICTION DROGUE : si le PNJ est un dealer de drogue (buyerType = CANNABIS=2, COCAINE=3
// ou "toutes drogues"=100), l action n est visible qu aux membres d un gang. Le serveur
// (RpcAsk_SellMinerals) verifie en plus que le gang du vendeur CONTROLE la zone correspondant
// a la drogue vendue :
//   - Cannabis : seul le gang qui a captur e la zone cannabis peut vendre
//   - Cocaine  : seul le gang qui a captur e la zone cocaine peut vendre
// Un VOYOU qui n est dans aucun gang ne peut plus vendre de drogue.
//
// Les autres types (Roche, Bois, Pomme, Ble, Agriculteur) restent ouverts a tous.
//
// Le flag "membre de gang" est synchronise au client via JobPlayerComponent.IsClientInGang().
// Le controle de zone est verifie uniquement cote serveur (anti-cheat).
//------------------------------------------------------------------------------------------------

class JobSellMineralsAction : ScriptedUserAction
{
	//------------------------------------------------------------------------------------------------
	// Retourne true si le PNJ vend uniquement de la drogue (nécessite metier VOYOU ou gang)
	//------------------------------------------------------------------------------------------------
	protected bool IsDrugBuyer(IEntity npc)
	{
		if (!npc) return false;
		JobMineralsBuyerComponent buyer = JobMineralsBuyerComponent.Cast(
			npc.FindComponent(JobMineralsBuyerComponent));
		if (!buyer) return false;
		int type = buyer.GetMineralType();
		// CANNABIS = 2, COCAINE = 3, "Toutes drogues" = 100
		return (type == EMineralType.CANNABIS || type == EMineralType.COCAINE || type == 100);
	}

	//------------------------------------------------------------------------------------------------
	// Retourne true si le joueur local est AUTORISE A VOIR l action de vente drogue.
	// Nouvelle regle : seuls les membres d un gang peuvent la voir. Le serveur verifiera
	// ensuite que le gang du joueur controle bien la zone correspondant a la drogue vendue.
	//------------------------------------------------------------------------------------------------
	protected bool CanSellDrugs(IEntity user)
	{
		if (!user) return false;

		PlayerController localPC = GetGame().GetPlayerController();
		if (!localPC)
			return false;
		// Securite : l action ne doit considerer le flag gang que pour le joueur local
		if (localPC.GetControlledEntity() != user)
			return false;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(
			localPC.FindComponent(JobPlayerComponent));
		if (!jpc)
			return false;

		// Seuls les membres de gang voient l action.
		// Le controle de zone (gang controle-t-il bien cette zone-la ?) est fait serveur.
		return jpc.IsClientInGang();
	}

	//------------------------------------------------------------------------------------------------
	override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
	{
		if (!pOwnerEntity || !pUserEntity)
			return;

		PlayerController localPC = GetGame().GetPlayerController();
		if (!localPC)
			return;
		IEntity localEntity = localPC.GetControlledEntity();
		if (localEntity != pUserEntity)
			return;

		// Recupere le component du PNJ pour savoir quels types il achete
		JobMineralsBuyerComponent buyer = JobMineralsBuyerComponent.Cast(
			pOwnerEntity.FindComponent(JobMineralsBuyerComponent));
		if (!buyer)
			return;

		// Si le PNJ est un dealer de drogue, verifie VOYOU OU gang (anti-cheat client)
		if (IsDrugBuyer(pOwnerEntity))
		{
			if (!CanSellDrugs(pUserEntity))
				return;
		}

		// Ouvre le menu de vente avec le type de minerai du PNJ
		JobSellMineralsMenu menu = JobSellMineralsMenu.Cast(
			GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.JobSellMineralsMenu));
		if (menu)
			menu.Initialize(buyer.GetMineralType());
	}

	//------------------------------------------------------------------------------------------------
	override bool CanBeShownScript(IEntity user)
	{
		if (!user) return false;

		// Si le PNJ est un dealer de drogue, action visible UNIQUEMENT pour VOYOU OU gang
		if (IsDrugBuyer(GetOwner()))
			return CanSellDrugs(user);

		// Pour tous les autres types de PNJ (Roche, Bois, Pomme, Ble, Agriculteur), reste ouvert
		return true;
	}

	//------------------------------------------------------------------------------------------------
	override bool CanBePerformedScript(IEntity user)
	{
		return CanBeShownScript(user);
	}

	//------------------------------------------------------------------------------------------------
	override bool GetActionNameScript(out string outName)
	{
		outName = "Vendre les minerais";
		return true;
	}
}
