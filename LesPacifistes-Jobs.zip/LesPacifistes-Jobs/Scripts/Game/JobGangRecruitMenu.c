//------------------------------------------------------------------------------------------------
// JobGangRecruitMenu.c
// Menu liste de joueurs connectes pour recruter un membre dans le gang.
// Calque sur JobAtmMenu (meme pattern de liste de joueurs).
//------------------------------------------------------------------------------------------------

class JobGangRecruitMenu : ChimeraMenuBase
{
	const string LAYOUT_PATH = "{REPLACE_BY_BOSS}UI/layouts/JobGangRecruitMenu.layout";
	const string ENTRY_LAYOUT_PATH = "{38EB876AF9C737C8}UI/layouts/JobAtmPlayerEntry.layout";
	
	// === PAGINATION ===
	const int PLAYERS_PER_PAGE = 10;
	int m_CurrentPage = 0;
	ref array<int> m_AllPlayerIds = new array<int>();
	ref array<string> m_AllPlayerNames = new array<string>();
	float m_TabPressCooldown = 0;
	
	Widget m_RootWidget;
	Widget m_PlayersContainer;
	TextWidget m_TitleText;
	ButtonWidget m_CloseButton;
	ButtonWidget m_PrevPageButton;
	ButtonWidget m_NextPageButton;
	TextWidget m_PageLabel;
	
	ref map<ButtonWidget, int> m_ButtonToPlayerId = new map<ButtonWidget, int>();
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuOpen()
	{
		super.OnMenuOpen();
		m_RootWidget = GetRootWidget();
		if (!m_RootWidget)
			return;
		
		m_PlayersContainer = m_RootWidget.FindAnyWidget("PlayersContainer");
		m_TitleText = TextWidget.Cast(m_RootWidget.FindAnyWidget("TitleText"));
		m_CloseButton = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("CloseButton"));
		m_PrevPageButton = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("PrevPageButton"));
		m_NextPageButton = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("NextPageButton"));
		m_PageLabel = TextWidget.Cast(m_RootWidget.FindAnyWidget("PageLabel"));
		
		if (m_PrevPageButton)
		{
			GangRecruitClickHandler prevCh = new GangRecruitClickHandler();
			prevCh.m_Menu = this;
			prevCh.m_Action = "prev_page";
			m_PrevPageButton.AddHandler(prevCh);
			JobFocusHandler.Attach(m_PrevPageButton);
		}
		if (m_NextPageButton)
		{
			GangRecruitClickHandler nextCh = new GangRecruitClickHandler();
			nextCh.m_Menu = this;
			nextCh.m_Action = "next_page";
			m_NextPageButton.AddHandler(nextCh);
			JobFocusHandler.Attach(m_NextPageButton);
		}
		
		if (m_CloseButton)
		{
			GangRecruitClickHandler ch = new GangRecruitClickHandler();
			ch.m_Menu = this;
			ch.m_Action = "close";
			m_CloseButton.AddHandler(ch);
			JobFocusHandler.Attach(m_CloseButton);
		}
		
		ButtonWidget floatingClose = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("FloatingCloseButton"));
		if (floatingClose)
		{
			GangRecruitClickHandler floatCh = new GangRecruitClickHandler();
			floatCh.m_Menu = this;
			floatCh.m_Action = "close";
			floatingClose.AddHandler(floatCh);
			JobFocusHandler.Attach(floatingClose);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuUpdate(float tDelta)
	{
		super.OnMenuUpdate(tDelta);
		if (GetGame().GetInputManager().GetActionValue("MenuBack") > 0.5)
		{
			CloseMenuInternal();
			return;
		}
		
		// Navigation pagination manette (LB/RB)
		if (m_TabPressCooldown > 0)
			m_TabPressCooldown = m_TabPressCooldown - tDelta;
		else
		{
			if (GetGame().GetInputManager().GetActionValue("MenuTabLeft") > 0.5)
			{
				PrevPage();
				m_TabPressCooldown = 0.30;
			}
			else if (GetGame().GetInputManager().GetActionValue("MenuTabRight") > 0.5)
			{
				NextPage();
				m_TabPressCooldown = 0.30;
			}
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void Initialize()
	{
		if (m_TitleText)
			m_TitleText.SetText("Recruter un membre");
		BuildPlayerList();
	}
	
	//------------------------------------------------------------------------------------------------
	void BuildPlayerList()
	{
		if (!m_PlayersContainer)
			return;
		
		// === PHASE 1 : cache la liste complete ===
		m_AllPlayerIds.Clear();
		m_AllPlayerNames.Clear();
		m_CurrentPage = 0;
		
		PlayerManager pm = GetGame().GetPlayerManager();
		if (!pm)
			return;
		
		int myPlayerId = -1;
		PlayerController myPc = GetGame().GetPlayerController();
		if (myPc)
			myPlayerId = myPc.GetPlayerId();
		
		array<int> playerIds = new array<int>();
		pm.GetPlayers(playerIds);
		
		foreach (int pid : playerIds)
		{
			if (pid == myPlayerId)
				continue;
			string playerName = JobIdentityManager.GetInstance().Client_GetDisplayName(pid);
			if (playerName == "")
				continue;
			m_AllPlayerIds.Insert(pid);
			m_AllPlayerNames.Insert(playerName);
		}
		
		RenderCurrentPage();
	}
	
	//------------------------------------------------------------------------------------------------
	void RenderCurrentPage()
	{
		if (!m_PlayersContainer)
			return;
		
		// Nettoie les entrees existantes
		Widget child = m_PlayersContainer.GetChildren();
		while (child)
		{
			Widget next = child.GetSibling();
			child.RemoveFromHierarchy();
			child = next;
		}
		m_ButtonToPlayerId.Clear();
		
		int totalPages = GetTotalPages();
		if (m_CurrentPage >= totalPages && totalPages > 0)
			m_CurrentPage = totalPages - 1;
		if (m_CurrentPage < 0)
			m_CurrentPage = 0;
		
		int startIdx = m_CurrentPage * PLAYERS_PER_PAGE;
		int endIdx = startIdx + PLAYERS_PER_PAGE;
		if (endIdx > m_AllPlayerIds.Count())
			endIdx = m_AllPlayerIds.Count();
		
		WorkspaceWidget ws = GetGame().GetWorkspace();
		const int ENTRY_HEIGHT = 40;
		const int ENTRY_PADDING = 5;
		int yPos = 0;
		ButtonWidget firstButton = null;
		
		for (int i = startIdx; i < endIdx; i++)
		{
			int pid = m_AllPlayerIds.Get(i);
			string playerName = m_AllPlayerNames.Get(i);
			
			Widget entry = ws.CreateWidgets(ENTRY_LAYOUT_PATH, m_PlayersContainer);
			if (!entry)
				continue;
			
			FrameSlot.SetPos(entry, 0, yPos);
			FrameSlot.SetSize(entry, 660, ENTRY_HEIGHT);
			yPos += ENTRY_HEIGHT + ENTRY_PADDING;
			
			TextWidget nameW = TextWidget.Cast(entry.FindAnyWidget("PlayerName"));
			if (nameW)
				nameW.SetText(playerName);
			
			ButtonWidget btn = ButtonWidget.Cast(entry.FindAnyWidget("SelectButton"));
			if (btn)
			{
				m_ButtonToPlayerId.Set(btn, pid);
				GangRecruitClickHandler ch = new GangRecruitClickHandler();
				ch.m_Menu = this;
				ch.m_Action = "select";
				btn.AddHandler(ch);
				JobFocusHandler.Attach(btn);
				if (!firstButton)
					firstButton = btn;
			}
		}
		
		UpdatePaginationUI();
		
		// Focus initial pour la manette
		if (firstButton)
			GetGame().GetWorkspace().SetFocusedWidget(firstButton);
		else if (m_CloseButton)
			GetGame().GetWorkspace().SetFocusedWidget(m_CloseButton);
	}
	
	//------------------------------------------------------------------------------------------------
	int GetTotalPages()
	{
		int total = m_AllPlayerIds.Count();
		if (total == 0)
			return 1;
		return (total + PLAYERS_PER_PAGE - 1) / PLAYERS_PER_PAGE;
	}
	
	//------------------------------------------------------------------------------------------------
	void UpdatePaginationUI()
	{
		int totalPages = GetTotalPages();
		if (m_PageLabel)
			m_PageLabel.SetText(string.Format("Page %1 / %2", m_CurrentPage + 1, totalPages));
		if (m_PrevPageButton)
			m_PrevPageButton.SetEnabled(m_CurrentPage > 0);
		if (m_NextPageButton)
			m_NextPageButton.SetEnabled(m_CurrentPage < totalPages - 1);
	}
	
	//------------------------------------------------------------------------------------------------
	void PrevPage()
	{
		if (m_CurrentPage <= 0)
			return;
		m_CurrentPage--;
		RenderCurrentPage();
	}
	
	//------------------------------------------------------------------------------------------------
	void NextPage()
	{
		if (m_CurrentPage >= GetTotalPages() - 1)
			return;
		m_CurrentPage++;
		RenderCurrentPage();
	}
	
	//------------------------------------------------------------------------------------------------
	void OnPlayerSelected(ButtonWidget btn)
	{
		int pid;
		if (!m_ButtonToPlayerId.Find(btn, pid))
			return;
		
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		
		jpc.ClientAskRecruitMember(pid);
		CloseMenuInternal();
	}
	
	//------------------------------------------------------------------------------------------------
	void CloseMenuInternal()
	{
		GetGame().GetMenuManager().CloseMenu(this);
	}
}

//------------------------------------------------------------------------------------------------
class GangRecruitClickHandler : ScriptedWidgetEventHandler
{
	JobGangRecruitMenu m_Menu;
	string m_Action;
	
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (!m_Menu)
			return false;
		if (m_Action == "close")
		{
			m_Menu.CloseMenuInternal();
			return true;
		}
		if (m_Action == "select")
		{
			ButtonWidget btn = ButtonWidget.Cast(w);
			if (btn)
				m_Menu.OnPlayerSelected(btn);
			return true;
		}
		if (m_Action == "prev_page")
		{
			m_Menu.PrevPage();
			return true;
		}
		if (m_Action == "next_page")
		{
			m_Menu.NextPage();
			return true;
		}
		return false;
	}
}
