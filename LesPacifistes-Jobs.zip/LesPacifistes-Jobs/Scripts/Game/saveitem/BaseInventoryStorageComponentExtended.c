// =========================================================================
// BaseInventoryStorageComponentExtended.c
// -------------------------------------------------------------------------
// On ne peut pas modder BaseInventoryStorageComponent (classe engine).
// On modde donc SCR_UniversalInventoryStorageComponent qui en hérite,
// pour exposer InsertItem (protected) via un wrapper public.
//
// Utilisation : universalStorage.LP_InsertItem(item);
// =========================================================================

modded class SCR_UniversalInventoryStorageComponent
{
    //! Wrapper public pour InsertItem (protected) hérité de BaseInventoryStorageComponent.
    bool LP_InsertItem(IEntity item, EStoragePurpose purpose = EStoragePurpose.PURPOSE_DEPOSIT)
    {
        if (!item)
            return false;

        // Tentative 1 : recherche explicite d'un slot compatible avant insertion
        int slotCount = GetSlotsCount();
        for (int i = 0; i < slotCount; i++)
        {
            InventoryStorageSlot slot = GetSlot(i);
            if (!slot)
                continue;

            // Slot déjà occupé -> on passe
            if (slot.GetAttachedEntity())
                continue;

            // Tente d'insérer directement dans ce slot précis
            BaseInventoryTask task = InsertItem(item, i, true);
            if (task)
            {
                Print("[LP_InsertItem] Insertion réussie au slot " + i + " pour " + item, LogLevel.NORMAL);
                return true;
            }
        }

        // Tentative 2 : fallback avec index -1 (recherche auto par l'engine)
        BaseInventoryTask fallbackTask = InsertItem(item, -1, true);
        if (fallbackTask)
        {
            Print("[LP_InsertItem] Insertion réussie (fallback -1) pour " + item, LogLevel.NORMAL);
            return true;
        }

        Print("[LP_InsertItem] Échec total insertion pour " + item + " — slots disponibles: " + slotCount, LogLevel.WARNING);
        return false;
    }
}