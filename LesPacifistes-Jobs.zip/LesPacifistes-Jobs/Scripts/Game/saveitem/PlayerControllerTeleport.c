// =========================================================================
// PlayerControllerTeleport.c
// -------------------------------------------------------------------------
// Étend SCR_PlayerController pour exposer une méthode de téléportation
// côté serveur qui déclenche la téléportation chez le client owner via RPC.
//
// Pattern : SetOrigin côté serveur ne suffit pas pour un perso joueur
// activement contrôlé (le client prédit sa position et écrase l'ordre).
// La seule méthode fiable est SCR_Global.TeleportLocalPlayer() exécutée
// localement par le client qui contrôle le perso.
// =========================================================================

modded class SCR_PlayerController
{
    //! Appelé côté serveur. Envoie une RPC au client owner pour téléport local.
    void RequestTeleportToPosition(vector pos)
    {
        if (!Replication.IsServer()) return;
        Rpc(RpcDo_TeleportOwner, pos);
    }

    [RplRpc(RplChannel.Reliable, RplRcver.Owner)]
    protected void RpcDo_TeleportOwner(vector pos)
    {
        // S'exécute uniquement chez le client qui contrôle ce PlayerController
        SCR_Global.TeleportLocalPlayer(pos);
    }
}
