// =========================================================================
// VehicleSaveManager.c
// -------------------------------------------------------------------------
// Sauvegarde périodique (60s) des véhicules de la carte :
//   - Position + rotation (matrice complète)
//   - Carburant
//   - Dégâts / santé
//   - Contenu du coffre / storages
//
// Restauration : UNE SEULE FOIS au démarrage du serveur (10s après l'init
// pour laisser les véhicules vanilla spawner).
//
// À installer : Add Component sur le prefab du GameMode.
// =========================================================================

class VehicleSaveManagerClass : ScriptComponentClass {}
class VehicleSaveManager : ScriptComponent
{
    static VehicleSaveManager s_Instance;

    // -----------------------------------------------------------------
    // CONFIG
    // -----------------------------------------------------------------
    protected const int    PERIODIC_SAVE_INTERVAL_MS = 60000;  // save auto toutes les 60s
    protected const int    RESTORE_DELAY_MS          = 10000;  // délai avant restauration (laisser vanilla spawn)
    protected const string SAVE_PATH                 = "$profile:LesPacifistes/vehicles.json";

    // Bounds de la map (Everon ≈ 12800x12800) — on prend large pour couvrir tout
    protected const float MAP_HALF_EXTENT = 20000;

    // Flag pour ne restaurer qu'une seule fois par démarrage
    protected bool m_HasRestored = false;

    // Buffer réutilisé pour la query AABB
    protected ref array<IEntity> m_QueryBuffer = new array<IEntity>();

    // -----------------------------------------------------------------
    override void OnPostInit(IEntity owner)
    {
        super.OnPostInit(owner);
        s_Instance = this;

        if (!Replication.IsServer()) return;

        // Restauration unique 10s après le start (laisse le temps aux vehicles vanilla de spawn)
        GetGame().GetCallqueue().CallLater(RestoreAllVehicles, RESTORE_DELAY_MS, false);

        // Sauvegarde périodique toutes les 60s
        GetGame().GetCallqueue().CallLater(SaveAllVehicles, PERIODIC_SAVE_INTERVAL_MS, true);

        Print("[VehicleSaveManager] Initialisé", LogLevel.NORMAL);
    }

    static VehicleSaveManager GetInstance()
    {
        return s_Instance;
    }

    // -----------------------------------------------------------------
    // QUERY : récupère tous les véhicules du monde
    // -----------------------------------------------------------------
    void QueryAllVehicles(out notnull array<Vehicle> vehicles)
    {
        vehicles.Clear();
        m_QueryBuffer.Clear();

        vector min = Vector(-MAP_HALF_EXTENT, -1000, -MAP_HALF_EXTENT);
        vector max = Vector( MAP_HALF_EXTENT,  5000,  MAP_HALF_EXTENT);

        GetGame().GetWorld().QueryEntitiesByAABB(min, max, QueryVehicleCallback);

        foreach (IEntity ent : m_QueryBuffer)
        {
            Vehicle veh = Vehicle.Cast(ent);
            if (veh) vehicles.Insert(veh);
        }
    }

    bool QueryVehicleCallback(IEntity ent)
    {
        if (Vehicle.Cast(ent))
            m_QueryBuffer.Insert(ent);
        return true; // continue query
    }

    // -----------------------------------------------------------------
    // SAUVEGARDE PÉRIODIQUE
    // -----------------------------------------------------------------
    void SaveAllVehicles()
    {
        if (!Replication.IsServer()) return;

        array<Vehicle> vehicles = {};
        QueryAllVehicles(vehicles);

        if (vehicles.IsEmpty())
        {
            Print("[VehicleSaveManager] Aucun véhicule à sauvegarder", LogLevel.NORMAL);
            return;
        }

        SCR_JsonSaveContext ctx = new SCR_JsonSaveContext();
        int saved = 0;

        foreach (Vehicle veh : vehicles)
        {
            EntityPrefabData pd = veh.GetPrefabData();
            if (!pd) continue;

            ResourceName prefab = pd.GetPrefabName();
            if (prefab.IsEmpty()) continue;

            // Normalise (ajoute des accolades si GUID nu)
            string prefabNormalized = NormalizePrefabName(prefab);

            // Transform complet (position + 3 vecteurs de base pour la rotation)
            vector mat[4];
            veh.GetWorldTransform(mat);

            string idx = saved.ToString();

            ctx.WriteValue("prefab_" + idx, prefabNormalized);

            // Position
            ctx.WriteValue("posX_" + idx, mat[3][0]);
            ctx.WriteValue("posY_" + idx, mat[3][1]);
            ctx.WriteValue("posZ_" + idx, mat[3][2]);

            // Rotation (matrice 3x3 : 9 floats)
            ctx.WriteValue("m00_" + idx, mat[0][0]);
            ctx.WriteValue("m01_" + idx, mat[0][1]);
            ctx.WriteValue("m02_" + idx, mat[0][2]);
            ctx.WriteValue("m10_" + idx, mat[1][0]);
            ctx.WriteValue("m11_" + idx, mat[1][1]);
            ctx.WriteValue("m12_" + idx, mat[1][2]);
            ctx.WriteValue("m20_" + idx, mat[2][0]);
            ctx.WriteValue("m21_" + idx, mat[2][1]);
            ctx.WriteValue("m22_" + idx, mat[2][2]);

            // Carburant
            ctx.WriteValue("fuel_" + idx, GetVehicleFuel(veh));

            // Santé (0-1)
            ctx.WriteValue("health_" + idx, GetVehicleHealth(veh));

            // Contenu des coffres/storages
            array<string> items = {};
            CollectVehicleItems(veh, items);
            ctx.WriteValue("items_" + idx, items);

            if (items.Count() > 0)
                Print("[VehicleSaveManager]   Véhicule #" + idx + " : " + items.Count() + " items dans les coffres", LogLevel.NORMAL);

            saved++;
        }

        ctx.WriteValue("count", saved);
        ctx.SaveToFile(SAVE_PATH);

        Print("[VehicleSaveManager] Sauvegarde périodique : " + saved + " véhicule(s)", LogLevel.NORMAL);
    }

    // -----------------------------------------------------------------
    // RESTAURATION (une seule fois au démarrage)
    // -----------------------------------------------------------------
    void RestoreAllVehicles()
    {
        if (!Replication.IsServer()) return;

        if (m_HasRestored)
        {
            Print("[VehicleSaveManager] Restauration déjà effectuée, skip", LogLevel.NORMAL);
            return;
        }
        m_HasRestored = true;

        SCR_JsonLoadContext ctx = new SCR_JsonLoadContext();
        if (!ctx.LoadFromFile(SAVE_PATH))
        {
            Print("[VehicleSaveManager] Aucune sauvegarde à restaurer", LogLevel.NORMAL);
            return;
        }

        int count = 0;
        ctx.ReadValue("count", count);

        if (count <= 0)
        {
            Print("[VehicleSaveManager] Sauvegarde vide (count=" + count + ")", LogLevel.NORMAL);
            return;
        }

        Print("[VehicleSaveManager] Restauration de " + count + " véhicule(s)...", LogLevel.NORMAL);

        int spawned = 0;
        int failed = 0;

        for (int i = 0; i < count; i++)
        {
            string idx = i.ToString();

            string prefab;
            ctx.ReadValue("prefab_" + idx, prefab);
            if (prefab.IsEmpty()) { failed++; continue; }

            // Normalise (ajoute des accolades si GUID nu — cas des anciens JSON)
            ResourceName resName = NormalizePrefabName(prefab);
            Resource resource = Resource.Load(resName);
            if (!resource)
            {
                Print("[VehicleSaveManager] Resource invalide: " + resName, LogLevel.WARNING);
                failed++;
                continue;
            }

            // Reconstruire la matrice de transform
            float posX, posY, posZ;
            float m00, m01, m02, m10, m11, m12, m20, m21, m22;
            ctx.ReadValue("posX_" + idx, posX);
            ctx.ReadValue("posY_" + idx, posY);
            ctx.ReadValue("posZ_" + idx, posZ);
            ctx.ReadValue("m00_" + idx, m00);
            ctx.ReadValue("m01_" + idx, m01);
            ctx.ReadValue("m02_" + idx, m02);
            ctx.ReadValue("m10_" + idx, m10);
            ctx.ReadValue("m11_" + idx, m11);
            ctx.ReadValue("m12_" + idx, m12);
            ctx.ReadValue("m20_" + idx, m20);
            ctx.ReadValue("m21_" + idx, m21);
            ctx.ReadValue("m22_" + idx, m22);

            vector mat[4];
            mat[0] = Vector(m00, m01, m02);
            mat[1] = Vector(m10, m11, m12);
            mat[2] = Vector(m20, m21, m22);
            mat[3] = Vector(posX, posY, posZ);

            // Spawn
            EntitySpawnParams params = new EntitySpawnParams();
            params.TransformMode = ETransformMode.WORLD;
            params.Transform = mat;

            IEntity veh = GetGame().SpawnEntityPrefab(resource, GetGame().GetWorld(), params);
            if (!veh)
            {
                Print("[VehicleSaveManager] Spawn échoué: " + prefab, LogLevel.WARNING);
                failed++;
                continue;
            }

            // Carburant
            float fuel = 0;
            ctx.ReadValue("fuel_" + idx, fuel);
            SetVehicleFuel(veh, fuel);

            // Santé
            float health = 1.0;
            ctx.ReadValue("health_" + idx, health);
            SetVehicleHealth(veh, health);

            // Items dans le coffre
            array<string> items = {};
            ctx.ReadValue("items_" + idx, items);
            FillVehicleItems(veh, items);

            spawned++;
        }

        Print("[VehicleSaveManager] Restauration terminée : " + spawned + " ok / " + failed + " échec / " + count + " total", LogLevel.NORMAL);
    }

    // -----------------------------------------------------------------
    // HELPERS — CARBURANT
    // -----------------------------------------------------------------
    float GetVehicleFuel(IEntity veh)
    {
        FuelManagerComponent fuelMgr = FuelManagerComponent.Cast(veh.FindComponent(FuelManagerComponent));
        if (!fuelMgr) return 0;
        return fuelMgr.GetTotalFuel();
    }

    void SetVehicleFuel(IEntity veh, float fuel)
    {
        FuelManagerComponent fuelMgr = FuelManagerComponent.Cast(veh.FindComponent(FuelManagerComponent));
        if (!fuelMgr) return;

        // Distribuer proportionnellement sur tous les fuel nodes
        array<BaseFuelNode> nodes = {};
        fuelMgr.GetFuelNodesList(nodes);
        if (nodes.IsEmpty()) return;

        float perNode = fuel / nodes.Count();
        foreach (BaseFuelNode node : nodes)
        {
            if (node) node.SetFuel(perNode);
        }
    }

    // -----------------------------------------------------------------
    // HELPERS — SANTÉ / DÉGÂTS
    // -----------------------------------------------------------------
    float GetVehicleHealth(IEntity veh)
    {
        SCR_VehicleDamageManagerComponent dmg = SCR_VehicleDamageManagerComponent.Cast(
            veh.FindComponent(SCR_VehicleDamageManagerComponent)
        );
        if (!dmg) return 1.0;
        return dmg.GetHealthScaled();
    }

    void SetVehicleHealth(IEntity veh, float health)
    {
        SCR_VehicleDamageManagerComponent dmg = SCR_VehicleDamageManagerComponent.Cast(
            veh.FindComponent(SCR_VehicleDamageManagerComponent)
        );
        if (!dmg) return;
        dmg.SetHealthScaled(health);
    }

    // -----------------------------------------------------------------
    // HELPERS — INVENTAIRE / COFFRE
    // Les véhicules utilisent BaseInventoryStorageComponent directement
    // (pas de SCR_InventoryStorageManagerComponent comme sur les personnages).
    // Un véhicule peut avoir plusieurs storages (coffre, boîte à gants...).
    // -----------------------------------------------------------------
void CollectVehicleItems(IEntity veh, out notnull array<string> items)
{
    items.Clear();
    CollectVehicleItemsRecursive(veh, items, 0);
}

void CollectVehicleItemsRecursive(IEntity entity, out notnull array<string> items, int depth)
{
    if (!entity || depth > 5)
        return;

    array<Managed> storages = {};
    entity.FindComponents(BaseInventoryStorageComponent, storages);

    if (storages.IsEmpty())
        return;

    foreach (Managed sMgd : storages)
    {
        BaseInventoryStorageComponent storage = BaseInventoryStorageComponent.Cast(sMgd);
        if (!storage)
            continue;

        int slotCount = storage.GetSlotsCount();
        for (int i = 0; i < slotCount; i++)
        {
            InventoryStorageSlot slot = storage.GetSlot(i);
            if (!slot)
                continue;

            IEntity itemEnt = slot.GetAttachedEntity();
            if (!itemEnt)
                continue;

            EntityPrefabData pd = itemEnt.GetPrefabData();
            if (!pd)
                continue;

            ResourceName rn = pd.GetPrefabName();
            if (rn.IsEmpty())
                continue;

            items.Insert(NormalizePrefabName(rn));

            // Recurse dans les containers (sacs, boites) mais pas dans les armes
            // (evite chargeurs/attachments dupliques)
            BaseWeaponComponent weaponCheck = BaseWeaponComponent.Cast(itemEnt.FindComponent(BaseWeaponComponent));
            if (!weaponCheck)
                CollectVehicleItemsRecursive(itemEnt, items, depth + 1);
        }
    }

    Print("[VehicleSaveManager]   DEBUG depth=" + depth + " : " + items.Count() + " item(s) au total", LogLevel.NORMAL);
}




void FillVehicleItems(IEntity veh, array<string> items)
{
    if (!veh || !items || items.IsEmpty())
        return;

    SCR_VehicleInventoryStorageManagerComponent vehInv = SCR_VehicleInventoryStorageManagerComponent.Cast(
        veh.FindComponent(SCR_VehicleInventoryStorageManagerComponent)
    );

    int added = 0;

    if (vehInv)
    {
        foreach (string prefabStr : items)
        {
            if (prefabStr.IsEmpty())
                continue;
            ResourceName rn = prefabStr;
            bool ok = vehInv.TrySpawnPrefabToStorage(rn);
            if (ok)
                added++;
        }
    }
    else
    {
        // Pas de storage manager vehicule sur ce prefab : on ne peut rien faire de fiable.
        // InsertItem() est protected sur BaseInventoryStorageComponent, donc pas d'alternative
        // directe ici. On log juste pour visibilité.
        Print("[VehicleSaveManager] FillVehicleItems : pas de SCR_VehicleInventoryStorageManagerComponent sur ce vehicule, items non restaures (" + items.Count() + " perdus)", LogLevel.WARNING);
    }

    Print("[VehicleSaveManager] FillVehicleItems : " + added + " / " + items.Count() + " item(s) restaure(s)", LogLevel.NORMAL);
}



    // -----------------------------------------------------------------
    // HELPERS — NORMALISATION DU NOM DE PREFAB
    // GetPrefabName() sur un véhicule renvoie parfois juste un GUID nu
    // (ex: "F07F109AA11368C6") au lieu de "{GUID}Chemin.et".
    // On entoure d'accolades si nécessaire pour que Resource.Load
    // puisse résoudre correctement.
    // -----------------------------------------------------------------
    string NormalizePrefabName(string prefabStr)
    {
        if (prefabStr.IsEmpty()) return prefabStr;
        // Déjà bien formaté ({GUID}... ou {GUID}Chemin.et)
        if (prefabStr.IndexOf("{") == 0) return prefabStr;
        // GUID nu → on ajoute les accolades
        return "{" + prefabStr + "}";
    }
}