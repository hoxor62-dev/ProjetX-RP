class InventorySaveManagerClass : ScriptComponentClass {}
class InventorySaveManager : ScriptComponent
{
    static InventorySaveManager s_Instance;

    // -----------------------------------------------------------------
    // CONFIG
    // -----------------------------------------------------------------
    // Délai avant tentative de restauration (le perso doit être pleinement spawné).
    protected const int RESTORE_DELAY_MS = 5000;
    protected const int RESTORE_RETRY_MS = 2000;

    // Seuil de bascule entre les deux modes de restauration.
    // - Joueur a ≤ ce nombre d'items (hors default/attachements) : RESTAURATION COMPLÈTE + téléport
    // - Joueur a > ce nombre d'items : MODE COMPARE (pas de téléport, ajout des manquants seulement)
    protected const int FULL_RESTORE_THRESHOLD = 5;

    // Sauvegarde périodique de tous les joueurs connectés
    protected const int PERIODIC_SAVE_INTERVAL_MS = 60000;   // 60s entre chaque save auto
    protected const int PERIODIC_SAVE_GRACE_MS    = 15000;   // On ne sauvegarde pas les joueurs connectés depuis < 15s
                                                              // (évite d'écraser une restauration en cours à T+5s)

    // Étalement des saves pour éviter les lag spikes avec beaucoup de joueurs.
    // Au lieu de sauvegarder tous les joueurs dans la même frame (blocage
    // disque + itération composants), on traite N joueurs par tick avec
    // un petit délai entre chaque tick.
    protected const int BATCH_SAVE_COUNT       = 1;    // Joueurs traités par tick
    protected const int BATCH_SAVE_INTERVAL_MS = 100;  // Délai entre chaque tick

    // Queue des joueurs en attente de sauvegarde périodique
    protected ref array<int> m_PendingSaveQueue = new array<int>();
    protected bool m_IsProcessingSaveQueue = false;

    // Tracking du temps de connexion (playerId → tick de connexion en ms)
    // Sert au grace period pour la save périodique.
    protected ref map<int, int> m_PlayerConnectTimes = new map<int, int>();

    // Tracking du dernier corps connu de chaque joueur (uid → entity)
    // Mis à jour à chaque save réussie (non anti-dupe).
    // Utilisé à la reconnexion pour supprimer l'ancien corps s'il traîne
    // encore dans le monde (anti-glitch timeout : évite qu'un autre joueur
    // le loot pendant que le joueur est déconnecté).
    protected ref map<string, IEntity> m_PlayerLastBodyRefs = new map<string, IEntity>();

    // Fallback GUID exact des items donnés au spawn par défaut (carte + montre + effets personnels).
    // Laisser vide si la détection par chemin du prefab suffit. REPLACE_BY_BOSS sinon.
    protected const string MAP_PREFAB_FALLBACK   = ""; // ex: "{XXXXXXXXXXXXXXXX}Prefabs/Items/Equipment/Tools/Maps/Map_Eden.et"
    protected const string WATCH_PREFAB_FALLBACK = ""; // ex: "{XXXXXXXXXXXXXXXX}Prefabs/Items/Equipment/Personal/Watches/Watch_01.et"
    protected const string BELONGINGS_PREFAB_FALLBACK = "{E7FF723379730BD5}Prefabs/Items/PersonalBelongings/PersonalBelongings_CIV.et";

    override void OnPostInit(IEntity owner)
    {
        super.OnPostInit(owner);
        s_Instance = this;

        if (!Replication.IsServer()) return;

        SCR_BaseGameMode gm = SCR_BaseGameMode.Cast(GetGame().GetGameMode());
        if (gm)
        {
            gm.GetOnPlayerConnected().Insert(OnPlayerConnected);
            gm.GetOnPlayerDisconnected().Insert(OnPlayerDisconnected);
        }

        // Timer de sauvegarde périodique (60s) pour tous les joueurs connectés
        GetGame().GetCallqueue().CallLater(SaveAllConnectedPlayers, PERIODIC_SAVE_INTERVAL_MS, true);

        Print("[InventorySaveManager] Initialisé", LogLevel.NORMAL);
    }

    static InventorySaveManager GetInstance()
    {
        return s_Instance;
    }

    // -----------------------------------------------------------------
    // HOOKS GAMEMODE
    // -----------------------------------------------------------------
    void OnPlayerConnected(int playerId)
    {
        // Mémorise l'heure de connexion (pour le grace period de la save périodique)
        m_PlayerConnectTimes.Set(playerId, System.GetTickCount());

        GetGame().GetCallqueue().CallLater(TryRestoreInventory, RESTORE_DELAY_MS, false, playerId);
    }

    void OnPlayerDisconnected(int playerId, KickCauseCode cause, int timeout)
    {
        Print("[InventorySaveManager] OnPlayerDisconnected playerId=" + playerId + " cause=" + cause + " timeout=" + timeout, LogLevel.NORMAL);

        bool antiDupe = ShouldSkipInventorySave(playerId, cause, timeout);
        SaveInventory(playerId, antiDupe);

        // Nettoie le tracking connexion
        m_PlayerConnectTimes.Remove(playerId);

        // Retire de la queue de save périodique si présent (évite un save
        // inutile après déconnexion, et un log d'erreur playerEntity null)
        int queueIdx = m_PendingSaveQueue.Find(playerId);
        if (queueIdx >= 0)
            m_PendingSaveQueue.Remove(queueIdx);
    }

    // -----------------------------------------------------------------
    // ANTI-DUPLICATION
    // Détecte si le joueur tente d'exploiter (ALT+F4 inconscient ou timeout)
    // pour conserver ses items en double : corps loot + reco avec items.
    // -----------------------------------------------------------------
    bool ShouldSkipInventorySave(int playerId, KickCauseCode cause, int timeout)
    {
        // 1. Déconnexion par timeout réseau (perte de connexion / ALT+F4 brutal)
        //    Le paramètre 'timeout' > 0 indique une déconnexion forcée côté serveur.
        if (timeout > 0)
        {
            Print("[InventorySaveManager] ⚠ Anti-dupe : timeout réseau (" + timeout + "s) — items non sauvegardés", LogLevel.NORMAL);
            return true;
        }

        // 2. État inconscient ou mort
        IEntity playerEntity = GetGame().GetPlayerManager().GetPlayerControlledEntity(playerId);
        if (!playerEntity)
        {
            Print("[InventorySaveManager] ⚠ Anti-dupe : playerEntity null — items non sauvegardés par sécurité", LogLevel.NORMAL);
            return true;
        }

        CharacterControllerComponent ccc = CharacterControllerComponent.Cast(
            playerEntity.FindComponent(CharacterControllerComponent)
        );
        if (ccc)
        {
            ECharacterLifeState lifeState = ccc.GetLifeState();
            if (lifeState != ECharacterLifeState.ALIVE)
            {
                Print("[InventorySaveManager] ⚠ Anti-dupe : joueur en état " + lifeState + " (inconscient/mort) — items non sauvegardés", LogLevel.NORMAL);
                return true;
            }
        }

        return false;
    }

    // -----------------------------------------------------------------
    // SAUVEGARDE PÉRIODIQUE (toutes les 60s)
    // Enfile les joueurs éligibles dans une queue, puis démarre le
    // traitement étalé dans le temps (1 joueur toutes les 100ms) pour
    // éviter les lag spikes avec beaucoup de joueurs connectés.
    // -----------------------------------------------------------------
    void SaveAllConnectedPlayers()
    {
        if (!Replication.IsServer()) return;

        array<int> playerIds = {};
        GetGame().GetPlayerManager().GetPlayers(playerIds);

        if (playerIds.IsEmpty()) return;

        // Enfile tous les joueurs (le filtre grace period se fera au traitement)
        int enqueued = 0;
        foreach (int playerId : playerIds)
        {
            // Ne pas ré-enfiler un joueur déjà dans la queue
            if (m_PendingSaveQueue.Find(playerId) >= 0) continue;
            m_PendingSaveQueue.Insert(playerId);
            enqueued++;
        }

        Print("[InventorySaveManager] Save périodique : " + enqueued + " joueur(s) enfilés (queue totale: " + m_PendingSaveQueue.Count() + ")", LogLevel.NORMAL);

        // Démarre le traitement si pas déjà en cours
        if (!m_IsProcessingSaveQueue && !m_PendingSaveQueue.IsEmpty())
        {
            m_IsProcessingSaveQueue = true;
            ProcessNextInSaveQueue();
        }
    }

    // Traite les prochains joueurs de la queue (BATCH_SAVE_COUNT par tick),
    // puis se re-planifie 100ms plus tard s'il reste des joueurs.
    void ProcessNextInSaveQueue()
    {
        if (m_PendingSaveQueue.IsEmpty())
        {
            m_IsProcessingSaveQueue = false;
            return;
        }

        int now = System.GetTickCount();
        int processed = 0;

        while (!m_PendingSaveQueue.IsEmpty() && processed < BATCH_SAVE_COUNT)
        {
            int playerId = m_PendingSaveQueue[0];
            m_PendingSaveQueue.Remove(0);

            // Vérifier grace period au moment du traitement (le joueur peut
            // s'être connecté juste avant que son tour arrive)
            int connectTime = 0;
            if (m_PlayerConnectTimes.Find(playerId, connectTime))
            {
                if ((now - connectTime) < PERIODIC_SAVE_GRACE_MS)
                    continue;
            }

            // Save avec check anti-dupe (inconscient/mort → position seule)
            bool antiDupe = ShouldSkipInventorySave(playerId, KickCauseCode.NONE, 0);
            SaveInventory(playerId, antiDupe);
            processed++;
        }

        // Re-planifier s'il reste des joueurs
        if (!m_PendingSaveQueue.IsEmpty())
        {
            GetGame().GetCallqueue().CallLater(ProcessNextInSaveQueue, BATCH_SAVE_INTERVAL_MS, false);
        }
        else
        {
            m_IsProcessingSaveQueue = false;
        }
    }

    // -----------------------------------------------------------------
    // ANTI-GLITCH TIMEOUT (approche combinée)
    // Contexte : quand un joueur perd sa connexion, son ChimeraCharacter
    // reste dans le monde plusieurs dizaines de secondes en tant que corps
    // "unresponsive". Un autre joueur peut le fouiller pendant ce temps.
    //
    // Fix en 3 temps :
    //   1) LIRE : lister les items encore sur le corps orphelin
    //   2) FILTRER : retirer de la restauration ceux qui ont été loot
    //   3) SUPPRIMER : détruire le corps pour empêcher tout loot ultérieur
    // -----------------------------------------------------------------
    void HandleOrphanBody(string uid, inout array<string> prefabList)
    {
        if (uid.IsEmpty()) return;

        IEntity oldBody;
        if (!m_PlayerLastBodyRefs.Find(uid, oldBody))
            return;

        // Cleanup de la ref (traitement unique)
        m_PlayerLastBodyRefs.Remove(uid);

        // L'entity a-t-elle déjà été despawnée par le serveur ? (cas quit propre)
        if (!oldBody)
            return;

        // 1) LIRE les items encore présents sur le corps
        array<string> stillPresent = {};
        GetPlayerCurrentPrefabs(oldBody, stillPresent);

        Print("[InventorySaveManager] Corps orphelin détecté pour " + uid + " : JSON=" + prefabList.Count() + " items, corps=" + stillPresent.Count() + " items", LogLevel.NORMAL);

        // 2) FILTRER : multiset - on garde uniquement les items du JSON encore présents
        array<string> filtered = {};
        int removed = 0;
        foreach (string prefab : prefabList)
        {
            int idx = stillPresent.Find(prefab);
            if (idx >= 0)
            {
                stillPresent.Remove(idx);
                filtered.Insert(prefab);
            }
            else
            {
                removed++;
            }
        }
        prefabList.Clear();
        foreach (string p : filtered)
            prefabList.Insert(p);

        if (removed > 0)
            Print("[InventorySaveManager] " + removed + " item(s) retirés de la restauration (lootés pendant le timeout)", LogLevel.NORMAL);

        // 3) SUPPRIMER le corps pour empêcher tout loot ultérieur
        Print("[InventorySaveManager] Suppression du corps orphelin pour " + uid, LogLevel.NORMAL);
        SCR_EntityHelper.DeleteEntityAndChildren(oldBody);
    }

    // Liste les prefabs des items actuellement dans l'inventaire d'un joueur/corps.
    // Applique les mêmes filtres que la sauvegarde (default items + attachements d'arme).
    void GetPlayerCurrentPrefabs(IEntity playerEntity, out notnull array<string> prefabs)
    {
        prefabs.Clear();
        if (!playerEntity) return;

        SCR_InventoryStorageManagerComponent invMgr = SCR_InventoryStorageManagerComponent.Cast(
            playerEntity.FindComponent(SCR_InventoryStorageManagerComponent)
        );
        if (!invMgr) return;

        array<IEntity> items = {};
        invMgr.GetItems(items);

        foreach (IEntity item : items)
        {
            if (!item) continue;
            if (IsDefaultSpawnItem(item)) continue;
            if (IsInsideWeapon(item)) continue;

            EntityPrefabData pd = item.GetPrefabData();
            if (!pd) continue;
            ResourceName res = pd.GetPrefabName();
            if (res.IsEmpty()) continue;
            prefabs.Insert(res);
        }
    }

    // -----------------------------------------------------------------
    // UTILITAIRES
    // -----------------------------------------------------------------
    string GetUID(int playerId)
    {
        return GetGame().GetBackendApi().GetPlayerUID(playerId);
    }

    // Détecte si un item est un "item donné par défaut au spawn" (carte, montre, effets personnels).
    // Ces items sont ignorés à la sauvegarde ET dans le check "joueur déjà équipé".
    bool IsDefaultSpawnItem(IEntity item)
    {
        if (!item) return false;

        EntityPrefabData prefabData = item.GetPrefabData();
        if (!prefabData) return false;

        ResourceName res = prefabData.GetPrefabName();
        if (res.IsEmpty()) return false;

        string resStr = res;

        // 1) Détection par chemin du prefab
        //    - Cartes :              /Maps/, Map_
        //    - Montres :              /Watches/, Watch_
        //    - Effets personnels :    /PersonalBelongings/, PersonalBelongings_
        if (resStr.IndexOf("/Maps/")               >= 0) return true;
        if (resStr.IndexOf("Map_")                 >= 0) return true;
        if (resStr.IndexOf("/Watches/")            >= 0) return true;
        if (resStr.IndexOf("Watch_")               >= 0) return true;
        if (resStr.IndexOf("/PersonalBelongings/") >= 0) return true;
        if (resStr.IndexOf("PersonalBelongings_")  >= 0) return true;

        // 2) Fallback GUID exact si renseigné
        if (!MAP_PREFAB_FALLBACK.IsEmpty()        && res == MAP_PREFAB_FALLBACK)        return true;
        if (!WATCH_PREFAB_FALLBACK.IsEmpty()      && res == WATCH_PREFAB_FALLBACK)      return true;
        if (!BELONGINGS_PREFAB_FALLBACK.IsEmpty() && res == BELONGINGS_PREFAB_FALLBACK) return true;

        return false;
    }

    // -----------------------------------------------------------------
    // FILTRE ANTI-DUPLICATION ATTACHEMENTS D'ARME
    // Détecte si un item est rangé DANS le storage d'une arme (chargeur
    // monté, optique attachée, lampe, suppresseur, underbarrel...).
    // Ces items reviennent automatiquement avec l'arme via son prefab.
    //
    // ⚠ Approche : on regarde le STORAGE DIRECT du slot parent de l'item
    // (et pas la hiérarchie d'entités complète, qui matche le character
    // au plus haut niveau et casse tout).
    // -----------------------------------------------------------------
    bool IsInsideWeapon(IEntity item)
    {
        if (!item) return false;

        InventoryItemComponent itemComp = InventoryItemComponent.Cast(
            item.FindComponent(InventoryItemComponent)
        );
        if (!itemComp) return false;

        InventoryStorageSlot slot = itemComp.GetParentSlot();
        if (!slot) return false;

        BaseInventoryStorageComponent storage = slot.GetStorage();
        if (!storage) return false;

        IEntity storageOwner = storage.GetOwner();
        if (!storageOwner) return false;

        // WeaponComponent (et non BaseWeaponComponent) est spécifique aux
        // armes individuelles ; il n'est PAS présent sur le character.
        if (storageOwner.FindComponent(WeaponComponent))
            return true;

        return false;
    }

    // -----------------------------------------------------------------
    // SAUVEGARDE
    // -----------------------------------------------------------------
    void SaveInventory(int playerId, bool antiDupe)
    {
        if (!Replication.IsServer()) return;

        Print("[InventorySaveManager] SaveInventory playerId=" + playerId + " antiDupe=" + antiDupe, LogLevel.NORMAL);

        IEntity playerEntity = GetGame().GetPlayerManager().GetPlayerControlledEntity(playerId);
        if (!playerEntity)
        {
            Print("[InventorySaveManager] ERREUR: playerEntity null", LogLevel.ERROR);
            return;
        }

        string uid = GetUID(playerId);
        if (uid.IsEmpty()) return;

        // Liste vide si anti-duplication actif
        array<string> prefabList = {};

        if (!antiDupe)
        {
            SCR_InventoryStorageManagerComponent invMgr = SCR_InventoryStorageManagerComponent.Cast(
                playerEntity.FindComponent(SCR_InventoryStorageManagerComponent)
            );
            if (!invMgr)
            {
                Print("[InventorySaveManager] ERREUR: invMgr null", LogLevel.ERROR);
                return;
            }

            array<IEntity> items = {};
            invMgr.GetItems(items);

            foreach (IEntity item : items)
            {
                if (!item) continue;

                // On ignore les items donnés par défaut (carte, montre, effets personnels)
                if (IsDefaultSpawnItem(item)) continue;

                // On ignore les items attachés à une arme (chargeur dans arme, optique, lampe...)
                // — ils reviennent automatiquement avec l'arme via son prefab
                if (IsInsideWeapon(item)) continue;

                EntityPrefabData prefabData = item.GetPrefabData();
                if (!prefabData) continue;

                ResourceName res = prefabData.GetPrefabName();
                if (res.IsEmpty()) continue;

                prefabList.Insert(res);
            }
        }

        string path = "$profile:LesPacifistes/inventory_" + uid + ".json";

        // Position du joueur au moment de la déconnexion (toujours sauvegardée)
        vector pos = playerEntity.GetOrigin();

        SCR_JsonSaveContext ctx = new SCR_JsonSaveContext();
        ctx.WriteValue("items", prefabList);
        ctx.WriteValue("posX", pos[0]);
        ctx.WriteValue("posY", pos[1]);
        ctx.WriteValue("posZ", pos[2]);
        ctx.SaveToFile(path);

        if (antiDupe)
            Print("[InventorySaveManager] Sauvegarde anti-dupe pour " + uid + " : POSITION SEULE, pos=(" + pos[0] + ", " + pos[1] + ", " + pos[2] + ")", LogLevel.NORMAL);
        else
            Print("[InventorySaveManager] Sauvegarde pour " + uid + " : " + prefabList.Count() + " items, pos=(" + pos[0] + ", " + pos[1] + ", " + pos[2] + ")", LogLevel.NORMAL);

        // Tracking du corps pour anti-glitch timeout à la reconnexion.
        // On garde la référence uniquement en mode normal (vivant), pas en anti-dupe.
        // À la reconnexion, si cette entity existe encore, elle sera supprimée
        // pour empêcher le loot par un autre joueur pendant le timeout.
        if (!antiDupe)
        {
            m_PlayerLastBodyRefs.Set(uid, playerEntity);
        }
    }

    // -----------------------------------------------------------------
    // RESTAURATION
    // -----------------------------------------------------------------
    void TryRestoreInventory(int playerId)
    {
        if (!Replication.IsServer()) return;

        string uid = GetUID(playerId);
        if (uid.IsEmpty()) return;

        string path = "$profile:LesPacifistes/inventory_" + uid + ".json";

        SCR_JsonLoadContext ctx = new SCR_JsonLoadContext();
        if (!ctx.LoadFromFile(path))
        {
            Print("[InventorySaveManager] Pas de sauvegarde pour " + uid, LogLevel.NORMAL);
            return;
        }

        array<string> prefabList = {};
        ctx.ReadValue("items", prefabList);

        float posX, posY, posZ;
        ctx.ReadValue("posX", posX);
        ctx.ReadValue("posY", posY);
        ctx.ReadValue("posZ", posZ);
        bool hasPosition = (posX != 0 || posY != 0 || posZ != 0);

        // Anti-glitch timeout : si l'ancien corps existe encore, on filtre
        // prefabList selon les items encore présents (retire les lootés)
        // PUIS on supprime le corps pour empêcher tout loot futur.
        HandleOrphanBody(uid, prefabList);

        if (prefabList.IsEmpty() && !hasPosition)
        {
            Print("[InventorySaveManager] Sauvegarde vide pour " + uid, LogLevel.NORMAL);
            return;
        }

        IEntity playerEntity = GetGame().GetPlayerManager().GetPlayerControlledEntity(playerId);
        if (!playerEntity)
        {
            Print("[InventorySaveManager] playerEntity null — retry dans 2s", LogLevel.WARNING);
            GetGame().GetCallqueue().CallLater(TryRestoreInventory, RESTORE_RETRY_MS, false, playerId);
            return;
        }

        SCR_InventoryStorageManagerComponent invMgr = SCR_InventoryStorageManagerComponent.Cast(
            playerEntity.FindComponent(SCR_InventoryStorageManagerComponent)
        );
        if (!invMgr)
        {
            Print("[InventorySaveManager] ERREUR: invMgr null", LogLevel.ERROR);
            return;
        }

        // -------------------------------------------------------------
        // ANALYSE DE L'ÉTAT DU JOUEUR
        // On compte les items existants (hors default/hors attachements)
        // ET on construit la liste pour la comparaison ultérieure.
        // -------------------------------------------------------------
        array<IEntity> currentItems = {};
        invMgr.GetItems(currentItems);

        int extraItems = 0;
        array<string> playerPrefabs = {};
        foreach (IEntity it : currentItems)
        {
            if (!it) continue;
            if (IsDefaultSpawnItem(it)) continue;
            if (IsInsideWeapon(it)) continue;  // cohérent avec ce qu'on sauvegarde
            extraItems++;

            EntityPrefabData pd = it.GetPrefabData();
            if (!pd) continue;
            ResourceName resCurrent = pd.GetPrefabName();
            if (resCurrent.IsEmpty()) continue;

            playerPrefabs.Insert(resCurrent);
        }

        // =============================================================
        // MODE COMPARE — joueur déjà partiellement équipé (> seuil)
        // → pas de téléport, on ajoute uniquement les items manquants
        // =============================================================
        if (extraItems > FULL_RESTORE_THRESHOLD)
        {
            Print("[InventorySaveManager] Mode COMPARE pour " + uid + " : joueur a " + extraItems + " items (seuil=" + FULL_RESTORE_THRESHOLD + "), JSON contient " + prefabList.Count() + " items", LogLevel.NORMAL);

            int added = 0;
            int alreadyPresent = 0;
            int failed = 0;

            foreach (string prefab : prefabList)
            {
                // L'item est-il déjà chez le joueur ? (multiset : on retire 1 occurrence à chaque match)
                int idx = playerPrefabs.Find(prefab);
                if (idx >= 0)
                {
                    playerPrefabs.Remove(idx);
                    alreadyPresent++;
                    continue;
                }

                // Item manquant → on l'ajoute
                ResourceName res = prefab;
                Resource resource = Resource.Load(res);
                if (!resource)
                {
                    Print("[InventorySaveManager] Resource invalide: " + prefab, LogLevel.WARNING);
                    failed++;
                    continue;
                }

                if (invMgr.TrySpawnPrefabToStorage(res))
                    added++;
                else
                {
                    failed++;
                    Print("[InventorySaveManager] Spawn dans inventaire échoué pour: " + prefab, LogLevel.WARNING);
                }
            }

            Print("[InventorySaveManager] COMPARE pour " + uid + " : " + added + " ajoutés / " + alreadyPresent + " déjà présents / " + failed + " échec", LogLevel.NORMAL);
            return;
        }

        // =============================================================
        // MODE RESTAURATION COMPLÈTE — joueur sous le seuil
        // → téléport + spawn de tous les items du JSON
        // =============================================================
        Print("[InventorySaveManager] Mode RESTAURATION COMPLÈTE pour " + uid + " : joueur a " + extraItems + " items (sous seuil)", LogLevel.NORMAL);

        // Téléportation à la dernière position connue
        // (via RPC client : SetOrigin côté serveur est écrasé par la
        //  prédiction client sur un perso joueur contrôlé)
        if (hasPosition)
        {
            vector savedPos = Vector(posX, posY, posZ);
            SCR_PlayerController pc = SCR_PlayerController.Cast(
                GetGame().GetPlayerManager().GetPlayerController(playerId)
            );
            if (pc)
            {
                pc.RequestTeleportToPosition(savedPos);
                Print("[InventorySaveManager] Téléport demandé pour " + uid + " : (" + posX + ", " + posY + ", " + posZ + ")", LogLevel.NORMAL);
            }
            else
            {
                Print("[InventorySaveManager] ERREUR: PlayerController introuvable pour téléport " + uid, LogLevel.ERROR);
            }
        }

        // Restauration item par item
        // TrySpawnPrefabToStorage spawn l'item DIRECTEMENT dans l'inventaire
        // (jamais dans le monde) → pas d'items à terre.
        int restored = 0;
        int failed = 0;

        foreach (string prefab : prefabList)
        {
            ResourceName res = prefab;
            Resource resource = Resource.Load(res);
            if (!resource)
            {
                Print("[InventorySaveManager] Resource invalide: " + prefab, LogLevel.WARNING);
                failed++;
                continue;
            }

            if (invMgr.TrySpawnPrefabToStorage(res))
                restored++;
            else
            {
                failed++;
                Print("[InventorySaveManager] Spawn dans inventaire échoué pour: " + prefab, LogLevel.WARNING);
            }
        }

        if (!prefabList.IsEmpty())
            Print("[InventorySaveManager] Inventaire restauré pour " + uid + " : " + restored + " ok / " + failed + " échec / " + prefabList.Count() + " total", LogLevel.NORMAL);
    }
}
