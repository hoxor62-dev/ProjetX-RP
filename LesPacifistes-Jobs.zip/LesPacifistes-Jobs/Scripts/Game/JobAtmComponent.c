//------------------------------------------------------------------------------------------------
// JobAtmComponent.c
// Composant a ajouter sur le prefab ATM pour permettre aux joueurs d'envoyer
// des capsules a d'autres joueurs connectes.
//
// Workbench setup:
// - Prefab source: {2E4F863EAF4C65AD}prefabs/atm.et
// - Ajouter ce composant JobAtmComponent
// - Ajouter ActionsManagerComponent
// - Ajouter l'action JobAtmAction (UserActions)
// - RplComponent obligatoire pour la replication
//------------------------------------------------------------------------------------------------

[ComponentEditorProps(category: "LesPacifistesJobs", description: "Marqueur ATM pour transfert de capsules")]
class JobAtmComponentClass : ScriptComponentClass
{
}

//------------------------------------------------------------------------------------------------
class JobAtmComponent : ScriptComponent
{
	// Composant marqueur simple - sert juste a identifier un prefab comme etant un ATM.
	// Toute la logique est dans JobAtmAction + JobAtmMenu + JobPlayerComponent.
}
