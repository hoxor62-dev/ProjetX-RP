//------------------------------------------------------------------------------------------------
// JobPlayerComponent.c
// Composant attache au SCR_PlayerController.
// Gere la synchro du metier actif entre serveur et client + update du HUD txt_Job.
//
// Architecture:
// - Serveur charge le metier depuis JSON au spawn
// - Serveur change le metier via ServerSetJob -> RPC vers le client proprietaire
// - Client owner recoit RpcDo_SetJob et met a jour son HUD txt_Job
//------------------------------------------------------------------------------------------------

[ComponentEditorProps(category: "LesPacifistesJobs", description: "Metier du joueur (sur PlayerController)")]
class JobPlayerComponentClass : ScriptComponentClass
{
}

//------------------------------------------------------------------------------------------------
class JobPlayerComponent : ScriptComponent
{
	// Metier actif - REPLIQUE A TOUS LES CLIENTS via RplProp
	// Permet aux autres clients de voir le metier d un joueur (pour CanBeShownScript filtre par job)
	[RplProp()]
	int m_JobInt = EJobType.NONE;
	
	// Quete active cote client (mise a jour via RPC - pour le menu Abandonner)
	int m_ClientActiveQuestType = 0;
	
	// Etat de la quete active cote client (0=inactive, 1=step1, 2=step2, 3=ready_to_turn_in)
	int m_ClientActiveQuestState = 0;
	
	// Compteur de retries pour UpdateHUD cote client local
	int m_HudRetryCount = 0;
	const int MAX_HUD_RETRIES = 40;
	
	// Etats client pour les logos HUD (sync via RPC depuis le serveur)
	bool m_ClientHasLicense = false;
	bool m_ClientHasIdentity = false;
	
	// Flag client : true si le joueur local est admin (synchronise par Svr_PushIsAdmin
	// au boot du composant). Utilise par le profil RP pour afficher le bouton Admin
	// uniquement aux admins. Le check serveur reste authoritative (cf RpcAsk_OpenAdminMenu).
	bool m_ClientIsAdmin = false;

	// Flag client : true si le joueur local est membre d un gang (synchronise par Svr_PushIsInGang
	// au boot et apres chaque creation/depart/dissolution/recrutement/ejection). Utilise par
	// JobSellMineralsAction pour autoriser la vente de drogue aux membres de gang.
	// Le check serveur reste authoritative (cf RpcAsk_SellMinerals).
	bool m_ClientIsInGang = false;
	
	//------------------------------------------------------------------------------------------------
	override void OnPostInit(IEntity owner)
	{
		super.OnPostInit(owner);
		
		PlayerController pc = PlayerController.Cast(owner);
		if (!pc)
			return;
		
		bool isServer = Replication.IsServer();
		Print(string.Format("[JobPlayerComponent] OnPostInit sur PlayerController, isServer=%1", isServer),
			LogLevel.NORMAL);
		
		if (isServer)
		{
			// Le serveur charge le metier depuis JSON avec un delai pour attendre que le playerId soit pret
			GetGame().GetCallqueue().CallLater(ServerInitFromJson, 3000, false);
		}
		
		// Tous les clients (y compris le host): declenche UpdateHUD au demarrage
		// Le HUD peut prendre quelques secondes a etre instancie apres le spawn
		GetGame().GetCallqueue().CallLater(ClientInitialHudUpdate, 5000, false);
	}
	
	//------------------------------------------------------------------------------------------------
	// Serveur: charge le metier depuis JSON et l'envoie au client proprietaire
	//------------------------------------------------------------------------------------------------
	void ServerInitFromJson()
	{
		if (!Replication.IsServer())
			return;
		
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc)
			return;
		
		int playerId = pc.GetPlayerId();
		if (playerId <= 0)
		{
			GetGame().GetCallqueue().CallLater(ServerInitFromJson, 2000, false);
			return;
		}
		
		JobPlayerData data = JobManager.GetInstance().GetPlayerData(playerId);
		if (!data)
			return;
		
		m_JobInt = data.m_Job;
		// Push la valeur a tous les clients via RplProp
		Replication.BumpMe();
		// Propage aussi au CharacterJobComponent (visible par tous les autres clients)
		SyncJobToCharacter();
		
		// Envoie au client proprietaire (Owner)
		Rpc(RpcDo_SetJob, data.m_Job);
		// Appel local pour le host en singleplayer (serveur = client)
		RpcDo_SetJob(data.m_Job);
		
		Print(string.Format("[JobPlayerComponent] ServerInitFromJson player=%1 job=%2",
			playerId, JobData.JobToString(data.m_Job)), LogLevel.NORMAL);
		
		// Push initial des flags HUD (permis + identite) vers le client
		// Avec un petit delai pour laisser le HUD du client se charger
		GetGame().GetCallqueue().CallLater(Svr_PushHudFlags, 6000, false);
		
		// Push le flag admin vers le client (utilise par le profil RP pour afficher
		// le bouton Admin uniquement aux administrateurs)
		GetGame().GetCallqueue().CallLater(Svr_PushIsAdmin, 6100, false);

		// Push le flag "membre de gang" vers le client (utilise par JobSellMineralsAction
		// pour autoriser les membres de gang a vendre de la drogue en plus des Voyous)
		GetGame().GetCallqueue().CallLater(Svr_PushIsInGang, 6200, false);
		
		// Push toutes les identites RP existantes des autres joueurs vers ce client
		// (pour que son cache local soit a jour pour ATM, vol, etc.)
		GetGame().GetCallqueue().CallLater(Svr_PushAllExistingIdentities, 6500, false);
		
		// Push les marqueurs de zones controlees par les gangs (persistance carte)
		// Delai pour laisser la carte du client s initialiser
		GetGame().GetCallqueue().CallLater(Svr_PushControlledZoneMarkers, 7000, false);
	}
	
	//------------------------------------------------------------------------------------------------
	// SERVEUR : envoie a CE client tous les marqueurs de zones actuellement controlees par un gang
	// (appele au spawn pour que les marqueurs persistent entre reconnexions et reboots)
	//------------------------------------------------------------------------------------------------
	void Svr_PushControlledZoneMarkers()
	{
		if (!Replication.IsServer())
			return;
		
		// Filtre : seuls les voyous OU membres d un gang voient les marqueurs de zone
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc)
			return;
		int myPlayerId = pc.GetPlayerId();
		if (!JobZoneCaptureManager.CanSeeZoneMarker(myPlayerId))
			return;
		
		array<int> items = new array<int>();
		array<string> gangs = new array<string>();
		array<float> xs = new array<float>();
		array<float> zs = new array<float>();
		JobGangManager.GetInstance().GetAllControlledZones(items, gangs, xs, zs);
		
		for (int i = 0; i < items.Count(); i++)
		{
			string drugLabel = "zone";
			if (items.Get(i) == EMarketItem.CANNABIS)
				drugLabel = "Cannabis";
			else if (items.Get(i) == EMarketItem.COCAINE)
				drugLabel = "Cocaine";
			
			// Ignore les zones sans position connue (anciennes captures avant cette MAJ)
			if (xs.Get(i) == 0 && zs.Get(i) == 0)
				continue;
			
			ServerSendZoneMarker(xs.Get(i), zs.Get(i), gangs.Get(i), drugLabel);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// SERVEUR : Push les identites de TOUS les joueurs (incluant les autres) vers ce client
	// Utilise lors de la connexion pour synchroniser le cache local du nouveau client
	//------------------------------------------------------------------------------------------------
	void Svr_PushAllExistingIdentities()
	{
		if (!Replication.IsServer())
			return;
		PlayerManager pm = GetGame().GetPlayerManager();
		if (!pm)
			return;
		
		array<int> allPlayers = new array<int>();
		pm.GetPlayers(allPlayers);
		foreach (int pid : allPlayers)
		{
			string uid = JobManager.GetInstance().GetPersistentUID(pid);
			if (uid == "")
				continue;
			JobRpIdentity id = JobIdentityManager.GetInstance().GetIdentity(uid);
			if (!id)
				continue;
			string displayName = id.m_FirstName + " " + id.m_LastName;
			PushIdentityToOwner(pid, displayName);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Helper : retourne le metier du joueur (utilisable depuis n importe ou - cote client comme serveur
	// grace au RplProp m_JobInt qui synchronise la valeur a tous les clients)
	//------------------------------------------------------------------------------------------------
	EJobType GetJob()
	{
		return m_JobInt;
	}
	
	//------------------------------------------------------------------------------------------------
	// SERVEUR : propage le metier au CharacterJobComponent du joueur (visible par tous les clients)
	// A appeler dans ServerSetJob et apres init JSON, juste apres avoir set m_JobInt + BumpMe.
	//------------------------------------------------------------------------------------------------
	void SyncJobToCharacter()
	{
		if (!Replication.IsServer())
			return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc)
			return;
		IEntity character = pc.GetControlledEntity();
		if (!character)
			return;
		JobCharacterJobComponent charComp = JobCharacterJobComponent.Cast(
			character.FindComponent(JobCharacterJobComponent));
		if (charComp)
			charComp.ServerSetJob(m_JobInt);
	}
	
	//------------------------------------------------------------------------------------------------
	// Serveur: change le metier (appelee par JobManager.SetPlayerJob)
	//------------------------------------------------------------------------------------------------
	void ServerSetJob(EJobType newJob)
	{
		if (!Replication.IsServer())
			return;
		
		m_JobInt = newJob;
		// Push la valeur a tous les clients via RplProp
		Replication.BumpMe();
		// Propage aussi au CharacterJobComponent (visible par tous les autres clients)
		SyncJobToCharacter();
		
		// Envoie au client proprietaire
		Rpc(RpcDo_SetJob, newJob);
		// Appel local pour le host
		RpcDo_SetJob(newJob);
		
		Print(string.Format("[JobPlayerComponent] ServerSetJob: %1", JobData.JobToString(newJob)),
			LogLevel.NORMAL);
	}
	
	//------------------------------------------------------------------------------------------------
	// RPC serveur -> client OWNER: met a jour le metier local et le HUD
	//------------------------------------------------------------------------------------------------
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_SetJob(int newJob)
	{
		m_JobInt = newJob;
		
		Print(string.Format("[JobPlayerComponent] RpcDo_SetJob recu: %1",
			JobData.JobToString(newJob)), LogLevel.NORMAL);
		
		// Met a jour le HUD cote client
		m_HudRetryCount = 0;
		UpdateHUD();
	}
	
	//------------------------------------------------------------------------------------------------
	// Cote client: force une mise a jour du HUD au demarrage
	//------------------------------------------------------------------------------------------------
	void ClientInitialHudUpdate()
	{
		// Verifie qu'on est bien le PC local (pas un proxy d'un autre joueur en multi)
		PlayerController localPC = GetGame().GetPlayerController();
		if (!localPC || GetOwner() != localPC)
			return;
		
		Print(string.Format("[JobPlayerComponent] ClientInitialHudUpdate job=%1",
			JobData.JobToString(m_JobInt)), LogLevel.NORMAL);
		
		m_HudRetryCount = 0;
		UpdateHUD();
		
	// Demarre le manager HUD identite (bloc haut droit : nom RP + especes + banque)
	LP_PlayerIdentityHud.GetInstance();
	
	}
	
	//------------------------------------------------------------------------------------------------
	// Met a jour le widget txt_Job du SurvivalHUD
	// Uniquement pour le joueur local (verifie par la garde)
	//------------------------------------------------------------------------------------------------
	void UpdateHUD()
	{
		// Garde: ne touche au HUD que si c'est le PC local
		PlayerController localPC = GetGame().GetPlayerController();
		if (!localPC || GetOwner() != localPC)
			return;
		
		TextWidget txt = FindJobTextWidget();
		
		if (!txt)
		{
			m_HudRetryCount++;
			if (m_HudRetryCount <= MAX_HUD_RETRIES)
			{
				GetGame().GetCallqueue().CallLater(UpdateHUD, 500, false);
			}
			else
			{
				Print("[JobPlayerComponent] ECHEC: txt_Job introuvable apres " + MAX_HUD_RETRIES + " tentatives",
					LogLevel.WARNING);
			}
			return;
		}
		
		string label = JobData.GetJobLabel(m_JobInt);
		txt.SetText(label);
		Print(string.Format("[JobPlayerComponent] HUD mis a jour: txt_Job = '%1'", label),
			LogLevel.NORMAL);
		
		// Met aussi a jour les logos permis/identite
		UpdateLogos();
		
		// Re-verifie periodiquement au cas ou le HUD est recree (death/respawn)
		GetGame().GetCallqueue().CallLater(RefreshHUD, 10000, false);
	}
	
	//------------------------------------------------------------------------------------------------
	// Met a jour les 4 logos HUD (permis OK/KO + identite OK/KO) selon l'etat client
	// Tolerant aux widgets manquants (si layout pas encore charge ou logos retires)
	//------------------------------------------------------------------------------------------------
	void UpdateLogos()
	{
		PlayerController localPC = GetGame().GetPlayerController();
		if (!localPC || GetOwner() != localPC)
			return;
		
		WorkspaceWidget ws = GetGame().GetWorkspace();
		if (!ws)
		{
			Print("[JobLogos DEBUG] Workspace est null", LogLevel.WARNING);
			return;
		}
		
		// Permis : on affiche soit OK soit KO selon m_ClientHasLicense
		Widget permisOk = ws.FindAnyWidget("Permis_Icon_Yes");
		Widget permisKo = ws.FindAnyWidget("Permis_Icon_No");
		Widget identityOk = ws.FindAnyWidget("Identity_Icon_Yes");
		Widget identityKo = ws.FindAnyWidget("Identity_Icon_No");
		
		// Debug: log si on trouve les widgets
		Print(string.Format("[JobLogos DEBUG] hasLicense=%1 hasIdentity=%2 | found: permisOK=%3 permisKO=%4 idOK=%5 idKO=%6",
			m_ClientHasLicense, m_ClientHasIdentity,
			(permisOk != null), (permisKo != null), (identityOk != null), (identityKo != null)),
			LogLevel.NORMAL);
		
		if (permisOk)
			permisOk.SetVisible(m_ClientHasLicense);
		if (permisKo)
			permisKo.SetVisible(!m_ClientHasLicense);
		
		if (identityOk)
			identityOk.SetVisible(m_ClientHasIdentity);
		if (identityKo)
			identityKo.SetVisible(!m_ClientHasIdentity);
	}
	
	//------------------------------------------------------------------------------------------------
	void RefreshHUD()
	{
		PlayerController localPC = GetGame().GetPlayerController();
		if (!localPC || GetOwner() != localPC)
			return;
		
		TextWidget txt = FindJobTextWidget();
		if (txt)
		{
			string expected = JobData.GetJobLabel(m_JobInt);
			txt.SetText(expected);
			GetGame().GetCallqueue().CallLater(RefreshHUD, 10000, false);
		}
		else
		{
			m_HudRetryCount = 0;
			UpdateHUD();
		}
	}
	
	//------------------------------------------------------------------------------------------------
	TextWidget FindJobTextWidget()
	{
		WorkspaceWidget ws = GetGame().GetWorkspace();
		if (!ws)
			return null;
		
		Widget root = ws.FindAnyWidget("txt_Job");
		if (!root)
			return null;
		
		return TextWidget.Cast(root);
	}
	
	//------------------------------------------------------------------------------------------------
	// SERVEUR -> CLIENT OWNER: affiche un hint cote client uniquement
	// Utilise pour les notifications de salaire, paiements, etc.
	//------------------------------------------------------------------------------------------------
	void ServerShowHint(string message)
	{
		if (!Replication.IsServer())
			return;

		Rpc(RpcDo_ShowHint, message);
		// Appel local uniquement pour le host (serveur = client). Sur un serveur dedie,
		// il n y a pas de joueur local et les widgets n existent pas.
		if (IsLocalPlayerOwner())
			RpcDo_ShowHint(message);
	}

	//------------------------------------------------------------------------------------------------
	// POINT DE PASSAGE DE TOUTES LES NOTIFICATIONS DU MOD
	// JobManager.NotifyPlayerChat() -> ServerShowHint() -> ici. Plus de 500 appels dans le
	// mod convergent vers cette fonction : amendes, paie, ventes, alertes, SMS, gang...
	//
	// CHANGEMENT 11 nov 2026 : on n utilise plus le hint vanilla Bohemia. Les notifications
	// passent par LP_NotificationManager, qui affiche un panneau centre a l ecran et deduit
	// le titre et la couleur du prefixe du message ("[JUSTICE] ..." -> titre JUSTICE, rouge).
	// Le titre est laisse vide ici justement pour activer cette deduction automatique.
	//------------------------------------------------------------------------------------------------
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_ShowHint(string message)
	{
		// Client uniquement : manipulation de widgets.
		if (!GetGame().GetPlayerController())
			return;

		LP_NotificationManager.Show(message, "", 6.0);
	}
	
	//------------------------------------------------------------------------------------------------
	// CORRECTIF 11 nov 2026 - crash "NULL pointer to instance" dans InsertStaticMarker
	//
	// Le motif "Rpc(RpcDo_X, ...) puis RpcDo_X(...)" execute la fonction client EN PLUS
	// directement sur le serveur. C est voulu pour le cas host (serveur-joueur), mais sur
	// un serveur DEDIE il n existe aucun joueur local : les markers de carte, les widgets
	// et le HUD n existent pas. SCR_MapMarkerManagerComponent.InsertStaticMarker plantait
	// donc a chaque appel urgence (NotifyAllMedics -> ServerSetQuestMarker).
	//
	// Cette garde n autorise l execution locale que si CE composant appartient bien au
	// joueur local. Elle corrige aussi un bug latent sur host : sans elle, le marker d un
	// AUTRE joueur s affichait sur la carte de l hote.
	//------------------------------------------------------------------------------------------------
	bool IsLocalPlayerOwner()
	{
		PlayerController localPc = GetGame().GetPlayerController();
		if (!localPc)
			return false;   // serveur dedie : aucun joueur local
		return (localPc == PlayerController.Cast(GetOwner()));
	}

	//------------------------------------------------------------------------------------------------
	// SERVEUR -> CLIENT: affiche un marker de quete sur la carte du joueur
	//------------------------------------------------------------------------------------------------
	void ServerSetQuestMarker(vector pos, string label)
	{
		if (!Replication.IsServer())
			return;

		Rpc(RpcDo_SetQuestMarker, pos[0], pos[2], label);
		if (IsLocalPlayerOwner())
			RpcDo_SetQuestMarker(pos[0], pos[2], label);
	}

	//------------------------------------------------------------------------------------------------
	void ServerRemoveQuestMarker()
	{
		if (!Replication.IsServer())
			return;

		Rpc(RpcDo_RemoveQuestMarker);
		if (IsLocalPlayerOwner())
			RpcDo_RemoveQuestMarker();
	}
	
	// Reference au marker carte local (client only)
	ref SCR_MapMarkerBase m_QuestMarker;
	ref array<ref SCR_MapMarkerBase> m_ZoneMarkers = new array<ref SCR_MapMarkerBase>();
	
	// Widget de la barre de progression de capture de zone (cree/detruit dynamiquement)
	Widget m_CaptureProgressWidget;
	// Widget HUD pour la barre de progression d activite metier (extraction/transformation)
	Widget m_ActivityProgressWidget;
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_SetQuestMarker(float posX, float posZ, string label)
	{
		// Defense en profondeur : le systeme de markers est purement client. Sans joueur
		// local (serveur dedie), InsertStaticMarker deref un stockage inexistant et plante.
		if (!GetGame().GetPlayerController())
			return;

		SCR_MapMarkerManagerComponent markerMgr = SCR_MapMarkerManagerComponent.Cast(
			GetGame().GetGameMode().FindComponent(SCR_MapMarkerManagerComponent));
		if (!markerMgr)
		{
			Print("[JobPlayerComponent] SCR_MapMarkerManagerComponent introuvable",
				LogLevel.WARNING);
			return;
		}
		
		// Supprime l'ancien marker s'il existe
		if (m_QuestMarker)
		{
			markerMgr.RemoveStaticMarker(m_QuestMarker);
			m_QuestMarker = null;
		}
		
		// Cree le nouveau marker
		m_QuestMarker = new SCR_MapMarkerBase();
		m_QuestMarker.SetType(SCR_EMapMarkerType.PLACED_CUSTOM);
		m_QuestMarker.SetWorldPos(posX, posZ);
		m_QuestMarker.SetCustomText(label);
		m_QuestMarker.SetColorEntry(4);
		markerMgr.InsertStaticMarker(m_QuestMarker, true, true);
		
		Print(string.Format("[JobPlayerComponent] Marker quete cree: pos=(%1, %2) label=%3",
			posX, posZ, label), LogLevel.NORMAL);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_RemoveQuestMarker()
	{
		// Defense en profondeur : pas de joueur local = pas de systeme de markers.
		if (!GetGame().GetPlayerController())
			return;

		if (!m_QuestMarker)
			return;

		SCR_MapMarkerManagerComponent markerMgr = SCR_MapMarkerManagerComponent.Cast(
			GetGame().GetGameMode().FindComponent(SCR_MapMarkerManagerComponent));
		if (markerMgr)
		{
			markerMgr.RemoveStaticMarker(m_QuestMarker);
		}
		m_QuestMarker = null;
		
		Print("[JobPlayerComponent] Marker quete supprime", LogLevel.NORMAL);
	}
	
	//------------------------------------------------------------------------------------------------
	// Sync cote client de l'etat quete active (pour afficher le bouton Abandonner)
	//------------------------------------------------------------------------------------------------
	void ServerSetActiveQuestType(int questType, int questState)
	{
		if (!Replication.IsServer())
			return;
		
		Rpc(RpcDo_SetActiveQuestType, questType, questState);
		if (IsLocalPlayerOwner())
			RpcDo_SetActiveQuestType(questType, questState);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_SetActiveQuestType(int questType, int questState)
	{
		m_ClientActiveQuestType = questType;
		m_ClientActiveQuestState = questState;
	}
	
	// Getter cote client pour JobQuestMenu
	int GetClientActiveQuestType()
	{
		return m_ClientActiveQuestType;
	}
	
	// Getter cote client pour JobActionMenu (afficher bouton "Valider ma quete")
	int GetClientActiveQuestState()
	{
		return m_ClientActiveQuestState;
	}
	
	// Helper: true si la quete est prete a etre rendue au PNJ
	bool IsClientQuestReadyToTurnIn()
	{
		return (m_ClientActiveQuestType != 0 && m_ClientActiveQuestState == 3);
	}
	
	//------------------------------------------------------------------------------------------------
	// ============ WRAPPERS RPC CLIENT -> SERVEUR ============
	// Ces RPC partent du PlayerController du joueur (dont il est owner),
	// ce qui garantit que Rpc() fonctionne correctement en multijoueur.
	// Elles delegient ensuite au JobManager cote serveur.
	//------------------------------------------------------------------------------------------------
	
	// Appelee cote client depuis JobSelectionMenu.ConfirmSelection
	void ClientAskSelectJob(int jobInt)
	{
		Rpc(RpcAsk_SelectJob, jobInt);
	}
	
	// Appelee cote client depuis JobActionMenu (bouton "Recevoir equipement")
	void ClientAskEquipment()
	{
		Rpc(RpcAsk_Equipment);
	}
	
	// Appelee cote client depuis JobShopMenu (bouton "Acheter")
	void ClientAskBuyShopItem(int itemIndex, int shopTypeInt)
	{
		Rpc(RpcAsk_BuyShopItem, itemIndex, shopTypeInt);
	}
	
	// Appelee cote client depuis JobShopMenu (bouton "Vendre" - mode sell)
	void ClientAskSellShopItem(int itemIndex, int shopTypeInt)
	{
		Rpc(RpcAsk_SellShopItem, itemIndex, shopTypeInt);
	}
	
	// Appelee cote client depuis JobAtmMenu (bouton "Envoyer")
	void ClientAskAtmTransfer(int targetPlayerId, int amount)
	{
		Rpc(RpcAsk_AtmTransfer, targetPlayerId, amount);
	}
	
	// Appelee cote client depuis JobDrugDealerMenu (bouton "Vendre")
	void ClientAskSellDrug(int drugTypeInt)
	{
		Rpc(RpcAsk_SellDrug, drugTypeInt);
	}
	
	// Appelee cote client depuis JobHarvestAction (touche F sur une plante)
	void ClientAskHarvest(int drugTypeInt, RplId plantRplId)
	{
		Rpc(RpcAsk_Harvest, drugTypeInt, plantRplId);
	}
	
	// Appelee cote client depuis JobActionMenu (bouton "Vehicule de service")
	void ClientAskServiceVehicle()
	{
		Rpc(RpcAsk_ServiceVehicle);
	}
	
	// Appelee cote client depuis JobQuestMenu (accepter une quete)
	void ClientAskAcceptQuest(int questTypeInt)
	{
		Rpc(RpcAsk_AcceptQuest, questTypeInt);
	}
	
	// Appelee cote client depuis JobActionMenu (bouton "Valider ma quete")
	void ClientAskTurnInQuest()
	{
		Rpc(RpcAsk_TurnInQuest);
	}
	
	// Appelee cote client depuis JobQuestMenu (abandonner)
	void ClientAskAbandonQuest()
	{
		Rpc(RpcAsk_AbandonQuest);
	}
	
	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER: le joueur a selectionne un metier via le PNJ metier public (interim).
	// Applique un cooldown de 24h entre deux changements de metier via cette voie.
	// L admin bypass ce cooldown via ClientAskAdminSetJob (RPC separe).
	//------------------------------------------------------------------------------------------------
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_SelectJob(int jobInt)
	{
		if (!Replication.IsServer())
			return;

		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc)
			return;
		int playerId = pc.GetPlayerId();
		if (playerId <= 0)
			return;

		EJobType newJob = jobInt;
		if (newJob == EJobType.NONE)
			return;

		// === COOLDOWN 24H ===
		// Si le joueur a deja change de metier dans les dernieres 24h, refus.
		// Premier changement (m_LastJobChangeUnix == 0) toujours autorise.
		JobPlayerData data = JobManager.GetInstance().GetPlayerData(playerId);
		if (data && data.m_LastJobChangeUnix > 0)
		{
			const int COOLDOWN_SECONDS = 86400; // 24h
			int now = System.GetUnixTime();
			int elapsed = now - data.m_LastJobChangeUnix;

			if (elapsed < COOLDOWN_SECONDS)
			{
				int remaining = COOLDOWN_SECONDS - elapsed;
				int remainingHours = remaining / 3600;
				int remainingMinutes = (remaining % 3600) / 60;

				JobManager.GetInstance().NotifyPlayerChat(playerId,
					string.Format("[EMPLOI] Vous devez attendre %1h %2min avant de pouvoir changer a nouveau de metier.",
						remainingHours.ToString(), remainingMinutes.ToString()));

				Print(string.Format("[JobPlayerComponent] RpcAsk_SelectJob REFUSE (cooldown) player=%1 restant=%2s",
					playerId, remaining.ToString()), LogLevel.NORMAL);
				return;
			}
		}

		Print(string.Format("[JobPlayerComponent] RpcAsk_SelectJob player=%1 job=%2",
			playerId, JobData.JobToString(newJob)), LogLevel.NORMAL);

		// Capture l ancien metier AVANT le SetPlayerJob pour detecter si c est un VRAI changement
		EJobType oldJob = EJobType.NONE;
		if (data)
			oldJob = data.m_Job;

		JobManager.GetInstance().SetPlayerJob(playerId, newJob);

		// Marque le cooldown UNIQUEMENT en cas de vrai changement (pas si le joueur reclique
		// son metier actuel). Note : SetPlayerJob a potentiellement rafraichi data en place.
		if (data && oldJob != newJob)
		{
			data.m_LastJobChangeUnix = System.GetUnixTime();
			JobManager.GetInstance().SavePlayerData(playerId);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER: le joueur demande son equipement de metier
	//------------------------------------------------------------------------------------------------
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_Equipment()
	{
		if (!Replication.IsServer())
			return;
		
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc)
			return;
		int playerId = pc.GetPlayerId();
		if (playerId <= 0)
			return;
		
		IEntity character = pc.GetControlledEntity();
		if (!character)
			return;
		
		JobPlayerData data = JobManager.GetInstance().GetPlayerData(playerId);
		if (!data)
			return;
		
		EJobType job = data.m_Job;
		
		Print(string.Format("[JobPlayerComponent] RpcAsk_Equipment player=%1 job=%2",
			playerId, JobData.JobToString(job)), LogLevel.NORMAL);
		
		// === CHECK COOLDOWN EQUIPEMENT 30 MIN ===
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "")
			return;
		JobCooldownManager cdMgr = JobCooldownManager.GetInstance();
		int remaining = cdMgr.GetEquipmentCooldownRemaining(uid);
		if (remaining > 0)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				string.Format("[EMPLOI] Cooldown actif - veuillez patienter %1 avant de reprendre votre tenue de service.",
					JobCooldownManager.FormatRemaining(remaining)));
			return;
		}
		
		JobEquipmentGiver.GiveEquipment(character, job);
		
		// === DEMARRE LE COOLDOWN APRES DISTRIBUTION ===
		cdMgr.StartEquipmentCooldown(uid);
		
		string msg = string.Format("[EMPLOI] Equipement %1 recu. Prochaine prise possible dans 30 minutes.",
			JobData.GetJobLabel(job));
		JobManager.GetInstance().NotifyPlayerChat(playerId, msg);
	}
	
	//------------------------------------------------------------------------------------------------
	// === MUNITIONS SUPPLEMENTAIRES (police / militaire) ===
	// Cooldown 30 min SEPARE de l equipement et du vehicule.
	//------------------------------------------------------------------------------------------------
	void ClientAskAmmoResupply()
	{
		Rpc(RpcAsk_AmmoResupply);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_AmmoResupply()
	{
		if (!Replication.IsServer())
			return;
		
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc)
			return;
		int playerId = pc.GetPlayerId();
		if (playerId <= 0)
			return;
		
		IEntity character = pc.GetControlledEntity();
		if (!character)
			return;
		
		JobPlayerData data = JobManager.GetInstance().GetPlayerData(playerId);
		if (!data)
			return;
		EJobType job = data.m_Job;
		
		// Verifie que le metier a droit aux munitions
		if (!JobData.HasAmmoResupply(job))
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[MUNITIONS] Votre metier n'a pas acces aux munitions de service.");
			return;
		}
		
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "")
			return;
		
		// === CHECK COOLDOWN MUNITIONS 30 MIN (separe) ===
		JobCooldownManager cdMgr = JobCooldownManager.GetInstance();
		int remaining = cdMgr.GetAmmoCooldownRemaining(uid);
		if (remaining > 0)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				string.Format("[MUNITIONS] Cooldown actif - veuillez patienter %1 avant de reprendre des munitions.",
					JobCooldownManager.FormatRemaining(remaining)));
			return;
		}
		
		// Distribue les munitions (items + quantites paralleles)
		array<ResourceName> items = JobData.GetAmmoResupplyItems(job);
		array<int> quantities = JobData.GetAmmoResupplyQuantities(job);
		int givenTypes = 0;
		for (int i = 0; i < items.Count(); i++)
		{
			ResourceName prefab = items.Get(i);
			if (prefab == "" || prefab == ResourceName.Empty)
				continue;
			// Ignore les placeholders non remplis (militaire)
			if (prefab.IndexOf("REPLACE_BY_BOSS") >= 0)
				continue;
			int qty = 1;
			if (i < quantities.Count())
				qty = quantities.Get(i);
			JobEquipmentGiver.SpawnAndGiveItemQuantity(character, prefab, qty);
			givenTypes++;
		}
		
		if (givenTypes == 0)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[MUNITIONS] Aucune munition configuree pour votre metier.");
			return;
		}
		
		// Demarre le cooldown munitions
		cdMgr.StartAmmoCooldown(uid);
		
		JobManager.GetInstance().NotifyPlayerChat(playerId,
			"[MUNITIONS] Munitions supplementaires recues. Prochaine prise possible dans 30 minutes.");
	}
	
	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER: achat dans la boutique du metier (Voyou ou Concessionnaire)
	//------------------------------------------------------------------------------------------------
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_BuyShopItem(int itemIndex, int shopTypeInt)
	{
		if (!Replication.IsServer())
			return;
		
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc)
			return;
		int playerId = pc.GetPlayerId();
		if (playerId <= 0)
			return;
		
		IEntity player = pc.GetControlledEntity();
		if (!player)
			return;
		
		JobPlayerData data = JobManager.GetInstance().GetPlayerData(playerId);
		if (!data)
			return;
		
		EJobType shopType = shopTypeInt;
		EJobType playerJob = data.m_Job;
		
		// === Validation acces aux shops ===
		// Shops publics (accessibles a tout le monde)
		bool isPublicShop = (shopType == EJobType.SHOP_VETEMENTS
			|| shopType == EJobType.SHOP_NOURRITURE
			|| shopType == EJobType.SHOP_LOCATION
			|| shopType == EJobType.SHOP_COIFFURE
			|| shopType == EJobType.SHOP_DROGERIE
			|| shopType == EJobType.SHOP_BIJOUTERIE);
		
		// Shops de metier (accessibles uniquement au joueur ayant ce metier)
		bool isPlayerJobShop = (shopType == playerJob
			&& (playerJob == EJobType.VOYOU
				|| playerJob == EJobType.CONCESSIONNAIRE
				|| playerJob == EJobType.VENDEUR_IMMOBILIER
				|| playerJob == EJobType.MECANICIEN
				|| playerJob == EJobType.JOURNALISTE
				|| playerJob == EJobType.VENDEUR_VETEMENTS));
		
		// Shops Voyou en lingots d or : reserves au metier VOYOU
		bool isVoyouGoldShop = JobGoldCurrencyHelper.IsVoyouGoldShop(shopType);
		if (isVoyouGoldShop && playerJob != EJobType.VOYOU)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[BOUTIQUE] Le marche noir est reserve aux Voyous.");
			return;
		}
		
		if (!isPublicShop && !isPlayerJobShop && !isVoyouGoldShop)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[BOUTIQUE] Acces refuse a cette boutique.");
			return;
		}
		
		if (!JobShopCatalog.HasShop(shopType))
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[BOUTIQUE] Boutique non configuree.");
			return;
		}
		
		JobShopItem item = JobShopCatalog.GetItemByIndex(shopType, itemIndex);
		if (!item)
			return;
		
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		
		// =========================================================================
		// === PAIEMENT EN LINGOTS D OR ===
		// =========================================================================
		if (item.m_PaidInGold)
		{
			int currentGold = JobGoldCurrencyHelper.CountGoldBars(playerId);
			if (currentGold < item.m_Price)
			{
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					string.Format("[BOUTIQUE] Lingots insuffisants. Besoin: %1 | Vous avez: %2",
						item.m_Price, currentGold));
				return;
			}
			
			// Retire les lingots
			int removed = JobGoldCurrencyHelper.RemoveGoldBars(playerId, item.m_Price);
			if (removed < item.m_Price)
			{
				// Echec partiel : rendre les lingots retires
				if (removed > 0)
					JobGoldCurrencyHelper.GiveGoldBars(playerId, removed);
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[BOUTIQUE] Erreur lors du paiement (lingots). Achat annule.");
				return;
			}
			
			// Spawn l item achete
			bool successGold;
			if (item.m_IsVehicle)
				successGold = JobRpcHandler.SpawnVehicleAt10m(player, item.m_Prefab, uid);
			else
			{
				int qty = item.m_Quantity;
				if (qty <= 0) qty = 1;
				successGold = JobEquipmentGiver.SpawnAndGiveItemQuantity(player, item.m_Prefab, qty);
			}
			
			if (!successGold)
			{
				// Rollback : redonner les lingots
				JobGoldCurrencyHelper.GiveGoldBars(playerId, item.m_Price);
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[BOUTIQUE] Echec du spawn, lingots rembourses.");
				return;
			}
			
			int newGold = JobGoldCurrencyHelper.CountGoldBars(playerId);
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				string.Format("[BOUTIQUE] %1 achete pour %2 lingot(s) d or. Lingots restants: %3",
					item.m_Name, item.m_Price, newGold));
			
			Print(string.Format("[JobPlayerComponent] RpcAsk_BuyShopItem GOLD player=%1 item=%2 prix=%3",
				playerId, item.m_Name, item.m_Price), LogLevel.NORMAL);
			return;
		}
		
		// =========================================================================
		// === PAIEMENT EN CAPSULES (mode classique) ===
		// =========================================================================
		CapsuleEconomyManager eco = CapsuleEconomyManager.GetInstance();
		if (!eco)
			return;
		
		int currentCapsules = eco.GetCapsules(uid);
		if (currentCapsules < item.m_Price)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				string.Format("[BOUTIQUE] Solde insuffisant. Besoin: %1 | Vous avez: %2",
					item.m_Price, currentCapsules));
			return;
		}
		
		// Deduction
		eco.AddCapsules(uid, -item.m_Price);
		int newTotal = eco.GetCapsules(uid);
		
		// Sync HUD capsules
		CapsulePlayerComponent capsComp = CapsulePlayerComponent.Cast(
			pc.FindComponent(CapsulePlayerComponent));
		if (capsComp)
			capsComp.Svr_SendCapsules(newTotal);
		
		// Spawn
		bool success;
		if (item.m_IsVehicle)
			success = JobRpcHandler.SpawnVehicleAt10m(player, item.m_Prefab, uid);
		else
		{
			int qty = item.m_Quantity;
			if (qty <= 0) qty = 1;
			success = JobEquipmentGiver.SpawnAndGiveItemQuantity(player, item.m_Prefab, qty);
		}
		
		if (!success)
		{
			// Rollback
			eco.AddCapsules(uid, item.m_Price);
			if (capsComp)
				capsComp.Svr_SendCapsules(eco.GetCapsules(uid));
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[BOUTIQUE] Echec du spawn, achat rembourse.");
			return;
		}
		
		string msg = string.Format("[BOUTIQUE] %1 achete pour %2 capsules. Solde: %3",
			item.m_Name, item.m_Price, newTotal);
		JobManager.GetInstance().NotifyPlayerChat(playerId, msg);
		
		Print(string.Format("[JobPlayerComponent] RpcAsk_BuyShopItem player=%1 item=%2 prix=%3",
			playerId, item.m_Name, item.m_Price), LogLevel.NORMAL);
	}

	
	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : vendre un item du catalogue (mode "sell" du shop)
	//  - Verifie que le joueur a bien au moins 1 exemplaire de l item dans son inventaire
	//  - Supprime 1 exemplaire de l inventaire
	//  - Credite m_Price / 3 capsules
	//------------------------------------------------------------------------------------------------
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_SellShopItem(int itemIndex, int shopTypeInt)
	{
		if (!Replication.IsServer())
			return;
		
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc)
			return;
		int playerId = pc.GetPlayerId();
		if (playerId <= 0)
			return;
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "")
			return;
		
		// Recupere le catalogue du shop
		EJobType shopJob = shopTypeInt;
		
		// === BLOCAGE VENTE BIJOUTERIE ===
		// Les bijoux ne peuvent pas etre revendus au shop (anti-exploit blanchiment / farming).
		// Le joueur peut toujours les fondre en lingots via le four (JobFonteManager).
		if (shopJob == EJobType.SHOP_BIJOUTERIE)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[BIJOUTERIE] Les bijoux ne se revendent pas ici. Fondez-les au four pour obtenir des lingots d or.");
			return;
		}
		
		array<ref JobShopItem> items = JobShopCatalog.GetItemsForJob(shopJob);
		if (!items || itemIndex < 0 || itemIndex >= items.Count())
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId, "[BOUTIQUE] Item invalide.");
			return;
		}
		
		JobShopItem item = items.Get(itemIndex);
		if (!item)
			return;
		
		// Prix de vente : prix d achat / 3 (arrondi inferieur)
		int sellPrice = item.m_Price / 3;
		if (sellPrice <= 0)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[BOUTIQUE] Cet item n'a pas de valeur de revente.");
			return;
		}
		
		// Recupere l inventaire du joueur
		IEntity playerChar = pc.GetControlledEntity();
		if (!playerChar)
			return;
		SCR_InventoryStorageManagerComponent inv = SCR_InventoryStorageManagerComponent.Cast(
			playerChar.FindComponent(SCR_InventoryStorageManagerComponent));
		if (!inv)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[BOUTIQUE] Inventaire inaccessible.");
			return;
		}
		
		// Cherche le 1er item de l inventaire qui correspond au prefab
		array<IEntity> playerItems = new array<IEntity>();
		inv.GetItems(playerItems);
		
		IEntity itemToRemove = null;
		foreach (IEntity invItem : playerItems)
		{
			if (!invItem) continue;
			EntityPrefabData pd = invItem.GetPrefabData();
			if (!pd) continue;
			if (pd.GetPrefabName() == item.m_Prefab)
			{
				itemToRemove = invItem;
				break;
			}
		}
		
		if (!itemToRemove)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[BOUTIQUE] Vous n'avez pas cet item dans votre inventaire.");
			return;
		}
		
		// Supprime l item de l inventaire
		// SCR_EntityHelper.DeleteEntityAndChildren gere le retrait + delete propre
		SCR_EntityHelper.DeleteEntityAndChildren(itemToRemove);
		
		// Credite le joueur
		CapsuleEconomyManager eco = CapsuleEconomyManager.GetInstance();
		if (!eco)
			return;
		eco.AddCapsules(uid, sellPrice);
		int newTotal = eco.GetCapsules(uid);
		
		// Notif
		JobManager.GetInstance().NotifyPlayerChat(playerId,
			string.Format("[BOUTIQUE] %1 vendu pour %2 capsules. Solde: %3",
				item.m_Name, sellPrice, newTotal));
		
		Print(string.Format("[JobPlayerComponent] RpcAsk_SellShopItem player=%1 item=%2 prix=%3",
			playerId, item.m_Name, sellPrice), LogLevel.NORMAL);
	}
	
	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER: transfert de capsules entre joueurs via l'ATM
	//------------------------------------------------------------------------------------------------
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_AtmTransfer(int targetPlayerId, int amount)
	{
		if (!Replication.IsServer())
			return;
		
		PlayerController senderPc = PlayerController.Cast(GetOwner());
		if (!senderPc)
			return;
		int senderPlayerId = senderPc.GetPlayerId();
		if (senderPlayerId <= 0)
			return;
		
		// Validation montant
		if (amount <= 0)
		{
			JobManager.GetInstance().NotifyPlayerChat(senderPlayerId,
				"[ATM] Montant invalide.");
			return;
		}
		
		// Validation cible
		if (targetPlayerId == senderPlayerId)
		{
			JobManager.GetInstance().NotifyPlayerChat(senderPlayerId,
				"[ATM] Impossible de s'envoyer a soi-meme.");
			return;
		}
		
		PlayerController targetPc = GetGame().GetPlayerManager().GetPlayerController(targetPlayerId);
		if (!targetPc)
		{
			JobManager.GetInstance().NotifyPlayerChat(senderPlayerId,
				"[ATM] Destinataire introuvable.");
			return;
		}
		
		// Recupere les UID
		string senderUid = JobManager.GetInstance().GetPersistentUID(senderPlayerId);
		string targetUid = JobManager.GetInstance().GetPersistentUID(targetPlayerId);
		if (senderUid == "" || targetUid == "")
		{
			JobManager.GetInstance().NotifyPlayerChat(senderPlayerId,
				"[ATM] Erreur: UID indisponible.");
			return;
		}
		
		// Validation solde
		CapsuleEconomyManager eco = CapsuleEconomyManager.GetInstance();
		if (!eco)
			return;
		
		int senderBalance = eco.GetCapsules(senderUid);
		if (senderBalance < amount)
		{
			JobManager.GetInstance().NotifyPlayerChat(senderPlayerId,
				string.Format("[ATM] Solde insuffisant. Vous avez: %1 | Besoin: %2",
					senderBalance, amount));
			return;
		}
		
		// Transfert
		eco.AddCapsules(senderUid, -amount);
		eco.AddCapsules(targetUid, amount);
		
		int senderNewBalance = eco.GetCapsules(senderUid);
		int targetNewBalance = eco.GetCapsules(targetUid);
		
		// Sync HUD capsules des deux joueurs
		CapsulePlayerComponent senderCapsComp = CapsulePlayerComponent.Cast(
			senderPc.FindComponent(CapsulePlayerComponent));
		if (senderCapsComp)
			senderCapsComp.Svr_SendCapsules(senderNewBalance);
		
		CapsulePlayerComponent targetCapsComp = CapsulePlayerComponent.Cast(
			targetPc.FindComponent(CapsulePlayerComponent));
		if (targetCapsComp)
			targetCapsComp.Svr_SendCapsules(targetNewBalance);
		
		// Notifications - utilise l'identite RP si dispo, sinon le playername
		string targetName = JobIdentityManager.GetInstance().GetDisplayNameByPlayerId(targetPlayerId);
		string senderName = JobIdentityManager.GetInstance().GetDisplayNameByPlayerId(senderPlayerId);
		
		JobManager.GetInstance().NotifyPlayerChat(senderPlayerId,
			string.Format("[ATM] %1 capsules envoyees a %2. Solde: %3", amount, targetName, senderNewBalance));
		
		JobManager.GetInstance().NotifyPlayerChat(targetPlayerId,
			string.Format("[ATM] %1 capsules recues de %2. Solde: %3", amount, senderName, targetNewBalance));
		
		Print(string.Format("[JobPlayerComponent] ATM: %1 -> %2 montant=%3",
			senderName, targetName, amount), LogLevel.NORMAL);
	}
	
	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER: vente de drogue au PNJ dealer
	//------------------------------------------------------------------------------------------------
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_SellDrug(int drugTypeInt)
	{
		if (!Replication.IsServer())
			return;
		
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc)
			return;
		int playerId = pc.GetPlayerId();
		if (playerId <= 0)
			return;
		
		IEntity player = pc.GetControlledEntity();
		if (!player)
			return;
		
		EDrugType drugType = drugTypeInt;
		JobDrugSystem.ServerSellDrug(playerId, player, drugType);
	}
	
	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER: recolte de drogue sur une plante
	//------------------------------------------------------------------------------------------------
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_Harvest(int drugTypeInt, RplId plantRplId)
	{
		if (!Replication.IsServer())
			return;
		
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc)
			return;
		int playerId = pc.GetPlayerId();
		if (playerId <= 0)
			return;
		
		IEntity player = pc.GetControlledEntity();
		if (!player)
			return;
		
		// Retrouve la plante via son RplId
		IEntity plantEntity = null;
		RplComponent plantRpl = RplComponent.Cast(Replication.FindItem(plantRplId));
		if (plantRpl)
			plantEntity = plantRpl.GetEntity();
		
		EDrugType drugType = drugTypeInt;
		JobDrugSystem.ServerHarvestDrug(playerId, player, drugType, plantEntity);
	}
	
	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER: demande de spawn du vehicule de service (police/militaire)
	//------------------------------------------------------------------------------------------------
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_ServiceVehicle()
	{
		if (!Replication.IsServer())
			return;
		
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc)
			return;
		int playerId = pc.GetPlayerId();
		if (playerId <= 0)
			return;
		
		IEntity player = pc.GetControlledEntity();
		if (!player)
			return;
		
		JobPlayerData data = JobManager.GetInstance().GetPlayerData(playerId);
		if (!data)
			return;
		
		EJobType job = data.m_Job;
		
		// Validation: le metier doit avoir droit a un vehicule de service
		if (!JobData.HasServiceVehicle(job))
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[VEHICULE] Votre metier n'a pas de vehicule de service.");
			return;
		}
		
		ResourceName prefab = JobData.GetServiceVehiclePrefab(job);
		if (prefab == "")
			return;
		
		// === CHECK COOLDOWN VEHICULE 30 MIN ===
		// Verifie le cooldown AVANT le spawn pour ne pas spawn et payer si refus
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "")
			return;
		JobCooldownManager cdMgr = JobCooldownManager.GetInstance();
		int remaining = cdMgr.GetVehicleCooldownRemaining(uid);
		if (remaining > 0)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				string.Format("[VEHICULE] Cooldown actif - veuillez patienter %1 avant de reprendre votre vehicule de service.",
					JobCooldownManager.FormatRemaining(remaining)));
			return;
		}
		
		// Spawn a 10m devant le joueur (reutilise la methode existante)
		bool success = JobRpcHandler.SpawnVehicleAt10m(player, prefab, uid);
		
		if (success)
		{
			// Demarre le cooldown UNIQUEMENT si le spawn a reussi
			// (si le spawn echoue ex: pas d espace, on ne penalise pas le joueur)
			cdMgr.StartVehicleCooldown(uid);
			
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				string.Format("[VEHICULE] Vehicule de service %1 livre a 10m. Prochaine prise possible dans 30 minutes.",
					JobData.GetJobLabel(job)));
			Print(string.Format("[JobPlayerComponent] Vehicule service spawn: player=%1 job=%2",
				playerId, JobData.JobToString(job)), LogLevel.NORMAL);
		}
		else
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[VEHICULE] Echec du spawn. Trouvez un espace degage.");
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER: acceptation d'une quete
	//------------------------------------------------------------------------------------------------
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_AcceptQuest(int questTypeInt)
	{
		if (!Replication.IsServer())
			return;
		
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc)
			return;
		int playerId = pc.GetPlayerId();
		if (playerId <= 0)
			return;
		
		EQuestType questType = questTypeInt;
		JobQuestManager.GetInstance().StartQuest(playerId, questType);
	}
	
	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER: validation de la quete (retour au PNJ)
	//------------------------------------------------------------------------------------------------
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_TurnInQuest()
	{
		if (!Replication.IsServer())
			return;
		
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc)
			return;
		int playerId = pc.GetPlayerId();
		if (playerId <= 0)
			return;
		
		JobQuestManager.GetInstance().CompleteQuest(playerId);
	}
	
	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER: abandon de la quete
	//------------------------------------------------------------------------------------------------
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_AbandonQuest()
	{
		if (!Replication.IsServer())
			return;
		
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc)
			return;
		int playerId = pc.GetPlayerId();
		if (playerId <= 0)
			return;
		
		JobQuestManager.GetInstance().AbandonQuest(playerId);
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnDelete(IEntity owner)
	{
		if (Replication.IsServer())
		{
			PlayerController pc = PlayerController.Cast(owner);
			if (pc)
			{
				int playerId = pc.GetPlayerId();
				if (playerId > 0)
					JobManager.GetInstance().OnPlayerDisconnected(playerId);
			}
		}
		super.OnDelete(owner);
	}
	
	//------------------------------------------------------------------------------------------------
	// ============================================================
	// SYSTEME POLICE / JUSTICE (Police, Militaire, Concessionnaire)
	// ============================================================
	//------------------------------------------------------------------------------------------------
	
	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : Emettre une amende contre un joueur cible
	//------------------------------------------------------------------------------------------------
	void ClientAskIssueFine(int targetPlayerId, int fineLevel)
	{
		Rpc(RpcAsk_IssueFine, targetPlayerId, fineLevel);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_IssueFine(int targetPlayerId, int fineLevel)
	{
		if (!Replication.IsServer())
			return;
		
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc)
			return;
		int issuerId = pc.GetPlayerId();
		if (issuerId <= 0)
			return;
		
		// Verifier que l'emetteur est flic ou militaire
		JobPlayerData issuerData = JobManager.GetInstance().GetPlayerData(issuerId);
		if (!issuerData)
			return;
		if (issuerData.m_Job != EJobType.POLICIER && issuerData.m_Job != EJobType.MILITAIRE)
		{
			JobManager.GetInstance().NotifyPlayerChat(issuerId,
				"[JUSTICE] Vous n'avez pas l'autorite pour cela.");
			return;
		}
		
		// Recupere l'UID de la cible
		string targetUID = JobCriminalManager.GetUIDFromPlayerId(targetPlayerId);
		if (targetUID == "")
			return;
		string targetName = JobCriminalManager.GetPlayerNameById(targetPlayerId);
		string issuerName = JobCriminalManager.GetPlayerNameById(issuerId);
		
		EFineLevel level = fineLevel;
		if (JobCriminalManager.GetInstance().IssueFine(targetUID, targetName, level, issuerId, issuerName))
		{
			int amount = JobFineAmounts.GetAmount(level);
			JobManager.GetInstance().NotifyPlayerChat(issuerId,
				string.Format("[JUSTICE] Amende de niveau %1 emise contre %2 (%3 capsules)",
					fineLevel, targetName, amount));
			JobManager.GetInstance().NotifyPlayerChat(targetPlayerId,
				string.Format("[JUSTICE] Amende de %1 capsules. Payer a un agent dans les 10 minutes ou incarceration automatique.",
					amount));
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : Payer une amende au flic pres duquel on est
	//------------------------------------------------------------------------------------------------
	void ClientAskPayFine(int officerPlayerId)
	{
		Rpc(RpcAsk_PayFine, officerPlayerId);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_PayFine(int officerPlayerId)
	{
		if (!Replication.IsServer())
			return;
		
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc)
			return;
		int payerId = pc.GetPlayerId();
		if (payerId <= 0)
			return;
		
		string payerUID = JobCriminalManager.GetUIDFromPlayerId(payerId);
		if (payerUID == "")
			return;
		
		int amount = JobCriminalManager.GetInstance().GetDueFineAmount(payerUID, officerPlayerId);
		if (amount <= 0)
		{
			JobManager.GetInstance().NotifyPlayerChat(payerId,
				"[JUSTICE] Aucune amende impayee a regler a cet agent.");
			return;
		}
		
		// Verifier le solde
		string payerUid = JobManager.GetInstance().GetPersistentUID(payerId);
		CapsuleEconomyManager eco = CapsuleEconomyManager.GetInstance();
		if (!eco)
			return;
		int balance = eco.GetCapsules(payerUid);
		if (balance < amount)
		{
			JobManager.GetInstance().NotifyPlayerChat(payerId,
				string.Format("[JUSTICE] Solde insuffisant (%1 capsules, amende: %2)", balance, amount));
			return;
		}
		
		// Deduction + marquage paye
		eco.AddCapsules(payerUid, -amount);
		int newTotal = eco.GetCapsules(payerUid);
		
		// Sync HUD capsules
		CapsulePlayerComponent capsComp = CapsulePlayerComponent.Cast(
			pc.FindComponent(CapsulePlayerComponent));
		if (capsComp)
			capsComp.Svr_SendCapsules(newTotal);
		
		JobCriminalManager.GetInstance().MarkFinePaid(payerUID, officerPlayerId);
		
		JobManager.GetInstance().NotifyPlayerChat(payerId,
			string.Format("[JUSTICE] Amende de %1 capsules payee.", amount));
		JobManager.GetInstance().NotifyPlayerChat(officerPlayerId,
			string.Format("[JUSTICE] %1 a paye son amende (%2 capsules)",
				JobCriminalManager.GetPlayerNameById(payerId), amount));
	}
	
	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : Ajouter une mention manuelle au casier
	//------------------------------------------------------------------------------------------------
	void ClientAskAddMention(int targetPlayerId, string text)
	{
		Rpc(RpcAsk_AddMention, targetPlayerId, text);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_AddMention(int targetPlayerId, string text)
	{
		if (!Replication.IsServer())
			return;
		
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc)
			return;
		int issuerId = pc.GetPlayerId();
		if (issuerId <= 0)
			return;
		
		JobPlayerData issuerData = JobManager.GetInstance().GetPlayerData(issuerId);
		if (!issuerData)
			return;
		if (issuerData.m_Job != EJobType.POLICIER && issuerData.m_Job != EJobType.MILITAIRE)
			return;
		
		string targetUID = JobCriminalManager.GetUIDFromPlayerId(targetPlayerId);
		if (targetUID == "")
			return;
		string targetName = JobCriminalManager.GetPlayerNameById(targetPlayerId);
		string issuerName = JobCriminalManager.GetPlayerNameById(issuerId);
		
		JobCriminalManager.GetInstance().AddMention(targetUID, targetName, text, issuerName);
		JobManager.GetInstance().NotifyPlayerChat(issuerId,
			string.Format("[JUSTICE] Mention ajoutee au casier de %1", targetName));
	}
	
	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : Envoyer un joueur en prison
	// durationMinutes : duree de la peine en minutes (whitelist 15/30/50 verifiee cote serveur)
	//------------------------------------------------------------------------------------------------
	void ClientAskJailPlayer(int targetPlayerId, int durationMinutes)
	{
		Rpc(RpcAsk_JailPlayer, targetPlayerId, durationMinutes);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_JailPlayer(int targetPlayerId, int durationMinutes)
	{
		if (!Replication.IsServer())
			return;
		
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc)
			return;
		int issuerId = pc.GetPlayerId();
		if (issuerId <= 0)
			return;
		
		JobPlayerData issuerData = JobManager.GetInstance().GetPlayerData(issuerId);
		if (!issuerData)
			return;
		if (issuerData.m_Job != EJobType.POLICIER && issuerData.m_Job != EJobType.MILITAIRE)
			return;
		
		// Whitelist stricte de la duree : uniquement 15, 30 ou 50 minutes
		// Empeche tout cheat client qui enverrait 999999
		if (durationMinutes != 15 && durationMinutes != 30 && durationMinutes != 50)
		{
			JobManager.GetInstance().NotifyPlayerChat(issuerId,
				"[JUSTICE] Duree de peine invalide (autorisees : 15/30/50 min)");
			return;
		}
		
		string targetUID = JobCriminalManager.GetUIDFromPlayerId(targetPlayerId);
		if (targetUID == "")
			return;
		string targetName = JobCriminalManager.GetPlayerNameById(targetPlayerId);
		
		// Assure-toi que le record existe
		JobCriminalManager.GetInstance().GetOrCreateRecord(targetUID, targetName);
		JobCriminalManager.GetInstance().SendToPrison(targetUID, durationMinutes * 60);
		
		JobManager.GetInstance().NotifyPlayerChat(issuerId,
			string.Format("[JUSTICE] %1 a ete incarcere pour %2 minutes", targetName, durationMinutes.ToString()));
	}
	
	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : Envoyer un joueur en PRISON LONGUE (60/90/120 minutes)
	// Teleport aleatoire sur 1 des 5 points de la zone prison dediee.
	//------------------------------------------------------------------------------------------------
	void ClientAskImprisonPlayer(int targetPlayerId, int durationMinutes)
	{
		Rpc(RpcAsk_ImprisonPlayer, targetPlayerId, durationMinutes);
	}

	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_ImprisonPlayer(int targetPlayerId, int durationMinutes)
	{
		if (!Replication.IsServer())
			return;

		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc)
			return;
		int issuerId = pc.GetPlayerId();
		if (issuerId <= 0)
			return;

		JobPlayerData issuerData = JobManager.GetInstance().GetPlayerData(issuerId);
		if (!issuerData)
			return;
		if (issuerData.m_Job != EJobType.POLICIER && issuerData.m_Job != EJobType.MILITAIRE)
			return;

		// Whitelist stricte : uniquement 60, 90 ou 120 minutes
		if (durationMinutes != 60 && durationMinutes != 90 && durationMinutes != 120)
		{
			JobManager.GetInstance().NotifyPlayerChat(issuerId,
				"[JUSTICE] Duree de prison invalide (autorisees : 60/90/120 min)");
			return;
		}

		string targetUID = JobCriminalManager.GetUIDFromPlayerId(targetPlayerId);
		if (targetUID == "")
			return;
		string targetName = JobCriminalManager.GetPlayerNameById(targetPlayerId);

		JobCriminalManager.GetInstance().GetOrCreateRecord(targetUID, targetName);
		JobCriminalManager.GetInstance().SendToLongPrison(targetUID, durationMinutes * 60);

		JobManager.GetInstance().NotifyPlayerChat(issuerId,
			string.Format("[JUSTICE] %1 a ete envoye en prison pour %2 minutes", targetName, durationMinutes.ToString()));
	}

	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : Liberer un joueur de prison (action flic)
	//------------------------------------------------------------------------------------------------
	void ClientAskReleasePlayer(int targetPlayerId)
	{
		Rpc(RpcAsk_ReleasePlayer, targetPlayerId);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_ReleasePlayer(int targetPlayerId)
	{
		if (!Replication.IsServer())
			return;
		
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc)
			return;
		int issuerId = pc.GetPlayerId();
		if (issuerId <= 0)
			return;
		
		JobPlayerData issuerData = JobManager.GetInstance().GetPlayerData(issuerId);
		if (!issuerData)
			return;
		if (issuerData.m_Job != EJobType.POLICIER && issuerData.m_Job != EJobType.MILITAIRE)
			return;
		
		string targetUID = JobCriminalManager.GetUIDFromPlayerId(targetPlayerId);
		if (targetUID == "")
			return;
		string targetName = JobCriminalManager.GetPlayerNameById(targetPlayerId);
		
		JobCriminalManager.GetInstance().ReleaseFromPrison(targetUID, false);
		JobManager.GetInstance().NotifyPlayerChat(issuerId,
			string.Format("[JUSTICE] %1 a ete libere", targetName));
	}

	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : Verifier le proprietaire d un vehicule (action POLICIER / MILITAIRE)
	// Lit le composant LP_VehiclePersistComponent sur le vehicule cible et renvoie le nom RP
	// du proprietaire dans un hint HUD cote client.
	//------------------------------------------------------------------------------------------------
	void ClientAskCheckVehicleOwner(RplId vehicleRplId)
	{
		Rpc(RpcAsk_CheckVehicleOwner, vehicleRplId);
	}

	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_CheckVehicleOwner(RplId vehicleRplId)
	{
		if (!Replication.IsServer())
			return;

		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc)
			return;
		int issuerId = pc.GetPlayerId();
		if (issuerId <= 0)
			return;

		// Double check serveur : seuls POLICIER / MILITAIRE peuvent utiliser cette action
		JobPlayerData issuerData = JobManager.GetInstance().GetPlayerData(issuerId);
		if (!issuerData)
			return;
		if (issuerData.m_Job != EJobType.POLICIER && issuerData.m_Job != EJobType.MILITAIRE)
			return;

		// Recupere l entite du vehicule
		RplComponent rplComp = RplComponent.Cast(Replication.FindItem(vehicleRplId));
		if (!rplComp)
		{
			ServerShowHint("Vehicule introuvable.");
			return;
		}
		IEntity vehicle = rplComp.GetEntity();
		if (!vehicle)
		{
			ServerShowHint("Vehicule introuvable.");
			return;
		}

		// Lit le composant persist
		LP_VehiclePersistComponent comp = LP_VehiclePersistComponent.Cast(
			vehicle.FindComponent(LP_VehiclePersistComponent));
		if (!comp || !comp.IsRegistered())
		{
			ServerShowHint("Ce vehicule n a pas de proprietaire enregistre (vehicule libre).");
			return;
		}

		string ownerUID = comp.GetOwnerUID();
		if (ownerUID == "")
		{
			ServerShowHint("Ce vehicule n a pas de proprietaire enregistre (vehicule libre).");
			return;
		}

		// Cas special : vehicule confisque a la fourriere
		if (ownerUID == "FOURRIERE_SHARED")
		{
			ServerShowHint("Vehicule confisque a la fourriere.");
			return;
		}

		// Recupere le nom RP via JobIdentityManager
		JobRpIdentity id = JobIdentityManager.GetInstance().GetIdentity(ownerUID);
		string displayName;
		if (id && (id.m_FirstName != "" || id.m_LastName != ""))
			displayName = string.Format("%1 %2", id.m_FirstName, id.m_LastName);
		else
			displayName = "Inconnu (pas d identite RP)";

		ServerShowHint(string.Format("Proprietaire : %1", displayName));

		Print(string.Format("[JobPlayerComponent] CheckVehicleOwner par playerId=%1 : ownerUID=%2 name=%3",
			issuerId, ownerUID, displayName), LogLevel.NORMAL);
	}

	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : Retirer le permis de conduire
	//------------------------------------------------------------------------------------------------
	void ClientAskRevokeLicense(int targetPlayerId)
	{
		Rpc(RpcAsk_RevokeLicense, targetPlayerId);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_RevokeLicense(int targetPlayerId)
	{
		if (!Replication.IsServer())
			return;
		
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc)
			return;
		int issuerId = pc.GetPlayerId();
		if (issuerId <= 0)
			return;
		
		JobPlayerData issuerData = JobManager.GetInstance().GetPlayerData(issuerId);
		if (!issuerData)
			return;
		if (issuerData.m_Job != EJobType.POLICIER && issuerData.m_Job != EJobType.MILITAIRE)
			return;
		
		string targetUID = JobCriminalManager.GetUIDFromPlayerId(targetPlayerId);
		if (targetUID == "")
			return;
		string targetName = JobCriminalManager.GetPlayerNameById(targetPlayerId);
		
		JobCriminalManager.GetInstance().RevokeLicense(targetUID);
		JobManager.GetInstance().NotifyPlayerChat(issuerId,
			string.Format("[JUSTICE] Permis de conduire retire a %1", targetName));
		JobManager.GetInstance().NotifyPlayerChat(targetPlayerId,
			"[JUSTICE] Votre permis de conduire vous a ete retire");
		
		// Met a jour le HUD du joueur cible (logo permis : KO)
		PushHudFlagsForPlayerId(targetPlayerId);
	}
	
	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : Delivrer un permis (concessionnaire uniquement, paie 500 caps)
	//------------------------------------------------------------------------------------------------
	void ClientAskGrantLicense(int targetPlayerId)
	{
		Rpc(RpcAsk_GrantLicense, targetPlayerId);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_GrantLicense(int targetPlayerId)
	{
		if (!Replication.IsServer())
			return;
		
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc)
			return;
		int issuerId = pc.GetPlayerId();
		if (issuerId <= 0)
			return;
		
		JobPlayerData issuerData = JobManager.GetInstance().GetPlayerData(issuerId);
		if (!issuerData)
			return;
		if (issuerData.m_Job != EJobType.CONCESSIONNAIRE)
		{
			JobManager.GetInstance().NotifyPlayerChat(issuerId,
				"[JUSTICE] Seul le concessionnaire peut delivrer un permis.");
			return;
		}
		
		const int LICENSE_PRICE = 500;
		string issuerUid = JobManager.GetInstance().GetPersistentUID(issuerId);
		CapsuleEconomyManager eco = CapsuleEconomyManager.GetInstance();
		if (!eco)
			return;
		int issuerBalance = eco.GetCapsules(issuerUid);
		if (issuerBalance < LICENSE_PRICE)
		{
			JobManager.GetInstance().NotifyPlayerChat(issuerId,
				string.Format("[BOUTIQUE] Solde insuffisant pour delivrer le permis (%1 capsules requises)",
					LICENSE_PRICE));
			return;
		}
		
		string targetUID = JobCriminalManager.GetUIDFromPlayerId(targetPlayerId);
		if (targetUID == "")
			return;
		string targetName = JobCriminalManager.GetPlayerNameById(targetPlayerId);
		
		// Deduit le cout et delivre
		eco.AddCapsules(issuerUid, -LICENSE_PRICE);
		
		// Sync HUD capsules du concessionnaire
		CapsulePlayerComponent capsComp = CapsulePlayerComponent.Cast(
			pc.FindComponent(CapsulePlayerComponent));
		if (capsComp)
			capsComp.Svr_SendCapsules(eco.GetCapsules(issuerUid));
		
		JobCriminalManager.GetInstance().GrantLicense(targetUID, targetName);
		
		JobManager.GetInstance().NotifyPlayerChat(issuerId,
			string.Format("[BOUTIQUE] Permis delivre a %1 (-%2 capsules)", targetName, LICENSE_PRICE));
		JobManager.GetInstance().NotifyPlayerChat(targetPlayerId,
			"[JUSTICE] Vous avez obtenu le permis de conduire !");
		
		// Met a jour le HUD du joueur cible (logo permis : OK)
		PushHudFlagsForPlayerId(targetPlayerId);
	}
	
	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : Voler un joueur (tous metiers, cooldown 30min par couple)
	//------------------------------------------------------------------------------------------------
	void ClientAskRobPlayer(int targetPlayerId)
	{
		Rpc(RpcAsk_RobPlayer, targetPlayerId);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_RobPlayer(int targetPlayerId)
	{
		if (!Replication.IsServer())
			return;
		
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc)
			return;
		int robberId = pc.GetPlayerId();
		if (robberId <= 0 || robberId == targetPlayerId)
			return;
		
		string robberUID = JobCriminalManager.GetUIDFromPlayerId(robberId);
		string victimUID = JobCriminalManager.GetUIDFromPlayerId(targetPlayerId);
		if (robberUID == "" || victimUID == "")
			return;
		
		// SECURITE : verifier que la victime est bien inconsciente (evite exploit client)
		// API officielle : SCR_CharacterControllerComponent.IsUnconscious()
		IEntity victimEntity = GetGame().GetPlayerManager().GetPlayerControlledEntity(targetPlayerId);
		if (!victimEntity)
			return;
		SCR_CharacterControllerComponent victimCcc = SCR_CharacterControllerComponent.Cast(
			victimEntity.FindComponent(SCR_CharacterControllerComponent));
		if (!victimCcc || !victimCcc.IsUnconscious())
		{
			JobManager.GetInstance().NotifyPlayerChat(robberId,
				"[VOL] La cible doit etre inconsciente pour etre volee.");
			return;
		}
		
		// Cooldown - 0=OK, 1=voleur en cooldown, 2=victime en cooldown
		int canRobResult = JobCriminalManager.GetInstance().CanRob(robberUID, victimUID);
		if (canRobResult == 1)
		{
			int remaining = JobCriminalManager.GetInstance().GetRobberCooldownRemaining(robberUID);
			int minutes = remaining / 60;
			int seconds = remaining - (minutes * 60);
			JobManager.GetInstance().NotifyPlayerChat(robberId,
				string.Format("[VOL] Vous avez deja vole quelqu'un recemment. Reessayez dans %1m %2s.",
					minutes, seconds));
			return;
		}
		else if (canRobResult == 2)
		{
			JobManager.GetInstance().NotifyPlayerChat(robberId,
				"[VOL] Cette personne a deja ete volee recemment. Choisissez une autre cible.");
			return;
		}
		
		// Montant a voler
		CapsuleEconomyManager eco = CapsuleEconomyManager.GetInstance();
		if (!eco)
			return;
		
		int victimBalance = eco.GetCapsules(victimUID);
		if (victimBalance <= 0)
		{
			JobManager.GetInstance().NotifyPlayerChat(robberId,
				"[VOL] La cible n'a aucune capsule a voler");
			return;
		}
		
		int percent = Math.RandomIntInclusive(1, 3);
		int stolen = Math.Floor((victimBalance * percent) / 100.0);
		if (stolen < 1)
			stolen = 1;  // au moins 1 capsule
		if (stolen > victimBalance)
			stolen = victimBalance;
		
		// Transfert
		eco.AddCapsules(victimUID, -stolen);
		eco.AddCapsules(robberUID, stolen);
		
		// Sync HUD capsules des deux joueurs
		CapsulePlayerComponent robberCapsComp = CapsulePlayerComponent.Cast(
			pc.FindComponent(CapsulePlayerComponent));
		if (robberCapsComp)
			robberCapsComp.Svr_SendCapsules(eco.GetCapsules(robberUID));
		
		PlayerManager pm = GetGame().GetPlayerManager();
		if (pm)
		{
			PlayerController victimPC = pm.GetPlayerController(targetPlayerId);
			if (victimPC)
			{
				CapsulePlayerComponent victimCapsComp = CapsulePlayerComponent.Cast(
					victimPC.FindComponent(CapsulePlayerComponent));
				if (victimCapsComp)
					victimCapsComp.Svr_SendCapsules(eco.GetCapsules(victimUID));
			}
		}
		
		// Enregistre le cooldown
		JobCriminalManager.GetInstance().RecordRob(robberUID, victimUID);
		
		// Notifications - utilise l'identite RP si dispo, sinon le playername
		string robberDisplayName = JobIdentityManager.GetInstance().GetDisplayNameByPlayerId(robberId);
		string victimDisplayName = JobIdentityManager.GetInstance().GetDisplayNameByPlayerId(targetPlayerId);
		
		JobManager.GetInstance().NotifyPlayerChat(robberId,
			string.Format("[VOL] Vous avez vole %1 capsules a %2",
				stolen, victimDisplayName));
		JobManager.GetInstance().NotifyPlayerChat(targetPlayerId,
			string.Format("[VOL] Vous avez ete vole de %1 capsules par %2 !",
				stolen, robberDisplayName));
	}
	
	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : Verifier le permis d'un joueur (flic/militaire/concessionnaire)
	//------------------------------------------------------------------------------------------------
	void ClientAskCheckLicense(int targetPlayerId)
	{
		Rpc(RpcAsk_CheckLicense, targetPlayerId);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_CheckLicense(int targetPlayerId)
	{
		if (!Replication.IsServer())
			return;
		
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc)
			return;
		int issuerId = pc.GetPlayerId();
		if (issuerId <= 0)
			return;
		
		JobPlayerData issuerData = JobManager.GetInstance().GetPlayerData(issuerId);
		if (!issuerData)
			return;
		if (issuerData.m_Job != EJobType.POLICIER
			&& issuerData.m_Job != EJobType.MILITAIRE
			&& issuerData.m_Job != EJobType.CONCESSIONNAIRE)
			return;
		
		string targetUID = JobCriminalManager.GetUIDFromPlayerId(targetPlayerId);
		if (targetUID == "")
			return;
		string targetName = JobCriminalManager.GetPlayerNameById(targetPlayerId);
		
		bool hasLicense = JobCriminalManager.GetInstance().HasLicense(targetUID);
		string statusMsg;
		if (hasLicense)
			statusMsg = string.Format("[JUSTICE] %1 possede le permis de conduire.", targetName);
		else
			statusMsg = string.Format("[JUSTICE] %1 n'a PAS le permis de conduire.", targetName);
		
		JobManager.GetInstance().NotifyPlayerChat(issuerId, statusMsg);
	}
	
	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : Recuperer le casier d'un joueur (renvoie au client via RpcDo_ShowRecord)
	//------------------------------------------------------------------------------------------------
	void ClientAskCriminalRecord(int targetPlayerId)
	{
		Rpc(RpcAsk_CriminalRecord, targetPlayerId);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_CriminalRecord(int targetPlayerId)
	{
		if (!Replication.IsServer())
			return;
		
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc)
			return;
		int issuerId = pc.GetPlayerId();
		if (issuerId <= 0)
			return;
		
		JobPlayerData issuerData = JobManager.GetInstance().GetPlayerData(issuerId);
		if (!issuerData)
			return;
		if (issuerData.m_Job != EJobType.POLICIER && issuerData.m_Job != EJobType.MILITAIRE)
			return;
		
		string targetUID = JobCriminalManager.GetUIDFromPlayerId(targetPlayerId);
		if (targetUID == "")
		{
			JobManager.GetInstance().NotifyPlayerChat(issuerId,
				"[JUSTICE] Joueur introuvable.");
			return;
		}
		
		CriminalRecord rec = JobCriminalManager.GetInstance().GetRecord(targetUID);
		string targetName = JobCriminalManager.GetPlayerNameById(targetPlayerId);
		
		// Construit un resume texte (max 9 parametres de format.Format par appel)
		string summary;
		if (!rec || (rec.m_Fines.Count() == 0 && rec.m_Mentions.Count() == 0))
		{
			summary = string.Format("[CASIER] %1 - Aucun antecedent", targetName);
		}
		else
		{
			int unpaid = rec.GetUnpaidFineCount();
			int paid = rec.m_Fines.Count() - unpaid;
			int mentionCount = rec.m_Mentions.Count();
			summary = string.Format("[CASIER] %1 - Amendes: %2 (payees: %3, impayees: %4) - Mentions: %5",
				targetName, rec.m_Fines.Count(), paid, unpaid, mentionCount);
		}
		
		JobManager.GetInstance().NotifyPlayerChat(issuerId, summary);
		
		// Envoie aussi chaque mention en chat (limite a 5 pour ne pas spammer)
		if (rec && rec.m_Mentions.Count() > 0)
		{
			int maxMentions = rec.m_Mentions.Count();
			if (maxMentions > 5)
				maxMentions = 5;
			for (int i = 0; i < maxMentions; i++)
			{
				MentionRecord m = rec.m_Mentions.Get(i);
				if (!m) continue;
				JobManager.GetInstance().NotifyPlayerChat(issuerId,
					string.Format("[CASIER] Mention #%1 (par %2): %3",
						(i + 1).ToString(), m.m_IssuerName, m.m_Text));
			}
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// ============================================================
	// SYSTEME TELEPHONE / SOS
	// ============================================================
	//------------------------------------------------------------------------------------------------
	
	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : Passer un appel SOS d'un type donne
	//------------------------------------------------------------------------------------------------
	void ClientAskMakePhoneCall(int callType)
	{
		Rpc(RpcAsk_MakePhoneCall, callType);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_MakePhoneCall(int callType)
	{
		if (!Replication.IsServer())
			return;
		
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc)
			return;
		int callerId = pc.GetPlayerId();
		if (callerId <= 0)
			return;
		
		EPhoneCallType type = callType;
		if (type == EPhoneCallType.NONE)
			return;
		
		string callerUID = JobManager.GetInstance().GetPersistentUID(callerId);
		if (callerUID == "")
			return;
		
		// Verif cooldown
		if (!JobPhoneManager.GetInstance().CanCall(callerUID))
		{
			int remaining = JobPhoneManager.GetInstance().GetRemainingCooldown(callerUID);
			int minutes = remaining / 60;
			int seconds = remaining - (minutes * 60);
			JobManager.GetInstance().NotifyPlayerChat(callerId,
				string.Format("[TELEPHONE] Attendez avant de rappeler (%1m %2s).",
					minutes, seconds));
			return;
		}
		
		// Recupere la position de l'appelant
		PlayerManager pm = GetGame().GetPlayerManager();
		if (!pm)
			return;
		IEntity callerEntity = pm.GetPlayerControlledEntity(callerId);
		if (!callerEntity)
			return;
		vector callerPos = callerEntity.GetOrigin();
		string callerName = pm.GetPlayerName(callerId);
		if (callerName == "")
			callerName = "Joueur " + callerId.ToString();
		
		// Recupere le metier cible
		EJobType targetJob = JobPhoneData.GetTargetJob(type);
		if (targetJob == EJobType.NONE)
			return;
		
		// Enregistre le cooldown
		JobPhoneManager.GetInstance().RecordCall(callerUID);
		
		// Confirme l'appel a l'appelant
		JobManager.GetInstance().NotifyPlayerChat(callerId,
			string.Format("[TELEPHONE] %1 - Appel transmis.",
				JobPhoneData.GetAlertTitle(type)));
		
		// Broadcast l'alerte a tous les agents du metier cible
		array<int> allIds = new array<int>();
		pm.GetPlayers(allIds);
		int notifiedCount = 0;
		
		foreach (int agentId : allIds)
		{
			JobPlayerData agentData = JobManager.GetInstance().GetPlayerData(agentId);
			if (!agentData)
				continue;
			if (agentData.m_Job != targetJob)
				continue;
			
			PlayerController agentPc = pm.GetPlayerController(agentId);
			if (!agentPc)
				continue;
			
			JobPlayerComponent agentJpc = JobPlayerComponent.Cast(
				agentPc.FindComponent(JobPlayerComponent));
			if (!agentJpc)
				continue;
			
			// Envoie l'alerte ciblee au composant de l'agent (RplRcver.Owner = client owner)
			agentJpc.Rpc(agentJpc.RpcDo_ReceivePhoneAlert, callType, callerName,
				callerPos[0], callerPos[2]);
			notifiedCount++;
		}
		
		// Feedback a l'appelant si personne n'est dispo
		if (notifiedCount == 0)
		{
			JobManager.GetInstance().NotifyPlayerChat(callerId,
				string.Format("[TELEPHONE] Aucun agent %1 en service actuellement.",
					JobPhoneData.GetAlertTitle(type)));
			Print(string.Format("[JobPhoneManager] Appel %1 de %2 @ (%3, %4) -> AUCUN agent en service",
				JobPhoneData.GetAlertTitle(type), callerName, callerPos[0], callerPos[2]), LogLevel.NORMAL);
		}
		else
		{
			Print(string.Format("[JobPhoneManager] Appel %1 de %2 @ (%3, %4) -> %5 agent(s) alerte(s)",
				JobPhoneData.GetAlertTitle(type), callerName, callerPos[0], callerPos[2], notifiedCount), LogLevel.NORMAL);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// SERVER -> CLIENT (Owner = agent alerte) : affiche hint 15s + cree marker local 10 min
	//------------------------------------------------------------------------------------------------
	// Reference au marker SOS local (par agent) + timestamp pour l auto-remove
	ref SCR_MapMarkerBase m_SosMarker;
	int m_SosMarkerPlacedAt = 0;  // tick (ms) ou le marker a ete pose, 0 si pas de marker

	//------------------------------------------------------------------------------------------------
	// Resout le MapMarkerManagerComponent du GameMode. Methode robuste utilisee en priorite
	// car GetInstance() peut renvoyer null dans certains contextes (joueur fraichement connecte,
	// map pas encore ouverte). Fallback sur GetInstance() si FindComponent echoue.
	//------------------------------------------------------------------------------------------------
	SCR_MapMarkerManagerComponent GetMarkerMgrSafe()
	{
		SCR_MapMarkerManagerComponent markerMgr;
		BaseGameMode gm = GetGame().GetGameMode();
		if (gm)
			markerMgr = SCR_MapMarkerManagerComponent.Cast(gm.FindComponent(SCR_MapMarkerManagerComponent));
		if (!markerMgr)
			markerMgr = SCR_MapMarkerManagerComponent.GetInstance();
		return markerMgr;
	}

	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_ReceivePhoneAlert(int callType, string callerName, float posX, float posZ)
	{
		EPhoneCallType type = callType;
		string title = JobPhoneData.GetAlertTitle(type);
		string tag = JobPhoneData.GetAlertTag(type);

		// 1) Hint 15 secondes
		string hintMsg = string.Format("%1 Appel de %2", tag, callerName);
		LP_NotificationManager.Show(hintMsg, title, 15);

		// 2) Marker local sur la carte (auto-remove 10 min)
		SCR_MapMarkerManagerComponent markerMgr = GetMarkerMgrSafe();
		if (!markerMgr)
		{
			Print(string.Format("[JobPhoneComponent] WARNING : MapMarkerManager introuvable, pas de marker pour l appel %1 de %2 @ (%3, %4)",
				tag, callerName, posX, posZ), LogLevel.WARNING);
			return;
		}

		// Supprime l'ancien marker SOS s'il y en a un
		if (m_SosMarker)
		{
			markerMgr.RemoveStaticMarker(m_SosMarker);
			m_SosMarker = null;
		}

		m_SosMarker = new SCR_MapMarkerBase();
		m_SosMarker.SetType(SCR_EMapMarkerType.PLACED_CUSTOM);
		m_SosMarker.SetWorldPos(posX, posZ);
		m_SosMarker.SetCustomText(tag + " - " + callerName);
		m_SosMarker.SetColorEntry(2);  // rouge (palette index 0 dans Bohemia)
		markerMgr.InsertStaticMarker(m_SosMarker, true, true);

		// Enregistre le timestamp pour que TryRemoveSosMarker sache si le marker a ete remplace
		m_SosMarkerPlacedAt = System.GetTickCount();

		// Auto-remove au bout de 10 minutes
		GetGame().GetCallqueue().CallLater(TryRemoveSosMarker, 600000, false);

		Print(string.Format("[JobPhoneComponent] Alerte recue: %1 de %2 @ (%3, %4)",
			tag, callerName, posX, posZ), LogLevel.NORMAL);
	}

	//------------------------------------------------------------------------------------------------
	// Tente de retirer le marker SOS 10 min apres sa pose. Si un marker plus recent a ete pose
	// entre-temps (donc m_SosMarkerPlacedAt a ete mis a jour), on n agit pas : le CallLater
	// associe au nouveau marker se chargera de l expiration.
	//------------------------------------------------------------------------------------------------
	void TryRemoveSosMarker()
	{
		if (!m_SosMarker)
			return;
		int now = System.GetTickCount();
		int elapsed = now - m_SosMarkerPlacedAt;
		// Tolerance 500ms pour la precision du CallLater
		if (elapsed < 599500)
			return;  // Marker plus recent, laisser le CallLater associe au nouveau marker gerer

		SCR_MapMarkerManagerComponent markerMgr2 = GetMarkerMgrSafe();
		if (markerMgr2)
			markerMgr2.RemoveStaticMarker(m_SosMarker);
		m_SosMarker = null;
		m_SosMarkerPlacedAt = 0;
	}
	
	//------------------------------------------------------------------------------------------------
	// ============================================================
	// SYSTEME MINING / TRANSFORMATION / VENTE
	// ============================================================
	//------------------------------------------------------------------------------------------------
	
	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : Demarrer / reprendre une session de mining
	//------------------------------------------------------------------------------------------------
	void ClientAskStartMining(RplId prefabRplId, bool isTransform)
	{
		Rpc(RpcAsk_StartMining, prefabRplId, isTransform);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_StartMining(RplId prefabRplId, bool isTransform)
	{
		if (!Replication.IsServer())
			return;
		
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc)
			return;
		int playerId = pc.GetPlayerId();
		if (playerId <= 0)
			return;
		
		// Recupere le prefab via son RplId
		RplComponent prefabRpl = RplComponent.Cast(Replication.FindItem(prefabRplId));
		if (!prefabRpl)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[MINING] Prefab introuvable");
			return;
		}
		IEntity prefab = prefabRpl.GetEntity();
		if (!prefab)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[MINING] Prefab introuvable");
			return;
		}
		
		// Determine le type de minerai depuis le component approprie
		int mineralType = 0;
		if (isTransform)
		{
			JobTransformComponent tc = JobTransformComponent.Cast(prefab.FindComponent(JobTransformComponent));
			if (tc)
				mineralType = tc.GetMineralType();
		}
		else
		{
			JobMiningSourceComponent sc = JobMiningSourceComponent.Cast(prefab.FindComponent(JobMiningSourceComponent));
			if (sc)
				mineralType = sc.GetMineralType();
		}
		
		if (mineralType == 0)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[MINING] Type de ressource non configure sur ce prefab");
			return;
		}
		
		// Verifie distance
		IEntity character = pc.GetControlledEntity();
		if (!character)
			return;
		float dist = vector.Distance(character.GetOrigin(), prefab.GetOrigin());
		if (dist > JobMiningData.MAX_DISTANCE_METERS)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[MINING] Trop loin du prefab pour commencer");
			return;
		}
		
		// Demarre la session
		int result = JobMiningManager.GetInstance().StartSession(
			playerId, prefabRplId, mineralType, isTransform);
		
		if (result == 1)
		{
			// Recupere le metier requis pour un message clair
			EJobType requiredJob = JobMiningData.GetRequiredJob(mineralType);
			string requiredJobLabel = JobData.GetJobLabel(requiredJob);
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				string.Format("[MINING] Reserve au metier %1 : votre metier actuel ne peut pas extraire ici", requiredJobLabel));
		}
		else if (result == 2)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[MINING] Cette source est en cooldown - reessayez dans quelques minutes");
		}
		else if (result == 4)
		{
			string toolName = JobToolCheck.GetRequiredToolName(mineralType);
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				string.Format("[MINING] Vous avez besoin de %1 dans votre inventaire pour extraire ici", toolName));
		}
		else if (result == 0)
		{
			string verb;
			if (isTransform)
				verb = "Transformation";
			else
				verb = "Extraction";
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				string.Format("[MINING] %1 demarree - restez a moins de %2m du prefab",
					verb, Math.Floor(JobMiningData.MAX_DISTANCE_METERS)));
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : Vendre tous les minerais transformes d'un type donne
	//------------------------------------------------------------------------------------------------
	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : demande les cours actuels du marche
	// Le serveur repond via RpcDo_ReceiveMarketCours avec les 5 valeurs
	//------------------------------------------------------------------------------------------------
	void ClientAskMarketCours()
	{
		Rpc(RpcAsk_MarketCours);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_MarketCours()
	{
		if (!Replication.IsServer())
			return;
		JobMarketManager mgr = JobMarketManager.GetInstance();
		int rock     = mgr.GetCours(EMarketItem.ROCK);
		int wood     = mgr.GetCours(EMarketItem.WOOD);
		int apple    = mgr.GetCours(EMarketItem.APPLE);
		int cannabis = mgr.GetCours(EMarketItem.CANNABIS);
		int cocaine  = mgr.GetCours(EMarketItem.COCAINE);
		int wheat    = mgr.GetCours(EMarketItem.WHEAT);
		Rpc(RpcDo_ReceiveMarketCours, rock, wood, apple, cannabis, cocaine, wheat);
	}
	
	//------------------------------------------------------------------------------------------------
	// SERVER -> CLIENT (owner) : envoie les 6 cours actuels - le client met a jour son cache
	//------------------------------------------------------------------------------------------------
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_ReceiveMarketCours(int rock, int wood, int apple, int cannabis, int cocaine, int wheat)
	{
		// Met a jour le cache client du JobMarketManager pour que GetCours / GetEffectivePrice
		// renvoient les bonnes valeurs cote client (pour l affichage menu)
		JobMarketManager mgr = JobMarketManager.GetInstance();
		mgr.ClientSetCours(EMarketItem.ROCK, rock);
		mgr.ClientSetCours(EMarketItem.WOOD, wood);
		mgr.ClientSetCours(EMarketItem.APPLE, apple);
		mgr.ClientSetCours(EMarketItem.CANNABIS, cannabis);
		mgr.ClientSetCours(EMarketItem.COCAINE, cocaine);
		mgr.ClientSetCours(EMarketItem.WHEAT, wheat);
		
		// Notifie les menus ouverts pour qu ils rafraichissent leur affichage
		JobSellMineralsMenu sellMenu = JobSellMineralsMenu.GetOpenMenu();
		if (sellMenu)
			sellMenu.RefreshUI();
		
		JobDrugDealerMenu dealerMenu = JobDrugDealerMenu.GetOpenMenu();
		if (dealerMenu)
			dealerMenu.UpdateButtonLabels();
	}
	
	//------------------------------------------------------------------------------------------------
	void ClientAskSellMinerals(int mineralType)
	{
		Rpc(RpcAsk_SellMinerals, mineralType);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_SellMinerals(int mineralType)
	{
		if (!Replication.IsServer())
			return;
		
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc)
			return;
		int playerId = pc.GetPlayerId();
		if (playerId <= 0)
			return;
		IEntity character = pc.GetControlledEntity();
		if (!character)
			return;
		
		EMineralType type = mineralType;
		if (type == EMineralType.NONE)
			return;

		// === ANTI-CHEAT DROGUE : CONTROLE DE ZONE PAR GANG ===
		// Nouvelle regle : seul le GANG qui CONTROLE la zone correspondante peut vendre la drogue.
		//   - Cannabis : seul le gang controlant la zone cannabis peut vendre
		//   - Cocaine  : seul le gang controlant la zone cocaine peut vendre
		// Un VOYOU qui n est pas en gang ne peut plus vendre de drogue.
		if (type == EMineralType.CANNABIS || type == EMineralType.COCAINE)
		{
			string sellerUIDCheck = JobManager.GetInstance().GetPersistentUID(playerId);
			if (sellerUIDCheck == "")
			{
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[VENTE] Erreur d identification. Reessayez.");
				return;
			}

			// Verifie que le joueur est dans un gang
			JobGang sellerGang = JobGangManager.GetInstance().GetGangOfPlayer(sellerUIDCheck);
			if (!sellerGang)
			{
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[VENTE] Seuls les membres d un gang peuvent vendre de la drogue.");
				return;
			}

			// Verifie que le gang controle la zone correspondant a la drogue vendue
			EMarketItem drugMarketItem = JobMarketManager.FromMineralType(type);
			string controllingGang = JobGangManager.GetInstance().GetZoneController(drugMarketItem);

			string drugName = "cannabis";
			if (type == EMineralType.COCAINE) drugName = "cocaine";

			if (controllingGang == "")
			{
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					string.Format("[VENTE] Aucun gang ne controle la zone %1. Capturez-la pour pouvoir vendre.", drugName));
				return;
			}

			if (controllingGang != sellerGang.m_Name)
			{
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					string.Format("[VENTE] Votre gang ne controle pas la zone %1 (controlee par \"%2\"). Capturez-la pour vendre.",
						drugName, controllingGang));
				return;
			}
			// OK : le gang du vendeur controle bien la zone correspondante, on autorise la vente.
		}

		// Recupere le prefab des items transformes
		ResourceName itemPrefab = JobMiningData.GetItemPrefab(type, EMineralState.PROCESSED);

		// Compte combien le joueur a en stock
		int stock = JobMiningManager.CountItemsInInventory(character, itemPrefab);
		if (stock <= 0)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[VENTE] Vous n'avez aucun minerai transforme a vendre");
			return;
		}
		
		// Retire les items et calcule la somme
		int removed = JobMiningManager.RemoveItemsFromInventory(character, itemPrefab, stock);
		if (removed <= 0)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[VENTE] Erreur lors du retrait des items");
			return;
		}
		
		int unitPrice = JobMiningData.GetSellPrice(type);
		
		// Applique le cours dynamique (JobMarketManager) au prix unitaire
		EMarketItem marketItem = JobMarketManager.FromMineralType(type);
		if (marketItem != EMarketItem.NONE)
		{
			unitPrice = JobMarketManager.GetInstance().GetEffectivePrice(marketItem, unitPrice);
		}
		
		// === BONUS PATRON +50% ===
		// Si le vendeur est patron d une entreprise du metier correspondant
		// (MINEUR/AGRICULTEUR/BUCHERON), il touche +50% sur le prix unitaire.
		// Note : les drogues (CANNABIS/COCAINE) ne sont PAS concernees (pas d entreprise legale).
		string sellerUID = JobManager.GetInstance().GetPersistentUID(playerId);
		bool isBossBonus = false;
		if (sellerUID != "")
		{
			JobCompany ownerCompany = JobCompanyManager.GetInstance().GetCompanyOwnedBy(sellerUID);
			if (ownerCompany)
			{
				EJobType companyJob = ownerCompany.m_JobType;
				bool jobMatches = false;
				if (type == EMineralType.ROCK && companyJob == EJobType.MINEUR)
					jobMatches = true;
				else if (type == EMineralType.WOOD && companyJob == EJobType.BUCHERON)
					jobMatches = true;
				else if (type == EMineralType.APPLE && companyJob == EJobType.AGRICULTEUR)
					jobMatches = true;
				else if (type == EMineralType.WHEAT && companyJob == EJobType.AGRICULTEUR)
					jobMatches = true;
				
				if (jobMatches)
				{
					unitPrice = unitPrice * 3 / 2;  // +50% (arrondi inferieur)
					isBossBonus = true;
					
					// === MINIMUM GARANTI PATRON ===
					// Filet de securite : le patron touche AU MOINS ces valeurs par unite,
					// meme si le marche + bonus +50% donne moins.
					// - APPLE (jus de pomme)   : 22 min
					// - WHEAT (sac de farine)  : 22 min
					// - WOOD (planches)         : 26 min
					// - ROCK (roche transformee): 26 min
					int minPrice = 0;
					if (type == EMineralType.APPLE)      minPrice = 22;
					else if (type == EMineralType.WHEAT) minPrice = 22;
					else if (type == EMineralType.WOOD)  minPrice = 26;
					else if (type == EMineralType.ROCK)  minPrice = 26;
					if (unitPrice < minPrice)
						unitPrice = minPrice;
				}
			}
		}
		
		int total = removed * unitPrice;
		
		// Recupere le UID pour eviter de re-resoudre + check si UID different du sellerUID precedent
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		CapsuleEconomyManager eco = CapsuleEconomyManager.GetInstance();
		if (!eco || uid == "")
			return;
		eco.AddCapsules(uid, total);
		
		// Sync HUD capsules
		CapsulePlayerComponent capsComp = CapsulePlayerComponent.Cast(
			pc.FindComponent(CapsulePlayerComponent));
		if (capsComp)
			capsComp.Svr_SendCapsules(eco.GetCapsules(uid));
		
		// Enregistre la vente -> -1% sur le cours (une fois par appel, peu importe la quantite vendue)
		// (Note : si tu veux une baisse par unite vendue, multiplier par "removed" - mais ca pourrait crasher le marche d un coup)
		if (marketItem != EMarketItem.NONE)
			JobMarketManager.GetInstance().RecordSale(marketItem);
		
		// === TAXE GANG : si un gang controle la zone de cette drogue, il touche 5% ===
		if (marketItem != EMarketItem.NONE)
		{
			int tax = JobGangManager.GetInstance().ApplyTaxOnSale(marketItem, total);
			if (tax > 0)
			{
				string gangName = JobGangManager.GetInstance().GetZoneController(marketItem);
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					string.Format("[GANG] %1 capsules de taxe (5%%) versees au gang %2 qui controle cette zone.",
						tax, gangName));
			}
		}
		
		string label = JobMiningData.GetMineralLabel(type, EMineralState.PROCESSED);
		if (isBossBonus)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				string.Format("[VENTE] %1 unites de %2 vendues : +%3 capsules (bonus patron +50%%)",
					removed, label, total));
		}
		else
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				string.Format("[VENTE] %1 unites de %2 vendues : +%3 capsules",
					removed, label, total));
		}
		
		// --- STATS RP : incremente le compteur correspondant ---
		JobPlayerData stats = JobManager.GetInstance().GetPlayerData(playerId);
		if (stats)
		{
			switch (type)
			{
				case EMineralType.WOOD:
					stats.m_PlanksSold = stats.m_PlanksSold + removed;
					break;
				case EMineralType.APPLE:
					stats.m_JuiceSold = stats.m_JuiceSold + removed;
					break;
				case EMineralType.WHEAT:
					// Reutilise le compteur agriculteur (jus + farine = productions agricoles)
					stats.m_JuiceSold = stats.m_JuiceSold + removed;
					break;
				case EMineralType.ROCK:
					stats.m_RocksSold = stats.m_RocksSold + removed;
					break;
				case EMineralType.CANNABIS:
				case EMineralType.COCAINE:
					stats.m_DrugsSold = stats.m_DrugsSold + removed;
					break;
			}
			JobManager.GetInstance().SavePlayerData(playerId);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// ============================================================
	// SYSTEME MAIRE - RECOMPENSE DE DEBUT (one-shot par UID)
	// ============================================================
	//------------------------------------------------------------------------------------------------
	
	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : Demande la recompense de debut
	//------------------------------------------------------------------------------------------------
	void ClientAskMayorReward()
	{
		Rpc(RpcAsk_MayorReward);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_MayorReward()
	{
		if (!Replication.IsServer())
			return;
		
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc)
			return;
		int playerId = pc.GetPlayerId();
		if (playerId <= 0)
			return;
		
		// Recupere l UID Bohemia persistant du joueur
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "")
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[MAIRE] Erreur: identifiant joueur introuvable");
			return;
		}
		
		// Verifie si le joueur a deja recu la recompense
		if (JobMayorManager.GetInstance().HasReceivedReward(uid))
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[MAIRE] Vous avez deja recu votre recompense de debut. Une seule fois par joueur !");
			return;
		}
		
		// Credit les capsules
		CapsuleEconomyManager eco = CapsuleEconomyManager.GetInstance();
		if (!eco)
			return;
		int amount = JobMayorManager.START_REWARD_AMOUNT;
		eco.AddCapsules(uid, amount);
		
		// Sync HUD capsules
		CapsulePlayerComponent capsComp = CapsulePlayerComponent.Cast(
			pc.FindComponent(CapsulePlayerComponent));
		if (capsComp)
			capsComp.Svr_SendCapsules(eco.GetCapsules(uid));
		
		// Marque comme recu (persistant JSON)
		JobMayorManager.GetInstance().MarkRewardReceived(uid);
		
		JobManager.GetInstance().NotifyPlayerChat(playerId,
			string.Format("[MAIRE] Bienvenue ! Vous recevez %1 capsules de la part du Maire. Bonne continuation sur Les Pacifistes !",
				amount));
	}
	
	//------------------------------------------------------------------------------------------------
	// ============================================================
	// SYSTEME IDENTITE ROLEPLAY (creation one-shot par UID)
	// ============================================================
	//------------------------------------------------------------------------------------------------
	
	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : Cree l'identite roleplay du joueur
	//------------------------------------------------------------------------------------------------
	void ClientAskCreateIdentity(string firstName, string lastName, string birthDate)
	{
		Rpc(RpcAsk_CreateIdentity, firstName, lastName, birthDate);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_CreateIdentity(string firstName, string lastName, string birthDate)
	{
		if (!Replication.IsServer())
			return;
		
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc)
			return;
		int playerId = pc.GetPlayerId();
		if (playerId <= 0)
			return;
		
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "")
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[IDENTITE] Erreur: identifiant joueur introuvable");
			return;
		}
		
		// Verifie si le joueur a deja une identite
		if (JobIdentityManager.GetInstance().HasIdentity(uid))
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[IDENTITE] Vous avez deja une identite roleplay enregistree. Impossible de la modifier.");
			return;
		}
		
		// Validation cote serveur (defense en profondeur)
		if (firstName == "" || lastName == "" || birthDate == "")
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[IDENTITE] Tous les champs doivent etre remplis");
			return;
		}
		
		// Cree l'identite (le manager gere la validation et la sauvegarde)
		bool ok = JobIdentityManager.GetInstance().CreateIdentity(uid, firstName, lastName, birthDate);
		if (!ok)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[IDENTITE] Erreur lors de la creation de l'identite");
			return;
		}
		
		JobManager.GetInstance().NotifyPlayerChat(playerId,
			string.Format("[IDENTITE] Bienvenue %1 %2 ! Votre identite roleplay est enregistree.",
				firstName, lastName));
		
		// Met a jour le HUD client (logo identite : OK)
		Svr_PushHudFlags();
		
		// Broadcast l'identite a tous les clients pour mise a jour de leur cache local
		// (utilise notamment par l ATM pour afficher Nom Prenom au lieu de playername)
		string displayName = firstName + " " + lastName;
		BroadcastIdentityToAllPlayers(playerId, displayName);
	}
	
	//------------------------------------------------------------------------------------------------
	// SERVEUR : Broadcast une identite a tous les clients connectes
	//------------------------------------------------------------------------------------------------
	static void BroadcastIdentityToAllPlayers(int targetPlayerId, string displayName)
	{
		if (!Replication.IsServer())
			return;
		PlayerManager pm = GetGame().GetPlayerManager();
		if (!pm)
			return;
		array<int> allPlayers = new array<int>();
		pm.GetPlayers(allPlayers);
		foreach (int pid : allPlayers)
		{
			PlayerController pc = pm.GetPlayerController(pid);
			if (!pc)
				continue;
			JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
			if (jpc)
				jpc.PushIdentityToOwner(targetPlayerId, displayName);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// SERVEUR : Push une identite au client owner (utilise par BroadcastIdentityToAllPlayers
	// et lors de la connexion d un client pour lui synchroniser tout l etat)
	//------------------------------------------------------------------------------------------------
	void PushIdentityToOwner(int targetPlayerId, string displayName)
	{
		if (!Replication.IsServer())
			return;
		Rpc(RpcDo_ReceiveIdentity, targetPlayerId, displayName);
	}
	
	//------------------------------------------------------------------------------------------------
	// CLIENT : Recoit une identite depuis le serveur, met a jour son cache local
	//------------------------------------------------------------------------------------------------
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_ReceiveIdentity(int targetPlayerId, string displayName)
	{
		JobIdentityManager.GetInstance().Client_SetIdentityForPlayer(targetPlayerId, displayName);
	}
	
	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : Demande au serveur l'identite RP d'une cible (controle police/militaire)
	// Le serveur repond via RpcDo_ShowIdentityHint sur le client demandeur (l'agent)
	//------------------------------------------------------------------------------------------------
	void ClientAskControlIdentity(int targetPlayerId)
	{
		Rpc(RpcAsk_ControlIdentity, targetPlayerId);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_ControlIdentity(int targetPlayerId)
	{
		if (!Replication.IsServer())
			return;
		
		// Recupere l UID de la cible
		string targetUID = JobManager.GetInstance().GetPersistentUID(targetPlayerId);
		string hintMsg = "";
		
		// Si le joueur n a pas d identite RP enregistree -> Citoyen sans papier
		if (!JobIdentityManager.GetInstance().HasIdentity(targetUID))
		{
			hintMsg = "Citoyen sans papier !";
		}
		else
		{
			JobRpIdentity id = JobIdentityManager.GetInstance().GetIdentity(targetUID);
			if (id)
			{
				hintMsg = string.Format("Nom: %1\nPrenom: %2\nNe le: %3",
					id.m_LastName, id.m_FirstName, id.m_BirthDate);
			}
			else
			{
				hintMsg = "Citoyen sans papier !";
			}
		}
		
		// Renvoie le hint a l agent qui a demande
		Rpc(RpcDo_ShowIdentityHint, hintMsg);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_ShowIdentityHint(string hintMsg)
	{
		LP_NotificationManager.Show(
			hintMsg,
			"Controle d'identite",
			6);
	}
	
	//------------------------------------------------------------------------------------------------
	// ============================================================
	// SYNCHRO ETAT HUD (permis + identite) - SERVEUR -> CLIENT
	// ============================================================
	//------------------------------------------------------------------------------------------------
	
	//------------------------------------------------------------------------------------------------
	// SERVEUR : pousse l'etat actuel vers le client owner pour mettre a jour les logos HUD.
	// A appeler apres : connexion, creation identite, attribution/retrait permis.
	//------------------------------------------------------------------------------------------------
	void Svr_PushHudFlags()
	{
		if (!Replication.IsServer())
			return;
		
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc)
			return;
		int playerId = pc.GetPlayerId();
		if (playerId <= 0)
			return;
		
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "")
			return;
		
		// Verif permis (via JobCriminalManager)
		bool hasLicense = false;
		CriminalRecord rec = JobCriminalManager.GetInstance().GetRecord(uid);
		if (rec)
			hasLicense = rec.m_HasDrivingLicense;
		
		// Verif identite RP
		bool hasIdentity = JobIdentityManager.GetInstance().HasIdentity(uid);
		
		Rpc(RpcDo_SetHudFlags, hasLicense, hasIdentity);
	}
	
	//------------------------------------------------------------------------------------------------
	// CLIENT : recoit l'etat depuis le serveur, met a jour les logos
	//------------------------------------------------------------------------------------------------
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_SetHudFlags(bool hasLicense, bool hasIdentity)
	{
		m_ClientHasLicense = hasLicense;
		m_ClientHasIdentity = hasIdentity;
		UpdateLogos();
	}
	
	//------------------------------------------------------------------------------------------------
	// SERVEUR : helper static pour pusher les flags HUD a un joueur cible (par playerId).
	// Utilise quand on modifie l'etat d'un autre joueur (delivrance/retrait permis).
	//------------------------------------------------------------------------------------------------
	static void PushHudFlagsForPlayerId(int playerId)
	{
		if (!Replication.IsServer())
			return;
		PlayerManager pm = GetGame().GetPlayerManager();
		if (!pm)
			return;
		PlayerController pc = pm.GetPlayerController(playerId);
		if (!pc)
			return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (jpc)
			jpc.Svr_PushHudFlags();
	}
	
	//------------------------------------------------------------------------------------------------
	// ============================================================
	// SYSTEME LOCATION DE VEHICULE
	// ============================================================
	//------------------------------------------------------------------------------------------------
	
	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : Demande la location d'un vehicule
	//------------------------------------------------------------------------------------------------
	void ClientAskRentVehicle(int vehicleType, int hours)
	{
		Rpc(RpcAsk_RentVehicle, vehicleType, hours);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_RentVehicle(int vehicleType, int hours)
	{
		if (!Replication.IsServer())
			return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc)
			return;
		int playerId = pc.GetPlayerId();
		if (playerId <= 0)
			return;
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "")
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[LOCATION] Erreur: identifiant joueur introuvable");
			return;
		}
		
		int result = JobVehicleRentalManager.GetInstance().StartRental(playerId, uid, vehicleType, hours);
		switch (result)
		{
			case 0:
				// OK, message deja envoye par StartRental
				break;
			case 1:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[LOCATION] Vous avez deja un vehicule en location. Rendez-le d'abord !");
				break;
			case 2:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[LOCATION] Capsules insuffisantes pour cette location.");
				break;
			case 3:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[LOCATION] Erreur lors du spawn du vehicule. Reessayez.");
				break;
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : Demande le retour de son vehicule
	//------------------------------------------------------------------------------------------------
	void ClientAskReturnVehicle()
	{
		Rpc(RpcAsk_ReturnVehicle);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_ReturnVehicle()
	{
		if (!Replication.IsServer())
			return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc)
			return;
		int playerId = pc.GetPlayerId();
		if (playerId <= 0)
			return;
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "")
			return;
		
		int result = JobVehicleRentalManager.GetInstance().TryReturnVehicle(playerId, uid);
		switch (result)
		{
			case 0:
				// OK, message deja envoye
				break;
			case 1:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[LOCATION] Vous n'avez aucun vehicule en location.");
				break;
			case 2:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[LOCATION] Le vehicule est trop loin de la zone de retour. Approchez-vous.");
				break;
			case 3:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[LOCATION] Sortez du vehicule avant de le rendre.");
				break;
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// ============================================================
	// SYSTEME FICHE RP
	// ============================================================
	//------------------------------------------------------------------------------------------------
	
	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : demande les donnees agregees pour la fiche RP
	//------------------------------------------------------------------------------------------------
	void ClientAskFicheData()
	{
		Rpc(RpcAsk_FicheData);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_FicheData()
	{
		if (!Replication.IsServer())
			return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc)
			return;
		int playerId = pc.GetPlayerId();
		if (playerId <= 0)
			return;
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "")
			return;
		
		// Agrege toutes les donnees
		string formatted = BuildFicheString(playerId, uid);
		
		// Renvoie au client owner
		Rpc(RpcDo_ReceiveFicheData, formatted);
	}
	
	//------------------------------------------------------------------------------------------------
	// SERVER : assemble la chaine de la fiche RP du joueur
	//------------------------------------------------------------------------------------------------
	string BuildFicheString(int playerId, string uid)
	{
		// --- IDENTITE ---
		JobRpIdentity id = JobIdentityManager.GetInstance().GetIdentity(uid);
		string firstName = "Non renseigne";
		string lastName = "Non renseigne";
		string birthDate = "Non renseignee";
		bool hasIdentity = false;
		string anciennete = "0 jour";
		if (id)
		{
			firstName = id.m_FirstName;
			lastName = id.m_LastName;
			birthDate = id.m_BirthDate;
			hasIdentity = true;
		}
		
		// --- ETAT JOUEUR ---
		JobPlayerData stats = JobManager.GetInstance().GetPlayerData(playerId);
		EJobType job = EJobType.NONE;
		bool hasLicense = false;
		int firstSeen = 0;
		if (stats)
		{
			job = stats.m_Job;
			firstSeen = stats.m_FirstSeenUnix;
		}
		
		// Permis : lu depuis JobCriminalManager
		hasLicense = JobCriminalManager.GetInstance().HasLicense(uid);
		
		// Anciennete RP en jours
		if (firstSeen > 0)
		{
			int now = System.GetUnixTime();
			int days = (now - firstSeen) / 86400;
			if (days <= 0)
				anciennete = "Aujourd'hui";
			else if (days == 1)
				anciennete = "1 jour";
			else
				anciennete = days.ToString() + " jours";
		}
		
		// --- CAPSULES (argent sur soi) ---
		CapsuleEconomyManager eco = CapsuleEconomyManager.GetInstance();
		int capsules = 0;
		if (eco)
			capsules = eco.GetCapsules(uid);

		// --- BANQUE ---
		int bankBalance = 0;
		JobBankManager bank = JobBankManager.GetInstance();
		if (bank)
			bankBalance = bank.GetBalance(uid);

		// NOTE: Soif / Faim ne sont PAS lues ici. Elles sont injectees cote client depuis
		// SurvivalHUDManager.GetInstance() qui est l API deja utilisee par le HUD du joueur.
		// Voir JobRpFicheMenu.BuildPersonnageCards.

		// --- CASIER JUDICIAIRE ---
		int unpaidFines = 0;
		int totalUnpaidAmount = 0;
		int mentionsCount = 0;
		bool inPrison = false;
		CriminalRecord cr = JobCriminalManager.GetInstance().GetRecord(uid);
		if (cr)
		{
			foreach (FineRecord f : cr.m_Fines)
			{
				if (f && !f.m_Paid)
				{
					unpaidFines++;
					totalUnpaidAmount = totalUnpaidAmount + f.m_Amount;
				}
			}
			if (cr.m_Mentions)
				mentionsCount = cr.m_Mentions.Count();
			inPrison = cr.m_InPrison;
		}
		
		// --- STATS RP ---
		int planks = 0, juice = 0, rocks = 0, drugs = 0, jailed = 0, infractions = 0, quests = 0;
		if (stats)
		{
			planks = stats.m_PlanksSold;
			juice = stats.m_JuiceSold;
			rocks = stats.m_RocksSold;
			drugs = stats.m_DrugsSold;
			jailed = stats.m_TimesJailed;
			infractions = stats.m_TotalInfractions;
			quests = stats.m_QuestsCompleted;
		}
		
		// --- FORMATAGE ---
		// On utilise des sauts de ligne pour separer les sections.
		// Le widget RichTextWidget aurait permis le HTML mais on reste sur TextWidget classique.
		string yesNo;
		string licenseStr;
		string identityStr;
		if (hasLicense) licenseStr = "OUI"; else licenseStr = "NON";
		if (hasIdentity) identityStr = "OUI"; else identityStr = "NON";
		
		string prisonStr = "";
		if (inPrison)
			prisonStr = " (EN PRISON)";
		
		string s = "";

		// --- IDENTITE (wrappee dans une section pour que le client la route sur la carte Identite) ---
		s = s + "--- IDENTITE ---\n";
		s = s + string.Format("Nom               : %1\n", lastName);
		s = s + string.Format("Prenom            : %1\n", firstName);
		s = s + string.Format("Date de naissance : %1\n", birthDate);
		s = s + string.Format("Anciennete RP     : %1", anciennete);
		s = s + "\n\n";

		// --- ETAT (statut documents + metier) ---
		s = s + "--- ETAT ---\n";
		s = s + string.Format("Identite          : %1\n", identityStr);
		s = s + string.Format("Permis conduire   : %1\n", licenseStr);
		s = s + string.Format("Metier            : %1%2", JobData.GetJobLabel(job), prisonStr);
		s = s + "\n\n";

		// --- FINANCES (nouvelle section dediee, affichee sur la page Mes finances) ---
		s = s + "--- FINANCES ---\n";
		s = s + "Argent en espece (sur soi) : " + capsules.ToString() + " caps\n";
		s = s + "Argent en banque           : " + bankBalance.ToString() + " caps\n";
		s = s + "Amendes impayees           : " + unpaidFines.ToString() + " (" + totalUnpaidAmount.ToString() + " caps)";
		s = s + "\n\n";

		// --- CASIER JUDICIAIRE (sans permis - deja dans ETAT; avec detail des mentions) ---
		s = s + "--- CASIER JUDICIAIRE ---\n";
		string prisonLineStr = "Non";
		if (inPrison) prisonLineStr = "OUI (actuellement incarcere)";
		s = s + "Prison            : " + prisonLineStr + "\n";
		s = s + "Mentions          : " + mentionsCount.ToString();
		if (mentionsCount > 0 && cr && cr.m_Mentions)
		{
			s = s + "\n\nDetails des mentions :";
			int mc = cr.m_Mentions.Count();
			for (int mi = 0; mi < mc; mi++)
			{
				MentionRecord m = cr.m_Mentions.Get(mi);
				if (!m) continue;
				string issuer = m.m_IssuerName;
				if (issuer == "") issuer = "Inconnu";
				string whenStr = "date ?";
				if (m.m_Timestamp > 0)
					whenStr = FicheFormatUnixDate(m.m_Timestamp);
				s = s + "\n> " + whenStr + " - " + issuer + " : " + m.m_Text;
			}
		}
		s = s + "\n\n";

		// --- STATISTIQUES (route cote client vers une carte en bas de Mon personnage) ---
		s = s + "--- STATISTIQUES ---\n";
		s = s + string.Format("Quetes terminees  : %1\n", quests);
		s = s + string.Format("Planches vendues  : %1\n", planks);
		s = s + string.Format("Jus vendus        : %1\n", juice);
		s = s + string.Format("Roches vendues    : %1\n", rocks);
		s = s + string.Format("Drogues vendues   : %1\n", drugs);
		s = s + string.Format("Fois en prison    : %1\n", jailed);
		s = s + string.Format("Total infractions : %1", infractions);
		s = s + "\n\n";

		// --- GANG ---
		JobGang myGang = JobGangManager.GetInstance().GetGangOfPlayer(uid);
		s = s + "--- GANG ---\n";
		if (!myGang)
		{
			s = s + "Aucun gang";
		}
		else
		{
			string roleLabel = "Membre";
			if (myGang.IsChef(uid)) roleLabel = "Chef";
			int memberTotal = myGang.m_Members.Count() + 1;
			s = s + string.Format("Nom du gang : %1\n", myGang.m_Name);
			s = s + string.Format("Statut      : %1\n", roleLabel);
			s = s + string.Format("Effectif    : %1 membre(s) (chef inclus)", memberTotal);
		}
		s = s + "\n\n";

		// --- BOURSE (va dans la carte AUTRES INFORMATIONS cote client) ---
		JobMarketManager market = JobMarketManager.GetInstance();
		int courseRock     = market.GetCours(EMarketItem.ROCK);
		int courseWood     = market.GetCours(EMarketItem.WOOD);
		int courseApple    = market.GetCours(EMarketItem.APPLE);
		int courseCannabis = market.GetCours(EMarketItem.CANNABIS);
		int courseCocaine  = market.GetCours(EMarketItem.COCAINE);
		int courseWheat    = market.GetCours(EMarketItem.WHEAT);
		s = s + "--- BOURSE ---\n";
		s = s + string.Format("Pierre        : %1\n", FormatCoursForFiche(courseRock));
		s = s + string.Format("Planche       : %1\n", FormatCoursForFiche(courseWood));
		s = s + string.Format("Jus de pomme  : %1\n", FormatCoursForFiche(courseApple));
		s = s + string.Format("Sac de farine : %1\n", FormatCoursForFiche(courseWheat));
		s = s + string.Format("Cannabis      : %1\n", FormatCoursForFiche(courseCannabis));
		s = s + string.Format("Cocaine       : %1", FormatCoursForFiche(courseCocaine));

		return s;
	}

	//------------------------------------------------------------------------------------------------
	// Helper local pour la fiche RP : formate un timestamp Unix en date lisible relative.
	// On ne reutilise pas FormatUnixDate() (protected, dans une autre extension modded) pour
	// eviter les soucis de visibilite inter-modded-extensions.
	//------------------------------------------------------------------------------------------------
	string FicheFormatUnixDate(int unixTime)
	{
		if (unixTime <= 0) return "-";
		// Valeur suspecte : moins de 1e9 = pas un Unix time valide (ancien bug JobTimeUtils.GetNow stocke
		// comme world time, resettait a chaque reboot). On evite d afficher "56 ans" sur ces donnees legacy.
		if (unixTime < 1000000000) return "date inconnue";
		int now = System.GetUnixTime();
		int diff = now - unixTime;
		if (diff < 0) return "recent";
		int days = diff / 86400;
		if (days == 0) return "aujourd hui";
		if (days == 1) return "hier";
		if (days < 7) return "il y a " + days.ToString() + " jours";
		if (days < 30)
		{
			int weeks = days / 7;
			if (weeks == 1) return "il y a 1 semaine";
			return "il y a " + weeks.ToString() + " semaines";
		}
		if (days < 365)
		{
			int months = days / 30;
			if (months == 1) return "il y a 1 mois";
			return "il y a " + months.ToString() + " mois";
		}
		int years = days / 365;
		if (years == 1) return "il y a 1 an";
		return "il y a " + years.ToString() + " ans";
	}
	
	//------------------------------------------------------------------------------------------------
	// Helper : formate un cours en % avec une fleche de tendance (pour la fiche RP)
	//------------------------------------------------------------------------------------------------
	string FormatCoursForFiche(int cours)
	{
		if (cours == 0)
			return "0% (stable)";
		if (cours > 0)
			return string.Format("+%1%% (hausse)", cours);
		// Le moins est deja dans le nombre
		return string.Format("%1%% (baisse)", cours);
	}
	
	//------------------------------------------------------------------------------------------------
	// SERVER -> CLIENT (owner) : envoie la fiche formatee au menu ouvert
	//------------------------------------------------------------------------------------------------
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_ReceiveFicheData(string formatted)
	{
		JobRpFicheMenu menu = JobRpFicheMenu.GetOpenMenu();
		if (menu)
			menu.DisplayFicheData(formatted);
	}

	//------------------------------------------------------------------------------------------------
	// FICHE RP - PAGE RESIDENCES : liste des portes possedees par le joueur
	//------------------------------------------------------------------------------------------------
	void ClientAskMyResidences()
	{
		Rpc(RpcAsk_MyResidences);
	}

	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_MyResidences()
	{
		if (!Replication.IsServer()) return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		if (playerId <= 0) return;
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "") return;

		LP_DoorManager dmgr = LP_DoorManager.GetInstance();
		// Format : header + delimiteur "~~~ENTRY~~~" entre chaque residence pour pagination client.
		string formatted = "";
		if (dmgr)
		{
			array<LP_DoorData> all = dmgr.GetAllDoors();
			int ownCount = 0;
			int i;
			int alen = all.Count();
			string entries = "";
			for (i = 0; i < alen; i++)
			{
				LP_DoorData d = all.Get(i);
				if (!d || d.m_OwnerUID != uid) continue;
				ownCount = ownCount + 1;
				string code = d.m_ShareCode;
				if (code == "") code = "(aucun code defini)";
				int posX = d.m_Position[0];
				int posY = d.m_Position[1];
				int posZ = d.m_Position[2];
				int sharedCount = 0;
				if (d.m_KnownPlayerUIDs) sharedCount = d.m_KnownPlayerUIDs.Count();

				string entry = "> Residence #" + ownCount.ToString() + "\n";
				entry = entry + "  Lieu           : X=" + posX.ToString() + "  Y=" + posY.ToString() + "  Z=" + posZ.ToString() + "\n";
				entry = entry + "  Prix d achat   : " + d.m_PurchasePrice.ToString() + " caps\n";
				entry = entry + "  Code           : " + code + "\n";
				entry = entry + "  Partage avec   : " + sharedCount.ToString() + " autre(s) joueur(s)";
				if (d.m_PurchaseUnix > 0)
					entry = entry + "\n  Date d achat   : " + FicheFormatUnixDate(d.m_PurchaseUnix);
				entries = entries + "~~~ENTRY~~~" + entry;
			}
			if (ownCount == 0)
				formatted = "Vous ne possedez aucune residence pour le moment.\n\nVisitez un agent immobilier pour acheter une porte.";
			else
				formatted = ownCount.ToString() + " residence(s) possedee(s)." + entries;
		}
		else
		{
			formatted = "Service immobilier indisponible.";
		}
		Rpc(RpcDo_MyResidences, formatted);
	}

	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_MyResidences(string formatted)
	{
		JobRpFicheMenu menu = JobRpFicheMenu.GetOpenMenu();
		if (menu)
			menu.DisplayResidencesData(formatted);
	}

	//------------------------------------------------------------------------------------------------
	// FICHE RP - PAGE DOSSIER MEDICAL PARTAGE : affiche le MedicalRecord du joueur
	//------------------------------------------------------------------------------------------------
	void ClientAskMyMedicalRecord()
	{
		Rpc(RpcAsk_MyMedicalRecord);
	}

	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_MyMedicalRecord()
	{
		if (!Replication.IsServer()) return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		if (playerId <= 0) return;
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "") return;

		JobMedicalManager mmgr = JobMedicalManager.GetInstance();
		string formatted = "";
		if (!mmgr)
		{
			formatted = "Service medical indisponible.";
		}
		else
		{
			MedicalRecord rec = mmgr.GetRecord(uid);
			if (!rec)
			{
				formatted = "Aucun dossier medical ouvert a votre nom.\n\nUn medecin pourra en creer un lors de votre premiere consultation.";
			}
			else
			{
				// Format : header + delimiteur "~~~ENTRY~~~" entre chaque evenement medical.
				// Le client affichera le header toujours puis paginera les evenements par 9.
				string buf = "";
				buf = buf + "N dossier       : " + rec.m_FileNumber + "\n";
				if (rec.m_DateOfBirth != "")
					buf = buf + "Date naissance  : " + rec.m_DateOfBirth + "\n";
				string allergies = rec.m_Allergies;
				if (allergies == "") allergies = "Aucune connue";
				string maladies = rec.m_KnownDiseases;
				if (maladies == "") maladies = "Aucune connue";
				string traitements = rec.m_CurrentTreatments;
				if (traitements == "") traitements = "Aucun en cours";
				buf = buf + "Allergies       : " + allergies + "\n";
				buf = buf + "Maladies connues: " + maladies + "\n";
				buf = buf + "Traitements     : " + traitements;

				int hospCount = 0;
				if (rec.m_Hospitalizations) hospCount = rec.m_Hospitalizations.Count();
				int soinCount = 0;
				if (rec.m_Soins) soinCount = rec.m_Soins.Count();
				buf = buf + "\n\nTotal hospitalisations : " + hospCount.ToString();
				buf = buf + "\nTotal soins            : " + soinCount.ToString();

				// Hospitalisations
				int hi;
				for (hi = 0; hi < hospCount; hi++)
				{
					HospitalizationRecord h = rec.m_Hospitalizations.Get(hi);
					if (!h) continue;
					string statusHosp = "Terminee";
					if (h.IsActive()) statusHosp = "EN COURS";
					string entryStr = "?";
					if (h.m_EntryTimestamp > 0) entryStr = FicheFormatUnixDate(h.m_EntryTimestamp);
					string medecinH = h.m_MedecinName;
					if (medecinH == "") medecinH = "Inconnu";
					string chambreH = h.m_Chambre;
					if (chambreH == "") chambreH = "?";
					string entry = "[HOSPITALISATION] " + entryStr + " (" + statusHosp + ")";
					entry = entry + "\n  Chambre  : " + chambreH;
					entry = entry + "\n  Medecin  : " + medecinH;
					if (h.m_CompteRendu != "")
						entry = entry + "\n  Rapport  : " + h.m_CompteRendu;
					if (h.m_Ordonnance != "")
						entry = entry + "\n  Ordonnance: " + h.m_Ordonnance;
					buf = buf + "~~~ENTRY~~~" + entry;
				}

				// Soins (les plus recents d abord)
				int si;
				for (si = soinCount - 1; si >= 0; si--)
				{
					SoinRecord sr = rec.m_Soins.Get(si);
					if (!sr) continue;
					string dateStr = "?";
					if (sr.m_Timestamp > 0) dateStr = FicheFormatUnixDate(sr.m_Timestamp);
					string medecinS = sr.m_MedecinName;
					if (medecinS == "") medecinS = "Inconnu";
					string sentry = "[SOIN] " + dateStr + " - " + medecinS;
					if (sr.m_Motif != "")
						sentry = sentry + "\n  Motif    : " + sr.m_Motif;
					if (sr.m_Diagnostic != "")
						sentry = sentry + "\n  Diagnostic: " + sr.m_Diagnostic;
					if (sr.m_SoinsRealises != "")
						sentry = sentry + "\n  Soins    : " + sr.m_SoinsRealises;
					if (sr.m_Medicaments != "")
						sentry = sentry + "\n  Rx       : " + sr.m_Medicaments;
					if (sr.m_Cout > 0)
						sentry = sentry + "\n  Facture  : " + sr.m_Cout.ToString() + " caps";
					buf = buf + "~~~ENTRY~~~" + sentry;
				}
				formatted = buf;
			}
		}
		Rpc(RpcDo_MyMedicalRecord, formatted);
	}

	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_MyMedicalRecord(string formatted)
	{
		JobRpFicheMenu menu = JobRpFicheMenu.GetOpenMenu();
		if (menu)
			menu.DisplayMedicalData(formatted);
	}

	//------------------------------------------------------------------------------------------------
	// ============================================================
	// SYSTEME SMS RP
	// ============================================================
	//------------------------------------------------------------------------------------------------
	
	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : envoyer un SMS a un destinataire
	//------------------------------------------------------------------------------------------------
	void ClientAskSendSms(int targetPlayerId, string content)
	{
		Rpc(RpcAsk_SendSms, targetPlayerId, content);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_SendSms(int targetPlayerId, string content)
	{
		if (!Replication.IsServer())
			return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc)
			return;
		int senderPid = pc.GetPlayerId();
		if (senderPid <= 0)
			return;
		
		string senderUID = JobManager.GetInstance().GetPersistentUID(senderPid);
		if (senderUID == "")
			return;
		
		// Verifie que l expediteur a un telephone
		IEntity senderChar = pc.GetControlledEntity();
		if (!senderChar || !JobToolCheck.HasPhone(senderChar))
		{
			JobManager.GetInstance().NotifyPlayerChat(senderPid,
				"[SMS] Vous devez avoir un telephone (iPhone) pour envoyer un SMS.");
			return;
		}
		
		// Resoud destinataire
		PlayerManager pm = GetGame().GetPlayerManager();
		if (!pm)
			return;
		PlayerController targetPc = pm.GetPlayerController(targetPlayerId);
		if (!targetPc)
		{
			JobManager.GetInstance().NotifyPlayerChat(senderPid,
				"[SMS] Destinataire introuvable (deconnecte ?).");
			return;
		}
		string targetUID = JobManager.GetInstance().GetPersistentUID(targetPlayerId);
		if (targetUID == "")
		{
			JobManager.GetInstance().NotifyPlayerChat(senderPid,
				"[SMS] Destinataire invalide.");
			return;
		}
		
		// Verifie que le destinataire a un telephone
		IEntity targetChar = targetPc.GetControlledEntity();
		if (!targetChar || !JobToolCheck.HasPhone(targetChar))
		{
			JobManager.GetInstance().NotifyPlayerChat(senderPid,
				"[SMS] Le destinataire n'a pas de telephone.");
			return;
		}
		
		// Resoud les noms d affichage (RP si dispo, sinon playername)
		string senderName = ResolveDisplayName(senderUID, senderPid);
		string targetName = ResolveDisplayName(targetUID, targetPlayerId);
		
		// Envoi
		int result = JobSmsManager.GetInstance().SendSms(senderUID, senderName, targetUID, targetName, content);
		if (result != 0)
		{
			JobManager.GetInstance().NotifyPlayerChat(senderPid,
				"[SMS] Erreur lors de l'envoi.");
			return;
		}
		
		// Confirmation expediteur
		JobManager.GetInstance().NotifyPlayerChat(senderPid,
			string.Format("[SMS] Message envoye a %1.", targetName));
		
		// Notif destinataire
		JobPlayerComponent targetJpc = JobPlayerComponent.Cast(targetPc.FindComponent(JobPlayerComponent));
		if (targetJpc)
			targetJpc.NotifyNewSms(senderName);
	}
	
	//------------------------------------------------------------------------------------------------
	// SERVER : helper pour resoudre le nom RP fallback playername
	//------------------------------------------------------------------------------------------------
	string ResolveDisplayName(string uid, int playerId)
	{
		JobRpIdentity id = JobIdentityManager.GetInstance().GetIdentity(uid);
		if (id)
			return id.m_FirstName + " " + id.m_LastName;
		PlayerManager pm = GetGame().GetPlayerManager();
		if (pm)
			return pm.GetPlayerName(playerId);
		return "Inconnu";
	}
	
	//------------------------------------------------------------------------------------------------
	// SERVER : envoie une notif RPC au destinataire pour signaler nouveau SMS
	//------------------------------------------------------------------------------------------------
	void NotifyNewSms(string senderName)
	{
		if (!Replication.IsServer())
			return;
		Rpc(RpcDo_NewSmsHint, senderName);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_NewSmsHint(string senderName)
	{
		// Hint client : nouveau SMS recu
		LP_NotificationManager.Show(
			string.Format("Nouveau SMS de %1", senderName), "SMS recu", 5.0);
		
		// Son local (notification "ding" du SMS) - GUID du fichier wav du mod
		// IMPORTANT : le wav doit etre "Import and register" dans Enfusion sinon ne joue rien
		AudioSystem.PlaySound("{8DFC426A631EAB39}Sounds/sms_notif.wav");
	}
	
	//------------------------------------------------------------------------------------------------
	// === VERROUILLAGE PORTES POLICE ===
	// Permet aux policiers/militaires de verrouiller/deverrouiller les portes du
	// batiment de police via les UserActions JobLockPoliceDoorAction / JobUnlockPoliceDoorAction.
	// Le filtrage metier est fait cote client (action visible) ET cote serveur (RPC verifie metier).
	//------------------------------------------------------------------------------------------------
	
	// CLIENT -> SERVER : bascule le verrouillage d une porte (lock=true pour verrouiller, false pour deverrouiller)
	void ClientAskTogglePoliceDoor(RplId doorRplId, bool lockState)
	{
		Rpc(RpcAsk_TogglePoliceDoor, doorRplId, lockState);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_TogglePoliceDoor(RplId doorRplId, bool lockState)
	{
		if (!Replication.IsServer())
			return;
		
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc)
			return;
		int playerId = pc.GetPlayerId();
		if (playerId <= 0)
			return;
		
		// Verifie metier serveur (anti-cheese, le client pourrait spoofer)
		JobPlayerData data = JobManager.GetInstance().GetPlayerData(playerId);
		if (!data || (data.m_Job != EJobType.POLICIER && data.m_Job != EJobType.MILITAIRE))
		{
			return;
		}
		
		// Resoud la porte
		RplComponent rpl = RplComponent.Cast(Replication.FindItem(doorRplId));
		if (!rpl)
			return;
		IEntity door = rpl.GetEntity();
		if (!door)
			return;
		JobPoliceDoorComponent doorComp = JobPoliceDoorComponent.Cast(
			door.FindComponent(JobPoliceDoorComponent));
		if (!doorComp)
			return;
		
		doorComp.ServerSetLocked(lockState);
		
		// Pas de notif/hint visuel demande par le boss : le feedback est donne
		// par l action UI qui change directement (Verrouiller -> Deverrouiller et inversement)
	}
	
	//------------------------------------------------------------------------------------------------
	// === VERROUILLAGE PORTES HOPITAL ===
	// Permet aux MEDECINS de verrouiller/deverrouiller les portes de l hopital via les
	// UserActions JobLockHospitalDoorAction / JobUnlockHospitalDoorAction.
	// Architecture independante de la police : composant et actions separes pour que
	// les medecins ne puissent verrouiller que l hopital (pas la police/gendarmerie)
	// et inversement.
	//------------------------------------------------------------------------------------------------
	
	// CLIENT -> SERVER : bascule le verrouillage d une porte hopital
	void ClientAskToggleHospitalDoor(RplId doorRplId, bool lockState)
	{
		Rpc(RpcAsk_ToggleHospitalDoor, doorRplId, lockState);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_ToggleHospitalDoor(RplId doorRplId, bool lockState)
	{
		if (!Replication.IsServer())
			return;
		
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc)
			return;
		int playerId = pc.GetPlayerId();
		if (playerId <= 0)
			return;
		
		// Verifie metier serveur (anti-cheese, le client pourrait spoofer).
		// Pas de notif/hint en cas d echec : le scenario normal (medecin qui agit) ne
		// declenche jamais ce code, et un cheat silencieux n a pas besoin d etre notifie.
		JobPlayerData data = JobManager.GetInstance().GetPlayerData(playerId);
		if (!data || data.m_Job != EJobType.MEDECIN)
			return;
		
		// Resoud la porte
		RplComponent rpl = RplComponent.Cast(Replication.FindItem(doorRplId));
		if (!rpl)
			return;
		IEntity door = rpl.GetEntity();
		if (!door)
			return;
		JobHospitalDoorComponent doorComp = JobHospitalDoorComponent.Cast(
			door.FindComponent(JobHospitalDoorComponent));
		if (!doorComp)
			return;
		
		doorComp.ServerSetLocked(lockState);
		
		// Pas de notif/hint visuel : feedback par changement d action contextuelle
	}
	
	//------------------------------------------------------------------------------------------------
	// ============================ SYSTEME DE GANG ============================
	//------------------------------------------------------------------------------------------------
	
	// CLIENT -> SERVER : demande les infos du gang du joueur (ou absence de gang)
	void ClientAskGangInfo()
	{
		Rpc(RpcAsk_GangInfo);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_GangInfo()
	{
		if (!Replication.IsServer())
			return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "") return;
		
		JobGang gang = JobGangManager.GetInstance().GetGangOfPlayer(uid);
		if (!gang)
		{
			// Pas de gang -> ouvre le menu de creation cote client
			Rpc(RpcDo_OpenGangCreate);
			return;
		}
		
		// A un gang -> envoie les infos formatees pour le menu de gestion
		bool isChef = gang.IsChef(uid);
		string formatted = BuildGangData(gang);
		Rpc(RpcDo_OpenGangManage, gang.m_Name, gang.m_Benefits, isChef, formatted);
	}
	
	//------------------------------------------------------------------------------------------------
	// SERVEUR : construit une string formatee avec les membres + zones controlees
	// Format : "MEMBRES\nuid1|nom1\nuid2|nom2\n...###ZONES\nCannabis|GangX\n..."
	//------------------------------------------------------------------------------------------------
	string BuildGangData(JobGang gang)
	{
		string s = "MEMBRES\n";
		// Chef d abord (prefixe CHEF)
		s = s + "CHEF|" + gang.m_ChefUID + "|" + gang.m_ChefDisplayName + "\n";
		// Puis membres
		foreach (JobGangMember m : gang.m_Members)
		{
			if (!m) continue;
			s = s + "MEMBRE|" + m.m_UID + "|" + m.m_DisplayName + "\n";
		}
		// Section zones controlees par ce gang
		s = s + "###ZONES\n";
		JobGangManager mgr = JobGangManager.GetInstance();
		// On verifie chaque drogue du marche
		if (mgr.GetZoneController(EMarketItem.CANNABIS) == gang.m_Name)
			s = s + "Cannabis\n";
		if (mgr.GetZoneController(EMarketItem.COCAINE) == gang.m_Name)
			s = s + "Cocaine\n";
		return s;
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_OpenGangCreate()
	{
		JobGangCreateMenu menu = JobGangCreateMenu.Cast(
			GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.JobGangCreateMenu));
		if (menu)
			menu.Initialize();
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_OpenGangManage(string gangName, int benefits, bool isChef, string membersData)
	{
		JobGangMenu menu = JobGangMenu.Cast(
			GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.JobGangMenu));
		if (menu)
			menu.Initialize(gangName, benefits, isChef, membersData);
	}
	
	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : creer un gang
	//------------------------------------------------------------------------------------------------
	void ClientAskCreateGang(string gangName)
	{
		Rpc(RpcAsk_CreateGang, gangName);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_CreateGang(string gangName)
	{
		if (!Replication.IsServer())
			return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "") return;
		
		// Verifie metier voyou
		JobPlayerData data = JobManager.GetInstance().GetPlayerData(playerId);
		if (!data || data.m_Job != EJobType.VOYOU)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[GANG] Seuls les voyous peuvent creer un gang.");
			return;
		}
		
		string displayName = JobIdentityManager.GetInstance().GetDisplayNameByPlayerId(playerId);
		int result = JobGangManager.GetInstance().CreateGang(uid, displayName, gangName);
		
		switch (result)
		{
			case 0:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					string.Format("[GANG] Gang '%1' cree avec succes ! (-30000 capsules)", gangName));
				// Sync HUD capsules
				CapsuleEconomyManager eco = CapsuleEconomyManager.GetInstance();
				if (eco)
				{
					CapsulePlayerComponent capsComp = CapsulePlayerComponent.Cast(pc.FindComponent(CapsulePlayerComponent));
					if (capsComp)
						capsComp.Svr_SendCapsules(eco.GetCapsules(uid));
				}
				// Sync flag gang client (autorise la vente de drogue)
				Svr_PushIsInGang();
				break;
			case 1:
				JobManager.GetInstance().NotifyPlayerChat(playerId, "[GANG] Nom de gang invalide.");
				break;
			case 2:
				JobManager.GetInstance().NotifyPlayerChat(playerId, "[GANG] Ce nom de gang est deja pris.");
				break;
			case 3:
				JobManager.GetInstance().NotifyPlayerChat(playerId, "[GANG] Vous etes deja dans un gang.");
				break;
			case 4:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[GANG] Solde insuffisant. Il faut 30000 capsules pour creer un gang.");
				break;
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : recruter un membre (le chef selectionne un joueur par son playerId)
	//------------------------------------------------------------------------------------------------
	void ClientAskRecruitMember(int targetPlayerId)
	{
		Rpc(RpcAsk_RecruitMember, targetPlayerId);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_RecruitMember(int targetPlayerId)
	{
		if (!Replication.IsServer())
			return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		string chefUID = JobManager.GetInstance().GetPersistentUID(playerId);
		if (chefUID == "") return;
		
		string targetUID = JobManager.GetInstance().GetPersistentUID(targetPlayerId);
		if (targetUID == "")
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId, "[GANG] Joueur cible introuvable.");
			return;
		}
		string targetName = JobIdentityManager.GetInstance().GetDisplayNameByPlayerId(targetPlayerId);
		
		int result = JobGangManager.GetInstance().RecruitMember(chefUID, targetUID, targetName);
		switch (result)
		{
			case 0:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					string.Format("[GANG] %1 a rejoint votre gang.", targetName));
				JobManager.GetInstance().NotifyPlayerChat(targetPlayerId,
					"[GANG] Vous avez ete recrute dans un gang !");
				// Sync flag gang client au recrute (autorise la vente de drogue)
				Svr_PushIsInGangForUID(targetUID);
				break;
			case 1:
				JobManager.GetInstance().NotifyPlayerChat(playerId, "[GANG] Seul le chef peut recruter.");
				break;
			case 2:
				JobManager.GetInstance().NotifyPlayerChat(playerId, "[GANG] Ce joueur est deja dans un gang.");
				break;
			case 3:
				JobManager.GetInstance().NotifyPlayerChat(playerId, "[GANG] Gang introuvable.");
				break;
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : ejecter un membre (par UID, recu du menu)
	//------------------------------------------------------------------------------------------------
	void ClientAskEjectMember(string targetUID)
	{
		Rpc(RpcAsk_EjectMember, targetUID);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_EjectMember(string targetUID)
	{
		if (!Replication.IsServer())
			return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		string chefUID = JobManager.GetInstance().GetPersistentUID(playerId);
		if (chefUID == "") return;
		
		int result = JobGangManager.GetInstance().EjectMember(chefUID, targetUID);
		switch (result)
		{
			case 0:
				JobManager.GetInstance().NotifyPlayerChat(playerId, "[GANG] Membre ejecte du gang.");
				// Sync flag gang client a l ejecte (perd l autorisation de vendre de la drogue)
				Svr_PushIsInGangForUID(targetUID);
				break;
			case 1:
				JobManager.GetInstance().NotifyPlayerChat(playerId, "[GANG] Seul le chef peut ejecter.");
				break;
			case 2:
				JobManager.GetInstance().NotifyPlayerChat(playerId, "[GANG] Ce joueur n'est pas dans le gang.");
				break;
			case 3:
				JobManager.GetInstance().NotifyPlayerChat(playerId, "[GANG] Gang introuvable.");
				break;
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// === QUITTER LE GANG ===
	// Si le joueur est un membre simple : sortie directe.
	// Si le joueur est le chef : transfere la chefferie au membre #0, OU dissout
	// automatiquement si plus aucun autre membre.
	//------------------------------------------------------------------------------------------------
	void ClientAskLeaveGang()
	{
		Rpc(RpcAsk_LeaveGang);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_LeaveGang()
	{
		if (!Replication.IsServer())
			return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "") return;
		
		// Recupere d abord le nom du nouveau chef AVANT de quitter (pour la notif)
		string newChefDisplayName = "";
		JobGang gangBefore = JobGangManager.GetInstance().GetGangOfPlayer(uid);
		if (gangBefore && gangBefore.IsChef(uid) && gangBefore.m_Members.Count() > 0)
		{
			JobGangMember nextChef = gangBefore.m_Members.Get(0);
			if (nextChef)
				newChefDisplayName = nextChef.m_DisplayName;
		}
		
		string newChefUID;
		string gangName;
		int result = JobGangManager.GetInstance().LeaveGang(uid, newChefUID, gangName);
		switch (result)
		{
			case -1:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[GANG] Vous n'etes pas dans un gang.");
				break;
			case 0:
				// Membre simple
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					string.Format("[GANG] Vous avez quitte le gang \"%1\".", gangName));
				// Sync flag gang client (perd l autorisation de vendre de la drogue)
				Svr_PushIsInGang();
				break;
			case 1:
				// Chef qui quitte avec transfert chefferie
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					string.Format("[GANG] Vous avez quitte \"%1\". %2 est le nouveau chef.",
						gangName, newChefDisplayName));
				if (newChefUID != "")
					NotifyPlayerByUID(newChefUID,
						string.Format("[GANG] L ancien chef a quitte. Vous etes desormais le chef du gang \"%1\" !",
							gangName));
				// Sync flag gang client (perd l autorisation de vendre de la drogue)
				Svr_PushIsInGang();
				break;
			case 2:
				// Chef solo : dissolution automatique
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					string.Format("[GANG] Vous etiez le seul membre. Le gang \"%1\" a ete dissous.", gangName));
				// Sync flag gang client (perd l autorisation de vendre de la drogue)
				Svr_PushIsInGang();
				break;
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// === DISSOUDRE LE GANG (chef uniquement) ===
	//------------------------------------------------------------------------------------------------
	void ClientAskDissolveGang()
	{
		Rpc(RpcAsk_DissolveGang);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_DissolveGang()
	{
		if (!Replication.IsServer())
			return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "") return;
		
		// La methode DissolveGang du manager retourne directement la liste des membres
		// a notifier (parametre out)
		string dissolvedName;
		array<string> memberUIDsToNotify = new array<string>();
		int result = JobGangManager.GetInstance().DissolveGang(uid, dissolvedName, memberUIDsToNotify);
		switch (result)
		{
			case 0:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					string.Format("[GANG] Vous avez dissous le gang \"%1\".", dissolvedName));
				foreach (string memberUID : memberUIDsToNotify)
				{
					NotifyPlayerByUID(memberUID,
						string.Format("[GANG] Le chef a dissous le gang \"%1\".", dissolvedName));
					// Sync flag gang client a chaque membre dissous
					Svr_PushIsInGangForUID(memberUID);
				}
				// Sync flag gang pour le chef dissolveur
				Svr_PushIsInGang();
				break;
			case 1:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[GANG] Seul le chef peut dissoudre le gang.");
				break;
			case 3:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[GANG] Vous n'etes pas dans un gang.");
				break;
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Helper : envoie une notif chat a un joueur identifie par son UID (s il est connecte).
	//------------------------------------------------------------------------------------------------
	void NotifyPlayerByUID(string targetUID, string message)
	{
		PlayerManager pm = GetGame().GetPlayerManager();
		if (!pm)
			return;
		array<int> playerIds = new array<int>();
		pm.GetPlayers(playerIds);
		foreach (int pid : playerIds)
		{
			string uid = JobManager.GetInstance().GetPersistentUID(pid);
			if (uid == targetUID)
			{
				JobManager.GetInstance().NotifyPlayerChat(pid, message);
				return;
			}
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : retirer les benefices du gang (chef uniquement)
	//------------------------------------------------------------------------------------------------
	void ClientAskWithdrawGangBenefits()
	{
		Rpc(RpcAsk_WithdrawGangBenefits);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_WithdrawGangBenefits()
	{
		if (!Replication.IsServer())
			return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "") return;
		
		int amount = JobGangManager.GetInstance().WithdrawBenefits(uid);
		if (amount > 0)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				string.Format("[GANG] %1 capsules de benefices retirees.", amount));
			// Sync HUD
			CapsuleEconomyManager eco = CapsuleEconomyManager.GetInstance();
			if (eco)
			{
				CapsulePlayerComponent capsComp = CapsulePlayerComponent.Cast(pc.FindComponent(CapsulePlayerComponent));
				if (capsComp)
					capsComp.Svr_SendCapsules(eco.GetCapsules(uid));
			}
		}
		else
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[GANG] Aucun benefice a retirer (ou vous n'etes pas le chef).");
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// === CAPTURE DE ZONE ===
	//------------------------------------------------------------------------------------------------
	
	// CLIENT -> SERVER : lance la capture d une zone d extraction (resolue par RplId)
	void ClientAskCaptureZone(RplId zoneRplId)
	{
		Rpc(RpcAsk_CaptureZone, zoneRplId);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_CaptureZone(RplId zoneRplId)
	{
		if (!Replication.IsServer())
			return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "") return;
		
		// Resoud l entite zone
		RplComponent rpl = RplComponent.Cast(Replication.FindItem(zoneRplId));
		if (!rpl)
			return;
		IEntity zone = rpl.GetEntity();
		if (!zone)
			return;
		
		int result = JobZoneCaptureManager.GetInstance().StartCapture(zone, playerId, uid);
		switch (result)
		{
			case 1:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[GANG] Vous devez faire partie d'un gang pour capturer une zone.");
				break;
			case 2:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[GANG] Cette zone est deja en cours de capture.");
				break;
			case 3:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[GANG] Votre gang controle deja cette zone.");
				break;
			// case 0 : message envoye par StartCapture
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// SERVER -> CLIENT (owner) : ajoute un marqueur local "Zone Controlee (Gang)" sur la carte
	//------------------------------------------------------------------------------------------------
	void ServerSendZoneMarker(float posX, float posZ, string gangName, string drugLabel)
	{
		Rpc(RpcDo_ReceiveZoneMarker, posX, posZ, gangName, drugLabel);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_ReceiveZoneMarker(float posX, float posZ, string gangName, string drugLabel)
	{
		// Cree un marqueur local sur la carte
		SCR_MapMarkerManagerComponent markerMgr = SCR_MapMarkerManagerComponent.Cast(
			GetGame().GetGameMode().FindComponent(SCR_MapMarkerManagerComponent));
		if (!markerMgr)
			return;
		
		// IMPORTANT : stocker le marqueur dans une variable MEMBRE (array) sinon il est
		// garbage-collecte des la fin de la fonction et n apparait jamais.
		// IMPORTANT : SetColorEntry est requis pour que le marqueur soit visible.
		SCR_MapMarkerBase marker = new SCR_MapMarkerBase();
		marker.SetType(SCR_EMapMarkerType.PLACED_CUSTOM);
		marker.SetWorldPos(posX, posZ);
		marker.SetCustomText(string.Format("Zone Controlee (%1)", gangName));
		marker.SetColorEntry(2);  // couleur (2 = rouge/orange selon config marker)
		markerMgr.InsertStaticMarker(marker, true, true);  // isLocal = true
		
		m_ZoneMarkers.Insert(marker);  // garde une reference pour eviter le GC
		
		Print(string.Format("[JobPlayerComponent] Marqueur zone cree: pos=(%1, %2) gang=%3",
			posX, posZ, gangName), LogLevel.NORMAL);
	}
	
	//------------------------------------------------------------------------------------------------
	// === BARRE DE PROGRESSION DE CAPTURE A L ECRAN ===
	//------------------------------------------------------------------------------------------------
	
	// SERVER -> CLIENT (owner) : met a jour la barre de progression
	void ServerSendCaptureProgress(int percent, int remainingSeconds, bool contested)
	{
		Rpc(RpcDo_UpdateCaptureProgress, percent, remainingSeconds, contested);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_UpdateCaptureProgress(int percent, int remainingSeconds, bool contested)
	{
		// Cree le widget s il n existe pas encore
		if (!m_CaptureProgressWidget)
		{
			WorkspaceWidget ws = GetGame().GetWorkspace();
			if (!ws)
				return;
			m_CaptureProgressWidget = ws.CreateWidgets(
				"{E0618A43A34B4071}UI/layouts/JobCaptureProgress.layout", null);
			if (!m_CaptureProgressWidget)
				return;
		}
		
		// Met a jour le remplissage de la barre (largeur proportionnelle au %)
		ImageWidget barFill = ImageWidget.Cast(m_CaptureProgressWidget.FindAnyWidget("BarFill"));
		if (barFill)
		{
			// Largeur totale de la barre = 420, on retire 4px de padding -> 416 utile
			float fillWidth = (416.0 * percent) / 100.0;
			barFill.SetSize(fillWidth, 24);
			// Couleur : vert si progression, orange si contestee (en pause)
			if (contested)
				barFill.SetColor(Color.FromRGBA(230, 140, 20, 255));   // orange
			else
				barFill.SetColor(Color.FromRGBA(50, 190, 75, 255));    // vert
		}
		
		// Met a jour le texte
		TextWidget barText = TextWidget.Cast(m_CaptureProgressWidget.FindAnyWidget("BarText"));
		if (barText)
		{
			if (contested)
			{
				barText.SetText(string.Format("%1%% - EN PAUSE (contestee)", percent));
			}
			else
			{
				int remainingMin = remainingSeconds / 60;
				int remainingSec = remainingSeconds % 60;
				if (remainingMin > 0)
					barText.SetText(string.Format("%1%% - %2min %3s restantes", percent, remainingMin, remainingSec));
				else
					barText.SetText(string.Format("%1%% - %2s restantes", percent, remainingSec));
			}
		}
	}
	
	// SERVER -> CLIENT (owner) : masque/detruit la barre de progression
	void ServerHideCaptureProgress()
	{
		Rpc(RpcDo_HideCaptureProgress);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_HideCaptureProgress()
	{
		if (m_CaptureProgressWidget)
		{
			m_CaptureProgressWidget.RemoveFromHierarchy();
			m_CaptureProgressWidget = null;
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// === BARRE DE PROGRESSION D ACTIVITE METIER (extraction / transformation) ===
	//------------------------------------------------------------------------------------------------
	// Calque sur le pattern capture mais separe : on peut imaginer un joueur qui
	// fait une extraction tout en etant proche d une zone de capture (peu probable
	// mais on garde les 2 systemes independants pour eviter tout conflit).
	//
	// title = libelle affiche (ex: "EXTRACTION", "TRANSFORMATION")
	// count = progression actuelle (0-30)
	// maxCount = total (30)
	//------------------------------------------------------------------------------------------------
	
	// SERVER -> CLIENT (owner) : met a jour la barre d activite
	void ServerSendActivityProgress(string title, int count, int maxCount)
	{
		Rpc(RpcDo_UpdateActivityProgress, title, count, maxCount);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_UpdateActivityProgress(string title, int count, int maxCount)
	{
		// Cree le widget s il n existe pas
		if (!m_ActivityProgressWidget)
		{
			WorkspaceWidget ws = GetGame().GetWorkspace();
			if (!ws)
				return;
			m_ActivityProgressWidget = ws.CreateWidgets(
				"{BDB249BB893548F6}UI/layouts/JobActivityProgress.layout", null);
			if (!m_ActivityProgressWidget)
				return;
		}
		
		// Met a jour le titre (EXTRACTION ou TRANSFORMATION)
		TextWidget titleW = TextWidget.Cast(m_ActivityProgressWidget.FindAnyWidget("ActivityTitle"));
		if (titleW)
			titleW.SetText(title);
		
		// Met a jour le remplissage de la barre (largeur proportionnelle)
		ImageWidget barFill = ImageWidget.Cast(m_ActivityProgressWidget.FindAnyWidget("BarFill"));
		if (barFill && maxCount > 0)
		{
			float ratio = count;
			ratio = ratio / maxCount;
			if (ratio < 0) ratio = 0;
			if (ratio > 1) ratio = 1;
			// Largeur totale 420 - 4px padding = 416 utile
			float fillWidth = 416.0 * ratio;
			barFill.SetSize(fillWidth, 24);
			barFill.SetColor(Color.FromRGBA(50, 190, 75, 255));  // vert
		}
		
		// Met a jour le texte "X/30"
		TextWidget barText = TextWidget.Cast(m_ActivityProgressWidget.FindAnyWidget("BarText"));
		if (barText)
			barText.SetText(string.Format("%1 / %2", count, maxCount));
	}
	
	// SERVER -> CLIENT (owner) : masque/detruit la barre d activite
	void ServerHideActivityProgress()
	{
		Rpc(RpcDo_HideActivityProgress);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_HideActivityProgress()
	{
		if (m_ActivityProgressWidget)
		{
			m_ActivityProgressWidget.RemoveFromHierarchy();
			m_ActivityProgressWidget = null;
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : demande la suppression LOCALE d une conversation (dans l inbox du
	// joueur uniquement, l autre voit toujours ses messages).
	//------------------------------------------------------------------------------------------------
	void ClientAskDeleteSmsConversation(string otherUID)
	{
		Rpc(RpcAsk_DeleteSmsConversation, otherUID);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_DeleteSmsConversation(string otherUID)
	{
		if (!Replication.IsServer())
			return;
		if (otherUID == "")
			return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc)
			return;
		int playerId = pc.GetPlayerId();
		string ownerUID = JobManager.GetInstance().GetPersistentUID(playerId);
		if (ownerUID == "")
			return;
		int removed = JobSmsManager.GetInstance().DeleteConversationForPlayer(ownerUID, otherUID);
		// Feedback client via chat (pattern coherent avec le reste du systeme SMS)
		if (removed > 0)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				string.Format("[SMS] Conversation supprimee (%1 messages).", removed));
		}
		else
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[SMS] Aucun message a supprimer.");
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : demande le statut d assurance d un vehicule (identifie par RplId)
	// Utilise par LP_VehicleInsuranceHudComponent pour afficher le HUD au conducteur.
	//------------------------------------------------------------------------------------------------
	void ClientAskVehicleInsurance(int vehicleRplId)
	{
		Rpc(RpcAsk_VehicleInsurance, vehicleRplId);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_VehicleInsurance(int vehicleRplId)
	{
		if (!Replication.IsServer())
			return;
		if (vehicleRplId == 0)
			return;
		
		// Resout l entite vehicule cote serveur
		RplId rid = vehicleRplId;
		RplComponent rpl = RplComponent.Cast(Replication.FindItem(rid));
		if (!rpl)
			return;
		IEntity vehicle = rpl.GetEntity();
		if (!vehicle)
			return;
		
		// Check si c est un vehicule de location -> pas d assurance a afficher
		// (le HUD Location gere son propre affichage, on evite la superposition)
		int rentalEnd = JobVehicleRentalManager.GetInstance().GetRentalEndUnixByVehicleRplId(vehicleRplId);
		bool isRental = (rentalEnd > 0);
		
		bool insured = false;
		if (!isRental)
			insured = JobInsuranceManager.GetInstance().IsVehicleInsured(vehicle);
		
		Rpc(RpcDo_ReceiveVehicleInsurance, vehicleRplId, insured, isRental);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_ReceiveVehicleInsurance(int vehicleRplId, bool insured, bool isRental)
	{
		LP_VehicleInsuranceHudComponent hud = LP_VehicleInsuranceHudComponent.GetLocalInstance();
		if (hud)
			hud.OnInsuranceStatusReceived(vehicleRplId, insured, isRental);
	}
	
	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : demande le statut de LOCATION d un vehicule (identifie par RplId)
	// Reponse : endUnix > 0 si vehicule en location, 0 sinon.
	//------------------------------------------------------------------------------------------------
	void ClientAskVehicleRental(int vehicleRplId)
	{
		Rpc(RpcAsk_VehicleRental, vehicleRplId);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_VehicleRental(int vehicleRplId)
	{
		if (!Replication.IsServer())
			return;
		if (vehicleRplId == 0)
			return;
		
		int endUnix = JobVehicleRentalManager.GetInstance().GetRentalEndUnixByVehicleRplId(vehicleRplId);
		Rpc(RpcDo_ReceiveVehicleRental, vehicleRplId, endUnix);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_ReceiveVehicleRental(int vehicleRplId, int endUnix)
	{
		LP_VehicleRentalHudComponent hud = LP_VehicleRentalHudComponent.GetLocalInstance();
		if (hud)
			hud.OnRentalInfoReceived(vehicleRplId, endUnix);
	}
	
	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : demande la liste des conversations
	//------------------------------------------------------------------------------------------------
	void ClientAskSmsList()
	{
		Rpc(RpcAsk_SmsList);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_SmsList()
	{
		if (!Replication.IsServer())
			return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc)
			return;
		int playerId = pc.GetPlayerId();
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "")
			return;
		
		string encoded = BuildConversationsList(uid);
		Rpc(RpcDo_ReceiveSmsList, encoded);
	}
	
	//------------------------------------------------------------------------------------------------
	// SERVER : construit la liste encodee des conversations pour le menu Inbox
	// Format : "uid1|displayname1|unread1|lastTs1|preview1\nuid2|...."
	//------------------------------------------------------------------------------------------------
	string BuildConversationsList(string ownerUID)
	{
		JobSmsInbox inbox = JobSmsManager.GetInstance().GetInbox(ownerUID);
		if (!inbox || inbox.m_Messages.Count() == 0)
			return "";
		
		// Group by other UID. On prend le dernier message + compte non lus pour chaque conversation.
		map<string, ref JobSmsConvSummary> summaries = new map<string, ref JobSmsConvSummary>();
		
		foreach (JobSmsMessage m : inbox.m_Messages)
		{
			if (!m) continue;
			string otherUID;
			string otherName;
			if (m.m_FromUID == ownerUID)
			{
				otherUID = m.m_ToUID;
				otherName = m.m_ToDisplayName;
			}
			else
			{
				otherUID = m.m_FromUID;
				otherName = m.m_FromDisplayName;
			}
			
			JobSmsConvSummary sum = summaries.Get(otherUID);
			if (!sum)
			{
				sum = new JobSmsConvSummary();
				sum.m_OtherUID = otherUID;
				sum.m_OtherName = otherName;
				summaries.Set(otherUID, sum);
			}
			
			// Compteur non lus (uniquement messages recus)
			if (m.m_FromUID == otherUID && !m.m_Read)
				sum.m_UnreadCount++;
			
			// Garde le dernier message (le plus recent timestamp)
			if (m.m_Timestamp > sum.m_LastTimestamp)
			{
				sum.m_LastTimestamp = m.m_Timestamp;
				sum.m_LastPreview = m.m_Content;
			}
		}
		
		// Encode chaque conversation
		string result = "";
		foreach (string uid, JobSmsConvSummary sum : summaries)
		{
			if (!sum) continue;
			string preview = sum.m_LastPreview;
			if (preview.Length() > 40)
				preview = preview.Substring(0, 40) + "...";
			
			result = result + sum.m_OtherUID + "|" + sum.m_OtherName + "|"
				+ sum.m_UnreadCount.ToString() + "|"
				+ sum.m_LastTimestamp.ToString() + "|"
				+ preview + "\n";
		}
		return result;
	}
	
	//------------------------------------------------------------------------------------------------
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_ReceiveSmsList(string encoded)
	{
		JobSmsInboxMenu menu = JobSmsInboxMenu.GetOpenMenu();
		if (menu)
			menu.DisplayConversations(encoded);
	}
	
	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : demande l historique d une conversation specifique
	// - page : 0-indexed, la page a recuperer (0 = plus recents)
	//------------------------------------------------------------------------------------------------
	void ClientAskSmsConversation(string otherUID, int page = 0)
	{
		Rpc(RpcAsk_SmsConversation, otherUID, page);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_SmsConversation(string otherUID, int page)
	{
		if (!Replication.IsServer())
			return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc)
			return;
		int playerId = pc.GetPlayerId();
		string ownerUID = JobManager.GetInstance().GetPersistentUID(playerId);
		if (ownerUID == "")
			return;
		
		// Marque cette conversation comme lue (cote serveur, page 0 uniquement pour eviter
		// de re-marquer a chaque changement de page)
		if (page == 0)
			JobSmsManager.GetInstance().MarkConversationAsRead(ownerUID, otherUID);
		
		// Construit l historique formate avec pagination
		// Format retourne : "currentPage|totalPages|historyText"
		string history = BuildConversationHistoryPaginated(ownerUID, otherUID, page, 30);
		
		// Resout le playerId du destinataire (pour pouvoir repondre)
		int otherPlayerId = ResolvePlayerIdFromUID(otherUID);
		
		Rpc(RpcDo_ReceiveSmsConversation, history, otherPlayerId);
	}
	
	//------------------------------------------------------------------------------------------------
	// SERVER : assemble l historique formate (VERSION PAGINEE)
	// Format retourne : "currentPage|totalPages|historyText"
	// - Les messages sont tries du plus recent au plus ancien pour la logique de pagination
	//   (page 0 = 30 messages les plus recents), mais reaffiches en ordre chrono dans le texte.
	//------------------------------------------------------------------------------------------------
	string BuildConversationHistoryPaginated(string ownerUID, string otherUID, int page, int perPage)
	{
		JobSmsInbox inbox = JobSmsManager.GetInstance().GetInbox(ownerUID);
		if (!inbox)
			return "0|0|";
		
		// Collecte tous les messages de la conversation
		array<ref JobSmsMessage> convMessages = new array<ref JobSmsMessage>();
		foreach (JobSmsMessage m : inbox.m_Messages)
		{
			if (!m) continue;
			bool isWithOther = (m.m_FromUID == otherUID && m.m_ToUID == ownerUID)
				|| (m.m_FromUID == ownerUID && m.m_ToUID == otherUID);
			if (isWithOther)
				convMessages.Insert(m);
		}
		
		int total = convMessages.Count();
		if (total == 0)
			return "0|0|";
		
		int totalPages = (total + perPage - 1) / perPage;
		if (page < 0) page = 0;
		if (page >= totalPages) page = totalPages - 1;
		
		// Page 0 = les 30 messages LES PLUS RECENTS
		// La liste convMessages est ordre chronologique (ancien -> recent)
		// Donc page 0 = derniers 30, page 1 = 30 avant, etc.
		int startFromEnd = page * perPage;         // combien de messages a sauter depuis la fin
		int startIdx = total - startFromEnd - perPage;
		if (startIdx < 0) startIdx = 0;
		int endIdx = total - startFromEnd;         // exclusif
		if (endIdx > total) endIdx = total;
		
		string result = "";
		for (int i = startIdx; i < endIdx; i++)
		{
			JobSmsMessage m = convMessages.Get(i);
			if (!m) continue;
			string sender;
			if (m.m_FromUID == ownerUID)
				sender = "Moi";
			else
				sender = m.m_FromDisplayName;
			
			string timeStr = FormatTimestamp(m.m_Timestamp);
			result = result + string.Format("[%1] %2 : %3\n", timeStr, sender, m.m_Content);
		}
		
		return string.Format("%1|%2|%3", page, totalPages, result);
	}
	
	//------------------------------------------------------------------------------------------------
	// SERVER : assemble l historique formate (legacy, non pagine - conserve pour compat)
	//------------------------------------------------------------------------------------------------
	string BuildConversationHistory(string ownerUID, string otherUID)
	{
		JobSmsInbox inbox = JobSmsManager.GetInstance().GetInbox(ownerUID);
		if (!inbox)
			return "";
		
		string result = "";
		foreach (JobSmsMessage m : inbox.m_Messages)
		{
			if (!m) continue;
			// Filtre : uniquement messages avec cet autre uid (envoyes ou recus)
			bool isWithOther = (m.m_FromUID == otherUID && m.m_ToUID == ownerUID)
				|| (m.m_FromUID == ownerUID && m.m_ToUID == otherUID);
			if (!isWithOther)
				continue;
			
			string sender;
			if (m.m_FromUID == ownerUID)
				sender = "Moi";
			else
				sender = m.m_FromDisplayName;
			
			string timeStr = FormatTimestamp(m.m_Timestamp);
			result = result + string.Format("[%1] %2 : %3\n", timeStr, sender, m.m_Content);
		}
		return result;
	}
	
	//------------------------------------------------------------------------------------------------
	// SERVER : trouve le playerId actuel pour un UID
	//------------------------------------------------------------------------------------------------
	int ResolvePlayerIdFromUID(string uid)
	{
		PlayerManager pm = GetGame().GetPlayerManager();
		if (!pm)
			return 0;
		array<int> all = new array<int>();
		pm.GetPlayers(all);
		foreach (int pid : all)
		{
			string pidUid = JobManager.GetInstance().GetPersistentUID(pid);
			if (pidUid == uid)
				return pid;
		}
		return 0;
	}
	
	//------------------------------------------------------------------------------------------------
	// SERVER : formate un timestamp Unix en heure courte (HH:MM)
	//------------------------------------------------------------------------------------------------
	string FormatTimestamp(int unixTs)
	{
		int now = System.GetUnixTime();
		int diff = now - unixTs;
		// Si moins d 1 heure : "il y a Xmin"
		if (diff < 3600)
		{
			int mins = diff / 60;
			if (mins == 0)
				return "a l'instant";
			return string.Format("%1min", mins);
		}
		// Si moins d 1 jour : "il y a Xh"
		if (diff < 86400)
		{
			int hours = diff / 3600;
			return string.Format("%1h", hours);
		}
		// Sinon : nb jours
		int days = diff / 86400;
		return string.Format("%1j", days);
	}
	
	//------------------------------------------------------------------------------------------------
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_ReceiveSmsConversation(string history, int otherPlayerId)
	{
		JobSmsConversationMenu menu = JobSmsConversationMenu.GetOpenMenu();
		if (menu)
			menu.DisplayHistory(history, otherPlayerId);
	}
	
	//------------------------------------------------------------------------------------------------
	// ============================================================
	// SYNCHRO FLAG ADMIN (Server -> Client)
	// ============================================================
	// Permet au client local de savoir si le joueur est admin sans devoir faire une RPC
	// a chaque fois. Utilise notamment par le profil RP pour afficher le bouton Admin
	// uniquement aux admins. Le check final reste serveur-side dans RpcAsk_OpenAdminMenu.
	//------------------------------------------------------------------------------------------------
	
	//------------------------------------------------------------------------------------------------
	// SERVEUR : verifie la whitelist admin et envoie le flag au client owner
	// Appele au boot du composant via ServerInitFromJson
	//------------------------------------------------------------------------------------------------
	void Svr_PushIsAdmin()
	{
		if (!Replication.IsServer())
			return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc)
			return;
		int playerId = pc.GetPlayerId();
		if (playerId <= 0)
			return;
		
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "")
		{
			// UID pas encore pret, retry dans 2s
			GetGame().GetCallqueue().CallLater(Svr_PushIsAdmin, 2000, false);
			return;
		}
		
		bool isAdmin = JobAdminManager.GetInstance().IsAdmin(uid);
		
		Rpc(RpcDo_SetIsAdmin, isAdmin);
		// Appel local pour le host
		RpcDo_SetIsAdmin(isAdmin);
		
		Print(string.Format("[JobPlayerComponent] Svr_PushIsAdmin player=%1 uid=%2 isAdmin=%3",
			playerId, uid, isAdmin), LogLevel.NORMAL);
	}
	
	//------------------------------------------------------------------------------------------------
	// CLIENT : recoit le flag admin et le stocke localement
	//------------------------------------------------------------------------------------------------
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_SetIsAdmin(bool isAdmin)
	{
		m_ClientIsAdmin = isAdmin;
		Print(string.Format("[JobPlayerComponent] RpcDo_SetIsAdmin : m_ClientIsAdmin=%1",
			m_ClientIsAdmin), LogLevel.NORMAL);
	}

	//------------------------------------------------------------------------------------------------
	// SERVEUR : verifie si le joueur appartient a un gang et envoie le flag au client owner.
	// Appele au boot via ServerInitFromJson et apres chaque changement de statut gang
	// (CreateGang, LeaveGang, Dissolve, Recruit, Eject).
	//------------------------------------------------------------------------------------------------
	void Svr_PushIsInGang()
	{
		if (!Replication.IsServer())
			return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc)
			return;
		int playerId = pc.GetPlayerId();
		if (playerId <= 0)
			return;

		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "")
		{
			// UID pas encore pret, retry dans 2s
			GetGame().GetCallqueue().CallLater(Svr_PushIsInGang, 2000, false);
			return;
		}

		bool isInGang = (JobGangManager.GetInstance().GetGangOfPlayer(uid) != null);

		Rpc(RpcDo_SetIsInGang, isInGang);
		// Appel local pour le host
		RpcDo_SetIsInGang(isInGang);

		Print(string.Format("[JobPlayerComponent] Svr_PushIsInGang player=%1 uid=%2 isInGang=%3",
			playerId, uid, isInGang), LogLevel.NORMAL);
	}

	//------------------------------------------------------------------------------------------------
	// SERVEUR (statique) : trouve le JobPlayerComponent d un joueur par son UID et pousse
	// le flag gang vers son client. Utilise pour notifier recruted/ejected/dissolved target.
	//------------------------------------------------------------------------------------------------
	static void Svr_PushIsInGangForUID(string targetUID)
	{
		if (targetUID == "")
			return;
		if (!Replication.IsServer())
			return;

		int targetPid = JobCriminalManager.GetPlayerIdFromUID(targetUID);
		if (targetPid <= 0)
			return; // Hors ligne : rien a faire, le flag sera recalcule a sa prochaine connexion

		PlayerManager pm = GetGame().GetPlayerManager();
		if (!pm)
			return;
		PlayerController targetPc = pm.GetPlayerController(targetPid);
		if (!targetPc)
			return;

		JobPlayerComponent targetJpc = JobPlayerComponent.Cast(
			targetPc.FindComponent(JobPlayerComponent));
		if (!targetJpc)
			return;

		targetJpc.Svr_PushIsInGang();
	}

	//------------------------------------------------------------------------------------------------
	// CLIENT : recoit le flag gang et le stocke localement
	//------------------------------------------------------------------------------------------------
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_SetIsInGang(bool isInGang)
	{
		m_ClientIsInGang = isInGang;
		Print(string.Format("[JobPlayerComponent] RpcDo_SetIsInGang : m_ClientIsInGang=%1",
			m_ClientIsInGang), LogLevel.NORMAL);
	}

	//------------------------------------------------------------------------------------------------
	// Getter client : utilise par JobSellMineralsAction pour autoriser la vente de drogue
	// aux membres de gang (en plus des Voyous).
	//------------------------------------------------------------------------------------------------
	bool IsClientInGang()
	{
		return m_ClientIsInGang;
	}
	
	//------------------------------------------------------------------------------------------------
	// ============================================================
	// FICHE JUDICIAIRE AVANCEE (JobPoliceRecordManager)
	// ============================================================
	// Verifie que le caller est un officier (Police ou Militaire).
	// Renvoie true et remplit outPid/outUID/outName si OK, false sinon.
	//------------------------------------------------------------------------------------------------
	bool IsCallerOfficer(out int outPid, out string outUID, out string outName)
	{
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc)
			return false;
		outPid = pc.GetPlayerId();
		if (outPid <= 0)
			return false;
		JobPlayerData d = JobManager.GetInstance().GetPlayerData(outPid);
		if (!d)
			return false;
		if (d.m_Job != EJobType.POLICIER && d.m_Job != EJobType.MILITAIRE)
			return false;
		outUID = JobManager.GetInstance().GetPersistentUID(outPid);
		outName = JobIdentityManager.GetInstance().GetDisplayNameByPlayerId(outPid);
		if (outName == "")
			outName = "Agent " + outPid.ToString();
		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	// RECHERCHE
	//------------------------------------------------------------------------------------------------
	void ClientAskPoliceSearch(string query)
	{
		Rpc(RpcAsk_PoliceSearch, query);
	}
	
	//------------------------------------------------------------------------------------------------
	// Helper : resout le nom RP d un joueur par son UID (offline OK), sinon fallback
	// utilise pour uniformiser l affichage dans la recherche + la fiche judiciaire.
	//------------------------------------------------------------------------------------------------
	string ResolveRpName(string uid, string fallback)
	{
		if (uid == "")
			return fallback;
		if (JobIdentityManager.GetInstance().HasIdentity(uid))
		{
			JobRpIdentity id = JobIdentityManager.GetInstance().GetIdentity(uid);
			if (id && (id.m_FirstName != "" || id.m_LastName != ""))
				return id.m_FirstName + " " + id.m_LastName;
		}
		return fallback;
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_PoliceSearch(string query)
	{
		if (!Replication.IsServer())
			return;
		int pid; string uid; string name;
		if (!IsCallerOfficer(pid, uid, name))
			return;

		// === DETECTION PLAQUE D IMMATRICULATION ===
		// Si la query ressemble a une plaque FR (AB-123-CD ou AB123CD sans tirets),
		// on tente le lookup : plaque -> UUID vehicule -> proprietaire UID.
		// Si trouve, on remplace la query par l UID du proprietaire : la suite de la
		// recherche affichera son dossier dans PoliceRecord / CriminalRecord / PlayerManager.
		// Si pas trouve, on continue avec la query d origine (recherche classique).
		string plateCandidate;
		if (TryExtractPlateFromQuery(query, plateCandidate))
		{
			string vehicleUUID = JobLicensePlateManager.GetInstance().GetUUIDForPlate(plateCandidate);
			if (vehicleUUID != "")
			{
				string ownerUID = JobVirtualGarageManager.GetInstance().GetOwnerUIDFromVehicleUUID(vehicleUUID);
				if (ownerUID != "")
				{
					Print(string.Format("[PoliceSearch] Plaque %1 -> UUID %2 -> owner %3",
						plateCandidate, vehicleUUID, ownerUID), LogLevel.NORMAL);
					query = ownerUID;
				}
				else
				{
					Print(string.Format("[PoliceSearch] Plaque %1 trouvee (UUID=%2) mais pas de proprietaire connu",
						plateCandidate, vehicleUUID), LogLevel.WARNING);
				}
			}
		}

		// Recherche multi-sources : on unifie les resultats venus de 3 endroits :
		//   1. PoliceRecord (dossiers judiciaires deja crees)
		//   2. CriminalRecord (casiers criminels - contient TOUS les joueurs ayant deja
		//      eu au moins une amende, une prison, ou un vol dans leur historique)
		//   3. PlayerManager (joueurs actuellement connectes - permet de cibler un nouveau
		//      joueur sans historique)
		// On indexe par UID pour eviter les doublons.
		string queryLower = query;
		queryLower.ToLower();
		
		// Map UID -> (name, statusVal) - evite les doublons
		// On maintient un array parallele des UIDs pour garder l ordre d insertion
		// (Enforce n a pas GetElementFromIndex sur map<string,string>)
		ref map<string, string> foundNames = new map<string, string>();
		ref map<string, int> foundStatuses = new map<string, int>();
		ref array<string> foundOrder = new array<string>();
		const int MAX_RESULTS = 20;
		
		// --- Source 1 : PoliceRecord ---
		array<ref PoliceRecord> policeResults = new array<ref PoliceRecord>();
		JobPoliceRecordManager.GetInstance().SearchRecords(query, MAX_RESULTS, policeResults);
		foreach (PoliceRecord pr : policeResults)
		{
			if (!pr) continue;
			if (foundNames.Contains(pr.m_PlayerUID)) continue;
			string prRpName = ResolveRpName(pr.m_PlayerUID, pr.m_PlayerName);
			foundNames.Set(pr.m_PlayerUID, prRpName);
			foundStatuses.Set(pr.m_PlayerUID, pr.m_Status);
			foundOrder.Insert(pr.m_PlayerUID);
		}
		
		// --- Source 2 : CriminalRecord ---
		JobCriminalManager cm = JobCriminalManager.GetInstance();
		if (cm && cm.m_Records)
		{
			int crimCount = cm.m_Records.Count();
			for (int i = 0; i < crimCount && foundOrder.Count() < MAX_RESULTS; i++)
			{
				CriminalRecord cr = cm.m_Records.GetElement(i);
				if (!cr || cr.m_PlayerUID == "") continue;
				if (foundNames.Contains(cr.m_PlayerUID)) continue;  // deja dans PoliceRecord
				
				string crRpName = ResolveRpName(cr.m_PlayerUID, cr.m_PlayerName);
				string crRpNameLower = crRpName;
				crRpNameLower.ToLower();
				bool matches = (query == "")
					|| crRpNameLower.Contains(queryLower)
					|| cr.m_PlayerUID.Contains(query);
				if (!matches) continue;
				
				foundNames.Set(cr.m_PlayerUID, crRpName);
				foundStatuses.Set(cr.m_PlayerUID, 0);
				foundOrder.Insert(cr.m_PlayerUID);
			}
		}
		
		// --- Source 3 : Joueurs connectes actuellement ---
		PlayerManager pmMgr = GetGame().GetPlayerManager();
		if (pmMgr)
		{
			array<int> playerIds = new array<int>();
			pmMgr.GetPlayers(playerIds);
			foreach (int pidCandidate : playerIds)
			{
				if (foundOrder.Count() >= MAX_RESULTS)
					break;
				string candidateUID = JobManager.GetInstance().GetPersistentUID(pidCandidate);
				if (candidateUID == "") continue;
				if (foundNames.Contains(candidateUID)) continue;
				
				// Nom RP en priorite, sinon pseudo BI de secours
				string fallbackName = pmMgr.GetPlayerName(pidCandidate);
				string candidateName = ResolveRpName(candidateUID, fallbackName);
				
				string cNameLower = candidateName;
				cNameLower.ToLower();
				bool matches = (query == "")
					|| cNameLower.Contains(queryLower)
					|| candidateUID.Contains(query);
				if (!matches) continue;
				
				foundNames.Set(candidateUID, candidateName);
				foundStatuses.Set(candidateUID, 0);
				foundOrder.Insert(candidateUID);
			}
		}
		
		// Serialise en 3 strings paralleles (uids|names|statuses)
		// On itere via foundOrder pour garder l ordre d insertion
		string uidsStr = "";
		string namesStr = "";
		string statusesStr = "";
		int totalFound = foundOrder.Count();
		for (int i = 0; i < totalFound; i++)
		{
			string foundUID = foundOrder.Get(i);
			string foundName = foundNames.Get(foundUID);
			int foundStatus = foundStatuses.Get(foundUID);
			if (i > 0)
			{
				uidsStr = uidsStr + "|";
				namesStr = namesStr + "###";
				statusesStr = statusesStr + "|";
			}
			uidsStr = uidsStr + foundUID;
			namesStr = namesStr + foundName;
			statusesStr = statusesStr + foundStatus.ToString();
		}
		Rpc(RpcDo_PoliceSearchResults, uidsStr, namesStr, statusesStr);
	}

	//------------------------------------------------------------------------------------------------
	// Tente d extraire une plaque d immatriculation FR (AB-123-CD) de la query utilisateur.
	// Accepte :
	//   - 9 caracteres avec tirets aux positions 2 et 6 ("AB-123-CD", "ab-123-cd")
	//   - 7 caracteres sans tirets ("AB123CD", "ab123cd") -> reformate en "AB-123-CD"
	// Retourne true + plaque normalisee (majuscules, format AB-123-CD) si la query ressemble
	// a une plaque. Retourne false si format non reconnu (continuera en recherche classique).
	// NOTE : on ne verifie PAS que les chars sont lettre/chiffre (couteux en Enforce).
	// Si le format matche mais que la plaque n existe pas dans le registre, le lookup
	// renvoie "" et la recherche retombe sur le mode classique.
	//------------------------------------------------------------------------------------------------
	bool TryExtractPlateFromQuery(string query, out string outPlate)
	{
		outPlate = "";
		if (query == "")
			return false;

		string s = query;
		s.ToUpper();
		int len = s.Length();

		// Cas 1 : 9 chars avec tirets aux positions 2 et 6 -> AB-123-CD
		if (len == 9 && s.Get(2) == "-" && s.Get(6) == "-")
		{
			outPlate = s;
			return true;
		}

		// Cas 2 : 7 chars sans tirets -> on reformate
		if (len == 7)
		{
			outPlate = s.Substring(0, 2) + "-" + s.Substring(2, 3) + "-" + s.Substring(5, 2);
			return true;
		}

		return false;
	}

	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_PoliceSearchResults(string uidsStr, string namesStr, string statusesStr)
	{
		JobPoliceRecordMenu menu = JobPoliceRecordMenu.GetOpenMenu();
		if (!menu) return;
		array<string> uids = new array<string>();
		array<string> names = new array<string>();
		array<int> statuses = new array<int>();
		if (uidsStr != "")
		{
			PoliceSplitByDelim(uidsStr, "|", uids);
			PoliceSplitByDelim(namesStr, "###", names);
			array<string> sp = new array<string>();
			PoliceSplitByDelim(statusesStr, "|", sp);
			foreach (string s : sp) statuses.Insert(s.ToInt());
		}
		menu.DisplaySearchResults(uids, names, statuses);
	}
	
	//------------------------------------------------------------------------------------------------
	// Helper local : split par delimiteur multi-caracteres (Enforce n a pas string.Split)
	// Nomme "Police" pour eviter les collisions avec les autres helpers presents dans le fichier.
	//------------------------------------------------------------------------------------------------
	void PoliceSplitByDelim(string source, string delim, out array<string> outResult)
	{
		if (source == "")
			return;
		int dlen = delim.Length();
		while (true)
		{
			int idx = source.IndexOf(delim);
			if (idx < 0)
			{
				outResult.Insert(source);
				return;
			}
			outResult.Insert(source.Substring(0, idx));
			int rest = source.Length() - idx - dlen;
			if (rest <= 0)
				return;
			source = source.Substring(idx + dlen, rest);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// GET RECORD (header + peines + mandats + notes)
	// Envoie 4 RPCs distincts pour eviter les payloads trop grosses
	//------------------------------------------------------------------------------------------------
	void ClientAskPoliceGetRecord(string uid)
	{
		Rpc(RpcAsk_PoliceGetRecord, uid);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_PoliceGetRecord(string uid)
	{
		if (!Replication.IsServer())
			return;
		int pid; string officerUID; string officerName;
		if (!IsCallerOfficer(pid, officerUID, officerName))
			return;
		
		PoliceRecord r = JobPoliceRecordManager.GetInstance().GetRecord(uid);
		if (!r)
		{
			// Si pas de dossier, envoie header vide (client va rester en "chargement...")
			Rpc(RpcDo_PoliceHeader, uid, "(aucun dossier)", 0, "", 0, 0, System.GetUnixTime());
			return;
		}
		
		int now = System.GetUnixTime();
		int rehab = JobPoliceRecordManager.GetInstance().GetRehabTimestamp(uid);
		string headerName = ResolveRpName(uid, r.m_PlayerName);
		Rpc(RpcDo_PoliceHeader, uid, headerName, r.m_Status, r.m_StatusDetail,
			r.m_LastConvictionTimestamp, rehab, now);
		
		// Push peines
		string sentencesStr = "";
		for (int i = 0; i < r.m_Sentences.Count(); i++)
		{
			SentenceRecord s = r.m_Sentences.Get(i);
			if (!s) continue;
			if (i > 0) sentencesStr = sentencesStr + "|||";
			// Format : idx@@charge@@duration@@issued@@active@@issuer
			string activeStr = "0";
			if (s.m_Active) activeStr = "1";
			sentencesStr = sentencesStr + i.ToString() + "@@" + s.m_Charge + "@@"
				+ s.m_DurationDays.ToString() + "@@" + s.m_IssuedTimestamp.ToString()
				+ "@@" + activeStr + "@@" + s.m_IssuerName;
		}
		Rpc(RpcDo_PoliceSentences, uid, sentencesStr);
		
		// Push mandats
		string warrantsStr = "";
		for (int i = 0; i < r.m_Warrants.Count(); i++)
		{
			WarrantRecord w = r.m_Warrants.Get(i);
			if (!w) continue;
			if (i > 0) warrantsStr = warrantsStr + "|||";
			string activeStr = "0";
			if (w.m_Active) activeStr = "1";
			warrantsStr = warrantsStr + i.ToString() + "@@" + w.m_Type.ToString() + "@@"
				+ w.m_Motive + "@@" + w.m_IssuedTimestamp.ToString() + "@@"
				+ w.m_ExpiresTimestamp.ToString() + "@@" + activeStr + "@@" + w.m_IssuerName;
		}
		Rpc(RpcDo_PoliceWarrants, uid, warrantsStr);
		
		// Push notes
		string notesStr = "";
		for (int i = 0; i < r.m_Notes.Count(); i++)
		{
			OfficerNote n = r.m_Notes.Get(i);
			if (!n) continue;
			if (i > 0) notesStr = notesStr + "|||";
			notesStr = notesStr + i.ToString() + "@@" + n.m_Text + "@@"
				+ n.m_Timestamp.ToString() + "@@" + n.m_AuthorName;
		}
		Rpc(RpcDo_PoliceNotes, uid, notesStr);
		
		// Push infractions (basees sur CriminalRecord/FineRecord)
		string infractionsStr = "";
		CriminalRecord crimRec = JobCriminalManager.GetInstance().GetRecord(uid);
		if (crimRec)
		{
			for (int i = 0; i < crimRec.m_Fines.Count(); i++)
			{
				FineRecord f = crimRec.m_Fines.Get(i);
				if (!f) continue;
				if (infractionsStr != "") infractionsStr = infractionsStr + "|||";
				string paidStr = "0";
				if (f.m_Paid) paidStr = "1";
				// Format : idx@@gravity@@level@@amount@@issued@@paid@@issuer@@evidence
				infractionsStr = infractionsStr + i.ToString() + "@@" + f.m_Gravity.ToString()
					+ "@@" + f.m_Level.ToString() + "@@" + f.m_Amount.ToString()
					+ "@@" + f.m_IssuedTimestamp.ToString() + "@@" + paidStr
					+ "@@" + f.m_IssuerName + "@@" + f.m_Evidence;
			}
		}
		Rpc(RpcDo_PoliceInfractions, uid, infractionsStr);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_PoliceHeader(string uid, string name, int status, string statusDetail,
		int lastConviction, int rehabTs, int nowTs)
	{
		JobPoliceRecordMenu menu = JobPoliceRecordMenu.GetOpenMenu();
		if (menu)
			menu.DisplayRecordHeader(uid, name, status, statusDetail, lastConviction, rehabTs, nowTs);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_PoliceSentences(string uid, string sentencesStr)
	{
		JobPoliceRecordMenu menu = JobPoliceRecordMenu.GetOpenMenu();
		if (menu)
			menu.DisplaySentences(uid, sentencesStr);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_PoliceWarrants(string uid, string warrantsStr)
	{
		JobPoliceRecordMenu menu = JobPoliceRecordMenu.GetOpenMenu();
		if (menu)
			menu.DisplayWarrants(uid, warrantsStr);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_PoliceNotes(string uid, string notesStr)
	{
		JobPoliceRecordMenu menu = JobPoliceRecordMenu.GetOpenMenu();
		if (menu)
			menu.DisplayNotes(uid, notesStr);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_PoliceInfractions(string uid, string infractionsStr)
	{
		JobPoliceRecordMenu menu = JobPoliceRecordMenu.GetOpenMenu();
		if (menu)
			menu.DisplayInfractions(uid, infractionsStr);
	}
	
	//------------------------------------------------------------------------------------------------
	// CRUD INFRACTIONS - Met a jour gravity + evidence sur une amende existante
	// (les amendes sont creees par le systeme d amendes existant, ici on ajoute juste
	// les metadonnees judiciaires)
	//------------------------------------------------------------------------------------------------
	void ClientAskPoliceUpdateInfraction(string uid, int index, int gravity, string evidence)
	{
		Rpc(RpcAsk_PoliceUpdateInfraction, uid, index, gravity, evidence);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_PoliceUpdateInfraction(string uid, int index, int gravity, string evidence)
	{
		if (!Replication.IsServer())
			return;
		int pid; string officerUID; string officerName;
		if (!IsCallerOfficer(pid, officerUID, officerName))
			return;
		CriminalRecord crimRec = JobCriminalManager.GetInstance().GetRecord(uid);
		if (!crimRec)
			return;
		if (index < 0 || index >= crimRec.m_Fines.Count())
			return;
		FineRecord f = crimRec.m_Fines.Get(index);
		if (!f)
			return;
		f.m_Gravity = gravity;
		f.m_Evidence = evidence;
		JobCriminalManager.GetInstance().SaveToDisk();
		RpcAsk_PoliceGetRecord(uid);
	}
	
	//------------------------------------------------------------------------------------------------
	// SET STATUS
	//------------------------------------------------------------------------------------------------
	void ClientAskPoliceSetStatus(string uid, int status, string detail)
	{
		Rpc(RpcAsk_PoliceSetStatus, uid, status, detail);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_PoliceSetStatus(string uid, int status, string detail)
	{
		if (!Replication.IsServer())
			return;
		int pid; string officerUID; string officerName;
		if (!IsCallerOfficer(pid, officerUID, officerName))
			return;
		JobPoliceRecordManager.GetInstance().GetOrCreateRecord(uid, "");
		JobPoliceRecordManager.GetInstance().SetStatus(uid, status, detail);
		// Re-push le header pour rafraichir
		RpcAsk_PoliceGetRecord(uid);
	}
	
	void ClientAskPoliceSetStatusDetail(string uid, string detail)
	{
		Rpc(RpcAsk_PoliceSetStatusDetail, uid, detail);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_PoliceSetStatusDetail(string uid, string detail)
	{
		if (!Replication.IsServer())
			return;
		int pid; string officerUID; string officerName;
		if (!IsCallerOfficer(pid, officerUID, officerName))
			return;
		PoliceRecord r = JobPoliceRecordManager.GetInstance().GetRecord(uid);
		if (!r) return;
		JobPoliceRecordManager.GetInstance().SetStatus(uid, r.m_Status, detail);
		RpcAsk_PoliceGetRecord(uid);
	}
	
	//------------------------------------------------------------------------------------------------
	// CRUD PEINES
	//------------------------------------------------------------------------------------------------
	void ClientAskPoliceAddSentence(string uid, string charge, int durationDays)
	{
		Rpc(RpcAsk_PoliceAddSentence, uid, charge, durationDays);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_PoliceAddSentence(string uid, string charge, int durationDays)
	{
		if (!Replication.IsServer())
			return;
		int pid; string officerUID; string officerName;
		if (!IsCallerOfficer(pid, officerUID, officerName))
			return;
		JobPoliceRecordManager.GetInstance().GetOrCreateRecord(uid, "");
		JobPoliceRecordManager.GetInstance().AddSentence(uid, charge, durationDays, officerName, officerUID);
		RpcAsk_PoliceGetRecord(uid);
	}
	
	void ClientAskPoliceRemoveSentence(string uid, int index)
	{
		Rpc(RpcAsk_PoliceRemoveSentence, uid, index);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_PoliceRemoveSentence(string uid, int index)
	{
		if (!Replication.IsServer())
			return;
		int pid; string officerUID; string officerName;
		if (!IsCallerOfficer(pid, officerUID, officerName))
			return;
		JobPoliceRecordManager.GetInstance().RemoveSentence(uid, index);
		RpcAsk_PoliceGetRecord(uid);
	}
	
	//------------------------------------------------------------------------------------------------
	// CRUD MANDATS
	//------------------------------------------------------------------------------------------------
	void ClientAskPoliceAddWarrant(string uid, int type, string motive, int durationDays)
	{
		Rpc(RpcAsk_PoliceAddWarrant, uid, type, motive, durationDays);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_PoliceAddWarrant(string uid, int type, string motive, int durationDays)
	{
		if (!Replication.IsServer())
			return;
		int pid; string officerUID; string officerName;
		if (!IsCallerOfficer(pid, officerUID, officerName))
			return;
		JobPoliceRecordManager.GetInstance().GetOrCreateRecord(uid, "");
		JobPoliceRecordManager.GetInstance().AddWarrant(uid, type, motive, durationDays, officerName, officerUID);
		RpcAsk_PoliceGetRecord(uid);
	}
	
	void ClientAskPoliceRemoveWarrant(string uid, int index)
	{
		Rpc(RpcAsk_PoliceRemoveWarrant, uid, index);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_PoliceRemoveWarrant(string uid, int index)
	{
		if (!Replication.IsServer())
			return;
		int pid; string officerUID; string officerName;
		if (!IsCallerOfficer(pid, officerUID, officerName))
			return;
		JobPoliceRecordManager.GetInstance().RemoveWarrant(uid, index);
		RpcAsk_PoliceGetRecord(uid);
	}
	
	//------------------------------------------------------------------------------------------------
	// CRUD NOTES
	//------------------------------------------------------------------------------------------------
	void ClientAskPoliceAddNote(string uid, string text)
	{
		Rpc(RpcAsk_PoliceAddNote, uid, text);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_PoliceAddNote(string uid, string text)
	{
		if (!Replication.IsServer())
			return;
		int pid; string officerUID; string officerName;
		if (!IsCallerOfficer(pid, officerUID, officerName))
			return;
		JobPoliceRecordManager.GetInstance().GetOrCreateRecord(uid, "");
		JobPoliceRecordManager.GetInstance().AddNote(uid, text, officerName, officerUID);
		RpcAsk_PoliceGetRecord(uid);
	}
	
	void ClientAskPoliceRemoveNote(string uid, int index)
	{
		Rpc(RpcAsk_PoliceRemoveNote, uid, index);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_PoliceRemoveNote(string uid, int index)
	{
		if (!Replication.IsServer())
			return;
		int pid; string officerUID; string officerName;
		if (!IsCallerOfficer(pid, officerUID, officerName))
			return;
		JobPoliceRecordManager.GetInstance().RemoveNote(uid, index);
		RpcAsk_PoliceGetRecord(uid);
	}
	
	//------------------------------------------------------------------------------------------------
	// ============================================================
	// FICHE MEDICALE PATIENT (JobMedicalManager)
	// ============================================================
	// Verifie que le caller est un medecin (EMS).
	//------------------------------------------------------------------------------------------------
	bool IsCallerMedecin(out int outPid, out string outUID, out string outName)
	{
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc)
			return false;
		outPid = pc.GetPlayerId();
		if (outPid <= 0)
			return false;
		JobPlayerData d = JobManager.GetInstance().GetPlayerData(outPid);
		if (!d)
			return false;
		if (d.m_Job != EJobType.MEDECIN)
			return false;
		outUID = JobManager.GetInstance().GetPersistentUID(outPid);
		outName = JobIdentityManager.GetInstance().GetDisplayNameByPlayerId(outPid);
		if (outName == "")
			outName = "Medecin " + outPid.ToString();
		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	// RECHERCHE PATIENT (par nom RP, UID ou N dossier)
	// Multi-sources : dossiers existants + joueurs connectes
	//------------------------------------------------------------------------------------------------
	void ClientAskMedicalSearch(string query)
	{
		Rpc(RpcAsk_MedicalSearch, query);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_MedicalSearch(string query)
	{
		if (!Replication.IsServer())
			return;
		int pid; string uid; string name;
		if (!IsCallerMedecin(pid, uid, name))
			return;
		
		string queryLower = query;
		queryLower.ToLower();
		
		ref map<string, string> foundNames = new map<string, string>();
		ref map<string, string> foundFileNums = new map<string, string>();
		ref array<string> foundOrder = new array<string>();
		const int MAX_RESULTS = 20;
		
		// Source 1 : dossiers medicaux existants
		array<string> uids0 = new array<string>();
		array<string> names0 = new array<string>();
		array<string> fnums0 = new array<string>();
		JobMedicalManager.GetInstance().SearchRecords(query, MAX_RESULTS, uids0, names0, fnums0);
		for (int i = 0; i < uids0.Count(); i++)
		{
			string u0 = uids0.Get(i);
			if (foundNames.Contains(u0)) continue;
			string rpName = ResolveRpName(u0, names0.Get(i));
			foundNames.Set(u0, rpName);
			foundFileNums.Set(u0, fnums0.Get(i));
			foundOrder.Insert(u0);
		}
		
		// Source 2 : joueurs connectes
		PlayerManager pmMgr = GetGame().GetPlayerManager();
		if (pmMgr)
		{
			array<int> playerIds = new array<int>();
			pmMgr.GetPlayers(playerIds);
			foreach (int pidCandidate : playerIds)
			{
				if (foundOrder.Count() >= MAX_RESULTS)
					break;
				string candidateUID = JobManager.GetInstance().GetPersistentUID(pidCandidate);
				if (candidateUID == "") continue;
				if (foundNames.Contains(candidateUID)) continue;
				
				string fallbackName = pmMgr.GetPlayerName(pidCandidate);
				string candidateName = ResolveRpName(candidateUID, fallbackName);
				
				string cNameLower = candidateName;
				cNameLower.ToLower();
				bool matches = (query == "")
					|| cNameLower.Contains(queryLower)
					|| candidateUID.Contains(query);
				if (!matches) continue;
				
				foundNames.Set(candidateUID, candidateName);
				foundFileNums.Set(candidateUID, "(aucun)");
				foundOrder.Insert(candidateUID);
			}
		}
		
		// Serialise en 3 strings paralleles
		string uidsStr = "";
		string namesStr = "";
		string fnumsStr = "";
		int totalFound = foundOrder.Count();
		for (int i = 0; i < totalFound; i++)
		{
			string fUID = foundOrder.Get(i);
			if (i > 0)
			{
				uidsStr = uidsStr + "|";
				namesStr = namesStr + "###";
				fnumsStr = fnumsStr + "|";
			}
			uidsStr = uidsStr + fUID;
			namesStr = namesStr + foundNames.Get(fUID);
			fnumsStr = fnumsStr + foundFileNums.Get(fUID);
		}
		Rpc(RpcDo_MedicalSearchResults, uidsStr, namesStr, fnumsStr);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_MedicalSearchResults(string uidsStr, string namesStr, string fnumsStr)
	{
		JobMedicalMenu menu = JobMedicalMenu.GetOpenMenu();
		if (!menu) return;
		array<string> uids = new array<string>();
		array<string> names = new array<string>();
		array<string> fnums = new array<string>();
		if (uidsStr != "")
		{
			PoliceSplitByDelim(uidsStr, "|", uids);
			PoliceSplitByDelim(namesStr, "###", names);
			PoliceSplitByDelim(fnumsStr, "|", fnums);
		}
		menu.DisplaySearchResults(uids, names, fnums);
	}
	
	//------------------------------------------------------------------------------------------------
	// GET RECORD (header + sante + infos med + soins + hospit + journal)
	// Envoie plusieurs RPCs distincts
	//------------------------------------------------------------------------------------------------
	void ClientAskMedicalGetRecord(string uid)
	{
		Rpc(RpcAsk_MedicalGetRecord, uid);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_MedicalGetRecord(string uid)
	{
		if (!Replication.IsServer())
			return;
		int callerPid; string callerUID; string callerName;
		if (!IsCallerMedecin(callerPid, callerUID, callerName))
			return;
		
		// Cree le dossier si absent (avec entree CONSULTATION dans le journal)
		string patientRpName = ResolveRpName(uid, "Patient inconnu");
		MedicalRecord rec = JobMedicalManager.GetInstance().GetOrCreateRecord(uid, patientRpName,
			callerName, callerUID);
		if (!rec)
			return;
		
		// Log consultation
		JobMedicalManager.GetInstance().LogAction(uid, EJournalActionType.CONSULTATION,
			string.Format("Consultation par %1", callerName),
			callerName, callerUID);
		
		// Header
		Rpc(RpcDo_MedicalHeader, uid, rec.m_PatientName, rec.m_FileNumber,
			rec.m_DateOfBirth, rec.m_Sex, rec.m_BloodType, rec.m_CreationTimestamp);
		
		// Sante - packe en string pour respecter la limite de parametres Rpc (9 max)
		// Format : lifePct@@bloodPct@@syncTs@@fract@@hemor@@pain@@temp@@pulse@@press@@o2
		// IMPORTANT : Enforce Script a une limite de complexite d expression, on decoupe.
		if (rec.m_Health)
		{
			string healthData = rec.m_Health.m_LifePercent.ToString();
			healthData = healthData + "@@" + rec.m_Health.m_BloodPercent.ToString();
			healthData = healthData + "@@" + rec.m_Health.m_LastSyncTimestamp.ToString();
			healthData = healthData + "@@" + rec.m_Health.m_Fractures.ToString();
			healthData = healthData + "@@" + rec.m_Health.m_Hemorrhages.ToString();
			healthData = healthData + "@@" + rec.m_Health.m_PainLevel.ToString();
			healthData = healthData + "@@" + rec.m_Health.m_Temperature.ToString();
			healthData = healthData + "@@" + rec.m_Health.m_Pulse.ToString();
			healthData = healthData + "@@" + rec.m_Health.m_BloodPressure;
			healthData = healthData + "@@" + rec.m_Health.m_OxygenSaturation.ToString();
			Rpc(RpcDo_MedicalHealth, uid, healthData);
		}
		
		// Infos med
		Rpc(RpcDo_MedicalInfo, uid, rec.m_Allergies, rec.m_KnownDiseases, rec.m_CurrentTreatments);
		
		// Soins : idx@@ts@@medName@@motif@@diag@@soins@@meds@@cout
		string soinsStr = "";
		for (int i = 0; i < rec.m_Soins.Count(); i++)
		{
			SoinRecord s = rec.m_Soins.Get(i);
			if (!s) continue;
			if (i > 0) soinsStr = soinsStr + "|||";
			soinsStr = soinsStr + i.ToString() + "@@" + s.m_Timestamp.ToString() + "@@"
				+ s.m_MedecinName + "@@" + s.m_Motif + "@@" + s.m_Diagnostic + "@@"
				+ s.m_SoinsRealises + "@@" + s.m_Medicaments;
		}
		Rpc(RpcDo_MedicalSoins, uid, soinsStr);
		
		// Hospit : idx@@chambre@@entry@@exit@@medName@@cr@@ordo@@active
		string hospitStr = "";
		for (int i = 0; i < rec.m_Hospitalizations.Count(); i++)
		{
			HospitalizationRecord h = rec.m_Hospitalizations.Get(i);
			if (!h) continue;
			if (i > 0) hospitStr = hospitStr + "|||";
			string activeStr = "0";
			if (h.m_Active) activeStr = "1";
			hospitStr = hospitStr + i.ToString() + "@@" + h.m_Chambre + "@@"
				+ h.m_EntryTimestamp.ToString() + "@@" + h.m_ExitTimestamp.ToString() + "@@"
				+ h.m_MedecinName + "@@" + h.m_CompteRendu + "@@" + h.m_Ordonnance
				+ "@@" + activeStr;
		}
		Rpc(RpcDo_MedicalHospit, uid, hospitStr);
		
		// Journal : idx@@type@@ts@@desc@@author
		string journalStr = "";
		for (int i = 0; i < rec.m_Journal.Count(); i++)
		{
			JournalEntry j = rec.m_Journal.Get(i);
			if (!j) continue;
			if (i > 0) journalStr = journalStr + "|||";
			journalStr = journalStr + i.ToString() + "@@" + j.m_Type.ToString() + "@@"
				+ j.m_Timestamp.ToString() + "@@" + j.m_Description + "@@" + j.m_AuthorName;
		}
		Rpc(RpcDo_MedicalJournal, uid, journalStr);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_MedicalHeader(string uid, string name, string fnum, string dob,
		int sex, int blood, int createdTs)
	{
		JobMedicalMenu menu = JobMedicalMenu.GetOpenMenu();
		if (menu)
			menu.DisplayRecordHeader(uid, name, fnum, dob, sex, blood, createdTs);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_MedicalHealth(string uid, string healthData)
	{
		JobMedicalMenu menu = JobMedicalMenu.GetOpenMenu();
		if (!menu) return;
		array<string> parts = new array<string>();
		PoliceSplitByDelim(healthData, "@@", parts);
		if (parts.Count() < 10) return;
		int lifePct = parts.Get(0).ToInt();
		int bloodPct = parts.Get(1).ToInt();
		int syncTs = parts.Get(2).ToInt();
		int fract = parts.Get(3).ToInt();
		int hemor = parts.Get(4).ToInt();
		int pain = parts.Get(5).ToInt();
		float temp = parts.Get(6).ToFloat();
		int pulse = parts.Get(7).ToInt();
		string press = parts.Get(8);
		int o2 = parts.Get(9).ToInt();
		menu.DisplayHealth(uid, lifePct, bloodPct, syncTs, fract, hemor, pain, temp, pulse, press, o2);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_MedicalInfo(string uid, string allergies, string diseases, string treatments)
	{
		JobMedicalMenu menu = JobMedicalMenu.GetOpenMenu();
		if (menu)
			menu.DisplayMedInfo(uid, allergies, diseases, treatments);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_MedicalSoins(string uid, string data)
	{
		JobMedicalMenu menu = JobMedicalMenu.GetOpenMenu();
		if (menu)
			menu.DisplaySoins(uid, data);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_MedicalHospit(string uid, string data)
	{
		JobMedicalMenu menu = JobMedicalMenu.GetOpenMenu();
		if (menu)
			menu.DisplayHospit(uid, data);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_MedicalJournal(string uid, string data)
	{
		JobMedicalMenu menu = JobMedicalMenu.GetOpenMenu();
		if (menu)
			menu.DisplayJournal(uid, data);
	}
	
	//------------------------------------------------------------------------------------------------
	// SET IDENTITY
	//------------------------------------------------------------------------------------------------
	void ClientAskMedicalSetIdentity(string uid, string dob, int sex, int blood)
	{
		Rpc(RpcAsk_MedicalSetIdentity, uid, dob, sex, blood);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_MedicalSetIdentity(string uid, string dob, int sex, int blood)
	{
		if (!Replication.IsServer())
			return;
		int callerPid; string callerUID; string callerName;
		if (!IsCallerMedecin(callerPid, callerUID, callerName))
			return;
		JobMedicalManager.GetInstance().GetOrCreateRecord(uid,
			ResolveRpName(uid, "Patient"), callerName, callerUID);
		JobMedicalManager.GetInstance().SetIdentity(uid, dob, sex, blood, callerName, callerUID);
		RpcAsk_MedicalGetRecord(uid);
	}
	
	//------------------------------------------------------------------------------------------------
	// SET HEALTH MANUAL
	//------------------------------------------------------------------------------------------------
	void ClientAskMedicalSetHealthManual(string uid, int fract, int hemor, int pain,
		float temp, int pulse, string press, int o2)
	{
		// Serialise en 1 string pour respecter la limite de params Rpc.
		// Decoupe la concatenation pour eviter "Formula too complex" en Enforce Script.
		string data = fract.ToString();
		data = data + "@@" + hemor.ToString();
		data = data + "@@" + pain.ToString();
		data = data + "@@" + temp.ToString();
		data = data + "@@" + pulse.ToString();
		data = data + "@@" + press;
		data = data + "@@" + o2.ToString();
		Rpc(RpcAsk_MedicalSetHealthManual, uid, data);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_MedicalSetHealthManual(string uid, string data)
	{
		if (!Replication.IsServer())
			return;
		int callerPid; string callerUID; string callerName;
		if (!IsCallerMedecin(callerPid, callerUID, callerName))
			return;
		array<string> parts = new array<string>();
		PoliceSplitByDelim(data, "@@", parts);
		if (parts.Count() < 7)
			return;
		int fract = parts.Get(0).ToInt();
		int hemor = parts.Get(1).ToInt();
		int pain = parts.Get(2).ToInt();
		float temp = parts.Get(3).ToFloat();
		int pulse = parts.Get(4).ToInt();
		string press = parts.Get(5);
		int o2 = parts.Get(6).ToInt();
		JobMedicalManager.GetInstance().GetOrCreateRecord(uid,
			ResolveRpName(uid, "Patient"), callerName, callerUID);
		JobMedicalManager.GetInstance().SetHealthManual(uid, fract, hemor, pain, temp, pulse, press, o2,
			callerName, callerUID);
		RpcAsk_MedicalGetRecord(uid);
	}
	
	//------------------------------------------------------------------------------------------------
	// REFRESH HEALTH (sync depuis SurvivalHUD du patient)
	// Recupere Vie/Sang du patient s il est connecte, sinon garde les valeurs actuelles.
	//------------------------------------------------------------------------------------------------
	void ClientAskMedicalRefreshHealth(string uid)
	{
		Rpc(RpcAsk_MedicalRefreshHealth, uid);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_MedicalRefreshHealth(string uid)
	{
		if (!Replication.IsServer())
			return;
		int callerPid; string callerUID; string callerName;
		if (!IsCallerMedecin(callerPid, callerUID, callerName))
			return;
		JobMedicalManager.GetInstance().GetOrCreateRecord(uid,
			ResolveRpName(uid, "Patient"), callerName, callerUID);
		
		// Cherche le patient s il est connecte
		int patientPid = 0;
		PlayerManager pmMgr = GetGame().GetPlayerManager();
		if (pmMgr)
		{
			array<int> playerIds = new array<int>();
			pmMgr.GetPlayers(playerIds);
			foreach (int pidCandidate : playerIds)
			{
				string candidateUID = JobManager.GetInstance().GetPersistentUID(pidCandidate);
				if (candidateUID == uid)
				{
					patientPid = pidCandidate;
					break;
				}
			}
		}
		
		int lifePercent = 100;
		int bloodPercent = 100;
		bool synced = false;
		
		if (patientPid > 0)
		{
			// Cherche le CharacterDamageManagerComponent du patient
			IEntity patientEnt = GetGame().GetPlayerManager().GetPlayerControlledEntity(patientPid);
			if (patientEnt)
			{
				SCR_CharacterDamageManagerComponent dmg = SCR_CharacterDamageManagerComponent.Cast(
					patientEnt.FindComponent(SCR_CharacterDamageManagerComponent));
				if (dmg)
				{
					// Vie = min des hitzones non-blood / non-resilience
					float healthMax = dmg.GetMaxHealth();
					float healthCurrent = dmg.GetHealth();
					if (healthMax > 0)
						lifePercent = Math.Clamp((int)(healthCurrent / healthMax * 100.0), 0, 100);
					// Sang
					HitZone bloodHZ = dmg.GetBloodHitZone();
					if (bloodHZ)
					{
						float bMax = bloodHZ.GetMaxHealth();
						float bCur = bloodHZ.GetHealth();
						if (bMax > 0)
							bloodPercent = Math.Clamp((int)(bCur / bMax * 100.0), 0, 100);
					}
					synced = true;
				}
			}
		}
		
		if (synced)
		{
			JobMedicalManager.GetInstance().SyncHealthFromSurvival(uid, lifePercent, bloodPercent,
				callerName, callerUID);
		}
		else
		{
			JobMedicalManager.GetInstance().LogAction(uid, EJournalActionType.SYNC,
				"Sync sante impossible (patient hors ligne)",
				callerName, callerUID);
		}
		RpcAsk_MedicalGetRecord(uid);
	}
	
	//------------------------------------------------------------------------------------------------
	// SET INFO (allergies / maladies / traitements)
	//------------------------------------------------------------------------------------------------
	void ClientAskMedicalSetInfo(string uid, string allergies, string diseases, string treatments)
	{
		Rpc(RpcAsk_MedicalSetInfo, uid, allergies, diseases, treatments);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_MedicalSetInfo(string uid, string allergies, string diseases, string treatments)
	{
		if (!Replication.IsServer())
			return;
		int callerPid; string callerUID; string callerName;
		if (!IsCallerMedecin(callerPid, callerUID, callerName))
			return;
		JobMedicalManager.GetInstance().GetOrCreateRecord(uid,
			ResolveRpName(uid, "Patient"), callerName, callerUID);
		JobMedicalManager.GetInstance().SetMedicalInfo(uid, allergies, diseases, treatments,
			callerName, callerUID);
		RpcAsk_MedicalGetRecord(uid);
	}
	
	//------------------------------------------------------------------------------------------------
	// CRUD SOINS
	//------------------------------------------------------------------------------------------------
	void ClientAskMedicalAddSoin(string uid, string motif, string diag, string actes,
		string meds)
	{
		Rpc(RpcAsk_MedicalAddSoin, uid, motif, diag, actes, meds);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_MedicalAddSoin(string uid, string motif, string diag, string actes,
		string meds)
	{
		if (!Replication.IsServer())
			return;
		int callerPid; string callerUID; string callerName;
		if (!IsCallerMedecin(callerPid, callerUID, callerName))
			return;
		JobMedicalManager.GetInstance().GetOrCreateRecord(uid,
			ResolveRpName(uid, "Patient"), callerName, callerUID);
		JobMedicalManager.GetInstance().AddSoin(uid, motif, diag, actes, meds,
			callerName, callerUID);
		RpcAsk_MedicalGetRecord(uid);
	}
	
	void ClientAskMedicalRemoveSoin(string uid, int index)
	{
		Rpc(RpcAsk_MedicalRemoveSoin, uid, index);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_MedicalRemoveSoin(string uid, int index)
	{
		if (!Replication.IsServer())
			return;
		int callerPid; string callerUID; string callerName;
		if (!IsCallerMedecin(callerPid, callerUID, callerName))
			return;
		JobMedicalManager.GetInstance().RemoveSoin(uid, index, callerName, callerUID);
		RpcAsk_MedicalGetRecord(uid);
	}
	
	//------------------------------------------------------------------------------------------------
	// CRUD HOSPITALISATIONS
	//------------------------------------------------------------------------------------------------
	void ClientAskMedicalAddHospit(string uid, string chambre, string cr)
	{
		Rpc(RpcAsk_MedicalAddHospit, uid, chambre, cr);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_MedicalAddHospit(string uid, string chambre, string cr)
	{
		if (!Replication.IsServer())
			return;
		int callerPid; string callerUID; string callerName;
		if (!IsCallerMedecin(callerPid, callerUID, callerName))
			return;
		JobMedicalManager.GetInstance().GetOrCreateRecord(uid,
			ResolveRpName(uid, "Patient"), callerName, callerUID);
		JobMedicalManager.GetInstance().AddHospitalization(uid, chambre, cr, callerName, callerUID);
		RpcAsk_MedicalGetRecord(uid);
	}
	
	void ClientAskMedicalCloseHospit(string uid, int index, string ordonnance)
	{
		Rpc(RpcAsk_MedicalCloseHospit, uid, index, ordonnance);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_MedicalCloseHospit(string uid, int index, string ordonnance)
	{
		if (!Replication.IsServer())
			return;
		int callerPid; string callerUID; string callerName;
		if (!IsCallerMedecin(callerPid, callerUID, callerName))
			return;
		JobMedicalManager.GetInstance().CloseHospitalization(uid, index, ordonnance,
			callerName, callerUID);
		RpcAsk_MedicalGetRecord(uid);
	}
	
	void ClientAskMedicalRemoveHospit(string uid, int index)
	{
		Rpc(RpcAsk_MedicalRemoveHospit, uid, index);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_MedicalRemoveHospit(string uid, int index)
	{
		if (!Replication.IsServer())
			return;
		int callerPid; string callerUID; string callerName;
		if (!IsCallerMedecin(callerPid, callerUID, callerName))
			return;
		JobMedicalManager.GetInstance().RemoveHospitalization(uid, index, callerName, callerUID);
		RpcAsk_MedicalGetRecord(uid);
	}
	
	//------------------------------------------------------------------------------------------------
	// Getter client : utilise par les menus pour afficher/cacher des elements admin
	// (ex: bouton Admin dans la fiche RP)
	//------------------------------------------------------------------------------------------------
	bool IsClientAdmin()
	{
		return m_ClientIsAdmin;
	}
	
	//------------------------------------------------------------------------------------------------
	// ============================================================
	// BANQUE (JobBankManager)
	// ============================================================
	// Client -> Serveur : demande info banque (solde + cash)
	// Serveur -> Client : push balance + cash pour afficher dans JobBankMenu
	//
	// Depot / retrait : le client envoie un montant, le serveur applique via JobBankManager.
	// Frais 1% -> cagnotte municipale (fait dans JobBankManager).
	// Apres chaque operation, le serveur re-push un BankInfo pour rafraichir la UI.
	//------------------------------------------------------------------------------------------------
	
	//------------------------------------------------------------------------------------------------
	// CLIENT : demande solde + cash au serveur (a l ouverture du menu ou apres depot/retrait)
	//------------------------------------------------------------------------------------------------
	void ClientAskBankInfo()
	{
		Rpc(RpcAsk_BankInfo);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_BankInfo()
	{
		if (!Replication.IsServer())
			return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc)
			return;
		int playerId = pc.GetPlayerId();
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "")
			return;
		
		BankAccount acc = JobBankManager.GetInstance().GetOrCreateAccount(uid);
		int balance = 0;
		int totalInterest = 0;
		if (acc)
		{
			balance = acc.m_Balance;
			totalInterest = acc.m_TotalInterest;
		}
		int cash = CapsuleEconomyManager.GetInstance().GetCapsules(uid);
		Rpc(RpcDo_BankInfo, balance, cash, totalInterest);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_BankInfo(int balance, int cash, int totalInterest)
	{
		JobBankMenu menu = JobBankMenu.GetOpenMenu();
		if (menu)
			menu.UpdateDisplay(balance, cash, totalInterest);
	}
	
	//------------------------------------------------------------------------------------------------
// ===== HUD IDENTITE (bloc haut droit) =====
// Poll leger du solde banque pour affichage HUD, sans ouvrir le menu banque
//------------------------------------------------------------------------------------------------
void ClientAskPlayerHudBank()
{
	Rpc(RpcAsk_PlayerHudBank);
}

[RplRpc(RplChannel.Reliable, RplRcver.Server)]
void RpcAsk_PlayerHudBank()
{
	if (!Replication.IsServer())
		return;
	PlayerController pc = PlayerController.Cast(GetOwner());
	if (!pc)
		return;
	int playerId = pc.GetPlayerId();
	string uid = JobManager.GetInstance().GetPersistentUID(playerId);
	if (uid == "")
		return;
	
	int balance = JobBankManager.GetInstance().GetBalance(uid);
	Rpc(RpcDo_PlayerHudBank, balance);
}

[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
void RpcDo_PlayerHudBank(int balance)
{
	LP_PlayerIdentityHud hud = LP_PlayerIdentityHud.GetInstance();
	if (hud)
		hud.OnBankBalanceReceived(balance);
}

	//------------------------------------------------------------------------------------------------
	// CLIENT : demande un depot (cash -> banque)
	//------------------------------------------------------------------------------------------------
	void ClientAskBankDeposit(int amount)
	{
		Rpc(RpcAsk_BankDeposit, amount);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_BankDeposit(int amount)
	{
		if (!Replication.IsServer())
			return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc)
			return;
		int playerId = pc.GetPlayerId();
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "")
			return;
		
		int netDeposited = 0;
		int fee = 0;
		int result = JobBankManager.GetInstance().Deposit(uid, amount, netDeposited, fee);
		
		switch (result)
		{
			case 0:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					string.Format("[BANQUE] Depot de %1 capsules effectue. Frais : %2. Credite : %3.",
						amount.ToString(), fee.ToString(), netDeposited.ToString()));
				break;
			case 1:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[BANQUE] Montant invalide.");
				break;
			case 2:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[BANQUE] Cash insuffisant pour ce depot.");
				break;
		}
		
		// Push nouveau solde au client (avec totalInterest pour la UI)
		BankAccount depAcc = JobBankManager.GetInstance().GetOrCreateAccount(uid);
		int balance = 0;
		int totalInterest = 0;
		if (depAcc)
		{
			balance = depAcc.m_Balance;
			totalInterest = depAcc.m_TotalInterest;
		}
		int cash = CapsuleEconomyManager.GetInstance().GetCapsules(uid);
		Rpc(RpcDo_BankInfo, balance, cash, totalInterest);
	}
	
	//------------------------------------------------------------------------------------------------
	// CLIENT : demande un retrait (banque -> cash)
	//------------------------------------------------------------------------------------------------
	void ClientAskBankWithdraw(int amount)
	{
		Rpc(RpcAsk_BankWithdraw, amount);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_BankWithdraw(int amount)
	{
		if (!Replication.IsServer())
			return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc)
			return;
		int playerId = pc.GetPlayerId();
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "")
			return;
		
		int netReceived = 0;
		int fee = 0;
		int result = JobBankManager.GetInstance().Withdraw(uid, amount, netReceived, fee);
		
		switch (result)
		{
			case 0:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					string.Format("[BANQUE] Retrait de %1 capsules effectue. Frais : %2. Recu cash : %3.",
						amount.ToString(), fee.ToString(), netReceived.ToString()));
				break;
			case 1:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[BANQUE] Montant invalide.");
				break;
			case 2:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[BANQUE] Solde banque insuffisant pour ce retrait.");
				break;
		}
		
		// Push nouveau solde au client (avec totalInterest pour la UI)
		BankAccount wAcc = JobBankManager.GetInstance().GetOrCreateAccount(uid);
		int balance = 0;
		int totalInterest = 0;
		if (wAcc)
		{
			balance = wAcc.m_Balance;
			totalInterest = wAcc.m_TotalInterest;
		}
		int cash = CapsuleEconomyManager.GetInstance().GetCapsules(uid);
		Rpc(RpcDo_BankInfo, balance, cash, totalInterest);
	}
}

//------------------------------------------------------------------------------------------------
// Petit container pour grouper conversations cote serveur lors du build de la liste
//------------------------------------------------------------------------------------------------
class JobSmsConvSummary
{
	string m_OtherUID;
	string m_OtherName;
	int m_UnreadCount;
	int m_LastTimestamp;
	string m_LastPreview;
}

//------------------------------------------------------------------------------------------------
// ============================================================
// SYSTEME ADMIN - RPCs (en classe modded de JobPlayerComponent)
// ============================================================
// Toutes les operations admin sont declarees dans le component JobPlayerComponent existant
// via cette extension modded class. Le check whitelist se fait au debut de chaque RPC server.
//------------------------------------------------------------------------------------------------

modded class JobPlayerComponent
{
	//------------------------------------------------------------------------------------------------
	// Helper : verifie que le caller est admin selon JobAdminManager
	//------------------------------------------------------------------------------------------------
	bool IsCallerAdmin(out int outPlayerId, out string outUID)
	{
		outPlayerId = 0;
		outUID = "";
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc)
			return false;
		outPlayerId = pc.GetPlayerId();
		outUID = JobManager.GetInstance().GetPersistentUID(outPlayerId);
		if (outUID == "")
			return false;
		return JobAdminManager.GetInstance().IsAdmin(outUID);
	}
	
	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : demande ouverture du menu admin (verifie whitelist)
	//------------------------------------------------------------------------------------------------
	void ClientAskOpenAdminMenu()
	{
		Rpc(RpcAsk_OpenAdminMenu);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_OpenAdminMenu()
	{
		if (!Replication.IsServer())
			return;
		int adminPid;
		string adminUID;
		if (!IsCallerAdmin(adminPid, adminUID))
		{
			JobManager.GetInstance().NotifyPlayerChat(adminPid,
				"[ADMIN] Acces refuse : vous n'etes pas administrateur.");
			return;
		}
		// Autorise l ouverture du menu cote client
		Rpc(RpcDo_AdminMenuAuthorized);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_AdminMenuAuthorized()
	{
		GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.JobAdminMenu);
	}
	
	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : demande infos d un joueur cible
	//------------------------------------------------------------------------------------------------
	void ClientAskAdminPlayerInfo(int targetPlayerId)
	{
		Rpc(RpcAsk_AdminPlayerInfo, targetPlayerId);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_AdminPlayerInfo(int targetPlayerId)
	{
		if (!Replication.IsServer())
			return;
		int adminPid;
		string adminUID;
		if (!IsCallerAdmin(adminPid, adminUID))
			return;
		
		string targetUID = JobManager.GetInstance().GetPersistentUID(targetPlayerId);
		if (targetUID == "")
			return;
		
		string formatted = BuildAdminPlayerInfo(targetPlayerId, targetUID);
		Rpc(RpcDo_AdminPlayerInfo, formatted);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_AdminPlayerInfo(string formatted)
	{
		JobAdminPlayerMenu menu = JobAdminPlayerMenu.GetOpenMenu();
		if (menu)
			menu.DisplayPlayerInfo(formatted);
	}
	
	//------------------------------------------------------------------------------------------------
	// SERVER : assemble la fiche admin du joueur cible
	//------------------------------------------------------------------------------------------------
	string BuildAdminPlayerInfo(int playerId, string uid)
	{
		PlayerManager pm = GetGame().GetPlayerManager();
		string playerName = "";
		if (pm)
			playerName = pm.GetPlayerName(playerId);
		
		// Identite RP
		JobRpIdentity id = JobIdentityManager.GetInstance().GetIdentity(uid);
		string firstName = "Non renseigne";
		string lastName = "Non renseigne";
		string birthDate = "Non renseignee";
		if (id)
		{
			firstName = id.m_FirstName;
			lastName = id.m_LastName;
			birthDate = id.m_BirthDate;
		}
		
		// Capsules
		CapsuleEconomyManager eco = CapsuleEconomyManager.GetInstance();
		int capsules = 0;
		if (eco)
			capsules = eco.GetCapsules(uid);
		
		// Solde banque
		int bankBalance = JobBankManager.GetInstance().GetBalance(uid);
		
		// Job + anciennete
		JobPlayerData stats = JobManager.GetInstance().GetPlayerData(playerId);
		EJobType job = EJobType.NONE;
		string anciennete = "0 jour";
		int timesJailed = 0;
		int totalInfractions = 0;
		if (stats)
		{
			job = stats.m_Job;
			if (stats.m_FirstSeenUnix > 0)
			{
				int days = (System.GetUnixTime() - stats.m_FirstSeenUnix) / 86400;
				if (days <= 0)
					anciennete = "Aujourd'hui";
				else
					anciennete = days.ToString() + " jours";
			}
			timesJailed = stats.m_TimesJailed;
			totalInfractions = stats.m_TotalInfractions;
		}
		
		// Permis + prison
		bool hasLicense = JobCriminalManager.GetInstance().HasLicense(uid);
		bool inPrison = false;
		int unpaidFines = 0;
		CriminalRecord cr = JobCriminalManager.GetInstance().GetRecord(uid);
		if (cr)
		{
			inPrison = cr.m_InPrison;
			foreach (FineRecord f : cr.m_Fines)
			{
				if (f && !f.m_Paid)
					unpaidFines++;
			}
		}
		
		string licStr;
		if (hasLicense) licStr = "OUI"; else licStr = "NON";
		string prisonStr;
		if (inPrison) prisonStr = "OUI"; else prisonStr = "NON";
		
		string s = "";
		s = s + string.Format("PlayerName       : %1\n", playerName);
		s = s + string.Format("UID              : %1\n", uid);
		s = s + string.Format("Nom RP           : %1 %2\n", firstName, lastName);
		s = s + string.Format("Date naissance   : %1\n", birthDate);
		s = s + string.Format("Anciennete       : %1\n", anciennete);
		s = s + string.Format("Capsules         : %1\n", capsules);
		s = s + string.Format("Solde banque     : %1\n", bankBalance);
		s = s + string.Format("Metier           : %1\n", JobData.GetJobLabel(job));
		s = s + string.Format("Permis conduire  : %1\n", licStr);
		s = s + string.Format("En prison        : %1\n", prisonStr);
		s = s + string.Format("Amendes impayees : %1\n", unpaidFines);
		s = s + string.Format("Fois en prison   : %1\n", timesJailed);
		s = s + string.Format("Total infractions: %1", totalInfractions);
		
		return s;
	}
	
	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : ajoute (ou retire si negatif) des capsules
	//------------------------------------------------------------------------------------------------
	void ClientAskAdminAddCaps(int targetPlayerId, int amount)
	{
		Rpc(RpcAsk_AdminAddCaps, targetPlayerId, amount);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_AdminAddCaps(int targetPlayerId, int amount)
	{
		if (!Replication.IsServer())
			return;
		int adminPid;
		string adminUID;
		if (!IsCallerAdmin(adminPid, adminUID))
			return;
		
		string targetUID = JobManager.GetInstance().GetPersistentUID(targetPlayerId);
		if (targetUID == "")
			return;
		
		CapsuleEconomyManager eco = CapsuleEconomyManager.GetInstance();
		if (!eco)
			return;
		eco.AddCapsules(targetUID, amount);
		
		// Notifie la cible
		string sign;
		int abs = amount;
		if (amount < 0)
		{
			sign = "retire";
			abs = -amount;
		}
		else
		{
			sign = "ajoute";
		}
		JobManager.GetInstance().NotifyPlayerChat(targetPlayerId,
			string.Format("[ADMIN] Un administrateur a %1 %2 capsules.", sign, abs));

		string adminLogName = JobIdentityManager.GetInstance().GetDisplayNameOrFallback(adminUID, adminUID);
		string targetLogName = JobIdentityManager.GetInstance().GetDisplayNameOrFallback(targetUID, targetUID);
		JobAdminActionLog.GetInstance().Log(adminLogName,
			string.Format("%1 %2 caps a %3", sign, abs, targetLogName));
	}

	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : ajoute/retire des capsules SUR LE COMPTE BANQUE (admin only)
	// amount > 0 = credit banque, amount < 0 = debit banque
	// Aucun frais, pas de check cash. Solde ne peut pas descendre sous 0.
	//------------------------------------------------------------------------------------------------
	void ClientAskAdminAddBank(int targetPlayerId, int amount)
	{
		Rpc(RpcAsk_AdminAddBank, targetPlayerId, amount);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_AdminAddBank(int targetPlayerId, int amount)
	{
		if (!Replication.IsServer())
			return;
		int adminPid;
		string adminUID;
		if (!IsCallerAdmin(adminPid, adminUID))
			return;
		
		string targetUID = JobManager.GetInstance().GetPersistentUID(targetPlayerId);
		if (targetUID == "")
			return;
		
		JobBankManager.GetInstance().AdminAddToBalance(targetUID, amount);
		
		// Notifie la cible si elle est en ligne
		string sign;
		int abs = amount;
		if (amount < 0)
		{
			sign = "retire";
			abs = -amount;
		}
		else
		{
			sign = "ajoute";
		}
		JobManager.GetInstance().NotifyPlayerChat(targetPlayerId,
			string.Format("[ADMIN] Un administrateur a %1 %2 capsules a votre compte banque.", sign, abs));
	}
	
	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : change le metier d un joueur
	//------------------------------------------------------------------------------------------------
	void ClientAskAdminSetJob(int targetPlayerId, EJobType job)
	{
		Rpc(RpcAsk_AdminSetJob, targetPlayerId, job);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_AdminSetJob(int targetPlayerId, EJobType job)
	{
		if (!Replication.IsServer())
			return;
		int adminPid;
		string adminUID;
		if (!IsCallerAdmin(adminPid, adminUID))
			return;
		
		JobManager.GetInstance().SetPlayerJob(targetPlayerId, job);
		JobManager.GetInstance().NotifyPlayerChat(targetPlayerId,
			string.Format("[ADMIN] Votre metier a ete change en : %1", JobData.GetJobLabel(job)));
	}
	
	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : reset toutes les amendes
	//------------------------------------------------------------------------------------------------
	void ClientAskAdminResetFines(int targetPlayerId)
	{
		Rpc(RpcAsk_AdminResetFines, targetPlayerId);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_AdminResetFines(int targetPlayerId)
	{
		if (!Replication.IsServer())
			return;
		int adminPid;
		string adminUID;
		if (!IsCallerAdmin(adminPid, adminUID))
			return;
		
		string targetUID = JobManager.GetInstance().GetPersistentUID(targetPlayerId);
		if (targetUID == "")
			return;
		
		CriminalRecord cr = JobCriminalManager.GetInstance().GetRecord(targetUID);
		if (cr && cr.m_Fines)
		{
			// Marque toutes les amendes comme payees
			foreach (FineRecord f : cr.m_Fines)
			{
				if (f) f.m_Paid = true;
			}
			JobCriminalManager.GetInstance().SaveToDisk();
		}
		JobManager.GetInstance().NotifyPlayerChat(targetPlayerId,
			"[ADMIN] Toutes vos amendes ont ete annulees.");
	}
	
	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : libere de prison
	//------------------------------------------------------------------------------------------------
	void ClientAskAdminReleasePrison(int targetPlayerId)
	{
		Rpc(RpcAsk_AdminReleasePrison, targetPlayerId);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_AdminReleasePrison(int targetPlayerId)
	{
		if (!Replication.IsServer())
			return;
		int adminPid;
		string adminUID;
		if (!IsCallerAdmin(adminPid, adminUID))
			return;
		
		string targetUID = JobManager.GetInstance().GetPersistentUID(targetPlayerId);
		if (targetUID == "")
			return;
		
		JobCriminalManager.GetInstance().ReleaseFromPrison(targetUID, true);
		JobManager.GetInstance().NotifyPlayerChat(targetPlayerId,
			"[ADMIN] Vous avez ete libere de prison par un administrateur.");
	}
	
	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : donne le permis de conduire
	//------------------------------------------------------------------------------------------------
	void ClientAskAdminGiveLicense(int targetPlayerId)
	{
		Rpc(RpcAsk_AdminGiveLicense, targetPlayerId);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_AdminGiveLicense(int targetPlayerId)
	{
		if (!Replication.IsServer())
			return;
		int adminPid;
		string adminUID;
		if (!IsCallerAdmin(adminPid, adminUID))
			return;
		
		string targetUID = JobManager.GetInstance().GetPersistentUID(targetPlayerId);
		if (targetUID == "")
			return;
		
		// Recupere le nom RP (ou playername fallback) pour le passer a GrantLicense
		string targetName = ResolveDisplayName(targetUID, targetPlayerId);
		JobCriminalManager.GetInstance().GrantLicense(targetUID, targetName);
		JobManager.GetInstance().NotifyPlayerChat(targetPlayerId,
			"[ADMIN] Un administrateur vous a accorde le permis de conduire.");
	}

	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : verifie si un joueur cible est whitelist et renvoie le statut
	// via RPC owner (RpcDo_AdminWhitelistStatus) pour mise a jour UI (hide bouton si deja WL).
	//------------------------------------------------------------------------------------------------
	void ClientAskAdminCheckWhitelist(int targetPlayerId)
	{
		Rpc(RpcAsk_AdminCheckWhitelist, targetPlayerId);
	}

	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_AdminCheckWhitelist(int targetPlayerId)
	{
		if (!Replication.IsServer())
			return;
		int adminPid;
		string adminUID;
		if (!IsCallerAdmin(adminPid, adminUID))
			return;

		string targetUID = JobManager.GetInstance().GetPersistentUID(targetPlayerId);
		if (targetUID == "")
			return;

		bool isWL = JobWhitelistManager.GetInstance().IsAllowed(targetUID);
		Rpc(RpcDo_AdminWhitelistStatus, targetPlayerId, isWL);
		if (IsLocalPlayerOwner())
			RpcDo_AdminWhitelistStatus(targetPlayerId, isWL); // host local
	}

	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_AdminWhitelistStatus(int targetPlayerId, bool isWhitelist)
	{
		JobAdminPlayerMenu menu = JobAdminPlayerMenu.s_Instance;
		if (!menu)
			return;
		menu.SetWhitelistStatus(targetPlayerId, isWhitelist);
	}

	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : ajoute l UID du joueur cible dans la whitelist (JSON) et sauvegarde.
	//------------------------------------------------------------------------------------------------
	void ClientAskAdminValidateWL(int targetPlayerId)
	{
		Rpc(RpcAsk_AdminValidateWL, targetPlayerId);
	}

	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_AdminValidateWL(int targetPlayerId)
	{
		if (!Replication.IsServer())
			return;
		int adminPid;
		string adminUID;
		if (!IsCallerAdmin(adminPid, adminUID))
			return;

		string targetUID = JobManager.GetInstance().GetPersistentUID(targetPlayerId);
		if (targetUID == "")
		{
			JobManager.GetInstance().NotifyPlayerChat(adminPid,
				"[ADMIN] UID cible introuvable - whitelist non ajoutee.");
			return;
		}

		bool added = JobWhitelistManager.GetInstance().AddUIDToWhitelist(targetUID);
		if (added)
		{
			JobManager.GetInstance().NotifyPlayerChat(adminPid,
				string.Format("[ADMIN] Whitelist validee pour UID=%1", targetUID));
			JobManager.GetInstance().NotifyPlayerChat(targetPlayerId,
				"[ADMIN] Votre whitelist a ete validee par un administrateur.");

			// Repercute le nouveau statut cote UI de l admin
			Rpc(RpcDo_AdminWhitelistStatus, targetPlayerId, true);
			if (IsLocalPlayerOwner())
				RpcDo_AdminWhitelistStatus(targetPlayerId, true);
		}
		else
		{
			JobManager.GetInstance().NotifyPlayerChat(adminPid,
				"[ADMIN] Ce joueur est deja whitelist.");
		}
	}

	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : retire l UID du joueur cible de la whitelist (JSON) et le teleporte en prison.
	// Flux : admin clique "Retirer WL" sur la fiche d un joueur -> cote serveur, on retire son UID
	// de la whitelist (sauve sur disque) et on envoie le joueur en prison (teleport auto).
	//------------------------------------------------------------------------------------------------
	void ClientAskAdminRemoveWL(int targetPlayerId)
	{
		Rpc(RpcAsk_AdminRemoveWL, targetPlayerId);
	}

	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_AdminRemoveWL(int targetPlayerId)
	{
		if (!Replication.IsServer())
			return;
		int adminPid;
		string adminUID;
		if (!IsCallerAdmin(adminPid, adminUID))
			return;

		string targetUID = JobManager.GetInstance().GetPersistentUID(targetPlayerId);
		if (targetUID == "")
		{
			JobManager.GetInstance().NotifyPlayerChat(adminPid,
				"[ADMIN] UID cible introuvable - whitelist non retiree.");
			return;
		}

		bool removed = JobWhitelistManager.GetInstance().RemoveUIDFromWhitelist(targetUID);
		if (removed)
		{
			// Teleport VRAIE prison (1 des 5 positions aleatoires) pour 1h.
			// A chaque reconnexion future, le JobWhitelistHandler re-teleportera le joueur
			// en prison tant qu un admin ne remet pas sa WL.
			JobCriminalManager.GetInstance().SendToLongPrison(targetUID, 3600);

			JobManager.GetInstance().NotifyPlayerChat(adminPid,
				string.Format("[ADMIN] Whitelist retiree pour UID=%1 - teleporte en prison.", targetUID));
			JobManager.GetInstance().NotifyPlayerChat(targetPlayerId,
				"[ADMIN] Votre whitelist a ete retiree par un administrateur. Vous etes incarcere.");

			// Repercute le nouveau statut cote UI de l admin (plus WL -> affiche Valider WL)
			Rpc(RpcDo_AdminWhitelistStatus, targetPlayerId, false);
			if (IsLocalPlayerOwner())
				RpcDo_AdminWhitelistStatus(targetPlayerId, false);
		}
		else
		{
			JobManager.GetInstance().NotifyPlayerChat(adminPid,
				"[ADMIN] Ce joueur n est pas whitelist (ou UID introuvable).");
		}
	}

	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : teleport l admin vers le joueur cible
	//------------------------------------------------------------------------------------------------
	void ClientAskAdminTeleport(int targetPlayerId)
	{
		Rpc(RpcAsk_AdminTeleport, targetPlayerId);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_AdminTeleport(int targetPlayerId)
	{
		if (!Replication.IsServer())
			return;
		int adminPid;
		string adminUID;
		if (!IsCallerAdmin(adminPid, adminUID))
			return;
		
		PlayerManager pm = GetGame().GetPlayerManager();
		if (!pm)
			return;
		PlayerController targetPc = pm.GetPlayerController(targetPlayerId);
		if (!targetPc)
			return;
		IEntity targetChar = targetPc.GetControlledEntity();
		if (!targetChar)
			return;
		
		vector targetPos = targetChar.GetOrigin();
		// Spawn legerement decalee
		vector adminPos = Vector(targetPos[0] + 2.0, targetPos[1], targetPos[2] + 2.0);
		
		// Envoie une RPC client pour teleporter l admin via le mecanisme existant
		Rpc(RpcDo_AdminTeleport, adminPos);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_AdminTeleport(vector pos)
	{
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc)
			return;
		IEntity localChar = pc.GetControlledEntity();
		if (!localChar)
			return;
		localChar.SetOrigin(pos);
	}
	
	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : teleport le joueur cible vers l admin
	//------------------------------------------------------------------------------------------------
	void ClientAskAdminTeleportToMe(int targetPlayerId)
	{
		Rpc(RpcAsk_AdminTeleportToMe, targetPlayerId);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_AdminTeleportToMe(int targetPlayerId)
	{
		if (!Replication.IsServer())
			return;
		int adminPid;
		string adminUID;
		if (!IsCallerAdmin(adminPid, adminUID))
			return;
		
		// Recupere position de l admin
		PlayerController adminPc = PlayerController.Cast(GetOwner());
		if (!adminPc)
			return;
		IEntity adminChar = adminPc.GetControlledEntity();
		if (!adminChar)
			return;
		vector adminPos = adminChar.GetOrigin();
		
		// Position de spawn legerement decalee de l admin pour eviter collision
		vector targetPos = Vector(adminPos[0] + 2.0, adminPos[1], adminPos[2] + 2.0);
		
		// Envoie une RPC au CLIENT cible (pas a soi-meme : on utilise le composant de la cible)
		PlayerManager pm = GetGame().GetPlayerManager();
		if (!pm)
			return;
		PlayerController targetPc = pm.GetPlayerController(targetPlayerId);
		if (!targetPc)
			return;
		JobPlayerComponent targetJpc = JobPlayerComponent.Cast(targetPc.FindComponent(JobPlayerComponent));
		if (!targetJpc)
			return;
		
		// La RPC RpcDo_AdminTeleport existe deja et est RplRcver.Owner :
		// elle s execute chez le proprietaire du component, donc le joueur cible
		targetJpc.Rpc(targetJpc.RpcDo_AdminTeleport, targetPos);
		
		// Notif a la cible
		JobManager.GetInstance().NotifyPlayerChat(targetPlayerId,
			"[ADMIN] Vous avez ete teleporte par un administrateur.");
	}
	
	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : liste l inventaire du joueur
	//------------------------------------------------------------------------------------------------
	void ClientAskAdminInventory(int targetPlayerId)
	{
		Rpc(RpcAsk_AdminInventory, targetPlayerId);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_AdminInventory(int targetPlayerId)
	{
		if (!Replication.IsServer())
			return;
		int adminPid;
		string adminUID;
		if (!IsCallerAdmin(adminPid, adminUID))
			return;
		
		PlayerManager pm = GetGame().GetPlayerManager();
		if (!pm)
			return;
		PlayerController targetPc = pm.GetPlayerController(targetPlayerId);
		if (!targetPc)
			return;
		IEntity targetChar = targetPc.GetControlledEntity();
		if (!targetChar)
			return;
		
		SCR_InventoryStorageManagerComponent inv = SCR_InventoryStorageManagerComponent.Cast(
			targetChar.FindComponent(SCR_InventoryStorageManagerComponent));
		if (!inv)
		{
			Rpc(RpcDo_AdminInventoryList, "Inventaire inaccessible");
			return;
		}
		
		array<IEntity> items = new array<IEntity>();
		inv.GetItems(items);
		
		string s = string.Format("Inventaire (%1 items) :\n", items.Count());
		int max = items.Count();
		if (max > 30) max = 30; // limite affichage
		for (int i = 0; i < max; i++)
		{
			IEntity item = items.Get(i);
			if (!item) continue;
			EntityPrefabData pd = item.GetPrefabData();
			if (!pd) continue;
			ResourceName rn = pd.GetPrefabName();
			s = s + " - " + rn + "\n";
		}
		if (items.Count() > 30)
			s = s + string.Format("... (%1 autres items non affiches)", items.Count() - 30);
		
		Rpc(RpcDo_AdminInventoryList, s);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_AdminInventoryList(string list)
	{
		// Affiche l inventaire dans un hint long (8s)
		LP_NotificationManager.Show(list, "Inventaire", 8.0);
	}
	
	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : spawn N items du prefab donne dans l inventaire du joueur cible
	// (si inventaire plein, le fallback au sol est applique via SpawnItemWithGroundFallback)
	//------------------------------------------------------------------------------------------------
	void ClientAskAdminSpawnItem(int targetPlayerId, string prefabName, int quantity)
	{
		Rpc(RpcAsk_AdminSpawnItem, targetPlayerId, prefabName, quantity);
	}

	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_AdminSpawnItem(int targetPlayerId, string prefabName, int quantity)
	{
		if (!Replication.IsServer()) return;
		int adminPid;
		string adminUID;
		if (!IsCallerAdmin(adminPid, adminUID)) return;
		if (prefabName == "") return;
		if (quantity <= 0) return;
		if (quantity > 100) quantity = 100; // garde-fou anti-abus

		PlayerManager pm = GetGame().GetPlayerManager();
		if (!pm) return;
		PlayerController targetPc = pm.GetPlayerController(targetPlayerId);
		if (!targetPc) return;
		IEntity targetChar = targetPc.GetControlledEntity();
		if (!targetChar) return;

		int spawnedCount = 0;
		for (int i = 0; i < quantity; i++)
		{
			SpawnItemWithGroundFallback(targetChar, prefabName, targetPlayerId);
			spawnedCount = spawnedCount + 1;
		}

		JobManager.GetInstance().NotifyPlayerChat(targetPlayerId,
			string.Format("[ADMIN] Un administrateur vous a spawne %1 item(s) : %2", spawnedCount, prefabName));
		JobManager.GetInstance().NotifyPlayerChat(adminPid,
			string.Format("[ADMIN] %1 item(s) spawne(s) sur le joueur cible.", spawnedCount));

		JobAdminActionLog log = JobAdminActionLog.GetInstance();
		if (log)
		{
			string adminName = ResolveDisplayName(adminUID, adminPid);
			string targetName = ResolveDisplayName("", targetPlayerId);
			log.Log(adminName, string.Format("Spawn item x%1 (%2) sur %3", spawnedCount, prefabName, targetName));
		}
	}

	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : retire l identite RP d un joueur
	//------------------------------------------------------------------------------------------------
	void ClientAskAdminRemoveIdentity(int targetPlayerId)
	{
		Rpc(RpcAsk_AdminRemoveIdentity, targetPlayerId);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_AdminRemoveIdentity(int targetPlayerId)
	{
		if (!Replication.IsServer())
			return;
		int adminPid;
		string adminUID;
		if (!IsCallerAdmin(adminPid, adminUID))
			return;
		
		string targetUID = JobManager.GetInstance().GetPersistentUID(targetPlayerId);
		if (targetUID == "")
			return;
		
		bool removed = JobIdentityManager.GetInstance().RemoveIdentity(targetUID);
		if (removed)
		{
			JobManager.GetInstance().NotifyPlayerChat(targetPlayerId,
				"[ADMIN] Votre identite RP a ete supprimee par un administrateur. Vous devrez en creer une nouvelle.");
		}
		else
		{
			JobManager.GetInstance().NotifyPlayerChat(adminPid,
				"[ADMIN] Ce joueur n'avait pas d'identite RP a supprimer.");
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : ban le joueur (kick + ajout a la blacklist locale)
	//------------------------------------------------------------------------------------------------
	void ClientAskAdminBan(int targetPlayerId)
	{
		Rpc(RpcAsk_AdminBan, targetPlayerId);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_AdminBan(int targetPlayerId)
	{
		if (!Replication.IsServer())
			return;
		int adminPid;
		string adminUID;
		if (!IsCallerAdmin(adminPid, adminUID))
			return;
		
		string targetUID = JobManager.GetInstance().GetPersistentUID(targetPlayerId);
		if (targetUID == "")
			return;
		
		// Ajoute a la blacklist
		JobBanManager.GetInstance().BanPlayer(targetUID);

		// Kick immediat
		PlayerManager pm = GetGame().GetPlayerManager();
		if (pm)
			pm.KickPlayer(targetPlayerId, PlayerManagerKickReason.KICK, 0);

		string adminLogName2 = JobIdentityManager.GetInstance().GetDisplayNameOrFallback(adminUID, adminUID);
		string targetLogName2 = JobIdentityManager.GetInstance().GetDisplayNameOrFallback(targetUID, targetUID);
		JobAdminActionLog.GetInstance().Log(adminLogName2,
			string.Format("BAN de %1 (UID %2)", targetLogName2, targetUID));
	}
	
	//------------------------------------------------------------------------------------------------
	// === ADMIN : VOIR FICHE RP COMPLETE D UN JOUEUR ===
	// Reutilise BuildFicheString (deja parametre par playerId/uid) puis renvoie au client
	// admin pour l afficher dans le JobRpFicheMenu (qui acceptera le data via un champ
	// statique en mode "admin viewing").
	//------------------------------------------------------------------------------------------------
	void ClientAskAdminViewFiche(int targetPlayerId)
	{
		Rpc(RpcAsk_AdminViewFiche, targetPlayerId);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_AdminViewFiche(int targetPlayerId)
	{
		if (!Replication.IsServer())
			return;
		int adminPid;
		string adminUID;
		if (!IsCallerAdmin(adminPid, adminUID))
			return;
		
		string targetUID = JobManager.GetInstance().GetPersistentUID(targetPlayerId);
		if (targetUID == "")
			return;
		
		// Reutilise la meme logique d agregation que pour la fiche du joueur lui-meme
		string formatted = BuildFicheString(targetPlayerId, targetUID);
		Rpc(RpcDo_AdminViewFiche, formatted);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_AdminViewFiche(string formatted)
	{
		// Stocke le contenu pour que le menu fiche RP l affiche en mode admin
		// puis ouvre le menu (le menu detectera le contenu en attente et l affichera
		// directement au lieu de demander la fiche du joueur local).
		JobRpFicheMenu.SetPendingAdminFicheData(formatted);
		GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.JobRpFicheMenu);
	}
	
	//------------------------------------------------------------------------------------------------
	// === ADMIN : EFFACER TOUTES LES MENTIONS DU CASIER D UN JOUEUR ===
	// Vide rec.m_Mentions et sauve a disque. Pas de notif a la cible (silencieux).
	//------------------------------------------------------------------------------------------------
	void ClientAskAdminClearMentions(int targetPlayerId)
	{
		Rpc(RpcAsk_AdminClearMentions, targetPlayerId);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_AdminClearMentions(int targetPlayerId)
	{
		if (!Replication.IsServer())
			return;
		int adminPid;
		string adminUID;
		if (!IsCallerAdmin(adminPid, adminUID))
			return;
		
		string targetUID = JobManager.GetInstance().GetPersistentUID(targetPlayerId);
		if (targetUID == "")
			return;
		
		// Recupere le casier (sans le creer s il n existe pas)
		CriminalRecord rec = JobCriminalManager.GetInstance().GetRecord(targetUID);
		if (!rec || !rec.m_Mentions || rec.m_Mentions.Count() == 0)
		{
			JobManager.GetInstance().NotifyPlayerChat(adminPid,
				"[ADMIN] Aucune mention a supprimer.");
			return;
		}
		
		int removedCount = rec.m_Mentions.Count();
		rec.m_Mentions.Clear();
		JobCriminalManager.GetInstance().SaveToDisk();
		
		string targetName = JobCriminalManager.GetPlayerNameById(targetPlayerId);
		JobManager.GetInstance().NotifyPlayerChat(adminPid,
			string.Format("[ADMIN] Casier de %1 vide : %2 mention(s) supprimee(s).",
				targetName, removedCount));
	}
	
	//------------------------------------------------------------------------------------------------
	// ============================================================
	// ADMIN : TABLEAU DE BORD + LISTE VEHICULES
	// ============================================================
	//------------------------------------------------------------------------------------------------

	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : demande les donnees du tableau de bord
	//------------------------------------------------------------------------------------------------
	void ClientAskAdminDashboard()
	{
		Rpc(RpcAsk_AdminDashboard);
	}

	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_AdminDashboard()
	{
		if (!Replication.IsServer())
			return;
		int adminPid;
		string adminUID;
		if (!IsCallerAdmin(adminPid, adminUID))
			return;

		// === 1. Online players (ids, noms RP, metiers, capsules) ===
		PlayerManager pm = GetGame().GetPlayerManager();
		array<int> onlineIds = new array<int>();
		array<string> onlineNames = new array<string>();
		array<string> onlineJobs = new array<string>();
		array<int> onlineCaps = new array<int>();

		if (pm)
		{
			array<int> allPlayers = new array<int>();
			pm.GetPlayers(allPlayers);
			foreach (int pid : allPlayers)
			{
				string targetUID = JobManager.GetInstance().GetPersistentUID(pid);
				string rpName = JobIdentityManager.GetInstance().GetDisplayNameOrFallback(targetUID, pm.GetPlayerName(pid));
				if (rpName == "") rpName = pm.GetPlayerName(pid);

				JobPlayerData pdata = JobManager.GetInstance().GetPlayerData(pid);
				string jobLabel = "Sans emploi";
				if (pdata) jobLabel = JobData.GetJobLabel(pdata.m_Job);

				// Total = liquide + banque (comme le top 25)
				int caps = 0;
				if (targetUID != "")
				{
					CapsuleEconomyManager eco = CapsuleEconomyManager.GetInstance();
					if (eco) caps = eco.GetCapsules(targetUID);
					JobBankManager bk = JobBankManager.GetInstance();
					if (bk) caps = caps + bk.GetBalance(targetUID);
				}

				onlineIds.Insert(pid);
				onlineNames.Insert(rpName);
				onlineJobs.Insert(jobLabel);
				onlineCaps.Insert(caps);
			}
		}

		// === 2. Top 25 des plus riches (TOUS les UIDs persistes, offline inclus) ===
		// On aggrege liquide (capsules) + banque pour chaque UID connu du bank manager.
		array<string> allUIDs = new array<string>();
		JobBankManager bank = JobBankManager.GetInstance();
		if (bank && bank.m_Accounts)
		{
			int bankCount = bank.m_Accounts.Count();
			for (int bi = 0; bi < bankCount; bi++)
			{
				BankAccount ba = bank.m_Accounts.GetElement(bi);
				if (ba && ba.m_UID != "")
					allUIDs.Insert(ba.m_UID);
			}
		}

		// Calcul des totaux par UID
		array<string> uidsForSort = new array<string>();
		array<int> totalsForSort = new array<int>();
		CapsuleEconomyManager ecoGlobal = CapsuleEconomyManager.GetInstance();
		int grandTotal = 0;
		foreach (string uid : allUIDs)
		{
			int liquid = 0;
			if (ecoGlobal) liquid = ecoGlobal.GetCapsules(uid);
			int bankBal = bank.GetBalance(uid);
			int totalU = liquid + bankBal;
			grandTotal = grandTotal + totalU;
			uidsForSort.Insert(uid);
			totalsForSort.Insert(totalU);
		}

		// Tri decroissant (bubble sort simple, N est petit)
		int nSort = totalsForSort.Count();
		for (int si = 0; si < nSort - 1; si++)
		{
			for (int sj = 0; sj < nSort - 1 - si; sj++)
			{
				if (totalsForSort.Get(sj) < totalsForSort.Get(sj + 1))
				{
					int tmpV = totalsForSort.Get(sj);
					totalsForSort.Set(sj, totalsForSort.Get(sj + 1));
					totalsForSort.Set(sj + 1, tmpV);
					string tmpU = uidsForSort.Get(sj);
					uidsForSort.Set(sj, uidsForSort.Get(sj + 1));
					uidsForSort.Set(sj + 1, tmpU);
				}
			}
		}

		// Garde les 25 premiers et resout les noms RP
		array<string> richestNames = new array<string>();
		array<int> richestAmounts = new array<int>();
		int keepN = nSort;
		if (keepN > 25) keepN = 25;
		for (int ri = 0; ri < keepN; ri++)
		{
			string uidR = uidsForSort.Get(ri);
			string rpN = JobIdentityManager.GetInstance().GetDisplayNameOrFallback(uidR, uidR);
			if (rpN == "") rpN = uidR;
			richestNames.Insert(rpN);
			richestAmounts.Insert(totalsForSort.Get(ri));
		}

		// === 3. Count vehicules dans le garage virtuel ===
		int vehicleTotal = 0;
		JobVirtualGarageManager vgm = JobVirtualGarageManager.GetInstance();
		if (vgm && vgm.m_Vehicles)
			vehicleTotal = vgm.m_Vehicles.Count();

		int playerTotal = onlineIds.Count();

		// === 4. Envoi au client admin ===
		Rpc(RpcDo_AdminDashboardStats, playerTotal, vehicleTotal, grandTotal);
		Rpc(RpcDo_AdminDashboardOnline, onlineIds, onlineNames, onlineJobs, onlineCaps);
		Rpc(RpcDo_AdminDashboardRichest, richestNames, richestAmounts);
	}

	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_AdminDashboardStats(int playerCount, int vehicleCount, int totalMoney)
	{
		JobAdminMenu.SetDashboardPendingData(playerCount, vehicleCount, totalMoney);
		JobAdminMenu.NotifyDashboardReady();
	}

	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_AdminDashboardOnline(array<int> ids, array<string> names, array<string> jobs, array<int> caps)
	{
		JobAdminMenu.SetOnlinePlayersPendingData(ids, names, jobs, caps);
		JobAdminMenu.NotifyDashboardReady();
	}

	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_AdminDashboardRichest(array<string> names, array<int> amounts)
	{
		JobAdminMenu.SetRichestPendingData(names, amounts);
		JobAdminMenu.NotifyDashboardReady();
	}

	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : demande la liste des vehicules du garage virtuel.
	// filter peut etre vide (= tout), un UID, un prefab name, ou un fragment de nom.
	//------------------------------------------------------------------------------------------------
	void ClientAskAdminVehiclesList(string filter)
	{
		Rpc(RpcAsk_AdminVehiclesList, filter);
	}

	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_AdminVehiclesList(string filter)
	{
		if (!Replication.IsServer())
			return;
		int adminPid;
		string adminUID;
		if (!IsCallerAdmin(adminPid, adminUID))
			return;

		JobVirtualGarageManager vgm = JobVirtualGarageManager.GetInstance();
		array<string> plates = new array<string>();
		array<string> owners = new array<string>();
		array<string> models = new array<string>();

		// Normalise le filtre en minuscules pour recherche case-insensitive
		string filterLow = LowerStr(filter);
		PlayerManager pmSearch = GetGame().GetPlayerManager();

		if (vgm && vgm.m_Vehicles)
		{
			int vcount = vgm.m_Vehicles.Count();
			int sent = 0;
			for (int vi = 0; vi < vcount && sent < 100; vi++)
			{
				JobGarageVehicle gv = vgm.m_Vehicles.Get(vi);
				if (!gv) continue;

				// Si vehicule en fourriere (m_OwnerUID == FOURRIERE_SHARED), on resout
				// le nom via m_OriginalOwnerUID et on tag [FOURRIERE] pour visibilite.
				string resolveUid = gv.m_OwnerUID;
				bool isImpounded = false;
				if (gv.m_OwnerUID == "FOURRIERE_SHARED")
				{
					resolveUid = gv.m_OriginalOwnerUID;
					isImpounded = true;
				}

				string ownerName = JobIdentityManager.GetInstance().GetDisplayNameOrFallback(
					resolveUid, resolveUid);
				if (ownerName == "") ownerName = resolveUid;
				if (isImpounded) ownerName = "[FOURRIERE] " + ownerName;

				string modelShort = ExtractModelName(gv.m_PrefabName);

				// Recupere aussi le playername Bohemia si le proprio est connecte
				string playerNameBohemia = "";
				if (pmSearch)
				{
					array<int> onlineForSearch = new array<int>();
					pmSearch.GetPlayers(onlineForSearch);
					foreach (int opid : onlineForSearch)
					{
						string opidUID = JobManager.GetInstance().GetPersistentUID(opid);
						if (opidUID == gv.m_OwnerUID)
						{
							playerNameBohemia = pmSearch.GetPlayerName(opid);
							break;
						}
					}
				}

				// Filtre texte case-insensitive sur : nom RP, playername, modele, UID, orig UID
				if (filterLow != "")
				{
					bool match = false;
					if (LowerStr(ownerName).IndexOf(filterLow) >= 0) match = true;
					if (playerNameBohemia != "" && LowerStr(playerNameBohemia).IndexOf(filterLow) >= 0) match = true;
					if (LowerStr(modelShort).IndexOf(filterLow) >= 0) match = true;
					if (LowerStr(gv.m_OwnerUID).IndexOf(filterLow) >= 0) match = true;
					if (gv.m_OriginalOwnerUID != "" && LowerStr(gv.m_OriginalOwnerUID).IndexOf(filterLow) >= 0) match = true;
					if (!match) continue;
				}

				string plateStr = "#" + vi.ToString();
				plates.Insert(plateStr);
				owners.Insert(ownerName);
				models.Insert(modelShort);
				sent = sent + 1;
			}
		}

		Rpc(RpcDo_AdminVehiclesList, plates, owners, models);
	}

	//------------------------------------------------------------------------------------------------
	// Helper : convertit une chaine en minuscules (Enforce n a pas de ToLower natif)
	//------------------------------------------------------------------------------------------------
	protected string LowerStr(string s)
	{
		if (s == "") return s;
		string result = "";
		int slen = s.Length();
		for (int li = 0; li < slen; li++)
		{
			string ch = s.Substring(li, 1);
			// Conversion basique ASCII A-Z -> a-z
			if (ch == "A") result = result + "a";
			else if (ch == "B") result = result + "b";
			else if (ch == "C") result = result + "c";
			else if (ch == "D") result = result + "d";
			else if (ch == "E") result = result + "e";
			else if (ch == "F") result = result + "f";
			else if (ch == "G") result = result + "g";
			else if (ch == "H") result = result + "h";
			else if (ch == "I") result = result + "i";
			else if (ch == "J") result = result + "j";
			else if (ch == "K") result = result + "k";
			else if (ch == "L") result = result + "l";
			else if (ch == "M") result = result + "m";
			else if (ch == "N") result = result + "n";
			else if (ch == "O") result = result + "o";
			else if (ch == "P") result = result + "p";
			else if (ch == "Q") result = result + "q";
			else if (ch == "R") result = result + "r";
			else if (ch == "S") result = result + "s";
			else if (ch == "T") result = result + "t";
			else if (ch == "U") result = result + "u";
			else if (ch == "V") result = result + "v";
			else if (ch == "W") result = result + "w";
			else if (ch == "X") result = result + "x";
			else if (ch == "Y") result = result + "y";
			else if (ch == "Z") result = result + "z";
			else result = result + ch;
		}
		return result;
	}

	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_AdminVehiclesList(array<string> plates, array<string> owners, array<string> models)
	{
		JobAdminMenu.SetVehiclesPendingData(plates, owners, models);
		JobAdminMenu.NotifyVehiclesReady();
	}

	//------------------------------------------------------------------------------------------------
	// === PAGE GARAGE DU JOUEUR (fiche RP, non admin) ===
	// Le joueur demande la liste de SES vehicules dans le garage virtuel + leur etat.
	//------------------------------------------------------------------------------------------------
	void ClientAskMyGarageList()
	{
		Rpc(RpcAsk_MyGarageList);
	}

	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_MyGarageList()
	{
		if (!Replication.IsServer()) return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		if (playerId <= 0) return;
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "") return;

		JobVirtualGarageManager vgm = JobVirtualGarageManager.GetInstance();
		array<string> models = new array<string>();
		array<string> prefabs = new array<string>();
		array<int> fuels = new array<int>();
		array<int> damaged = new array<int>();
		array<int> itemCounts = new array<int>();
		array<int> insured = new array<int>();

		if (vgm && vgm.m_Vehicles)
		{
			int vcount = vgm.m_Vehicles.Count();
			for (int vi = 0; vi < vcount; vi++)
			{
				JobGarageVehicle gv = vgm.m_Vehicles.Get(vi);
				if (!gv) continue;
				// Ne retourne que les vehicules du JOUEUR (owner courant = uid, pas fourriere)
				if (gv.m_OwnerUID != uid) continue;

				string shortName = ExtractModelName(gv.m_PrefabName);
				int fuelInt = -1;
				if (gv.m_Fuel >= 0) fuelInt = Math.Round(gv.m_Fuel);

				int dmgCount = 0;
				if (gv.m_HitzoneDamages) dmgCount = gv.m_HitzoneDamages.Count();

				int itemCount = 0;
				if (gv.m_Items) itemCount = gv.m_Items.Count();

				int isInsured = 0;
				if (gv.m_InstanceUUID != "") isInsured = 1;

				models.Insert(shortName);
				prefabs.Insert(gv.m_PrefabName);
				fuels.Insert(fuelInt);
				damaged.Insert(dmgCount);
				itemCounts.Insert(itemCount);
				insured.Insert(isInsured);
			}
		}

		Rpc(RpcDo_MyGarageList, models, prefabs, fuels, damaged, itemCounts, insured);
	}

	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_MyGarageList(array<string> models, array<string> prefabs, array<int> fuels, array<int> damaged, array<int> itemCounts, array<int> insured)
	{
		JobRpFicheMenu.SetGaragePending(models, prefabs, fuels, damaged, itemCounts, insured);
		JobRpFicheMenu.NotifyGarageReady();
	}

	//------------------------------------------------------------------------------------------------
	// === ADMIN : SUPPRESSION DE VEHICULE DU GARAGE VIRTUEL ===
	//------------------------------------------------------------------------------------------------
	void ClientAskAdminDeleteVehicle(int vehicleIndex)
	{
		Rpc(RpcAsk_AdminDeleteVehicle, vehicleIndex);
	}

	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_AdminDeleteVehicle(int vehicleIndex)
	{
		if (!Replication.IsServer()) return;
		int adminPid;
		string adminUID;
		if (!IsCallerAdmin(adminPid, adminUID)) return;

		JobVirtualGarageManager vgm = JobVirtualGarageManager.GetInstance();
		if (!vgm || !vgm.m_Vehicles) return;
		if (vehicleIndex < 0 || vehicleIndex >= vgm.m_Vehicles.Count()) return;

		JobGarageVehicle gv = vgm.m_Vehicles.Get(vehicleIndex);
		if (!gv) return;

		string ownerUID = gv.m_OwnerUID;
		string prefabName = gv.m_PrefabName;
		vgm.m_Vehicles.Remove(vehicleIndex);
		vgm.SaveToDisk();

		string adminName = JobIdentityManager.GetInstance().GetDisplayNameOrFallback(adminUID, adminUID);
		JobAdminActionLog.GetInstance().Log(adminName,
			string.Format("Supprime vehicule #%1 (proprio %2, prefab %3)",
				vehicleIndex.ToString(), ownerUID,
				ExtractModelName(prefabName)));

		JobManager.GetInstance().NotifyPlayerChat(adminPid,
			string.Format("[ADMIN] Vehicule #%1 supprime du garage virtuel.", vehicleIndex.ToString()));
	}

	//------------------------------------------------------------------------------------------------
	// === ADMIN : JOURNAL DES ACTIONS (lecture) ===
	//------------------------------------------------------------------------------------------------
	void ClientAskAdminGetActionLog()
	{
		Rpc(RpcAsk_AdminGetActionLog);
	}

	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_AdminGetActionLog()
	{
		if (!Replication.IsServer()) return;
		int adminPid;
		string adminUID;
		if (!IsCallerAdmin(adminPid, adminUID)) return;

		array<string> entries = new array<string>();
		JobAdminActionLog.GetInstance().GetEntries(entries);
		Rpc(RpcDo_AdminActionLog, entries);
	}

	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_AdminActionLog(array<string> entries)
	{
		JobAdminMenu.SetAdminLogPending(entries);
		JobAdminMenu.NotifyAdminLogReady();
	}

	//------------------------------------------------------------------------------------------------
	// === ADMIN ECONOMIE : BOURSES (lecture + modification des cours) ===
	//------------------------------------------------------------------------------------------------

	// CLIENT -> SERVER : demande les cours actuels des 6 bourses
	void ClientAskAdminGetCours()
	{
		Rpc(RpcAsk_AdminGetCours);
	}

	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_AdminGetCours()
	{
		if (!Replication.IsServer()) return;
		int adminPid;
		string adminUID;
		if (!IsCallerAdmin(adminPid, adminUID)) return;

		JobMarketManager mm = JobMarketManager.GetInstance();
		if (!mm) return;

		int rock = mm.GetCours(EMarketItem.ROCK);
		int wood = mm.GetCours(EMarketItem.WOOD);
		int apple = mm.GetCours(EMarketItem.APPLE);
		int cannabis = mm.GetCours(EMarketItem.CANNABIS);
		int cocaine = mm.GetCours(EMarketItem.COCAINE);
		int wheat = mm.GetCours(EMarketItem.WHEAT);

		// Prix essence (en caps/litre, actuellement 1 a 5)
		int fuelPrice = 3;
		JobFuelStationManager fmgr = JobFuelStationManager.GetInstance();
		if (fmgr) fuelPrice = Math.Round(fmgr.PRICE_PER_LITER);

		Rpc(RpcDo_AdminCoursData, rock, wood, apple, cannabis, cocaine, wheat, fuelPrice);
	}

	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_AdminCoursData(int rock, int wood, int apple, int cannabis, int cocaine, int wheat, int fuelPrice)
	{
		JobAdminMenu.SetCoursPendingData(rock, wood, apple, cannabis, cocaine, wheat);
		JobAdminMenu.SetFuelPricePending(fuelPrice);
		JobAdminMenu.NotifyCoursReady();
	}

	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : change le prix essence (delta +1/-1, ou 0 pour reset a 3)
	//------------------------------------------------------------------------------------------------
	void ClientAskAdminSetFuelPrice(int delta)
	{
		Rpc(RpcAsk_AdminSetFuelPrice, delta);
	}

	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_AdminSetFuelPrice(int delta)
	{
		if (!Replication.IsServer()) return;
		int adminPid;
		string adminUID;
		if (!IsCallerAdmin(adminPid, adminUID)) return;

		JobFuelStationManager fmgr = JobFuelStationManager.GetInstance();
		if (!fmgr) return;

		float oldPrice = fmgr.PRICE_PER_LITER;
		float newPrice = oldPrice;
		if (delta == 0)
			newPrice = fmgr.PRICE_DEFAULT;
		else
			newPrice = oldPrice + delta;

		// Clamp
		if (newPrice < fmgr.PRICE_MIN) newPrice = fmgr.PRICE_MIN;
		if (newPrice > fmgr.PRICE_MAX) newPrice = fmgr.PRICE_MAX;

		fmgr.PRICE_PER_LITER = newPrice;
		fmgr.SaveToDisk();

		int oldInt = Math.Round(oldPrice);
		int newInt = Math.Round(newPrice);
		Print(string.Format("[Admin] Prix essence : %1 -> %2 caps/L par %3",
			oldInt.ToString(), newInt.ToString(), adminUID), LogLevel.NORMAL);

		string adminLabel = JobIdentityManager.GetInstance().GetDisplayNameOrFallback(adminUID, adminUID);
		JobAdminActionLog.GetInstance().Log(adminLabel,
			string.Format("Prix essence : %1 -> %2 caps/L", oldInt.ToString(), newInt.ToString()));

		// Renvoie le snapshot complet (cours + nouveau prix essence) au client
		RpcAsk_AdminGetCours();
	}

	// CLIENT -> SERVER : modifie le cours d un item
	// delta : +5 (hausse), -5 (baisse), 0 (reset)
	void ClientAskAdminSetCours(int itemType, int delta)
	{
		Rpc(RpcAsk_AdminSetCours, itemType, delta);
	}

	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_AdminSetCours(int itemType, int delta)
	{
		if (!Replication.IsServer()) return;
		int adminPid;
		string adminUID;
		if (!IsCallerAdmin(adminPid, adminUID)) return;

		JobMarketManager mm = JobMarketManager.GetInstance();
		if (!mm) return;

		EMarketItem item = itemType;
		int currentCours = mm.GetCours(item);
		int newCours = currentCours;
		if (delta == 0)
			newCours = 0; // reset
		else
			newCours = currentCours + delta;

		// Clamp selon les limites de JobMarketManager (MIN_COURS=-50, MAX_COURS=+100)
		if (newCours > 100) newCours = 100;
		if (newCours < -50) newCours = -50;
		mm.m_Cours.Set(item, newCours);
		mm.SaveToDisk();

		Print(string.Format("[Admin] Cours %1 : %2 -> %3 par %4",
			JobMarketManager.GetItemLabel(item),
			currentCours.ToString(), newCours.ToString(), adminUID), LogLevel.NORMAL);

		string adminLabel = JobIdentityManager.GetInstance().GetDisplayNameOrFallback(adminUID, adminUID);
		JobAdminActionLog.GetInstance().Log(adminLabel,
			string.Format("Cours %1 : %2%% -> %3%%",
				JobMarketManager.GetItemLabel(item),
				currentCours.ToString(), newCours.ToString()));

		// Renvoie le nouvel etat global au client admin
		RpcAsk_AdminGetCours();
	}

	//------------------------------------------------------------------------------------------------
	// Helper : extrait un nom lisible depuis un chemin prefab complet
	//------------------------------------------------------------------------------------------------
	protected string ExtractModelName(string prefabName)
	{
		if (prefabName == "") return "?";
		int lastSlash = -1;
		int plen = prefabName.Length();
		for (int ci = plen - 1; ci >= 0; ci--)
		{
			string ch = prefabName.Substring(ci, 1);
			if (ch == "/")
			{
				lastSlash = ci;
				break;
			}
		}
		string shortName = prefabName;
		if (lastSlash >= 0 && lastSlash + 1 < plen)
			shortName = prefabName.Substring(lastSlash + 1, plen - lastSlash - 1);
		// Retire ".et"
		int extIdx = shortName.IndexOf(".et");
		if (extIdx > 0)
			shortName = shortName.Substring(0, extIdx);
		return shortName;
	}

	//------------------------------------------------------------------------------------------------
	// ============================================================
	// SYSTEME FOURRIERE (POLICE/MILITAIRE)
	// ============================================================
	//------------------------------------------------------------------------------------------------

	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : demande mise en fourriere d un vehicule
	//------------------------------------------------------------------------------------------------
	void ClientAskImpoundVehicle(RplId vehicleRplId)
	{
		Rpc(RpcAsk_ImpoundVehicle, vehicleRplId);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_ImpoundVehicle(RplId vehicleRplId)
	{
		if (!Replication.IsServer())
			return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc)
			return;
		int playerId = pc.GetPlayerId();
		if (playerId <= 0)
			return;

		// Verifie metier (requester : policier ou militaire)
		JobPlayerData data = JobManager.GetInstance().GetPlayerData(playerId);
		if (!data || (data.m_Job != EJobType.POLICIER && data.m_Job != EJobType.MILITAIRE))
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[FOURRIERE] Reserve aux policiers et militaires.");
			return;
		}

		// === NOUVEAU : si au moins un employe FOURRIERE est connecte, on envoie une alerte
		// a tous les Fourriere connectes avec la position du vehicule, au lieu de teleporter.
		// Le vehicule reste sur place en attendant qu un Fourriere vienne le remorquer manuellement.
		PlayerManager pm = GetGame().GetPlayerManager();
		array<int> allIds = new array<int>();
		if (pm)
			pm.GetPlayers(allIds);

		int fourriereCount = 0;
		foreach (int pid : allIds)
		{
			JobPlayerData d = JobManager.GetInstance().GetPlayerData(pid);
			if (d && d.m_Job == EJobType.FOURRIERE)
				fourriereCount = fourriereCount + 1;
		}

		if (fourriereCount > 0)
		{
			// === MODE ALERTE ===
			// Resout le vehicule pour recuperer sa position monde
			RplComponent rpl = RplComponent.Cast(Replication.FindItem(vehicleRplId));
			if (!rpl)
			{
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[FOURRIERE] Vehicule introuvable.");
				return;
			}
			IEntity vehicle = rpl.GetEntity();
			if (!vehicle)
			{
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[FOURRIERE] Vehicule introuvable.");
				return;
			}
			vector vehiclePos = vehicle.GetOrigin();

			// Nom affichable du requester (prend le nom RP si dispo, sinon le playername)
			string requesterName = JobIdentityManager.GetInstance().GetDisplayNameByPlayerId(playerId);
			if (requesterName == "")
			{
				requesterName = pm.GetPlayerName(playerId);
				if (requesterName == "")
					requesterName = "Officier " + playerId.ToString();
			}

			// Broadcast de l alerte a tous les Fourriere connectes via le pattern des alertes telephone
			int notified = 0;
			foreach (int fid : allIds)
			{
				JobPlayerData fd = JobManager.GetInstance().GetPlayerData(fid);
				if (!fd || fd.m_Job != EJobType.FOURRIERE)
					continue;

				PlayerController fpc = pm.GetPlayerController(fid);
				if (!fpc)
					continue;
				JobPlayerComponent fjpc = JobPlayerComponent.Cast(fpc.FindComponent(JobPlayerComponent));
				if (!fjpc)
					continue;

				// Reutilise le RPC d alerte existant : hint 15s + marker carte 10 min cote Fourriere
				fjpc.Rpc(fjpc.RpcDo_ReceivePhoneAlert, EPhoneCallType.FOURRIERE_ALERT,
					requesterName, vehiclePos[0], vehiclePos[2]);
				notified = notified + 1;
			}

			JobManager.GetInstance().NotifyPlayerChat(playerId,
				string.Format("[FOURRIERE] %1 employe(s) Fourriere alerte(s). Un vehicule est a recuperer sur place.",
					notified.ToString()));

			Print(string.Format("[JobPlayerComponent] Impound ALERTE : requester=%1 pos=%2 -> %3 Fourriere notifies",
				playerId, vehiclePos.ToString(), notified), LogLevel.NORMAL);
			return;
		}

		// === MODE FALLBACK (aucun Fourriere en ligne) ===
		// Teleporte le vehicule directement en fourriere (comportement historique)
		bool ok = JobImpoundManager.GetInstance().ImpoundVehicle(vehicleRplId);
		if (ok)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[FOURRIERE] Aucun Fourriere connecte : vehicule teleporte automatiquement a la fourriere.");
		}
		else
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[FOURRIERE] Impossible de mettre ce vehicule en fourriere.");
		}
	}

	//------------------------------------------------------------------------------------------------
	// ============================================================
	// SYSTEME STATION ESSENCE (POMPISTE + remplissage joueur)
	// ============================================================
	// Flow joueur normal :
	//  1. Clic action "Mettre de l essence" sur son vehicule
	//  2. ClientAskFuelVehicle(vehRplId) -> serveur
	//  3. Serveur valide (station proche, caps, reservoir), fait la transaction atomique
	//  4. Serveur renvoie result (liters verses + capsules debitees + reserve station restante)
	//  5. Client ouvre JobFuelPumpMenu avec animation du remplissage
	//
	// Flow pompiste :
	//  1. Clic action "Remplir la station" sur une station
	//  2. ClientAskPompisteRefillStation(stationRplId) -> serveur
	//  3. Serveur remplit la station a 150L, verse 400 caps au pompiste
	//------------------------------------------------------------------------------------------------

	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : demande de mettre de l essence dans un vehicule
	//------------------------------------------------------------------------------------------------
	void ClientAskFuelVehicle(RplId vehicleRplId)
	{
		Rpc(RpcAsk_FuelVehicle, vehicleRplId);
	}

	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_FuelVehicle(RplId vehicleRplId)
	{
		if (!Replication.IsServer())
			return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		if (playerId <= 0) return;

		// Resout le vehicule
		RplComponent rpl = RplComponent.Cast(Replication.FindItem(vehicleRplId));
		if (!rpl)
		{
			SendFuelPumpResult(0, 0, 0, 1, "Vehicule introuvable.");
			return;
		}
		IEntity vehicle = rpl.GetEntity();
		if (!vehicle)
		{
			SendFuelPumpResult(0, 0, 0, 1, "Vehicule introuvable.");
			return;
		}

		JobFuelStationManager mgr = JobFuelStationManager.GetInstance();

		// Trouve la station la plus proche du vehicule (4m)
		vector vehiclePos = vehicle.GetOrigin();
		string stationKey = mgr.FindNearestStationKey(vehiclePos, mgr.USAGE_RADIUS);
		if (stationKey == "")
		{
			SendFuelPumpResult(0, 0, 0, 1, "Aucune station essence a moins de 4m du vehicule.");
			return;
		}

		float stationFuel = mgr.GetStationFuel(stationKey);
		if (stationFuel <= 0.1)
		{
			SendFuelPumpResult(0, 0, stationFuel, 2, "Station vide. Attendez le pompiste.");
			return;
		}

		// Recupere le FuelManager du vehicule (classe scriptee Reforger : SCR_FuelManagerComponent)
		SCR_FuelManagerComponent fm = SCR_FuelManagerComponent.Cast(
			vehicle.FindComponent(SCR_FuelManagerComponent));
		if (!fm)
		{
			SendFuelPumpResult(0, 0, stationFuel, 5, "Ce vehicule n a pas de reservoir.");
			return;
		}

		float currentFuel = fm.GetTotalFuel();
		float maxFuel = fm.GetTotalMaxFuel();
		float remainingCapacity = maxFuel - currentFuel;
		if (remainingCapacity <= 0.1)
		{
			SendFuelPumpResult(0, 0, stationFuel, 3, "Reservoir deja plein.");
			return;
		}

		// Cap aussi au max 45L (comme demande, cap par session plein serveur)
		if (remainingCapacity > mgr.VEHICLE_TANK_MAX)
			remainingCapacity = mgr.VEHICLE_TANK_MAX;

		// Verifie capsules dispo
		CapsuleEconomyManager eco = CapsuleEconomyManager.GetInstance();
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		int playerCaps = 0;
		if (eco && uid != "")
			playerCaps = eco.GetCapsules(uid);

		float maxAffordableLiters = playerCaps / mgr.PRICE_PER_LITER;

		// Calcule les litres a verser : min(station, reservoir restant, caps dispo)
		float litersToFill = remainingCapacity;
		if (litersToFill > stationFuel)
			litersToFill = stationFuel;
		if (litersToFill > maxAffordableLiters)
			litersToFill = maxAffordableLiters;

		if (litersToFill <= 0.1)
		{
			SendFuelPumpResult(0, 0, stationFuel, 4, "Pas assez de capsules pour acheter du carburant.");
			return;
		}

		int priceToPay = Math.Round(litersToFill * mgr.PRICE_PER_LITER);

		// === TRANSACTION ATOMIQUE ===
		// 1. Debite capsules joueur (convention mod : AddCapsules(uid, -montant))
		if (eco && uid != "")
			eco.AddCapsules(uid, -priceToPay);

		// 2. Deplete station
		float consumed = mgr.ConsumeFuel(stationKey, litersToFill);

		// 3. Rajoute carburant au vehicule (iteration sur les tanks du FuelManager)
		AddFuelToVehicle(fm, consumed);

		// 4. Sync HUD capsules
		if (eco && uid != "")
		{
			CapsulePlayerComponent capsComp = CapsulePlayerComponent.Cast(pc.FindComponent(CapsulePlayerComponent));
			if (capsComp)
				capsComp.Svr_SendCapsules(eco.GetCapsules(uid));
		}

		// 5. Notif chat
		JobManager.GetInstance().NotifyPlayerChat(playerId,
			string.Format("[STATION] %1 L d essence pour %2 capsules.",
				FormatLitersStr(consumed), priceToPay.ToString()));

		// 6. Envoie resultat au client pour l animation
		float stationFuelAfter = mgr.GetStationFuel(stationKey);
		SendFuelPumpResult(consumed, priceToPay, stationFuelAfter, 0, "");

		Print(string.Format("[JobPlayerComponent] Fueling player=%1 liters=%2 price=%3 station=%4",
			playerId, consumed, priceToPay, stationKey), LogLevel.NORMAL);
	}

	//------------------------------------------------------------------------------------------------
	// Ajoute du carburant au vehicule en iterant sur ses nodes (BaseFuelNode).
	// L API Reforger : SCR_FuelManagerComponent herite de FuelManagerComponent, qui expose
	// GetFuelNodesList(out array<BaseFuelNode>). Chaque BaseFuelNode a GetFuel/GetMaxFuel/SetFuel.
	//------------------------------------------------------------------------------------------------
	protected void AddFuelToVehicle(SCR_FuelManagerComponent fm, float amount)
	{
		if (!fm || amount <= 0) return;

		array<BaseFuelNode> nodes = new array<BaseFuelNode>();
		fm.GetFuelNodesList(nodes);

		float remaining = amount;
		foreach (BaseFuelNode node : nodes)
		{
			if (!node || remaining <= 0) continue;
			float nodeMax = node.GetMaxFuel();
			float nodeCur = node.GetFuel();
			float nodeFree = nodeMax - nodeCur;
			if (nodeFree <= 0) continue;

			float toAdd = remaining;
			if (toAdd > nodeFree)
				toAdd = nodeFree;

			node.SetFuel(nodeCur + toAdd);
			remaining = remaining - toAdd;
		}
	}

	//------------------------------------------------------------------------------------------------
	// SERVEUR -> CLIENT (Owner) : envoie le resultat de la transaction et ouvre le menu
	//------------------------------------------------------------------------------------------------
	protected void SendFuelPumpResult(float liters, int price, float stationFuel, int resultCode, string status)
	{
		Rpc(RpcDo_OpenFuelPumpResult, liters, price, stationFuel, resultCode, status);
	}

	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_OpenFuelPumpResult(float liters, int price, float stationFuel, int resultCode, string status)
	{
		// Pre-charge les donnees et ouvre le menu
		JobFuelPumpMenu.SetPendingData(liters, price, stationFuel, resultCode, status);
		GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.JobFuelPumpMenu);
	}

	//------------------------------------------------------------------------------------------------
	// Helper : formate un float en string avec 1 decimale (Enforce n a pas de %.1f natif)
	//------------------------------------------------------------------------------------------------
	protected string FormatLitersStr(float value)
	{
		int whole = value;
		int dec = Math.AbsFloat((value - whole) * 10);
		return whole.ToString() + "." + dec.ToString();
	}

	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : pompiste remplit la station a 150L contre 400 caps
	//------------------------------------------------------------------------------------------------
	void ClientAskPompisteRefillStation(RplId stationRplId)
	{
		Rpc(RpcAsk_PompisteRefillStation, stationRplId);
	}

	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_PompisteRefillStation(RplId stationRplId)
	{
		if (!Replication.IsServer())
			return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		if (playerId <= 0) return;

		// Verifie metier
		JobPlayerData data = JobManager.GetInstance().GetPlayerData(playerId);
		if (!data || data.m_Job != EJobType.POMPISTE)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[STATION] Reserve au metier Pompiste.");
			return;
		}

		// Resout la station
		RplComponent rpl = RplComponent.Cast(Replication.FindItem(stationRplId));
		if (!rpl)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[STATION] Station introuvable.");
			return;
		}
		IEntity station = rpl.GetEntity();
		if (!station)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[STATION] Station introuvable.");
			return;
		}

		JobFuelStationManager mgr = JobFuelStationManager.GetInstance();
		mgr.RegisterStationIfNew(station); // au cas ou pas encore dans la cache

		// IMPORTANT : le composant clique (toit, mur, pompe) peut etre a quelques metres
		// du centre enregistre de la station. On recupere la cle via FindNearestStationKey
		// pour matcher le cluster physique le plus proche (< 15m).
		string key = mgr.FindNearestStationKey(station.GetOrigin(), 15.0);
		if (key == "")
		{
			SendPompisteRefillResult(0, 0, 0, 1,
				"Station non enregistree (reload serveur ?).");
			return;
		}

		float stationFuelBefore = mgr.GetStationFuel(key);
		float added = mgr.RefillStation(key);
		float stationFuelAfter = mgr.GetStationFuel(key);

		if (added <= 0.1)
		{
			// Station deja pleine : ouvre quand meme le menu en mode erreur
			SendPompisteRefillResult(0, 0, stationFuelAfter, 1,
				"Cette station est deja pleine.");
			return;
		}

		// Recompense = litres rajoutes * cap/L (ex: 80/300 -> ajoute 220L -> gagne 220 capsules)
		int reward = Math.Round(added * mgr.POMPISTE_REWARD_PER_LITER);

		// Verse les capsules au pompiste
		CapsuleEconomyManager eco = CapsuleEconomyManager.GetInstance();
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (eco && uid != "")
		{
			eco.AddCapsules(uid, reward);

			CapsulePlayerComponent capsComp = CapsulePlayerComponent.Cast(pc.FindComponent(CapsulePlayerComponent));
			if (capsComp)
				capsComp.Svr_SendCapsules(eco.GetCapsules(uid));
		}

		// Ouvre le menu client avec animation (meme pattern que JobFuelPumpMenu)
		SendPompisteRefillResult(added, reward, stationFuelAfter, 0, "");

		Print(string.Format("[JobPlayerComponent] Pompiste refill station=%1 by player=%2 added=%3L reward=%4",
			key, playerId, added, reward), LogLevel.NORMAL);
	}

	//------------------------------------------------------------------------------------------------
	// SERVEUR -> CLIENT (Owner) : envoie le resultat du refill station et ouvre le menu Pompiste
	//------------------------------------------------------------------------------------------------
	protected void SendPompisteRefillResult(float liters, int reward, float stationFuel, int resultCode, string status)
	{
		Rpc(RpcDo_OpenPompisteRefillResult, liters, reward, stationFuel, resultCode, status);
	}

	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_OpenPompisteRefillResult(float liters, int reward, float stationFuel, int resultCode, string status)
	{
		JobPompisteRefillMenu.SetPendingData(liters, reward, stationFuel, resultCode, status);
		GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.JobPompisteRefillMenu);
	}

	//------------------------------------------------------------------------------------------------
	// ============================================================
	// SYSTEME BRAQUAGE ATM (VOYOU)
	// ============================================================
	//------------------------------------------------------------------------------------------------
	
	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : demande de demarrer un braquage
	//------------------------------------------------------------------------------------------------
	void ClientAskStartRobbery(RplId atmRplId)
	{
		Rpc(RpcAsk_StartRobbery, atmRplId);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_StartRobbery(RplId atmRplId)
	{
		if (!Replication.IsServer())
			return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc)
			return;
		int playerId = pc.GetPlayerId();
		if (playerId <= 0)
			return;
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "")
			return;
		
		// Resoud nom RP
		string displayName = ResolveDisplayName(uid, playerId);
		
		int result = JobRobberyManager.GetInstance().StartRobbery(playerId, uid, displayName, atmRplId);
		switch (result)
		{
			case 1:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[BRAQUAGE] Reserve aux voyous.");
				break;
			case 2:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[BRAQUAGE] Vous avez deja un braquage en cours.");
				break;
			// case 3 : message deja envoye par le manager (avec temps restant)
			case 4:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[BRAQUAGE] Distributeur introuvable.");
				break;
			case 5:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[BRAQUAGE] Trop loin du distributeur.");
				break;
			// case 6 : message deja envoye par le manager (avec compteur X/2)
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// SERVER -> CLIENT (police/militaire) : envoie le hint de notification de braquage
	//------------------------------------------------------------------------------------------------
	void NotifyRobberyHint(string voyouName)
	{
		if (!Replication.IsServer())
			return;
		Rpc(RpcDo_RobberyHint, voyouName);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_RobberyHint(string voyouName)
	{
		LP_NotificationManager.Show(
			string.Format("Braquage en cours par %1 - voir la carte", voyouName),
			"ALERTE", 8.0);
	}
	
	//------------------------------------------------------------------------------------------------
	// Marker local de braquage pour la police (un par client, conserve pour suppression)
	//------------------------------------------------------------------------------------------------
	ref SCR_MapMarkerBase m_RobberyMarker;
	
	//------------------------------------------------------------------------------------------------
	// SERVER -> CLIENT (police/militaire) : cree un marker LOCAL chez ce client
	//------------------------------------------------------------------------------------------------
	void NotifyRobberyMarkerAdd(float posX, float posZ, string voyouName)
	{
		if (!Replication.IsServer())
			return;
		Rpc(RpcDo_RobberyMarkerAdd, posX, posZ, voyouName);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_RobberyMarkerAdd(float posX, float posZ, string voyouName)
	{
		SCR_MapMarkerManagerComponent markerMgr = SCR_MapMarkerManagerComponent.GetInstance();
		if (!markerMgr)
			return;
		
		// Supprime un ancien marker au cas ou (cas rare : 2 braquages successifs)
		if (m_RobberyMarker)
		{
			markerMgr.RemoveStaticMarker(m_RobberyMarker);
			m_RobberyMarker = null;
		}
		
		// Cree le nouveau marker local (visible uniquement par ce client police)
		m_RobberyMarker = new SCR_MapMarkerBase();
		m_RobberyMarker.SetType(SCR_EMapMarkerType.PLACED_CUSTOM);
		m_RobberyMarker.SetWorldPos(posX, posZ);
		m_RobberyMarker.SetCustomText(string.Format("BRAQUAGE - %1", voyouName));
		m_RobberyMarker.SetColorEntry(2);  // rouge
		markerMgr.InsertStaticMarker(m_RobberyMarker, true, true);
	}
	
	//------------------------------------------------------------------------------------------------
	// SERVER -> CLIENT (police/militaire) : supprime le marker LOCAL du braquage
	//------------------------------------------------------------------------------------------------
	void NotifyRobberyMarkerRemove()
	{
		if (!Replication.IsServer())
			return;
		Rpc(RpcDo_RobberyMarkerRemove);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_RobberyMarkerRemove()
	{
		if (!m_RobberyMarker)
			return;
		SCR_MapMarkerManagerComponent markerMgr = SCR_MapMarkerManagerComponent.GetInstance();
		if (markerMgr)
			markerMgr.RemoveStaticMarker(m_RobberyMarker);
		m_RobberyMarker = null;
	}
	
	//------------------------------------------------------------------------------------------------
	// ============================================================
	// GARAGE VIRTUEL
	// ============================================================
	// Permet au joueur de stocker virtuellement un vehicule via un PNJ dedie, et de le
	// recuperer plus tard. L etat et l inventaire interne sont preserves.
	//
	// Flow stockage :
	//   1. Joueur clique "Stocker mon vehicule" (action sur PNJ)
	//   2. ClientAskStoreVehicle(npcRplId) -> serveur
	//   3. Serveur trouve le vehicule le plus proche du PNJ, sauve son etat dans JSON
	//      et supprime l entite. Notif chat au joueur.
	//
	// Flow recuperation :
	//   1. Joueur clique "Recuperer mon vehicule" (action sur PNJ)
	//   2. ClientAskRetrieveVehicleList(npcRplId) -> serveur
	//   3. Serveur renvoie via RpcDo_ReceiveVirtualGarageList la liste des vehicules
	//      stockes du joueur (indexes + prefabs)
	//   4. Client ouvre JobVirtualGarageMenu avec les donnees pre-chargees
	//   5. Joueur clique sur un vehicule de la liste
	//   6. ClientAskRetrieveVehicle(npcRplId, garageIndex) -> serveur
	//   7. Serveur spawn le vehicule a 5m devant le PNJ, restaure son etat, supprime
	//      l entree JSON. Notif chat au joueur.
	//------------------------------------------------------------------------------------------------
	
	// CLIENT -> SERVER : stocke le vehicule le plus proche du PNJ designe
	void ClientAskStoreVehicle(RplId npcRplId)
	{
		Rpc(RpcAsk_StoreVehicle, npcRplId);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_StoreVehicle(RplId npcRplId)
	{
		if (!Replication.IsServer())
			return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc)
			return;
		int playerId = pc.GetPlayerId();
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "")
			return;
		
		// Resoud le PNJ
		RplComponent rpl = RplComponent.Cast(Replication.FindItem(npcRplId));
		if (!rpl)
			return;
		IEntity npc = rpl.GetEntity();
		if (!npc)
			return;
		
		string vehiclePrefab;
		int result = JobVirtualGarageManager.GetInstance().StoreVehicleNearPos(
			uid, npc.GetOrigin(), vehiclePrefab);
		
		switch (result)
		{
			case 0:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[GARAGE] Vehicule stocke avec succes dans votre garage virtuel.");
				break;
			case 1:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[GARAGE] Aucun vehicule a portee (5 metres autour du PNJ).");
				break;
			case 2:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[GARAGE] Impossible de lire les donnees du vehicule.");
				break;
			case 3:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[GARAGE] Ce vehicule n est pas le votre.");
				break;
			case 4:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[GARAGE] Les vehicules de location ne peuvent pas etre stockes.");
				break;
			case 5:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[GARAGE] Le garagiste refuse de garder un vehicule avec des choses illegales !");
				break;
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : demande la liste des vehicules stockes (pour ouvrir le menu)
	//------------------------------------------------------------------------------------------------
	void ClientAskRetrieveVehicleList(RplId npcRplId)
	{
		Rpc(RpcAsk_RetrieveVehicleList, npcRplId);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_RetrieveVehicleList(RplId npcRplId)
	{
		if (!Replication.IsServer())
			return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc)
			return;
		int playerId = pc.GetPlayerId();
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "")
			return;
		
		// Recupere la liste des vehicules du joueur + flag assure
		array<int> indexes = new array<int>();
		array<string> prefabs = new array<string>();
		array<bool> insured = new array<bool>();
		JobVirtualGarageManager vgm = JobVirtualGarageManager.GetInstance();
		vgm.GetPlayerVehiclesWithInsurance(uid, indexes, prefabs, insured);

		// Compte les zones endommagees + fuel par vehicule (persistes dans JobGarageVehicle)
		array<int> damaged = new array<int>();
		array<int> fuels = new array<int>();
		for (int d = 0; d < indexes.Count(); d++)
		{
			int gIdx = indexes.Get(d);
			int dCount = 0;
			int fLiters = -1;
			if (gIdx >= 0 && gIdx < vgm.m_Vehicles.Count())
			{
				JobGarageVehicle vref = vgm.m_Vehicles.Get(gIdx);
				if (vref)
				{
					if (vref.m_HitzoneDamages) dCount = vref.m_HitzoneDamages.Count();
					if (vref.m_Fuel >= 0) fLiters = Math.Round(vref.m_Fuel);
				}
			}
			damaged.Insert(dCount);
			fuels.Insert(fLiters);
		}

		// Serialisation en 5 strings (indexes, prefabs, insured, damaged, fuels).
		string indexesStr = "";
		string prefabsStr = "";
		string insuredStr = "";
		string damagedStr = "";
		string fuelsStr = "";
		for (int i = 0; i < indexes.Count(); i++)
		{
			if (i > 0)
			{
				indexesStr = indexesStr + "|";
				prefabsStr = prefabsStr + "###";
				insuredStr = insuredStr + "|";
				damagedStr = damagedStr + "|";
				fuelsStr = fuelsStr + "|";
			}
			indexesStr = indexesStr + indexes.Get(i).ToString();
			prefabsStr = prefabsStr + prefabs.Get(i);
			if (insured.Get(i))
				insuredStr = insuredStr + "1";
			else
				insuredStr = insuredStr + "0";
			damagedStr = damagedStr + damaged.Get(i).ToString();
			fuelsStr = fuelsStr + fuels.Get(i).ToString();
		}

		Rpc(RpcDo_ReceiveVirtualGarageList, npcRplId, indexesStr, prefabsStr, insuredStr, damagedStr, fuelsStr);
	}

	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_ReceiveVirtualGarageList(RplId npcRplId, string indexesStr, string prefabsStr, string insuredStr, string damagedStr, string fuelsStr)
	{
		array<int> indexes = new array<int>();
		array<string> prefabs = new array<string>();
		array<bool> insured = new array<bool>();
		array<int> damaged = new array<int>();
		array<int> fuels = new array<int>();

		ParseSplitInt(indexesStr, "|", indexes);
		ParseSplitString(prefabsStr, "###", prefabs);
		array<string> insuredParts = new array<string>();
		ParseSplitString(insuredStr, "|", insuredParts);
		foreach (string ip : insuredParts)
			insured.Insert(ip == "1");
		ParseSplitInt(damagedStr, "|", damaged);
		ParseSplitInt(fuelsStr, "|", fuels);

		JobVirtualGarageMenu.SetPendingData(indexes, prefabs, insured, npcRplId);
		JobVirtualGarageMenu.SetPendingDamaged(damaged);
		JobVirtualGarageMenu.SetPendingFuels(fuels);
		GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.JobVirtualGarageMenu);
	}
	
	//------------------------------------------------------------------------------------------------
	// Helpers de parsing (Enforce n a pas string.Split)
	//------------------------------------------------------------------------------------------------
	void ParseSplitString(string source, string sep, out array<string> outResult)
	{
		if (source == "")
			return;
		int sepLen = sep.Length();
		int start = 0;
		int len = source.Length();
		while (start < len)
		{
			int idx = source.IndexOfFrom(start, sep);
			if (idx < 0)
			{
				outResult.Insert(source.Substring(start, len - start));
				return;
			}
			outResult.Insert(source.Substring(start, idx - start));
			start = idx + sepLen;
		}
	}
	
	void ParseSplitInt(string source, string sep, out array<int> outResult)
	{
		array<string> tmp = new array<string>();
		ParseSplitString(source, sep, tmp);
		foreach (string s : tmp)
		{
			if (s != "")
				outResult.Insert(s.ToInt());
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : recupere un vehicule precis (selectionne dans le menu)
	//------------------------------------------------------------------------------------------------
	void ClientAskRetrieveVehicle(RplId npcRplId, int garageIndex)
	{
		Rpc(RpcAsk_RetrieveVehicle, npcRplId, garageIndex);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_RetrieveVehicle(RplId npcRplId, int garageIndex)
	{
		if (!Replication.IsServer())
			return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc)
			return;
		int playerId = pc.GetPlayerId();
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "")
			return;
		
		// Resoud le PNJ
		RplComponent rpl = RplComponent.Cast(Replication.FindItem(npcRplId));
		if (!rpl)
			return;
		IEntity npc = rpl.GetEntity();
		if (!npc)
			return;
		
		// Calcule la direction "devant" le PNJ (axe -Z dans Enfusion)
		vector npcMat[4];
		npc.GetWorldTransform(npcMat);
		vector forward = -npcMat[2];  // axe Z inverse = direction avant
		
		string vehiclePrefab;
		IEntity spawnedVehicle;
		int result = JobVirtualGarageManager.GetInstance().RetrieveVehicleByIndex(
			uid, garageIndex, npc.GetOrigin(), forward, vehiclePrefab, spawnedVehicle);
		
		switch (result)
		{
			case 0:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[GARAGE] Vehicule recupere ! Il vous attend devant le PNJ.");
				break;
			case 1:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[GARAGE] Vehicule introuvable dans le garage (deja recupere ?).");
				break;
			case 2:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[GARAGE] Ce vehicule ne vous appartient pas.");
				break;
			case 3:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[GARAGE] Erreur lors du spawn du vehicule (prefab invalide ?).");
				break;
		}
	}

	//------------------------------------------------------------------------------------------------
	// ============================================================
	// GARAGE VIRTUEL PARTAGE FOURRIERE (metier FOURRIERE uniquement)
	// ============================================================
	// Les 3 RPCs ci-dessous (store, list, retrieve) utilisent le MEME JobVirtualGarageManager
	// que le garage joueur classique, mais passent la constante FOURRIERE_SHARED_UID comme
	// owner UID au lieu du UID du joueur. Resultat : tous les joueurs ayant le metier FOURRIERE
	// voient et partagent le MEME garage virtuel.
	//
	// Securite : chaque RPC verifie cote serveur que le joueur a bien le metier FOURRIERE
	// avant d acceder au garage partage.
	//------------------------------------------------------------------------------------------------

	// UID special partage entre tous les employes Fourriere pour le garage virtuel du metier.
	static const string FOURRIERE_SHARED_UID = "FOURRIERE_SHARED";

	//------------------------------------------------------------------------------------------------
	// Verifie cote serveur si le joueur appelant a bien le metier FOURRIERE
	//------------------------------------------------------------------------------------------------
	protected bool IsCallerFourriere(int playerId)
	{
		JobPlayerData data = JobManager.GetInstance().GetPlayerData(playerId);
		return (data && data.m_Job == EJobType.FOURRIERE);
	}

	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : stocke le vehicule le plus proche dans le garage partage Fourriere
	//------------------------------------------------------------------------------------------------
	void ClientAskFourriereStoreVehicle(RplId npcRplId)
	{
		Rpc(RpcAsk_FourriereStoreVehicle, npcRplId);
	}

	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_FourriereStoreVehicle(RplId npcRplId)
	{
		if (!Replication.IsServer())
			return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc)
			return;
		int playerId = pc.GetPlayerId();

		// Securite : seul le metier FOURRIERE peut utiliser ce garage
		if (!IsCallerFourriere(playerId))
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[FOURRIERE] Acces refuse : vous devez etre employe de la fourriere.");
			return;
		}

		// Resoud le PNJ
		RplComponent rpl = RplComponent.Cast(Replication.FindItem(npcRplId));
		if (!rpl)
			return;
		IEntity npc = rpl.GetEntity();
		if (!npc)
			return;

		// Stocke le vehicule le plus proche sous l UID partage.
		// La methode dediee Fourriere capture aussi le vrai proprio original pour l affichage.
		string vehiclePrefab;
		string originalOwnerUID;
		int result = JobVirtualGarageManager.GetInstance().StoreVehicleForFourriere(
			FOURRIERE_SHARED_UID, npc.GetOrigin(), vehiclePrefab, originalOwnerUID);

		switch (result)
		{
			case 0:
			{
				string ownerRpName = "";
				if (originalOwnerUID != "")
					ownerRpName = JobIdentityManager.GetInstance().GetDisplayName(originalOwnerUID);
				if (ownerRpName == "")
					ownerRpName = "proprietaire inconnu";
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					string.Format("[FOURRIERE] Vehicule depose au garage partage (proprio: %1).", ownerRpName));
				break;
			}
			case 1:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[FOURRIERE] Aucun vehicule a portee (5 metres autour du PNJ).");
				break;
			case 2:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[FOURRIERE] Impossible de lire les donnees du vehicule.");
				break;
			case 4:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[FOURRIERE] Les vehicules de location ne peuvent pas etre stockes.");
				break;
			case 5:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[FOURRIERE] Le vehicule contient des objets illegaux, depot refuse.");
				break;
		}
	}

	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : demande la liste des vehicules du garage partage Fourriere
	//------------------------------------------------------------------------------------------------
	void ClientAskFourriereGarageList(RplId npcRplId)
	{
		Rpc(RpcAsk_FourriereGarageList, npcRplId);
	}

	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_FourriereGarageList(RplId npcRplId)
	{
		if (!Replication.IsServer())
			return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc)
			return;
		int playerId = pc.GetPlayerId();

		if (!IsCallerFourriere(playerId))
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[FOURRIERE] Acces refuse : vous devez etre employe de la fourriere.");
			return;
		}

		// Recupere la liste des vehicules sous l UID partage + les UIDs des proprios originaux
		array<int> indexes = new array<int>();
		array<string> prefabs = new array<string>();
		array<bool> insured = new array<bool>();
		array<string> originalOwnerUIDs = new array<string>();
		JobVirtualGarageManager vgmF = JobVirtualGarageManager.GetInstance();
		vgmF.GetVehiclesWithOriginalOwners(
			FOURRIERE_SHARED_UID, indexes, prefabs, insured, originalOwnerUIDs);

		// Compte les zones endommagees + fuel par vehicule (persistes dans JobGarageVehicle)
		array<int> damaged = new array<int>();
		array<int> fuels = new array<int>();
		for (int d = 0; d < indexes.Count(); d++)
		{
			int gIdxF = indexes.Get(d);
			int dCountF = 0;
			int fLitersF = -1;
			if (gIdxF >= 0 && gIdxF < vgmF.m_Vehicles.Count())
			{
				JobGarageVehicle vrefF = vgmF.m_Vehicles.Get(gIdxF);
				if (vrefF)
				{
					if (vrefF.m_HitzoneDamages) dCountF = vrefF.m_HitzoneDamages.Count();
					if (vrefF.m_Fuel >= 0) fLitersF = Math.Round(vrefF.m_Fuel);
				}
			}
			damaged.Insert(dCountF);
			fuels.Insert(fLitersF);
		}

		// Resoud chaque UID en nom RP affichable (Prenom Nom)
		string indexesStr = "";
		string prefabsStr = "";
		string insuredStr = "";
		string ownersStr = "";
		string damagedStr = "";
		string fuelsStr = "";
		for (int i = 0; i < indexes.Count(); i++)
		{
			if (i > 0)
			{
				indexesStr = indexesStr + "|";
				prefabsStr = prefabsStr + "###";
				insuredStr = insuredStr + "|";
				ownersStr = ownersStr + "###";
				damagedStr = damagedStr + "|";
				fuelsStr = fuelsStr + "|";
			}
			indexesStr = indexesStr + indexes.Get(i).ToString();
			prefabsStr = prefabsStr + prefabs.Get(i);
			if (insured.Get(i))
				insuredStr = insuredStr + "1";
			else
				insuredStr = insuredStr + "0";
			damagedStr = damagedStr + damaged.Get(i).ToString();
			fuelsStr = fuelsStr + fuels.Get(i).ToString();

			string ownerName = "";
			string origUid = originalOwnerUIDs.Get(i);
			if (origUid != "")
				ownerName = JobIdentityManager.GetInstance().GetDisplayName(origUid);
			if (ownerName == "")
				ownerName = "Inconnu";
			ownersStr = ownersStr + ownerName;
		}

		Rpc(RpcDo_ReceiveFourriereGarageList, npcRplId, indexesStr, prefabsStr, insuredStr, ownersStr, damagedStr, fuelsStr);
	}

	//------------------------------------------------------------------------------------------------
	// SERVER -> CLIENT (owner) : reçoit la liste + les noms RP des proprios et ouvre le menu
	// garage en "mode Fourriere"
	//------------------------------------------------------------------------------------------------
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_ReceiveFourriereGarageList(RplId npcRplId, string indexesStr, string prefabsStr, string insuredStr, string ownersStr, string damagedStr, string fuelsStr)
	{
		array<int> indexes = new array<int>();
		array<string> prefabs = new array<string>();
		array<bool> insured = new array<bool>();
		array<string> owners = new array<string>();
		array<int> damaged = new array<int>();
		array<int> fuels = new array<int>();

		ParseSplitInt(indexesStr, "|", indexes);
		ParseSplitString(prefabsStr, "###", prefabs);
		array<string> insuredParts = new array<string>();
		ParseSplitString(insuredStr, "|", insuredParts);
		foreach (string ip : insuredParts)
			insured.Insert(ip == "1");
		ParseSplitString(ownersStr, "###", owners);
		ParseSplitInt(damagedStr, "|", damaged);
		ParseSplitInt(fuelsStr, "|", fuels);

		// Pre-charge les donnees + les noms de proprios + flag "mode Fourriere" dans le menu
		// puis l ouvre. Le menu affichera le nom du proprio original a cote du nom du vehicule.
		JobVirtualGarageMenu.SetPendingData(indexes, prefabs, insured, npcRplId);
		JobVirtualGarageMenu.SetPendingDamaged(damaged);
		JobVirtualGarageMenu.SetPendingFuels(fuels);
		JobVirtualGarageMenu.SetPendingOwnerNames(owners);
		JobVirtualGarageMenu.SetFourriereMode(true);
		GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.JobVirtualGarageMenu);
	}

	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : recupere un vehicule precis du garage partage Fourriere
	//------------------------------------------------------------------------------------------------
	void ClientAskFourriereRetrieveVehicle(RplId npcRplId, int garageIndex)
	{
		Rpc(RpcAsk_FourriereRetrieveVehicle, npcRplId, garageIndex);
	}

	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_FourriereRetrieveVehicle(RplId npcRplId, int garageIndex)
	{
		if (!Replication.IsServer())
			return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc)
			return;
		int playerId = pc.GetPlayerId();

		if (!IsCallerFourriere(playerId))
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[FOURRIERE] Acces refuse : vous devez etre employe de la fourriere.");
			return;
		}

		// Resoud le PNJ
		RplComponent rpl = RplComponent.Cast(Replication.FindItem(npcRplId));
		if (!rpl)
			return;
		IEntity npc = rpl.GetEntity();
		if (!npc)
			return;

		// Calcule la direction "devant" le PNJ
		vector npcMat[4];
		npc.GetWorldTransform(npcMat);
		vector forward = -npcMat[2];

		// Recupere via l UID partage FOURRIERE_SHARED
		string vehiclePrefab;
		IEntity spawnedVehicle;
		int result = JobVirtualGarageManager.GetInstance().RetrieveVehicleByIndex(
			FOURRIERE_SHARED_UID, garageIndex, npc.GetOrigin(), forward, vehiclePrefab, spawnedVehicle);

		switch (result)
		{
			case 0:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[FOURRIERE] Vehicule sorti du garage ! Il vous attend devant le PNJ.");
				break;
			case 1:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[FOURRIERE] Vehicule introuvable (deja sorti par un collegue ?).");
				break;
			case 2:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[FOURRIERE] Erreur d acces au vehicule.");
				break;
			case 3:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[FOURRIERE] Erreur lors du spawn du vehicule (prefab invalide ?).");
				break;
		}
	}

	//------------------------------------------------------------------------------------------------
	// ===== TRANSFERT DE PROPRIETE D UN VEHICULE STOCKE =====
	//------------------------------------------------------------------------------------------------
	
	// CLIENT -> SERVER : demande la liste des joueurs connectes (pour le menu transfert)
	void ClientAskConnectedPlayersList()
	{
		Rpc(RpcAsk_ConnectedPlayersList);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_ConnectedPlayersList()
	{
		if (!Replication.IsServer())
			return;
		PlayerController callerPc = PlayerController.Cast(GetOwner());
		if (!callerPc)
			return;
		int callerPid = callerPc.GetPlayerId();
		
		// Recupere tous les joueurs connectes sauf le caller
		PlayerManager pm = GetGame().GetPlayerManager();
		if (!pm)
			return;
		array<int> allPids = new array<int>();
		pm.GetPlayers(allPids);
		
		// Serialise la liste : "uid1|uid2|uid3" et "name1###name2###name3"
		string uidsStr = "";
		string namesStr = "";
		int countAdded = 0;
		foreach (int pid : allPids)
		{
			if (pid == callerPid)
				continue;
			string uid = JobManager.GetInstance().GetPersistentUID(pid);
			if (uid == "")
				continue;
			string name = JobCriminalManager.GetPlayerNameById(pid);
			if (name == "")
				name = "Joueur " + pid.ToString();
			
			if (countAdded > 0)
			{
				uidsStr = uidsStr + "|";
				namesStr = namesStr + "###";
			}
			uidsStr = uidsStr + uid;
			namesStr = namesStr + name;
			countAdded++;
		}
		
		Rpc(RpcDo_ReceiveConnectedPlayers, uidsStr, namesStr);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_ReceiveConnectedPlayers(string uidsStr, string namesStr)
	{
		// Parse les chaines
		array<string> uids = new array<string>();
		array<string> names = new array<string>();
		ParseSplitString(uidsStr, "|", uids);
		ParseSplitString(namesStr, "###", names);
		
		// Le menu transfert est ouvert -> lui pousser les donnees
		JobGarageTransferMenu menu = JobGarageTransferMenu.GetOpenMenu();
		if (menu)
			menu.SetPlayersList(uids, names);
	}
	
	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : transfert effectif du vehicule a un autre joueur
	//------------------------------------------------------------------------------------------------
	void ClientAskTransferVehicle(int garageIndex, string newOwnerUID)
	{
		Rpc(RpcAsk_TransferVehicle, garageIndex, newOwnerUID);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_TransferVehicle(int garageIndex, string newOwnerUID)
	{
		if (!Replication.IsServer())
			return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc)
			return;
		int playerId = pc.GetPlayerId();
		string callerUID = JobManager.GetInstance().GetPersistentUID(playerId);
		if (callerUID == "")
			return;
		
		string prefab;
		int result = JobVirtualGarageManager.GetInstance().TransferOwnership(
			callerUID, garageIndex, newOwnerUID, prefab);
		
		switch (result)
		{
			case 0:
			{
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[GARAGE] Vehicule transfere avec succes.");
				// Notifie le nouveau proprietaire s il est connecte
				int newOwnerPid = JobCriminalManager.GetPlayerIdFromUID(newOwnerUID);
				if (newOwnerPid > 0)
				{
					JobManager.GetInstance().NotifyPlayerChat(newOwnerPid,
						"[GARAGE] Un joueur vous a transfere un vehicule. Il apparait dans votre garage virtuel.");
				}
				break;
			}
			case 1:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[GARAGE] Index de vehicule invalide.");
				break;
			case 2:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[GARAGE] Ce vehicule ne vous appartient pas.");
				break;
			case 3:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[GARAGE] Destinataire invalide.");
				break;
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// ============================================================
	// ENTREPRISES (SESSION 1 : creation)
	// ============================================================
	// Permet a un joueur de creer une entreprise via le PNJ Maire. Cout 30000 capsules,
	// 1 entreprise par joueur, metier doit etre dans la liste autorisee.
	//------------------------------------------------------------------------------------------------
	
	// CLIENT -> SERVER : demande de creation d entreprise
	void ClientAskCreateCompany(string companyName, EJobType jobType)
	{
		Rpc(RpcAsk_CreateCompany, companyName, jobType);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_CreateCompany(string companyName, EJobType jobType)
	{
		if (!Replication.IsServer())
			return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc)
			return;
		int playerId = pc.GetPlayerId();
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "")
			return;
		// Nom affiche : identite RP si dispo (Prenom Nom), sinon nom Bohemia
		string displayName = JobIdentityManager.GetInstance().GetDisplayNameByPlayerId(playerId);
		if (displayName == "")
			displayName = "Joueur " + playerId.ToString();
		
		int result = JobCompanyManager.GetInstance().CreateCompany(uid, displayName, companyName, jobType);
		
		switch (result)
		{
			case 0:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					string.Format("[ENTREPRISE] Votre entreprise '%1' a ete creee avec succes !", companyName));
				// Assigne le metier de l entreprise au patron
				JobManager.GetInstance().SetPlayerJob(playerId, jobType);
				break;
			case 1:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[ENTREPRISE] Le nom de l entreprise ne peut pas etre vide.");
				break;
			case 2:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[ENTREPRISE] Ce nom d entreprise est deja pris.");
				break;
			case 3:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[ENTREPRISE] Vous etes deja patron d une entreprise.");
				break;
			case 4:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[ENTREPRISE] Solde insuffisant (30000 capsules requises).");
				break;
			case 5:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[ENTREPRISE] Vous etes deja employe d une autre entreprise.");
				break;
			case 6:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[ENTREPRISE] Metier invalide pour creer une entreprise.");
				break;
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// ============================================================
	// ENTREPRISES - SESSION 2 : ACCES + BONS DE COMMANDE
	// ============================================================
	//------------------------------------------------------------------------------------------------
	
	// === ACCES ENTREPRISE (ouverture du menu depuis PNJ metier) ===
	
	void ClientAskOpenCompanyAccess()
	{
		Rpc(RpcAsk_OpenCompanyAccess);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_OpenCompanyAccess()
	{
		if (!Replication.IsServer())
			return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "") return;
		
		JobCompany c = JobCompanyManager.GetInstance().GetCompanyOfPlayer(uid);
		if (!c)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[ENTREPRISE] Vous n etes ni patron ni employe d une entreprise.");
			return;
		}
		
		// Compute stats
		int pendingCount = 0;
		int totalCount = c.m_Orders.Count();
		foreach (JobCompanyOrder o : c.m_Orders)
		{
			if (o && o.m_Status == 0)
				pendingCount++;
		}
		
		// Top 3 employes (par nombre de bons valides)
		string top3Text = BuildTop3Text(c);
		
		// Envoie payload au client. La fonction Rpc a une limite de parametres (9 max),
		// donc on compacte les 5 ints en un seul string "benefits;totalSales;pending;total;employees".
		bool isOwner = c.IsOwner(uid);
		string stats = c.m_Benefits.ToString() + ";"
			+ c.m_TotalSales.ToString() + ";"
			+ pendingCount.ToString() + ";"
			+ totalCount.ToString() + ";"
			+ c.m_Employees.Count().ToString();
		Rpc(RpcDo_ReceiveCompanyPayload,
			isOwner,
			c.m_Name,
			c.m_JobType,
			stats,
			top3Text);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_ReceiveCompanyPayload(bool isOwner, string companyName, int jobType,
		string statsStr, string top3Text)
	{
		// Parse les stats du format "benefits;totalSales;pending;total;employees"
		array<string> fields = new array<string>();
		ParseSplitString(statsStr, ";", fields);
		int benefits = 0;
		int totalSales = 0;
		int pendingCount = 0;
		int totalCount = 0;
		int employeeCount = 0;
		if (fields.Count() >= 5)
		{
			benefits = fields.Get(0).ToInt();
			totalSales = fields.Get(1).ToInt();
			pendingCount = fields.Get(2).ToInt();
			totalCount = fields.Get(3).ToInt();
			employeeCount = fields.Get(4).ToInt();
		}
		
		JobCompanyMenuPayload p = new JobCompanyMenuPayload();
		p.m_IsOwner = isOwner;
		p.m_CompanyName = companyName;
		p.m_JobType = jobType;
		p.m_Benefits = benefits;
		p.m_TotalSales = totalSales;
		p.m_PendingOrderCount = pendingCount;
		p.m_TotalOrderCount = totalCount;
		p.m_EmployeeCount = employeeCount;
		p.m_Top3Text = top3Text;
		
		JobCompanyAccessMenu.SetPendingPayload(p);
		GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.JobCompanyAccessMenu);
	}
	
	// Helper : construit le texte top 3 employes en comptant les bons valides
	string BuildTop3Text(JobCompany c)
	{
		// Compte les bons valides par auteur
		map<string, int> countByAuthor = new map<string, int>();
		map<string, string> nameByAuthor = new map<string, string>();
		foreach (JobCompanyOrder o : c.m_Orders)
		{
			if (!o || o.m_Status != 1) continue;
			int existing;
			if (countByAuthor.Find(o.m_AuthorUID, existing))
				countByAuthor.Set(o.m_AuthorUID, existing + 1);
			else
			{
				countByAuthor.Set(o.m_AuthorUID, 1);
				nameByAuthor.Set(o.m_AuthorUID, o.m_AuthorDisplayName);
			}
		}
		
		// Tri rudimentaire (selection des 3 plus gros)
		array<string> topUIDs = new array<string>();
		array<int> topCounts = new array<int>();
		for (int rank = 0; rank < 3; rank++)
		{
			string bestUID = "";
			int bestCount = 0;
			foreach (string uid, int cnt : countByAuthor)
			{
				if (cnt > bestCount && topUIDs.Find(uid) < 0)
				{
					bestCount = cnt;
					bestUID = uid;
				}
			}
			if (bestUID == "") break;
			topUIDs.Insert(bestUID);
			topCounts.Insert(bestCount);
		}
		
		string s = "";
		for (int i = 0; i < topUIDs.Count(); i++)
		{
			string nm = nameByAuthor.Get(topUIDs.Get(i));
			s = s + string.Format("%1. %2 - %3 vente(s)\n",
				(i + 1).ToString(), nm, topCounts.Get(i).ToString());
		}
		return s;
	}
	
	// === RETRAIT BENEFICES ===
	
	void ClientAskWithdrawCompanyBenefits()
	{
		Rpc(RpcAsk_WithdrawCompanyBenefits);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_WithdrawCompanyBenefits()
	{
		if (!Replication.IsServer())
			return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "") return;
		
		JobCompany c = JobCompanyManager.GetInstance().GetCompanyOwnedBy(uid);
		if (!c)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[ENTREPRISE] Vous n etes patron d aucune entreprise.");
			return;
		}
		
		int amount = JobCompanyManager.GetInstance().WithdrawBenefits(uid, c.m_Name);
		if (amount > 0)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				string.Format("[ENTREPRISE] %1 capsules retirees de la cagnotte vers votre compte.",
					amount.ToString()));
		}
		else
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[ENTREPRISE] Aucun benefice a retirer.");
		}
	}
	
	// === INJECTION DE CAPSULES DANS LA CAGNOTTE ===
	
	void ClientAskInjectCompanyBenefits(int amount)
	{
		Rpc(RpcAsk_InjectCompanyBenefits, amount);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_InjectCompanyBenefits(int amount)
	{
		if (!Replication.IsServer())
			return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "") return;
		
		JobCompany c = JobCompanyManager.GetInstance().GetCompanyOwnedBy(uid);
		if (!c)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[ENTREPRISE] Vous n etes patron d aucune entreprise.");
			return;
		}
		
		int result = JobCompanyManager.GetInstance().InjectBenefits(uid, c.m_Name, amount);
		switch (result)
		{
			case 0:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					string.Format("[ENTREPRISE] %1 capsules injectees dans la cagnotte de '%2'.",
						amount.ToString(), c.m_Name));
				break;
			case 2:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[ENTREPRISE] Montant invalide.");
				break;
			case 3:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[ENTREPRISE] Solde personnel insuffisant.");
				break;
		}
	}
	
	// === DISSOLUTION ENTREPRISE ===
	
	void ClientAskDissolveCompany()
	{
		Rpc(RpcAsk_DissolveCompany);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_DissolveCompany()
	{
		if (!Replication.IsServer())
			return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "") return;
		
		JobCompany c = JobCompanyManager.GetInstance().GetCompanyOwnedBy(uid);
		if (!c)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[ENTREPRISE] Vous n etes patron d aucune entreprise.");
			return;
		}
		
		string companyName = c.m_Name;
		array<string> employeeUIDs = new array<string>();
		int result = JobCompanyManager.GetInstance().DissolveCompany(uid, companyName, employeeUIDs);
		if (result == 0)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				string.Format("[ENTREPRISE] Vous avez dissous l entreprise '%1'.", companyName));
			// Le patron devient chomeur
			JobManager.GetInstance().SetPlayerJob(playerId, EJobType.CHOMEUR);
			foreach (string empUID : employeeUIDs)
			{
				int empPid = JobCriminalManager.GetPlayerIdFromUID(empUID);
				if (empPid > 0)
				{
					JobManager.GetInstance().NotifyPlayerChat(empPid,
						string.Format("[ENTREPRISE] L entreprise '%1' a ete dissoute par son patron.", companyName));
					// L employe devient chomeur
					JobManager.GetInstance().SetPlayerJob(empPid, EJobType.CHOMEUR);
				}
			}
		}
	}
	
	// === DEMISSION EMPLOYE ===
	
	void ClientAskResignFromCompany()
	{
		Rpc(RpcAsk_ResignFromCompany);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_ResignFromCompany()
	{
		if (!Replication.IsServer())
			return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "") return;
		
		JobCompany c = JobCompanyManager.GetInstance().GetCompanyEmployedBy(uid);
		if (!c)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[ENTREPRISE] Vous n etes employe d aucune entreprise.");
			return;
		}
		
		string companyName = c.m_Name;
		string ownerUID = c.m_OwnerUID;
		string resigningName;
		
		// Retire l employe
		for (int i = c.m_Employees.Count() - 1; i >= 0; i--)
		{
			JobCompanyEmployee e = c.m_Employees.Get(i);
			if (e && e.m_UID == uid)
			{
				resigningName = e.m_DisplayName;
				c.m_Employees.Remove(i);
				break;
			}
		}
		JobCompanyManager.GetInstance().SaveToDisk();
		
		JobManager.GetInstance().NotifyPlayerChat(playerId,
			string.Format("[ENTREPRISE] Vous avez demissionne de '%1'.", companyName));
		
		// L employe demissionnaire devient chomeur
		JobManager.GetInstance().SetPlayerJob(playerId, EJobType.CHOMEUR);
		
		// Notif au patron
		int ownerPid = JobCriminalManager.GetPlayerIdFromUID(ownerUID);
		if (ownerPid > 0)
		{
			JobManager.GetInstance().NotifyPlayerChat(ownerPid,
				string.Format("[ENTREPRISE] %1 a demissionne de votre entreprise '%2'.",
					resigningName, companyName));
		}
	}
	
	// === CREATION BON : LISTER L INVENTAIRE ===
	
	void ClientAskListInventoryForOrder()
	{
		Rpc(RpcAsk_ListInventoryForOrder);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_ListInventoryForOrder()
	{
		if (!Replication.IsServer())
			return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "") return;
		
		// Verifie membre d entreprise
		JobCompany c = JobCompanyManager.GetInstance().GetCompanyOfPlayer(uid);
		if (!c)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[ENTREPRISE] Vous n etes pas membre d une entreprise.");
			return;
		}
		
		// Scan inventory
		IEntity character = pc.GetControlledEntity();
		if (!character) return;
		SCR_InventoryStorageManagerComponent invMgr = SCR_InventoryStorageManagerComponent.Cast(
			character.FindComponent(SCR_InventoryStorageManagerComponent));
		if (!invMgr)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[ENTREPRISE] Erreur d acces a votre inventaire.");
			return;
		}
		
		array<IEntity> items = new array<IEntity>();
		invMgr.GetItems(items);
		
		// Serialise prefab + nom
		string prefabsStr = "";
		string namesStr = "";
		int count = 0;
		foreach (IEntity item : items)
		{
			if (!item) continue;
			EntityPrefabData pd = item.GetPrefabData();
			if (!pd) continue;
			ResourceName rn = pd.GetPrefabName();
			if (rn == "" || rn == ResourceName.Empty) continue;
			string nm = ExtractItemDisplayName(rn);
			if (count > 0)
			{
				prefabsStr = prefabsStr + "###";
				namesStr = namesStr + "###";
			}
			prefabsStr = prefabsStr + rn;
			namesStr = namesStr + nm;
			count++;
		}
		
		Rpc(RpcDo_ReceiveInventoryForOrder, prefabsStr, namesStr);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_ReceiveInventoryForOrder(string prefabsStr, string namesStr)
	{
		array<string> prefabs = new array<string>();
		array<string> names = new array<string>();
		ParseSplitString(prefabsStr, "###", prefabs);
		ParseSplitString(namesStr, "###", names);
		
		JobCompanyCreateOrderMenu.SetPendingItems(prefabs, names);
		GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.JobCompanyCreateOrderMenu);
	}
	
	// Extrait un nom lisible d un prefab path
	string ExtractItemDisplayName(string prefab)
	{
		int lastSlash = -1;
		for (int i = prefab.Length() - 1; i >= 0; i--)
		{
			if (prefab.Get(i) == "/")
			{
				lastSlash = i;
				break;
			}
		}
		string name;
		if (lastSlash >= 0 && lastSlash + 1 < prefab.Length())
			name = prefab.Substring(lastSlash + 1, prefab.Length() - lastSlash - 1);
		else
			name = prefab;
		if (name.Length() > 3)
		{
			string suffix = name.Substring(name.Length() - 3, 3);
			if (suffix == ".et")
				name = name.Substring(0, name.Length() - 3);
		}
		return name;
	}
	
	// === CREATION BON DE COMMANDE ===
	
	void ClientAskCreateCompanyOrder(string prefabsStr, int proposedPrice)
	{
		Rpc(RpcAsk_CreateCompanyOrder, prefabsStr, proposedPrice);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_CreateCompanyOrder(string prefabsStr, int proposedPrice)
	{
		if (!Replication.IsServer())
			return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "") return;
		// Nom affiche : identite RP si dispo (Prenom Nom), sinon nom Bohemia
		string displayName = JobIdentityManager.GetInstance().GetDisplayNameByPlayerId(playerId);
		if (displayName == "")
			displayName = "Joueur " + playerId.ToString();
		
		// Verifie membre entreprise
		JobCompany c = JobCompanyManager.GetInstance().GetCompanyOfPlayer(uid);
		if (!c)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[ENTREPRISE] Vous n etes pas membre d une entreprise.");
			return;
		}
		
		// Parse les prefabs choisis
		array<string> selectedPrefabs = new array<string>();
		ParseSplitString(prefabsStr, "###", selectedPrefabs);
		if (selectedPrefabs.Count() == 0)
			return;
		
		// Verifie + retire les items de l inventaire du joueur
		IEntity character = pc.GetControlledEntity();
		if (!character) return;
		SCR_InventoryStorageManagerComponent invMgr = SCR_InventoryStorageManagerComponent.Cast(
			character.FindComponent(SCR_InventoryStorageManagerComponent));
		if (!invMgr) return;
		
		array<IEntity> currentItems = new array<IEntity>();
		invMgr.GetItems(currentItems);
		
		// Pour chaque prefab demande, on trouve la 1ere occurrence dans l inventaire et on la retire
		array<ref JobCompanyOrderItem> orderItems = new array<ref JobCompanyOrderItem>();
		foreach (string wantedPrefab : selectedPrefabs)
		{
			if (wantedPrefab == "") continue;
			IEntity match = null;
			foreach (IEntity item : currentItems)
			{
				if (!item) continue;
				EntityPrefabData pd = item.GetPrefabData();
				if (!pd) continue;
				ResourceName rn = pd.GetPrefabName();
				if (rn == wantedPrefab)
				{
					match = item;
					break;
				}
			}
			if (!match)
			{
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[ENTREPRISE] Certains items n ont pas pu etre trouves dans votre inventaire.");
				continue;
			}
			
			// Retire de la liste pour ne pas re-matcher le meme item
			int idxInList = currentItems.Find(match);
			if (idxInList >= 0)
				currentItems.Remove(idxInList);
			
			// Supprime l item de l inventaire (FindStorageForItem + DeleteEntity)
			BaseInventoryStorageComponent parentStorage = invMgr.FindStorageForItem(match);
			bool removed = invMgr.TryRemoveItemFromStorage(match, parentStorage);
			SCR_EntityHelper.DeleteEntityAndChildren(match);
			
			JobCompanyOrderItem oi = new JobCompanyOrderItem();
			oi.m_PrefabName = wantedPrefab;
			oi.m_Quantity = 1;
			orderItems.Insert(oi);
		}
		
		if (orderItems.Count() == 0)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[ENTREPRISE] Aucun item valide pour creer le bon.");
			return;
		}
		
		// Cree le bon
		int newOrderId;
		string companyName;
		int result = JobCompanyManager.GetInstance().CreateOrder(uid, displayName, proposedPrice,
			orderItems, newOrderId, companyName);
		
		switch (result)
		{
			case 0:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					string.Format("[ENTREPRISE] Bon #%1 cree (prix demande : %2 capsules).",
						newOrderId.ToString(), proposedPrice.ToString()));
				// Notifie le patron s il est connecte
				int ownerPid = JobCriminalManager.GetPlayerIdFromUID(c.m_OwnerUID);
				if (ownerPid > 0 && ownerPid != playerId)
				{
					JobManager.GetInstance().NotifyPlayerChat(ownerPid,
						string.Format("[ENTREPRISE] Nouveau bon de %1 (%2 items, %3 capsules demandees).",
							displayName, orderItems.Count().ToString(), proposedPrice.ToString()));
				}
				break;
			case 1:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[ENTREPRISE] Vous n etes pas membre d une entreprise.");
				break;
			case 2:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[ENTREPRISE] Prix invalide.");
				break;
			case 3:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[ENTREPRISE] Aucun item dans le bon.");
				break;
		}
	}
	
	// === LISTE DES BONS DE COMMANDE ===
	
	void ClientAskListOrders(bool ownerPendingOnly)
	{
		Rpc(RpcAsk_ListOrders, ownerPendingOnly);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_ListOrders(bool ownerPendingOnly)
	{
		if (!Replication.IsServer())
			return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "") return;
		
		JobCompany c = JobCompanyManager.GetInstance().GetCompanyOfPlayer(uid);
		if (!c) return;
		bool isOwner = c.IsOwner(uid);
		
		// Filtre : si ownerPendingOnly + viewer est patron -> bons en attente uniquement
		// Sinon -> bons dont je suis l auteur
		string serialized = "";
		int count = 0;
		foreach (JobCompanyOrder o : c.m_Orders)
		{
			if (!o) continue;
			bool include = false;
			if (ownerPendingOnly && isOwner)
				include = (o.m_Status == 0);
			else
				include = (o.m_AuthorUID == uid);
			if (!include) continue;
			
			if (count > 0)
				serialized = serialized + "|||";
			// Format compact : id;status;proposed;final;itemCount;authorName
			serialized = serialized + o.m_OrderId.ToString() + ";";
			serialized = serialized + o.m_Status.ToString() + ";";
			serialized = serialized + o.m_ProposedPrice.ToString() + ";";
			serialized = serialized + o.m_FinalPrice.ToString() + ";";
			serialized = serialized + o.m_Items.Count().ToString() + ";";
			serialized = serialized + o.m_AuthorDisplayName;
			count++;
		}
		
		Rpc(RpcDo_ReceiveOrdersList, serialized, ownerPendingOnly && isOwner);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_ReceiveOrdersList(string serialized, bool ownerView)
	{
		array<ref JobCompanyOrderEntry> orders = new array<ref JobCompanyOrderEntry>();
		if (serialized != "")
		{
			array<string> entries = new array<string>();
			ParseSplitString(serialized, "|||", entries);
			foreach (string e : entries)
			{
				array<string> fields = new array<string>();
				ParseSplitString(e, ";", fields);
				if (fields.Count() < 6) continue;
				JobCompanyOrderEntry oe = new JobCompanyOrderEntry();
				oe.m_OrderId = fields.Get(0).ToInt();
				oe.m_Status = fields.Get(1).ToInt();
				oe.m_ProposedPrice = fields.Get(2).ToInt();
				oe.m_FinalPrice = fields.Get(3).ToInt();
				oe.m_ItemCount = fields.Get(4).ToInt();
				oe.m_AuthorName = fields.Get(5);
				orders.Insert(oe);
			}
		}
		
		JobCompanyOrderListMenu.SetPendingData(orders, ownerView);
		GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.JobCompanyOrderListMenu);
	}
	
	// === DETAIL D UN BON DE COMMANDE ===
	
	void ClientAskOrderDetail(int orderId)
	{
		Rpc(RpcAsk_OrderDetail, orderId);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_OrderDetail(int orderId)
	{
		if (!Replication.IsServer())
			return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "") return;
		
		JobCompany c = JobCompanyManager.GetInstance().GetCompanyOfPlayer(uid);
		if (!c) return;
		JobCompanyOrder o = JobCompanyManager.GetInstance().FindOrder(c, orderId);
		if (!o) return;
		
		// Serialise les noms d items
		string itemNamesStr = "";
		for (int i = 0; i < o.m_Items.Count(); i++)
		{
			JobCompanyOrderItem it = o.m_Items.Get(i);
			if (!it) continue;
			if (i > 0)
				itemNamesStr = itemNamesStr + "###";
			itemNamesStr = itemNamesStr + ExtractItemDisplayName(it.m_PrefabName);
		}
		
		// canAct = viewer est patron ET bon en attente
		bool canAct = c.IsOwner(uid) && (o.m_Status == 0);
		// canRecover = viewer est l auteur ET statut REFUSE ET items pas encore recuperes
		bool canRecover = (o.m_AuthorUID == uid) && (o.m_Status == 2) && (!o.m_ItemsRecovered);
		// flags compactes : "canAct|canRecover|itemsRecovered" (1 ou 0)
		string flags = "";
		if (canAct) flags = flags + "1"; else flags = flags + "0";
		flags = flags + "|";
		if (canRecover) flags = flags + "1"; else flags = flags + "0";
		flags = flags + "|";
		if (o.m_ItemsRecovered) flags = flags + "1"; else flags = flags + "0";
		
		Rpc(RpcDo_ReceiveOrderDetail,
			o.m_OrderId, o.m_Status, o.m_ProposedPrice, o.m_FinalPrice,
			o.m_AuthorDisplayName, itemNamesStr, flags);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_ReceiveOrderDetail(int orderId, int status, int proposedPrice, int finalPrice,
		string authorName, string itemNamesStr, string flags)
	{
		array<string> itemNames = new array<string>();
		ParseSplitString(itemNamesStr, "###", itemNames);
		
		// Parse les flags
		array<string> flagParts = new array<string>();
		ParseSplitString(flags, "|", flagParts);
		bool canAct = false;
		bool canRecover = false;
		bool itemsRecovered = false;
		if (flagParts.Count() >= 3)
		{
			canAct = (flagParts.Get(0) == "1");
			canRecover = (flagParts.Get(1) == "1");
			itemsRecovered = (flagParts.Get(2) == "1");
		}
		
		JobCompanyOrderDetailMenu.SetPendingData(orderId, status, proposedPrice, finalPrice,
			authorName, itemNames, canAct, canRecover, itemsRecovered);
		GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.JobCompanyOrderDetailMenu);
	}
	
	// === ACCEPTATION D UN BON ===
	
	void ClientAskAcceptOrder(int orderId, int finalPrice)
	{
		Rpc(RpcAsk_AcceptOrder, orderId, finalPrice);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_AcceptOrder(int orderId, int finalPrice)
	{
		if (!Replication.IsServer())
			return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "") return;
		
		JobCompany c = JobCompanyManager.GetInstance().GetCompanyOwnedBy(uid);
		if (!c) return;
		
		string authorUID;
		array<ref JobCompanyOrderItem> items;
		int result = JobCompanyManager.GetInstance().AcceptOrder(uid, c.m_Name, orderId,
			finalPrice, authorUID, items);
		
		switch (result)
		{
			case 0:
			{
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					string.Format("[ENTREPRISE] Bon #%1 accepte. %2 capsules payees a l employe.",
						orderId.ToString(), finalPrice.ToString()));
				
				// Spawn les items dans l inventaire du patron (livraison).
				// Si inventaire plein, drop au sol a la position du patron.
				IEntity character = pc.GetControlledEntity();
				if (character && items)
				{
					foreach (JobCompanyOrderItem it : items)
					{
						if (it)
						{
							ResourceName rn = it.m_PrefabName;
							SpawnItemWithGroundFallback(character, rn, playerId);
						}
					}
				}
				
				// Notifie l employe
				int authorPid = JobCriminalManager.GetPlayerIdFromUID(authorUID);
				if (authorPid > 0 && authorPid != playerId)
				{
					JobManager.GetInstance().NotifyPlayerChat(authorPid,
						string.Format("[ENTREPRISE] Votre bon #%1 a ete valide ! %2 capsules creditees.",
							orderId.ToString(), finalPrice.ToString()));
				}
				break;
			}
			case 1:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[ENTREPRISE] Vous n etes pas le patron.");
				break;
			case 2:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[ENTREPRISE] Bon introuvable.");
				break;
			case 3:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[ENTREPRISE] Ce bon a deja ete traite.");
				break;
			case 4:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[ENTREPRISE] Cagnotte entreprise insuffisante.");
				break;
			case 5:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[ENTREPRISE] Prix final invalide.");
				break;
		}
	}
	
	// === REFUS D UN BON ===
	
	void ClientAskRefuseOrder(int orderId)
	{
		Rpc(RpcAsk_RefuseOrder, orderId);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_RefuseOrder(int orderId)
	{
		if (!Replication.IsServer())
			return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "") return;
		
		JobCompany c = JobCompanyManager.GetInstance().GetCompanyOwnedBy(uid);
		if (!c) return;
		
		string authorUID;
		array<ref JobCompanyOrderItem> items;
		int result = JobCompanyManager.GetInstance().RefuseOrder(uid, c.m_Name, orderId,
			authorUID, items);
		
		if (result == 0)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				string.Format("[ENTREPRISE] Bon #%1 refuse.",
					orderId.ToString()));
			
			// L employe doit aller cliquer sur 'Recuperer mes items' dans son bon refuse.
			// Pas de restitution automatique : evite la perte si inventaire plein ou deconnexion.
			int authorPid = JobCriminalManager.GetPlayerIdFromUID(authorUID);
			if (authorPid > 0 && authorPid != playerId)
			{
				JobManager.GetInstance().NotifyPlayerChat(authorPid,
					string.Format("[ENTREPRISE] Votre bon #%1 a ete refuse. Allez le voir pour recuperer vos items.",
						orderId.ToString()));
			}
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// ============================================================
	// ENTREPRISES - SESSION 3 : GESTION EMPLOYES + CHAT INTERNE
	// ============================================================
	//------------------------------------------------------------------------------------------------
	
	// === OUVERTURE DU MENU GESTION EMPLOYES ===
	
	void ClientAskOpenEmployees()
	{
		Rpc(RpcAsk_OpenEmployees);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_OpenEmployees()
	{
		if (!Replication.IsServer()) return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "") return;
		
		JobCompany c = JobCompanyManager.GetInstance().GetCompanyOwnedBy(uid);
		if (!c)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[ENTREPRISE] Vous n etes patron d aucune entreprise.");
			return;
		}
		
		// Serialise les UIDs et noms en deux strings "uid1###uid2###..."
		string uidsStr = "";
		string namesStr = "";
		for (int i = 0; i < c.m_Employees.Count(); i++)
		{
			JobCompanyEmployee e = c.m_Employees.Get(i);
			if (!e) continue;
			if (i > 0)
			{
				uidsStr = uidsStr + "###";
				namesStr = namesStr + "###";
			}
			uidsStr = uidsStr + e.m_UID;
			namesStr = namesStr + e.m_DisplayName;
		}
		
		Rpc(RpcDo_ReceiveEmployees, uidsStr, namesStr);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_ReceiveEmployees(string uidsStr, string namesStr)
	{
		array<string> uids = new array<string>();
		array<string> names = new array<string>();
		ParseSplitString(uidsStr, "###", uids);
		ParseSplitString(namesStr, "###", names);
		
		JobCompanyEmployeesMenu.SetPendingData(uids, names);
		GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.JobCompanyEmployeesMenu);
	}
	
	// === OUVERTURE DU MENU RECRUTEMENT ===
	
	void ClientAskOpenRecruitMenu()
	{
		Rpc(RpcAsk_OpenRecruitMenu);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_OpenRecruitMenu()
	{
		if (!Replication.IsServer()) return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "") return;
		
		JobCompany c = JobCompanyManager.GetInstance().GetCompanyOwnedBy(uid);
		if (!c)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[ENTREPRISE] Vous n etes patron d aucune entreprise.");
			return;
		}
		if (c.m_Employees.Count() >= JobCompanyManager.MAX_EMPLOYEES)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[ENTREPRISE] Votre entreprise a atteint le maximum d employes (5).");
			return;
		}
		
		// Liste tous les joueurs connectes, filtre : pas moi, pas deja patron, pas deja employe
		array<int> players = new array<int>();
		GetGame().GetPlayerManager().GetPlayers(players);
		
		string uidsStr = "";
		string namesStr = "";
		int count = 0;
		foreach (int otherPid : players)
		{
			if (otherPid == playerId) continue;
			string otherUID = JobManager.GetInstance().GetPersistentUID(otherPid);
			if (otherUID == "") continue;
			// Skip si deja patron OU employe d une entreprise
			if (JobCompanyManager.GetInstance().GetCompanyOfPlayer(otherUID)) continue;
			string otherName = JobIdentityManager.GetInstance().GetDisplayNameByPlayerId(otherPid);
			if (otherName == "")
				otherName = "Joueur " + otherPid.ToString();
			if (count > 0)
			{
				uidsStr = uidsStr + "###";
				namesStr = namesStr + "###";
			}
			uidsStr = uidsStr + otherUID;
			namesStr = namesStr + otherName;
			count++;
		}
		
		Rpc(RpcDo_ReceiveRecruitList, uidsStr, namesStr);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_ReceiveRecruitList(string uidsStr, string namesStr)
	{
		array<string> uids = new array<string>();
		array<string> names = new array<string>();
		ParseSplitString(uidsStr, "###", uids);
		ParseSplitString(namesStr, "###", names);
		
		JobCompanyRecruitMenu.SetPendingData(uids, names);
		GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.JobCompanyRecruitMenu);
	}
	
	// === INVITATION DE RECRUTEMENT ===
	// Le menu de recrutement (cote patron) envoie une INVITATION au joueur cible.
	// Le joueur cible doit aller voir le PNJ Maire pour Accepter / Refuser.
	// Le nom de la fonction "ClientAskRecruitEmployee" est conserve pour ne pas casser
	// le menu JobCompanyRecruitMenu existant, mais cote serveur on appelle InviteEmployee.
	
	void ClientAskRecruitEmployee(string targetUID)
	{
		Rpc(RpcAsk_RecruitEmployee, targetUID);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_RecruitEmployee(string targetUID)
	{
		if (!Replication.IsServer()) return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "") return;
		
		JobCompany c = JobCompanyManager.GetInstance().GetCompanyOwnedBy(uid);
		if (!c) return;
		
		// Resoud le nom RP du patron (pour stocker dans l invitation)
		string ownerName = JobIdentityManager.GetInstance().GetDisplayNameByPlayerId(playerId);
		if (ownerName == "") ownerName = "Le patron";
		
		// Resoud le nom de la cible (pour les notifs chat)
		int targetPid = JobCriminalManager.GetPlayerIdFromUID(targetUID);
		string targetName = "Joueur";
		if (targetPid > 0)
		{
			targetName = JobIdentityManager.GetInstance().GetDisplayNameByPlayerId(targetPid);
		}
		if (targetName == "")
			targetName = "Joueur " + targetUID;
		
		int result = JobCompanyManager.GetInstance().InviteEmployee(uid, ownerName, c.m_Name, targetUID);
		switch (result)
		{
			case 0:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					string.Format("[ENTREPRISE] Invitation envoyee a %1 pour rejoindre '%2'.",
						targetName, c.m_Name));
				// Notif au joueur invite (si connecte)
				if (targetPid > 0 && targetPid != playerId)
				{
					JobManager.GetInstance().NotifyPlayerChat(targetPid,
						string.Format("[ENTREPRISE] %1 vous invite a rejoindre '%2'. Allez voir le Maire pour accepter ou refuser.",
							ownerName, c.m_Name));
				}
				break;
			case 2:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[ENTREPRISE] Votre entreprise est pleine (5 employes max).");
				break;
			case 3:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[ENTREPRISE] Ce joueur est deja patron d une autre entreprise.");
				break;
			case 4:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[ENTREPRISE] Ce joueur est deja employe quelque part.");
				break;
			case 6:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[ENTREPRISE] Ce joueur a deja une invitation en attente d un autre patron.");
				break;
		}
	}
	
	// === LICENCIEMENT ===
	
	void ClientAskFireEmployee(string targetUID)
	{
		Rpc(RpcAsk_FireEmployee, targetUID);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_FireEmployee(string targetUID)
	{
		if (!Replication.IsServer()) return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "") return;
		
		JobCompany c = JobCompanyManager.GetInstance().GetCompanyOwnedBy(uid);
		if (!c) return;
		
		string firedName;
		int result = JobCompanyManager.GetInstance().FireEmployee(uid, c.m_Name, targetUID, firedName);
		if (result == 0)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				string.Format("[ENTREPRISE] %1 a ete licencie de '%2'.", firedName, c.m_Name));
			// Notif au joueur licencie
			int targetPid = JobCriminalManager.GetPlayerIdFromUID(targetUID);
			if (targetPid > 0)
			{
				JobManager.GetInstance().NotifyPlayerChat(targetPid,
					string.Format("[ENTREPRISE] Vous avez ete licencie de '%1'.", c.m_Name));
				// L employe licencie devient chomeur
				JobManager.GetInstance().SetPlayerJob(targetPid, EJobType.CHOMEUR);
			}
		}
	}
	
	// === PAIEMENT SALAIRE ===
	
	void ClientAskPaySalary(string targetUID, int amount)
	{
		Rpc(RpcAsk_PaySalary, targetUID, amount);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_PaySalary(string targetUID, int amount)
	{
		if (!Replication.IsServer()) return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "") return;
		
		JobCompany c = JobCompanyManager.GetInstance().GetCompanyOwnedBy(uid);
		if (!c) return;
		
		int result = JobCompanyManager.GetInstance().PaySalary(uid, c.m_Name, targetUID, amount);
		switch (result)
		{
			case 0:
			{
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					string.Format("[ENTREPRISE] %1 capsules versees a l employe.", amount.ToString()));
				int targetPid = JobCriminalManager.GetPlayerIdFromUID(targetUID);
				if (targetPid > 0)
				{
					JobManager.GetInstance().NotifyPlayerChat(targetPid,
						string.Format("[ENTREPRISE] Vous avez recu un salaire de %1 capsules.",
							amount.ToString()));
				}
				break;
			}
			case 2:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[ENTREPRISE] Employe introuvable dans votre entreprise.");
				break;
			case 3:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[ENTREPRISE] Montant invalide.");
				break;
			case 4:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[ENTREPRISE] Cagnotte insuffisante.");
				break;
		}
	}
	
	// === CHAT : OUVERTURE INITIALE ===
	
	void ClientAskOpenChat()
	{
		Rpc(RpcAsk_OpenChat);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_OpenChat()
	{
		if (!Replication.IsServer()) return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "") return;
		
		JobCompany c = JobCompanyManager.GetInstance().GetCompanyOfPlayer(uid);
		if (!c)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[ENTREPRISE] Vous n etes pas membre d une entreprise.");
			return;
		}
		
		string chatText = BuildChatTextForCompany(c);
		Rpc(RpcDo_OpenChat, chatText);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_OpenChat(string chatText)
	{
		JobCompanyChatMenu.SetPendingMessagesText(chatText);
		GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.JobCompanyChatMenu);
	}
	
	// === CHAT : REFRESH PERIODIQUE ===
	
	void ClientAskRefreshCompanyChat()
	{
		Rpc(RpcAsk_RefreshCompanyChat);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_RefreshCompanyChat()
	{
		if (!Replication.IsServer()) return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		string uid = JobManager.GetInstance().GetPersistentUID(pc.GetPlayerId());
		if (uid == "") return;
		
		JobCompany c = JobCompanyManager.GetInstance().GetCompanyOfPlayer(uid);
		if (!c) return;
		
		string chatText = BuildChatTextForCompany(c);
		Rpc(RpcDo_RefreshChat, chatText);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_RefreshChat(string chatText)
	{
		// Met a jour le menu chat s il est ouvert (sinon ignore)
		JobCompanyChatMenu.SetPendingMessagesText(chatText);
	}
	
	// === CHAT : ENVOI MESSAGE ===
	
	void ClientAskSendCompanyChatMessage(string text)
	{
		Rpc(RpcAsk_SendCompanyChatMessage, text);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_SendCompanyChatMessage(string text)
	{
		if (!Replication.IsServer()) return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "") return;
		
		JobCompany c = JobCompanyManager.GetInstance().GetCompanyOfPlayer(uid);
		if (!c) return;
		
		// Nom affiche : identite RP si dispo (Prenom Nom), sinon nom Bohemia
		string displayName = JobIdentityManager.GetInstance().GetDisplayNameByPlayerId(playerId);
		if (displayName == "")
			displayName = "Joueur " + playerId.ToString();
		
		JobCompanyManager.GetInstance().AddChatMessage(uid, displayName, c.m_Name, text);
	}
	
	// Helper : construit le texte affichable des 30 derniers messages du chat.
	// Format : [HH:MM] NomAuteur: message
	string BuildChatTextForCompany(JobCompany c)
	{
		if (!c) return "";
		int total = c.m_ChatMessages.Count();
		if (total == 0) return "";
		
		int start = total - 30;
		if (start < 0) start = 0;
		
		string s = "";
		for (int i = start; i < total; i++)
		{
			JobCompanyChatMsg msg = c.m_ChatMessages.Get(i);
			if (!msg) continue;
			// Convertit timestamp Unix en HH:MM tres rudimentaire (secondes -> heure de la journee UTC)
			int totalSeconds = msg.m_Timestamp;
			int secondsInDay = totalSeconds - (totalSeconds / 86400) * 86400;
			int hours = secondsInDay / 3600;
			int minutes = (secondsInDay - hours * 3600) / 60;
			string hh = hours.ToString();
			string mm = minutes.ToString();
			if (hours < 10) hh = "0" + hh;
			if (minutes < 10) mm = "0" + mm;
			if (i > start) s = s + "\n";
			s = s + "[" + hh + ":" + mm + "] " + msg.m_AuthorDisplayName + ": " + msg.m_Text;
		}
		return s;
	}
	
	//------------------------------------------------------------------------------------------------
	// ============================================================
	// ENTREPRISES - SESSION 4 : INVITATIONS DE RECRUTEMENT
	// ============================================================
	//------------------------------------------------------------------------------------------------
	
	// === OUVERTURE DU MENU "MES INVITATIONS" (chez le Maire) ===
	
	void ClientAskOpenInvitations()
	{
		Rpc(RpcAsk_OpenInvitations);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_OpenInvitations()
	{
		if (!Replication.IsServer()) return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "") return;
		
		// V1 : une seule invitation max par joueur. On envoie l invitation s il y en a une.
		JobCompanyInvitation invit = JobCompanyManager.GetInstance().GetInvitationFor(uid);
		if (!invit)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[ENTREPRISE] Vous n avez aucune invitation en attente.");
			return;
		}
		
		// Envoie payload au client : companyName + ownerDisplayName + jobType + createdAt
		Rpc(RpcDo_ReceiveInvitation,
			invit.m_CompanyName,
			invit.m_OwnerDisplayName,
			invit.m_JobType,
			invit.m_CreatedAt);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_ReceiveInvitation(string companyName, string ownerName, int jobType, int createdAt)
	{
		JobCompanyInvitationsMenu.SetPendingData(companyName, ownerName, jobType, createdAt);
		GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.JobCompanyInvitationsMenu);
	}
	
	// === ACCEPTATION D UNE INVITATION ===
	
	void ClientAskAcceptInvitation()
	{
		Rpc(RpcAsk_AcceptInvitation);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_AcceptInvitation()
	{
		if (!Replication.IsServer()) return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "") return;
		// Nom RP du nouvel employe
		string displayName = JobIdentityManager.GetInstance().GetDisplayNameByPlayerId(playerId);
		if (displayName == "")
			displayName = "Joueur " + playerId.ToString();
		
		int jobType;
		string companyName;
		string ownerUID;
		int result = JobCompanyManager.GetInstance().AcceptInvitation(uid, displayName,
			jobType, companyName, ownerUID);
		
		switch (result)
		{
			case 0:
			{
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					string.Format("[ENTREPRISE] Vous avez rejoint '%1' !", companyName));
				// Assigne le metier de l entreprise au nouvel employe
				JobManager.GetInstance().SetPlayerJob(playerId, jobType);
				// Notif au patron si connecte
				int ownerPid = JobCriminalManager.GetPlayerIdFromUID(ownerUID);
				if (ownerPid > 0)
				{
					JobManager.GetInstance().NotifyPlayerChat(ownerPid,
						string.Format("[ENTREPRISE] %1 a accepte votre invitation et a rejoint '%2'.",
							displayName, companyName));
				}
				break;
			}
			case 1:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[ENTREPRISE] Aucune invitation en attente.");
				break;
			case 2:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[ENTREPRISE] L entreprise a ete dissoute entre temps. Invitation annulee.");
				break;
			case 3:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[ENTREPRISE] L entreprise est maintenant pleine.");
				break;
			case 4:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[ENTREPRISE] Vous etes deja membre d une entreprise. Invitation annulee.");
				break;
		}
	}
	
	// === REFUS D UNE INVITATION ===
	
	void ClientAskRefuseInvitation()
	{
		Rpc(RpcAsk_RefuseInvitation);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_RefuseInvitation()
	{
		if (!Replication.IsServer()) return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "") return;
		
		string targetCompanyName;
		string ownerUID;
		int result = JobCompanyManager.GetInstance().RefuseInvitation(uid,
			targetCompanyName, ownerUID);
		
		if (result == 0)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				string.Format("[ENTREPRISE] Vous avez refuse l invitation de '%1'.", targetCompanyName));
			// Notif au patron
			int ownerPid = JobCriminalManager.GetPlayerIdFromUID(ownerUID);
			if (ownerPid > 0)
			{
				string targetDisplayName = JobIdentityManager.GetInstance().GetDisplayNameByPlayerId(playerId);
				if (targetDisplayName == "")
					targetDisplayName = "Le joueur";
				JobManager.GetInstance().NotifyPlayerChat(ownerPid,
					string.Format("[ENTREPRISE] %1 a refuse votre invitation pour '%2'.",
						targetDisplayName, targetCompanyName));
			}
		}
		else
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[ENTREPRISE] Aucune invitation en attente.");
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Helper : spawn un prefab dans l inventaire d un joueur. Si inventaire plein (ou
	// echec pour une raison quelconque), drop l item au sol a la position du joueur.
	// Appele cote serveur uniquement.
	//------------------------------------------------------------------------------------------------
	void SpawnItemWithGroundFallback(IEntity character, ResourceName prefabName, int notifyPlayerId)
	{
		if (!character || prefabName == "" || prefabName == ResourceName.Empty)
			return;
		
		SCR_InventoryStorageManagerComponent invMgr = SCR_InventoryStorageManagerComponent.Cast(
			character.FindComponent(SCR_InventoryStorageManagerComponent));
		
		bool placedInInventory = false;
		if (invMgr)
			placedInInventory = invMgr.TrySpawnPrefabToStorage(prefabName);
		
		if (placedInInventory)
			return;
		
		// Drop au sol a la position du joueur
		Resource res = Resource.Load(prefabName);
		if (!res)
			return;
		vector pos = character.GetOrigin();
		EntitySpawnParams params = new EntitySpawnParams();
		params.TransformMode = ETransformMode.WORLD;
		params.Transform[3] = pos;
		IEntity dropped = GetGame().SpawnEntityPrefab(res, GetGame().GetWorld(), params);
		if (dropped && notifyPlayerId > 0)
		{
			JobManager.GetInstance().NotifyPlayerChat(notifyPlayerId,
				"[ENTREPRISE] Inventaire plein : un item a ete depose au sol.");
		}
	}
	
	// === RECUPERATION DES ITEMS D UN BON REFUSE ===
	
	void ClientAskRecoverItems(int orderId)
	{
		Rpc(RpcAsk_RecoverItems, orderId);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_RecoverItems(int orderId)
	{
		if (!Replication.IsServer())
			return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "") return;
		
		JobCompany c = JobCompanyManager.GetInstance().GetCompanyOfPlayer(uid);
		if (!c) return;
		
		array<ref JobCompanyOrderItem> items;
		int result = JobCompanyManager.GetInstance().RecoverRefusedOrderItems(uid, c.m_Name,
			orderId, items);
		
		switch (result)
		{
			case 0:
			{
				IEntity character = pc.GetControlledEntity();
				if (character && items)
				{
					foreach (JobCompanyOrderItem it : items)
					{
						if (it)
						{
							ResourceName rn = it.m_PrefabName;
							SpawnItemWithGroundFallback(character, rn, playerId);
						}
					}
				}
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					string.Format("[ENTREPRISE] Items du bon #%1 recuperes.", orderId.ToString()));
				break;
			}
			case 1:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[ENTREPRISE] Bon introuvable.");
				break;
			case 2:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[ENTREPRISE] Vous n etes pas l auteur de ce bon.");
				break;
			case 3:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[ENTREPRISE] Ce bon n est pas refuse.");
				break;
			case 4:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[ENTREPRISE] Vous avez deja recupere ces items.");
				break;
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// ============================================================
	// CLEF VIERGE (Garage virtuel) - SYSTEME ISOLE
	// ============================================================
	// Spawn une CarKey dans l inventaire du joueur, avec cooldown 30 min.
	// Si inventaire plein, drop au sol a la position du joueur.
	// La logique cooldown est dans JobBlankKeyManager (fichier separe).
	//------------------------------------------------------------------------------------------------
	
	void ClientAskBlankKey()
	{
		Rpc(RpcAsk_BlankKey);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_BlankKey()
	{
		if (!Replication.IsServer())
			return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "") return;
		
		// Verifie cooldown via le manager isole
		int remaining = JobBlankKeyManager.GetInstance().RequestKey(uid);
		if (remaining > 0)
		{
			int minutes = remaining / 60;
			int seconds = remaining - minutes * 60;
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				string.Format("[GARAGE] Vous devez attendre %1 min %2 sec avant la prochaine clef vierge.",
					minutes.ToString(), seconds.ToString()));
			return;
		}
		
		// OK : spawn la clef dans l inventaire (drop au sol si plein)
		IEntity character = pc.GetControlledEntity();
		if (!character)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[GARAGE] Erreur : impossible de spawn la clef.");
			return;
		}
		
		ResourceName keyPrefab = JobBlankKeyManager.GetInstance().BLANK_KEY_PREFAB;
		
		// Tente le spawn dans l inventaire
		SCR_InventoryStorageManagerComponent invMgr = SCR_InventoryStorageManagerComponent.Cast(
			character.FindComponent(SCR_InventoryStorageManagerComponent));
		bool placed = false;
		if (invMgr)
			placed = invMgr.TrySpawnPrefabToStorage(keyPrefab);
		
		if (placed)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[GARAGE] Une clef vierge vous a ete remise. Prochaine clef dans 30 minutes.");
			return;
		}
		
		// Inventaire plein : drop au sol a la position du joueur
		Resource res = Resource.Load(keyPrefab);
		if (!res)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[GARAGE] Erreur : prefab clef invalide.");
			return;
		}
		vector pos = character.GetOrigin();
		EntitySpawnParams params = new EntitySpawnParams();
		params.TransformMode = ETransformMode.WORLD;
		params.Transform[3] = pos;
		IEntity dropped = GetGame().SpawnEntityPrefab(res, GetGame().GetWorld(), params);
		if (dropped)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[GARAGE] Inventaire plein : clef vierge deposee au sol. Prochaine dans 30 min.");
		}
		else
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[GARAGE] Erreur lors du spawn de la clef.");
		}
	}
}
modded class JobPlayerComponent
{
	//------------------------------------------------------------------------------------------------
	// ============================================================
	// WHITELIST : OUVERTURE DU MENU COTE CLIENT
	// ============================================================
	// Appele cote serveur uniquement. Envoie un RPC au client qui possede ce
	// PlayerController pour declencher l affichage du layout whitelist.
	//------------------------------------------------------------------------------------------------
	
	void ServerSendOpenWhitelistMenu()
	{
		if (!Replication.IsServer())
			return;
		Rpc(RpcDo_OpenWhitelistMenu);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_OpenWhitelistMenu()
	{
		// Cote client : ouvre le layout. Le menu gere son propre timer/affichage.
		GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.JobWhitelistMenu);
	}
	
	//------------------------------------------------------------------------------------------------
	// Envoi au client de l ordre d ouvrir le layout "Whitelist validee - Chargement..."
	// Le menu se ferme tout seul apres 5 secondes.
	//------------------------------------------------------------------------------------------------
	void ServerSendOpenWhitelistLoadingMenu()
	{
		if (!Replication.IsServer())
			return;
		Rpc(RpcDo_OpenWhitelistLoadingMenu);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_OpenWhitelistLoadingMenu()
	{
		GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.JobWhitelistLoadingMenu);
	}
}

modded class JobPlayerComponent
{
	//------------------------------------------------------------------------------------------------
	// ============================================================
	// LE BON POINT - SESSION 1 : Accueil + Vendre
	// ============================================================
	//------------------------------------------------------------------------------------------------
	
	// === OUVERTURE DU MENU D ACCUEIL ===
	
	void ClientAskOpenBonPoint()
	{
		// Ouverture directe cote client (pas besoin d aller chercher de donnees serveur
		// pour l accueil). Les onglets demandent ensuite leurs donnees au serveur.
		GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.JobBonPointAccessMenu);
	}
	
	// === LISTAGE INVENTAIRE POUR VENDRE ===
	
	void ClientAskListInventoryForBonPoint()
	{
		Rpc(RpcAsk_ListInventoryForBonPoint);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_ListInventoryForBonPoint()
	{
		if (!Replication.IsServer())
			return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "") return;
		
		// Verifie que le joueur n a pas deja 5 annonces
		int currentAds = JobBonPointManager.GetInstance().CountAdsByPlayer(uid);
		if (currentAds >= JobBonPointManager.MAX_ADS_PER_PLAYER)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				string.Format("[BONPOINT] Limite de %1 annonces atteinte. Retirez-en une pour en publier une nouvelle.",
					JobBonPointManager.MAX_ADS_PER_PLAYER.ToString()));
			return;
		}
		
		// Scan inventory
		IEntity character = pc.GetControlledEntity();
		if (!character) return;
		SCR_InventoryStorageManagerComponent invMgr = SCR_InventoryStorageManagerComponent.Cast(
			character.FindComponent(SCR_InventoryStorageManagerComponent));
		if (!invMgr)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[BONPOINT] Erreur d acces a votre inventaire.");
			return;
		}
		
		array<IEntity> items = new array<IEntity>();
		invMgr.GetItems(items);
		
		// Serialise prefab + nom, filtre les items blacklistes
		string prefabsStr = "";
		string namesStr = "";
		int count = 0;
		foreach (IEntity item : items)
		{
			if (!item) continue;
			EntityPrefabData pd = item.GetPrefabData();
			if (!pd) continue;
			ResourceName rn = pd.GetPrefabName();
			if (rn == "" || rn == ResourceName.Empty) continue;
			// Filtre la blacklist
			if (JobBonPointManager.GetInstance().IsPrefabBlacklisted(rn))
				continue;
			string nm = ExtractItemDisplayName(rn);
			if (count > 0)
			{
				prefabsStr = prefabsStr + "###";
				namesStr = namesStr + "###";
			}
			prefabsStr = prefabsStr + rn;
			namesStr = namesStr + nm;
			count++;
		}
		
		Rpc(RpcDo_ReceiveInventoryForBonPoint, prefabsStr, namesStr);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_ReceiveInventoryForBonPoint(string prefabsStr, string namesStr)
	{
		array<string> prefabs = new array<string>();
		array<string> names = new array<string>();
		ParseSplitString(prefabsStr, "###", prefabs);
		ParseSplitString(namesStr, "###", names);
		
		JobBonPointSellMenu.SetPendingData(prefabs, names);
		GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.JobBonPointSellMenu);
	}
	
	// === CREATION D ANNONCE ===
	
	void ClientAskCreateBonPointAd(string prefabName, string title, string description, int price)
	{
		Rpc(RpcAsk_CreateBonPointAd, prefabName, title, description, price);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_CreateBonPointAd(string prefabName, string title, string description, int price)
	{
		if (!Replication.IsServer())
			return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "") return;
		
		// Verifications de base
		if (prefabName == "" || title == "")
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[BONPOINT] Donnees invalides : titre obligatoire.");
			return;
		}
		if (price <= 0)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[BONPOINT] Prix invalide (doit etre superieur a 0).");
			return;
		}
		
		// Verifie blacklist
		if (JobBonPointManager.GetInstance().IsPrefabBlacklisted(prefabName))
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[BONPOINT] Cet item ne peut pas etre mis en vente.");
			return;
		}
		
		// Verifie limite annonces
		int currentAds = JobBonPointManager.GetInstance().CountAdsByPlayer(uid);
		if (currentAds >= JobBonPointManager.MAX_ADS_PER_PLAYER)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				string.Format("[BONPOINT] Limite de %1 annonces atteinte.",
					JobBonPointManager.MAX_ADS_PER_PLAYER.ToString()));
			return;
		}
		
		// Cherche l item dans l inventaire
		IEntity character = pc.GetControlledEntity();
		if (!character) return;
		SCR_InventoryStorageManagerComponent invMgr = SCR_InventoryStorageManagerComponent.Cast(
			character.FindComponent(SCR_InventoryStorageManagerComponent));
		if (!invMgr)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[BONPOINT] Erreur d acces a votre inventaire.");
			return;
		}
		
		// Trouve un item correspondant au prefabName et le retire de l inventaire
		array<IEntity> items = new array<IEntity>();
		invMgr.GetItems(items);
		IEntity itemToRemove = null;
		foreach (IEntity item : items)
		{
			if (!item) continue;
			EntityPrefabData pd = item.GetPrefabData();
			if (!pd) continue;
			ResourceName rn = pd.GetPrefabName();
			if (rn == prefabName)
			{
				itemToRemove = item;
				break;
			}
		}
		
		if (!itemToRemove)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[BONPOINT] Item introuvable dans votre inventaire.");
			return;
		}
		
		// Retire l item (delete car on a stocke son prefab dans l annonce, on respawnera)
		SCR_EntityHelper.DeleteEntityAndChildren(itemToRemove);
		
		// Nom RP du vendeur
		string sellerName = JobIdentityManager.GetInstance().GetDisplayNameByPlayerId(playerId);
		if (sellerName == "")
			sellerName = "Joueur " + playerId.ToString();
		
		// Cree l annonce
		int adId;
		int result = JobBonPointManager.GetInstance().CreateAd(uid, sellerName, prefabName,
			title, description, price, adId);
		
		switch (result)
		{
			case 0:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					string.Format("[BONPOINT] Annonce #%1 publiee : '%2' a %3 capsules.",
						adId.ToString(), title, price.ToString()));
				break;
			case 1:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[BONPOINT] Erreur : limite d annonces atteinte (item perdu).");
				break;
			case 2:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[BONPOINT] Erreur : prix invalide (item perdu).");
				break;
			case 3:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[BONPOINT] Erreur : item blackliste (item perdu).");
				break;
			case 4:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[BONPOINT] Erreur : donnees invalides (item perdu).");
				break;
		}
	}
}

modded class JobPlayerComponent
{
	//------------------------------------------------------------------------------------------------
	// ============================================================
	// LE BON POINT - SESSION 2 : Acheter + Profil + Modif/Retrait
	// ============================================================
	//------------------------------------------------------------------------------------------------
	
	// === LISTAGE DES ANNONCES (ONGLET ACHETER) ===
	
	void ClientAskListBonPointAds()
	{
		Rpc(RpcAsk_ListBonPointAds);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_ListBonPointAds()
	{
		if (!Replication.IsServer()) return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		
		array<ref JobBonPointAd> ads = JobBonPointManager.GetInstance().GetAllAds();
		
		// Serialise : adIds (int separes par #), prices (int sep #), sellerNames (str sep ###), titles (str sep ###)
		string adIdsStr = "";
		string pricesStr = "";
		string sellerNamesStr = "";
		string titlesStr = "";
		int count = 0;
		foreach (JobBonPointAd ad : ads)
		{
			if (!ad) continue;
			if (count > 0)
			{
				adIdsStr = adIdsStr + "#";
				pricesStr = pricesStr + "#";
				sellerNamesStr = sellerNamesStr + "###";
				titlesStr = titlesStr + "###";
			}
			adIdsStr = adIdsStr + ad.m_AdId.ToString();
			pricesStr = pricesStr + ad.m_Price.ToString();
			sellerNamesStr = sellerNamesStr + ad.m_SellerDisplayName;
			titlesStr = titlesStr + ad.m_ItemTitle;
			count++;
		}
		
		Rpc(RpcDo_ReceiveBonPointAdsList, adIdsStr, pricesStr, sellerNamesStr, titlesStr);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_ReceiveBonPointAdsList(string adIdsStr, string pricesStr, string sellerNamesStr, string titlesStr)
	{
		array<string> idStrs = new array<string>();
		array<string> priceStrs = new array<string>();
		array<string> sellerNames = new array<string>();
		array<string> titles = new array<string>();
		ParseSplitString(adIdsStr, "#", idStrs);
		ParseSplitString(pricesStr, "#", priceStrs);
		ParseSplitString(sellerNamesStr, "###", sellerNames);
		ParseSplitString(titlesStr, "###", titles);
		
		array<int> adIds = new array<int>();
		array<int> prices = new array<int>();
		foreach (string s : idStrs) adIds.Insert(s.ToInt());
		foreach (string s : priceStrs) prices.Insert(s.ToInt());
		
		JobBonPointBuyMenu.SetPendingData(adIds, prices, sellerNames, titles);
		GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.JobBonPointBuyMenu);
	}
	
	// === DETAIL D UNE ANNONCE (FICHE PRODUIT) ===
	
	void ClientAskBonPointAdDetail(int adId)
	{
		Rpc(RpcAsk_BonPointAdDetail, adId);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_BonPointAdDetail(int adId)
	{
		if (!Replication.IsServer()) return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		
		JobBonPointAd ad = JobBonPointManager.GetInstance().GetAdById(adId);
		if (!ad)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[BONPOINT] Annonce introuvable (peut-etre vendue ou expiree).");
			return;
		}
		
		bool isMyAd = (ad.m_SellerUID == uid);
		Rpc(RpcDo_ReceiveBonPointAdDetail, adId, ad.m_ItemTitle, ad.m_ItemDescription,
			ad.m_Price, ad.m_SellerDisplayName, ad.m_PrefabName, isMyAd);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_ReceiveBonPointAdDetail(int adId, string title, string description, int price,
		string sellerName, string prefabName, bool isMyAd)
	{
		JobBonPointAdDetailMenu.SetPendingData(adId, title, description, price, sellerName, prefabName, isMyAd);
		GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.JobBonPointAdDetailMenu);
	}
	
	// === ACHAT D UNE ANNONCE ===
	
	void ClientAskBuyBonPointAd(int adId)
	{
		Rpc(RpcAsk_BuyBonPointAd, adId);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_BuyBonPointAd(int adId)
	{
		if (!Replication.IsServer()) return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		string buyerUID = JobManager.GetInstance().GetPersistentUID(playerId);
		if (buyerUID == "") return;
		
		// Recupere l annonce pour connaitre le prix avant d appeler BuyAd
		JobBonPointAd ad = JobBonPointManager.GetInstance().GetAdById(adId);
		if (!ad)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[BONPOINT] Annonce introuvable (deja vendue ou expiree).");
			return;
		}
		if (ad.m_SellerUID == buyerUID)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[BONPOINT] Vous ne pouvez pas acheter votre propre annonce.");
			return;
		}
		
		// Verifie capsules acheteur
		int balance = CapsuleEconomyManager.GetInstance().GetCapsules(buyerUID);
		if (balance < ad.m_Price)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				string.Format("[BONPOINT] Solde insuffisant : %1 capsules requises, vous en avez %2.",
					ad.m_Price.ToString(), balance.ToString()));
			return;
		}
		
		// Effectue l achat
		string sellerUID;
		int forSeller;
		int tax;
		string itemTitle;
		string sellerName;
		int result = JobBonPointManager.GetInstance().BuyAd(adId, buyerUID,
			sellerUID, forSeller, tax, itemTitle, sellerName);
		
		if (result != 0)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[BONPOINT] Erreur lors de l achat. Reessayez.");
			return;
		}
		
		// Debit acheteur
		CapsuleEconomyManager.GetInstance().AddCapsules(buyerUID, -ad.m_Price);
		// Credit vendeur (montant moins taxe)
		CapsuleEconomyManager.GetInstance().AddCapsules(sellerUID, forSeller);
		
		// Notifs
		JobManager.GetInstance().NotifyPlayerChat(playerId,
			string.Format("[BONPOINT] Achat reussi ! '%1' pour %2 capsules. Recuperer dans 'Mon Profil > Mes achats'.",
				itemTitle, ad.m_Price.ToString()));
		
		// Notif vendeur si connecte
		NotifySellerByUID(sellerUID,
			string.Format("[BONPOINT] Votre annonce '%1' a ete vendue pour %2 capsules (vous recevez %3 apres taxe).",
				itemTitle, ad.m_Price.ToString(), forSeller.ToString()));
	}
	
	//------------------------------------------------------------------------------------------------
	// Helper : envoie une notif chat a un joueur identifie par son UID (s il est connecte)
	void NotifySellerByUID(string sellerUID, string msg)
	{
		PlayerManager pm = GetGame().GetPlayerManager();
		if (!pm) return;
		array<int> playerIds = new array<int>();
		pm.GetPlayers(playerIds);
		foreach (int pid : playerIds)
		{
			string puid = JobManager.GetInstance().GetPersistentUID(pid);
			if (puid == sellerUID)
			{
				JobManager.GetInstance().NotifyPlayerChat(pid, msg);
				return;
			}
		}
	}
	
	// === OUVERTURE PROFIL ===
	
	void ClientAskOpenBonPointProfile()
	{
		Rpc(RpcAsk_OpenBonPointProfile);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_OpenBonPointProfile()
	{
		if (!Replication.IsServer()) return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "") return;
		
		// Mes annonces
		array<ref JobBonPointAd> myAds = JobBonPointManager.GetInstance().GetAdsByPlayer(uid);
		string adIdsStr = "";
		string adTitlesStr = "";
		string adPricesStr = "";
		string adChatCountsStr = "";
		int counta = 0;
		foreach (JobBonPointAd ad : myAds)
		{
			if (!ad) continue;
			if (counta > 0)
			{
				adIdsStr = adIdsStr + "#";
				adTitlesStr = adTitlesStr + "###";
				adPricesStr = adPricesStr + "#";
				adChatCountsStr = adChatCountsStr + "#";
			}
			adIdsStr = adIdsStr + ad.m_AdId.ToString();
			adTitlesStr = adTitlesStr + ad.m_ItemTitle;
			adPricesStr = adPricesStr + ad.m_Price.ToString();
			int chatCount = JobBonPointManager.GetInstance().CountBuyersWhoChatted(ad.m_AdId);
			adChatCountsStr = adChatCountsStr + chatCount.ToString();
			counta++;
		}
		
		// Mes achats
		array<ref JobBonPointPurchase> myPurchases = JobBonPointManager.GetInstance().GetPurchasesByPlayer(uid);
		string purIdsStr = "";
		string purTitlesStr = "";
		string purSellersStr = "";
		int countp = 0;
		foreach (JobBonPointPurchase p : myPurchases)
		{
			if (!p) continue;
			if (countp > 0)
			{
				purIdsStr = purIdsStr + "#";
				purTitlesStr = purTitlesStr + "###";
				purSellersStr = purSellersStr + "###";
			}
			purIdsStr = purIdsStr + p.m_PurchaseId.ToString();
			purTitlesStr = purTitlesStr + p.m_ItemTitle;
			purSellersStr = purSellersStr + p.m_SellerDisplayName;
			countp++;
		}
		
		Rpc(RpcDo_ReceiveBonPointProfile, adIdsStr, adTitlesStr, adPricesStr, adChatCountsStr,
			purIdsStr, purTitlesStr, purSellersStr);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_ReceiveBonPointProfile(string adIdsStr, string adTitlesStr, string adPricesStr, string adChatCountsStr,
		string purIdsStr, string purTitlesStr, string purSellersStr)
	{
		array<string> adIdStrs = new array<string>();
		array<string> adTitles = new array<string>();
		array<string> adPriceStrs = new array<string>();
		array<string> adChatCountStrs = new array<string>();
		array<string> purIdStrs = new array<string>();
		array<string> purTitles = new array<string>();
		array<string> purSellers = new array<string>();
		ParseSplitString(adIdsStr, "#", adIdStrs);
		ParseSplitString(adTitlesStr, "###", adTitles);
		ParseSplitString(adPricesStr, "#", adPriceStrs);
		ParseSplitString(adChatCountsStr, "#", adChatCountStrs);
		ParseSplitString(purIdsStr, "#", purIdStrs);
		ParseSplitString(purTitlesStr, "###", purTitles);
		ParseSplitString(purSellersStr, "###", purSellers);
		
		array<int> adIds = new array<int>();
		array<int> adPrices = new array<int>();
		array<int> adChatCounts = new array<int>();
		array<int> purIds = new array<int>();
		foreach (string s : adIdStrs) adIds.Insert(s.ToInt());
		foreach (string s : adPriceStrs) adPrices.Insert(s.ToInt());
		foreach (string s : adChatCountStrs) adChatCounts.Insert(s.ToInt());
		foreach (string s : purIdStrs) purIds.Insert(s.ToInt());
		
		JobBonPointProfileMenu.SetPendingData(adIds, adTitles, adPrices, adChatCounts,
			purIds, purTitles, purSellers);
		GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.JobBonPointProfileMenu);
	}
	
	// === RETRAIT D ANNONCE ===
	
	void ClientAskRemoveBonPointAd(int adId)
	{
		Rpc(RpcAsk_RemoveBonPointAd, adId);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_RemoveBonPointAd(int adId)
	{
		if (!Replication.IsServer()) return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "") return;
		
		int result = JobBonPointManager.GetInstance().RemoveAd(adId, uid);
		switch (result)
		{
			case 0:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[BONPOINT] Annonce retiree. Recuperez votre item dans 'Mon Profil > Mes achats'.");
				break;
			case 1:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[BONPOINT] Annonce introuvable.");
				break;
			case 2:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[BONPOINT] Ce n est pas votre annonce.");
				break;
		}
	}
	
	// === MODIFICATION D ANNONCE ===
	
	void ClientAskUpdateBonPointAd(int adId, int newPrice, string newDescription)
	{
		Rpc(RpcAsk_UpdateBonPointAd, adId, newPrice, newDescription);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_UpdateBonPointAd(int adId, int newPrice, string newDescription)
	{
		if (!Replication.IsServer()) return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "") return;
		
		int result = JobBonPointManager.GetInstance().UpdateAd(adId, uid, newPrice, newDescription);
		switch (result)
		{
			case 0:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					string.Format("[BONPOINT] Annonce mise a jour : nouveau prix %1 capsules.",
						newPrice.ToString()));
				break;
			case 1:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[BONPOINT] Annonce introuvable.");
				break;
			case 2:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[BONPOINT] Ce n est pas votre annonce.");
				break;
			case 3:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[BONPOINT] Prix invalide.");
				break;
		}
	}
	
	// === RECUPERATION D UN ACHAT ===
	
	void ClientAskRecoverBonPointPurchase(int purchaseId)
	{
		Rpc(RpcAsk_RecoverBonPointPurchase, purchaseId);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_RecoverBonPointPurchase(int purchaseId)
	{
		if (!Replication.IsServer()) return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "") return;
		
		string prefabName;
		string itemTitle;
		int result = JobBonPointManager.GetInstance().RecoverPurchase(purchaseId, uid, prefabName, itemTitle);
		switch (result)
		{
			case 0:
				// Spawn l item dans l inventaire (drop au sol si plein)
				SpawnItemWithGroundFallback(pc.GetControlledEntity(), prefabName, playerId);
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					string.Format("[BONPOINT] Item '%1' recupere.", itemTitle));
				break;
			case 1:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[BONPOINT] Achat introuvable.");
				break;
			case 2:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[BONPOINT] Ce n est pas votre achat.");
				break;
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Helper : spawn un item dans l inventaire d un personnage, drop au sol si plein
	void SpawnItemWithGroundFallback(IEntity character, string prefabName, int notifyPlayerId)
	{
		if (!character || prefabName == "")
			return;
		
		ResourceName rn = prefabName;
		
		// Tente le spawn dans l inventaire
		SCR_InventoryStorageManagerComponent invMgr = SCR_InventoryStorageManagerComponent.Cast(
			character.FindComponent(SCR_InventoryStorageManagerComponent));
		bool placed = false;
		if (invMgr)
			placed = invMgr.TrySpawnPrefabToStorage(rn);
		
		if (placed)
			return;
		
		// Inventaire plein : drop au sol
		Resource res = Resource.Load(rn);
		if (!res)
			return;
		vector pos = character.GetOrigin();
		EntitySpawnParams params = new EntitySpawnParams();
		params.TransformMode = ETransformMode.WORLD;
		params.Transform[3] = pos;
		IEntity dropped = GetGame().SpawnEntityPrefab(res, GetGame().GetWorld(), params);
		if (dropped && notifyPlayerId > 0)
		{
			JobManager.GetInstance().NotifyPlayerChat(notifyPlayerId,
				"[BONPOINT] Inventaire plein : item depose au sol.");
		}
	}
}

modded class JobPlayerComponent
{
	//------------------------------------------------------------------------------------------------
	// ============================================================
	// LE BON POINT - SESSION 3 : Chat 1-to-1
	// ============================================================
	//------------------------------------------------------------------------------------------------
	
	// === OUVERTURE DU CHAT (par l acheteur potentiel) ===
	// L acheteur clique sur 'Discuter' depuis la fiche produit.
	// Le serveur identifie sa conversation par son propre UID comme buyerUID.
	
	void ClientAskOpenBonPointChat(int adId, string otherDisplayName, string adTitle)
	{
		// Stocke le contexte (titre + nom du vendeur) avant d ouvrir
		JobBonPointChatMenu.SetPendingContext(adId, "", otherDisplayName, adTitle);
		Rpc(RpcAsk_OpenBonPointChat, adId);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_OpenBonPointChat(int adId)
	{
		if (!Replication.IsServer()) return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		string myUID = JobManager.GetInstance().GetPersistentUID(playerId);
		if (myUID == "") return;
		
		// L acheteur ouvre sa conversation : buyerUID = mon UID
		SendChatMessagesToClient(adId, myUID, myUID);
	}
	
	// === DEMANDE DE REFRESH (auto-refresh 5s) ===
	
	void ClientAskBonPointChatMessages(int adId, string buyerUID)
	{
		Rpc(RpcAsk_BonPointChatMessages, adId, buyerUID);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_BonPointChatMessages(int adId, string buyerUID)
	{
		if (!Replication.IsServer()) return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		string myUID = JobManager.GetInstance().GetPersistentUID(playerId);
		if (myUID == "") return;
		
		// Si buyerUID est vide ou correspond a moi, c est qu on est l acheteur consultant
		string effectiveBuyerUID = buyerUID;
		if (effectiveBuyerUID == "")
			effectiveBuyerUID = myUID;
		
		SendChatMessagesToClient(adId, effectiveBuyerUID, myUID);
	}
	
	//------------------------------------------------------------------------------------------------
	// Helper serveur : recupere les messages de la conversation et les renvoie au client
	void SendChatMessagesToClient(int adId, string buyerUID, string myUID)
	{
		array<ref JobBonPointChatMsg> messages = JobBonPointManager.GetInstance()
			.GetChatMessages(adId, buyerUID);
		
		// Serialise : 4 strings (ts, uids, names, texts) separes par "###"
		string tsStr = "";
		string uidsStr = "";
		string namesStr = "";
		string textsStr = "";
		int count = 0;
		foreach (JobBonPointChatMsg m : messages)
		{
			if (!m) continue;
			if (count > 0)
			{
				tsStr = tsStr + "#";
				uidsStr = uidsStr + "###";
				namesStr = namesStr + "###";
				textsStr = textsStr + "###";
			}
			tsStr = tsStr + m.m_Timestamp.ToString();
			uidsStr = uidsStr + m.m_AuthorUID;
			namesStr = namesStr + m.m_AuthorDisplayName;
			textsStr = textsStr + m.m_Text;
			count++;
		}
		
		Rpc(RpcDo_ReceiveBonPointChatMessages, adId, buyerUID, tsStr, uidsStr,
			namesStr, textsStr, myUID);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_ReceiveBonPointChatMessages(int adId, string buyerUID, string tsStr,
		string uidsStr, string namesStr, string textsStr, string myUID)
	{
		array<string> tsStrs = new array<string>();
		array<string> uids = new array<string>();
		array<string> names = new array<string>();
		array<string> texts = new array<string>();
		ParseSplitString(tsStr, "#", tsStrs);
		ParseSplitString(uidsStr, "###", uids);
		ParseSplitString(namesStr, "###", names);
		ParseSplitString(textsStr, "###", texts);
		
		array<int> ts = new array<int>();
		foreach (string s : tsStrs) ts.Insert(s.ToInt());
		
		// Si le menu est deja ouvert, met juste a jour les messages
		// Sinon, met aussi a jour le contexte (premier load)
		if (!JobBonPointChatMenu.GetOpenMenu())
		{
			// Premier load : on enrichit le contexte avec adId + buyerUID stocke
			// Le titre et l autre nom doivent deja avoir ete set via SetPendingContext
			JobBonPointChatMenu.s_AdId = adId;
			JobBonPointChatMenu.s_BuyerUID = buyerUID;
		}
		
		JobBonPointChatMenu.SetPendingMessages(ts, uids, names, texts, myUID);
		
		// Ouvre le menu si pas encore ouvert
		if (!JobBonPointChatMenu.GetOpenMenu())
			GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.JobBonPointChatMenu);
	}
	
	// === ENVOI D UN MESSAGE ===
	
	void ClientAskSendBonPointChat(int adId, string buyerUID, string text)
	{
		Rpc(RpcAsk_SendBonPointChat, adId, buyerUID, text);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_SendBonPointChat(int adId, string buyerUID, string text)
	{
		if (!Replication.IsServer()) return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		string myUID = JobManager.GetInstance().GetPersistentUID(playerId);
		if (myUID == "") return;
		
		string authorName = JobIdentityManager.GetInstance().GetDisplayNameByPlayerId(playerId);
		if (authorName == "")
			authorName = "Joueur " + playerId.ToString();
		
		// Si buyerUID vide, on suppose que c est l acheteur qui parle (= moi)
		string effectiveBuyerUID = buyerUID;
		if (effectiveBuyerUID == "")
			effectiveBuyerUID = myUID;
		
		int result = JobBonPointManager.GetInstance().SendChatMessage(adId, effectiveBuyerUID,
			myUID, authorName, text);
		
		if (result == 1)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[BONPOINT] Annonce introuvable (vendue ou expiree).");
			return;
		}
		if (result == 2)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[BONPOINT] Vous n etes pas autorise a participer a ce chat.");
			return;
		}
		if (result == 3)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[BONPOINT] Message vide ou trop long (max 200 caracteres).");
			return;
		}
		
		// Notif au destinataire si connecte (= l autre interlocuteur)
		JobBonPointAd ad = JobBonPointManager.GetInstance().GetAdById(adId);
		if (ad)
		{
			string recipientUID;
			if (myUID == ad.m_SellerUID)
				recipientUID = effectiveBuyerUID;
			else
				recipientUID = ad.m_SellerUID;
			
			NotifySellerByUID(recipientUID,
				string.Format("[BONPOINT] Nouveau message sur l annonce '%1' de %2",
					ad.m_ItemTitle, authorName));
		}
	}
}

modded class JobPlayerComponent
{
	//------------------------------------------------------------------------------------------------
	// ============================================================
	// LE BON POINT - Session 4 : Liste acheteurs cote vendeur
	// ============================================================
	//------------------------------------------------------------------------------------------------
	
	void ClientAskListBonPointBuyers(int adId, string adTitle)
	{
		// Stocke le contexte avant
		JobBonPointBuyersListMenu.SetPendingData(adId, adTitle,
			new array<string>(), new array<string>());
		Rpc(RpcAsk_ListBonPointBuyers, adId, adTitle);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_ListBonPointBuyers(int adId, string adTitle)
	{
		if (!Replication.IsServer()) return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		string myUID = JobManager.GetInstance().GetPersistentUID(playerId);
		if (myUID == "") return;
		
		// Verifie que c est bien mon annonce (sinon, le vendeur ne pourrait pas voir les chats d un autre)
		JobBonPointAd ad = JobBonPointManager.GetInstance().GetAdById(adId);
		if (!ad)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[BONPOINT] Annonce introuvable.");
			return;
		}
		if (ad.m_SellerUID != myUID)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[BONPOINT] Ce n est pas votre annonce.");
			return;
		}
		
		// Recupere la liste des acheteurs qui ont parle
		array<string> buyerUIDs = new array<string>();
		array<string> buyerNames = new array<string>();
		JobBonPointManager.GetInstance().GetBuyersWhoChatted(adId, buyerUIDs, buyerNames);
		
		// Serialise pour RPC
		string uidsStr = "";
		string namesStr = "";
		int count = 0;
		for (int i = 0; i < buyerUIDs.Count(); i++)
		{
			if (count > 0)
			{
				uidsStr = uidsStr + "###";
				namesStr = namesStr + "###";
			}
			uidsStr = uidsStr + buyerUIDs.Get(i);
			namesStr = namesStr + buyerNames.Get(i);
			count++;
		}
		
		Rpc(RpcDo_ReceiveBonPointBuyers, adId, adTitle, uidsStr, namesStr);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_ReceiveBonPointBuyers(int adId, string adTitle, string uidsStr, string namesStr)
	{
		array<string> uids = new array<string>();
		array<string> names = new array<string>();
		ParseSplitString(uidsStr, "###", uids);
		ParseSplitString(namesStr, "###", names);
		
		JobBonPointBuyersListMenu.SetPendingData(adId, adTitle, uids, names);
		GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.JobBonPointBuyersListMenu);
	}
}

modded class JobPlayerComponent
{
	//------------------------------------------------------------------------------------------------
	// ============================================================
	// ASSURANCE GARAGE VIRTUEL
	// ============================================================
	// Le joueur paie 300 capsules puis le serveur retire le vehicule du garage,
	// le spawn devant le PNJ, et le track pour detecter sa destruction.
	//
	// Cooldown 3h par joueur.
	//------------------------------------------------------------------------------------------------
	
	void ClientAskInsureAndRetrieveVehicle(RplId npcRplId, int garageIndex)
	{
		Rpc(RpcAsk_InsureAndRetrieveVehicle, npcRplId, garageIndex);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_InsureAndRetrieveVehicle(RplId npcRplId, int garageIndex)
	{
		if (!Replication.IsServer()) return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "") return;
		
		// Verifie le cooldown 3h
		int remaining = JobInsuranceManager.GetInstance().CheckCooldown(uid);
		if (remaining > 0)
		{
			int hours = remaining / 3600;
			int minutes = (remaining - hours * 3600) / 60;
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				string.Format("[ASSURANCE] Cooldown en cours : encore %1h %2 min avant de pouvoir reassurer.",
					hours.ToString(), minutes.ToString()));
			return;
		}
		
		// Verifie que le vehicule n est pas deja assure (evite double-facturation)
		int insStatus = JobVirtualGarageManager.GetInstance().GetInsuranceStatusOfEntry(uid, garageIndex);
		if (insStatus == 2)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[ASSURANCE] Ce vehicule est deja assure. Utilisez le bouton 'Retirer' classique.");
			return;
		}
		
		// Verifie capsules
		int balance = CapsuleEconomyManager.GetInstance().GetCapsules(uid);
		int cost = JobInsuranceManager.INSURANCE_COST;
		if (balance < cost)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				string.Format("[ASSURANCE] Solde insuffisant : %1 capsules requises, vous en avez %2.",
					cost.ToString(), balance.ToString()));
			return;
		}
		
		// Resout le PNJ pour avoir sa position + orientation
		RplComponent npcRpl = RplComponent.Cast(Replication.FindItem(npcRplId));
		if (!npcRpl)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[ASSURANCE] Erreur : PNJ introuvable. Reessayez.");
			return;
		}
		IEntity npc = npcRpl.GetEntity();
		if (!npc)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[ASSURANCE] Erreur : PNJ introuvable. Reessayez.");
			return;
		}
		
		vector npcMat[4];
		npc.GetWorldTransform(npcMat);
		vector forward = -npcMat[2];
		
		// Retire le vehicule (avec recuperation de l entity spawn)
		string vehiclePrefab;
		IEntity spawnedVehicle;
		int result = JobVirtualGarageManager.GetInstance().RetrieveVehicleByIndex(
			uid, garageIndex, npc.GetOrigin(), forward, vehiclePrefab, spawnedVehicle);
		
		if (result != 0)
		{
			// Erreur retrieve : pas de debit, pas de cooldown
			switch (result)
			{
				case 1:
					JobManager.GetInstance().NotifyPlayerChat(playerId,
						"[ASSURANCE] Vehicule introuvable.");
					break;
				case 2:
					JobManager.GetInstance().NotifyPlayerChat(playerId,
						"[ASSURANCE] Ce vehicule ne vous appartient pas.");
					break;
				case 3:
					JobManager.GetInstance().NotifyPlayerChat(playerId,
						"[ASSURANCE] Erreur de spawn du vehicule.");
					break;
			}
			return;
		}
		
		// Succes : debite + marque cooldown + tracke
		CapsuleEconomyManager.GetInstance().AddCapsules(uid, -cost);
		JobInsuranceManager.GetInstance().MarkInsured(uid);
		string insUUID = JobInsuranceManager.GetInstance().InsureVehicleInstance(uid, spawnedVehicle);
		
		// Installe le watcher de destruction pour auto-respawn au garage si le vehicule
		// est detruit (SCR_VehicleDamageManagerComponent). Le watcher persiste tant que
		// le vehicule est en jeu (arret automatique s il est stocke a nouveau).
		if (insUUID != "")
			JobVirtualGarageManager.GetInstance().InstallDamageWatcher(spawnedVehicle, insUUID, uid, vehiclePrefab);
		
		JobManager.GetInstance().NotifyPlayerChat(playerId,
			string.Format("[ASSURANCE] Vehicule recupere et assure pour %1 capsules. En cas de destruction, il sera restitue dans votre garage virtuel.",
				cost.ToString()));
	}
}

modded class JobPlayerComponent
{
	//------------------------------------------------------------------------------------------------
	// ============================================================
	// BRAQUAGE BIJOUTERIE
	// ============================================================
	//------------------------------------------------------------------------------------------------
	
	// HUD braquage cote client
	Widget m_BraquageHudRoot;
	TextWidget m_BraquageBarText;
	ImageWidget m_BraquageBarFill;
	TextWidget m_BraquageDistanceText;
	TextWidget m_BraquageGainsText;
	int m_BraquageTotalSeconds;
	int m_BraquageStartUnixTime;
	vector m_BraquageBijouterieOrigin;
	
	// Sirene cote client
	// AudioSystem.PlaySound ne renvoie pas de handle et ne boucle pas nativement,
	// donc on gere la boucle manuellement avec un CallLater periodique.
	bool m_BraquageSirenActive;
	
	// Duree approximative du son sirene en millisecondes (a ajuster selon le fichier reel).
	// On rejoue le son tous les SIREN_LOOP_INTERVAL_MS pour creer une boucle.
	const int SIREN_LOOP_INTERVAL_MS = 3000;  // 3 secondes par defaut
	
	//------------------------------------------------------------------------------------------------
	// === DEMARRAGE DU BRAQUAGE ===
	//------------------------------------------------------------------------------------------------
	
	void ClientAskStartBraquage(vector bijouterieOrigin)
	{
		Rpc(RpcAsk_StartBraquage, bijouterieOrigin);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_StartBraquage(vector bijouterieOrigin)
	{
		if (!Replication.IsServer()) return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		
		int cdRemaining;
		int result = JobBraquageManager.GetInstance().StartBraquage(playerId, bijouterieOrigin, cdRemaining);
		
		switch (result)
		{
			case 0:
				// OK, le manager a deja envoye les notifs et HUDs
				break;
			case 1:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[BRAQUAGE] Vous avez deja un braquage en cours.");
				break;
			case 2:
				int minutes = cdRemaining / 60;
				int secs = cdRemaining - minutes * 60;
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					string.Format("[BRAQUAGE] Cooldown actif : encore %1 min %2s avant de pouvoir braquer.",
						minutes.ToString(), secs.ToString()));
				break;
			case 3:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[BRAQUAGE] Vous n avez pas les 2 items requis dans votre inventaire.");
				break;
			case 4:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[BRAQUAGE] Erreur : impossible de demarrer le braquage.");
				break;
			case 5:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[BRAQUAGE] Seul le metier Voyou peut braquer la bijouterie.");
				break;
			case 6:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[BRAQUAGE] Il faut au moins 4 forces de l ordre (police + militaire) connectees pour braquer.");
				break;
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// === HUD BRAQUAGE COTE CLIENT (barre progression) ===
	// Le serveur envoie la duree totale au client; le client gere son propre tick local pour
	// afficher le temps restant.
	//------------------------------------------------------------------------------------------------
	
	void ServerStartBraquageHud(int totalSeconds, vector bijouterieOrigin)
	{
		Rpc(RpcDo_StartBraquageHud, totalSeconds, bijouterieOrigin);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_StartBraquageHud(int totalSeconds, vector bijouterieOrigin)
	{
		m_BraquageTotalSeconds = totalSeconds;
		m_BraquageStartUnixTime = System.GetUnixTime();
		m_BraquageBijouterieOrigin = bijouterieOrigin;
		ShowBraquageHud();
	}
	
	void ServerEndBraquageHud()
	{
		Rpc(RpcDo_EndBraquageHud);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_EndBraquageHud()
	{
		HideBraquageHud();
	}
	
	//------------------------------------------------------------------------------------------------
	// Cree le HUD et demarre le tick local
	void ShowBraquageHud()
	{
		if (m_BraquageHudRoot)
			return;  // deja affiche
		
		WorkspaceWidget ws = GetGame().GetWorkspace();
		if (!ws) return;
		m_BraquageHudRoot = ws.CreateWidgets(
			"{C7EEC3399643EB18}UI/layouts/JobBraquageHud.layout");
		if (!m_BraquageHudRoot) return;
		
		m_BraquageBarText = TextWidget.Cast(m_BraquageHudRoot.FindAnyWidget("BarText"));
		m_BraquageBarFill = ImageWidget.Cast(m_BraquageHudRoot.FindAnyWidget("BarFill"));
		m_BraquageDistanceText = TextWidget.Cast(m_BraquageHudRoot.FindAnyWidget("DistanceText"));
		m_BraquageGainsText = TextWidget.Cast(m_BraquageHudRoot.FindAnyWidget("GainsText"));
		
		GetGame().GetCallqueue().CallLater(TickBraquageHud, 1000, true);
		TickBraquageHud();
	}
	
	void HideBraquageHud()
	{
		GetGame().GetCallqueue().Remove(TickBraquageHud);
		if (m_BraquageHudRoot)
		{
			m_BraquageHudRoot.RemoveFromHierarchy();
			m_BraquageHudRoot = null;
			m_BraquageBarText = null;
			m_BraquageBarFill = null;
			m_BraquageDistanceText = null;
			m_BraquageGainsText = null;
		}
	}
	
	// Tick local cote client : met a jour le temps restant + la barre + distance + gains
	void TickBraquageHud()
	{
		if (!m_BraquageHudRoot) return;
		int now = System.GetUnixTime();
		int elapsed = now - m_BraquageStartUnixTime;
		int remaining = m_BraquageTotalSeconds - elapsed;
		if (remaining < 0) remaining = 0;
		
		// Format mm:ss
		int mm = remaining / 60;
		int ss = remaining - mm * 60;
		string label = string.Format("%1:%2", mm.ToString(),
			JobBraquageHudPadInt(ss));
		if (m_BraquageBarText)
			m_BraquageBarText.SetText(label);
		
		// Largeur barre : on remplit progressivement (de 0 vers 416 pixels = 420-4 padding)
		if (m_BraquageBarFill && m_BraquageTotalSeconds > 0)
		{
			float ratio = (float)elapsed / (float)m_BraquageTotalSeconds;
			if (ratio > 1) ratio = 1;
			float width = 416 * ratio;
			m_BraquageBarFill.SetSize(width, 24);
		}
		
		// Distance : calcule la distance entre le joueur local et la bijouterie
		// Devient rouge clignotant a partir de 12m (warning avant annulation a 15m)
		if (m_BraquageDistanceText)
		{
			float dist = 0;
			IEntity playerEnt = GetGame().GetPlayerController().GetControlledEntity();
			if (playerEnt)
				dist = vector.Distance(playerEnt.GetOrigin(), m_BraquageBijouterieOrigin);
			int distInt = Math.Floor(dist);
			m_BraquageDistanceText.SetText(string.Format("Distance : %1m / 15m", distInt.ToString()));
			// Couleur dynamique selon la distance
			if (dist >= 12)
				m_BraquageDistanceText.SetColor(Color.FromRGBA(230, 50, 50, 255));   // rouge alerte
			else if (dist >= 8)
				m_BraquageDistanceText.SetColor(Color.FromRGBA(240, 190, 50, 255));  // orange warning
			else
				m_BraquageDistanceText.SetColor(Color.FromRGBA(220, 220, 220, 255)); // blanc normal
		}
		
		// Gains : 25 capsules par seconde ecoule
		if (m_BraquageGainsText)
		{
			int gains = elapsed * 25;  // 25 cps/s
			m_BraquageGainsText.SetText(string.Format("Gains : +%1 capsules", gains.ToString()));
		}
		
		// Self-stop si timer fini (au cas ou)
		if (remaining <= 0)
			HideBraquageHud();
	}
	
	// Helper : zero-pad un int a 2 chiffres (ex: 5 -> "05")
	static string JobBraquageHudPadInt(int v)
	{
		if (v < 10)
			return "0" + v.ToString();
		return v.ToString();
	}
	
	//------------------------------------------------------------------------------------------------
	// === SIRENE BRAQUAGE ===
	// Le serveur indique a chaque client (dans le rayon de 500m) de jouer ou stopper la sirene.
	//------------------------------------------------------------------------------------------------
	
	void ServerStartBraquageSiren(vector bijouterieOrigin)
	{
		Rpc(RpcDo_StartBraquageSiren, bijouterieOrigin);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_StartBraquageSiren(vector bijouterieOrigin)
	{
		string soundRes = JobBraquageData.SIREN_SOUND_RESOURCE;
		if (soundRes == "" || soundRes == "{REPLACE_BY_BOSS_SIREN_SOUND}")
		{
			Print("[JobPlayerComponent] Sirene braquage : SIREN_SOUND_RESOURCE non configure",
				LogLevel.WARNING);
			return;
		}
		
		// Stop l ancienne sirene si presente
		if (m_BraquageSirenActive)
		{
			GetGame().GetCallqueue().Remove(TickBraquageSirenLoop);
			m_BraquageSirenActive = false;
		}
		
		// Demarre la boucle (joue tout de suite + repete tous les N ms)
		m_BraquageSirenActive = true;
		TickBraquageSirenLoop();
		GetGame().GetCallqueue().CallLater(TickBraquageSirenLoop, SIREN_LOOP_INTERVAL_MS, true);
	}
	
	// Tick : rejoue le son sirene pour creer une boucle
	void TickBraquageSirenLoop()
	{
		if (!m_BraquageSirenActive)
			return;
		string soundRes = JobBraquageData.SIREN_SOUND_RESOURCE;
		if (soundRes == "" || soundRes == "{REPLACE_BY_BOSS_SIREN_SOUND}")
			return;
		AudioSystem.PlaySound(soundRes);
	}
	
	void ServerStopBraquageSiren()
	{
		Rpc(RpcDo_StopBraquageSiren);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_StopBraquageSiren()
	{
		if (m_BraquageSirenActive)
		{
			GetGame().GetCallqueue().Remove(TickBraquageSirenLoop);
			m_BraquageSirenActive = false;
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// === ALERTE SOS BRAQUAGE (Police + Gendarmerie) ===
	//------------------------------------------------------------------------------------------------
	
	void ServerSendBraquageAlert(vector bijouterieOrigin, string msg)
	{
		Rpc(RpcDo_BraquageAlert, bijouterieOrigin, msg);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_BraquageAlert(vector bijouterieOrigin, string msg)
	{
		// Hint 15 secondes (comme les appels telephone)
		LP_NotificationManager.Show(msg, "ALERTE BRAQUAGE", 15);
		// Note : le marker carte est gere directement cote serveur dans le manager
		// (ServerSetQuestMarker) pour utiliser le pattern correct serveur->client.
	}
}

modded class JobPlayerComponent
{
	//------------------------------------------------------------------------------------------------
	// ============================================================
	// FONTE EN OR (chaines -> lingots)
	// ============================================================
	//------------------------------------------------------------------------------------------------
	
	// HUD fonte cote client
	Widget m_FonteHudRoot;
	TextWidget m_FonteBarText;
	ImageWidget m_FonteBarFill;
	TextWidget m_FonteChainsText;
	TextWidget m_FonteIngotsText;
	int m_FonteTotalIngots;
	int m_FonteIngotsDone;
	int m_FonteChainsDone;
	int m_FonteCurrentIngotStartTime;  // timestamp debut du palier (pour barre par palier)
	const int FONTE_SECONDS_PER_INGOT = 60;
	
	//------------------------------------------------------------------------------------------------
	// === DEMARRAGE DE LA FONTE ===
	
	void ClientAskStartFonte(RplId fourRplId)
	{
		Rpc(RpcAsk_StartFonte, fourRplId);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_StartFonte(RplId fourRplId)
	{
		if (!Replication.IsServer()) return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		IEntity playerEntity = pc.GetControlledEntity();
		if (!playerEntity)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[FONTE] Erreur : joueur introuvable.");
			return;
		}

		// ACCES LIBRE (11 nov 2026) : le metier FONDEUR n est plus requis pour utiliser
		// le four. Le check metier a ete retire ici et dans JobFonteFourAction.
		// Les validations restantes (distance au four, presence des chaines) suffisent.

		// Resout le four et verifie la distance
		RplComponent fourRpl = RplComponent.Cast(Replication.FindItem(fourRplId));
		if (!fourRpl)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[FONTE] Erreur : four introuvable.");
			return;
		}
		IEntity fourEntity = fourRpl.GetEntity();
		if (!fourEntity)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[FONTE] Erreur : four introuvable.");
			return;
		}
		float dist = vector.Distance(playerEntity.GetOrigin(), fourEntity.GetOrigin());
		if (dist > JobFonteData.MAX_DISTANCE_FROM_FOUR)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				string.Format("[FONTE] Vous etes trop loin du four (%1m).",
					Math.Floor(dist).ToString()));
			return;
		}
		
		int totalChains;
		int totalIngots;
		int result = JobFonteManager.GetInstance().StartFonte(playerId, fourEntity,
			totalChains, totalIngots);
		switch (result)
		{
			case 0:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					string.Format("[FONTE] Fonte demarree : %1 chaines -> %2 lingots (%3 min).",
						totalChains.ToString(), totalIngots.ToString(),
						totalIngots.ToString()));
				break;
			case 1:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[FONTE] Une fonte est deja en cours.");
				break;
			case 2:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[FONTE] Il faut au moins 5 chaines en or dans votre inventaire.");
				break;
			case 3:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[FONTE] Erreur : impossible de demarrer la fonte.");
				break;
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// === HUD FONTE COTE CLIENT ===
	
	void ServerStartFonteHud(int totalIngots, vector fourOrigin)
	{
		Rpc(RpcDo_StartFonteHud, totalIngots);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_StartFonteHud(int totalIngots)
	{
		m_FonteTotalIngots = totalIngots;
		m_FonteIngotsDone = 0;
		m_FonteChainsDone = 0;
		m_FonteCurrentIngotStartTime = System.GetUnixTime();
		ShowFonteHud();
	}
	
	void ServerEndFonteHud()
	{
		Rpc(RpcDo_EndFonteHud);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_EndFonteHud()
	{
		HideFonteHud();
	}
	
	void ServerSyncFonteStats(int ingotsDone, int chainsDone)
	{
		Rpc(RpcDo_SyncFonteStats, ingotsDone, chainsDone);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_SyncFonteStats(int ingotsDone, int chainsDone)
	{
		m_FonteIngotsDone = ingotsDone;
		m_FonteChainsDone = chainsDone;
		// Reset le timer du palier au moment ou un lingot est cree (debut du palier suivant)
		m_FonteCurrentIngotStartTime = System.GetUnixTime();
		// Force refresh immediat
		TickFonteHud();
	}
	
	//------------------------------------------------------------------------------------------------
	void ShowFonteHud()
	{
		if (m_FonteHudRoot)
			return;
		WorkspaceWidget ws = GetGame().GetWorkspace();
		if (!ws) return;
		m_FonteHudRoot = ws.CreateWidgets(
			"{6FE56748154E5505}UI/layouts/JobFonteHud.layout");
		if (!m_FonteHudRoot) return;
		
		m_FonteBarText = TextWidget.Cast(m_FonteHudRoot.FindAnyWidget("BarText"));
		m_FonteBarFill = ImageWidget.Cast(m_FonteHudRoot.FindAnyWidget("BarFill"));
		m_FonteChainsText = TextWidget.Cast(m_FonteHudRoot.FindAnyWidget("ChainsText"));
		m_FonteIngotsText = TextWidget.Cast(m_FonteHudRoot.FindAnyWidget("IngotsText"));
		
		GetGame().GetCallqueue().CallLater(TickFonteHud, 1000, true);
		TickFonteHud();
	}
	
	void HideFonteHud()
	{
		GetGame().GetCallqueue().Remove(TickFonteHud);
		if (m_FonteHudRoot)
		{
			m_FonteHudRoot.RemoveFromHierarchy();
			m_FonteHudRoot = null;
			m_FonteBarText = null;
			m_FonteBarFill = null;
			m_FonteChainsText = null;
			m_FonteIngotsText = null;
		}
	}
	
	// Tick local cote client : met a jour timer + barre + stats
	void TickFonteHud()
	{
		if (!m_FonteHudRoot) return;
		int now = System.GetUnixTime();
		int elapsed = now - m_FonteCurrentIngotStartTime;
		int remaining = FONTE_SECONDS_PER_INGOT - elapsed;
		if (remaining < 0) remaining = 0;
		
		// Format mm:ss
		int mm = remaining / 60;
		int ss = remaining - mm * 60;
		string label = string.Format("%1:%2", mm.ToString(),
			JobFonteHudPadInt(ss));
		if (m_FonteBarText)
			m_FonteBarText.SetText(label);
		
		// Largeur barre : progression du palier en cours (de 0 vers 416)
		if (m_FonteBarFill)
		{
			float ratio = (float)elapsed / (float)FONTE_SECONDS_PER_INGOT;
			if (ratio > 1) ratio = 1;
			float width = 416 * ratio;
			m_FonteBarFill.SetSize(width, 24);
		}
		
		// Stats : chaines fondues + lingots
		if (m_FonteChainsText)
			m_FonteChainsText.SetText(string.Format("Chaines fondues : %1",
				m_FonteChainsDone.ToString()));
		if (m_FonteIngotsText)
			m_FonteIngotsText.SetText(string.Format("Lingots : %1 / %2",
				m_FonteIngotsDone.ToString(), m_FonteTotalIngots.ToString()));
	}
	
	// Helper : zero-pad un int a 2 chiffres
	static string JobFonteHudPadInt(int v)
	{
		if (v < 10)
			return "0" + v.ToString();
		return v.ToString();
	}
}

modded class JobPlayerComponent
{
	//------------------------------------------------------------------------------------------------
	// ============================================================
	// FOUILLE COFFRE AU TRESOR SOUS-MARIN
	// ============================================================
	//------------------------------------------------------------------------------------------------
	
	// HUD tresor cote client
	Widget m_TresorHudRoot;
	TextWidget m_TresorBarText;
	ImageWidget m_TresorBarFill;
	TextWidget m_TresorItemsText;
	TextWidget m_TresorRaresText;
	TextWidget m_TresorDistanceText;
	int m_TresorTotalSeconds;
	int m_TresorStartUnixTime;
	vector m_TresorCoffreOrigin;
	int m_TresorItemsDone;
	int m_TresorRaresDone;
	
	//------------------------------------------------------------------------------------------------
	// === DEMARRAGE DE LA RECHERCHE ===
	
	void ClientAskStartTresor(RplId coffreRplId)
	{
		Rpc(RpcAsk_StartTresor, coffreRplId);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_StartTresor(RplId coffreRplId)
	{
		if (!Replication.IsServer()) return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		
		// Resout le coffre
		RplComponent coffreRpl = RplComponent.Cast(Replication.FindItem(coffreRplId));
		if (!coffreRpl)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[TRESOR] Erreur : coffre introuvable.");
			return;
		}
		IEntity coffreEntity = coffreRpl.GetEntity();
		if (!coffreEntity)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[TRESOR] Erreur : coffre introuvable.");
			return;
		}
		
		int cdRemaining;
		int result = JobTresorManager.GetInstance().StartTresor(playerId, coffreEntity, cdRemaining);
		switch (result)
		{
			case 0:
				// OK, le manager a deja envoye le HUD
				break;
			case 1:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[TRESOR] Vous avez deja une recherche en cours.");
				break;
			case 2:
				int mins = cdRemaining / 60;
				int secs = cdRemaining - mins * 60;
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					string.Format("[TRESOR] Cooldown actif : encore %1 min %2s avant de pouvoir reouvrir.",
						mins.ToString(), secs.ToString()));
				break;
			case 3:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[TRESOR] Il vous faut des palmes de plongee + scuba gear pour ouvrir le coffre.");
				break;
			case 4:
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					"[TRESOR] Erreur : impossible de demarrer la recherche.");
				break;
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// === HUD TRESOR COTE CLIENT ===
	
	void ServerStartTresorHud(int totalSeconds, vector coffreOrigin)
	{
		Rpc(RpcDo_StartTresorHud, totalSeconds, coffreOrigin);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_StartTresorHud(int totalSeconds, vector coffreOrigin)
	{
		m_TresorTotalSeconds = totalSeconds;
		m_TresorStartUnixTime = System.GetUnixTime();
		m_TresorCoffreOrigin = coffreOrigin;
		m_TresorItemsDone = 0;
		m_TresorRaresDone = 0;
		ShowTresorHud();
	}
	
	void ServerEndTresorHud()
	{
		Rpc(RpcDo_EndTresorHud);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_EndTresorHud()
	{
		HideTresorHud();
	}
	
	void ServerSyncTresorStats(int itemsDone, int raresDone)
	{
		Rpc(RpcDo_SyncTresorStats, itemsDone, raresDone);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_SyncTresorStats(int itemsDone, int raresDone)
	{
		m_TresorItemsDone = itemsDone;
		m_TresorRaresDone = raresDone;
		TickTresorHud();
	}
	
	void ServerShowTresorRareHint(string msg)
	{
		Rpc(RpcDo_ShowTresorRareHint, msg);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_ShowTresorRareHint(string msg)
	{
		LP_NotificationManager.Show(msg, "TRESOR RARE", 5);
	}
	
	//------------------------------------------------------------------------------------------------
	void ShowTresorHud()
	{
		if (m_TresorHudRoot) return;
		WorkspaceWidget ws = GetGame().GetWorkspace();
		if (!ws) return;
		m_TresorHudRoot = ws.CreateWidgets(
			"{72166C014757BE91}UI/layouts/JobTresorHud.layout");
		if (!m_TresorHudRoot) return;
		
		m_TresorBarText = TextWidget.Cast(m_TresorHudRoot.FindAnyWidget("BarText"));
		m_TresorBarFill = ImageWidget.Cast(m_TresorHudRoot.FindAnyWidget("BarFill"));
		m_TresorItemsText = TextWidget.Cast(m_TresorHudRoot.FindAnyWidget("ItemsText"));
		m_TresorRaresText = TextWidget.Cast(m_TresorHudRoot.FindAnyWidget("RaresText"));
		m_TresorDistanceText = TextWidget.Cast(m_TresorHudRoot.FindAnyWidget("DistanceText"));
		
		GetGame().GetCallqueue().CallLater(TickTresorHud, 1000, true);
		TickTresorHud();
	}
	
	void HideTresorHud()
	{
		GetGame().GetCallqueue().Remove(TickTresorHud);
		if (m_TresorHudRoot)
		{
			m_TresorHudRoot.RemoveFromHierarchy();
			m_TresorHudRoot = null;
			m_TresorBarText = null;
			m_TresorBarFill = null;
			m_TresorItemsText = null;
			m_TresorRaresText = null;
			m_TresorDistanceText = null;
		}
	}
	
	// Tick local : timer + barre + items + rares + distance
	void TickTresorHud()
	{
		if (!m_TresorHudRoot) return;
		int now = System.GetUnixTime();
		int elapsed = now - m_TresorStartUnixTime;
		int remaining = m_TresorTotalSeconds - elapsed;
		if (remaining < 0) remaining = 0;
		
		// Format mm:ss
		int mm = remaining / 60;
		int ss = remaining - mm * 60;
		string label = string.Format("%1:%2", mm.ToString(),
			JobTresorHudPadInt(ss));
		if (m_TresorBarText)
			m_TresorBarText.SetText(label);
		
		// Barre
		if (m_TresorBarFill && m_TresorTotalSeconds > 0)
		{
			float ratio = (float)elapsed / (float)m_TresorTotalSeconds;
			if (ratio > 1) ratio = 1;
			float width = 416 * ratio;
			m_TresorBarFill.SetSize(width, 24);
		}
		
		// Items obtenus
		if (m_TresorItemsText)
			m_TresorItemsText.SetText(string.Format("Items : %1",
				m_TresorItemsDone.ToString()));
		// Rares
		if (m_TresorRaresText)
			m_TresorRaresText.SetText(string.Format("Rares : %1",
				m_TresorRaresDone.ToString()));
		
		// Distance dynamique
		if (m_TresorDistanceText)
		{
			float dist = 0;
			IEntity playerEnt = GetGame().GetPlayerController().GetControlledEntity();
			if (playerEnt)
				dist = vector.Distance(playerEnt.GetOrigin(), m_TresorCoffreOrigin);
			int distInt = Math.Floor(dist);
			m_TresorDistanceText.SetText(string.Format("%1m / 15m", distInt.ToString()));
			if (dist >= 12)
				m_TresorDistanceText.SetColor(Color.FromRGBA(230, 50, 50, 255));
			else if (dist >= 8)
				m_TresorDistanceText.SetColor(Color.FromRGBA(240, 190, 50, 255));
			else
				m_TresorDistanceText.SetColor(Color.FromRGBA(220, 220, 220, 255));
		}
		
		// Self-stop si timer fini (au cas ou)
		if (remaining <= 0)
			HideTresorHud();
	}
	
	static string JobTresorHudPadInt(int v)
	{
		if (v < 10)
			return "0" + v.ToString();
		return v.ToString();
	}
	
			// Map des cooldowns de retrait (cle = UID, valeur = timestamp unix de fin de cooldown).
	// On utilise un static pour simplifier (volatile au reboot, acceptable car peu d impact RP).
	static ref map<string, int> s_PresidentWithdrawCooldowns = new map<string, int>();
	const int PRESIDENT_WITHDRAW_COOLDOWN_SECONDS = 3600;  // 1 heure
	
	//------------------------------------------------------------------------------------------------
	// === DEMANDE D INFOS PRESIDENT (LBP tax + Company tax + Treasury + Cooldown) ===
	//------------------------------------------------------------------------------------------------
	
	void ClientAskPresidentInfo()
	{
		Rpc(RpcAsk_PresidentInfo);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_PresidentInfo()
	{
		if (!Replication.IsServer()) return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		
		// Verifie metier PRESIDENT
		JobPlayerData data = JobManager.GetInstance().GetPlayerData(playerId);
		if (!data || data.m_Job != EJobType.PRESIDENT)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[PRESIDENT] Acces refuse : vous n etes pas le President.");
			return;
		}
		
		// Recupere les valeurs
		JobBonPointManager bpm = JobBonPointManager.GetInstance();
		JobCompanyManager cm = JobCompanyManager.GetInstance();
		if (!bpm || !cm) return;
		
		int lbpTax = bpm.GetTaxRatePercent();
		int companyTax = cm.GetCompanyTaxPercent();
		int treasury = bpm.GetTreasury();
		
		// Cooldown retrait
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		int cooldownRemaining = 0;
		if (uid != "")
		{
			int endTime;
			if (s_PresidentWithdrawCooldowns.Find(uid, endTime))
			{
				int now = System.GetUnixTime();
				if (now < endTime)
					cooldownRemaining = endTime - now;
			}
		}
		
		// Push au client
		Rpc(RpcDo_PresidentInfo, lbpTax, companyTax, treasury, cooldownRemaining);
		if (IsLocalPlayerOwner())
			RpcDo_PresidentInfo(lbpTax, companyTax, treasury, cooldownRemaining);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_PresidentInfo(int lbpTax, int companyTax, int treasury, int cooldownRemaining)
	{
		// Met a jour le menu si ouvert (utilise l instance statique du menu)
		JobPresidentMenu menu = JobPresidentMenu.GetOpenMenu();
		if (menu)
			menu.UpdateDisplay(lbpTax, companyTax, treasury, cooldownRemaining);
	}
	
	//------------------------------------------------------------------------------------------------
	// === MODIFIER LA TAXE LEBONPOINT ===
	//------------------------------------------------------------------------------------------------
	
	void ClientAskPresidentSetLbpTax(int newTax)
	{
		Rpc(RpcAsk_PresidentSetLbpTax, newTax);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_PresidentSetLbpTax(int newTax)
	{
		if (!Replication.IsServer()) return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		
		JobPlayerData data = JobManager.GetInstance().GetPlayerData(playerId);
		if (!data || data.m_Job != EJobType.PRESIDENT)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[PRESIDENT] Acces refuse.");
			return;
		}
		
		JobBonPointManager bpm = JobBonPointManager.GetInstance();
		if (!bpm) return;
		
		int applied = bpm.SetTaxRatePercent(newTax);
		JobManager.GetInstance().NotifyPlayerChat(playerId,
			string.Format("[PRESIDENT] Taxe LeBonPoint mise a %1%%.", applied.ToString()));
	}
	
	//------------------------------------------------------------------------------------------------
	// === MODIFIER LA TAXE ENTREPRISE ===
	//------------------------------------------------------------------------------------------------
	
	void ClientAskPresidentSetCompanyTax(int newTax)
	{
		Rpc(RpcAsk_PresidentSetCompanyTax, newTax);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_PresidentSetCompanyTax(int newTax)
	{
		if (!Replication.IsServer()) return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		
		JobPlayerData data = JobManager.GetInstance().GetPlayerData(playerId);
		if (!data || data.m_Job != EJobType.PRESIDENT)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[PRESIDENT] Acces refuse.");
			return;
		}
		
		JobCompanyManager cm = JobCompanyManager.GetInstance();
		if (!cm) return;
		
		int applied = cm.SetCompanyTaxPercent(newTax);
		JobManager.GetInstance().NotifyPlayerChat(playerId,
			string.Format("[PRESIDENT] Taxe Entreprises mise a %1%%.", applied.ToString()));
	}
	
	//------------------------------------------------------------------------------------------------
	// === RETIRER 10% DE LA CAGNOTTE MUNICIPALE ===
	// Conditions :
	//  - Metier PRESIDENT
	//  - Pas de cooldown actif (1 retrait / heure)
	//  - Cagnotte > 0
	// Action :
	//  - Calcule 10% de la cagnotte actuelle
	//  - Retire cette somme de la cagnotte
	//  - Credite les capsules personnelles du President
	//  - Demarre le cooldown 1h
	//------------------------------------------------------------------------------------------------
	
	void ClientAskPresidentWithdraw()
	{
		Rpc(RpcAsk_PresidentWithdraw);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_PresidentWithdraw()
	{
		if (!Replication.IsServer()) return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		
		JobPlayerData data = JobManager.GetInstance().GetPlayerData(playerId);
		if (!data || data.m_Job != EJobType.PRESIDENT)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[PRESIDENT] Acces refuse.");
			return;
		}
		
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "")
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[PRESIDENT] Erreur d identification.");
			return;
		}
		
		// Verif cooldown
		int now = System.GetUnixTime();
		int endTime;
		if (s_PresidentWithdrawCooldowns.Find(uid, endTime))
		{
			if (now < endTime)
			{
				int remaining = endTime - now;
				int mins = remaining / 60;
				JobManager.GetInstance().NotifyPlayerChat(playerId,
					string.Format("[PRESIDENT] Cooldown actif : encore %1 min avant le prochain retrait.",
						mins.ToString()));
				return;
			}
		}
		
		// Calcule le retrait (10% de la cagnotte)
		JobBonPointManager bpm = JobBonPointManager.GetInstance();
		if (!bpm) return;
		int treasury = bpm.GetTreasury();
		if (treasury <= 0)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[PRESIDENT] La cagnotte municipale est vide.");
			return;
		}
		int amount = treasury / 10;
		if (amount <= 0)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[PRESIDENT] Cagnotte trop faible (10% = 0).");
			return;
		}
		
		// Effectue le retrait + credit au president
		int withdrawn = bpm.WithdrawFromTreasury(amount);
		if (withdrawn <= 0)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[PRESIDENT] Erreur lors du retrait.");
			return;
		}
		
		CapsuleEconomyManager eco = CapsuleEconomyManager.GetInstance();
		if (eco)
		{
			eco.AddCapsules(uid, withdrawn);
			int newTotal = eco.GetCapsules(uid);
			
			// Sync HUD capsules
			CapsulePlayerComponent capsComp = CapsulePlayerComponent.Cast(
				pc.FindComponent(CapsulePlayerComponent));
			if (capsComp)
				capsComp.Svr_SendCapsules(newTotal);
		}
		
		// Demarre le cooldown
		s_PresidentWithdrawCooldowns.Set(uid, now + PRESIDENT_WITHDRAW_COOLDOWN_SECONDS);
		
		JobManager.GetInstance().NotifyPlayerChat(playerId,
			string.Format("[PRESIDENT] %1 capsules retirees de la cagnotte. Prochain retrait dans 1 heure.",
				withdrawn.ToString()));
		
		Print(string.Format("[JobPlayerComponent] President withdraw : player=%1 amount=%2",
			playerId, withdrawn), LogLevel.NORMAL);
	}
	
	//------------------------------------------------------------------------------------------------
	// ============================================================
	// ================  SYSTEME POCHON (MARCHANDISE)  ==============
	// ============================================================
	//------------------------------------------------------------------------------------------------
	
	// === HUD Pochon (client) ===
	Widget m_PochonHudRoot;
	TextWidget m_PochonBarText;
	ImageWidget m_PochonBarFill;
	TextWidget m_PochonPochonsText;
	int m_PochonTotalPochons;
	int m_PochonPochonsDone;
	int m_PochonCurrentPochonStartTime;
	
	// === Effets Pochon (client) ===
	int m_PochonEffectEndUnix = 0;   // 0 = pas d effet actif
	Widget m_PochonEffectRoot;       // overlay post-process visuel
	
	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : demande le solde de capsules (rafraichissement menu shop)
	//------------------------------------------------------------------------------------------------
	void ClientAskCapsulesForPochonShop()
	{
		Rpc(RpcAsk_CapsulesForPochonShop);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_CapsulesForPochonShop()
	{
		if (!Replication.IsServer()) return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "") return;
		int capsules = CapsuleEconomyManager.GetInstance().GetCapsules(uid);
		Rpc(RpcDo_CapsulesForPochonShop, capsules);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_CapsulesForPochonShop(int capsules)
	{
		JobPochonShopMenu menu = JobPochonShopMenu.GetOpenMenu();
		if (menu) menu.DisplayCapsules(capsules);
	}
	
	//------------------------------------------------------------------------------------------------
	// ==================== VENTE DE POCHONS AU PNJ ACHETEUR ====================
	//------------------------------------------------------------------------------------------------
	
	// CLIENT -> SERVER : demande les infos pour le menu de vente
	// (inventaire, quota restant, fin de fenetre)
	void ClientAskPochonSaleInfo()
	{
		Rpc(RpcAsk_PochonSaleInfo);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_PochonSaleInfo()
	{
		if (!Replication.IsServer()) return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "") return;
		
		IEntity character = pc.GetControlledEntity();
		int invCount = CountPochonsInInventory(character);
		int remaining = JobPochonSaleManager.GetInstance().GetRemainingQuota(uid);
		int windowEnd = JobPochonSaleManager.GetInstance().GetWindowEndUnix(uid);
		int boursePercent = JobPochonBourseManager.GetInstance().GetCurrentPercent();
		int unitPrice = JobPochonBourseManager.GetInstance().GetCurrentUnitPrice();
		
		Rpc(RpcDo_PochonSaleInfo, invCount, remaining, windowEnd, boursePercent, unitPrice);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_PochonSaleInfo(int invCount, int remaining, int windowEnd, int boursePercent, int unitPrice)
	{
		JobPochonSaleMenu menu = JobPochonSaleMenu.GetOpenMenu();
		if (menu) menu.DisplayInfo(invCount, remaining, windowEnd, boursePercent, unitPrice);
	}
	
	//------------------------------------------------------------------------------------------------
	// Compte les pochons dans l inventaire du personnage
	//------------------------------------------------------------------------------------------------
	int CountPochonsInInventory(IEntity character)
	{
		if (!character) return 0;
		SCR_InventoryStorageManagerComponent inv = SCR_InventoryStorageManagerComponent.Cast(
			character.FindComponent(SCR_InventoryStorageManagerComponent));
		if (!inv) return 0;
		
		array<IEntity> items = new array<IEntity>();
		inv.GetItems(items);
		
		int count = 0;
		foreach (IEntity item : items)
		{
			if (!item) continue;
			string prefabName = item.GetPrefabData().GetPrefabName();
			if (PochonStringContains(prefabName, JobPochonData.GUID_POCHON))
				count = count + 1;
		}
		return count;
	}
	
	//------------------------------------------------------------------------------------------------
	// Helper local Contains (Enforce Script n a pas string.Contains natif)
	//------------------------------------------------------------------------------------------------
	bool PochonStringContains(string haystack, string needle)
	{
		int hlen = haystack.Length();
		int nlen = needle.Length();
		if (nlen == 0) return true;
		if (nlen > hlen) return false;
		int lastStart = hlen - nlen;
		for (int i = 0; i <= lastStart; i++)
		{
			if (haystack.Substring(i, nlen) == needle)
				return true;
		}
		return false;
	}
	
	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : vend N pochons
	//------------------------------------------------------------------------------------------------
	void ClientAskSellPochons(int quantity)
	{
		Rpc(RpcAsk_SellPochons, quantity);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_SellPochons(int quantity)
	{
		if (!Replication.IsServer()) return;
		if (quantity <= 0) return;
		
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "") return;
		
		// Check metier voyou OU membre gang
		JobPlayerData data = JobManager.GetInstance().GetPlayerData(playerId);
		if (!data)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[Marchandise] Donnees joueur introuvables.");
			return;
		}
		bool isVoyou = (data.m_Job == EJobType.VOYOU);
		bool isInGang = (JobGangManager.GetInstance().GetGangOfPlayer(uid) != null);
		if (!isVoyou && !isInGang)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[Marchandise] Reserve aux Voyous et membres d un gang.");
			return;
		}
		
		// Check cap quantity (max fenetre)
		if (quantity > JobPochonData.MAX_VENTES_PAR_FENETRE)
			quantity = JobPochonData.MAX_VENTES_PAR_FENETRE;
		
		// Check quota fenetre glissante
		int remaining = JobPochonSaleManager.GetInstance().GetRemainingQuota(uid);
		if (remaining <= 0)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[Marchandise] Quota atteint - reessayez plus tard.");
			return;
		}
		if (quantity > remaining) quantity = remaining;
		
		// Consomme les pochons dans l inventaire
		IEntity character = pc.GetControlledEntity();
		if (!character)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[Marchandise] Personnage introuvable.");
			return;
		}
		int consumed = ConsumePochonsFromInventory(character, quantity);
		if (consumed <= 0)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[Marchandise] Aucun pochon dans votre inventaire.");
			return;
		}
		
		// Credite le joueur (prix modifie par la bourse)
		int unitPrice = JobPochonBourseManager.GetInstance().GetCurrentUnitPrice();
		int gain = consumed * unitPrice;
		CapsuleEconomyManager.GetInstance().AddCapsules(uid, gain);
		
		// Enregistre la vente (quota joueur + bourse globale)
		JobPochonSaleManager.GetInstance().RecordSale(uid, consumed);
		JobPochonBourseManager.GetInstance().RecordSale(consumed);
		
		int boursePercent = JobPochonBourseManager.GetInstance().GetCurrentPercent();
		JobManager.GetInstance().NotifyPlayerChat(playerId,
			string.Format("[Marchandise] %1 pochon(s) vendu(s) pour %2 capsules (bourse %3%%).",
				consumed.ToString(), gain.ToString(), boursePercent.ToString()));
	}
	
	//------------------------------------------------------------------------------------------------
	// Consomme jusqu a "quantity" pochons dans l inventaire. Retourne le nombre effectivement consomme.
	//------------------------------------------------------------------------------------------------
	int ConsumePochonsFromInventory(IEntity character, int quantity)
	{
		if (!character || quantity <= 0) return 0;
		SCR_InventoryStorageManagerComponent inv = SCR_InventoryStorageManagerComponent.Cast(
			character.FindComponent(SCR_InventoryStorageManagerComponent));
		if (!inv) return 0;
		
		array<IEntity> items = new array<IEntity>();
		inv.GetItems(items);
		
		// Collecte d abord les pochons a supprimer
		array<IEntity> toDelete = new array<IEntity>();
		foreach (IEntity item : items)
		{
			if (!item) continue;
			string prefabName = item.GetPrefabData().GetPrefabName();
			if (PochonStringContains(prefabName, JobPochonData.GUID_POCHON))
			{
				toDelete.Insert(item);
				if (toDelete.Count() >= quantity) break;
			}
		}
		
		// Supprime maintenant (hors iteration)
		int deleted = 0;
		foreach (IEntity item : toDelete)
		{
			if (!item) continue;
			SCR_EntityHelper.DeleteEntityAndChildren(item);
			deleted = deleted + 1;
		}
		return deleted;
	}
	
	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : achete un sac a pochon
	//------------------------------------------------------------------------------------------------
	void ClientAskBuyPochonBag()
	{
		Rpc(RpcAsk_BuyPochonBag);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_BuyPochonBag()
	{
		if (!Replication.IsServer()) return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "") return;
		
		// Check metier voyou OU membre gang
		JobPlayerData data = JobManager.GetInstance().GetPlayerData(playerId);
		if (!data)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[Marchandise] Donnees joueur introuvables.");
			return;
		}
		bool isVoyou = (data.m_Job == EJobType.VOYOU);
		bool isInGang = (JobGangManager.GetInstance().GetGangOfPlayer(uid) != null);
		if (!isVoyou && !isInGang)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[Marchandise] Reserve aux Voyous et membres d un gang.");
			return;
		}
		
		// Check solde
		int balance = CapsuleEconomyManager.GetInstance().GetCapsules(uid);
		if (balance < JobPochonData.PRIX_SAC_POCHON)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				string.Format("[Marchandise] Solde insuffisant (%1 / %2 capsules).",
					balance.ToString(), JobPochonData.PRIX_SAC_POCHON.ToString()));
			return;
		}
		
		// Spawn le sac dans l inventaire
		IEntity character = pc.GetControlledEntity();
		if (!character)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[Marchandise] Personnage introuvable.");
			return;
		}
		SCR_InventoryStorageManagerComponent inv = SCR_InventoryStorageManagerComponent.Cast(
			character.FindComponent(SCR_InventoryStorageManagerComponent));
		if (!inv)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[Marchandise] Inventaire introuvable.");
			return;
		}
		ResourceName rn = JobPochonData.PREFAB_SAC_POCHON;
		bool spawned = inv.TrySpawnPrefabToStorage(rn);
		if (!spawned)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[Marchandise] Inventaire plein - achat annule.");
			return;
		}
		
		// Debit apres spawn reussi
		CapsuleEconomyManager.GetInstance().AddCapsules(uid, -JobPochonData.PRIX_SAC_POCHON);
		JobManager.GetInstance().NotifyPlayerChat(playerId,
			string.Format("[Marchandise] Sac a pochon achete pour %1 capsules.",
				JobPochonData.PRIX_SAC_POCHON.ToString()));
	}
	
	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : demarre transformation sur la table
	//------------------------------------------------------------------------------------------------
	void ClientAskStartPochonTransform(RplId tableRplId)
	{
		Rpc(RpcAsk_StartPochonTransform, tableRplId);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_StartPochonTransform(RplId tableRplId)
	{
		if (!Replication.IsServer()) return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		
		RplComponent rpl = RplComponent.Cast(Replication.FindItem(tableRplId));
		if (!rpl)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId, "[Marchandise] Table introuvable.");
			return;
		}
		IEntity table = rpl.GetEntity();
		if (!table)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId, "[Marchandise] Table introuvable.");
			return;
		}
		
		int result = JobPochonTransformManager.GetInstance().StartTransformation(playerId, table);
		if (result == 1)
			JobManager.GetInstance().NotifyPlayerChat(playerId, "[Marchandise] Transformation deja en cours.");
		else if (result == 2)
			JobManager.GetInstance().NotifyPlayerChat(playerId, "[Marchandise] Aucun sac a pochon dans votre inventaire.");
		else if (result == 3)
			JobManager.GetInstance().NotifyPlayerChat(playerId, "[Marchandise] Reserve aux Voyous et membres d un gang.");
		else if (result == 4)
			JobManager.GetInstance().NotifyPlayerChat(playerId, "[Marchandise] Erreur - impossible de demarrer.");
	}
	
	//------------------------------------------------------------------------------------------------
	// SERVER -> CLIENT : demarre le HUD pochon
	//------------------------------------------------------------------------------------------------
	void ServerStartPochonHud(int totalPochons, vector tableOrigin)
	{
		Rpc(RpcDo_StartPochonHud, totalPochons);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_StartPochonHud(int totalPochons)
	{
		m_PochonTotalPochons = totalPochons;
		m_PochonPochonsDone = 0;
		m_PochonCurrentPochonStartTime = System.GetUnixTime();
		ShowPochonHud();
	}
	
	void ServerEndPochonHud()
	{
		Rpc(RpcDo_EndPochonHud);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_EndPochonHud()
	{
		HidePochonHud();
	}
	
	void ServerSyncPochonStats(int pochonsDone, int totalPochons)
	{
		Rpc(RpcDo_SyncPochonStats, pochonsDone, totalPochons);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_SyncPochonStats(int pochonsDone, int totalPochons)
	{
		m_PochonPochonsDone = pochonsDone;
		m_PochonTotalPochons = totalPochons;
		m_PochonCurrentPochonStartTime = System.GetUnixTime();
		TickPochonHud();
	}
	
	//------------------------------------------------------------------------------------------------
	// Cote client : cree / detruit le HUD
	//------------------------------------------------------------------------------------------------
	void ShowPochonHud()
	{
		if (m_PochonHudRoot) return;
		WorkspaceWidget ws = GetGame().GetWorkspace();
		if (!ws) return;
		m_PochonHudRoot = ws.CreateWidgets("UI/layouts/JobPochonHud.layout");
		if (!m_PochonHudRoot) return;
		
		m_PochonBarText = TextWidget.Cast(m_PochonHudRoot.FindAnyWidget("BarText"));
		m_PochonBarFill = ImageWidget.Cast(m_PochonHudRoot.FindAnyWidget("BarFill"));
		m_PochonPochonsText = TextWidget.Cast(m_PochonHudRoot.FindAnyWidget("PochonsText"));
		
		GetGame().GetCallqueue().CallLater(TickPochonHud, 1000, true);
		TickPochonHud();
	}
	
	void HidePochonHud()
	{
		GetGame().GetCallqueue().Remove(TickPochonHud);
		if (m_PochonHudRoot)
		{
			m_PochonHudRoot.RemoveFromHierarchy();
			m_PochonHudRoot = null;
			m_PochonBarText = null;
			m_PochonBarFill = null;
			m_PochonPochonsText = null;
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Tick local cote client : met a jour timer + barre + stats
	//------------------------------------------------------------------------------------------------
	void TickPochonHud()
	{
		if (!m_PochonHudRoot) return;
		int now = System.GetUnixTime();
		int elapsed = now - m_PochonCurrentPochonStartTime;
		int remaining = JobPochonData.INTERVALLE_POCHON_S - elapsed;
		if (remaining < 0) remaining = 0;
		
		int mm = remaining / 60;
		int ss = remaining - mm * 60;
		string mmStr = mm.ToString();
		string ssStr = ss.ToString();
		if (ss < 10) ssStr = "0" + ssStr;
		string label = mmStr + ":" + ssStr;
		if (m_PochonBarText) m_PochonBarText.SetText(label);
		
		// Largeur barre progression
		if (m_PochonBarFill)
		{
			float ratio = (float)elapsed / (float)JobPochonData.INTERVALLE_POCHON_S;
			if (ratio > 1) ratio = 1;
			float width = 416 * ratio;
			m_PochonBarFill.SetSize(width, 24);
		}
		
		if (m_PochonPochonsText)
			m_PochonPochonsText.SetText(string.Format("Pochons : %1 / %2",
				m_PochonPochonsDone.ToString(), m_PochonTotalPochons.ToString()));
	}
	
	//------------------------------------------------------------------------------------------------
	// CLIENT -> SERVER : utilise un pochon (par action)
	//------------------------------------------------------------------------------------------------
	void ClientAskUsePochon(RplId pochonRplId)
	{
		Rpc(RpcAsk_UsePochon, pochonRplId);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_UsePochon(RplId pochonRplId)
	{
		if (!Replication.IsServer()) return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		
		RplComponent rpl = RplComponent.Cast(Replication.FindItem(pochonRplId));
		if (!rpl) return;
		IEntity pochon = rpl.GetEntity();
		if (!pochon) return;
		
		// Verifie que le pochon appartient bien au joueur (dans son inventaire)
		IEntity character = pc.GetControlledEntity();
		if (!character) return;
		
		// Consomme le pochon
		SCR_EntityHelper.DeleteEntityAndChildren(pochon);
		
		// Applique les effets
		JobPochonEffectManager.GetInstance().StartEffect(playerId);
	}
	
	//------------------------------------------------------------------------------------------------
	// SERVER -> CLIENT : demarre les effets visuels + vitesse du pochon
	//------------------------------------------------------------------------------------------------
	void ServerStartPochonEffect(int duration)
	{
		Rpc(RpcDo_StartPochonEffect, duration);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_StartPochonEffect(int duration)
	{
		m_PochonEffectEndUnix = System.GetUnixTime() + duration;
		ShowPochonEffectOverlay();
		// Vitesse : le boost passe par SetCharacterSpeedMultiplier sur le controle client
		// Le controle est deja pilote cote client, on peut appliquer via SCR_CharacterControllerComponent
		ApplyPochonSpeedEffect(true);
	}
	
	void ServerEndPochonEffect()
	{
		Rpc(RpcDo_EndPochonEffect);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_EndPochonEffect()
	{
		m_PochonEffectEndUnix = 0;
		HidePochonEffectOverlay();
		ApplyPochonSpeedEffect(false);
	}
	
	//------------------------------------------------------------------------------------------------
	// Cote client : affiche/masque l overlay post-process visuel (teinte violet)
	//------------------------------------------------------------------------------------------------
	void ShowPochonEffectOverlay()
	{
		if (m_PochonEffectRoot) return;
		WorkspaceWidget ws = GetGame().GetWorkspace();
		if (!ws) return;
		
		// Utilise un layout dedie plutot que CreateWidgetGroup (plus fiable)
		m_PochonEffectRoot = ws.CreateWidgets("UI/layouts/JobPochonEffectOverlay.layout");
	}
	
	void HidePochonEffectOverlay()
	{
		if (m_PochonEffectRoot)
		{
			m_PochonEffectRoot.RemoveFromHierarchy();
			m_PochonEffectRoot = null;
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Cote client : le boost de vitesse a ete abandonne (API SetSprintSpeedMultiplier
	// non disponible en Enforce Script - CharacterControllerComponent n expose que
	// SetDynamicSpeed avec valeur 0-1 qui n est pas un multiplicateur).
	// Le pochon garde uniquement l effet visuel de 3 minutes.
	//------------------------------------------------------------------------------------------------
	void ApplyPochonSpeedEffect(bool enable)
	{
		// No-op : effet vitesse abandonne
	}
	
	//------------------------------------------------------------------------------------------------
	// ============================================================
	// ================  PORTES IMMOBILIERES (VENDEUR IMMO)  =======
	// ============================================================
	//------------------------------------------------------------------------------------------------
	
	// ============ OUVERTURE DES MENUS (BRIDGE CLIENT LOCAL) ============
	
	// Depuis Action Vendre / Revendre : ouvre le menu de vente cote client
	void ClientAskOpenDoorSellMenu(RplId doorRplId, bool isResell)
	{
		LP_DoorSellMenu.SetPendingTarget(doorRplId, isResell);
		GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.LP_DoorSellMenu);
	}
	
	void ClientAskOpenLpDoorCodeMenu(RplId doorRplId)
	{
		LP_DoorCodeMenu.SetPendingTarget(doorRplId);
		GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.LP_DoorCodeMenu);
	}
	
	void ClientAskOpenLpEnterCodeMenu(RplId doorRplId)
	{
		LP_DoorEnterCodeMenu.SetPendingTarget(doorRplId);
		GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.LP_DoorEnterCodeMenu);
	}
	
	// ============ INFOS MENU DE VENTE (LISTE JOUEURS) ============
	
	void ClientAskLpDoorSellInfo(RplId doorRplId)
	{
		Rpc(RpcAsk_LpDoorSellInfo, doorRplId);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_LpDoorSellInfo(RplId doorRplId)
	{
		if (!Replication.IsServer()) return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int callerId = pc.GetPlayerId();
		
		// Recupere la position de la porte pour filtrer les joueurs proches (rayon 5m)
		vector doorPos = "0 0 0";
		bool hasDoorPos = false;
		RplComponent doorRpl = RplComponent.Cast(Replication.FindItem(doorRplId));
		if (doorRpl)
		{
			IEntity doorEntity = doorRpl.GetEntity();
			if (doorEntity)
			{
				doorPos = doorEntity.GetOrigin();
				hasDoorPos = true;
			}
		}
		const float DOOR_PROXIMITY_RADIUS_SQ = 5.0 * 5.0; // 25 (squared pour eviter sqrt)
		
		// Liste joueurs connectes (sauf soi-meme, sauf joueurs > 5m de la porte) - avec noms RP
		array<int> allIds = new array<int>();
		GetGame().GetPlayerManager().GetPlayers(allIds);
		array<int> filteredIds = new array<int>();
		array<string> filteredNames = new array<string>();
		foreach (int pid : allIds)
		{
			if (pid == callerId) continue;
			
			// Filtre proximite : le joueur doit etre a moins de 5m de la porte
			if (hasDoorPos)
			{
				IEntity playerEntity = GetGame().GetPlayerManager().GetPlayerControlledEntity(pid);
				if (!playerEntity) continue;
				vector playerPos = playerEntity.GetOrigin();
				if (vector.DistanceSq(playerPos, doorPos) > DOOR_PROXIMITY_RADIUS_SQ)
					continue;
			}
			
			string pseudoName = GetGame().GetPlayerManager().GetPlayerName(pid);
			if (pseudoName == "") pseudoName = "Joueur " + pid.ToString();
			// Nom RP (nom + prenom) OU pseudo Steam si pas defini
			string uid = JobManager.GetInstance().GetPersistentUID(pid);
			string displayName = JobIdentityManager.GetInstance().GetDisplayNameOrFallback(uid, pseudoName);
			filteredIds.Insert(pid);
			filteredNames.Insert(displayName);
		}
		
		string packed = "";
		for (int i = 0; i < filteredIds.Count(); i++)
		{
			if (packed != "") packed = packed + ";";
			packed = packed + filteredIds.Get(i).ToString() + "|" + filteredNames.Get(i);
		}
		Rpc(RpcDo_LpDoorSellInfo, packed);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_LpDoorSellInfo(string packed)
	{
		array<int> ids = new array<int>();
		array<string> names = new array<string>();
		LP_ParsePlayerListDoor(packed, ids, names);
		LP_DoorSellMenu menu = LP_DoorSellMenu.GetOpenMenu();
		if (menu) menu.DisplayPlayers(ids, names);
	}
	
	static void LP_ParsePlayerListDoor(string packed, out array<int> ids, out array<string> names)
	{
		if (packed == "") return;
		int start = 0;
		int len = packed.Length();
		for (int i = 0; i <= len; i++)
		{
			if (i == len || packed.Substring(i, 1) == ";")
			{
				string chunk = packed.Substring(start, i - start);
				start = i + 1;
				if (chunk == "") continue;
				int sepPos = -1;
				for (int j = 0; j < chunk.Length(); j++)
				{
					if (chunk.Substring(j, 1) == "|") { sepPos = j; break; }
				}
				if (sepPos < 0) continue;
				string idStr = chunk.Substring(0, sepPos);
				string nameStr = chunk.Substring(sepPos + 1, chunk.Length() - sepPos - 1);
				ids.Insert(idStr.ToInt());
				names.Insert(nameStr);
			}
		}
	}
	
	// ============ PROPOSITION DE VENTE ============
	
	// NOTE : le doorRplId est passe comme RplId (pas de conversion int)
	void ClientAskProposeLpDoorSale(RplId doorRplId, int buyerPlayerId, int price, bool isResell)
	{
		Rpc(RpcAsk_ProposeLpDoorSale, doorRplId, buyerPlayerId, price, isResell);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_ProposeLpDoorSale(RplId doorRplId, int buyerPlayerId, int price, bool isResell)
	{
		if (!Replication.IsServer()) return;
		if (price < 0) price = 0;
		
		PlayerController sellerPc = PlayerController.Cast(GetOwner());
		if (!sellerPc) return;
		int sellerId = sellerPc.GetPlayerId();
		string sellerUID = JobManager.GetInstance().GetPersistentUID(sellerId);
		if (sellerUID == "") return;
		
		JobPlayerData sellerData = JobManager.GetInstance().GetPlayerData(sellerId);
		if (!sellerData) return;
		
		LP_DoorData existingDoor = LP_DoorManager.GetInstance().GetDoorByRplId(doorRplId);
		bool isImmoAgent = (sellerData.m_Job == EJobType.VENDEUR_IMMOBILIER);
		bool isOwner = (existingDoor != null && existingDoor.m_OwnerUID == sellerUID);
		
		if (!isResell)
		{
			if (!isImmoAgent)
			{
				JobManager.GetInstance().NotifyPlayerChat(sellerId,
					"[Porte] Reserve au metier Vendeur Immobilier.");
				return;
			}
			if (existingDoor != null)
			{
				JobManager.GetInstance().NotifyPlayerChat(sellerId,
					"[Porte] Cette porte a deja un proprietaire.");
				return;
			}
			if (price < LP_DoorManager.DOOR_BASE_COST)
			{
				JobManager.GetInstance().NotifyPlayerChat(sellerId,
					string.Format("[Porte] Prix minimum : %1 capsules (cout de base).",
						LP_DoorManager.DOOR_BASE_COST.ToString()));
				return;
			}
		}
		else
		{
			if (!existingDoor)
			{
				JobManager.GetInstance().NotifyPlayerChat(sellerId,
					"[Porte] Cette porte n a pas de proprietaire.");
				return;
			}
			if (!isOwner)
			{
				JobManager.GetInstance().NotifyPlayerChat(sellerId,
					"[Porte] Vous n etes pas proprietaire de cette porte.");
				return;
			}
		}
		
		PlayerController buyerPc = GetGame().GetPlayerManager().GetPlayerController(buyerPlayerId);
		if (!buyerPc)
		{
			JobManager.GetInstance().NotifyPlayerChat(sellerId, "[Porte] Acheteur non trouve.");
			return;
		}
		string buyerUID = JobManager.GetInstance().GetPersistentUID(buyerPlayerId);
		if (buyerUID == "" || buyerUID == sellerUID)
		{
			JobManager.GetInstance().NotifyPlayerChat(sellerId,
				"[Porte] Vous ne pouvez pas vous vendre a vous-meme.");
			return;
		}
		
		// Enregistre l offre (utilise rplId.ToString() comme cle)
		string sellerPseudoName = GetGame().GetPlayerManager().GetPlayerName(sellerId);
		string sellerRpName = JobIdentityManager.GetInstance().GetDisplayNameOrFallback(sellerUID, sellerPseudoName);
		string buyerPseudoName = GetGame().GetPlayerManager().GetPlayerName(buyerPlayerId);
		string buyerRpName = JobIdentityManager.GetInstance().GetDisplayNameOrFallback(buyerUID, buyerPseudoName);
		
		LP_DoorPendingOffer offer = new LP_DoorPendingOffer();
		offer.SetDoor(doorRplId);
		offer.m_SellerUID = sellerUID;
		offer.m_SellerId = sellerId;
		offer.m_SellerName = sellerRpName;
		offer.m_BuyerUID = buyerUID;
		offer.m_BuyerId = buyerPlayerId;
		offer.m_Price = price;
		offer.m_IsResell = isResell;
		LP_DoorPendingOffer.RegisterOffer(offer);
		
		int buyerBalance = CapsuleEconomyManager.GetInstance().GetCapsules(buyerUID);
		JobPlayerComponent buyerJpc = JobPlayerComponent.Cast(buyerPc.FindComponent(JobPlayerComponent));
		if (buyerJpc)
			buyerJpc.ServerOpenLpDoorBuyConfirm(doorRplId, sellerRpName, price, buyerBalance);
		
		JobManager.GetInstance().NotifyPlayerChat(sellerId,
			string.Format("[Porte] Proposition envoyee a %1 (%2 capsules).",
				buyerRpName, price.ToString()));
	}
	
	// Serveur -> client acheteur
	void ServerOpenLpDoorBuyConfirm(RplId doorRplId, string sellerName, int price, int balance)
	{
		Rpc(RpcDo_OpenLpDoorBuyConfirm, doorRplId, sellerName, price, balance);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_OpenLpDoorBuyConfirm(RplId doorRplId, string sellerName, int price, int balance)
	{
		// Stocke les infos en static + ouvre le menu -> le menu recuperera au OnMenuOpen
		LP_DoorBuyConfirmMenu.s_PendingRplId = doorRplId;
		LP_DoorBuyConfirmMenu.s_PendingSellerName = sellerName;
		LP_DoorBuyConfirmMenu.s_PendingPrice = price;
		LP_DoorBuyConfirmMenu.s_PendingBalance = balance;
		GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.LP_DoorBuyConfirmMenu);
	}
	
	// ============ REPONSE ACHETEUR ============
	
	void ClientAnswerLpDoorSale(RplId doorRplId, bool accept)
	{
		Rpc(RpcAsk_AnswerLpDoorSale, doorRplId, accept);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_AnswerLpDoorSale(RplId doorRplId, bool accept)
	{
		if (!Replication.IsServer()) return;
		PlayerController buyerPc = PlayerController.Cast(GetOwner());
		if (!buyerPc) return;
		int buyerId = buyerPc.GetPlayerId();
		string buyerUID = JobManager.GetInstance().GetPersistentUID(buyerId);
		if (buyerUID == "") return;
		
		LP_DoorPendingOffer offer = LP_DoorPendingOffer.GetOffer(doorRplId.ToString(), buyerUID);
		if (!offer)
		{
			JobManager.GetInstance().NotifyPlayerChat(buyerId,
				"[Porte] Offre introuvable ou expiree.");
			return;
		}
		LP_DoorPendingOffer.RemoveOffer(offer);
		
		if (!accept)
		{
			string buyerRefuseName = JobIdentityManager.GetInstance().GetDisplayNameOrFallback(
				buyerUID, GetGame().GetPlayerManager().GetPlayerName(buyerId));
			JobManager.GetInstance().NotifyPlayerChat(offer.m_SellerId,
				string.Format("[Porte] %1 a refuse la proposition.", buyerRefuseName));
			JobManager.GetInstance().NotifyPlayerChat(buyerId,
				"[Porte] Vous avez refuse la proposition.");
			return;
		}
		
		int balance = CapsuleEconomyManager.GetInstance().GetCapsules(buyerUID);
		if (balance < offer.m_Price)
		{
			JobManager.GetInstance().NotifyPlayerChat(buyerId, "[Porte] Solde insuffisant.");
			JobManager.GetInstance().NotifyPlayerChat(offer.m_SellerId,
				"[Porte] L acheteur n a pas assez de capsules.");
			return;
		}
		
		CapsuleEconomyManager.GetInstance().AddCapsules(buyerUID, -offer.m_Price);
		
		int sellerGain = 0;
		if (offer.m_IsResell)
			sellerGain = offer.m_Price;
		else
			sellerGain = offer.m_Price - LP_DoorManager.DOOR_BASE_COST;
		if (sellerGain < 0) sellerGain = 0;
		if (sellerGain > 0)
			CapsuleEconomyManager.GetInstance().AddCapsules(offer.m_SellerUID, sellerGain);
		
		// Transfert / creation - utilise le RplId cache dans l offre
		string buyerName = GetGame().GetPlayerManager().GetPlayerName(buyerId);
		string buyerRpName = JobIdentityManager.GetInstance().GetDisplayNameOrFallback(buyerUID, buyerName);
		string sellerName = GetGame().GetPlayerManager().GetPlayerName(offer.m_SellerId);
		string sellerRpName = JobIdentityManager.GetInstance().GetDisplayNameOrFallback(offer.m_SellerUID, sellerName);
		RplId offerDoorRplId = offer.GetDoorRplId();
		
		// Recupere l entite porte (pour SyncDoorComponent apres modif)
		IEntity doorEntity = null;
		RplComponent doorRpl = RplComponent.Cast(Replication.FindItem(offerDoorRplId));
		if (doorRpl) doorEntity = doorRpl.GetEntity();
		
		if (offer.m_IsResell)
		{
			LP_DoorData existing = LP_DoorManager.GetInstance().GetDoorByRplId(offerDoorRplId);
			if (existing)
			{
				LP_DoorManager.GetInstance().TransferDoor(existing, buyerUID, buyerRpName);
				LP_DoorManager.GetInstance().SyncDoorComponentByEntity(doorEntity, existing);
			}
		}
		else
		{
			// Achat initial : recupere l entite pour extraire prefab + position (cle stable)
			if (doorEntity)
			{
				LP_DoorData newDoor = LP_DoorManager.GetInstance().PurchaseDoor(doorEntity, offerDoorRplId, buyerUID, buyerRpName, offer.m_Price);
				LP_DoorManager.GetInstance().SyncDoorComponentByEntity(doorEntity, newDoor);
			}
		}
		
		JobManager.GetInstance().NotifyPlayerChat(buyerId,
			string.Format("[Porte] Acces achete pour %1 capsules.", offer.m_Price.ToString()));
		JobManager.GetInstance().NotifyPlayerChat(offer.m_SellerId,
			string.Format("[Porte] %1 a accepte la vente. Vous avez gagne %2 capsules.",
				buyerRpName, sellerGain.ToString()));
	}
	
	// ============ LOCK / UNLOCK ============
	
	void ClientAskLockLpDoor(RplId doorRplId, bool lock)
	{
		Rpc(RpcAsk_LockLpDoor, doorRplId, lock);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_LockLpDoor(RplId doorRplId, bool lock)
	{
		if (!Replication.IsServer()) return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "") return;
		
		LP_DoorData door = LP_DoorManager.GetInstance().GetDoorByRplId(doorRplId);
		if (!door)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[Porte] Cette porte n a pas de proprietaire.");
			return;
		}
		if (!door.CanUseDoor(uid))
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[Porte] Vous n avez pas l acces a cette porte.");
			return;
		}
		
		RplComponent rpl = RplComponent.Cast(Replication.FindItem(doorRplId));
		if (!rpl) return;
		IEntity doorEntity = rpl.GetEntity();
		if (!doorEntity) return;
		LP_DoorAccessComponent accessComp = LP_DoorAccessComponent.Cast(
			doorEntity.FindComponent(LP_DoorAccessComponent));
		if (!accessComp)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[Porte] Cette porte n a pas de composant d acces.");
			return;
		}
		accessComp.ServerSetLocked(lock);
		
		if (lock) JobManager.GetInstance().NotifyPlayerChat(playerId, "[Porte] Verrouillee.");
		else JobManager.GetInstance().NotifyPlayerChat(playerId, "[Porte] Deverrouillee.");
	}
	
	// ============ GESTION DU CODE (PROPRIO) ============
	
	void ClientAskLpDoorCodeInfo(RplId doorRplId)
	{
		Rpc(RpcAsk_LpDoorCodeInfo, doorRplId);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_LpDoorCodeInfo(RplId doorRplId)
	{
		if (!Replication.IsServer()) return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "") return;
		
		LP_DoorData door = LP_DoorManager.GetInstance().GetDoorByRplId(doorRplId);
		if (!door || !door.IsOwner(uid)) return;
		
		Rpc(RpcDo_LpDoorCodeInfo, door.m_ShareCode);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_LpDoorCodeInfo(string code)
	{
		LP_DoorCodeMenu menu = LP_DoorCodeMenu.GetOpenMenu();
		if (menu) menu.DisplayCurrentCode(code);
	}
	
	void ClientAskSetLpDoorCode(RplId doorRplId, string newCode)
	{
		Rpc(RpcAsk_SetLpDoorCode, doorRplId, newCode);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_SetLpDoorCode(RplId doorRplId, string newCode)
	{
		if (!Replication.IsServer()) return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "") return;
		
		LP_DoorData door = LP_DoorManager.GetInstance().GetDoorByRplId(doorRplId);
		if (!door || !door.IsOwner(uid))
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[Porte] Vous n etes pas proprietaire.");
			return;
		}
		
		LP_DoorManager.GetInstance().SetDoorCode(door, newCode);
		
		// Sync composant : le code change reset les joueurs connus
		RplComponent doorRplComp = RplComponent.Cast(Replication.FindItem(doorRplId));
		if (doorRplComp)
			LP_DoorManager.GetInstance().SyncDoorComponentByEntity(doorRplComp.GetEntity(), door);
	}
	
	// ============ ENTREE DE CODE (NON-PROPRIO) ============
	
	void ClientAskTryLpDoorCode(RplId doorRplId, string code)
	{
		Rpc(RpcAsk_TryLpDoorCode, doorRplId, code);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_TryLpDoorCode(RplId doorRplId, string code)
	{
		if (!Replication.IsServer()) return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "") return;
		
		LP_DoorData door = LP_DoorManager.GetInstance().GetDoorByRplId(doorRplId);
		if (!door)
		{
			Rpc(RpcDo_TryLpDoorCodeResult, 3);
			return;
		}
		if (door.m_ShareCode == "")
		{
			Rpc(RpcDo_TryLpDoorCodeResult, 2);
			return;
		}
		if (LP_DoorManager.GetInstance().TryEnterCode(door, uid, code))
		{
			// Sync composant : le joueur est ajoute a la whitelist
			RplComponent tryDoorRplComp = RplComponent.Cast(Replication.FindItem(doorRplId));
			if (tryDoorRplComp)
				LP_DoorManager.GetInstance().SyncDoorComponentByEntity(tryDoorRplComp.GetEntity(), door);
			Rpc(RpcDo_TryLpDoorCodeResult, 0);
		}
		else
			Rpc(RpcDo_TryLpDoorCodeResult, 1);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_TryLpDoorCodeResult(int result)
	{
		LP_DoorEnterCodeMenu menu = LP_DoorEnterCodeMenu.GetOpenMenu();
		if (menu) menu.OnValidationResult(result);
	}
	
	// ============ ADMIN : RESET PORTE ============
	
	void ClientAskAdminResetDoor(RplId doorRplId)
	{
		Rpc(RpcAsk_AdminResetDoor, doorRplId);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_AdminResetDoor(RplId doorRplId)
	{
		if (!Replication.IsServer()) return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		string uid = JobManager.GetInstance().GetPersistentUID(playerId);
		if (uid == "") return;
		
		// Double check admin cote serveur (authoritative)
		if (!JobAdminManager.GetInstance().IsAdmin(uid))
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[Admin] Vous n etes pas admin.");
			return;
		}
		
		LP_DoorData door = LP_DoorManager.GetInstance().GetDoorByRplId(doorRplId);
		if (!door)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[Admin] Cette porte n a pas de proprietaire.");
			return;
		}
		
		string oldOwnerName = door.m_OwnerDisplayName;
		
		// Recupere l entite porte pour resync composant apres suppression
		IEntity doorEntity = null;
		RplComponent doorRplComp = RplComponent.Cast(Replication.FindItem(doorRplId));
		if (doorRplComp) doorEntity = doorRplComp.GetEntity();
		
		// Supprime la porte du manager (efface persistance + cache runtime)
		LP_DoorManager.GetInstance().RemoveDoor(door);
		
		// Deverrouille + reset composant sur l entite (m_HasOwner=false, m_OwnerPlayerId=-1, m_KnownPlayerIdsPacked="")
		if (doorEntity)
		{
			LP_DoorAccessComponent access = LP_DoorAccessComponent.Cast(
				doorEntity.FindComponent(LP_DoorAccessComponent));
			if (access)
			{
				access.ServerSetLocked(false);
				access.ServerSetRaidInProgress(false);
			}
			// Sync composant avec door=null -> reset m_HasOwner, m_OwnerPlayerId, m_KnownPlayerIdsPacked
			LP_DoorManager.GetInstance().SyncDoorComponentByEntity(doorEntity, null);
		}
		
		JobManager.GetInstance().NotifyPlayerChat(playerId,
			string.Format("[Admin] Porte reset avec succes (ancien proprio : %1). Vendable a nouveau.",
				oldOwnerName));
		Print(string.Format("[LP_DoorAdmin] playerId=%1 (uid=%2) a reset la porte de %3",
			playerId, uid, oldOwnerName), LogLevel.NORMAL);
	}
	
	//------------------------------------------------------------------------------------------------
	// ============================================================
	// ================  PERQUISITION POLICIERE  ===================
	// ============================================================
	//------------------------------------------------------------------------------------------------
	
	// Client -> Serveur : demande de demarrage d une perquisition
	void ClientAskStartPoliceRaid(RplId doorRplId)
	{
		Rpc(RpcAsk_StartPoliceRaid, doorRplId);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_StartPoliceRaid(RplId doorRplId)
	{
		if (!Replication.IsServer()) return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		
		int result = LP_PoliceRaidManager.GetInstance().TryStartRaid(playerId, doorRplId);
		
		// Envoie un feedback au declencheur
		string msg = "";
		if (result == 0) msg = "[Perquisition] Operation demarree - restez a proximite 1 minute.";
		else if (result == 1) msg = "[Perquisition] Une perquisition est deja en cours sur cette porte.";
		else if (result == 2)
		{
			msg = string.Format("[Perquisition] Il faut au moins %1 policier/militaire a moins de 10m.",
				LP_PoliceRaidManager.MIN_OFFICERS.ToString());
		}
		else if (result == 3) msg = "[Perquisition] Il vous faut un belier dans votre inventaire.";
		else if (result == 4) msg = "[Perquisition] Cette porte n a pas de proprietaire.";
		else msg = "[Perquisition] Erreur.";
		
		JobManager.GetInstance().NotifyPlayerChat(playerId, msg);
	}
	
	// Serveur -> client : affiche le HUD
	void LP_ServerSendShowRaidHud(int remainingMs)
	{
		Rpc(LP_RpcDo_ShowRaidHud, remainingMs);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void LP_RpcDo_ShowRaidHud(int remainingMs)
	{
		LP_PoliceRaidHudManager.GetInstance().Show(remainingMs);
	}
	
	// Serveur -> client : cache le HUD
	void LP_ServerSendHideRaidHud()
	{
		Rpc(LP_RpcDo_HideRaidHud);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void LP_RpcDo_HideRaidHud()
	{
		LP_PoliceRaidHudManager.GetInstance().Hide();
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== SYSTEME DE PECHE =====
	// Etats locaux client (utilises par les UserActions pour la visibilite)
	//------------------------------------------------------------------------------------------------
	protected bool m_ClientFishingActive = false;
	protected bool m_ClientFishingBiting = false;
	
	bool IsFishingActive() { return m_ClientFishingActive; }
	bool IsFishingBiting() { return m_ClientFishingBiting; }
	
	//------------------------------------------------------------------------------------------------
	// Client -> serveur : demande de demarrer une session de peche
	//------------------------------------------------------------------------------------------------
	void ClientAskStartFishing()
	{
		Rpc(RpcAsk_StartFishing);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_StartFishing()
	{
		if (!Replication.IsServer()) return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		if (playerId <= 0) return;
		IEntity character = pc.GetControlledEntity();
		if (!character) return;
		
		Print(string.Format("[LP_Fishing] RPC StartFishing recu pour joueur %1", playerId.ToString()),
			LogLevel.NORMAL);
		
		int result = LP_FishingManager.GetInstance().StartSession(playerId, character);
		string msg = "";
		switch (result)
		{
			case 0: return; // OK, notif deja envoyee par le manager
			case 1: msg = "Vous etes deja en train de pecher."; break;
			case 2: msg = "Il vous faut une canne a peche dans votre inventaire."; break;
			case 3: msg = "Il vous faut au moins 1 asticot."; break;
			case 5:
			{
				int cdRemaining = LP_FishingManager.GetInstance().GetCooldownRemaining(playerId);
				int mm = cdRemaining / 60;
				int ss = cdRemaining - (mm * 60);
				string sec = ss.ToString();
				if (ss < 10) sec = "0" + sec;
				msg = string.Format("Vous devez attendre encore %1min %2s avant de pouvoir repecher.",
					mm.ToString(), sec);
				break;
			}
			default: msg = "Erreur inventaire."; break;
		}
		JobManager.GetInstance().NotifyPlayerChat(playerId, "[Peche] " + msg);
	}
	
	//------------------------------------------------------------------------------------------------
	// Client -> serveur : ferrer le poisson (fenetre 3s)
	//------------------------------------------------------------------------------------------------
	void ClientAskFishingHook()
	{
		Rpc(RpcAsk_FishingHook);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_FishingHook()
	{
		if (!Replication.IsServer()) return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		if (playerId <= 0) return;
		LP_FishingManager.GetInstance().ServerHookAttempt(playerId);
	}
	
	//------------------------------------------------------------------------------------------------
	// Serveur -> client : met a jour l etat local (active/biting)
	//------------------------------------------------------------------------------------------------
	void ServerFishingSetState(bool active, bool biting)
	{
		Rpc(RpcDo_FishingSetState, active, biting);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_FishingSetState(bool active, bool biting)
	{
		m_ClientFishingActive = active;
		m_ClientFishingBiting = biting;
	}
	
	//------------------------------------------------------------------------------------------------
	// Serveur -> client : push le HUD (temps restant + poissons + biting)
	//------------------------------------------------------------------------------------------------
	void ServerFishingSendHudUpdate(int secondsRemaining, int fishCaught, bool biting)
	{
		Rpc(RpcDo_FishingHudUpdate, secondsRemaining, fishCaught, biting);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_FishingHudUpdate(int secondsRemaining, int fishCaught, bool biting)
	{
		LP_FishingHudManager.GetInstance().Show(secondsRemaining, fishCaught, biting);
	}
	
	//------------------------------------------------------------------------------------------------
	// Serveur -> client : cache le HUD (fin de session)
	//------------------------------------------------------------------------------------------------
	void ServerFishingHideHud()
	{
		Rpc(RpcDo_FishingHideHud);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_FishingHideHud()
	{
		LP_FishingHudManager.GetInstance().Hide();
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== SYSTEME DE CRAFT EPICERIE =====
	//------------------------------------------------------------------------------------------------
	
	//------------------------------------------------------------------------------------------------
	// Client -> serveur : ajoute une recette a la file d attente
	//------------------------------------------------------------------------------------------------
	void ClientAskEpicerieCraftAdd(int recipeId)
	{
		Rpc(RpcAsk_EpicerieCraftAdd, recipeId);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_EpicerieCraftAdd(int recipeId)
	{
		if (!Replication.IsServer()) return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		if (playerId <= 0) return;
		IEntity character = pc.GetControlledEntity();
		if (!character) return;
		
		int result = LP_EpicerieCraftManager.GetInstance().AddToQueue(playerId, character, recipeId);
		string msg = "";
		switch (result)
		{
			case 0: return; // OK, la file push l update via RPC
			case 1: msg = "Vous devez etre Epicier pour crafter."; break;
			case 2: msg = "Recette introuvable."; break;
			case 3: msg = "Il vous manque des ingredients."; break;
			default: msg = "Erreur inventaire."; break;
		}
		JobManager.GetInstance().NotifyPlayerChat(playerId, "[Craft] " + msg);
	}
	
	//------------------------------------------------------------------------------------------------
	// Client -> serveur : recupere un item termine de la file
	//------------------------------------------------------------------------------------------------
	void ClientAskEpicerieCraftCollect(int entryId)
	{
		Rpc(RpcAsk_EpicerieCraftCollect, entryId);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_EpicerieCraftCollect(int entryId)
	{
		if (!Replication.IsServer()) return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		if (playerId <= 0) return;
		IEntity character = pc.GetControlledEntity();
		if (!character) return;
		
		int result = LP_EpicerieCraftManager.GetInstance().CollectFromQueue(playerId, character, entryId);
		string msg = "";
		switch (result)
		{
			case 0: return; // OK
			case 1: msg = "Cette commande n existe plus."; break;
			case 2: msg = "Le craft n est pas encore termine."; break;
			default: msg = "Erreur inventaire, item non recupere."; break;
		}
		JobManager.GetInstance().NotifyPlayerChat(playerId, "[Craft] " + msg);
	}
	
	//------------------------------------------------------------------------------------------------
	// Client -> serveur : demande l etat actuel de la file (quand le menu s ouvre)
	//------------------------------------------------------------------------------------------------
	void ClientAskEpicerieCraftQueueRefresh()
	{
		Rpc(RpcAsk_EpicerieCraftQueueRefresh);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_EpicerieCraftQueueRefresh()
	{
		if (!Replication.IsServer()) return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		if (playerId <= 0) return;
		
		array<int> entryIds = new array<int>();
		array<int> recipeIds = new array<int>();
		array<int> secondsRem = new array<int>();
		LP_EpicerieCraftManager.GetInstance().GetQueueSnapshot(playerId, entryIds, recipeIds, secondsRem);
		
		ServerEpicerieCraftPushQueue(entryIds, recipeIds, secondsRem);
	}
	
	//------------------------------------------------------------------------------------------------
	// Serveur -> client : push l etat courant de la file
	//------------------------------------------------------------------------------------------------
	void ServerEpicerieCraftPushQueue(array<int> entryIds, array<int> recipeIds, array<int> secondsRem)
	{
		Rpc(RpcDo_EpicerieCraftPushQueue, entryIds, recipeIds, secondsRem);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_EpicerieCraftPushQueue(array<int> entryIds, array<int> recipeIds, array<int> secondsRem)
	{
		LP_EpicerieCraftMenu menu = LP_EpicerieCraftMenu.GetOpenMenu();
		if (menu)
			menu.UpdateQueue(entryIds, recipeIds, secondsRem);
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== SYSTEME DE CRAFT BUCHERON =====
	//------------------------------------------------------------------------------------------------
	
	void ClientAskBucheronCraftAdd(int recipeId)
	{
		Rpc(RpcAsk_BucheronCraftAdd, recipeId);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_BucheronCraftAdd(int recipeId)
	{
		if (!Replication.IsServer()) return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		if (playerId <= 0) return;
		IEntity character = pc.GetControlledEntity();
		if (!character) return;
		
		int result = LP_BucheronCraftManager.GetInstance().AddToQueue(playerId, character, recipeId);
		string msg = "";
		switch (result)
		{
			case 0: return;
			case 1: msg = "Vous devez etre Bucheron pour crafter."; break;
			case 2: msg = "Recette introuvable."; break;
			case 3: msg = "Il vous manque des ingredients."; break;
			default: msg = "Erreur inventaire."; break;
		}
		JobManager.GetInstance().NotifyPlayerChat(playerId, "[Craft] " + msg);
	}
	
	//------------------------------------------------------------------------------------------------
	void ClientAskBucheronCraftCollect(int entryId)
	{
		Rpc(RpcAsk_BucheronCraftCollect, entryId);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_BucheronCraftCollect(int entryId)
	{
		if (!Replication.IsServer()) return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		if (playerId <= 0) return;
		IEntity character = pc.GetControlledEntity();
		if (!character) return;
		
		int result = LP_BucheronCraftManager.GetInstance().CollectFromQueue(playerId, character, entryId);
		string msg = "";
		switch (result)
		{
			case 0: return;
			case 1: msg = "Cette commande n existe plus."; break;
			case 2: msg = "Le craft n est pas encore termine."; break;
			default: msg = "Erreur inventaire, item non recupere."; break;
		}
		JobManager.GetInstance().NotifyPlayerChat(playerId, "[Craft] " + msg);
	}
	
	//------------------------------------------------------------------------------------------------
	void ClientAskBucheronCraftQueueRefresh()
	{
		Rpc(RpcAsk_BucheronCraftQueueRefresh);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_BucheronCraftQueueRefresh()
	{
		if (!Replication.IsServer()) return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		if (playerId <= 0) return;
		
		array<int> entryIds = new array<int>();
		array<int> recipeIds = new array<int>();
		array<int> secondsRem = new array<int>();
		LP_BucheronCraftManager.GetInstance().GetQueueSnapshot(playerId, entryIds, recipeIds, secondsRem);
		
		ServerBucheronCraftPushQueue(entryIds, recipeIds, secondsRem);
	}
	
	//------------------------------------------------------------------------------------------------
	void ServerBucheronCraftPushQueue(array<int> entryIds, array<int> recipeIds, array<int> secondsRem)
	{
		Rpc(RpcDo_BucheronCraftPushQueue, entryIds, recipeIds, secondsRem);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_BucheronCraftPushQueue(array<int> entryIds, array<int> recipeIds, array<int> secondsRem)
	{
		LP_BucheronCraftMenu menu = LP_BucheronCraftMenu.GetOpenMenu();
		if (menu)
			menu.UpdateQueue(entryIds, recipeIds, secondsRem);
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== VERIFICATION PROPRIETE AVOCAT (LECTURE SEULE) =====
	//------------------------------------------------------------------------------------------------
	
	void ClientAskAvocatSearchProperty(string query)
	{
		Rpc(RpcAsk_AvocatSearchProperty, query);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_AvocatSearchProperty(string query)
	{
		if (!Replication.IsServer()) return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		if (playerId <= 0) return;
		IEntity character = pc.GetControlledEntity();
		if (!character) return;
		
		// Server-side : verifie que le joueur est bien AVOCAT
		JobCharacterJobComponent jcjc = JobCharacterJobComponent.Cast(
			character.FindComponent(JobCharacterJobComponent));
		if (!jcjc || jcjc.GetJob() != EJobType.AVOCAT)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[AVOCAT] Vous devez etre Avocat pour utiliser ce service.");
			return;
		}
		
		// Nettoyage query
		query.TrimInPlace();
		query.ToLower();
		if (query.Length() < 2) return;
		
		// Parcours toutes les portes et filtre par nom / prenom qui contient la query
		array<string> outNames = new array<string>();
		array<string> outCoords = new array<string>();
		array<string> outDates = new array<string>();
		array<string> outDoorKeys = new array<string>();
		
		array<LP_DoorData> allDoors = LP_DoorManager.GetInstance().GetAllDoors();
		foreach (LP_DoorData door : allDoors)
		{
			if (!door || door.m_OwnerUID == "") continue;
			
			JobRpIdentity id = JobIdentityManager.GetInstance().GetIdentity(door.m_OwnerUID);
			if (!id) continue;
			
			// Match sur prenom OU nom (insensible casse)
			string firstLower = id.m_FirstName;
			string lastLower = id.m_LastName;
			firstLower.ToLower();
			lastLower.ToLower();
			
			bool matches = (firstLower.Contains(query) || lastLower.Contains(query));
			if (!matches) continue;
			
			string fullName = id.m_FirstName + " " + id.m_LastName;
			vector p = door.m_Position;
			string coordStr = string.Format("X=%1  Y=%2  Z=%3",
				p[0].ToString(), p[1].ToString(), p[2].ToString());
			string dateStr = FormatUnixDate(door.m_PurchaseUnix);
			
			outNames.Insert(fullName);
			outCoords.Insert(coordStr);
			outDates.Insert(dateStr);
			outDoorKeys.Insert(door.m_DoorKey);
		}
		
		Print(string.Format("[LP_Avocat] Joueur %1 a cherche '%2' - %3 resultats",
			playerId.ToString(), query, outNames.Count().ToString()), LogLevel.NORMAL);
		
		ServerAvocatSendResults(outNames, outCoords, outDates, outDoorKeys);
	}
	
	//------------------------------------------------------------------------------------------------
	// Format un timestamp unix en date lisible relative : "il y a 3 jours" / "aujourd hui" / "hier"
	//------------------------------------------------------------------------------------------------
	protected string FormatUnixDate(int unixTime)
	{
		if (unixTime <= 0) return "-";
		int now = System.GetUnixTime();
		int diff = now - unixTime;
		if (diff < 0) return "recent";
		
		int days = diff / 86400;
		if (days == 0) return "aujourd hui";
		if (days == 1) return "hier";
		if (days < 7) return string.Format("il y a %1 jours", days.ToString());
		if (days < 30)
		{
			int weeks = days / 7;
			if (weeks == 1) return "il y a 1 semaine";
			return string.Format("il y a %1 semaines", weeks.ToString());
		}
		if (days < 365)
		{
			int months = days / 30;
			if (months == 1) return "il y a 1 mois";
			return string.Format("il y a %1 mois", months.ToString());
		}
		int years = days / 365;
		if (years == 1) return "il y a 1 an";
		return string.Format("il y a %1 ans", years.ToString());
	}
	
	//------------------------------------------------------------------------------------------------
	void ServerAvocatSendResults(array<string> names, array<string> coords, array<string> dates,
		array<string> doorKeys)
	{
		Rpc(RpcDo_AvocatReceiveResults, names, coords, dates, doorKeys);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_AvocatReceiveResults(array<string> names, array<string> coords, array<string> dates,
		array<string> doorKeys)
	{
		LP_AvocatCheckPropertyMenu menu = LP_AvocatCheckPropertyMenu.GetOpenMenu();
		if (menu)
			menu.ShowSearchResults(names, coords, dates, doorKeys);
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== REMORQUAGE DE VEHICULE (METIERS MECANICIEN et FOURRIERE) =====
	//------------------------------------------------------------------------------------------------

	void ClientAskTowVehicle(RplId truckRplId)
	{
		Rpc(RpcAsk_TowVehicle, truckRplId);
	}

	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_TowVehicle(RplId truckRplId)
	{
		if (!Replication.IsServer()) return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		if (playerId <= 0) return;
		IEntity character = pc.GetControlledEntity();
		if (!character) return;

		// Server-side : verifie que le joueur est bien MECANICIEN ou FOURRIERE
		JobCharacterJobComponent jcjc = JobCharacterJobComponent.Cast(
			character.FindComponent(JobCharacterJobComponent));
		EJobType callerJob = EJobType.NONE;
		if (jcjc)
			callerJob = jcjc.GetJob();
		if (callerJob != EJobType.MECANICIEN && callerJob != EJobType.FOURRIERE)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[DEPANNEUSE] Vous devez etre Mecanicien ou Fourriere pour utiliser la depanneuse.");
			return;
		}

		// Resout la depanneuse via son RplId
		RplComponent rpl = RplComponent.Cast(Replication.FindItem(truckRplId));
		if (!rpl)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[DEPANNEUSE] Depanneuse introuvable.");
			return;
		}
		IEntity truck = rpl.GetEntity();
		if (!truck) return;

		// Verifie que la depanneuse ne remorque pas deja un vehicule
		LP_TowManager mgr = LP_TowManager.GetInstance();
		if (mgr.IsTruckTowing(truck))
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[DEPANNEUSE] Cette depanneuse remorque deja un vehicule. Descendez-le d abord.");
			return;
		}

		// Cherche le vehicule le plus proche
		IEntity vehicle = mgr.FindNearestVehicle(truck);
		if (!vehicle)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[DEPANNEUSE] Aucun vehicule a moins de 5m de la depanneuse.");
			return;
		}

		int result = mgr.RegisterTow(truck, vehicle);
		if (result == 0)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[DEPANNEUSE] Vehicule remorque avec succes.");
		}
		else if (result == 1)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[DEPANNEUSE] Cette depanneuse remorque deja un vehicule.");
		}
		else if (result == 2)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[DEPANNEUSE] Ce vehicule est deja remorque par une autre depanneuse.");
		}
		else
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[DEPANNEUSE] Erreur lors du remorquage.");
		}
	}

	//------------------------------------------------------------------------------------------------
	void ClientAskReleaseTowedVehicle(RplId truckRplId)
	{
		Rpc(RpcAsk_ReleaseTowedVehicle, truckRplId);
	}

	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_ReleaseTowedVehicle(RplId truckRplId)
	{
		if (!Replication.IsServer()) return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		if (playerId <= 0) return;
		IEntity character = pc.GetControlledEntity();
		if (!character) return;

		JobCharacterJobComponent jcjc = JobCharacterJobComponent.Cast(
			character.FindComponent(JobCharacterJobComponent));
		EJobType callerJob = EJobType.NONE;
		if (jcjc)
			callerJob = jcjc.GetJob();
		if (callerJob != EJobType.MECANICIEN && callerJob != EJobType.FOURRIERE)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[DEPANNEUSE] Vous devez etre Mecanicien ou Fourriere pour utiliser la depanneuse.");
			return;
		}
		
		RplComponent rpl = RplComponent.Cast(Replication.FindItem(truckRplId));
		if (!rpl) return;
		IEntity truck = rpl.GetEntity();
		if (!truck) return;
		
		int result = LP_TowManager.GetInstance().ReleaseTow(truck);
		if (result == 0)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[DEPANNEUSE] Vehicule descendu derriere la depanneuse.");
		}
		else if (result == 1)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[DEPANNEUSE] Cette depanneuse ne remorque aucun vehicule.");
		}
		else
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[DEPANNEUSE] Erreur lors de la descente du vehicule.");
		}
	}

	//------------------------------------------------------------------------------------------------
	// ===== CONTROLE ALCOOL (POLICIER / MILITAIRE) =====
	//------------------------------------------------------------------------------------------------

	void ClientAskAlcoholControl(int targetPlayerId)
	{
		// Ouvre le menu cote client immediatement (affichage "..." en attendant la reponse)
		LP_AlcoholControlMenu menu = LP_AlcoholControlMenu.Cast(
			GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.LP_AlcoholControlMenu));
		if (menu)
		{
			// Nom RP (prenom + nom) via JobIdentityManager, fallback playername si pas d identite RP
			string targetName = JobIdentityManager.GetInstance().Client_GetDisplayName(targetPlayerId);
			menu.Initialize(targetPlayerId, targetName);
		}

		Rpc(RpcAsk_AlcoholControl, targetPlayerId);
	}

	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_AlcoholControl(int targetPlayerId)
	{
		if (!Replication.IsServer()) return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		if (playerId <= 0) return;
		IEntity character = pc.GetControlledEntity();
		if (!character) return;

		// Anti-cheat : verifie POLICIER ou MILITAIRE
		JobCharacterJobComponent jcjc = JobCharacterJobComponent.Cast(
			character.FindComponent(JobCharacterJobComponent));
		if (!jcjc) return;
		EJobType job = jcjc.GetJob();
		if (job != EJobType.POLICIER && job != EJobType.MILITAIRE)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[CONTROLE ALCOOL] Reserve aux forces de l ordre.");
			return;
		}

		// Recupere le taux d alcool de la cible
		float alcoholLevel = LP_AlcoholManager.GetInstance().GetAlcohol(targetPlayerId);

		// Recupere le nom RP de la cible (prenom + nom via JobIdentityManager)
		// Fallback playername si le joueur n a pas d identite RP creee
		string targetName = JobIdentityManager.GetInstance().GetDisplayNameByPlayerId(targetPlayerId);

		Print(string.Format("[LP_AlcoholControl] Player %1 (%2) controle Player %3 : taux=%4%%",
			playerId.ToString(), JobData.GetJobLabel(job), targetPlayerId.ToString(),
			alcoholLevel.ToString()), LogLevel.NORMAL);

		Rpc(RpcDo_AlcoholControlResult, alcoholLevel, targetName);
	}

	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_AlcoholControlResult(float alcoholLevel, string targetName)
	{
		LP_AlcoholControlMenu menu = LP_AlcoholControlMenu.GetOpenMenu();
		if (menu) menu.DisplayAlcoholLevel(alcoholLevel, targetName);
	}

	//------------------------------------------------------------------------------------------------
	// ===== CONTROLE CANNABIS (POLICIER / MILITAIRE) =====
	//------------------------------------------------------------------------------------------------

	void ClientAskCannabisControl(int targetPlayerId)
	{
		LP_CannabisControlMenu menu = LP_CannabisControlMenu.Cast(
			GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.LP_CannabisControlMenu));
		if (menu)
		{
			string targetName = JobIdentityManager.GetInstance().Client_GetDisplayName(targetPlayerId);
			menu.Initialize(targetPlayerId, targetName);
		}

		Rpc(RpcAsk_CannabisControl, targetPlayerId);
	}

	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_CannabisControl(int targetPlayerId)
	{
		if (!Replication.IsServer()) return;
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int playerId = pc.GetPlayerId();
		if (playerId <= 0) return;
		IEntity character = pc.GetControlledEntity();
		if (!character) return;

		JobCharacterJobComponent jcjc = JobCharacterJobComponent.Cast(
			character.FindComponent(JobCharacterJobComponent));
		if (!jcjc) return;
		EJobType job = jcjc.GetJob();
		if (job != EJobType.POLICIER && job != EJobType.MILITAIRE)
		{
			JobManager.GetInstance().NotifyPlayerChat(playerId,
				"[CONTROLE CANNABIS] Reserve aux forces de l ordre.");
			return;
		}

		float thcLevel = LP_CannabisManager.GetInstance().GetThc(targetPlayerId);
		string targetName = JobIdentityManager.GetInstance().GetDisplayNameByPlayerId(targetPlayerId);

		Print(string.Format("[LP_CannabisControl] Player %1 (%2) controle Player %3 : taux=%4%%",
			playerId.ToString(), JobData.GetJobLabel(job), targetPlayerId.ToString(),
			thcLevel.ToString()), LogLevel.NORMAL);

		Rpc(RpcDo_CannabisControlResult, thcLevel, targetName);
	}

	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	void RpcDo_CannabisControlResult(float thcLevel, string targetName)
	{
		LP_CannabisControlMenu menu = LP_CannabisControlMenu.GetOpenMenu();
		if (menu) menu.DisplayThcLevel(thcLevel, targetName);
	}
}
