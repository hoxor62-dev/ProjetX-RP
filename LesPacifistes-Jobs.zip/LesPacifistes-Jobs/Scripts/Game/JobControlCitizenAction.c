//------------------------------------------------------------------------------------------------
// JobControlCitizenAction.c
// Action "F - Controler le citoyen" (flic / militaire uniquement, distance max 2m)
// A placer sur les joueurs via le prefab character (ou via modification vanilla)
//
// Limitation: cette action doit etre attachee a l'entity Character du joueur pour etre visible
// quand on regarde un joueur. En pratique, on utilise le prefab character mod ou un override
// du prefab vanilla Character.et.
//------------------------------------------------------------------------------------------------

class JobControlCitizenAction : ScriptedUserAction
{
	const float MAX_DISTANCE = 2.0; // 2 metres
	
	//------------------------------------------------------------------------------------------------
	override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
	{
		if (!pOwnerEntity || !pUserEntity)
			return;
		
		// pOwnerEntity = joueur cible, pUserEntity = flic/militaire qui appuie sur F
		
		// Securite: seul le joueur local doit ouvrir le menu (sinon ouvre chez tous)
		PlayerController localPC = GetGame().GetPlayerController();
		if (!localPC)
			return;
		IEntity localEntity = localPC.GetControlledEntity();
		if (localEntity != pUserEntity)
			return;
		
		// Recupere le playerId de la cible (OwnerEntity = character de la cible)
		int targetPlayerId = GetGame().GetPlayerManager().GetPlayerIdFromControlledEntity(pOwnerEntity);
		if (targetPlayerId <= 0)
			return;
		
		// Ouvre le menu de controle
		JobControlMenu menu = JobControlMenu.Cast(
			GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.JobControlMenu));
		if (menu)
			menu.Initialize(targetPlayerId);
	}
	
	//------------------------------------------------------------------------------------------------
	// Visible uniquement si le joueur qui regarde est flic ou militaire
	//------------------------------------------------------------------------------------------------
	override bool CanBeShownScript(IEntity user)
	{
		if (!user)
			return false;
		
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc)
			return false;
		
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc)
			return false;
		
		EJobType job = jpc.GetJob();
		return (job == EJobType.POLICIER || job == EJobType.MILITAIRE);
	}
	
	//------------------------------------------------------------------------------------------------
	// Distance max 2m
	//------------------------------------------------------------------------------------------------
	override bool CanBePerformedScript(IEntity user)
	{
		if (!user)
			return false;
		
		IEntity owner = GetOwner();
		if (!owner)
			return false;
		
		float dist = vector.Distance(user.GetOrigin(), owner.GetOrigin());
		return dist <= MAX_DISTANCE;
	}
}
