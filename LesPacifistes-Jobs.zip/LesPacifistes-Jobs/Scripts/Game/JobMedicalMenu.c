//------------------------------------------------------------------------------------------------
// JobMedicalMenu.c
//
// Menu "Fiche medicale patient" pour les medecins (EMS).
// Accessible via UserAction sur un ordinateur d hopital.
//
// Structure (6 onglets) :
//   1. Identite   (nom RP, DDN, sexe, n dossier, groupe sanguin)
//   2. Sante      (Vie/Sang auto-sync + 7 constantes manuelles + bouton Actualiser)
//   3. Infos med  (allergies, maladies, traitements)
//   4. Soins      (liste + bouton "+" ajout)
//   5. Hospit.    (liste + bouton "+" ajout)
//   6. Journal    (journal auto - lecture seule)
//------------------------------------------------------------------------------------------------

enum EMedicalMenuTab
{
	IDENTITY = 0,
	HEALTH = 1,
	MEDICAL_INFO = 2,
	SOINS = 3,
	HOSPITALIZATIONS = 4,
	JOURNAL = 5
}

class JobMedicalMenu : ChimeraMenuBase
{
	// === Widgets principaux ===
	Widget m_RootWidget;
	TextWidget m_TitleText;
	
	// Section recherche
	Widget m_SearchPanel;
	EditBoxWidget m_SearchInput;
	ButtonWidget m_BtnSearch;
	Widget m_ResultsContainer;
	TextWidget m_ResultsInfo;
	
	// Section fiche
	Widget m_FichePanel;
	TextWidget m_FicheNameText;
	TextWidget m_FicheFileNumText;
	TextWidget m_FicheUIDText;
	
	// Onglets
	ButtonWidget m_TabIdentity;
	ButtonWidget m_TabHealth;
	ButtonWidget m_TabMedInfo;
	ButtonWidget m_TabSoins;
	ButtonWidget m_TabHospit;
	ButtonWidget m_TabJournal;
	
	// Contenus par onglet
	Widget m_ContentIdentity;
	Widget m_ContentHealth;
	Widget m_ContentMedInfo;
	Widget m_ContentSoins;
	Widget m_ContentHospit;
	Widget m_ContentJournal;
	
	// Onglet Identite : DDN + sex + blood type (dropdowns par boutons)
	EditBoxWidget m_IdDobInput;
	ButtonWidget m_IdSexMale;
	ButtonWidget m_IdSexFemale;
	ButtonWidget m_IdSexOther;
	ButtonWidget m_IdBloodApos;
	ButtonWidget m_IdBloodAneg;
	ButtonWidget m_IdBloodBpos;
	ButtonWidget m_IdBloodBneg;
	ButtonWidget m_IdBloodABpos;
	ButtonWidget m_IdBloodABneg;
	ButtonWidget m_IdBloodOpos;
	ButtonWidget m_IdBloodOneg;
	ButtonWidget m_IdSaveButton;
	TextWidget m_IdCurrentSexText;
	TextWidget m_IdCurrentBloodText;
	
	// Onglet Sante : affichages + bouton actualiser + saisies manuelles
	TextWidget m_HealthLifeText;
	TextWidget m_HealthBloodText;
	TextWidget m_HealthSyncText;
	ButtonWidget m_BtnHealthRefresh;
	EditBoxWidget m_HealthFractInput;
	EditBoxWidget m_HealthHemorInput;
	EditBoxWidget m_HealthPainInput;
	EditBoxWidget m_HealthTempInput;
	EditBoxWidget m_HealthPulseInput;
	EditBoxWidget m_HealthPressInput;
	EditBoxWidget m_HealthO2Input;
	ButtonWidget m_BtnHealthSave;
	
	// Onglet Infos medicales
	EditBoxWidget m_MedAllergiesInput;
	EditBoxWidget m_MedDiseasesInput;
	EditBoxWidget m_MedTreatmentsInput;
	ButtonWidget m_BtnMedInfoSave;
	
	// Onglet Soins : liste + bouton ajout
	Widget m_SoinsList;
	ButtonWidget m_BtnAddSoin;
	
	// Onglet Hospitalisations : liste + bouton ajout
	Widget m_HospitList;
	ButtonWidget m_BtnAddHospit;
	
	// Onglet Journal : liste readonly + pagination
	Widget m_JournalList;
	ButtonWidget m_JournalPrevBtn;
	ButtonWidget m_JournalNextBtn;
	TextWidget m_JournalPageLabel;
	// Etat pagination journal
	int m_JournalPage = 0;
	const int JOURNAL_PER_PAGE = 10;
	ref array<string> m_JournalEntriesCache = new array<string>();
	
	// Popup ajout Soin
	Widget m_PopupAddSoin;
	EditBoxWidget m_PopupSoinMotif;
	EditBoxWidget m_PopupSoinDiag;
	EditBoxWidget m_PopupSoinActes;
	EditBoxWidget m_PopupSoinMeds;
	ButtonWidget m_PopupSoinOk;
	ButtonWidget m_PopupSoinCancel;
	
	// Popup ajout Hospitalisation
	Widget m_PopupAddHospit;
	EditBoxWidget m_PopupHospitChambre;
	EditBoxWidget m_PopupHospitCR;
	ButtonWidget m_PopupHospitOk;
	ButtonWidget m_PopupHospitCancel;
	
	// Popup fermer Hospitalisation (avec ordonnance)
	Widget m_PopupCloseHospit;
	TextWidget m_PopupCloseHospitInfo;
	EditBoxWidget m_PopupCloseHospitOrdo;
	ButtonWidget m_PopupCloseHospitOk;
	ButtonWidget m_PopupCloseHospitCancel;
	int m_PopupCloseHospitIndex = -1;
	
	// Retour + Fermer
	ButtonWidget m_BtnClose;
	ButtonWidget m_BtnBackToSearch;
	
	// === Etat ===
	string m_SelectedUID = "";
	string m_SelectedName = "";
	EMedicalMenuTab m_ActiveTab = EMedicalMenuTab.IDENTITY;
	int m_SelectedSex = 0;
	int m_SelectedBlood = 0;
	
	// Instance statique pour recevoir les push RPCs
	static JobMedicalMenu s_Instance;
	
	static JobMedicalMenu GetOpenMenu()
	{
		return s_Instance;
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuOpen()
	{
		super.OnMenuOpen();
		s_Instance = this;
		JobFocusHandler.ClearRegistry();
		m_RootWidget = GetRootWidget();
		if (!m_RootWidget)
			return;
		
		FindWidgets();
		AttachHandlers();
		
		ShowSearchPanel();
		if (m_TitleText)
			m_TitleText.SetText("FICHE MEDICALE PATIENT");
		if (m_ResultsInfo)
			m_ResultsInfo.SetText("Recherche par nom RP, UID ou N dossier (vide = tous les dossiers).");
		
		if (m_SearchInput)
			GetGame().GetWorkspace().SetFocusedWidget(m_SearchInput);
		
		RequestSearch("");
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuClose()
	{
		if (s_Instance == this)
			s_Instance = null;
		super.OnMenuClose();
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuUpdate(float tDelta)
	{
		super.OnMenuUpdate(tDelta);
		if (GetGame().GetInputManager().GetActionValue("MenuBack") > 0.5)
		{
			if (m_FichePanel && m_FichePanel.IsVisible())
			{
				ShowSearchPanel();
				return;
			}
			CloseMenuInternal();
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void FindWidgets()
	{
		m_TitleText = TextWidget.Cast(m_RootWidget.FindAnyWidget("TitleText"));
		m_SearchPanel = m_RootWidget.FindAnyWidget("SearchPanel");
		m_SearchInput = EditBoxWidget.Cast(m_RootWidget.FindAnyWidget("SearchInput"));
		m_BtnSearch = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnSearch"));
		m_ResultsContainer = m_RootWidget.FindAnyWidget("ResultsContainer");
		m_ResultsInfo = TextWidget.Cast(m_RootWidget.FindAnyWidget("ResultsInfo"));
		
		m_FichePanel = m_RootWidget.FindAnyWidget("FichePanel");
		m_FicheNameText = TextWidget.Cast(m_RootWidget.FindAnyWidget("FicheNameText"));
		m_FicheFileNumText = TextWidget.Cast(m_RootWidget.FindAnyWidget("FicheFileNumText"));
		m_FicheUIDText = TextWidget.Cast(m_RootWidget.FindAnyWidget("FicheUIDText"));
		
		m_TabIdentity = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("TabIdentity"));
		m_TabHealth = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("TabHealth"));
		m_TabMedInfo = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("TabMedInfo"));
		m_TabSoins = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("TabSoins"));
		m_TabHospit = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("TabHospit"));
		m_TabJournal = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("TabJournal"));
		
		m_ContentIdentity = m_RootWidget.FindAnyWidget("ContentIdentity");
		m_ContentHealth = m_RootWidget.FindAnyWidget("ContentHealth");
		m_ContentMedInfo = m_RootWidget.FindAnyWidget("ContentMedInfo");
		m_ContentSoins = m_RootWidget.FindAnyWidget("ContentSoins");
		m_ContentHospit = m_RootWidget.FindAnyWidget("ContentHospit");
		m_ContentJournal = m_RootWidget.FindAnyWidget("ContentJournal");
		
		// Identite
		m_IdDobInput = EditBoxWidget.Cast(m_RootWidget.FindAnyWidget("IdDobInput"));
		m_IdSexMale = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("IdSexMale"));
		m_IdSexFemale = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("IdSexFemale"));
		m_IdSexOther = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("IdSexOther"));
		m_IdBloodApos = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("IdBloodApos"));
		m_IdBloodAneg = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("IdBloodAneg"));
		m_IdBloodBpos = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("IdBloodBpos"));
		m_IdBloodBneg = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("IdBloodBneg"));
		m_IdBloodABpos = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("IdBloodABpos"));
		m_IdBloodABneg = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("IdBloodABneg"));
		m_IdBloodOpos = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("IdBloodOpos"));
		m_IdBloodOneg = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("IdBloodOneg"));
		m_IdSaveButton = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("IdSaveButton"));
		m_IdCurrentSexText = TextWidget.Cast(m_RootWidget.FindAnyWidget("IdCurrentSexText"));
		m_IdCurrentBloodText = TextWidget.Cast(m_RootWidget.FindAnyWidget("IdCurrentBloodText"));
		
		// Sante
		m_HealthLifeText = TextWidget.Cast(m_RootWidget.FindAnyWidget("HealthLifeText"));
		m_HealthBloodText = TextWidget.Cast(m_RootWidget.FindAnyWidget("HealthBloodText"));
		m_HealthSyncText = TextWidget.Cast(m_RootWidget.FindAnyWidget("HealthSyncText"));
		m_BtnHealthRefresh = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnHealthRefresh"));
		m_HealthFractInput = EditBoxWidget.Cast(m_RootWidget.FindAnyWidget("HealthFractInput"));
		m_HealthHemorInput = EditBoxWidget.Cast(m_RootWidget.FindAnyWidget("HealthHemorInput"));
		m_HealthPainInput = EditBoxWidget.Cast(m_RootWidget.FindAnyWidget("HealthPainInput"));
		m_HealthTempInput = EditBoxWidget.Cast(m_RootWidget.FindAnyWidget("HealthTempInput"));
		m_HealthPulseInput = EditBoxWidget.Cast(m_RootWidget.FindAnyWidget("HealthPulseInput"));
		m_HealthPressInput = EditBoxWidget.Cast(m_RootWidget.FindAnyWidget("HealthPressInput"));
		m_HealthO2Input = EditBoxWidget.Cast(m_RootWidget.FindAnyWidget("HealthO2Input"));
		m_BtnHealthSave = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnHealthSave"));
		
		// Infos medicales
		m_MedAllergiesInput = EditBoxWidget.Cast(m_RootWidget.FindAnyWidget("MedAllergiesInput"));
		m_MedDiseasesInput = EditBoxWidget.Cast(m_RootWidget.FindAnyWidget("MedDiseasesInput"));
		m_MedTreatmentsInput = EditBoxWidget.Cast(m_RootWidget.FindAnyWidget("MedTreatmentsInput"));
		m_BtnMedInfoSave = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnMedInfoSave"));
		
		// Listes
		m_SoinsList = m_RootWidget.FindAnyWidget("SoinsList");
		m_BtnAddSoin = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnAddSoin"));
		m_HospitList = m_RootWidget.FindAnyWidget("HospitList");
		m_BtnAddHospit = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnAddHospit"));
		m_JournalList = m_RootWidget.FindAnyWidget("JournalList");
		m_JournalPrevBtn = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("JournalPrevBtn"));
		m_JournalNextBtn = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("JournalNextBtn"));
		m_JournalPageLabel = TextWidget.Cast(m_RootWidget.FindAnyWidget("JournalPageLabel"));
		
		// Popup Soin
		m_PopupAddSoin = m_RootWidget.FindAnyWidget("PopupAddSoin");
		m_PopupSoinMotif = EditBoxWidget.Cast(m_RootWidget.FindAnyWidget("PopupSoinMotif"));
		m_PopupSoinDiag = EditBoxWidget.Cast(m_RootWidget.FindAnyWidget("PopupSoinDiag"));
		m_PopupSoinActes = EditBoxWidget.Cast(m_RootWidget.FindAnyWidget("PopupSoinActes"));
		m_PopupSoinMeds = EditBoxWidget.Cast(m_RootWidget.FindAnyWidget("PopupSoinMeds"));
		m_PopupSoinOk = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("PopupSoinOk"));
		m_PopupSoinCancel = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("PopupSoinCancel"));
		
		// Popup Hospit
		m_PopupAddHospit = m_RootWidget.FindAnyWidget("PopupAddHospit");
		m_PopupHospitChambre = EditBoxWidget.Cast(m_RootWidget.FindAnyWidget("PopupHospitChambre"));
		m_PopupHospitCR = EditBoxWidget.Cast(m_RootWidget.FindAnyWidget("PopupHospitCR"));
		m_PopupHospitOk = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("PopupHospitOk"));
		m_PopupHospitCancel = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("PopupHospitCancel"));
		
		// Popup Close Hospit
		m_PopupCloseHospit = m_RootWidget.FindAnyWidget("PopupCloseHospit");
		m_PopupCloseHospitInfo = TextWidget.Cast(m_RootWidget.FindAnyWidget("PopupCloseHospitInfo"));
		m_PopupCloseHospitOrdo = EditBoxWidget.Cast(m_RootWidget.FindAnyWidget("PopupCloseHospitOrdo"));
		m_PopupCloseHospitOk = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("PopupCloseHospitOk"));
		m_PopupCloseHospitCancel = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("PopupCloseHospitCancel"));
		
		// Cache tous les popups par defaut
		if (m_PopupAddSoin) m_PopupAddSoin.SetVisible(false);
		if (m_PopupAddHospit) m_PopupAddHospit.SetVisible(false);
		if (m_PopupCloseHospit) m_PopupCloseHospit.SetVisible(false);
		
		m_BtnClose = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnClose"));
		m_BtnBackToSearch = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnBackToSearch"));
	}
	
	//------------------------------------------------------------------------------------------------
	void AttachHandlers()
	{
		AttachHandler(m_BtnSearch, "search");
		AttachHandler(m_BtnClose, "close");
		AttachHandler(m_BtnBackToSearch, "back");
		
		AttachHandler(m_TabIdentity, "tab_identity");
		AttachHandler(m_TabHealth, "tab_health");
		AttachHandler(m_TabMedInfo, "tab_medinfo");
		AttachHandler(m_TabSoins, "tab_soins");
		AttachHandler(m_TabHospit, "tab_hospit");
		AttachHandler(m_TabJournal, "tab_journal");
		
		AttachHandler(m_IdSexMale, "id_sex_male");
		AttachHandler(m_IdSexFemale, "id_sex_female");
		AttachHandler(m_IdSexOther, "id_sex_other");
		AttachHandler(m_IdBloodApos, "id_blood_apos");
		AttachHandler(m_IdBloodAneg, "id_blood_aneg");
		AttachHandler(m_IdBloodBpos, "id_blood_bpos");
		AttachHandler(m_IdBloodBneg, "id_blood_bneg");
		AttachHandler(m_IdBloodABpos, "id_blood_abpos");
		AttachHandler(m_IdBloodABneg, "id_blood_abneg");
		AttachHandler(m_IdBloodOpos, "id_blood_opos");
		AttachHandler(m_IdBloodOneg, "id_blood_oneg");
		AttachHandler(m_IdSaveButton, "id_save");
		
		AttachHandler(m_BtnHealthRefresh, "health_refresh");
		AttachHandler(m_BtnHealthSave, "health_save");
		
		// Phase 3
		AttachHandler(m_BtnMedInfoSave, "medinfo_save");
		AttachHandler(m_BtnAddSoin, "add_soin");
		AttachHandler(m_BtnAddHospit, "add_hospit");
		AttachHandler(m_PopupSoinOk, "popup_soin_ok");
		AttachHandler(m_PopupSoinCancel, "popup_soin_cancel");
		AttachHandler(m_PopupHospitOk, "popup_hospit_ok");
		AttachHandler(m_PopupHospitCancel, "popup_hospit_cancel");
		AttachHandler(m_PopupCloseHospitOk, "popup_close_hospit_ok");
		AttachHandler(m_PopupCloseHospitCancel, "popup_close_hospit_cancel");
		
		AttachHandler(m_JournalPrevBtn, "journal_prev");
		AttachHandler(m_JournalNextBtn, "journal_next");
	}
	
	void AttachHandler(ButtonWidget btn, string action)
	{
		if (!btn) return;
		MedicalMenuHandler h = new MedicalMenuHandler();
		h.m_Menu = this;
		h.m_Action = action;
		btn.AddHandler(h);
		JobFocusHandler.Attach(btn);
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== NAVIGATION =====
	//------------------------------------------------------------------------------------------------
	
	void ShowSearchPanel()
	{
		if (m_SearchPanel) m_SearchPanel.SetVisible(true);
		if (m_FichePanel) m_FichePanel.SetVisible(false);
		if (m_SearchInput)
			GetGame().GetWorkspace().SetFocusedWidget(m_SearchInput);
	}
	
	void ShowFichePanel()
	{
		if (m_SearchPanel) m_SearchPanel.SetVisible(false);
		if (m_FichePanel) m_FichePanel.SetVisible(true);
		SwitchTab(EMedicalMenuTab.IDENTITY);
	}
	
	void SwitchTab(EMedicalMenuTab tab)
	{
		m_ActiveTab = tab;
		if (m_ContentIdentity) m_ContentIdentity.SetVisible(tab == EMedicalMenuTab.IDENTITY);
		if (m_ContentHealth)   m_ContentHealth.SetVisible(tab == EMedicalMenuTab.HEALTH);
		if (m_ContentMedInfo)  m_ContentMedInfo.SetVisible(tab == EMedicalMenuTab.MEDICAL_INFO);
		if (m_ContentSoins)    m_ContentSoins.SetVisible(tab == EMedicalMenuTab.SOINS);
		if (m_ContentHospit)   m_ContentHospit.SetVisible(tab == EMedicalMenuTab.HOSPITALIZATIONS);
		if (m_ContentJournal)  m_ContentJournal.SetVisible(tab == EMedicalMenuTab.JOURNAL);
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== RECHERCHE =====
	//------------------------------------------------------------------------------------------------
	
	void RequestSearch(string query)
	{
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		jpc.ClientAskMedicalSearch(query);
	}
	
	void DisplaySearchResults(array<string> uids, array<string> names, array<string> fileNumbers)
	{
		if (!m_ResultsContainer)
			return;
		
		Widget child = m_ResultsContainer.GetChildren();
		while (child)
		{
			Widget next = child.GetSibling();
			child.RemoveFromHierarchy();
			child = next;
		}
		
		int count = uids.Count();
		if (count == 0)
		{
			if (m_ResultsInfo)
				m_ResultsInfo.SetText("Aucun dossier trouve.");
			return;
		}
		
		if (m_ResultsInfo)
			m_ResultsInfo.SetText(string.Format("%1 dossier(s) trouve(s) :", count.ToString()));
		
		WorkspaceWidget ws = GetGame().GetWorkspace();
		if (!ws) return;
		
		string entryLayout = "{9D68BEB73DF970D8}UI/layouts/JobSmsEntry.layout";
		int yPos = 0;
		const int ENTRY_HEIGHT = 40;
		const int ENTRY_SPACING = 4;
		
		for (int i = 0; i < count; i++)
		{
			string uid = uids.Get(i);
			string name = names.Get(i);
			string fnum = fileNumbers.Get(i);
			
			Widget entry = ws.CreateWidgets(entryLayout, m_ResultsContainer);
			if (!entry)
				continue;
			
			FrameSlot.SetPos(entry, 0, yPos);
			FrameSlot.SetSize(entry, 620, ENTRY_HEIGHT);
			yPos += ENTRY_HEIGHT + ENTRY_SPACING;
			
			TextWidget nameW = TextWidget.Cast(entry.FindAnyWidget("PlayerName"));
			if (nameW)
			{
				string uidShort = uid;
				if (uid.Length() > 12)
					uidShort = uid.Substring(0, 12) + "...";
				nameW.SetText(string.Format("%1  [%2]  UID: %3", name, fnum, uidShort));
			}
			
			ButtonWidget btn = ButtonWidget.Cast(entry.FindAnyWidget("SelectButton"));
			if (btn)
			{
				MedicalSearchResultHandler h = new MedicalSearchResultHandler();
				h.m_Menu = this;
				h.m_UID = uid;
				h.m_Name = name;
				btn.AddHandler(h);
				JobFocusHandler.Attach(btn);
			}
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Ouvre la fiche complete d un patient
	//------------------------------------------------------------------------------------------------
	void OpenFicheFor(string uid, string name)
	{
		m_SelectedUID = uid;
		m_SelectedName = name;
		
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		jpc.ClientAskMedicalGetRecord(uid);
		
		ShowFichePanel();
		
		if (m_FicheNameText)
			m_FicheNameText.SetText(string.Format("Patient : %1", name));
		if (m_FicheUIDText)
			m_FicheUIDText.SetText(string.Format("UID : %1", uid));
		if (m_FicheFileNumText)
			m_FicheFileNumText.SetText("N dossier : chargement...");
	}
	
	//------------------------------------------------------------------------------------------------
	// Reception du header depuis le serveur
	//------------------------------------------------------------------------------------------------
	void DisplayRecordHeader(string uid, string name, string fileNumber, string dob,
		int sex, int blood, int createdTs)
	{
		if (uid != m_SelectedUID) return;
		
		if (m_FicheNameText)
			m_FicheNameText.SetText(string.Format("Patient : %1", name));
		if (m_FicheUIDText)
			m_FicheUIDText.SetText(string.Format("UID : %1", uid));
		if (m_FicheFileNumText)
			m_FicheFileNumText.SetText(string.Format("N dossier : %1", fileNumber));
		
		// Onglet Identite : pre-remplit DDN + affiche sex/blood actuels
		m_SelectedSex = sex;
		m_SelectedBlood = blood;
		if (m_IdDobInput)
			m_IdDobInput.SetText(dob);
		if (m_IdCurrentSexText)
			m_IdCurrentSexText.SetText(string.Format("Sexe actuel : %1",
				JobPatientSexHelper.GetLabel(sex)));
		if (m_IdCurrentBloodText)
			m_IdCurrentBloodText.SetText(string.Format("Groupe actuel : %1",
				JobBloodTypeHelper.GetLabel(blood)));
	}
	
	//------------------------------------------------------------------------------------------------
	// Reception de l etat de sante depuis le serveur
	//------------------------------------------------------------------------------------------------
	void DisplayHealth(string uid, int lifePct, int bloodPct, int syncTs, int fract,
		int hemor, int pain, float temp, int pulse, string press, int o2)
	{
		if (uid != m_SelectedUID) return;
		
		if (m_HealthLifeText)
			m_HealthLifeText.SetText(string.Format("Vie : %1%%", lifePct.ToString()));
		if (m_HealthBloodText)
			m_HealthBloodText.SetText(string.Format("Sang : %1%%", bloodPct.ToString()));
		if (m_HealthSyncText)
		{
			if (syncTs == 0)
				m_HealthSyncText.SetText("Derniere sync : jamais");
			else
			{
				int now = System.GetUnixTime();
				int agoMinutes = (now - syncTs) / 60;
				m_HealthSyncText.SetText(string.Format("Derniere sync : il y a %1 min",
					agoMinutes.ToString()));
			}
		}
		
		if (m_HealthFractInput) m_HealthFractInput.SetText(fract.ToString());
		if (m_HealthHemorInput) m_HealthHemorInput.SetText(hemor.ToString());
		if (m_HealthPainInput) m_HealthPainInput.SetText(pain.ToString());
		if (m_HealthTempInput) m_HealthTempInput.SetText(temp.ToString());
		if (m_HealthPulseInput) m_HealthPulseInput.SetText(pulse.ToString());
		if (m_HealthPressInput) m_HealthPressInput.SetText(press);
		if (m_HealthO2Input) m_HealthO2Input.SetText(o2.ToString());
	}
	
	//------------------------------------------------------------------------------------------------
	// Reception des infos medicales
	//------------------------------------------------------------------------------------------------
	void DisplayMedInfo(string uid, string allergies, string diseases, string treatments)
	{
		if (uid != m_SelectedUID) return;
		if (m_MedAllergiesInput) m_MedAllergiesInput.SetText(allergies);
		if (m_MedDiseasesInput) m_MedDiseasesInput.SetText(diseases);
		if (m_MedTreatmentsInput) m_MedTreatmentsInput.SetText(treatments);
	}
	
	//------------------------------------------------------------------------------------------------
	// Reception liste soins
	// Format : idx@@ts@@medName@@motif@@diag@@soins@@meds@@cout, entrees separees par |||
	//------------------------------------------------------------------------------------------------
	void DisplaySoins(string uid, string data)
	{
		if (uid != m_SelectedUID) return;
		BuildDynamicList(m_SoinsList, data, "soin");
	}
	
	//------------------------------------------------------------------------------------------------
	// Reception liste hospitalisations
	// Format : idx@@chambre@@entry@@exit@@medName@@cr@@ordo@@active
	//------------------------------------------------------------------------------------------------
	void DisplayHospit(string uid, string data)
	{
		if (uid != m_SelectedUID) return;
		BuildDynamicList(m_HospitList, data, "hospit");
	}
	
	void DisplayJournal(string uid, string data)
	{
		if (uid != m_SelectedUID) return;
		// Parse et inverse (plus recent en tete)
		m_JournalEntriesCache.Clear();
		if (data != "")
		{
			array<string> entries = new array<string>();
			SplitByDelim(data, "|||", entries);
			// Inverser : dernier en premier
			for (int i = entries.Count() - 1; i >= 0; i--)
				m_JournalEntriesCache.Insert(entries.Get(i));
		}
		m_JournalPage = 0;
		RebuildJournal();
	}
	
	//------------------------------------------------------------------------------------------------
	// Rebuild journal (pagination locale, pas de RPC)
	//------------------------------------------------------------------------------------------------
	void RebuildJournal()
	{
		int total = m_JournalEntriesCache.Count();
		int totalPages = 1;
		if (total > 0)
			totalPages = (total + JOURNAL_PER_PAGE - 1) / JOURNAL_PER_PAGE;
		if (m_JournalPage < 0)
			m_JournalPage = 0;
		if (m_JournalPage >= totalPages)
			m_JournalPage = totalPages - 1;
		if (m_JournalPage < 0)
			m_JournalPage = 0;
		
		if (m_JournalPageLabel)
			m_JournalPageLabel.SetText(string.Format("Page %1 / %2",
				(m_JournalPage + 1).ToString(), totalPages.ToString()));
		
		// Extract entries for current page
		int startIdx = m_JournalPage * JOURNAL_PER_PAGE;
		int endIdx = startIdx + JOURNAL_PER_PAGE;
		if (endIdx > total) endIdx = total;
		
		string pageData = "";
		for (int i = startIdx; i < endIdx; i++)
		{
			if (i > startIdx) pageData = pageData + "|||";
			pageData = pageData + m_JournalEntriesCache.Get(i);
		}
		BuildJournalList(m_JournalList, pageData);
	}
	
	//------------------------------------------------------------------------------------------------
	// Journal readonly - construit une liste SANS boutons (juste affichage)
	//------------------------------------------------------------------------------------------------
	void BuildJournalList(Widget container, string data)
	{
		if (!container) return;
		Widget child = container.GetChildren();
		while (child)
		{
			Widget next = child.GetSibling();
			child.RemoveFromHierarchy();
			child = next;
		}
		if (data == "") return;
		
		WorkspaceWidget ws = GetGame().GetWorkspace();
		if (!ws) return;
		
		array<string> entries = new array<string>();
		SplitByDelim(data, "|||", entries);
		
		int yPos = 0;
		const int ENTRY_HEIGHT = 36;
		const int ENTRY_SPACING = 2;
		const int LIST_WIDTH = 740;
		
		string entryLayout = "{9D68BEB73DF970D8}UI/layouts/JobSmsEntry.layout";
		
		foreach (string entryStr : entries)
		{
			array<string> parts = new array<string>();
			SplitByDelim(entryStr, "@@", parts);
			// Format : idx@@type@@ts@@desc@@author
			if (parts.Count() < 5) continue;
			
			Widget entry = ws.CreateWidgets(entryLayout, container);
			if (!entry) continue;
			
			FrameSlot.SetPos(entry, 0, yPos);
			FrameSlot.SetSize(entry, LIST_WIDTH, ENTRY_HEIGHT);
			
			TextWidget nameW = TextWidget.Cast(entry.FindAnyWidget("PlayerName"));
			if (nameW)
			{
				int typeVal = parts.Get(1).ToInt();
				string typeLbl = JobJournalActionHelper.GetLabel(typeVal);
				string desc = parts.Get(3);
				string author = parts.Get(4);
				nameW.SetText(string.Format("[%1] %2 (par %3)", typeLbl, desc, author));
			}
			
			// Pas de handler - journal readonly
			ButtonWidget selBtn = ButtonWidget.Cast(entry.FindAnyWidget("SelectButton"));
			if (selBtn)
				JobFocusHandler.Attach(selBtn);
			
			yPos += ENTRY_HEIGHT + ENTRY_SPACING;
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Construit une liste avec entrees dynamiques + bouton "X" pour supprimer.
	// Pour les hospitalisations actives, un bouton "Fermer" est ajoute a la place.
	//------------------------------------------------------------------------------------------------
	void BuildDynamicList(Widget container, string data, string kind)
	{
		if (!container) return;
		Widget child = container.GetChildren();
		while (child)
		{
			Widget next = child.GetSibling();
			child.RemoveFromHierarchy();
			child = next;
		}
		if (data == "") return;
		
		WorkspaceWidget ws = GetGame().GetWorkspace();
		if (!ws) return;
		
		array<string> entries = new array<string>();
		SplitByDelim(data, "|||", entries);
		
		int yPos = 0;
		const int ENTRY_HEIGHT = 44;
		const int ENTRY_SPACING = 4;
		const int BTN_WIDTH = 36;
		const int LIST_WIDTH = 740;
		
		string entryLayout = "{9D68BEB73DF970D8}UI/layouts/JobSmsEntry.layout";
		
		foreach (string entryStr : entries)
		{
			array<string> parts = new array<string>();
			SplitByDelim(entryStr, "@@", parts);
			if (parts.Count() < 2) continue;
			int idx = parts.Get(0).ToInt();
			
			Widget entry = ws.CreateWidgets(entryLayout, container);
			if (!entry) continue;
			
			FrameSlot.SetPos(entry, 0, yPos);
			// Hospit active = 2 boutons (Fermer + X) donc 2*BTN_WIDTH
			bool isActiveHospit = (kind == "hospit" && parts.Count() >= 8 && parts.Get(7) == "1");
			int usedBtnWidth = BTN_WIDTH;
			if (isActiveHospit)
				usedBtnWidth = BTN_WIDTH * 2 + 4;
			FrameSlot.SetSize(entry, LIST_WIDTH - usedBtnWidth - 8, ENTRY_HEIGHT);
			
			TextWidget nameW = TextWidget.Cast(entry.FindAnyWidget("PlayerName"));
			if (nameW)
				nameW.SetText(FormatEntryLine(kind, parts));
			
			ButtonWidget selBtn = ButtonWidget.Cast(entry.FindAnyWidget("SelectButton"));
			if (selBtn)
				JobFocusHandler.Attach(selBtn);
			
			// Bouton "Fermer" (uniquement pour hospit active)
			if (isActiveHospit)
			{
				CreateActionButton(container, "close_hospit", idx, yPos,
					LIST_WIDTH - usedBtnWidth, BTN_WIDTH, ENTRY_HEIGHT, "F");
			}
			
			// Bouton "X" suppression
			CreateActionButton(container, kind + "_delete", idx, yPos,
				LIST_WIDTH - BTN_WIDTH, BTN_WIDTH, ENTRY_HEIGHT, "X");
			
			yPos += ENTRY_HEIGHT + ENTRY_SPACING;
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Cree un mini-bouton "action" (X pour delete, F pour fermer hospit).
	// Reutilise JobSmsEntry pour la fiabilite (pas d API CreateWidget native).
	//------------------------------------------------------------------------------------------------
	ButtonWidget CreateActionButton(Widget parent, string action, int index, int yPos,
		int xPos, int width, int height, string label)
	{
		WorkspaceWidget ws = GetGame().GetWorkspace();
		if (!ws) return null;
		
		string entryLayout = "{9D68BEB73DF970D8}UI/layouts/JobSmsEntry.layout";
		Widget btnEntry = ws.CreateWidgets(entryLayout, parent);
		if (!btnEntry) return null;
		
		FrameSlot.SetPos(btnEntry, xPos, yPos);
		FrameSlot.SetSize(btnEntry, width, height);
		
		TextWidget txt = TextWidget.Cast(btnEntry.FindAnyWidget("PlayerName"));
		if (txt)
		{
			txt.SetText("  " + label);
			if (label == "X")
				txt.SetColor(Color.FromRGBA(255, 80, 80, 255));
			else
				txt.SetColor(Color.FromRGBA(255, 200, 80, 255));
		}
		
		ButtonWidget btn = ButtonWidget.Cast(btnEntry.FindAnyWidget("SelectButton"));
		if (btn)
		{
			MedicalActionHandler h = new MedicalActionHandler();
			h.m_Menu = this;
			h.m_Action = action;
			h.m_Index = index;
			btn.AddHandler(h);
			JobFocusHandler.Attach(btn);
		}
		return btn;
	}
	
	//------------------------------------------------------------------------------------------------
	string FormatEntryLine(string kind, array<string> parts)
	{
		if (kind == "soin")
		{
			// idx@@ts@@medName@@motif@@diag@@soins@@meds
			if (parts.Count() < 7) return "?";
			string medName = parts.Get(2);
			string motif = parts.Get(3);
			return string.Format("[Med: %1] %2", medName, motif);
		}
		else if (kind == "hospit")
		{
			// idx@@chambre@@entry@@exit@@medName@@cr@@ordo@@active
			if (parts.Count() < 8) return "?";
			string chambre = parts.Get(1);
			string medName = parts.Get(4);
			bool active = (parts.Get(7) == "1");
			string status = "SORTIE";
			if (active) status = "EN COURS";
			return string.Format("[%1] Chambre %2 - Med: %3", status, chambre, medName);
		}
		return "?";
	}
	
	//------------------------------------------------------------------------------------------------
	void SplitByDelim(string source, string delim, out array<string> outResult)
	{
		if (source == "") return;
		int dlen = delim.Length();
		while (true)
		{
			int idx = source.IndexOf(delim);
			if (idx < 0)
			{
				outResult.Insert(source);
				return;
			}
			outResult.Insert(source.Substring(0, idx));
			int rest = source.Length() - idx - dlen;
			if (rest <= 0)
			{
				// Le delim est en fin de chaine : insere une chaine vide finale
				outResult.Insert("");
				return;
			}
			source = source.Substring(idx + dlen, rest);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Suppression / action sur une entree (appele depuis MedicalActionHandler)
	//------------------------------------------------------------------------------------------------
	void OnEntryAction(string action, int index)
	{
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		
		if (action == "soin_delete")
			jpc.ClientAskMedicalRemoveSoin(m_SelectedUID, index);
		else if (action == "hospit_delete")
			jpc.ClientAskMedicalRemoveHospit(m_SelectedUID, index);
		else if (action == "close_hospit")
		{
			// Ouvre popup avec ordonnance
			m_PopupCloseHospitIndex = index;
			if (m_PopupCloseHospit) m_PopupCloseHospit.SetVisible(true);
			if (m_PopupCloseHospitInfo)
				m_PopupCloseHospitInfo.SetText(string.Format("Sortie hospitalisation #%1", index.ToString()));
			if (m_PopupCloseHospitOrdo)
			{
				m_PopupCloseHospitOrdo.SetText("");
				GetGame().GetWorkspace().SetFocusedWidget(m_PopupCloseHospitOrdo);
			}
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== HANDLER PRINCIPAL =====
	//------------------------------------------------------------------------------------------------
	
	void OnButtonClicked(string action)
	{
		PlayerController pc = GetGame().GetPlayerController();
		JobPlayerComponent jpc = null;
		if (pc)
			jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		
		if (action == "close")
			CloseMenuInternal();
		else if (action == "back")
			ShowSearchPanel();
		else if (action == "search")
		{
			string q = "";
			if (m_SearchInput)
				q = m_SearchInput.GetText();
			RequestSearch(q);
		}
		else if (action == "tab_identity")     SwitchTab(EMedicalMenuTab.IDENTITY);
		else if (action == "tab_health")       SwitchTab(EMedicalMenuTab.HEALTH);
		else if (action == "tab_medinfo")      SwitchTab(EMedicalMenuTab.MEDICAL_INFO);
		else if (action == "tab_soins")        SwitchTab(EMedicalMenuTab.SOINS);
		else if (action == "tab_hospit")       SwitchTab(EMedicalMenuTab.HOSPITALIZATIONS);
		else if (action == "tab_journal")      SwitchTab(EMedicalMenuTab.JOURNAL);
		else if (action == "id_sex_male")      { m_SelectedSex = EPatientSex.MALE; UpdateIdentityPreview(); }
		else if (action == "id_sex_female")    { m_SelectedSex = EPatientSex.FEMALE; UpdateIdentityPreview(); }
		else if (action == "id_sex_other")     { m_SelectedSex = EPatientSex.OTHER; UpdateIdentityPreview(); }
		else if (action == "id_blood_apos")    { m_SelectedBlood = EBloodType.A_POS; UpdateIdentityPreview(); }
		else if (action == "id_blood_aneg")    { m_SelectedBlood = EBloodType.A_NEG; UpdateIdentityPreview(); }
		else if (action == "id_blood_bpos")    { m_SelectedBlood = EBloodType.B_POS; UpdateIdentityPreview(); }
		else if (action == "id_blood_bneg")    { m_SelectedBlood = EBloodType.B_NEG; UpdateIdentityPreview(); }
		else if (action == "id_blood_abpos")   { m_SelectedBlood = EBloodType.AB_POS; UpdateIdentityPreview(); }
		else if (action == "id_blood_abneg")   { m_SelectedBlood = EBloodType.AB_NEG; UpdateIdentityPreview(); }
		else if (action == "id_blood_opos")    { m_SelectedBlood = EBloodType.O_POS; UpdateIdentityPreview(); }
		else if (action == "id_blood_oneg")    { m_SelectedBlood = EBloodType.O_NEG; UpdateIdentityPreview(); }
		else if (action == "id_save")
		{
			if (!jpc) return;
			string dob = "";
			if (m_IdDobInput)
				dob = m_IdDobInput.GetText();
			jpc.ClientAskMedicalSetIdentity(m_SelectedUID, dob, m_SelectedSex, m_SelectedBlood);
		}
		else if (action == "health_refresh")
		{
			// Demande au serveur de re-sync Vie/Sang depuis le SurvivalHUD du patient si connecte
			if (jpc)
				jpc.ClientAskMedicalRefreshHealth(m_SelectedUID);
		}
		else if (action == "health_save")
		{
			if (!jpc) return;
			int fract = 0, hemor = 0, pain = 0, pulse = 0, o2 = 0;
			float temp = 37.0;
			string press = "";
			if (m_HealthFractInput) fract = m_HealthFractInput.GetText().ToInt();
			if (m_HealthHemorInput) hemor = m_HealthHemorInput.GetText().ToInt();
			if (m_HealthPainInput) pain = m_HealthPainInput.GetText().ToInt();
			if (m_HealthTempInput) temp = m_HealthTempInput.GetText().ToFloat();
			if (m_HealthPulseInput) pulse = m_HealthPulseInput.GetText().ToInt();
			if (m_HealthPressInput) press = m_HealthPressInput.GetText();
			if (m_HealthO2Input) o2 = m_HealthO2Input.GetText().ToInt();
			jpc.ClientAskMedicalSetHealthManual(m_SelectedUID, fract, hemor, pain, temp,
				pulse, press, o2);
		}
		else if (action == "medinfo_save")
		{
			if (!jpc) return;
			string all = "", dis = "", tre = "";
			if (m_MedAllergiesInput) all = m_MedAllergiesInput.GetText();
			if (m_MedDiseasesInput) dis = m_MedDiseasesInput.GetText();
			if (m_MedTreatmentsInput) tre = m_MedTreatmentsInput.GetText();
			jpc.ClientAskMedicalSetInfo(m_SelectedUID, all, dis, tre);
		}
		else if (action == "add_soin")
		{
			if (m_PopupAddSoin) m_PopupAddSoin.SetVisible(true);
			if (m_PopupSoinMotif) { m_PopupSoinMotif.SetText(""); GetGame().GetWorkspace().SetFocusedWidget(m_PopupSoinMotif); }
			if (m_PopupSoinDiag) m_PopupSoinDiag.SetText("");
			if (m_PopupSoinActes) m_PopupSoinActes.SetText("");
			if (m_PopupSoinMeds) m_PopupSoinMeds.SetText("");
		}
		else if (action == "add_hospit")
		{
			if (m_PopupAddHospit) m_PopupAddHospit.SetVisible(true);
			if (m_PopupHospitChambre) { m_PopupHospitChambre.SetText(""); GetGame().GetWorkspace().SetFocusedWidget(m_PopupHospitChambre); }
			if (m_PopupHospitCR) m_PopupHospitCR.SetText("");
		}
		else if (action == "popup_soin_ok")
		{
			if (!jpc || !m_PopupSoinMotif) return;
			string motif = m_PopupSoinMotif.GetText();
			string diag = "";
			string actes = "";
			string meds = "";
			if (m_PopupSoinDiag) diag = m_PopupSoinDiag.GetText();
			if (m_PopupSoinActes) actes = m_PopupSoinActes.GetText();
			if (m_PopupSoinMeds) meds = m_PopupSoinMeds.GetText();
			if (motif != "")
			{
				jpc.ClientAskMedicalAddSoin(m_SelectedUID, motif, diag, actes, meds);
				if (m_PopupAddSoin) m_PopupAddSoin.SetVisible(false);
			}
		}
		else if (action == "popup_soin_cancel")
		{
			if (m_PopupAddSoin) m_PopupAddSoin.SetVisible(false);
		}
		else if (action == "popup_hospit_ok")
		{
			if (!jpc || !m_PopupHospitChambre) return;
			string chambre = m_PopupHospitChambre.GetText();
			string cr = "";
			if (m_PopupHospitCR) cr = m_PopupHospitCR.GetText();
			if (chambre != "")
			{
				jpc.ClientAskMedicalAddHospit(m_SelectedUID, chambre, cr);
				if (m_PopupAddHospit) m_PopupAddHospit.SetVisible(false);
			}
		}
		else if (action == "popup_hospit_cancel")
		{
			if (m_PopupAddHospit) m_PopupAddHospit.SetVisible(false);
		}
		else if (action == "popup_close_hospit_ok")
		{
			if (!jpc || m_PopupCloseHospitIndex < 0) return;
			string ordo = "";
			if (m_PopupCloseHospitOrdo) ordo = m_PopupCloseHospitOrdo.GetText();
			jpc.ClientAskMedicalCloseHospit(m_SelectedUID, m_PopupCloseHospitIndex, ordo);
			if (m_PopupCloseHospit) m_PopupCloseHospit.SetVisible(false);
			m_PopupCloseHospitIndex = -1;
		}
		else if (action == "popup_close_hospit_cancel")
		{
			if (m_PopupCloseHospit) m_PopupCloseHospit.SetVisible(false);
			m_PopupCloseHospitIndex = -1;
		}
		else if (action == "journal_prev")
		{
			m_JournalPage = m_JournalPage - 1;
			RebuildJournal();
		}
		else if (action == "journal_next")
		{
			m_JournalPage = m_JournalPage + 1;
			RebuildJournal();
		}
	}
	
	void UpdateIdentityPreview()
	{
		if (m_IdCurrentSexText)
			m_IdCurrentSexText.SetText(string.Format("Sexe actuel : %1",
				JobPatientSexHelper.GetLabel(m_SelectedSex)));
		if (m_IdCurrentBloodText)
			m_IdCurrentBloodText.SetText(string.Format("Groupe actuel : %1",
				JobBloodTypeHelper.GetLabel(m_SelectedBlood)));
	}
	
	void CloseMenuInternal()
	{
		GetGame().GetMenuManager().CloseMenu(this);
	}
}

//------------------------------------------------------------------------------------------------
class MedicalMenuHandler : ScriptedWidgetEventHandler
{
	JobMedicalMenu m_Menu;
	string m_Action;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu)
			m_Menu.OnButtonClicked(m_Action);
		return true;
	}
}

//------------------------------------------------------------------------------------------------
class MedicalSearchResultHandler : ScriptedWidgetEventHandler
{
	JobMedicalMenu m_Menu;
	string m_UID;
	string m_Name;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu)
			m_Menu.OpenFicheFor(m_UID, m_Name);
		return true;
	}
}

//------------------------------------------------------------------------------------------------
class MedicalActionHandler : ScriptedWidgetEventHandler
{
	JobMedicalMenu m_Menu;
	string m_Action;
	int m_Index;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu)
			m_Menu.OnEntryAction(m_Action, m_Index);
		return true;
	}
}
