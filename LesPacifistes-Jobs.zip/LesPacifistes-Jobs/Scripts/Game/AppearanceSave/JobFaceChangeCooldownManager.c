//------------------------------------------------------------------------------------------------
// JobFaceChangeCooldownManager.c
//
// Singleton serveur qui gere le cooldown de 14 jours pour l action Changer de visage.
// - Sauvegarde persistante des timestamps de premiere utilisation par UID (map UID -> ts)
// - Si aucun timestamp ou si +14j ecoules depuis le premier -> le joueur peut changer
// - Apres 14j, le timestamp est efface (reset auto au prochain check ou usage)
//
// Persistance : $profile:LesPacifistesJobs/face_change_cooldowns.json (flat, comme les autres
// managers du mod, pas de sous-dossier).
//------------------------------------------------------------------------------------------------

class JobFaceChangeCooldownManager
{
	static ref JobFaceChangeCooldownManager s_Instance;
	
	const int COOLDOWN_DURATION_S = 604800;  // 14 jours = 14 * 24 * 3600
	const string SAVE_PATH = "$profile:LesPacifistesJobs/face_change_cooldowns.json";
	
	// Map UID -> timestamp UNIX de PREMIERE utilisation (debut du cooldown)
	ref map<string, int> m_CooldownStart = new map<string, int>();
	
	//------------------------------------------------------------------------------------------------
	static JobFaceChangeCooldownManager GetInstance()
	{
		if (!s_Instance)
		{
			s_Instance = new JobFaceChangeCooldownManager();
			s_Instance.LoadFromDisk();
		}
		return s_Instance;
	}
	
	//------------------------------------------------------------------------------------------------
	// Retourne true si le joueur peut utiliser l action.
	// Nettoie automatiquement l entree si le cooldown est ecoule.
	//------------------------------------------------------------------------------------------------
	bool CanUse(string uid)
	{
		if (uid == "")
			return false;
		
		if (!m_CooldownStart.Contains(uid))
			return true;
		
		int startTs = m_CooldownStart.Get(uid);
		int now = System.GetUnixTime();
		if (now - startTs >= COOLDOWN_DURATION_S)
		{
			// Cooldown ecoule -> nettoyage auto
			m_CooldownStart.Remove(uid);
			SaveToDisk();
			return true;
		}
		return false;
	}
	
	//------------------------------------------------------------------------------------------------
	// Enregistre l utilisation actuelle. Ne fait rien si un cooldown est deja en cours
	// (donc le cooldown demarre a la PREMIERE utilisation et se maintient 14j).
	//------------------------------------------------------------------------------------------------
	void RegisterUse(string uid)
	{
		if (uid == "")
			return;
		
		// Si deja un cooldown en cours, on ne l ecrase pas
		if (m_CooldownStart.Contains(uid))
		{
			int existing = m_CooldownStart.Get(uid);
			int now = System.GetUnixTime();
			if (now - existing < COOLDOWN_DURATION_S)
				return;  // cooldown deja actif
		}
		
		m_CooldownStart.Set(uid, System.GetUnixTime());
		SaveToDisk();
		Print(string.Format("[JobFaceChangeCooldownManager] Cooldown demarre pour UID %1", uid),
			LogLevel.NORMAL);
	}
	
	//------------------------------------------------------------------------------------------------
	// Retourne le timestamp UNIX de FIN de cooldown (0 si aucun cooldown actif).
	//------------------------------------------------------------------------------------------------
	int GetCooldownEndTs(string uid)
	{
		if (uid == "")
			return 0;
		if (!m_CooldownStart.Contains(uid))
			return 0;
		int startTs = m_CooldownStart.Get(uid);
		int endTs = startTs + COOLDOWN_DURATION_S;
		int now = System.GetUnixTime();
		if (now >= endTs)
			return 0;  // deja ecoule
		return endTs;
	}
	
	//------------------------------------------------------------------------------------------------
	// Retourne le nombre de secondes restantes avant que le joueur puisse utiliser l action.
	// 0 si aucun cooldown.
	//------------------------------------------------------------------------------------------------
	int GetRemainingSeconds(string uid)
	{
		int endTs = GetCooldownEndTs(uid);
		if (endTs == 0) return 0;
		int now = System.GetUnixTime();
		return endTs - now;
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== PERSISTANCE =====
	//------------------------------------------------------------------------------------------------
	void SaveToDisk()
	{
		SCR_JsonSaveContext ctx = new SCR_JsonSaveContext();
		
		// Serialise en 2 tableaux paralleles {uids[], timestamps[]}
		array<string> uids = new array<string>();
		array<int> tss = new array<int>();
		foreach (string uid, int ts : m_CooldownStart)
		{
			uids.Insert(uid);
			tss.Insert(ts);
		}
		ctx.WriteValue("uids", uids);
		ctx.WriteValue("timestamps", tss);
		
		ctx.SaveToFile(SAVE_PATH);
	}
	
	void LoadFromDisk()
	{
		SCR_JsonLoadContext ctx = new SCR_JsonLoadContext();
		if (!ctx.LoadFromFile(SAVE_PATH))
		{
			Print("[JobFaceChangeCooldownManager] Aucun fichier existant, demarrage propre",
				LogLevel.NORMAL);
			return;
		}
		
		array<string> uids = new array<string>();
		array<int> tss = new array<int>();
		ctx.ReadValue("uids", uids);
		ctx.ReadValue("timestamps", tss);
		
		int count = uids.Count();
		if (count != tss.Count())
		{
			Print("[JobFaceChangeCooldownManager] ERREUR : uids et timestamps de tailles differentes",
				LogLevel.WARNING);
			return;
		}
		
		int now = System.GetUnixTime();
		int loaded = 0;
		int expired = 0;
		for (int i = 0; i < count; i++)
		{
			string uid = uids.Get(i);
			int ts = tss.Get(i);
			// Ignore les cooldowns deja ecoules
			if (now - ts >= COOLDOWN_DURATION_S)
			{
				expired = expired + 1;
				continue;
			}
			m_CooldownStart.Set(uid, ts);
			loaded = loaded + 1;
		}
		Print(string.Format("[JobFaceChangeCooldownManager] Charge : %1 cooldown(s) actif(s), %2 expire(s) ignore(s)",
			loaded.ToString(), expired.ToString()), LogLevel.NORMAL);
		
		if (expired > 0)
			SaveToDisk();  // nettoyage disque
	}
}
