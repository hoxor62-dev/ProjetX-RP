class AppearanceSaveManagerClass : ScriptComponentClass {}
class AppearanceSaveManager : ScriptComponent
{
    static AppearanceSaveManager s_Instance;

    override void OnPostInit(IEntity owner)
    {
        super.OnPostInit(owner);
        s_Instance = this;

        if (!Replication.IsServer()) return;

        SCR_BaseGameMode gm = SCR_BaseGameMode.Cast(GetGame().GetGameMode());
        if (gm)
        {
            gm.GetOnPlayerConnected().Insert(OnPlayerConnected);
            gm.GetOnPlayerDisconnected().Insert(OnPlayerDisconnected);
        }

        Print("[AppearanceSaveManager] Initialisé", LogLevel.NORMAL);
    }

    static AppearanceSaveManager GetInstance()
    {
        return s_Instance;
    }

    void OnPlayerConnected(int playerId)
    {
        GetGame().GetCallqueue().CallLater(RestoreAppearance, 10000, false, playerId);
    }

    void OnPlayerDisconnected(int playerId, KickCauseCode cause, int timeout)
    {
        SaveAppearance(playerId);
    }

    string GetUID(int playerId)
    {
        return GetGame().GetBackendApi().GetPlayerUID(playerId);
    }

    void SaveAppearance(int playerId)
    {
        if (!Replication.IsServer()) return;

        Print("[AppearanceSaveManager] SaveAppearance playerId=" + playerId, LogLevel.NORMAL);

        IEntity playerEntity = GetGame().GetPlayerManager().GetPlayerControlledEntity(playerId);
        if (!playerEntity)
        {
            Print("[AppearanceSaveManager] ERREUR: playerEntity null", LogLevel.ERROR);
            return;
        }

        CharacterIdentityComponent identityComp = CharacterIdentityComponent.Cast(
            playerEntity.FindComponent(CharacterIdentityComponent)
        );
        if (!identityComp)
        {
            Print("[AppearanceSaveManager] ERREUR: identityComp null", LogLevel.ERROR);
            return;
        }

        Identity identity = identityComp.GetIdentity();
        if (!identity)
        {
            Print("[AppearanceSaveManager] ERREUR: identity null", LogLevel.ERROR);
            return;
        }

        VisualIdentity visual = identity.GetVisualIdentity();
        if (!visual)
        {
            Print("[AppearanceSaveManager] ERREUR: visual null", LogLevel.ERROR);
            return;
        }

        string headStr = visual.GetHead();
        string bodyStr = visual.GetBody();

        Print("[AppearanceSaveManager] head=" + headStr + " body=" + bodyStr, LogLevel.NORMAL);

        string uid = GetUID(playerId);
        if (uid.IsEmpty()) return;

        string path = "$profile:LesPacifistes/appearance_" + uid + ".json";

        SCR_JsonSaveContext ctx = new SCR_JsonSaveContext();
        ctx.WriteValue("head", headStr);
        ctx.WriteValue("body", bodyStr);
        ctx.SaveToFile(path);

        Print("[AppearanceSaveManager] Apparence sauvegardée pour " + uid, LogLevel.NORMAL);
    }

    void RestoreAppearance(int playerId)
    {
        if (!Replication.IsServer()) return;

        string uid = GetUID(playerId);
        if (uid.IsEmpty()) return;

        string path = "$profile:LesPacifistes/appearance_" + uid + ".json";

        SCR_JsonLoadContext ctx = new SCR_JsonLoadContext();
        if (!ctx.LoadFromFile(path))
        {
            Print("[AppearanceSaveManager] Pas de sauvegarde pour " + uid, LogLevel.NORMAL);
            return;
        }

        string headStr, bodyStr;
        ctx.ReadValue("head", headStr);
        ctx.ReadValue("body", bodyStr);

        if (headStr.IsEmpty() || bodyStr.IsEmpty())
        {
            Print("[AppearanceSaveManager] Données incomplètes pour " + uid, LogLevel.ERROR);
            return;
        }

        Print("[AppearanceSaveManager] Tentative restore head=" + headStr + " body=" + bodyStr, LogLevel.NORMAL);

        IEntity playerEntity = GetGame().GetPlayerManager().GetPlayerControlledEntity(playerId);
        if (!playerEntity)
        {
            Print("[AppearanceSaveManager] RestoreAppearance: playerEntity null — retry dans 2s", LogLevel.WARNING);
            GetGame().GetCallqueue().CallLater(RestoreAppearance, 10000, false, playerId);
            return;
        }

        CharacterIdentityComponent identityComp = CharacterIdentityComponent.Cast(
            playerEntity.FindComponent(CharacterIdentityComponent)
        );
        if (!identityComp)
        {
            Print("[AppearanceSaveManager] ERREUR: identityComp null", LogLevel.ERROR);
            return;
        }

        Identity identity = identityComp.GetIdentity();
        if (!identity)
        {
            Print("[AppearanceSaveManager] ERREUR: identity null", LogLevel.ERROR);
            return;
        }

        VisualIdentity visual = identity.GetVisualIdentity();
        if (!visual)
        {
            Print("[AppearanceSaveManager] ERREUR: visual null", LogLevel.ERROR);
            return;
        }

        visual.SetHead(headStr);
        visual.SetBody(bodyStr);

        identity.SetVisualIdentity(visual);
        identityComp.SetIdentity(identity);
        identityComp.CommitChanges();

        Print("[AppearanceSaveManager] Apparence restaurée pour " + uid, LogLevel.NORMAL);
    }
}
