//------------------------------------------------------------------------------------------------
// LP_FaceChangeCooldownComponent.c
//
// Composant a attacher au SCR_PlayerController.
// Role :
//   - Cote SERVEUR : synchronise le timestamp de fin de cooldown vers le client via RplProp
//   - Cote CLIENT : expose GetCooldownEndTs() pour l action / l UI
//   - Cote SERVEUR : expose ServerRegisterFaceChange() a appeler apres un changement reussi
//
// Le timestamp est refresh cote serveur au spawn du joueur puis a chaque changement.
//------------------------------------------------------------------------------------------------

class LP_FaceChangeCooldownComponentClass : ScriptComponentClass {}

class LP_FaceChangeCooldownComponent : ScriptComponent
{
	// Timestamp UNIX de fin de cooldown. 0 = aucun cooldown actif.
	// RplProp = replique automatiquement du serveur vers le owner client.
	[RplProp()]
	int m_CooldownEndTs = 0;
	
	//------------------------------------------------------------------------------------------------
	override void OnPostInit(IEntity owner)
	{
		super.OnPostInit(owner);
		// Sync initial cote serveur : quand un joueur se connecte, on lui pousse son cooldown
		if (Replication.IsServer())
		{
			// Le PlayerController n a pas encore forcement un playerId ici,
			// on differe le refresh
			GetGame().GetCallqueue().CallLater(ServerRefreshCooldown, 2000, false);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Cote SERVEUR : refresh le timestamp de fin depuis le manager et le pousse via RplProp
	//------------------------------------------------------------------------------------------------
	void ServerRefreshCooldown()
	{
		if (!Replication.IsServer())
			return;
		
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int pid = pc.GetPlayerId();
		if (pid <= 0) return;
		
		string uid = GetGame().GetBackendApi().GetPlayerIdentityId(pid);
		if (uid == "") return;
		
		int endTs = JobFaceChangeCooldownManager.GetInstance().GetCooldownEndTs(uid);
		if (m_CooldownEndTs != endTs)
		{
			m_CooldownEndTs = endTs;
			Replication.BumpMe();
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Cote SERVEUR : appele apres un changement de visage reussi.
	// Enregistre la premiere utilisation dans le manager (si pas deja fait) et sync le RplProp.
	//------------------------------------------------------------------------------------------------
	void ServerRegisterFaceChange()
	{
		if (!Replication.IsServer())
			return;
		
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		int pid = pc.GetPlayerId();
		if (pid <= 0) return;
		
		string uid = GetGame().GetBackendApi().GetPlayerIdentityId(pid);
		if (uid == "") return;
		
		JobFaceChangeCooldownManager mgr = JobFaceChangeCooldownManager.GetInstance();
		mgr.RegisterUse(uid);
		
		m_CooldownEndTs = mgr.GetCooldownEndTs(uid);
		Replication.BumpMe();
		
		Print(string.Format("[LP_FaceChangeCooldown] Changement enregistre pour pid=%1 uid=%2 endTs=%3",
			pid.ToString(), uid, m_CooldownEndTs.ToString()), LogLevel.NORMAL);
	}
	
	//------------------------------------------------------------------------------------------------
	// RPC declenche par le client apres avoir termine le changement de visage.
	//------------------------------------------------------------------------------------------------
	void ClientAskRegisterFaceChange()
	{
		Rpc(RpcAsk_RegisterFaceChange);
	}
	
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void RpcAsk_RegisterFaceChange()
	{
		ServerRegisterFaceChange();
	}
	
	//------------------------------------------------------------------------------------------------
	// Cote CLIENT ou SERVEUR : retourne le timestamp UNIX de fin de cooldown (0 si aucun).
	//------------------------------------------------------------------------------------------------
	int GetCooldownEndTs()
	{
		return m_CooldownEndTs;
	}
	
	//------------------------------------------------------------------------------------------------
	// Cote CLIENT : retourne le nombre de secondes restantes avant la fin du cooldown.
	// 0 si aucun cooldown actif.
	//------------------------------------------------------------------------------------------------
	int GetRemainingSeconds()
	{
		if (m_CooldownEndTs == 0) return 0;
		int now = System.GetUnixTime();
		if (now >= m_CooldownEndTs) return 0;
		return m_CooldownEndTs - now;
	}
	
	//------------------------------------------------------------------------------------------------
	// Cote CLIENT : true si le joueur peut utiliser l action.
	//------------------------------------------------------------------------------------------------
	bool CanUse()
	{
		return GetRemainingSeconds() == 0;
	}
	
	//------------------------------------------------------------------------------------------------
	// Helper : formate le temps restant en libelle FR
	// Ex : "13 jours" / "1 jour" / "3 heures" / "42 minutes" / "moins d 1 min"
	//------------------------------------------------------------------------------------------------
	string GetRemainingLabel()
	{
		int sec = GetRemainingSeconds();
		if (sec <= 0) return "";
		
		int days = sec / 86400;
		if (days >= 1)
		{
			if (days == 1) return "1 jour";
			return days.ToString() + " jours";
		}
		int hours = sec / 3600;
		if (hours >= 1)
		{
			if (hours == 1) return "1 heure";
			return hours.ToString() + " heures";
		}
		int minutes = sec / 60;
		if (minutes >= 1)
		{
			if (minutes == 1) return "1 minute";
			return minutes.ToString() + " minutes";
		}
		return "moins d 1 min";
	}
	
	//------------------------------------------------------------------------------------------------
	// Cote CLIENT : recupere le composant de son PlayerController local.
	//------------------------------------------------------------------------------------------------
	static LP_FaceChangeCooldownComponent GetLocalInstance()
	{
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return null;
		return LP_FaceChangeCooldownComponent.Cast(pc.FindComponent(LP_FaceChangeCooldownComponent));
	}
}
