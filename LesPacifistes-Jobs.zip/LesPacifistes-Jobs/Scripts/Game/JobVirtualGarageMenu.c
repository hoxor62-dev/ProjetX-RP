//------------------------------------------------------------------------------------------------
// JobVirtualGarageMenu.c
// Menu du garage virtuel : liste des vehicules stockes du joueur (ou du garage partage Fourriere).
//
// NOUVEAU STYLE : s inspire de la page Garage virtuel de la fiche RP :
//   - Colonne gauche : preview 3D du vehicule selectionne + nom + info + boutons action
//   - Colonne droite : liste cliquable des vehicules + pagination
//   - Bouton bas : Obtenir une clef vierge
//
// Workflow :
//   1. Le client recoit les donnees via RpcDo_ReceiveVirtualGarageList et appelle SetPendingData,
//      puis ouvre le menu.
//   2. Le menu construit la liste (une ligne par vehicule). Pas de preview 3D sur chaque ligne,
//      le preview s affiche a gauche quand on clique sur une ligne.
//   3. Clic sur une ligne -> SelectVehicle(i) : met a jour preview + info + rend les boutons
//      action utilisables (Recuperer, Transferer, Assurer et recuperer).
//   4. Clic sur une action : envoie la RPC correspondante au serveur et ferme le menu.
//------------------------------------------------------------------------------------------------

class JobVirtualGarageMenu : ChimeraMenuBase
{
	// Layout des lignes : reutilise JobAdminRowEntry.layout (meme pattern que la fiche RP)
	const string ROW_LAYOUT_PATH = "{4C675B899ADF8C84}UI/layouts/JobAdminRowEntry.layout";

	// Plus de pagination : toutes les entrees sont affichees dans une liste scrollable
	// (ScrollLayoutWidget dans le layout). Nav manette : DPad bas/haut defile naturellement.

	// === WIDGETS ===
	Widget m_RootWidget;
	TextWidget m_TitleText;
	TextWidget m_SelectedTitle;
	TextWidget m_SelectedInfo;
	TextWidget m_EmptyText;
	ItemPreviewWidget m_GaragePreviewWidget;

	Widget m_EntriesContainer;

	ButtonWidget m_BtnRetrieve;
	ButtonWidget m_BtnTransfer;
	ButtonWidget m_BtnInsureRetrieve;
	ButtonWidget m_BtnBlankKey;
	ButtonWidget m_BtnClose;

	// === ETAT ===
	int m_SelectedIndex = -1; // index dans s_PendingIndexes (-1 = rien de selectionne)
	ItemPreviewManagerEntity m_PreviewManager;

	// === DONNEES PRE-CHARGEES (set par RpcDo_ReceiveVirtualGarageList AVANT OpenMenu) ===
	static ref array<int> s_PendingIndexes = new array<int>();
	static ref array<string> s_PendingPrefabs = new array<string>();
	static ref array<bool> s_PendingInsured = new array<bool>();
	static ref array<int> s_PendingDamaged = new array<int>();  // nombre de zones endommagees
	static ref array<int> s_PendingFuels = new array<int>();    // litres restants (-1 = inconnu)
	static RplId s_PendingNpcRplId = RplId.Invalid();

	// Copie locale (consumee a OnMenuOpen pour decoupler du prochain ouverture)
	ref array<int> m_Damaged = new array<int>();
	ref array<int> m_Fuels = new array<int>();

	// Edge detect pour la nav manette directionnelle (intercepte dans OnMenuUpdate)
	bool m_NavLeftPrev = false;
	bool m_NavRightPrev = false;
	bool m_NavUpPrev = false;
	bool m_NavDownPrev = false;
	Widget m_PendingFocus; // cible du prochain SetFocusedWidget differe (pour battre la nav native engine)

	// VERROU DE FOCUS : apres un QueueFocus(target), le focus est re-force sur target a CHAQUE
	// frame pour battre le repeat-timer agressif de la nav native engine.
	//   - Lock PERMANENT (m_NavLockPermanent=true) : actif jusqu au prochain QueueFocus. Utilise
	//     pour les boutons action (Retrieve/Transfer/Insure/Close/BlankKey) ou chaque appui
	//     DPad doit mener a exactement 1 cran.
	//   - Lock TEMPORAIRE (m_NavLockFrames frames) : utilise pour les Row buttons de la liste,
	//     ou on veut que la nav native engine puisse ensuite naviguer librement.
	Widget m_NavLockTarget;
	bool m_NavLockPermanent = false;
	int m_NavLockFrames = 0;

	// Mode Fourriere : utilise le garage PARTAGE au lieu du garage perso
	static bool s_PendingFourriereMode = false;
	protected bool m_IsFourriereMode = false;

	// Noms RP des proprietaires originaux (parallele a s_PendingIndexes), mode Fourriere uniquement
	static ref array<string> s_PendingOwnerNames = new array<string>();
	ref array<string> m_OwnerNames = new array<string>();

	static JobVirtualGarageMenu s_Instance;

	//------------------------------------------------------------------------------------------------
	static void SetPendingData(array<int> indexes, array<string> prefabs, array<bool> insured, RplId npcRplId)
	{
		s_PendingIndexes.Clear();
		s_PendingPrefabs.Clear();
		s_PendingInsured.Clear();
		foreach (int idx : indexes)
			s_PendingIndexes.Insert(idx);
		foreach (string pf : prefabs)
			s_PendingPrefabs.Insert(pf);
		foreach (bool ins : insured)
			s_PendingInsured.Insert(ins);
		s_PendingNpcRplId = npcRplId;
	}

	static void SetFourriereMode(bool mode) { s_PendingFourriereMode = mode; }

	//------------------------------------------------------------------------------------------------
	// Pre-charge le nombre de zones endommagees par vehicule (parallele a s_PendingIndexes).
	// Vide = pas d info de degats (affiche "?").
	//------------------------------------------------------------------------------------------------
	static void SetPendingDamaged(array<int> damaged)
	{
		s_PendingDamaged.Clear();
		if (damaged)
			foreach (int d : damaged)
				s_PendingDamaged.Insert(d);
	}

	//------------------------------------------------------------------------------------------------
	// Pre-charge le fuel en litres par vehicule (-1 = inconnu)
	//------------------------------------------------------------------------------------------------
	static void SetPendingFuels(array<int> fuels)
	{
		s_PendingFuels.Clear();
		if (fuels)
			foreach (int f : fuels)
				s_PendingFuels.Insert(f);
	}

	static void SetPendingOwnerNames(array<string> ownerNames)
	{
		s_PendingOwnerNames.Clear();
		foreach (string n : ownerNames)
			s_PendingOwnerNames.Insert(n);
	}

	//------------------------------------------------------------------------------------------------
	override void OnMenuOpen()
	{
		super.OnMenuOpen();
		s_Instance = this;
		JobFocusHandler.ClearRegistry();

		m_RootWidget = GetRootWidget();
		if (!m_RootWidget) return;

		m_TitleText = TextWidget.Cast(m_RootWidget.FindAnyWidget("TitleText"));
		m_SelectedTitle = TextWidget.Cast(m_RootWidget.FindAnyWidget("SelectedTitle"));
		m_SelectedInfo = TextWidget.Cast(m_RootWidget.FindAnyWidget("SelectedInfo"));
		m_EmptyText = TextWidget.Cast(m_RootWidget.FindAnyWidget("EmptyText"));
		m_GaragePreviewWidget = ItemPreviewWidget.Cast(m_RootWidget.FindAnyWidget("GaragePreviewWidget"));

		m_EntriesContainer = m_RootWidget.FindAnyWidget("EntriesContainer");

		m_BtnRetrieve = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnRetrieve"));
		m_BtnTransfer = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnTransfer"));
		m_BtnInsureRetrieve = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnInsureRetrieve"));
		m_BtnBlankKey = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnBlankKey"));
		m_BtnClose = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnClose"));

		// Consomme le flag Fourriere
		m_IsFourriereMode = s_PendingFourriereMode;
		s_PendingFourriereMode = false;

		// Consomme la liste des noms de proprios (vide pour garage perso)
		m_OwnerNames.Clear();
		foreach (string n : s_PendingOwnerNames)
			m_OwnerNames.Insert(n);
		s_PendingOwnerNames.Clear();

		// Consomme la liste des degats (parallele a s_PendingIndexes)
		m_Damaged.Clear();
		foreach (int dmg : s_PendingDamaged)
			m_Damaged.Insert(dmg);
		s_PendingDamaged.Clear();

		// Consomme la liste des fuels (parallele a s_PendingIndexes)
		m_Fuels.Clear();
		foreach (int flit : s_PendingFuels)
			m_Fuels.Insert(flit);
		s_PendingFuels.Clear();

		if (m_TitleText)
		{
			if (m_IsFourriereMode)
				m_TitleText.SetText("GARAGE FOURRIERE - Vehicules partages");
			else
				m_TitleText.SetText("GARAGE VIRTUEL - Mes vehicules");
		}

		// Boutons action : handler central, action string distingue chaque bouton
		AttachAction(m_BtnRetrieve, "retrieve");
		AttachAction(m_BtnTransfer, "transfer");
		AttachAction(m_BtnInsureRetrieve, "insure");
		AttachAction(m_BtnBlankKey, "blankkey");
		AttachAction(m_BtnClose, "close");
		// Masque les boutons action tant qu aucun vehicule n est selectionne
		SetActionButtonsEnabled(false);

		// Construit la liste complete (scrollable)
		m_SelectedIndex = -1;
		RebuildEntries();

		// Auto-selection du premier vehicule si la liste n est pas vide
		if (s_PendingIndexes.Count() > 0)
			SelectVehicle(0);

		// Nav manette : pousse le focus initial sur la premiere ligne de la liste a droite
		// pour que DPad bas/haut navigue immediatement entre les vehicules, et DPad gauche
		// vers les boutons action a gauche.
		// Si la liste est vide, retombe sur Fermer.
		Widget initialFocus = GetFirstRowButton();
		if (!initialFocus) initialFocus = m_BtnClose;
		if (initialFocus)
			GetGame().GetWorkspace().SetFocusedWidget(initialFocus);
	}

	//------------------------------------------------------------------------------------------------
	// Retourne le RowButton de la premiere ligne vehicule (nav manette initiale), null si vide.
	//------------------------------------------------------------------------------------------------
	Widget GetFirstRowButton()
	{
		if (!m_EntriesContainer) return null;
		Widget firstRow = m_EntriesContainer.GetChildren();
		if (!firstRow) return null;
		return firstRow.FindAnyWidget("RowButton");
	}

	//------------------------------------------------------------------------------------------------
	// Helper pour attacher un handler central + focus manette sur un bouton
	//------------------------------------------------------------------------------------------------
	void AttachAction(ButtonWidget btn, string action)
	{
		if (!btn) return;
		VgSimpleHandler h = new VgSimpleHandler();
		h.m_Menu = this;
		h.m_Action = action;
		btn.AddHandler(h);
		JobFocusHandler.Attach(btn);
	}

	//------------------------------------------------------------------------------------------------
	override void OnMenuClose()
	{
		if (s_Instance == this) s_Instance = null;
		super.OnMenuClose();
	}

	//------------------------------------------------------------------------------------------------
	override void OnMenuUpdate(float tDelta)
	{
		super.OnMenuUpdate(tDelta);
		InputManager im = GetGame().GetInputManager();
		if (!im) return;

		if (im.GetActionValue("MenuBack") > 0.5)
		{
			CloseMenuInternal();
			return;
		}

		// Pontage manette directionnel : la nav spatiale Enfusion a du mal a traverser les grandes
		// distances entre panneau gauche (preview + 3 boutons action) et colonne droite (liste),
		// et entre les sections verticales (barre haute Fermer / contenu / barre basse Clef vierge).
		// On intercepte explicitement les 4 directions avec edge-detect pour router au bon widget.
		bool navLeft = im.GetActionValue("MenuLeft") > 0.5;
		bool navRight = im.GetActionValue("MenuRight") > 0.5;
		bool navUp = im.GetActionValue("MenuUp") > 0.5;
		bool navDown = im.GetActionValue("MenuDown") > 0.5;

		// VERROU : enforce a CHAQUE frame tant que le lock est actif.
		//   - Lock permanent : enforce indefiniment jusqu au prochain QueueFocus (qui change la cible).
		//     Utilise pour les boutons action, ou l engine ne doit JAMAIS pouvoir sauter un cran.
		//   - Lock temporaire : enforce pendant m_NavLockFrames frames puis libere (pour Row buttons).
		if (m_NavLockTarget)
		{
			Widget cur = GetGame().GetWorkspace().GetFocusedWidget();
			if (cur != m_NavLockTarget)
				GetGame().GetWorkspace().SetFocusedWidget(m_NavLockTarget);

			if (!m_NavLockPermanent)
			{
				m_NavLockFrames--;
				if (m_NavLockFrames <= 0)
					m_NavLockTarget = null;
			}
		}

		if (navLeft && !m_NavLeftPrev) HandleNavLeft();
		if (navRight && !m_NavRightPrev) HandleNavRight();
		if (navUp && !m_NavUpPrev) HandleNavUp();
		if (navDown && !m_NavDownPrev) HandleNavDown();
		m_NavLeftPrev = navLeft;
		m_NavRightPrev = navRight;
		m_NavUpPrev = navUp;
		m_NavDownPrev = navDown;
	}

	//------------------------------------------------------------------------------------------------
	// Helper : queue un SetFocusedWidget qui s executera APRES la nav native engine (meme frame)
	// + enregistre un verrou qui re-force le focus sur la cible pendant quelques frames tant que
	// le DPad reste presse. Combo : CallLater(0) bat la nav native sur la premiere frame, et le
	// verrou dans OnMenuUpdate bat le repeat-timer de l engine sur les frames suivantes.
	//------------------------------------------------------------------------------------------------
	void QueueFocus(Widget target)
	{
		if (!target) return;
		m_PendingFocus = target;
		m_NavLockTarget = target;

		// Determine le type de lock : permanent sur boutons action/Close/BlankKey, temporaire sur Row.
		// Les boutons action doivent avoir un lock permanent car la nav native engine saute des
		// crans a chaque appui DPad maintenu. Pour les Row buttons on veut que la nav native
		// puisse naviguer la liste librement apres l atterissage initial.
		bool isActionBtn = (target == m_BtnRetrieve || target == m_BtnTransfer
			|| target == m_BtnInsureRetrieve || target == m_BtnClose || target == m_BtnBlankKey);
		m_NavLockPermanent = isActionBtn;
		m_NavLockFrames = 20; // pour lock temporaire (Row buttons, pagination)

		GetGame().GetCallqueue().CallLater(ApplyPendingFocus, 0, false);
	}

	void ApplyPendingFocus()
	{
		if (m_PendingFocus)
		{
			GetGame().GetWorkspace().SetFocusedWidget(m_PendingFocus);
			m_PendingFocus = null;
		}
	}

	//------------------------------------------------------------------------------------------------
	// NAV MANETTE : les 3 boutons action sont desormais empiles VERTICALEMENT (Retrieve/Transfer/
	// Insure). La nav native engine traverse DPad haut/bas de maniere parfaitement fiable sur une
	// liste verticale, donc on NE touche PAS aux transitions entre eux. On intercepte seulement
	// les SAUTS entre sections (gauche/droite entre liste et colonne action, et les sorties
	// haut/bas vers Close/BlankKey/pagination).
	//------------------------------------------------------------------------------------------------

	//------------------------------------------------------------------------------------------------
	// DPad gauche : pont vers la colonne de boutons action (depuis la liste de droite)
	//------------------------------------------------------------------------------------------------
	void HandleNavLeft()
	{
		Widget focused = GetGame().GetWorkspace().GetFocusedWidget();
		if (!focused) return;

		if (IsRowButton(focused))
		{
			// Depuis une ligne de la liste, atterris sur Transferer (bouton du milieu de la colonne)
			Widget target = null;
			if (m_BtnTransfer && m_BtnTransfer.IsVisible()) target = m_BtnTransfer;
			else if (m_BtnRetrieve && m_BtnRetrieve.IsVisible()) target = m_BtnRetrieve;
			else if (m_BtnInsureRetrieve && m_BtnInsureRetrieve.IsVisible()) target = m_BtnInsureRetrieve;
			QueueFocus(target);
			return;
		}
	}

	//------------------------------------------------------------------------------------------------
	// DPad droit : pont vers la liste de droite (depuis les boutons action a gauche)
	//------------------------------------------------------------------------------------------------
	void HandleNavRight()
	{
		Widget focused = GetGame().GetWorkspace().GetFocusedWidget();
		if (!focused) return;

		if (focused == m_BtnRetrieve || focused == m_BtnTransfer || focused == m_BtnInsureRetrieve
			|| focused == m_BtnBlankKey)
		{
			QueueFocus(GetFirstRowButton());
			return;
		}
	}

	//------------------------------------------------------------------------------------------------
	// DPad haut : mapping explicite COMPLET pour la colonne gauche
	//   BtnClose <- BtnRetrieve <- BtnTransfer <- BtnInsureRetrieve <- BtnBlankKey
	//   BtnPrevPage / BtnNextPage -> derniere ligne de la liste
	//   Row buttons : nav native dans la liste
	//------------------------------------------------------------------------------------------------
	void HandleNavUp()
	{
		Widget focused = GetGame().GetWorkspace().GetFocusedWidget();
		if (!focused) return;

		if (focused == m_BtnBlankKey) { QueueFocus(m_BtnInsureRetrieve); return; }
		if (focused == m_BtnInsureRetrieve) { QueueFocus(m_BtnTransfer); return; }
		if (focused == m_BtnTransfer) { QueueFocus(m_BtnRetrieve); return; }
		if (focused == m_BtnRetrieve) { QueueFocus(m_BtnClose); return; }
	}

	//------------------------------------------------------------------------------------------------
	// DPad bas : mapping explicite COMPLET pour la colonne gauche
	//   BtnClose -> BtnRetrieve -> BtnTransfer -> BtnInsureRetrieve -> BtnBlankKey
	//   RowButton derniere ligne -> BtnPrevPage (si pagination visible)
	//   Autres Row buttons : nav native dans la liste
	//------------------------------------------------------------------------------------------------
	void HandleNavDown()
	{
		Widget focused = GetGame().GetWorkspace().GetFocusedWidget();
		if (!focused) return;

		if (focused == m_BtnClose) { QueueFocus(m_BtnRetrieve); return; }
		if (focused == m_BtnRetrieve) { QueueFocus(m_BtnTransfer); return; }
		if (focused == m_BtnTransfer) { QueueFocus(m_BtnInsureRetrieve); return; }
		if (focused == m_BtnInsureRetrieve) { QueueFocus(m_BtnBlankKey); return; }
	}

	//------------------------------------------------------------------------------------------------
	// Vrai si le widget focused est un RowButton (bouton d une ligne vehicule de la liste droite).
	//------------------------------------------------------------------------------------------------
	bool IsRowButton(Widget w)
	{
		if (!w) return false;
		return w.GetName() == "RowButton";
	}

	//------------------------------------------------------------------------------------------------
	// Retourne le RowButton de la DERNIERE ligne visible (pour DPad bas depuis liste -> pagination)
	//------------------------------------------------------------------------------------------------
	Widget GetLastRowButton()
	{
		if (!m_EntriesContainer) return null;
		Widget child = m_EntriesContainer.GetChildren();
		Widget last = null;
		while (child)
		{
			Widget b = child.FindAnyWidget("RowButton");
			if (b) last = b;
			child = child.GetSibling();
		}
		return last;
	}

	//------------------------------------------------------------------------------------------------
	//------------------------------------------------------------------------------------------------
	// Rebuild complet de la liste (plus de pagination : toutes les entrees, scroll via ScrollLayoutWidget)
	//------------------------------------------------------------------------------------------------
	void RebuildEntries()
	{
		if (!m_EntriesContainer) return;

		Widget child = m_EntriesContainer.GetChildren();
		while (child)
		{
			Widget next = child.GetSibling();
			child.RemoveFromHierarchy();
			child = next;
		}

		int total = s_PendingIndexes.Count();

		if (total == 0)
		{
			if (m_EmptyText)
			{
				m_EmptyText.SetText("Vous n'avez aucun vehicule stocke.");
				m_EmptyText.SetVisible(true);
			}
			SetActionButtonsEnabled(false);
			if (m_SelectedTitle) m_SelectedTitle.SetText("Aucun vehicule");
			if (m_SelectedInfo) m_SelectedInfo.SetText("");
			return;
		}

		if (m_EmptyText) m_EmptyText.SetVisible(false);

		WorkspaceWidget ws = GetGame().GetWorkspace();
		if (!ws) return;

		for (int i = 0; i < total; i++)
		{
			Widget row = ws.CreateWidgets(ROW_LAYOUT_PATH, m_EntriesContainer);
			if (!row) continue;

			string prefab = s_PendingPrefabs.Get(i);
			string displayName = ExtractVehicleDisplayName(prefab);
			bool isInsured = false;
			if (i < s_PendingInsured.Count()) isInsured = s_PendingInsured.Get(i);

			string insLabel = "Non assure";
			if (isInsured) insLabel = "ASSURE";

			// Degats : nombre de zones endommagees (lu depuis m_Damaged, paralele aux indexes)
			string dmgLabel = "Intact";
			if (i < m_Damaged.Count())
			{
				int dCount = m_Damaged.Get(i);
				if (dCount > 0) dmgLabel = dCount.ToString() + " zone(s) endommagee(s)";
			}

			// Fuel : litres restants
			string fuelLabel = "? L";
			if (i < m_Fuels.Count())
			{
				int fL = m_Fuels.Get(i);
				if (fL >= 0) fuelLabel = fL.ToString() + " L";
			}

			// Mode Fourriere : prepend le nom RP du proprietaire original
			string middleText = fuelLabel + "  |  " + dmgLabel + "  |  " + insLabel;
			if (m_IsFourriereMode && i < m_OwnerNames.Count())
			{
				string ownerName = m_OwnerNames.Get(i);
				if (ownerName != "")
					middleText = "Proprio: " + ownerName + "  |  " + fuelLabel + "  |  " + dmgLabel + "  |  " + insLabel;
			}

			FillRowCols(row,
				(i + 1).ToString(),
				displayName,
				middleText,
				"Voir");

			ButtonWidget rowBtn = ButtonWidget.Cast(row.FindAnyWidget("RowButton"));
			if (rowBtn)
			{
				VgRowHandler rh = new VgRowHandler();
				rh.m_Menu = this;
				rh.m_Index = i;
				rowBtn.AddHandler(rh);
				JobFocusHandler.Attach(rowBtn);
			}
		}
	}

	//------------------------------------------------------------------------------------------------
	void FillRowCols(Widget row, string colId, string colName, string colMiddle, string colRight)
	{
		if (!row) return;
		TextWidget ti = TextWidget.Cast(row.FindAnyWidget("ColId"));
		TextWidget tn = TextWidget.Cast(row.FindAnyWidget("ColName"));
		TextWidget tm = TextWidget.Cast(row.FindAnyWidget("ColMiddle"));
		TextWidget tr = TextWidget.Cast(row.FindAnyWidget("ColRight"));
		if (ti) ti.SetText(colId);
		if (tn) tn.SetText(colName);
		if (tm) tm.SetText(colMiddle);
		if (tr) tr.SetText(colRight);
	}

	//------------------------------------------------------------------------------------------------
	// Selectionne un vehicule : met a jour le preview 3D, le titre, l info et active les boutons.
	//------------------------------------------------------------------------------------------------
	void SelectVehicle(int index)
	{
		if (index < 0 || index >= s_PendingIndexes.Count()) return;
		m_SelectedIndex = index;

		string prefab = s_PendingPrefabs.Get(index);
		string displayName = ExtractVehicleDisplayName(prefab);
		bool isInsured = false;
		if (index < s_PendingInsured.Count()) isInsured = s_PendingInsured.Get(index);

		if (m_SelectedTitle) m_SelectedTitle.SetText(displayName);

		if (m_SelectedInfo)
		{
			string insTxt = "Non assure";
			if (isInsured) insTxt = "ASSURE";
			string dmgTxt = "Intact";
			if (index < m_Damaged.Count())
			{
				int dC = m_Damaged.Get(index);
				if (dC > 0) dmgTxt = dC.ToString() + " zone(s) endommagee(s)";
			}
			string fuelTxt = "? L";
			if (index < m_Fuels.Count())
			{
				int fL = m_Fuels.Get(index);
				if (fL >= 0) fuelTxt = fL.ToString() + " L";
			}
			string info = "Carburant : " + fuelTxt + "\nEtat : " + dmgTxt + "\nAssurance : " + insTxt;
			if (m_IsFourriereMode && index < m_OwnerNames.Count())
			{
				string ownerName = m_OwnerNames.Get(index);
				if (ownerName != "")
					info = "Proprietaire : " + ownerName + "\n" + info;
			}
			m_SelectedInfo.SetText(info);
		}

		if (m_GaragePreviewWidget && prefab != "")
		{
			ItemPreviewManagerEntity mgr = GetPreviewManager();
			if (mgr)
				mgr.SetPreviewItemFromPrefab(m_GaragePreviewWidget, prefab, null, false);
		}

		SetActionButtonsEnabled(true);
	}

	//------------------------------------------------------------------------------------------------
	// Active ou grise les boutons d action (Recuperer / Transferer / Assurer)
	//------------------------------------------------------------------------------------------------
	void SetActionButtonsEnabled(bool enabled)
	{
		Color grayColor = Color.FromRGBA(60, 60, 70, 180);
		if (m_BtnRetrieve)
		{
			if (enabled) m_BtnRetrieve.SetColor(Color.FromRGBA(64, 141, 77, 255));
			else m_BtnRetrieve.SetColor(grayColor);
		}
		if (m_BtnTransfer)
		{
			if (enabled) m_BtnTransfer.SetColor(Color.FromRGBA(77, 102, 166, 255));
			else m_BtnTransfer.SetColor(grayColor);
		}
		if (m_BtnInsureRetrieve)
		{
			if (enabled) m_BtnInsureRetrieve.SetColor(Color.FromRGBA(242, 179, 26, 255));
			else m_BtnInsureRetrieve.SetColor(grayColor);
		}
	}

	//------------------------------------------------------------------------------------------------
	ItemPreviewManagerEntity GetPreviewManager()
	{
		if (m_PreviewManager) return m_PreviewManager;
		BaseWorld world = GetGame().GetWorld();
		if (!world) return null;
		IEntity entity = world.FindEntityByName("ItemPreviewManagerEntity");
		if (entity) m_PreviewManager = ItemPreviewManagerEntity.Cast(entity);
		return m_PreviewManager;
	}

	//------------------------------------------------------------------------------------------------
	string ExtractVehicleDisplayName(string prefab)
	{
		int lastSlash = -1;
		for (int i = prefab.Length() - 1; i >= 0; i--)
		{
			if (prefab.Get(i) == "/")
			{
				lastSlash = i;
				break;
			}
		}
		string name;
		if (lastSlash >= 0 && lastSlash + 1 < prefab.Length())
			name = prefab.Substring(lastSlash + 1, prefab.Length() - lastSlash - 1);
		else
			name = prefab;
		if (name.Length() > 3)
		{
			string suffix = name.Substring(name.Length() - 3, 3);
			if (suffix == ".et")
				name = name.Substring(0, name.Length() - 3);
		}
		return name;
	}

	//------------------------------------------------------------------------------------------------
	// Dispatcher central des actions boutons (reduit le nombre de classes handler)
	//------------------------------------------------------------------------------------------------
	void OnActionClicked(string action)
	{
		if (action == "close") { CloseMenuInternal(); return; }

		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;

		if (action == "blankkey")
		{
			jpc.ClientAskBlankKey();
			return;
		}

		// Actions sur le vehicule selectionne : exige une selection
		if (m_SelectedIndex < 0 || m_SelectedIndex >= s_PendingIndexes.Count())
		{
			if (m_SelectedInfo)
				m_SelectedInfo.SetText("Selectionnez d abord un vehicule dans la liste a droite.");
			return;
		}

		int garageIndex = s_PendingIndexes.Get(m_SelectedIndex);
		string prefab = s_PendingPrefabs.Get(m_SelectedIndex);
		string displayName = ExtractVehicleDisplayName(prefab);

		if (action == "retrieve")
		{
			if (m_IsFourriereMode)
				jpc.ClientAskFourriereRetrieveVehicle(s_PendingNpcRplId, garageIndex);
			else
				jpc.ClientAskRetrieveVehicle(s_PendingNpcRplId, garageIndex);
			CloseMenuInternal();
			return;
		}

		if (action == "transfer")
		{
			JobGarageTransferMenu.SetPendingGarageIndex(garageIndex);
			JobGarageTransferMenu.SetPendingVehicleName(displayName);
			CloseMenuInternal();
			GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.JobGarageTransferMenu);
			return;
		}

		if (action == "insure")
		{
			JobInsuranceConfirmMenu.SetPendingData(garageIndex, s_PendingNpcRplId, displayName);
			CloseMenuInternal();
			GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.JobInsuranceConfirmMenu);
			return;
		}
	}

	//------------------------------------------------------------------------------------------------
	void CloseMenuInternal()
	{
		GetGame().GetMenuManager().CloseMenu(this);
	}

	static JobVirtualGarageMenu GetOpenMenu() { return s_Instance; }
}

//------------------------------------------------------------------------------------------------
// Handler central : chaque action est identifiee par une string, dispatchee par OnActionClicked.
//------------------------------------------------------------------------------------------------
class VgSimpleHandler : ScriptedWidgetEventHandler
{
	JobVirtualGarageMenu m_Menu;
	string m_Action;

	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.OnActionClicked(m_Action);
		return true;
	}
}

//------------------------------------------------------------------------------------------------
// Clic sur une ligne vehicule -> SelectVehicle(index) qui met a jour preview + info
//------------------------------------------------------------------------------------------------
class VgRowHandler : ScriptedWidgetEventHandler
{
	JobVirtualGarageMenu m_Menu;
	int m_Index;

	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.SelectVehicle(m_Index);
		return true;
	}
}
