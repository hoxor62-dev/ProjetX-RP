//------------------------------------------------------------------------------------------------
// JobGoldCurrencyHelper.c
// Helpers serveur-side pour gerer les lingots d or comme devise alternative aux capsules.
// Utilise notamment par les 4 shops Voyou (CAC, Point, Fusil, Mitraillette).
//
// La constante du GUID lingot est definie dans JobGoldCurrency (dans JobShopCatalog.c)
//------------------------------------------------------------------------------------------------

class JobGoldCurrencyHelper
{
	//------------------------------------------------------------------------------------------------
	// Compte le nombre de lingots d or dans l inventaire du joueur
	//------------------------------------------------------------------------------------------------
	static int CountGoldBars(int playerId)
	{
		PlayerController pc = GetGame().GetPlayerManager().GetPlayerController(playerId);
		if (!pc) return 0;
		IEntity playerEntity = pc.GetControlledEntity();
		if (!playerEntity) return 0;
		
		SCR_InventoryStorageManagerComponent invMgr = SCR_InventoryStorageManagerComponent.Cast(
			playerEntity.FindComponent(SCR_InventoryStorageManagerComponent));
		if (!invMgr) return 0;
		
		array<IEntity> items = new array<IEntity>();
		invMgr.GetItems(items);
		
		int count = 0;
		foreach (IEntity item : items)
		{
			if (!item) continue;
			EntityPrefabData pd = item.GetPrefabData();
			if (!pd) continue;
			if (pd.GetPrefabName() == JobGoldCurrency.LINGOT_OR_PREFAB)
				count++;
		}
		return count;
	}
	
	//------------------------------------------------------------------------------------------------
	// Retire N lingots d or de l inventaire du joueur.
	// Retourne le nombre reellement retire (0 si erreur, n si OK).
	//------------------------------------------------------------------------------------------------
	static int RemoveGoldBars(int playerId, int count)
	{
		if (count <= 0) return 0;
		PlayerController pc = GetGame().GetPlayerManager().GetPlayerController(playerId);
		if (!pc) return 0;
		IEntity playerEntity = pc.GetControlledEntity();
		if (!playerEntity) return 0;
		
		SCR_InventoryStorageManagerComponent invMgr = SCR_InventoryStorageManagerComponent.Cast(
			playerEntity.FindComponent(SCR_InventoryStorageManagerComponent));
		if (!invMgr) return 0;
		
		array<IEntity> items = new array<IEntity>();
		invMgr.GetItems(items);
		
		// Collecte d abord les entites a supprimer
		array<IEntity> toRemove = new array<IEntity>();
		foreach (IEntity item : items)
		{
			if (toRemove.Count() >= count) break;
			if (!item) continue;
			EntityPrefabData pd = item.GetPrefabData();
			if (!pd) continue;
			if (pd.GetPrefabName() == JobGoldCurrency.LINGOT_OR_PREFAB)
				toRemove.Insert(item);
		}
		
		// Supprime les entites collectees
		int removed = 0;
		foreach (IEntity item : toRemove)
		{
			if (!item) continue;
			SCR_EntityHelper.DeleteEntityAndChildren(item);
			removed++;
		}
		return removed;
	}
	
	//------------------------------------------------------------------------------------------------
	// Donne N lingots d or au joueur (spawn dans l inventaire).
	// Utilise notamment pour le rollback si un achat echoue.
	// Retourne le nombre reellement donne.
	//------------------------------------------------------------------------------------------------
	static int GiveGoldBars(int playerId, int count)
	{
		if (count <= 0) return 0;
		PlayerController pc = GetGame().GetPlayerManager().GetPlayerController(playerId);
		if (!pc) return 0;
		IEntity playerEntity = pc.GetControlledEntity();
		if (!playerEntity) return 0;
		
		SCR_InventoryStorageManagerComponent invMgr = SCR_InventoryStorageManagerComponent.Cast(
			playerEntity.FindComponent(SCR_InventoryStorageManagerComponent));
		if (!invMgr) return 0;
		
		ResourceName rn = JobGoldCurrency.LINGOT_OR_PREFAB;
		int given = 0;
		for (int i = 0; i < count; i++)
		{
			bool ok = invMgr.TrySpawnPrefabToStorage(rn);
			if (!ok)
				break;
			given++;
		}
		return given;
	}
	
	//------------------------------------------------------------------------------------------------
	// Helper : verifie si un EJobType est un shop Voyou en lingots d or
	//------------------------------------------------------------------------------------------------
	static bool IsVoyouGoldShop(EJobType shop)
	{
		return (shop == EJobType.SHOP_VOYOU_CAC
			|| shop == EJobType.SHOP_VOYOU_POINT
			|| shop == EJobType.SHOP_VOYOU_FUSIL
			|| shop == EJobType.SHOP_VOYOU_MITRAILLETTE);
	}
}
