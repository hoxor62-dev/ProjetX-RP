//------------------------------------------------------------------------------------------------
// LP_DoorData.c
// Struct de donnees pour une porte dont l acces a ete achete par un joueur.
//
// IDENTIFICATION STABLE :
//   La cle unique = prefabName + posX + posY + posZ (arrondis a l entier).
//   Le RplId change a chaque reboot serveur, il n est PAS persistant.
//   La position + le nom du prefab identifient de maniere absolue une porte donnee.
//------------------------------------------------------------------------------------------------

class LP_DoorData
{
	string m_DoorKey;                // cle unique persistante (prefab + xyz arrondi)
	string m_PrefabName;             // nom du prefab (ex: Door_Base)
	vector m_Position;               // position XYZ de la porte
	string m_OwnerUID;               // UID du proprietaire
	string m_OwnerDisplayName;       // nom affichage (cache)
	string m_ShareCode;              // "" ou "1234" (4 chiffres)
	ref array<string> m_KnownPlayerUIDs = new array<string>();
	int m_PurchaseUnix;
	int m_PurchasePrice;
	
	void LP_DoorData()
	{
		m_KnownPlayerUIDs = new array<string>();
	}
	
	//------------------------------------------------------------------------------------------------
	// Construit la cle stable a partir du prefab + position arrondie a l entier.
	// La position arrondie evite les erreurs de precision float entre 2 boots.
	//------------------------------------------------------------------------------------------------
	static string BuildDoorKey(string prefabName, vector pos)
	{
		int x = pos[0];
		int y = pos[1];
		int z = pos[2];
		return prefabName + "_" + x.ToString() + "_" + y.ToString() + "_" + z.ToString();
	}
	
	//------------------------------------------------------------------------------------------------
	bool IsOwner(string uid)
	{
		return uid != "" && uid == m_OwnerUID;
	}
	
	//------------------------------------------------------------------------------------------------
	bool KnowsCode(string uid)
	{
		if (uid == "") return false;
		foreach (string knownUid : m_KnownPlayerUIDs)
		{
			if (knownUid == uid) return true;
		}
		return false;
	}
	
	//------------------------------------------------------------------------------------------------
	bool CanUseDoor(string uid)
	{
		return IsOwner(uid) || KnowsCode(uid);
	}
	
	//------------------------------------------------------------------------------------------------
	void AddKnownPlayer(string uid)
	{
		if (uid == "" || KnowsCode(uid)) return;
		m_KnownPlayerUIDs.Insert(uid);
	}
	
	//------------------------------------------------------------------------------------------------
	void ClearKnownPlayers()
	{
		m_KnownPlayerUIDs.Clear();
	}
}
