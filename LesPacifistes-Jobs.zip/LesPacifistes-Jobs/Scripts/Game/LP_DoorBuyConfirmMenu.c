//------------------------------------------------------------------------------------------------
// LP_DoorBuyConfirmMenu.c
// Popup client presente a l acheteur : "X vous propose l acces a une porte pour Y capsules".
//------------------------------------------------------------------------------------------------

class LP_DoorBuyConfirmMenu : ChimeraMenuBase
{
	Widget m_Root;
	RichTextWidget m_OfferText;
	TextWidget m_BalanceText;
	ButtonWidget m_BtnAccept;
	ButtonWidget m_BtnRefuse;
	
	RplId m_DoorRplId = RplId.Invalid();
	string m_SellerName = "";
	int m_Price = 0;
	int m_Balance = 0;
	
	static LP_DoorBuyConfirmMenu s_Instance;
	
	// Bridge static : le RPC serveur remplit ces valeurs avant OpenMenu.
	// Le menu consomme au OnMenuOpen.
	static RplId s_PendingRplId = RplId.Invalid();
	static string s_PendingSellerName = "";
	static int s_PendingPrice = 0;
	static int s_PendingBalance = 0;
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuOpen()
	{
		super.OnMenuOpen();
		s_Instance = this;
		JobFocusHandler.ClearRegistry();
		
		// Consomme les valeurs pending
		if (s_PendingRplId.IsValid())
		{
			m_DoorRplId = s_PendingRplId;
			m_SellerName = s_PendingSellerName;
			m_Price = s_PendingPrice;
			m_Balance = s_PendingBalance;
			s_PendingRplId = RplId.Invalid();
			s_PendingSellerName = "";
			s_PendingPrice = 0;
			s_PendingBalance = 0;
		}
		
		m_Root = GetRootWidget();
		if (!m_Root) return;
		
		m_OfferText = RichTextWidget.Cast(m_Root.FindAnyWidget("OfferText"));
		m_BalanceText = TextWidget.Cast(m_Root.FindAnyWidget("BalanceText"));
		m_BtnAccept = ButtonWidget.Cast(m_Root.FindAnyWidget("BtnAccept"));
		m_BtnRefuse = ButtonWidget.Cast(m_Root.FindAnyWidget("BtnRefuse"));
		
		AttachBtn(m_BtnAccept, "accept");
		AttachBtn(m_BtnRefuse, "refuse");
		
		UpdateDisplay();
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuClose()
	{
		if (s_Instance == this) s_Instance = null;
		super.OnMenuClose();
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuUpdate(float tDelta)
	{
		super.OnMenuUpdate(tDelta);
		// Volontairement pas de MenuBack : le joueur doit choisir Accepter/Refuser
	}
	
	//------------------------------------------------------------------------------------------------
	void AttachBtn(ButtonWidget btn, string action)
	{
		if (!btn) return;
		LP_DoorBuyBtnHandler h = new LP_DoorBuyBtnHandler();
		h.m_Menu = this;
		h.m_Action = action;
		btn.AddHandler(h);
		JobFocusHandler.Attach(btn);
	}
	
	//------------------------------------------------------------------------------------------------
	void ConfigureOffer(RplId doorRplId, string sellerName, int price, int balance)
	{
		m_DoorRplId = doorRplId;
		m_SellerName = sellerName;
		m_Price = price;
		m_Balance = balance;
		UpdateDisplay();
	}
	
	//------------------------------------------------------------------------------------------------
	void UpdateDisplay()
	{
		if (m_OfferText)
		{
			m_OfferText.SetText(string.Format(
				"%1 vous propose l acces\na une porte pour %2 capsules.",
				m_SellerName, m_Price.ToString()));
		}
		if (m_BalanceText)
		{
			m_BalanceText.SetText(string.Format("Votre solde : %1 capsules", m_Balance.ToString()));
			if (m_Balance < m_Price)
				m_BalanceText.SetColor(Color.FromRGBA(230, 60, 60, 255));
			else
				m_BalanceText.SetColor(Color.FromRGBA(120, 200, 255, 255));
		}
		if (m_BtnAccept) m_BtnAccept.SetEnabled(m_Balance >= m_Price);
	}
	
	//------------------------------------------------------------------------------------------------
	void OnButtonClicked(string action)
	{
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		
		bool accept = (action == "accept");
		jpc.ClientAnswerLpDoorSale(m_DoorRplId, accept);
		CloseMenuInternal();
	}
	
	//------------------------------------------------------------------------------------------------
	void CloseMenuInternal() { GetGame().GetMenuManager().CloseMenu(this); }
	static LP_DoorBuyConfirmMenu GetOpenMenu() { return s_Instance; }
}

class LP_DoorBuyBtnHandler : ScriptedWidgetEventHandler
{
	LP_DoorBuyConfirmMenu m_Menu;
	string m_Action;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.OnButtonClicked(m_Action);
		return true;
	}
}
