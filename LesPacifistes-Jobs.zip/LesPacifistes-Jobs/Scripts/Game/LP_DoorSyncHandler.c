//------------------------------------------------------------------------------------------------
// LP_DoorSyncHandler.c
// Hook GameMode pour resync les LP_DoorAccessComponent quand un joueur se connecte
// ou se deconnecte + LOCK INITIAL de toutes les portes possedees au demarrage serveur.
//
// - Connect  : le joueur reconnecte peut etre proprio d une porte OU dans la whitelist code.
//              On resync tous les composants concernes pour mettre a jour m_OwnerPlayerId
//              et m_KnownPlayerIdsPacked.
// - Disconnect : le playerId n est plus valide. On resync pour retirer les references.
// - Boot serveur : au 1er joueur connecte (le monde est alors garanti charge),
//                  toutes les portes possedees sont automatiquement verrouillees.
//                  Un flag static s_InitialLockDone empeche de refaire le lock plus tard.
//
// Utilise QueryEntitiesByAABB pour retrouver les entites porte.
//------------------------------------------------------------------------------------------------

modded class SCR_BaseGameMode
{
	// Flag static : true apres le premier lock initial (evite de re-lock a chaque connexion)
	static bool s_InitialLockDone = false;
	
	// Flag static : true apres le cleanup des items au sol (une seule fois par boot serveur)
	static bool s_GroundCleanupDone = false;
	
	// Flag static : true apres le restore des coffres (une seule fois par boot serveur)
	static bool s_StorageRestoreDone = false;
	
	// Flag static : true apres le demarrage du timer animal products (une seule fois par boot)
	static bool s_AnimalProductStarted = false;

	// Fuel stations : flag pour n executer la decouverte qu une seule fois.
	static bool s_FuelStationDiscoveryDone = false;
	
	//------------------------------------------------------------------------------------------------
	override void OnPlayerConnected(int playerId)
	{
		super.OnPlayerConnected(playerId);
		if (!Replication.IsServer()) return;
		
		// Delay 2s pour laisser l UID Bohemia arriver
		GetGame().GetCallqueue().CallLater(LP_ResyncPortesJoueur, 2000, false, playerId);
		
		// LOCK INITIAL : au premier joueur connecte, lock toutes les portes possedees.
		// Delay 3s pour etre sur que le monde et les entites soient completement chargees.
		if (!s_InitialLockDone)
		{
			s_InitialLockDone = true;
			GetGame().GetCallqueue().CallLater(LP_LockAllOwnedDoorsOnBoot, 3000, false);
		}
		
		// GROUND CLEANUP : au premier joueur connecte, supprime les items blacklistes au sol.
		// Delay 5s (apres le lock initial, pour ne pas surcharger la boucle a T+3s)
		if (!s_GroundCleanupDone)
		{
			s_GroundCleanupDone = true;
			GetGame().GetCallqueue().CallLater(LP_CleanupGroundItems, 5000, false);
		}
		
		// STORAGE RESTORE : au premier joueur connecte, restore les items disparus dans les coffres.
		// Delay 7s (apres cleanup ground pour ne pas restaurer un item qui vient d etre supprime)
		// puis demarre l auto-save 60s.
		if (!s_StorageRestoreDone)
		{
			s_StorageRestoreDone = true;
			GetGame().GetCallqueue().CallLater(LP_RestoreAndStartStorageSave, 7000, false);
		}
		
		// ANIMAL PRODUCTS : au premier joueur connecte, demarre le timer 3h qui spawn
		// oeufs sur Chicken + lait sur Cow. Delay 9s (dernier de la sequence boot).
		if (!s_AnimalProductStarted)
		{
			s_AnimalProductStarted = true;
			GetGame().GetCallqueue().CallLater(LP_StartAnimalProductTicker, 9000, false);
		}

		// FUEL STATIONS : au premier joueur connecte, decouvre toutes les stations essence
		// (prefab FuelStation_E_01_tankpistol) et bootstrap leur jauge en memoire.
		// Delay 11s pour laisser les entites de la map se charger.
		if (!s_FuelStationDiscoveryDone)
		{
			s_FuelStationDiscoveryDone = true;
			GetGame().GetCallqueue().CallLater(LP_DiscoverFuelStations, 11000, false);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnPlayerDisconnected(int playerId, KickCauseCode cause, int timeout)
	{
		super.OnPlayerDisconnected(playerId, cause, timeout);
		if (!Replication.IsServer()) return;
		
		// Resync immediat pour retirer le playerId des composants
		LP_ResyncPortesJoueur(playerId);
	}
	
	//------------------------------------------------------------------------------------------------
	// Resync tous les composants LP_DoorAccessComponent pour un joueur donne.
	// OPTIMISATION : utilise le cache d entites de LP_DoorManager (m_DoorEntitiesByKey)
	// au lieu de scanner tout le monde (QueryEntitiesByAABB avec bornes 99999).
	//
	// Le cache est peuple au boot par LP_LockAllOwnedDoorsOnBoot (scan unique)
	// et mis a jour par PurchaseDoor (nouvel achat).
	//
	// AVANT : ~50 000 entites parcourues avec FindComponent = ~1s de freeze mainthread
	// APRES : ~N portes (30-100 typiquement) direct depuis le cache = quasi instantane
	//------------------------------------------------------------------------------------------------
	void LP_ResyncPortesJoueur(int playerId)
	{
		if (!Replication.IsServer()) return;
		
		LP_DoorManager mgr = LP_DoorManager.GetInstance();
		if (!mgr) return;
		
		array<IEntity> doors = mgr.GetAllRegisteredDoorEntities();
		foreach (IEntity doorEntity : doors)
		{
			if (!doorEntity) continue;
			LP_DoorData door = mgr.FindDoorByEntity(doorEntity);
			if (!door) continue;
			mgr.SyncDoorComponentByEntity(doorEntity, door);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// LOCK INITIAL au boot serveur.
	// Verrouille toutes les portes qui ont un proprietaire (present dans LP_DoorManager).
	// Appele une seule fois via s_InitialLockDone.
	//
	// OPTIMISATION : peuple aussi le cache d entites (m_DoorEntitiesByKey) pendant ce scan.
	// Ainsi les futurs LP_ResyncPortesJoueur (a chaque connexion) evitent de rescanner
	// le monde entier - ils utilisent le cache directement.
	//------------------------------------------------------------------------------------------------
	void LP_LockAllOwnedDoorsOnBoot()
	{
		if (!Replication.IsServer()) return;
		
		BaseWorld world = GetGame().GetWorld();
		if (!world) return;
		
		// Force le chargement du manager (LoadFromDisk lazy) si pas deja fait
		LP_DoorManager mgr = LP_DoorManager.GetInstance();
		if (!mgr) return;
		
		LP_DoorSyncCollector collector = new LP_DoorSyncCollector();
		world.QueryEntitiesByAABB("-99999 -99999 -99999", "99999 99999 99999", collector.OnEntity);
		
		int lockedCount = 0;
		int cachedCount = 0;
		foreach (IEntity doorEntity : collector.m_Doors)
		{
			if (!doorEntity) continue;
			LP_DoorData door = mgr.FindDoorByEntity(doorEntity);
			if (!door) continue; // porte pas possedee -> laisser vanilla
			
			// Enregistre l entite dans le cache runtime pour eviter rescans futurs
			mgr.RegisterDoorEntity(door.m_DoorKey, doorEntity);
			cachedCount = cachedCount + 1;
			
			LP_DoorAccessComponent access = LP_DoorAccessComponent.Cast(
				doorEntity.FindComponent(LP_DoorAccessComponent));
			if (!access) continue;
			
			// Verrouille + sync composant (proprio + code connus)
			access.ServerSetLocked(true);
			mgr.SyncDoorComponentByEntity(doorEntity, door);
			lockedCount = lockedCount + 1;
		}
		
		Print(string.Format("[LP_DoorSyncHandler] Lock initial : %1 porte(s) verrouillee(s), %2 entite(s) cachee(s) au boot serveur.",
			lockedCount.ToString(), cachedCount.ToString()), LogLevel.NORMAL);
	}
	
	//------------------------------------------------------------------------------------------------
	// CLEANUP GROUND ITEMS au boot serveur.
	// Parcourt toutes les entites, supprime celles de la blacklist qui trainent au sol
	// (GetParent() == null = pas dans un inventaire / coffre / equipe).
	// Vehicules, portes, batiments non concernes (pas dans la blacklist).
	//------------------------------------------------------------------------------------------------
	void LP_CleanupGroundItems()
	{
		if (!Replication.IsServer()) return;
		
		BaseWorld world = GetGame().GetWorld();
		if (!world) return;
		
		LP_GroundItemBlacklist.EnsureLoaded();
		
		LP_GroundItemCleanupCollector collector = new LP_GroundItemCleanupCollector();
		world.QueryEntitiesByAABB("-99999 -99999 -99999", "99999 99999 99999", collector.OnEntity);
		
		int deletedCount = 0;
		foreach (IEntity ent : collector.m_ToDelete)
		{
			if (!ent) continue;
			SCR_EntityHelper.DeleteEntityAndChildren(ent);
			deletedCount = deletedCount + 1;
		}
		
		Print(string.Format("[LP_GroundCleanup] Nettoyage boot : %1 item(s) supprime(s) au sol.",
			deletedCount.ToString()), LogLevel.NORMAL);
	}
	
	//------------------------------------------------------------------------------------------------
	// STORAGE RESTORE au boot serveur + demarrage auto-save 60s.
	// Compare les snapshots persistes vs l inventaire actuel des coffres, spawn les items disparus.
	//------------------------------------------------------------------------------------------------
	void LP_RestoreAndStartStorageSave()
	{
		if (!Replication.IsServer()) return;
		StorageSaveManager mgr = StorageSaveManager.GetInstance();
		if (!mgr) return;
		mgr.RestoreAll();
		mgr.StartAutoSave();
	}
	
	//------------------------------------------------------------------------------------------------
	// FUEL STATIONS : decouvre les stations essence du monde au boot, bootstrap la cache
	// de JobFuelStationManager (positions + jauges, 150L par defaut pour les nouvelles).
	//------------------------------------------------------------------------------------------------
	void LP_DiscoverFuelStations()
	{
		if (!Replication.IsServer()) return;
		JobFuelStationManager mgr = JobFuelStationManager.GetInstance();
		if (!mgr) return;
		mgr.DiscoverAllStations();
	}

	//------------------------------------------------------------------------------------------------
	// ANIMAL PRODUCTS : demarre le timer 3h qui spawn oeufs sur Chicken + lait sur Cow.
	//------------------------------------------------------------------------------------------------
	void LP_StartAnimalProductTicker()
	{
		if (!Replication.IsServer()) return;
		LP_AnimalProductManager.GetInstance().StartTicker();
	}
}

//------------------------------------------------------------------------------------------------
// Collecteur d entites ayant un LP_DoorAccessComponent
//------------------------------------------------------------------------------------------------
class LP_DoorSyncCollector
{
	ref array<IEntity> m_Doors = new array<IEntity>();
	
	bool OnEntity(IEntity entity)
	{
		if (!entity) return true;
		LP_DoorAccessComponent access = LP_DoorAccessComponent.Cast(
			entity.FindComponent(LP_DoorAccessComponent));
		if (access) m_Doors.Insert(entity);
		return true;
	}
}
