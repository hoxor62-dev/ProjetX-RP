//------------------------------------------------------------------------------------------------
// LP_AvocatCheckPropertyMenu.c
// Menu de consultation des proprietes pour le metier AVOCAT.
// Le joueur tape un nom / prenom RP et le systeme recherche cote serveur les proprietes.
//------------------------------------------------------------------------------------------------

class LP_AvocatCheckPropertyMenu : ChimeraMenuBase
{
	static LP_AvocatCheckPropertyMenu s_Instance;
	static LP_AvocatCheckPropertyMenu GetOpenMenu() { return s_Instance; }
	
	Widget m_Root;
	TextWidget m_TitleText;
	EditBoxWidget m_SearchInput;
	ButtonWidget m_BtnSearch;
	ButtonWidget m_BtnClose;
	Widget m_ResultsContainer;
	TextWidget m_StatusText;
	
	// Etat des resultats (recu par RPC serveur)
	ref array<string> m_ResultOwnerNames = new array<string>();  // "Prenom Nom"
	ref array<string> m_ResultCoords = new array<string>();      // "(X, Y, Z)"
	ref array<string> m_ResultDates = new array<string>();       // date achat formatee
	ref array<string> m_ResultDoorKeys = new array<string>();    // cle porte (info debug)
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuOpen()
	{
		super.OnMenuOpen();
		s_Instance = this;
		JobFocusHandler.ClearRegistry();
		m_Root = GetRootWidget();
		if (!m_Root) return;
		
		m_TitleText        = TextWidget.Cast(m_Root.FindAnyWidget("TitleText"));
		m_SearchInput      = EditBoxWidget.Cast(m_Root.FindAnyWidget("SearchInput"));
		m_BtnSearch        = ButtonWidget.Cast(m_Root.FindAnyWidget("BtnSearch"));
		m_BtnClose         = ButtonWidget.Cast(m_Root.FindAnyWidget("BtnClose"));
		m_ResultsContainer = m_Root.FindAnyWidget("ResultsContainer");
		m_StatusText       = TextWidget.Cast(m_Root.FindAnyWidget("StatusText"));
		
		if (m_TitleText) m_TitleText.SetText("Verification Propriete - Bureau Avocat");
		if (m_StatusText) m_StatusText.SetText("Entrez un nom ou prenom RP pour rechercher les proprietes.");
		
		if (m_BtnSearch)
		{
			LP_AvocatPropertyClickHandler h = new LP_AvocatPropertyClickHandler();
			h.m_Menu = this;
			h.m_Kind = "search";
			m_BtnSearch.AddHandler(h);
			JobFocusHandler.Attach(m_BtnSearch);
		}
		
		if (m_BtnClose)
		{
			LP_AvocatPropertyClickHandler h = new LP_AvocatPropertyClickHandler();
			h.m_Menu = this;
			h.m_Kind = "close";
			m_BtnClose.AddHandler(h);
			JobFocusHandler.Attach(m_BtnClose);
		}
		
		// Focus initial sur le champ de recherche
		if (m_SearchInput)
			GetGame().GetCallqueue().CallLater(FocusSearchInput, 50, false);
	}
	
	//------------------------------------------------------------------------------------------------
	protected void FocusSearchInput()
	{
		if (m_SearchInput)
			GetGame().GetWorkspace().SetFocusedWidget(m_SearchInput);
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuClose()
	{
		s_Instance = null;
		JobFocusHandler.ClearRegistry();
		super.OnMenuClose();
	}
	
	//------------------------------------------------------------------------------------------------
	// Tick chaque frame : ecoute le bouton MenuBack (B manette / Echap clavier) pour fermer
	//------------------------------------------------------------------------------------------------
	override void OnMenuUpdate(float tDelta)
	{
		super.OnMenuUpdate(tDelta);
		if (GetGame().GetInputManager().GetActionValue("MenuBack") > 0.5)
		{
			OnCloseClicked();
			return;
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void OnSearchClicked()
	{
		if (!m_SearchInput) return;
		string query = m_SearchInput.GetText();
		query.TrimInPlace();
		
		if (query.Length() < 2)
		{
			if (m_StatusText)
				m_StatusText.SetText("La recherche doit contenir au moins 2 caracteres.");
			return;
		}
		
		if (m_StatusText)
			m_StatusText.SetText("Recherche en cours...");
		
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		
		jpc.ClientAskAvocatSearchProperty(query);
	}
	
	//------------------------------------------------------------------------------------------------
	void OnCloseClicked()
	{
		GetGame().GetMenuManager().CloseMenu(this);
	}
	
	//------------------------------------------------------------------------------------------------
	// Appele par RPC serveur avec les resultats de la recherche.
	// Arrays paralleles : une entree par propriete (le meme joueur peut apparaitre plusieurs fois)
	//------------------------------------------------------------------------------------------------
	void ShowSearchResults(array<string> ownerNames, array<string> coords, array<string> dates,
		array<string> doorKeys)
	{
		m_ResultOwnerNames.Clear();
		m_ResultCoords.Clear();
		m_ResultDates.Clear();
		m_ResultDoorKeys.Clear();
		
		foreach (string s : ownerNames) m_ResultOwnerNames.Insert(s);
		foreach (string s : coords) m_ResultCoords.Insert(s);
		foreach (string s : dates) m_ResultDates.Insert(s);
		foreach (string s : doorKeys) m_ResultDoorKeys.Insert(s);
		
		RefreshResultsUI();
	}
	
	//------------------------------------------------------------------------------------------------
	protected void RefreshResultsUI()
	{
		if (!m_ResultsContainer) return;
		
		// Vide les anciens resultats
		Widget child = m_ResultsContainer.GetChildren();
		while (child)
		{
			Widget next = child.GetSibling();
			child.RemoveFromHierarchy();
			child = next;
		}
		
		int count = m_ResultOwnerNames.Count();
		if (count == 0)
		{
			if (m_StatusText)
				m_StatusText.SetText("Aucun proprietaire trouve avec ce nom / prenom.");
			return;
		}
		
		// Compte les proprietaires uniques (pour le message de statut)
		if (m_StatusText)
		{
			m_StatusText.SetText(string.Format("%1 propriete(s) trouvee(s) - lecture seule",
				count.ToString()));
		}
		
		// Genere une ligne par propriete
		for (int i = 0; i < count; i++)
		{
			Widget entry = GetGame().GetWorkspace().CreateWidgets(
				"UI/layouts/LP_AvocatPropertyEntry.layout", m_ResultsContainer);
			if (!entry) continue;
			
			TextWidget nameLbl  = TextWidget.Cast(entry.FindAnyWidget("EntryName"));
			TextWidget coordLbl = TextWidget.Cast(entry.FindAnyWidget("EntryCoords"));
			TextWidget dateLbl  = TextWidget.Cast(entry.FindAnyWidget("EntryDate"));
			
			if (nameLbl)  nameLbl.SetText(m_ResultOwnerNames[i]);
			if (coordLbl) coordLbl.SetText("Coordonnees : " + m_ResultCoords[i]);
			if (dateLbl)  dateLbl.SetText("Date achat : " + m_ResultDates[i]);
		}
	}
}

//------------------------------------------------------------------------------------------------
// Handler generique pour les boutons du menu
//------------------------------------------------------------------------------------------------
class LP_AvocatPropertyClickHandler : ScriptedWidgetEventHandler
{
	LP_AvocatCheckPropertyMenu m_Menu;
	string m_Kind;   // "search" ou "close"
	
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (!m_Menu) return false;
		if (m_Kind == "search") { m_Menu.OnSearchClicked(); return true; }
		if (m_Kind == "close") { m_Menu.OnCloseClicked(); return true; }
		return false;
	}
}
