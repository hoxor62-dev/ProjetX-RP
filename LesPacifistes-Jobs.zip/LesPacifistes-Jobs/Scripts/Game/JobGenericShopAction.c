//------------------------------------------------------------------------------------------------
// JobGenericShopAction.c
// Action "F Parler" sur les PNJ de shops publics (vetements / nourriture / location).
// Ouvre directement JobShopMenu avec le type de shop configure sur le PNJ.
//------------------------------------------------------------------------------------------------

class JobGenericShopAction : ScriptedUserAction
{
	//------------------------------------------------------------------------------------------------
	override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
	{
		if (!pUserEntity)
			return;
		
		// Ne s'execute que pour le joueur local (sinon ouvre le menu chez tout le monde)
		PlayerController localPC = GetGame().GetPlayerController();
		if (!localPC)
			return;
		IEntity localEntity = localPC.GetControlledEntity();
		if (localEntity != pUserEntity)
			return;
		
		JobGenericShopComponent shopComp = JobGenericShopComponent.Cast(
			pOwnerEntity.FindComponent(JobGenericShopComponent));
		if (!shopComp)
			return;
		
		EJobType shopType = shopComp.GetShopType();
		
		// Cas special : SHOP_LOCATION ouvre le menu de location de vehicules au lieu du shop classique
		if (shopType == EJobType.SHOP_LOCATION)
		{
			GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.JobRentalMenu);
			return;
		}
		
		// Recupere le RplId du PNJ (pour tracking mais pas de check metier ici)
		RplComponent npcRpl = RplComponent.Cast(pOwnerEntity.FindComponent(RplComponent));
		RplId npcRplId = RplId.Invalid();
		if (npcRpl)
			npcRplId = npcRpl.Id();
		
		// Ouvre directement le JobShopMenu avec le type configure
		JobShopMenu shop = JobShopMenu.Cast(
			GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.JobShopMenu));
		if (shop)
			shop.Initialize(shopType, npcRplId);
	}
	
	//------------------------------------------------------------------------------------------------
	override bool CanBeShownScript(IEntity user)
	{
		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	override bool CanBePerformedScript(IEntity user)
	{
		return true;
	}
}
