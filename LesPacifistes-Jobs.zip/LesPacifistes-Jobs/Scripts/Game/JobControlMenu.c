//------------------------------------------------------------------------------------------------
// JobControlMenu.c
// Menu policier/militaire avec 8 boutons d'actions sur la cible controlee.
// Le bouton "Mettre en prison" ouvre un sous-panneau permettant de choisir la duree
// (15, 30 ou 50 minutes) suivi d une pop-up de confirmation.
//------------------------------------------------------------------------------------------------

class JobControlMenu : ChimeraMenuBase
{
	Widget m_RootWidget;
	TextWidget m_TargetText;
	int m_TargetPlayerId;
	string m_TargetName;
	
	// Sous-panneau garde a vue + sous-panneau prison + pop-up confirmation
	Widget m_JailSubmenuPanel;       // sous-panneau garde a vue (15/30/50)
	Widget m_PrisonSubmenuPanel;     // sous-panneau prison (60/90/120)
	Widget m_ConfirmPopupPanel;      // pop-up de confirmation partagee
	TextWidget m_ConfirmText;        // texte "Confirmer X min ?"
	int m_PendingDurationMinutes;    // duree en attente de confirmation
	bool m_PendingIsPrison;          // true = ClientAskImprisonPlayer, false = ClientAskJailPlayer
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuOpen()
	{
		super.OnMenuOpen();
		m_RootWidget = GetRootWidget();
		if (!m_RootWidget)
			return;
		
		m_TargetText = TextWidget.Cast(m_RootWidget.FindAnyWidget("TargetText"));
		
		AttachButton("IdentityButton", "identity");
		AttachButton("RecordButton", "record");
		AttachButton("LicenseButton", "license");
		AttachButton("FineButton", "fine");
		AttachButton("MentionButton", "mention");
		AttachButton("JailButton", "jail");
		AttachButton("PrisonButton", "prison");
		AttachButton("ReleaseButton", "release");
		AttachButton("RevokeLicenseButton", "revoke_license");
		AttachButton("CloseButton", "close");
		AttachButton("FloatingCloseButton", "close");
		
		// === Sous-panneau garde a vue (15/30/50) ===
		m_JailSubmenuPanel = m_RootWidget.FindAnyWidget("JailSubmenuPanel");
		if (m_JailSubmenuPanel)
			m_JailSubmenuPanel.SetVisible(false);
		AttachButton("Jail15Button", "jail_15");
		AttachButton("Jail30Button", "jail_30");
		AttachButton("Jail50Button", "jail_50");
		AttachButton("JailBackButton", "jail_back");

		// === Sous-panneau prison longue (60/90/120) ===
		m_PrisonSubmenuPanel = m_RootWidget.FindAnyWidget("PrisonSubmenuPanel");
		if (m_PrisonSubmenuPanel)
			m_PrisonSubmenuPanel.SetVisible(false);
		AttachButton("Prison60Button", "prison_60");
		AttachButton("Prison90Button", "prison_90");
		AttachButton("Prison120Button", "prison_120");
		AttachButton("PrisonBackButton", "prison_back");
		
		// === Pop-up confirmation ===
		m_ConfirmPopupPanel = m_RootWidget.FindAnyWidget("ConfirmPopupPanel");
		if (m_ConfirmPopupPanel)
			m_ConfirmPopupPanel.SetVisible(false);
		m_ConfirmText = TextWidget.Cast(m_RootWidget.FindAnyWidget("ConfirmText"));
		AttachButton("ConfirmYesButton", "confirm_yes");
		AttachButton("ConfirmNoButton", "confirm_no");
		
		// Focus initial
		ButtonWidget firstBtn = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("IdentityButton"));
		if (firstBtn)
			GetGame().GetWorkspace().SetFocusedWidget(firstBtn);
	}
	
	//------------------------------------------------------------------------------------------------
	void AttachButton(string name, string action)
	{
		ButtonWidget btn = ButtonWidget.Cast(m_RootWidget.FindAnyWidget(name));
		if (!btn)
			return;
		ControlMenuClickHandler h = new ControlMenuClickHandler();
		h.m_Menu = this;
		h.m_Action = action;
		btn.AddHandler(h);
		JobFocusHandler.Attach(btn);
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuUpdate(float tDelta)
	{
		super.OnMenuUpdate(tDelta);
		if (GetGame().GetInputManager().GetActionValue("MenuBack") > 0.5)
		{
			// Si la pop-up de confirmation est visible : la fermer
			if (m_ConfirmPopupPanel && m_ConfirmPopupPanel.IsVisible())
			{
				HideConfirmPopup();
				return;
			}
			// Si le sous-panneau garde a vue est visible : le fermer
			if (m_JailSubmenuPanel && m_JailSubmenuPanel.IsVisible())
			{
				HideJailSubmenu();
				return;
			}
			// Si le sous-panneau prison est visible : le fermer
			if (m_PrisonSubmenuPanel && m_PrisonSubmenuPanel.IsVisible())
			{
				HidePrisonSubmenu();
				return;
			}
			CloseMenuInternal();
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void Initialize(int targetPlayerId)
	{
		m_TargetPlayerId = targetPlayerId;
		// On n'a pas le nom cote client tout de suite - on affiche un placeholder
		// et on resoudra via PlayerManager
		PlayerManager pm = GetGame().GetPlayerManager();
		if (pm)
			m_TargetName = pm.GetPlayerName(targetPlayerId);
		if (m_TargetName == "")
			m_TargetName = "Joueur " + targetPlayerId.ToString();
		
		if (m_TargetText)
			m_TargetText.SetText("Cible: " + m_TargetName);
	}
	
	//------------------------------------------------------------------------------------------------
	void OnButtonClicked(string action)
	{
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc)
			return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		
		if (action == "identity")
		{
			JobPlayerComponent jpc2 = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
			if (jpc2)
				jpc2.ClientAskControlIdentity(m_TargetPlayerId);
		}
		else if (action == "record")
		{
			JobCriminalDisplayMenu menu = JobCriminalDisplayMenu.Cast(
				GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.JobCriminalDisplayMenu));
			if (menu)
				menu.Initialize(m_TargetPlayerId, m_TargetName);
		}
		else if (action == "license")
		{
			if (jpc)
				jpc.ClientAskCheckLicense(m_TargetPlayerId);
		}
		else if (action == "fine")
		{
			JobFineSubmenu menu = JobFineSubmenu.Cast(
				GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.JobFineSubmenu));
			if (menu)
				menu.Initialize(m_TargetPlayerId, m_TargetName);
		}
		else if (action == "mention")
		{
			JobAddMentionMenu menu = JobAddMentionMenu.Cast(
				GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.JobAddMentionMenu));
			if (menu)
				menu.Initialize(m_TargetPlayerId, m_TargetName);
		}
		else if (action == "jail")
		{
			// Ouvre le sous-panneau garde a vue pour choisir la duree
			ShowJailSubmenu();
		}
		else if (action == "jail_15")
		{
			ShowConfirmPopup(15, false);
		}
		else if (action == "jail_30")
		{
			ShowConfirmPopup(30, false);
		}
		else if (action == "jail_50")
		{
			ShowConfirmPopup(50, false);
		}
		else if (action == "jail_back")
		{
			HideJailSubmenu();
		}
		else if (action == "prison")
		{
			// Ouvre le sous-panneau prison longue
			ShowPrisonSubmenu();
		}
		else if (action == "prison_60")
		{
			ShowConfirmPopup(60, true);
		}
		else if (action == "prison_90")
		{
			ShowConfirmPopup(90, true);
		}
		else if (action == "prison_120")
		{
			ShowConfirmPopup(120, true);
		}
		else if (action == "prison_back")
		{
			HidePrisonSubmenu();
		}
		else if (action == "confirm_yes")
		{
			// Confirmation : route vers la bonne RPC selon le mode (jail / prison)
			if (jpc)
			{
				if (m_PendingIsPrison)
					jpc.ClientAskImprisonPlayer(m_TargetPlayerId, m_PendingDurationMinutes);
				else
					jpc.ClientAskJailPlayer(m_TargetPlayerId, m_PendingDurationMinutes);
			}
			HideConfirmPopup();
			HideJailSubmenu();
			HidePrisonSubmenu();
			CloseMenuInternal();
		}
		else if (action == "confirm_no")
		{
			HideConfirmPopup();
		}
		else if (action == "release")
		{
			if (jpc)
				jpc.ClientAskReleasePlayer(m_TargetPlayerId);
			CloseMenuInternal();
		}
		else if (action == "revoke_license")
		{
			if (jpc)
				jpc.ClientAskRevokeLicense(m_TargetPlayerId);
			CloseMenuInternal();
		}
		else if (action == "close")
		{
			CloseMenuInternal();
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Sous-panneau garde a vue (15/30/50)
	//------------------------------------------------------------------------------------------------
	void ShowJailSubmenu()
	{
		if (m_JailSubmenuPanel)
		{
			m_JailSubmenuPanel.SetVisible(true);
			ButtonWidget b = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("Jail15Button"));
			if (b)
				GetGame().GetWorkspace().SetFocusedWidget(b);
		}
	}

	void HideJailSubmenu()
	{
		if (m_JailSubmenuPanel)
			m_JailSubmenuPanel.SetVisible(false);
	}

	//------------------------------------------------------------------------------------------------
	// Sous-panneau prison longue (60/90/120)
	//------------------------------------------------------------------------------------------------
	void ShowPrisonSubmenu()
	{
		if (m_PrisonSubmenuPanel)
		{
			m_PrisonSubmenuPanel.SetVisible(true);
			ButtonWidget b = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("Prison60Button"));
			if (b)
				GetGame().GetWorkspace().SetFocusedWidget(b);
		}
	}

	void HidePrisonSubmenu()
	{
		if (m_PrisonSubmenuPanel)
			m_PrisonSubmenuPanel.SetVisible(false);
	}

	//------------------------------------------------------------------------------------------------
	// Pop-up confirmation partagee (jail ou prison selon isPrison)
	//------------------------------------------------------------------------------------------------
	void ShowConfirmPopup(int minutes, bool isPrison)
	{
		m_PendingDurationMinutes = minutes;
		m_PendingIsPrison = isPrison;
		if (m_ConfirmText)
		{
			if (isPrison)
				m_ConfirmText.SetText(string.Format("Confirmer la mise en prison pour %1 minutes ?", minutes.ToString()));
			else
				m_ConfirmText.SetText(string.Format("Confirmer une garde a vue de %1 minutes ?", minutes.ToString()));
		}
		if (m_ConfirmPopupPanel)
		{
			m_ConfirmPopupPanel.SetVisible(true);
			ButtonWidget b = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("ConfirmYesButton"));
			if (b)
				GetGame().GetWorkspace().SetFocusedWidget(b);
		}
	}

	void HideConfirmPopup()
	{
		if (m_ConfirmPopupPanel)
			m_ConfirmPopupPanel.SetVisible(false);
	}
	
	//------------------------------------------------------------------------------------------------
	void CloseMenuInternal()
	{
		GetGame().GetMenuManager().CloseMenu(this);
	}
}

//------------------------------------------------------------------------------------------------
class ControlMenuClickHandler : ScriptedWidgetEventHandler
{
	JobControlMenu m_Menu;
	string m_Action;
	
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu)
			m_Menu.OnButtonClicked(m_Action);
		return true;
	}
	
	override bool OnMouseButtonDown(Widget w, int x, int y, int button)
	{
		return false;
	}
}
