//------------------------------------------------------------------------------------------------
// LP_TowManager.c
// Singleton SERVEUR qui gere le remorquage de vehicules par les depanneuses (metier MECANICIEN).
//
// FONCTIONNEMENT :
//   - Le mecanicien active "Remorquer vehicule" sur la depanneuse
//     -> On cherche le vehicule le plus proche dans un rayon de 5m (autre que la depanneuse elle-meme)
//     -> On enregistre la paire depanneuse -> vehicule dans m_TowedByTruck
//   - Un ticker 100ms teleporte le vehicule remorque sur la depanneuse (offset relatif au repere)
//     -> Le vehicule reste sur la depanneuse meme quand elle bouge
//   - Le mecanicien active "Descendre le vehicule"
//     -> Retire de la map + spawn le vehicule a 2m derriere la depanneuse
//
// LIMITE : un seul vehicule remorque par depanneuse (deuxieme tentative refusee).
//------------------------------------------------------------------------------------------------

class LP_TowedVehicleData
{
	IEntity m_TruckEntity;      // la depanneuse
	IEntity m_VehicleEntity;    // le vehicule remorque
	vector m_LocalOffset;       // offset local sur le repere de la depanneuse (0, hauteur, arriere)
	
	void LP_TowedVehicleData(IEntity truck, IEntity vehicle, vector localOffset)
	{
		m_TruckEntity = truck;
		m_VehicleEntity = vehicle;
		m_LocalOffset = localOffset;
	}
}

class LP_TowManager
{
	static ref LP_TowManager s_Instance;
	
	// Map : truck EntityID.ToString() -> LP_TowedVehicleData (une seule voiture remorquee par depanneuse)
	ref map<string, ref LP_TowedVehicleData> m_TowedByTruck = new map<string, ref LP_TowedVehicleData>();
	
	// Cache inverse : vehicle EntityID.ToString() -> truck EntityID.ToString() (pour verifier
	// qu un vehicule n est pas deja remorque par une autre depanneuse)
	ref map<string, string> m_TruckByVehicle = new map<string, string>();
	
	bool m_TickerStarted = false;
	
	// Rayon de recherche du vehicule le plus proche
	const float SEARCH_RADIUS = 9.0;
	
	// Offset local du vehicule remorque sur la depanneuse (X=lateral, Y=hauteur, Z=avant-arriere)
	// (0, 2.5, -2) = centre lateral, 2.5m au dessus (le vehicule flotte legerement au dessus
	// du plateau pour eviter tout contact physique avec la depanneuse), 2m vers l arriere.
	static const vector TOW_OFFSET = "0 1.4 -3.6";
	
	// Distance de spawn arriere pour "Descendre le vehicule" (2m derriere)
	const float DROP_DISTANCE_BACK = 9.0;
	
	//------------------------------------------------------------------------------------------------
	static LP_TowManager GetInstance()
	{
		if (!s_Instance) s_Instance = new LP_TowManager();
		return s_Instance;
	}
	
	//------------------------------------------------------------------------------------------------
	protected void EnsureTicker()
	{
		if (m_TickerStarted) return;
		m_TickerStarted = true;
		// Tick 100ms : comportement V1 qui fonctionnait bien.
		// Aucun reset velocity ni SetActive - juste SetWorldTransform pur.
		// L offset Y=2.5m evite tout contact physique avec la depanneuse.
		GetGame().GetCallqueue().CallLater(TickAllTows, 2, true);
	}
	
	//------------------------------------------------------------------------------------------------
	// Retourne true si la depanneuse remorque deja un vehicule
	//------------------------------------------------------------------------------------------------
	bool IsTruckTowing(IEntity truck)
	{
		if (!truck) return false;
		return m_TowedByTruck.Contains(truck.GetID().ToString());
	}
	
	//------------------------------------------------------------------------------------------------
	// Retourne true si le vehicule est actuellement remorque par une depanneuse
	//------------------------------------------------------------------------------------------------
	bool IsVehicleTowed(IEntity vehicle)
	{
		if (!vehicle) return false;
		return m_TruckByVehicle.Contains(vehicle.GetID().ToString());
	}
	
	//------------------------------------------------------------------------------------------------
	// Enregistre un vehicule comme remorque par une depanneuse.
	// Retourne 0=OK, 1=depanneuse deja utilisee, 2=vehicule deja remorque ailleurs, 3=erreur
	//------------------------------------------------------------------------------------------------
	int RegisterTow(IEntity truck, IEntity vehicle)
	{
		if (!Replication.IsServer()) return 3;
		if (!truck || !vehicle) return 3;
		if (IsTruckTowing(truck)) return 1;
		if (IsVehicleTowed(vehicle)) return 2;
		
		LP_TowedVehicleData data = new LP_TowedVehicleData(truck, vehicle, TOW_OFFSET);
		m_TowedByTruck.Set(truck.GetID().ToString(), data);
		m_TruckByVehicle.Set(vehicle.GetID().ToString(), truck.GetID().ToString());
		
		// Teleporte immediatement le vehicule sur la depanneuse
		ApplyTowedPosition(data);
		
		EnsureTicker();
		
		Print(string.Format("[LP_TowManager] Remorquage : truck=%1 vehicle=%2",
			truck.GetID().ToString(), vehicle.GetID().ToString()), LogLevel.NORMAL);
		return 0;
	}
	
	//------------------------------------------------------------------------------------------------
	// Retire le vehicule de la depanneuse et le pose 4m derriere elle.
	// Retourne 0=OK, 1=depanneuse ne remorque rien, 2=erreur
	//------------------------------------------------------------------------------------------------
	int ReleaseTow(IEntity truck)
	{
		if (!Replication.IsServer()) return 2;
		if (!truck) return 2;
		
		LP_TowedVehicleData data = m_TowedByTruck.Get(truck.GetID().ToString());
		if (!data) return 1;
		if (!data.m_VehicleEntity) return 2;
		
		IEntity vehicle = data.m_VehicleEntity;
		
		// Calcule la position 4m derriere la depanneuse
		vector truckPos = truck.GetOrigin();
		vector truckMat[4];
		truck.GetWorldTransform(truckMat);
		// truckMat[2] = axe forward local du repere. -truckMat[2] = arriere.
		vector backward = -truckMat[2] * DROP_DISTANCE_BACK;
		vector dropPos = truckPos + backward;
		// Legere elevation pour eviter de spawn sous le sol
		dropPos[1] = dropPos[1] + 0.5;
		
		// Applique la nouvelle position au vehicule
		vector newMat[4];
		vehicle.GetWorldTransform(newMat);
		newMat[3] = dropPos;
		vehicle.SetWorldTransform(newMat);
		
		// Retire des maps
		m_TowedByTruck.Remove(truck.GetID().ToString());
		m_TruckByVehicle.Remove(vehicle.GetID().ToString());
		
		Print(string.Format("[LP_TowManager] Vehicule descendu : truck=%1 vehicle=%2 pos=%3",
			truck.GetID().ToString(), vehicle.GetID().ToString(), dropPos.ToString()),
			LogLevel.NORMAL);
		return 0;
	}
	
	//------------------------------------------------------------------------------------------------
	// Cherche le vehicule le plus proche de la depanneuse (dans SEARCH_RADIUS, exclut la depanneuse).
	//------------------------------------------------------------------------------------------------
	IEntity FindNearestVehicle(IEntity truck)
	{
		if (!truck) return null;
		BaseWorld world = GetGame().GetWorld();
		if (!world) return null;
		
		m_SearchTruck = truck;
		m_SearchRefPos = truck.GetOrigin();
		m_SearchBestDistSq = SEARCH_RADIUS * SEARCH_RADIUS;
		m_SearchFoundEntity = null;
		
		world.QueryEntitiesBySphere(m_SearchRefPos, SEARCH_RADIUS,
			FilterNearestVehicleCallback, null, EQueryEntitiesFlags.ALL);
		
		IEntity result = m_SearchFoundEntity;
		m_SearchFoundEntity = null;
		m_SearchTruck = null;
		return result;
	}
	
	// Variables temporaires pour la recherche (le callback ne prend pas de contexte)
	IEntity m_SearchTruck;
	IEntity m_SearchFoundEntity;
	vector m_SearchRefPos;
	float m_SearchBestDistSq;
	
	//------------------------------------------------------------------------------------------------
	bool FilterNearestVehicleCallback(IEntity ent)
	{
		if (!ent) return true;
		if (ent == m_SearchTruck) return true; // exclut la depanneuse elle-meme
		
		Vehicle veh = Vehicle.Cast(ent);
		if (!veh) return true;
		
		// Exclut les vehicules deja remorques
		if (IsVehicleTowed(ent)) return true;
		
		vector entPos = ent.GetOrigin();
		float dx = entPos[0] - m_SearchRefPos[0];
		float dy = entPos[1] - m_SearchRefPos[1];
		float dz = entPos[2] - m_SearchRefPos[2];
		float distSq = dx * dx + dy * dy + dz * dz;
		
		if (distSq < m_SearchBestDistSq)
		{
			m_SearchBestDistSq = distSq;
			m_SearchFoundEntity = ent;
		}
		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	// Tick 100ms : maintient tous les vehicules remorques sur leur depanneuse.
	//------------------------------------------------------------------------------------------------
	void TickAllTows()
	{
		if (!Replication.IsServer()) return;
		if (m_TowedByTruck.Count() == 0) return;
		
		// Recolte les paires invalides pour nettoyage a la fin (evite modif pendant iteration)
		array<string> toRemove = new array<string>();
		
		foreach (string truckId, LP_TowedVehicleData data : m_TowedByTruck)
		{
			if (!data) { toRemove.Insert(truckId); continue; }
			if (!data.m_TruckEntity || !data.m_VehicleEntity)
			{
				toRemove.Insert(truckId);
				continue;
			}
			ApplyTowedPosition(data);
		}
		
		foreach (string id : toRemove)
		{
			LP_TowedVehicleData d = m_TowedByTruck.Get(id);
			if (d && d.m_VehicleEntity)
				m_TruckByVehicle.Remove(d.m_VehicleEntity.GetID().ToString());
			m_TowedByTruck.Remove(id);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Calcule et applique la position du vehicule remorque en fonction du repere de la depanneuse.
	// Utilise un clamp DOUX de la vitesse verticale pour empecher l accumulation gravitationnelle,
	// sans faire de reset brutal (qui declenche le systeme de damage du vehicule et le fait exploser).
	//------------------------------------------------------------------------------------------------
	protected void ApplyTowedPosition(LP_TowedVehicleData data)
	{
		if (!data || !data.m_TruckEntity || !data.m_VehicleEntity) return;
		
		vector truckMat[4];
		data.m_TruckEntity.GetWorldTransform(truckMat);
		
		// Position monde = origine depanneuse + offset local transforme par la matrice
		vector localOffset = data.m_LocalOffset;
		vector worldOffset = truckMat[0] * localOffset[0]
			+ truckMat[1] * localOffset[1]
			+ truckMat[2] * localOffset[2];
		vector newPos = truckMat[3] + worldOffset;
		
		// On applique la meme rotation que la depanneuse au vehicule remorque
		vector newMat[4];
		newMat[0] = truckMat[0];
		newMat[1] = truckMat[1];
		newMat[2] = truckMat[2];
		newMat[3] = newPos;
		data.m_VehicleEntity.SetWorldTransform(newMat);
		
		// CLAMP DOUX de la vitesse verticale : evite l accumulation de chute libre
		// entre 2 ticks. On limite juste la vitesse Y a une valeur faible, sans reset
		// brutal a zero (qui provoquerait une explosion du vehicule via son damage system).
		Physics phys = data.m_VehicleEntity.GetPhysics();
		if (phys)
		{
			vector vel = phys.GetVelocity();
			// Autorise le vehicule a "tomber" doucement mais pas plus vite que 0.5 m/s
			if (vel[1] < -0.5) vel[1] = -0.5;
			// Meme principe pour un vehicule qui rebondirait vers le haut
			if (vel[1] > 0.5) vel[1] = 0.5;
			phys.SetVelocity(vel);
		}
	}
}