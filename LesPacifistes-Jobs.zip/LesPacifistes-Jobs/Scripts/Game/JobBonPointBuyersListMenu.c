//------------------------------------------------------------------------------------------------
// JobBonPointBuyersListMenu.c
// Liste des acheteurs qui ont ecrit au vendeur sur une annonce donnee.
// Clic sur un acheteur -> ouvre la conversation avec lui.
//------------------------------------------------------------------------------------------------

class JobBonPointBuyersListMenu : ChimeraMenuBase
{
	const string ENTRY_LAYOUT_PATH = "{A862D471F564E407}UI/layouts/JobBonPointBuyerEntry.layout";
	
	Widget m_RootWidget;
	TextWidget m_TitleText;
	TextWidget m_EmptyText;
	Widget m_ListContainer;
	ButtonWidget m_BtnBack;
	
	// Donnees pre-chargees
	static int s_AdId;
	static string s_AdTitle;
	static ref array<string> s_PendingBuyerUIDs = new array<string>();
	static ref array<string> s_PendingBuyerNames = new array<string>();
	
	static JobBonPointBuyersListMenu s_Instance;
	
	//------------------------------------------------------------------------------------------------
	static void SetPendingData(int adId, string adTitle, array<string> uids, array<string> names)
	{
		s_AdId = adId;
		s_AdTitle = adTitle;
		s_PendingBuyerUIDs.Clear();
		s_PendingBuyerNames.Clear();
		foreach (string u : uids) s_PendingBuyerUIDs.Insert(u);
		foreach (string n : names) s_PendingBuyerNames.Insert(n);
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuOpen()
	{
		super.OnMenuOpen();
		s_Instance = this;
		JobFocusHandler.ClearRegistry();
		
		m_RootWidget = GetRootWidget();
		if (!m_RootWidget) return;
		
		m_TitleText = TextWidget.Cast(m_RootWidget.FindAnyWidget("TitleText"));
		m_EmptyText = TextWidget.Cast(m_RootWidget.FindAnyWidget("EmptyText"));
		m_ListContainer = m_RootWidget.FindAnyWidget("ListContainer");
		m_BtnBack = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnBack"));
		
		if (m_TitleText)
			m_TitleText.SetText(string.Format("Discussions : %1", s_AdTitle));
		
		if (m_BtnBack)
		{
			BonPointBuyersListHandler h = new BonPointBuyersListHandler();
			h.m_Menu = this;
			h.m_Action = "back";
			m_BtnBack.AddHandler(h);
			JobFocusHandler.Attach(m_BtnBack);
			GetGame().GetWorkspace().SetFocusedWidget(m_BtnBack);
		}
		
		BuildList();
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuClose()
	{
		if (s_Instance == this) s_Instance = null;
		super.OnMenuClose();
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuUpdate(float tDelta)
	{
		super.OnMenuUpdate(tDelta);
		if (GetGame().GetInputManager().GetActionValue("MenuBack") > 0.5)
			CloseMenuInternal();
	}
	
	//------------------------------------------------------------------------------------------------
	void BuildList()
	{
		if (!m_ListContainer) return;
		
		Widget child = m_ListContainer.GetChildren();
		while (child)
		{
			Widget next = child.GetSibling();
			child.RemoveFromHierarchy();
			child = next;
		}
		
		if (s_PendingBuyerUIDs.Count() == 0)
		{
			if (m_EmptyText)
			{
				m_EmptyText.SetText("Aucun acheteur n a encore ecrit.");
				m_EmptyText.SetVisible(true);
			}
			return;
		}
		if (m_EmptyText) m_EmptyText.SetVisible(false);
		
		WorkspaceWidget ws = GetGame().GetWorkspace();
		for (int i = 0; i < s_PendingBuyerUIDs.Count(); i++)
		{
			string buyerUID = s_PendingBuyerUIDs.Get(i);
			string buyerName = s_PendingBuyerNames.Get(i);
			
			Widget entry = ws.CreateWidgets(ENTRY_LAYOUT_PATH, m_ListContainer);
			if (!entry) continue;
			
			TextWidget nameW = TextWidget.Cast(entry.FindAnyWidget("BuyerName"));
			if (nameW) nameW.SetText(buyerName);
			
			ButtonWidget btn = ButtonWidget.Cast(entry.FindAnyWidget("BtnOpenChat"));
			if (btn)
			{
				BonPointBuyerSelectHandler h = new BonPointBuyerSelectHandler();
				h.m_Menu = this;
				h.m_BuyerUID = buyerUID;
				h.m_BuyerName = buyerName;
				btn.AddHandler(h);
				JobFocusHandler.Attach(btn);
			}
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void OnBuyerPicked(string buyerUID, string buyerName)
	{
		// Ouvre la conversation cote vendeur : le contexte du chat utilise buyerUID
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		
		// Pre-charge le contexte (titre + nom + buyerUID) puis demande les messages
		JobBonPointChatMenu.SetPendingContext(s_AdId, buyerUID, buyerName, s_AdTitle);
		jpc.ClientAskBonPointChatMessages(s_AdId, buyerUID);
		CloseMenuInternal();
	}
	
	//------------------------------------------------------------------------------------------------
	void OnAction(string action)
	{
		if (action == "back")
		{
			CloseMenuInternal();
			return;
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void CloseMenuInternal()
	{
		GetGame().GetMenuManager().CloseMenu(this);
	}
}

//------------------------------------------------------------------------------------------------
class BonPointBuyersListHandler : ScriptedWidgetEventHandler
{
	JobBonPointBuyersListMenu m_Menu;
	string m_Action;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.OnAction(m_Action);
		return true;
	}
}

//------------------------------------------------------------------------------------------------
class BonPointBuyerSelectHandler : ScriptedWidgetEventHandler
{
	JobBonPointBuyersListMenu m_Menu;
	string m_BuyerUID;
	string m_BuyerName;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.OnBuyerPicked(m_BuyerUID, m_BuyerName);
		return true;
	}
}
