//------------------------------------------------------------------------------------------------
// LP_DoorUnlockAction.c
// Action "Deverrouiller" - visible si :
//   - porte a un proprio
//   - porte actuellement verrouillee
//   - joueur local est proprio OU dans la liste des joueurs qui connaissent le code
//------------------------------------------------------------------------------------------------

class LP_DoorUnlockAction : ScriptedUserAction
{
	override bool CanBeShownScript(IEntity user)
	{
		if (!user) return false;
		
		IEntity door = GetOwner();
		if (!door) return false;
		LP_DoorAccessComponent access = LP_DoorAccessComponent.Cast(
			door.FindComponent(LP_DoorAccessComponent));
		if (!access || !access.HasOwner()) return false;
		if (!access.IsLocked()) return false; // deja deverrouille
		
		int localPlayerId = SCR_PlayerController.GetLocalPlayerId();
		return access.CanUseDoorPlayerId(localPlayerId);
	}
	
	override bool CanBePerformedScript(IEntity user) { return CanBeShownScript(user); }
	
	override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
	{
		PlayerController pc = PlayerController.Cast(GetGame().GetPlayerController());
		if (!pc) return;
		if (pUserEntity != pc.GetControlledEntity()) return;
		
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		
		RplComponent rpl = RplComponent.Cast(pOwnerEntity.FindComponent(RplComponent));
		if (!rpl) return;
		
		jpc.ClientAskLockLpDoor(rpl.Id(), false);
	}
}
