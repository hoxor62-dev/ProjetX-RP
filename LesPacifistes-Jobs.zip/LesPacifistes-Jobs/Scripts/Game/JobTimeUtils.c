//------------------------------------------------------------------------------------------------
// JobTimeUtils.c
// Helper centralise pour la gestion des timestamps dans le mod LesPacifistesJobs.
//
// PROBLEMATIQUE : GetGame().GetWorld().GetWorldTime() retourne le temps depuis le demarrage
// du monde, en millisecondes. Ce compteur repart a ZERO a chaque reboot serveur.
//
// Si un timestamp est sauvegarde (par exemple "joueur incarcere a t=30000s") puis le serveur
// redemarre, le nouveau "now" repart de 0 et la comparaison "now - savedTimestamp" donne
// des valeurs negatives gigantesques, ce qui rend les cooldowns/durees incoherents.
//
// SOLUTION : centraliser la lecture des timestamps via ces helpers, qui detectent le cas
// "timestamp futur > now actuel" et le traitent comme un reboot (reset = 0).
//------------------------------------------------------------------------------------------------

class JobTimeUtils
{
	//------------------------------------------------------------------------------------------------
	// Retourne le timestamp courant en secondes depuis le demarrage du monde
	//------------------------------------------------------------------------------------------------
	static int GetNow()
	{
		return Math.Floor(GetGame().GetWorld().GetWorldTime() / 1000);
	}
	
	//------------------------------------------------------------------------------------------------
	// "Sanitize" un timestamp sauvegarde : si > now, considere reboot detecte et retourne 0
	// Utilise pour calculer correctement les cooldowns et durees apres reboot serveur.
	//------------------------------------------------------------------------------------------------
	static int Sanitize(int savedTimestamp)
	{
		int now = GetNow();
		if (savedTimestamp > now)
			return 0;
		return savedTimestamp;
	}
	
	//------------------------------------------------------------------------------------------------
	// Calcule le nombre de secondes ecoulees depuis un timestamp sauvegarde.
	// Si reboot detecte (timestamp > now), considere que le temps est ecoule (retourne LARGE_VALUE).
	// Cela permet aux conditions "elapsed >= cooldown" de devenir vraies (cooldown expire).
	//------------------------------------------------------------------------------------------------
	static int Elapsed(int savedTimestamp)
	{
		if (savedTimestamp <= 0)
			return 999999999;  // pas de timestamp = "tres longtemps"
		int now = GetNow();
		if (savedTimestamp > now)
			return 999999999;  // reboot detecte = "tres longtemps"
		return now - savedTimestamp;
	}
	
	//------------------------------------------------------------------------------------------------
	// Verifie si un cooldown est encore actif (true) ou expire (false).
	// cooldownSeconds = duree du cooldown en secondes
	// Robuste au reboot serveur : si timestamp > now, le cooldown est considere expire.
	//------------------------------------------------------------------------------------------------
	static bool IsInCooldown(int savedTimestamp, int cooldownSeconds)
	{
		if (savedTimestamp <= 0)
			return false;
		int now = GetNow();
		if (savedTimestamp > now)
			return false;
		return (now - savedTimestamp) < cooldownSeconds;
	}
	
	//------------------------------------------------------------------------------------------------
	// Renvoie le nombre de secondes restantes d'un cooldown (0 si expire ou inactif).
	//------------------------------------------------------------------------------------------------
	static int CooldownRemaining(int savedTimestamp, int cooldownSeconds)
	{
		if (savedTimestamp <= 0)
			return 0;
		int now = GetNow();
		if (savedTimestamp > now)
			return 0;
		int elapsed = now - savedTimestamp;
		if (elapsed >= cooldownSeconds)
			return 0;
		return cooldownSeconds - elapsed;
	}
}
