//------------------------------------------------------------------------------------------------
// JobPochonUseAction.c
// UserAction "Utiliser pochon" a placer sur le prefab pochon.
// Envoie le RplId du pochon au serveur qui consomme l item et applique les effets 3 min.
//------------------------------------------------------------------------------------------------

class JobPochonUseAction : ScriptedUserAction
{
	override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
	{
		PlayerController pc = PlayerController.Cast(GetGame().GetPlayerController());
		if (!pc) return;
		if (pUserEntity != pc.GetControlledEntity()) return;
		
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		
		RplComponent rpl = RplComponent.Cast(pOwnerEntity.FindComponent(RplComponent));
		if (!rpl) return;
		jpc.ClientAskUsePochon(rpl.Id());
	}
	
	override bool CanBePerformedScript(IEntity user)
	{
		return true;
	}
	
	override bool CanBeShownScript(IEntity user)
	{
		return true;
	}
}
