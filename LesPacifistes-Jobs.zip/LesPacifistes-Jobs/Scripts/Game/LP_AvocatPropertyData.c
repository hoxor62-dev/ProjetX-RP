//------------------------------------------------------------------------------------------------
// LP_AvocatPropertyData.c
// Structure de donnees serialisable pour transferer les infos d une propriete
// du serveur vers le client (menu Avocat).
//
// Une entree = un joueur proprietaire + toutes ses proprietes agregees.
//------------------------------------------------------------------------------------------------

class LP_AvocatPropertyEntry
{
	string m_OwnerUID;
	string m_FirstName;
	string m_LastName;
	// Arrays paralleles : une entree = une porte (le joueur peut en avoir plusieurs)
	ref array<string> m_DoorKeys = new array<string>();     // cle stable prefab+xyz
	ref array<vector> m_Positions = new array<vector>();    // coordonnees exactes
	ref array<int> m_PurchaseUnix = new array<int>();       // timestamp d achat
	ref array<int> m_KnownCount = new array<int>();         // nb de personnes avec le code
}
