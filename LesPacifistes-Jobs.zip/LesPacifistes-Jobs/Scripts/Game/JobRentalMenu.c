//------------------------------------------------------------------------------------------------
// JobRentalMenu.c
// Menu de location de vehicule - workflow 3 etapes :
// 1. Selection du vehicule (3 choix)
// 2. Selection de la duree (1h / 2h / 3h)
// 3. Confirmation et paiement
//
// Reutilise les 3 memes boutons en changeant leur texte selon l'etape.
//------------------------------------------------------------------------------------------------

class JobRentalMenu : ChimeraMenuBase
{
	Widget m_RootWidget;
	TextWidget m_TitleText;
	TextWidget m_StepText;
	TextWidget m_InfoText;
	ButtonWidget m_Btn1;
	ButtonWidget m_Btn2;
	ButtonWidget m_Btn3;
	TextWidget m_Btn1Text;
	TextWidget m_Btn2Text;
	TextWidget m_Btn3Text;
	ButtonWidget m_BtnBack;
	ButtonWidget m_BtnClose;
	
	// Etat de selection
	int m_Step;             // 1 = vehicule, 2 = duree, 3 = confirmation
	int m_SelectedVehicle;  // EVehicleRentalType
	int m_SelectedHours;    // 1, 2 ou 3
	
	// Timestamp d ouverture (pour ignorer les clics dans les 250 premieres ms)
	int m_OpenTime;
	const int CLICK_GRACE_MS = 250;
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuOpen()
	{
		super.OnMenuOpen();
		m_RootWidget = GetRootWidget();
		if (!m_RootWidget)
			return;
		
		m_TitleText = TextWidget.Cast(m_RootWidget.FindAnyWidget("TitleText"));
		m_StepText = TextWidget.Cast(m_RootWidget.FindAnyWidget("StepText"));
		m_InfoText = TextWidget.Cast(m_RootWidget.FindAnyWidget("InfoText"));
		m_Btn1 = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("Btn1"));
		m_Btn2 = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("Btn2"));
		m_Btn3 = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("Btn3"));
		m_Btn1Text = TextWidget.Cast(m_RootWidget.FindAnyWidget("Btn1Text"));
		m_Btn2Text = TextWidget.Cast(m_RootWidget.FindAnyWidget("Btn2Text"));
		m_Btn3Text = TextWidget.Cast(m_RootWidget.FindAnyWidget("Btn3Text"));
		m_BtnBack = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnBack"));
		m_BtnClose = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnClose"));
		
		AttachButton(m_Btn1, "btn1");
		AttachButton(m_Btn2, "btn2");
		AttachButton(m_Btn3, "btn3");
		AttachButton(m_BtnBack, "back");
		AttachButton(m_BtnClose, "close");
		
		m_Step = 1;
		m_SelectedVehicle = 0;
		m_SelectedHours = 0;
		m_OpenTime = System.GetTickCount();
		ShowStep1();
	}
	
	//------------------------------------------------------------------------------------------------
	void AttachButton(ButtonWidget btn, string action)
	{
		if (!btn)
			return;
		RentalMenuClickHandler h = new RentalMenuClickHandler();
		h.m_Menu = this;
		h.m_Action = action;
		btn.AddHandler(h);
		JobFocusHandler.Attach(btn);
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuUpdate(float tDelta)
	{
		super.OnMenuUpdate(tDelta);
		if (GetGame().GetInputManager().GetActionValue("MenuBack") > 0.5)
		{
			CloseMenuInternal();
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// ETAPE 1 - Selection du vehicule
	//------------------------------------------------------------------------------------------------
	void ShowStep1()
	{
		m_Step = 1;
		if (m_StepText)
			m_StepText.SetText("Etape 1 : Choisissez votre vehicule");
		if (m_Btn1Text)
			m_Btn1Text.SetText("Tmax gris");
		if (m_Btn2Text)
			m_Btn2Text.SetText("Vieux velo");
		if (m_Btn3Text)
			m_Btn3Text.SetText("Twingo Rouge");
		if (m_InfoText)
			m_InfoText.SetText("");
		// Bouton Retour invisible a l etape 1
		if (m_BtnBack)
			m_BtnBack.SetVisible(false);
	}
	
	//------------------------------------------------------------------------------------------------
	// ETAPE 2 - Selection de la duree
	//------------------------------------------------------------------------------------------------
	void ShowStep2()
	{
		m_Step = 2;
		string vehLabel = JobVehicleRentalManager.GetVehicleLabel(m_SelectedVehicle);
		if (m_StepText)
			m_StepText.SetText(string.Format("Etape 2 : Duree de location pour %1", vehLabel));
		
		int p1 = JobVehicleRentalManager.GetPrice(m_SelectedVehicle, 1);
		int p2 = JobVehicleRentalManager.GetPrice(m_SelectedVehicle, 2);
		int p3 = JobVehicleRentalManager.GetPrice(m_SelectedVehicle, 3);
		
		if (m_Btn1Text)
			m_Btn1Text.SetText(string.Format("1 heure - %1 capsules", p1));
		if (m_Btn2Text)
			m_Btn2Text.SetText(string.Format("2 heures - %1 capsules", p2));
		if (m_Btn3Text)
			m_Btn3Text.SetText(string.Format("3 heures - %1 capsules", p3));
		
		if (m_InfoText)
			m_InfoText.SetText("Le vehicule spawnera pres de vous apres confirmation.");
		if (m_BtnBack)
			m_BtnBack.SetVisible(true);
	}
	
	//------------------------------------------------------------------------------------------------
	// ETAPE 3 - Confirmation
	//------------------------------------------------------------------------------------------------
	void ShowStep3()
	{
		m_Step = 3;
		string vehLabel = JobVehicleRentalManager.GetVehicleLabel(m_SelectedVehicle);
		int price = JobVehicleRentalManager.GetPrice(m_SelectedVehicle, m_SelectedHours);
		
		if (m_StepText)
			m_StepText.SetText("Etape 3 : Confirmation");
		if (m_Btn1Text)
			m_Btn1Text.SetText(string.Format("CONFIRMER - %1c", price));
		if (m_Btn2Text)
			m_Btn2Text.SetText("");
		if (m_Btn3Text)
			m_Btn3Text.SetText("");
		// Cache les boutons 2 et 3 sur l etape de confirmation
		if (m_Btn2)
			m_Btn2.SetVisible(false);
		if (m_Btn3)
			m_Btn3.SetVisible(false);
		// Met le bouton confirmation en vert
		if (m_Btn1)
			m_Btn1.SetColor(Color.FromRGBA(46, 128, 46, 255));
		
		if (m_InfoText)
			m_InfoText.SetText(string.Format(
				"Vehicule : %1 | Duree : %2h | Prix : %3 capsules",
				vehLabel, m_SelectedHours, price));
		if (m_BtnBack)
			m_BtnBack.SetVisible(true);
	}
	
	//------------------------------------------------------------------------------------------------
	void OnButtonClicked(string action)
	{
		// Garde : ignore les clics dans les premieres ms apres ouverture du menu
		// (sinon le click qui a ouvert le menu peut declencher immediatement le bouton focusé)
		int elapsed = System.GetTickCount() - m_OpenTime;
		if (elapsed < CLICK_GRACE_MS)
			return;
		
		if (action == "close")
		{
			CloseMenuInternal();
			return;
		}
		
		if (action == "back")
		{
			if (m_Step == 2)
			{
				m_SelectedVehicle = 0;
				ShowStep1();
			}
			else if (m_Step == 3)
			{
				// Retour a l etape 2 - on doit re-afficher les 3 boutons
				if (m_Btn2)
					m_Btn2.SetVisible(true);
				if (m_Btn3)
					m_Btn3.SetVisible(true);
				if (m_Btn1)
					m_Btn1.SetColor(Color.FromRGBA(26, 115, 165, 255));  // bleu d origine
				m_SelectedHours = 0;
				ShowStep2();
			}
			return;
		}
		
		// btn1/btn2/btn3 selon etape
		if (m_Step == 1)
		{
			if (action == "btn1")
				m_SelectedVehicle = EVehicleRentalType.GOLF_CART;
			else if (action == "btn2")
				m_SelectedVehicle = EVehicleRentalType.WW2_BIKE;
			else if (action == "btn3")
				m_SelectedVehicle = EVehicleRentalType.FORD_F150;
			ShowStep2();
		}
		else if (m_Step == 2)
		{
			if (action == "btn1")
				m_SelectedHours = 1;
			else if (action == "btn2")
				m_SelectedHours = 2;
			else if (action == "btn3")
				m_SelectedHours = 3;
			ShowStep3();
		}
		else if (m_Step == 3)
		{
			if (action == "btn1")
				DoRent();
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void DoRent()
	{
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc)
			return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc)
			return;
		jpc.ClientAskRentVehicle(m_SelectedVehicle, m_SelectedHours);
		CloseMenuInternal();
	}
	
	//------------------------------------------------------------------------------------------------
	void CloseMenuInternal()
	{
		GetGame().GetMenuManager().CloseMenu(this);
	}
}

class RentalMenuClickHandler : ScriptedWidgetEventHandler
{
	JobRentalMenu m_Menu;
	string m_Action;
	
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu)
			m_Menu.OnButtonClicked(m_Action);
		return true;
	}
}