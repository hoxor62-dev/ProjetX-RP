//------------------------------------------------------------------------------------------------
// JobVirtualGarageManager.c
// Singleton serveur qui gere le garage virtuel des joueurs.
//
// Fonctionnement :
//   - Stockage : sauvegarde le vehicule cible (prefab, etat, inventaire de tous les storages)
//     dans le JSON puis supprime l entite physique.
//   - Recuperation : spawn un nouveau vehicule du prefab sauvegarde, restaure son etat et
//     son inventaire, puis supprime l entree JSON.
//
// Sauve a $profile:LesPacifistesJobs/virtual_garage.json
// Pas de limite de vehicules stockes par joueur. Filtre proprietaire : NON (toute voiture
// a portee est stockable - amelioration future possible).
//------------------------------------------------------------------------------------------------

// ===== STRUCTURES DE DONNEES =====

// Un item stocke dans un slot d inventaire d un vehicule
class JobGarageItem
{
	string m_PrefabName;     // resource name du prefab item
	int m_Quantity = 1;      // pour stackable (munitions, etc.)
}

// Un vehicule stocke dans le garage virtuel
// Damage d une hitzone (ex: "Engine" -> 0.5, "Hull" -> 0.2, etc.)
class JobGarageHitzoneDamage
{
	string m_HitzoneName;
	float m_DamageValue;       // 0.0 (sain) a 1.0 (detruit)
}

class JobGarageVehicle
{
	string m_OwnerUID;          // UID du proprietaire courant (= propriétaire si garage perso ;
	                            //   = "FOURRIERE_SHARED" si vehicule confisque a la fourriere)
	string m_OriginalOwnerUID;  // UID du proprietaire D ORIGINE au moment du depot
	                            //   (si personne detecte = egal a m_OwnerUID au moment du depot).
	                            //   Permet a la fourriere d afficher a qui appartient la caisse.
	string m_PrefabName;        // resource name du prefab vehicule
	string m_InstanceUUID;      // UUID d assurance (persistant entre sortie/rentree). "" si non assure.
	string m_VehicleUUID;       // UUID d IDENTITE stable du vehicule (persiste entre reboot/crash).
	                            //   Genere a l achat chez le concessionnaire, voyage avec le vehicule
	                            //   dans toutes les transitions (stock garage / spawn / transfert).
	float m_Damage = 0;         // 0.0 (intact) a 1.0 (detruit) - DEPRECATED, conserve pour compat saves
	float m_Fuel = -1;          // -1 = inconnu, sinon litres
	ref array<ref JobGarageItem> m_Items = new array<ref JobGarageItem>();
	ref array<ref JobGarageHitzoneDamage> m_HitzoneDamages = new array<ref JobGarageHitzoneDamage>();
}

//------------------------------------------------------------------------------------------------
// Snapshot d un vehicule actif (spawn sur la map, suivi par le manager pour resister aux reboot).
// Sauvegarde periodique dans active_vehicles.json : position + rotation + proprio + etat.
//------------------------------------------------------------------------------------------------
class JobActiveVehicleData
{
	string m_VehicleUUID;       // identite stable (pivot)
	string m_OwnerUID;           // proprietaire courant
	string m_PrefabName;         // resource name pour respawn au reboot
	string m_PosStr;             // position derniere connue, format "x y z"
	string m_RotStr;             // rotation (angles yaw pitch roll)
	string m_InsuranceUUID;      // UUID assurance (JobInsuranceManager). "" si non assure.
	                             // Permet au reboot de ReattachExistingUUID + InstallDamageWatcher.
	float m_Fuel = -1;           // litres (-1 = inconnu)
	ref array<ref JobGarageHitzoneDamage> m_HitzoneDamages = new array<ref JobGarageHitzoneDamage>();
	int m_LastUpdateUnix;        // timestamp dernier update (debug)
}

//------------------------------------------------------------------------------------------------
// Etat d un watcher damage (vehicule assure spawne). Utilise par le tick global du manager.
//------------------------------------------------------------------------------------------------
class JobInsuranceWatcherState
{
	string m_UUID;        // UUID d assurance
	string m_OwnerUID;    // UID proprietaire
	ResourceName m_Prefab; // Prefab du vehicule (pour auto-respawn)
	string m_RplKey;      // RplId du vehicule spawne (string pour lookup map)
	// OPTIM : refs damage components cachees pour eviter FindComponent a chaque tick (toutes les 5s)
	SCR_VehicleDamageManagerComponent m_CachedScrDmg;
	DamageManagerComponent m_CachedBaseDmg;
	IEntity m_CachedEntity; // ref faible : si l entite est detruite, elle devient null (geree par GC Enforce)
}

// ===== LE MANAGER =====

class JobVirtualGarageManager
{
	static ref JobVirtualGarageManager s_Instance;
	
	// === PERSISTANCE SHARDEE PAR UID ===
	// Chaque joueur a son propre fichier shard sous SHARD_DIR/<UID>.json.
	// Un fichier _index.json liste les UIDs connus pour load au boot.
	// SAVE_PATH (monolithique legacy) est garde pour la MIGRATION au premier boot.
	const string SHARD_DIR = "$profile:LesPacifistesJobs/virtual_garage/";
	const string SHARD_INDEX_PATH = "$profile:LesPacifistesJobs/virtual_garage/_index.json";
	const string SAVE_PATH = "$profile:LesPacifistesJobs/virtual_garage.json";       // legacy, lecture migration seulement
	const string OLD_BACKUP_PATH = "$profile:LesPacifistesJobs/virtual_garage.json.bak"; // backup apres migration
	const float DEPOSIT_RANGE = 5.0;   // distance max PNJ <-> vehicule pour pouvoir stocker
	const float SPAWN_DISTANCE = 5.0;  // distance devant le PNJ pour spawn au retrait
	
	// === BLACKLIST VEHICULES DE LOCATION (non stockables) ===
	// Ces vehicules sont gerees par le systeme de location et ne doivent jamais entrer
	// dans le garage virtuel personnel des joueurs.
	static const string RENTAL_GUID_1 = "{C25C065F5B173ED6}";  // motorbike
	static const string RENTAL_GUID_2 = "{3FDBFE7F1A1EB8F2}";  // WW2_Bike_base
	static const string RENTAL_GUID_3 = "{1B3D4C7040A97656}";  // S105_darkblue
	static const string RENTAL_GUID_4 = "{4BCA032A9D4D0E09}";  // gendarmerie
	static const string RENTAL_GUID_5 = "{A18C3A6B44DE8A56}";  // smur
	
	


	// === BLACKLIST ITEMS ILLEGAUX (drogues + armes) ===
	// Un vehicule contenant l un de ces items (meme dans un sac imbrique) sera refuse
	// au stockage : "Le garagiste refuse de garder un vehicule avec des choses illegales !"
	// Le scan est RECURSIF : coffre + sacs imbriques + attaches d armes.
	// Pour ajouter/retirer un item, modifie la liste ci-dessous et ajuste ILLEGAL_COUNT.
	const int ILLEGAL_COUNT = 18;
	static const string ILLEGAL_GUID_01 = "{FB1CC21B8E56BCEC}";  // CocaineBag
	static const string ILLEGAL_GUID_02 = "{29CAED9E186127A1}";  // WeedBag
	static const string ILLEGAL_GUID_03 = "{C3D01F32432A1FF1}";  // cannabis-frais
	static const string ILLEGAL_GUID_04 = "{76BD00F7988BC108}";  // Cock (grenade)
	static const string ILLEGAL_GUID_06 = "{0A0D83B06541BF5F}";  // Handgun_PM_Gold
	static const string ILLEGAL_GUID_07 = "{8E4663FD6B74BB57}";  // BayonetKnifeAC
	static const string ILLEGAL_GUID_08 = "{2189664E08B26B2A}";  // ButterflyKnifeAC
	static const string ILLEGAL_GUID_09 = "{E5FF2886246E0797}";  // HuntsmanKnifeAC
	static const string ILLEGAL_GUID_10 = "{49EAF95FBCF04EE8}";  // KarambitKnifeAC
	static const string ILLEGAL_GUID_11 = "{A9F072E6A79A9E8A}";  // Rifle_AKS74U_Gold
	static const string ILLEGAL_GUID_12 = "{1353C6EAD1DCFE43}";  // Handgun_M9
	static const string ILLEGAL_GUID_13 = "{3D3758C525994D3A}";  // Shotgun_Double_Barrel_610mm
	static const string ILLEGAL_GUID_14 = "{3C4FB3D9D54B46DF}";  // Shotgun_Double_Barrel_760mm
	static const string ILLEGAL_GUID_15 = "{E7A3BA1F06C057FF}";  // Shotgun_Double_Barrel_Sawn_Off
	static const string ILLEGAL_GUID_16 = "{9655CB851205DF47}";  // Shotgun_Ithaca_37
	static const string ILLEGAL_GUID_17 = "{34B2434D37E3FF16}";  // Shotgun_Ithaca_37_Sawed
	static const string ILLEGAL_GUID_18 = "{458A4E8CD3590D92}";  // Shotgun_Remington_870
	
	// Tous les vehicules stockes (toutes proprietaires confondus)
	ref array<ref JobGarageVehicle> m_Vehicles;

	// === MAP RUNTIME PROPRIETAIRES ===
	// Cle = rplId.ToString() du vehicule en jeu, Valeur = UID du proprietaire.
	// Volatile : reset a chaque reboot serveur (cf doc). Un vehicule sortant du garage
	// virtuel est ajoute ici. Au stockage on verifie cette map :
	//  - si le vehicule y est et que ownerUID != joueur : refus (vol)
	//  - sinon : OK (premier stockage ou vehicule "libre" apres reboot)
	ref map<string, string> m_VehicleOwners;

	// === REGISTRE DES VEHICULES ACTIFS (sur la map, hors garage virtuel) ===
	// Cle = m_VehicleUUID (stable). Valeur = snapshot complet pour respawn au reboot.
	// PERSISTANT (sauvegarde dans active_vehicles.json toutes les 60s et sur changements).
	// Un vehicule est a tout moment dans UN SEUL etat :
	//   - soit stocke dans m_Vehicles (garage virtuel)
	//   - soit actif dans m_ActiveVehicles (sur la map, visible, conduit)
	// Les transitions store/retrieve/transfert mutent les deux structures atomiquement.
	ref map<string, ref JobActiveVehicleData> m_ActiveVehicles;

	const string ACTIVE_SAVE_PATH = "$profile:LesPacifistesJobs/active_vehicles.json";
	const int ACTIVE_SNAPSHOT_TICK_MS = 180000; // save periodique position/etat des actifs (3 min)

	// Round-robin : chaque tick traite uniquement 1/N des vehicules. Chaque vehicule a donc
	// sa chance toutes les ACTIVE_SNAPSHOT_TICK_MS * SNAPSHOT_SHARDS = 180s * 5 = 900s (15 min).
	// Reduit drastiquement le coût d un tick individuel.
	const int SNAPSHOT_SHARDS = 5;
	int m_SnapshotCursor = 0;

	// === DEBOUNCE DES ECRITURES DISQUE ===
	// Au lieu d ecrire sync a chaque store/retrieve/update, on marque dirty et on ecrit
	// une seule fois apres SAVE_DEBOUNCE_MS. Si 3 joueurs rangent en meme temps, on fait
	// 1 ecriture au lieu de 3. Perte max en cas de crash : SAVE_DEBOUNCE_MS de donnees.
	const int SAVE_DEBOUNCE_MS = 5000; // 5s : groupe mieux les operations en pic (reduit nb d I/O bloquantes)
	bool m_ActiveSaveDirty = false;
	bool m_ActiveSaveScheduled = false;
	// === DIRTY TRACKING PAR UID (shards) ===
	// Set des UIDs dont le fichier shard doit etre reecrit au prochain flush.
	// Plus efficace qu un flag global : chaque shard etant petit (~50 KB max),
	// 10 shards x 20ms = 200ms repartis au lieu d un gros write de 4MB x 500ms.
	ref set<string> m_DirtyOwnerUIDs = new set<string>();
	bool m_IndexDirty = false; // true si des UIDs ont ete ajoutes/retires (requiert reecrit l index)
	bool m_GarageSaveScheduled = false;

	// === PURGE PERIODIQUE DES CACHES ===
	// Toutes les N ticks snapshot, on balaye m_UUIDToEntityCache et m_VehicleOwners pour
	// retirer les entries dont l entite n existe plus. Previent le buildup lent de refs
	// mortes qui ralentit les iterations apres plusieurs heures de serveur.
	int m_PurgeTickCounter = 0;
	const int PURGE_EVERY_N_TICKS = 5; // purge toutes les 5 * 180s = 15 min

	// === CACHE DIRECT UUID -> IEntity (OPTIMISATION PERF) ===
	// Evite de scanner tout le monde avec QueryEntitiesByAABB a chaque tick snapshot.
	// Rempli au spawn (RegisterNewPurchase, RegisterRetrievedVehicle, Reconciliation)
	// et vide au stockage garage (UnregisterActiveVehicle). Volatile : reset au reboot.
	// Si une entree devient null (vehicule detruit), fallback automatique vers QueryEntitiesByAABB.
	ref map<string, IEntity> m_UUIDToEntityCache;
	
	// === CLEF VIERGE : COOLDOWN PAR JOUEUR ===
	// Cle = UID joueur, Valeur = timestamp Unix de la derniere distribution.
	// Volatile : reset au reboot serveur (choix du boss).
	// Resource a spawn dans l inventaire (stocke en string, converti en ResourceName a l usage) :
	const string BLANK_KEY_PREFAB = "{CCFD8AA837B9611A}Prefabs/Items/CarKey/CarKey.et";
	const int BLANK_KEY_COOLDOWN_SECONDS = 1800;  // 30 minutes
	ref map<string, int> m_BlankKeyCooldowns;
	
	//------------------------------------------------------------------------------------------------
	void JobVirtualGarageManager()
	{
		m_Vehicles = new array<ref JobGarageVehicle>();
		m_VehicleOwners = new map<string, string>();
		m_BlankKeyCooldowns = new map<string, int>();
		m_ActiveVehicles = new map<string, ref JobActiveVehicleData>();
		m_UUIDToEntityCache = new map<string, IEntity>();
	}
	
	//------------------------------------------------------------------------------------------------
	static JobVirtualGarageManager GetInstance()
	{
		if (!s_Instance)
		{
			s_Instance = new JobVirtualGarageManager();
			s_Instance.Init();
		}
		return s_Instance;
	}
	
	//------------------------------------------------------------------------------------------------
	void Init()
	{
		Print("[JobVirtualGarageManager] Initialisation", LogLevel.NORMAL);
		// CRITIQUE : s assure que le dossier des shards existe AVANT le premier save.
		// Sans ca, SCR_JsonSaveContext.SaveToFile echoue silencieusement et aucun shard
		// n est jamais ecrit sur disque, meme si l index est cree.
		EnsureShardDirExists();
		LoadFromDisk();
		LoadActiveVehiclesFromDisk();

		// DEDUPLICATION : un vehicule peut etre a la fois dans m_Vehicles (garage virtuel)
		// ET dans m_ActiveVehicles (sur la map) si une operation garage a eu lieu sans etre
		// persistee sur disque (ex: crash, migration incomplete). On privilegie la version
		// active (celle que le joueur voit en jeu) et on retire du garage virtuel.
		DedupeActiveVsStored();

		// Reconciliation differee pour laisser le monde se charger entierement
		// (les vehicules du save-world natif ou de notre JSON doivent etre spawn/presents).
		GetGame().GetCallqueue().CallLater(ReconcileActiveVehiclesAtStartup, 10000, false);

		// Tick global de sauvegarde periodique des positions/etats
		GetGame().GetCallqueue().CallLater(TickSnapshotActiveVehicles, ACTIVE_SNAPSHOT_TICK_MS, true);
	}

	//------------------------------------------------------------------------------------------------
	// DEDUP : parcourt m_Vehicles, retire les entrees dont le m_VehicleUUID stable existe
	// aussi dans m_ActiveVehicles. Ce sont des doublons crees quand une operation garage
	// (retrait) n a pas ete persistee avant un crash/reboot, mais que active_vehicles.json
	// l etait. Marque les UIDs touches dirty pour reecrire les shards sans doublons.
	//------------------------------------------------------------------------------------------------
	void DedupeActiveVsStored()
	{
		if (!m_Vehicles || !m_ActiveVehicles)
			return;
		int removedCount = 0;
		ref set<string> touchedUIDs = new set<string>();
		// Iteration en arriere pour pouvoir faire Remove sans casser l index
		for (int i = m_Vehicles.Count() - 1; i >= 0; i--)
		{
			JobGarageVehicle v = m_Vehicles.Get(i);
			if (!v || v.m_VehicleUUID == "")
				continue; // pas d UUID stable -> on ne peut pas dedupliquer
			if (m_ActiveVehicles.Contains(v.m_VehicleUUID))
			{
				Print(string.Format("[JobVirtualGarageManager] DEDUP : doublon detecte uuid=%1 owner=%2 prefab=%3 (vehicule actif sur map, retrait du garage virtuel)",
					v.m_VehicleUUID, v.m_OwnerUID, v.m_PrefabName), LogLevel.WARNING);
				touchedUIDs.Insert(v.m_OwnerUID);
				m_Vehicles.Remove(i);
				removedCount++;
			}
		}
		if (removedCount > 0)
		{
			// Reecrit les shards touches pour persister la dedup
			for (int j = 0; j < touchedUIDs.Count(); j++)
				MarkOwnerDirty(touchedUIDs.Get(j));
			Print(string.Format("[JobVirtualGarageManager] DEDUP : %1 doublons supprimes sur %2 UIDs touches",
				removedCount, touchedUIDs.Count()), LogLevel.WARNING);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== REQUETES (LECTURE) =====
	//------------------------------------------------------------------------------------------------

	//------------------------------------------------------------------------------------------------
	// Lookup proprietaire par UUID stable.
	// Cherche d abord dans les vehicules actifs (circulant sur la map), puis dans le garage.
	// Retourne "" si l UUID n est associe a aucun vehicule connu.
	// Utilise par la recherche police par plaque d immatriculation.
	//------------------------------------------------------------------------------------------------
	string GetOwnerUIDFromVehicleUUID(string uuid)
	{
		if (uuid == "")
			return "";

		// 1) Cherche d abord dans les vehicules actifs (sur la map)
		if (m_ActiveVehicles)
		{
			JobActiveVehicleData active;
			if (m_ActiveVehicles.Find(uuid, active) && active)
			{
				if (active.m_OwnerUID != "")
					return active.m_OwnerUID;
			}
		}

		// 2) Puis dans le garage (vehicules stockes)
		if (m_Vehicles)
		{
			for (int i = 0; i < m_Vehicles.Count(); i++)
			{
				JobGarageVehicle v = m_Vehicles.Get(i);
				if (v && v.m_VehicleUUID == uuid && v.m_OwnerUID != "")
					return v.m_OwnerUID;
			}
		}

		return "";
	}

	//------------------------------------------------------------------------------------------------
	// Retourne les vehicules stockes du joueur UID, dans l ordre d insertion (le plus
	// ancien d abord). Les indices renvoyes dans outIndexes correspondent aux indices
	// dans m_Vehicles (a utiliser pour RetrieveVehicleByIndex).
	void GetPlayerVehicles(string uid, out array<int> outIndexes, out array<string> outPrefabs)
	{
		// Version simple retro-compatible (sans isInsured)
		for (int i = 0; i < m_Vehicles.Count(); i++)
		{
			JobGarageVehicle v = m_Vehicles.Get(i);
			if (v && v.m_OwnerUID == uid)
			{
				outIndexes.Insert(i);
				outPrefabs.Insert(v.m_PrefabName);
			}
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Version etendue avec flag d assurance (utilise par le menu Garage pour afficher le label).
	// Un vehicule est considere "assure" si son m_InstanceUUID n est pas vide ET
	// que l UUID existe encore dans JobInsuranceManager (defense-en-profondeur).
	//------------------------------------------------------------------------------------------------
	void GetPlayerVehiclesWithInsurance(string uid, out array<int> outIndexes, out array<string> outPrefabs, out array<bool> outInsured)
	{
		JobInsuranceManager insMgr = JobInsuranceManager.GetInstance();
		for (int i = 0; i < m_Vehicles.Count(); i++)
		{
			JobGarageVehicle v = m_Vehicles.Get(i);
			if (v && v.m_OwnerUID == uid)
			{
				outIndexes.Insert(i);
				outPrefabs.Insert(v.m_PrefabName);
				// Assure = a un UUID ET l assurance est encore active
				bool isIns = false;
				if (v.m_InstanceUUID != "" && insMgr)
					isIns = insMgr.IsUUIDInsured(v.m_InstanceUUID);
				outInsured.Insert(isIns);
			}
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Verifie rapidement si un vehicule du garage (par index) appartient au joueur et est assure.
	// Utilise par le RPC RpcAsk_InsureAndRetrieveVehicle pour refuser un double-achat.
	//
	// Retourne :
	//   0 = index invalide ou pas le proprietaire
	//   1 = NON assure
	//   2 = deja assure
	//------------------------------------------------------------------------------------------------
	int GetInsuranceStatusOfEntry(string ownerUID, int index)
	{
		if (index < 0 || index >= m_Vehicles.Count())
			return 0;
		JobGarageVehicle v = m_Vehicles.Get(index);
		if (!v || v.m_OwnerUID != ownerUID)
			return 0;
		if (v.m_InstanceUUID == "")
			return 1;
		JobInsuranceManager insMgr = JobInsuranceManager.GetInstance();
		if (insMgr && insMgr.IsUUIDInsured(v.m_InstanceUUID))
			return 2;
		return 1;
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== STOCKAGE (DEPOT) =====
	// Cherche le vehicule le plus proche du PNJ (max DEPOSIT_RANGE), sauve son etat
	// + inventaire dans la liste persistante, puis supprime l entite physique.
	//
	// Verifie au passage que le vehicule appartient au joueur (via m_VehicleOwners).
	// Si le vehicule n est pas dans la map (vehicule "libre" jamais stocke ou serveur
	// rebootee), le joueur en devient proprietaire automatiquement.
	//
	// Verifie aussi que le vehicule n est pas un vehicule de location (blacklist).
	//
	// Retourne :
	//   0  = OK depot reussi (le prefab du vehicule est dans outVehiclePrefab pour notif)
	//   1  = aucun vehicule a portee
	//   2  = vehicule trouve mais erreur lors de la lecture du prefab (cas rare)
	//   3  = vehicule trouve mais appartient a un autre joueur (vol)
	//   4  = vehicule de location (blacklist), non stockable
	//   5  = vehicule contient des items illegaux (drogues, armes prohibees)
	//------------------------------------------------------------------------------------------------
	int StoreVehicleNearPos(string ownerUID, vector npcPos, out string outVehiclePrefab)
	{
		outVehiclePrefab = "";
		
		// 1. Trouve le vehicule le plus proche du PNJ
		IEntity vehicle = FindClosestVehicle(npcPos, DEPOSIT_RANGE);
		if (!vehicle)
			return 1;
		
		// 2. Lit son prefab (necessaire pour les checks blacklist + creation entree)
		EntityPrefabData pd = vehicle.GetPrefabData();
		if (!pd)
			return 2;
		ResourceName prefabName = pd.GetPrefabName();
		if (prefabName == "" || prefabName == ResourceName.Empty)
			return 2;
		
		// 3. Check blacklist : vehicule de location ?
		if (IsRentalVehicle(prefabName))
			return 4;
		
		// 4. Check items illegaux dans le vehicule (scan recursif : coffre + sacs imbriques)
		if (HasIllegalItems(vehicle))
			return 5;
		
		// 5. Verifie la propriete via la map runtime
		RplComponent rpl = RplComponent.Cast(vehicle.FindComponent(RplComponent));
		string rplKey = "";
		if (rpl)
			rplKey = rpl.Id().ToString();
		
		if (rplKey != "" && m_VehicleOwners.Contains(rplKey))
		{
			string registeredOwner = m_VehicleOwners.Get(rplKey);
			if (registeredOwner != "" && registeredOwner != ownerUID)
			{
				// Vehicule appartient a quelqu un d autre : refus
				return 3;
			}
		}
		
		outVehiclePrefab = prefabName;
		
		// 6. Cree l entree de garage
		JobGarageVehicle entry = new JobGarageVehicle();
		entry.m_OwnerUID = ownerUID;
		entry.m_OriginalOwnerUID = ownerUID; // garage perso : proprio courant = original
		entry.m_PrefabName = prefabName;

		// 6b. Recupere l UUID d assurance eventuel du vehicule (pour persistance)
		// Ainsi si le vehicule est assure, l assurance sera restauree au retrait.
		entry.m_InstanceUUID = JobInsuranceManager.GetInstance().GetVehicleInstanceId(vehicle);

		// 6b-bis. Preserve l UUID d IDENTITE stable (voyage avec le vehicule entre
		// garage virtuel et map, resiste au reboot/crash).
		LP_VehiclePersistComponent persistComp = GetPersistComponent(vehicle);
		if (persistComp)
		{
			entry.m_VehicleUUID = persistComp.GetVehicleUUID();
			// Retire l entree correspondante du registre actif (passe en etat "stocke")
			if (entry.m_VehicleUUID != "")
				UnregisterActiveVehicle(entry.m_VehicleUUID);
		}
		
		// 6c. Sauve l etat (vie + carburant + hitzones detaillees)
		entry.m_Damage = ReadVehicleDamage(vehicle);
		entry.m_Fuel = ReadVehicleFuel(vehicle);
		ReadVehicleHitzones(vehicle, entry.m_HitzoneDamages);
		
		// 7. Sauve l inventaire complet (tous storages internes)
		ReadVehicleInventory(vehicle, entry.m_Items);
		
		// 8. Ajoute a la liste + sauve disque (differe, shard du proprietaire uniquement)
		m_Vehicles.Insert(entry);
		MarkOwnerDirty(entry.m_OwnerUID);

		// 9. Retire de la map runtime (le vehicule n existe plus en jeu)
		if (rplKey != "")
			m_VehicleOwners.Remove(rplKey);
		
		// 9b. Si le vehicule etait assure, on retire le tracking runtime AVANT la suppression
		// (sans ca, le tick assurance croit a une destruction et cree un doublon).
		// L UUID lui-meme est conserve dans m_InsurancesByUUID + dans entry.m_InstanceUUID.
		JobInsuranceManager.GetInstance().ClearRuntimeMapping(vehicle);
		
		// 10. Supprime l entite vehicule
		SCR_EntityHelper.DeleteEntityAndChildren(vehicle);
		
		Print(string.Format("[JobVirtualGarageManager] Stockage : owner=%1 prefab=%2 items=%3",
			ownerUID, prefabName, entry.m_Items.Count()), LogLevel.NORMAL);
		return 0;
	}

	//------------------------------------------------------------------------------------------------
	// === STOCKAGE SPECIFIQUE FOURRIERE ===
	// Variante de StoreVehicleNearPos pour le metier Fourriere :
	//   - L owner COURANT devient le UID partage (ex: "FOURRIERE_SHARED")
	//   - L owner ORIGINAL est detecte depuis m_VehicleOwners et conserve dans
	//     entry.m_OriginalOwnerUID, pour pouvoir afficher qui etait le vrai proprio
	//   - La verification de propriete (return 3) est DESACTIVEE : la fourriere peut
	//     confisquer la caisse de n importe qui
	//
	// outOriginalOwnerUID est renseigne avec le UID du vrai proprio detecte (ou "" si inconnu).
	//
	// Retourne (meme table que StoreVehicleNearPos sauf "3" qui n est plus retourne) :
	//   0 = OK depose
	//   1 = aucun vehicule a portee
	//   2 = erreur de lecture prefab
	//   4 = vehicule de location (blacklist)
	//   5 = vehicule contient des items illegaux
	//------------------------------------------------------------------------------------------------
	int StoreVehicleForFourriere(string sharedOwnerUID, vector npcPos, out string outVehiclePrefab, out string outOriginalOwnerUID)
	{
		outVehiclePrefab = "";
		outOriginalOwnerUID = "";

		// 1. Trouve le vehicule le plus proche
		IEntity vehicle = FindClosestVehicle(npcPos, DEPOSIT_RANGE);
		if (!vehicle)
			return 1;

		// 2. Lit son prefab
		EntityPrefabData pd = vehicle.GetPrefabData();
		if (!pd)
			return 2;
		ResourceName prefabName = pd.GetPrefabName();
		if (prefabName == "" || prefabName == ResourceName.Empty)
			return 2;

		// 3. Blacklist location
		if (IsRentalVehicle(prefabName))
			return 4;

		// 4. Blacklist items illegaux
		if (HasIllegalItems(vehicle))
			return 5;

		// 5. Detecte le vrai proprio (si tracke) MAIS n applique pas de rejet
		RplComponent rpl = RplComponent.Cast(vehicle.FindComponent(RplComponent));
		string rplKey = "";
		if (rpl)
			rplKey = rpl.Id().ToString();

		if (rplKey != "" && m_VehicleOwners.Contains(rplKey))
		{
			string registeredOwner = m_VehicleOwners.Get(rplKey);
			if (registeredOwner != "")
				outOriginalOwnerUID = registeredOwner;
		}
		// Si pas de proprietaire tracke, outOriginalOwnerUID reste "" (vehicule libre /
		// serveur rebootee / jamais stocke par personne).

		outVehiclePrefab = prefabName;

		// 6. Cree l entree de garage sous l UID partage, en conservant l owner original
		JobGarageVehicle entry = new JobGarageVehicle();
		entry.m_OwnerUID = sharedOwnerUID;
		entry.m_OriginalOwnerUID = outOriginalOwnerUID;
		entry.m_PrefabName = prefabName;
		entry.m_InstanceUUID = JobInsuranceManager.GetInstance().GetVehicleInstanceId(vehicle);

		// Preserve l UUID d IDENTITE stable et retire du registre actif
		LP_VehiclePersistComponent persistCompF = GetPersistComponent(vehicle);
		if (persistCompF)
		{
			entry.m_VehicleUUID = persistCompF.GetVehicleUUID();
			if (entry.m_VehicleUUID != "")
				UnregisterActiveVehicle(entry.m_VehicleUUID);
		}

		entry.m_Damage = ReadVehicleDamage(vehicle);
		entry.m_Fuel = ReadVehicleFuel(vehicle);
		ReadVehicleHitzones(vehicle, entry.m_HitzoneDamages);
		ReadVehicleInventory(vehicle, entry.m_Items);

		m_Vehicles.Insert(entry);
		MarkOwnerDirty(entry.m_OwnerUID); // = sharedOwnerUID (FOURRIERE_SHARED)

		// 7. Nettoyage runtime
		if (rplKey != "")
			m_VehicleOwners.Remove(rplKey);
		JobInsuranceManager.GetInstance().ClearRuntimeMapping(vehicle);
		SCR_EntityHelper.DeleteEntityAndChildren(vehicle);

		Print(string.Format("[JobVirtualGarageManager] Stockage FOURRIERE : original=%1 shared=%2 prefab=%3",
			outOriginalOwnerUID, sharedOwnerUID, prefabName), LogLevel.NORMAL);
		return 0;
	}

	//------------------------------------------------------------------------------------------------
	// Variante de GetPlayerVehiclesWithInsurance qui renvoie EN PLUS les UIDs des proprios
	// originaux. Utilise par la Fourriere pour afficher a qui appartenait chaque caisse.
	//------------------------------------------------------------------------------------------------
	void GetVehiclesWithOriginalOwners(string ownerUID,
		out array<int> outIndexes,
		out array<string> outPrefabs,
		out array<bool> outInsured,
		out array<string> outOriginalOwners)
	{
		for (int i = 0; i < m_Vehicles.Count(); i++)
		{
			JobGarageVehicle v = m_Vehicles.Get(i);
			if (!v || v.m_OwnerUID != ownerUID)
				continue;
			outIndexes.Insert(i);
			outPrefabs.Insert(v.m_PrefabName);
			outInsured.Insert(v.m_InstanceUUID != "");
			outOriginalOwners.Insert(v.m_OriginalOwnerUID);
		}
	}

	//------------------------------------------------------------------------------------------------
	// Ajoute directement un vehicule au garage virtuel d un joueur, sans verif PNJ ni inventaire.
	// Utilise par le systeme d assurance pour restituer un vehicule detruit.
	// Le vehicule est ajoute avec damage=0 et fuel=-1 (pas d inventaire).
	//------------------------------------------------------------------------------------------------
	void AddVehicleDirect(string ownerUID, string prefabName)
	{
		if (!m_Vehicles)
			return;
		if (ownerUID == "" || prefabName == "")
			return;
		
		JobGarageVehicle entry = new JobGarageVehicle();
		entry.m_OwnerUID = ownerUID;
		entry.m_OriginalOwnerUID = ownerUID; // garage perso : proprio courant = original
		entry.m_PrefabName = prefabName;
		entry.m_Damage = 0;
		entry.m_Fuel = -1;
		m_Vehicles.Insert(entry);
		MarkOwnerDirty(entry.m_OwnerUID);

		Print(string.Format("[JobVirtualGarageManager] AddVehicleDirect (assurance) : owner=%1 prefab=%2",
			ownerUID, prefabName), LogLevel.NORMAL);
	}
	
	//------------------------------------------------------------------------------------------------
	// Retourne true si le prefab donne fait partie de la blacklist des vehicules de location.
	// Ces vehicules sont gerees par le systeme de location et ne doivent pas finir dans
	// le garage virtuel personnel d un joueur.
	//------------------------------------------------------------------------------------------------
	bool IsRentalVehicle(string prefabName)
	{
		if (prefabName == "")
			return false;
		// Match par prefixe du GUID (ResourceName commence par {GUID}path/file.et)
		if (prefabName.IndexOf(RENTAL_GUID_1) == 0)
			return true;
		if (prefabName.IndexOf(RENTAL_GUID_2) == 0)
			return true;
		if (prefabName.IndexOf(RENTAL_GUID_3) == 0)
			return true;
		if (prefabName.IndexOf(RENTAL_GUID_4) == 0)
			return true;
		if (prefabName.IndexOf(RENTAL_GUID_5) == 0)
			return true;
		return false;
	}
	
	//------------------------------------------------------------------------------------------------
	// Retourne true si le prefab donne fait partie de la blacklist des items illegaux
	// (drogues, armes prohibees, grenades). Match par prefixe du GUID.
	//------------------------------------------------------------------------------------------------
	bool IsIllegalPrefab(string prefabName)
	{
		if (prefabName == "")
			return false;
		if (prefabName.IndexOf(ILLEGAL_GUID_01) == 0) return true;
		if (prefabName.IndexOf(ILLEGAL_GUID_02) == 0) return true;
		if (prefabName.IndexOf(ILLEGAL_GUID_03) == 0) return true;
		if (prefabName.IndexOf(ILLEGAL_GUID_04) == 0) return true;
		if (prefabName.IndexOf(ILLEGAL_GUID_06) == 0) return true;
		if (prefabName.IndexOf(ILLEGAL_GUID_07) == 0) return true;
		if (prefabName.IndexOf(ILLEGAL_GUID_08) == 0) return true;
		if (prefabName.IndexOf(ILLEGAL_GUID_09) == 0) return true;
		if (prefabName.IndexOf(ILLEGAL_GUID_10) == 0) return true;
		if (prefabName.IndexOf(ILLEGAL_GUID_11) == 0) return true;
		if (prefabName.IndexOf(ILLEGAL_GUID_12) == 0) return true;
		if (prefabName.IndexOf(ILLEGAL_GUID_13) == 0) return true;
		if (prefabName.IndexOf(ILLEGAL_GUID_14) == 0) return true;
		if (prefabName.IndexOf(ILLEGAL_GUID_15) == 0) return true;
		if (prefabName.IndexOf(ILLEGAL_GUID_16) == 0) return true;
		if (prefabName.IndexOf(ILLEGAL_GUID_17) == 0) return true;
		if (prefabName.IndexOf(ILLEGAL_GUID_18) == 0) return true;
		return false;
	}
	
	//------------------------------------------------------------------------------------------------
	// Scan RECURSIF : verifie si le vehicule (ou une de ses entites imbriquees) contient
	// un item de la blacklist ILLEGAL_GUID_XX.
	//
	// Le scan traverse :
	//   1. Tous les BaseInventoryStorageComponent du vehicule (coffre + sieges + secondaires)
	//   2. Pour chaque item trouve, recurse dans ses propres storages (sacs, gilets, etc.)
	//
	// Retourne true des qu un item illegal est trouve (short-circuit pour perf).
	//------------------------------------------------------------------------------------------------
	bool HasIllegalItems(IEntity vehicle)
	{
		if (!vehicle)
			return false;
		return RecursiveScanForIllegal(vehicle, 0);
	}
	
	//------------------------------------------------------------------------------------------------
	// Scan recursif interne. Le parametre depth previent les boucles infinies (max 5 niveaux
	// d imbrication, largement suffisant pour un sac dans un sac dans un sac...).
	//------------------------------------------------------------------------------------------------
	bool RecursiveScanForIllegal(IEntity entity, int depth)
	{
		if (!entity || depth > 5)
			return false;
		
		// Recupere tous les storages de cette entite (vehicule = coffre + sieges,
		// item = les containers internes s il en a comme un sac)
		array<Managed> storages = new array<Managed>();
		entity.FindComponents(BaseInventoryStorageComponent, storages);
		if (storages.Count() == 0)
			return false;
		
		foreach (Managed sMgd : storages)
		{
			BaseInventoryStorageComponent storage = BaseInventoryStorageComponent.Cast(sMgd);
			if (!storage)
				continue;
			
			int slotCount = storage.GetSlotsCount();
			for (int i = 0; i < slotCount; i++)
			{
				InventoryStorageSlot slot = storage.GetSlot(i);
				if (!slot)
					continue;
				IEntity itemEnt = slot.GetAttachedEntity();
				if (!itemEnt)
					continue;
				
				// Check le prefab de l item
				EntityPrefabData pd = itemEnt.GetPrefabData();
				if (pd)
				{
					ResourceName rn = pd.GetPrefabName();
					if (rn != "" && rn != ResourceName.Empty)
					{
						if (IsIllegalPrefab(rn))
						{
							Print(string.Format("[JobVirtualGarageManager] Item illegal detecte : %1 (depth=%2)",
								rn, depth), LogLevel.NORMAL);
							return true;
						}
					}
				}
				
				// Recurse dans cet item (peut etre un sac ou un container)
				if (RecursiveScanForIllegal(itemEnt, depth + 1))
					return true;
			}
		}
		
		return false;
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== RECUPERATION (RETRAIT) =====
	// Spawn le vehicule a 5m devant le PNJ, restaure son etat + inventaire, supprime l entree.
	//
	// Retourne :
	//   0  = OK retrait reussi (outVehiclePrefab = prefab du vehicule pour notif)
	//   1  = index invalide
	//   2  = pas le proprietaire (UID ne correspond pas)
	//   3  = erreur de spawn (prefab introuvable ou null)
	//------------------------------------------------------------------------------------------------
	int RetrieveVehicleByIndex(string ownerUID, int index, vector npcPos, vector npcForward, out string outVehiclePrefab, out IEntity outSpawnedVehicle)
	{
		outVehiclePrefab = "";
		outSpawnedVehicle = null;
		
		if (index < 0 || index >= m_Vehicles.Count())
			return 1;
		
		JobGarageVehicle entry = m_Vehicles.Get(index);
		if (!entry)
			return 1;
		if (entry.m_OwnerUID != ownerUID)
			return 2;
		
		outVehiclePrefab = entry.m_PrefabName;
		
		// 1. Calcule la position de spawn (5m devant le PNJ)
		vector spawnPos = npcPos + (npcForward * SPAWN_DISTANCE);
		// Ajuste a la hauteur du terrain
		float terrainY = GetGame().GetWorld().GetSurfaceY(spawnPos[0], spawnPos[2]);
		spawnPos[1] = terrainY + 0.5;  // 0.5m au-dessus du sol pour eviter clipping
		
		// 2. Spawn le vehicule
		Resource res = Resource.Load(entry.m_PrefabName);
		if (!res || !res.IsValid())
			return 3;
		
		EntitySpawnParams params = new EntitySpawnParams();
		params.TransformMode = ETransformMode.WORLD;
		params.Transform[3] = spawnPos;
		// Oriente le vehicule dans le sens oppose au PNJ (capot vers l avant)
		// Pour simplicite on garde l identite ; le boss pourra orienter manuellement
		
		IEntity newVehicle = GetGame().SpawnEntityPrefab(res, GetGame().GetWorld(), params);
		if (!newVehicle)
			return 3;
		
		outSpawnedVehicle = newVehicle;
		
		// 3. Enregistre le proprietaire dans la map runtime via le RplId du nouveau vehicule.
		// IMPORTANT : on utilise m_OriginalOwnerUID (pas m_OwnerUID) :
		//  - Garage perso : original == owner, aucun changement de comportement
		//  - Garage Fourriere : owner = FOURRIERE_SHARED mais original = vrai proprio.
		//    Enregistrer le vrai proprio permet :
		//      (a) au proprio de ranger a nouveau le vehicule dans son garage perso
		//      (b) de preserver le nom affiche si un Fourriere le re-depose dans le partage
		// Si original est vide (vehicule libre jamais traque, ex: depot Fourriere immediat au
		// spawn serveur), la map stocke "" ce qui autorise n importe qui a le ranger (OK).
		RplComponent newRpl = RplComponent.Cast(newVehicle.FindComponent(RplComponent));
		if (newRpl)
		{
			string trueOwner = entry.m_OriginalOwnerUID;
			m_VehicleOwners.Set(newRpl.Id().ToString(), trueOwner);
			Print(string.Format("[JobVirtualGarageManager] Spawn vehicule : rplKey=%1 trueOwner=%2 (entry.owner=%3)",
				newRpl.Id().ToString(), trueOwner, entry.m_OwnerUID), LogLevel.NORMAL);
		}
		
		// 3. Restaure l etat
		if (entry.m_Damage > 0)
			ApplyVehicleDamage(newVehicle, entry.m_Damage);
		if (entry.m_Fuel >= 0)
			ApplyVehicleFuel(newVehicle, entry.m_Fuel);
		// Restaure le damage par hitzone (moteur, carrosserie, roues, etc.)
		if (entry.m_HitzoneDamages && entry.m_HitzoneDamages.Count() > 0)
			ApplyVehicleHitzones(newVehicle, entry.m_HitzoneDamages);
		
		// 4. Restaure l inventaire (asynchrone : on planifie un CallLater car les storages
		//    ne sont pas toujours prets immediatement apres le spawn)
		ApplyVehicleInventory(newVehicle, entry.m_Items);
		
		// 4b. Si le vehicule etait assure, re-attache l UUID au nouveau spawn
		if (entry.m_InstanceUUID != "")
		{
			JobInsuranceManager.GetInstance().ReattachExistingUUID(newVehicle, entry.m_InstanceUUID);
			// Installe le watcher de destruction pour auto-respawn au garage du VRAI proprio
			// (pas du UID partage Fourriere) si le vehicule est detruit en circulation.
			string watcherOwner = entry.m_OriginalOwnerUID;
			if (watcherOwner == "")
				watcherOwner = entry.m_OwnerUID; // fallback vieux saves
			InstallDamageWatcher(newVehicle, entry.m_InstanceUUID, watcherOwner, entry.m_PrefabName);
		}

		// 4c. Re-fixe l UUID d IDENTITE stable sur le composant du nouveau vehicule spawn,
		// et re-enregistre dans m_ActiveVehicles. Si l entree avait un UUID (achetee apres
		// la MAJ UUID stable), on la reutilise. Sinon on en genere un retroactif pour que
		// le vehicule soit trackable des maintenant (migration douce des anciens saves).
		string vehUUID = entry.m_VehicleUUID;
		string retrieveOwner = entry.m_OriginalOwnerUID;
		if (retrieveOwner == "")
			retrieveOwner = entry.m_OwnerUID;
		if (vehUUID == "")
			vehUUID = GenerateVehicleUUID(retrieveOwner);
		RegisterRetrievedVehicle(newVehicle, vehUUID, retrieveOwner, entry.m_PrefabName, entry.m_InstanceUUID);

		// 5. Supprime l entree + sauve disque (differe, shard du proprietaire uniquement)
		string retrievedOwnerUID = entry.m_OwnerUID;
		m_Vehicles.Remove(index);
		MarkOwnerDirty(retrievedOwnerUID);

		Print(string.Format("[JobVirtualGarageManager] Retrait : owner=%1 prefab=%2 uuidAssurance=%3",
			ownerUID, entry.m_PrefabName, entry.m_InstanceUUID), LogLevel.NORMAL);
		return 0;
	}
	
	//------------------------------------------------------------------------------------------------
	//------------------------------------------------------------------------------------------------
	// ===== DAMAGE WATCHER (auto-respawn au garage si vehicule assure detruit) =====
	//------------------------------------------------------------------------------------------------
	
	// Map RplId -> conteneur d etat pour le watcher (nom prefab + owner + uuid)
	// Rechecke toutes les 2 secondes chaque vehicule assure : si detruit, respawn au garage.
	ref map<string, ref JobInsuranceWatcherState> m_InsuranceWatchers = new map<string, ref JobInsuranceWatcherState>();
	const int WATCHER_TICK_MS = 5000; // 2s -> 5s : 2.5x moins de scans FindComponent, destruction toujours detectee <5s
	
	//------------------------------------------------------------------------------------------------
	// Installe un watcher sur un vehicule assure spawne. Verifie periodiquement l etat de vie.
	// Si detruit (SCR_VehicleDamageManagerComponent.GetState() == EDamageState.DESTROYED) :
	//   - Retire l assurance
	//   - Auto-respawn le vehicule dans le garage virtuel du proprietaire (sans assurance)
	//   - Notifie le proprietaire
	//------------------------------------------------------------------------------------------------
	void InstallDamageWatcher(IEntity vehicle, string uuid, string ownerUID, ResourceName prefab)
	{
		if (!vehicle || uuid == "" || ownerUID == "")
			return;
		RplComponent rpl = RplComponent.Cast(vehicle.FindComponent(RplComponent));
		if (!rpl)
			return;
		string rplKey = rpl.Id().ToString();

		JobInsuranceWatcherState state = new JobInsuranceWatcherState();
		state.m_UUID = uuid;
		state.m_OwnerUID = ownerUID;
		state.m_Prefab = prefab;
		state.m_RplKey = rplKey;
		// OPTIM : resout les composants damage UNE SEULE FOIS a l install du watcher
		// (evite N * FindComponent a chaque tick pendant toute la vie du vehicule).
		state.m_CachedEntity = vehicle;
		state.m_CachedScrDmg = SCR_VehicleDamageManagerComponent.Cast(vehicle.FindComponent(SCR_VehicleDamageManagerComponent));
		state.m_CachedBaseDmg = DamageManagerComponent.Cast(vehicle.FindComponent(DamageManagerComponent));
		m_InsuranceWatchers.Set(rplKey, state);

		// Demarre le tick global si pas deja actif
		if (m_InsuranceWatchers.Count() == 1)
		{
			GetGame().GetCallqueue().CallLater(TickInsuranceWatchers, WATCHER_TICK_MS, true);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Tick global appele toutes les 2s. Parcourt les vehicules assures spawnes en jeu.
	// Si l un est detruit, consomme l assurance + auto-respawn au garage + notifie.
	//------------------------------------------------------------------------------------------------
	void TickInsuranceWatchers()
	{
		if (!m_InsuranceWatchers || m_InsuranceWatchers.Count() == 0)
			return;

		// Enforce iteration map : parcours par index via GetElement (l ordre est stable).
		// On collecte les states ET les cles a virer separement.
		int wCount = m_InsuranceWatchers.Count();
		array<ref JobInsuranceWatcherState> statesToCheck = new array<ref JobInsuranceWatcherState>();
		for (int idx = 0; idx < wCount; idx++)
		{
			JobInsuranceWatcherState st = m_InsuranceWatchers.GetElement(idx);
			if (st)
				statesToCheck.Insert(st);
		}
		array<string> toRemove = new array<string>();
		
		foreach (JobInsuranceWatcherState state : statesToCheck)
		{
			if (!state)
				continue;
			string rplKey = state.m_RplKey;

			// OPTIM : utilise les refs cachees si encore valides, sinon fallback vers lookup Rpl.
			// Evite FindComponent repete toutes les 5s pour chaque vehicule assure.
			IEntity vehicle = state.m_CachedEntity;
			if (!vehicle || vehicle.IsDeleted())
			{
				// Cache perdu : fallback au lookup via RplId
				int rplIdInt = rplKey.ToInt();
				if (rplIdInt == 0)
				{
					toRemove.Insert(rplKey);
					continue;
				}
				RplId rid = rplIdInt;
				RplComponent rplComp = RplComponent.Cast(Replication.FindItem(rid));
				if (!rplComp)
				{
					toRemove.Insert(rplKey);
					continue;
				}
				vehicle = rplComp.GetEntity();
				if (!vehicle)
				{
					toRemove.Insert(rplKey);
					continue;
				}
				// Repeuple le cache + refresh refs
				state.m_CachedEntity = vehicle;
				state.m_CachedScrDmg = SCR_VehicleDamageManagerComponent.Cast(vehicle.FindComponent(SCR_VehicleDamageManagerComponent));
				state.m_CachedBaseDmg = DamageManagerComponent.Cast(vehicle.FindComponent(DamageManagerComponent));
			}

			// === DETECTION DESTRUCTION - TRIPLE CHECK ===
			// 1. Via IsDeleted() de l entite
			// 2. Via SCR_VehicleDamageManagerComponent.GetState() (ref cachee)
			// 3. Via base DamageManagerComponent.GetDamageState() (ref cachee)

			bool isDestroyed = false;
			string detectMethod = "";

			// Check 1 : entite deletee ?
			if (vehicle.IsDeleted())
			{
				isDestroyed = true;
				detectMethod = "IsDeleted";
			}

			// Check 2 : SCR_VehicleDamageManagerComponent (ref cachee - 0 lookup)
			if (!isDestroyed && state.m_CachedScrDmg)
			{
				EDamageState dmgState = state.m_CachedScrDmg.GetState();
				if (dmgState == EDamageState.DESTROYED)
				{
					isDestroyed = true;
					detectMethod = "SCR_VehicleDamage.DESTROYED";
				}
			}

			// Check 3 : DamageManagerComponent base (ref cachee - 0 lookup)
			if (!isDestroyed && state.m_CachedBaseDmg)
			{
				EDamageState dmgState = state.m_CachedBaseDmg.GetState();
				if (dmgState == EDamageState.DESTROYED)
				{
					isDestroyed = true;
					detectMethod = "BaseDamage.DESTROYED";
				}
			}
			
			if (isDestroyed)
			{
				Print(string.Format("[JobVirtualGarageManager] Vehicule detruit detecte via %1 : rplKey=%2 uuid=%3",
					detectMethod, rplKey, state.m_UUID), LogLevel.NORMAL);
				OnInsuredVehicleDestroyed(state);
				toRemove.Insert(rplKey);
			}
		}
		
		// Cleanup des watchers termines
		foreach (string k : toRemove)
		{
			if (m_InsuranceWatchers.Contains(k))
				m_InsuranceWatchers.Remove(k);
		}
		
		// Arrete le tick si plus de watcher
		if (m_InsuranceWatchers.Count() == 0)
		{
			GetGame().GetCallqueue().Remove(TickInsuranceWatchers);
		}
	}

	//------------------------------------------------------------------------------------------------
	// Callback : vehicule assure detruit -> consomme assurance + auto-respawn au garage
	//------------------------------------------------------------------------------------------------
	void OnInsuredVehicleDestroyed(JobInsuranceWatcherState state)
	{
		if (!state)
			return;
		
		// 1. Consomme l assurance (retire de la map + save)
		InsuredVehicle ins = JobInsuranceManager.GetInstance().ConsumeInsurance(state.m_UUID);
		if (!ins)
		{
			Print(string.Format("[JobVirtualGarageManager] OnInsuredVehicleDestroyed : assurance %1 introuvable dans map",
				state.m_UUID), LogLevel.WARNING);
			// On continue quand meme le respawn pour ne pas frustrer le joueur
		}
		
		// 2. Auto-respawn dans le garage virtuel (sans assurance : elle est consommee)
		JobGarageVehicle newEntry = new JobGarageVehicle();
		newEntry.m_OwnerUID = state.m_OwnerUID;
		newEntry.m_PrefabName = state.m_Prefab;
		newEntry.m_InstanceUUID = "";  // Nouvelle instance vierge, plus d assurance
		newEntry.m_Damage = 0;
		newEntry.m_Fuel = -1;
		m_Vehicles.Insert(newEntry);
		MarkOwnerDirty(newEntry.m_OwnerUID);

		Print(string.Format("[JobVirtualGarageManager] Vehicule ajoute au garage virtuel : total vehicules=%1",
			m_Vehicles.Count()), LogLevel.NORMAL);
		
		// 3. Notifie le proprietaire s il est en ligne
		NotifyOwnerInsuranceUsed(state.m_OwnerUID, state.m_Prefab);
		
		Print(string.Format("[JobVirtualGarageManager] Vehicule assure detruit : uuid=%1 -> auto-respawn au garage de %2 OK",
			state.m_UUID, state.m_OwnerUID), LogLevel.NORMAL);
	}
	
	//------------------------------------------------------------------------------------------------
	// Envoie un message chat au proprietaire s il est en ligne pour l informer de la destruction
	//------------------------------------------------------------------------------------------------
	void NotifyOwnerInsuranceUsed(string ownerUID, ResourceName prefab)
	{
		if (ownerUID == "")
			return;
		
		// Cherche le playerId correspondant a ownerUID en itereant sur les joueurs en ligne.
		// Enforce n a pas de lookup direct UID -> playerId (le mapping est dans JobManager).
		int playerId = 0;
		array<int> playerIds = new array<int>();
		GetGame().GetPlayerManager().GetPlayers(playerIds);
		foreach (int pid : playerIds)
		{
			string uid = JobManager.GetInstance().GetPersistentUID(pid);
			if (uid == ownerUID)
			{
				playerId = pid;
				break;
			}
		}
		if (playerId <= 0)
			return;  // proprietaire pas en ligne : rien a notifier (il verra a sa reconnexion)
		
		string vehicleName = JobInsuranceManager.GetInstance().ExtractDisplayName(prefab);
		JobManager.GetInstance().NotifyPlayerChat(playerId,
			string.Format("[ASSURANCE] Votre vehicule %1 a ete detruit. L assurance a ete utilisee et un nouveau vehicule a ete depose dans votre garage virtuel.",
				vehicleName));
	}
	//------------------------------------------------------------------------------------------------
	// ===== TRANSFERT DE PROPRIETE =====
	// L actuel proprietaire transfere son vehicule stocke (par index dans m_Vehicles)
	// a un autre joueur identifie par son UID.
	//
	// Retourne :
	//   0  = OK transfert reussi (outOldOwnerNotice + outNewOwnerNotice = prefab pour notif)
	//   1  = index invalide
	//   2  = currentOwnerUID n est pas le proprietaire actuel de l entree
	//   3  = newOwnerUID est vide ou identique au current (rien a faire)
	//------------------------------------------------------------------------------------------------
	int TransferOwnership(string currentOwnerUID, int garageIndex, string newOwnerUID, out string outPrefab)
	{
		outPrefab = "";

		if (garageIndex < 0 || garageIndex >= m_Vehicles.Count())
			return 1;
		JobGarageVehicle entry = m_Vehicles.Get(garageIndex);
		if (!entry)
			return 1;
		if (entry.m_OwnerUID != currentOwnerUID)
			return 2;
		if (newOwnerUID == "" || newOwnerUID == currentOwnerUID)
			return 3;

		outPrefab = entry.m_PrefabName;
		// IMPORTANT : un vrai transfert d ownership change les 2 champs. Si on ne mettait
		// a jour que m_OwnerUID, le fix fourriere (qui utilise m_OriginalOwnerUID comme
		// "vrai proprio" a la sortie) marquerait le vehicule comme appartenant toujours
		// a l ancien proprio -> le nouveau proprio ne pourrait pas le rentrer dans sont
		// garage virtuel. Un transfert est definitif, pas une custody temporaire.
		entry.m_OwnerUID = newOwnerUID;
		entry.m_OriginalOwnerUID = newOwnerUID;
		// Deux shards touches : ancien UID perd le vehicule, nouveau UID le recoit
		MarkOwnerDirty(currentOwnerUID);
		MarkOwnerDirty(newOwnerUID);

		Print(string.Format("[JobVirtualGarageManager] Transfert : %1 -> %2 (prefab=%3)",
			currentOwnerUID, newOwnerUID, entry.m_PrefabName), LogLevel.NORMAL);
		return 0;
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== HELPERS LECTURE VEHICULE =====
	//------------------------------------------------------------------------------------------------
	
	// Cherche le vehicule (entite avec VehicleControllerComponent ou simple Vehicle)
	// le plus proche d une position, dans un rayon donne. Retourne null si rien.
	IEntity FindClosestVehicle(vector pos, float maxRange)
	{
		// On utilise QueryEntitiesBySphere pour scanner les entites dans le rayon
		// puis on filtre celles qui ont un composant de vehicule (Wheeled, Helicopter, Boat...)
		array<IEntity> entities = new array<IEntity>();
		s_QueryClosestVehiclePos = pos;
		s_QueryClosestVehicleMaxRange = maxRange;
		s_QueryClosestVehicleBest = null;
		s_QueryClosestVehicleBestDistSq = maxRange * maxRange;
		
		GetGame().GetWorld().QueryEntitiesBySphere(pos, maxRange,
			QueryClosestVehicleCallback, null, EQueryEntitiesFlags.ALL);
		
		IEntity result = s_QueryClosestVehicleBest;
		s_QueryClosestVehicleBest = null;
		return result;
	}
	
	// Variables statiques temporaires pour la callback (Enforce Script n a pas de closures)
	static vector s_QueryClosestVehiclePos;
	static float s_QueryClosestVehicleMaxRange;
	static IEntity s_QueryClosestVehicleBest;
	static float s_QueryClosestVehicleBestDistSq;
	
	static bool QueryClosestVehicleCallback(IEntity e)
	{
		if (!e)
			return true;
		
		// Filtre : doit etre une Vehicle (classe parent de tous les vehicules dans Enfusion)
		Vehicle veh = Vehicle.Cast(e);
		if (!veh)
			return true;
		
		float dSq = vector.DistanceSq(e.GetOrigin(), s_QueryClosestVehiclePos);
		if (dSq < s_QueryClosestVehicleBestDistSq)
		{
			s_QueryClosestVehicleBestDistSq = dSq;
			s_QueryClosestVehicleBest = e;
		}
		return true;
	}
	
	//------------------------------------------------------------------------------------------------
	// Lit la "vie" globale du vehicule. Retourne 0.0 (intact) a 1.0 (detruit).
	// Note : l API publique de SCR_DamageManagerComponent ne expose pas facilement un
	// damage state global ; on conserve une valeur indicative simple (0 = neuf, qu on
	// peut affiner plus tard via les hitzones individuelles si besoin).
	//------------------------------------------------------------------------------------------------
	float ReadVehicleDamage(IEntity vehicle)
	{
		// DEPRECATED : utilise pour compat, mais la vraie sauvegarde se fait via
		// ReadVehicleHitzones() qui sauvegarde le damage par composant.
		return 0;
	}
	
	void ApplyVehicleDamage(IEntity vehicle, float damage)
	{
		// DEPRECATED : remplace par ApplyVehicleHitzones()
	}
	
	//------------------------------------------------------------------------------------------------
	// Lit le damage de chaque hitzone du vehicule (moteur, carrosserie, roues, etc.).
	// Utilise SCR_DamageManagerComponent.GetAllHitZones() qui retourne toutes les hitzones.
	// Pour chaque hitzone : stocke son nom + ratio de damage (0 = sain, 1 = detruit).
	//
	// IMPORTANT : on utilise GetDamage() qui retourne directement le ratio 0..1 (0 = sain).
	// (GetHealthScaled() pouvait poser probleme selon les versions).
	//------------------------------------------------------------------------------------------------
	void ReadVehicleHitzones(IEntity vehicle, out array<ref JobGarageHitzoneDamage> outHitzones)
	{
		if (!vehicle)
			return;
		SCR_DamageManagerComponent dm = SCR_DamageManagerComponent.Cast(
			vehicle.FindComponent(SCR_DamageManagerComponent));
		if (!dm)
		{
			Print("[JobVirtualGarageManager] ReadHitzones : pas de DamageManager sur le vehicule",
				LogLevel.WARNING);
			return;
		}

		// IMPORTANT : GetAllHitZones() ne retourne QUE les hitzones directes du chassis.
		// Les roues sont souvent des entites ENFANTS attachees, leurs hitzones ne sont
		// donc pas captees. GetAllHitZonesInHierarchy() traverse toute la hierarchie
		// et capte les SCR_WheelHitZone des roues attachees.
		array<HitZone> hitzones = new array<HitZone>();
		dm.GetAllHitZonesInHierarchy(hitzones);

		Print(string.Format("[JobVirtualGarageManager] ReadHitzones : %1 hitzones trouvees (hierarchie)",
			hitzones.Count()), LogLevel.NORMAL);

		// IMPORTANT : les 4 roues partagent souvent le MEME m_Name (SCR_WheelHitZone).
		// Si on utilise juste le nom comme cle, le map ecrase et au restore on applique
		// la valeur a TOUTES les roues (symptome : 1 roue abimee stockee -> 3 autres abimees).
		// On prefixe la cle avec l index d iteration pour la rendre unique par hitzone.
		int hzCount = hitzones.Count();
		for (int i = 0; i < hzCount; i++)
		{
			HitZone hz = hitzones.Get(i);
			if (!hz)
				continue;
			string hzName = hz.GetName();
			if (hzName == "")
				continue;
			float health = hz.GetHealth();
			float maxHealth = hz.GetMaxHealth();
			if (maxHealth <= 0)
				continue;
			float damageRatio = 1.0 - (health / maxHealth);

			if (damageRatio <= 0.01)
				continue;
			JobGarageHitzoneDamage hd = new JobGarageHitzoneDamage();
			// Cle = index + "#" + nom (unique). L index assume que GetAllHitZonesInHierarchy
			// retourne les hitzones dans un ordre deterministe pour un meme prefab, ce qui
			// est le cas des vehicules Enfusion.
			hd.m_HitzoneName = i.ToString() + "#" + hzName;
			hd.m_DamageValue = damageRatio;
			outHitzones.Insert(hd);
		}
		
		Print(string.Format("[JobVirtualGarageManager] ReadHitzones : %1 zones endommagees sauvegardees",
			outHitzones.Count()), LogLevel.NORMAL);
	}
	
	//------------------------------------------------------------------------------------------------
	// Reapplique le damage par hitzone sur le vehicule fraichement spawne.
	// Comme le damage manager peut ne pas etre pret immediatement, on utilise un CallLater.
	//------------------------------------------------------------------------------------------------
	static IEntity s_PendingDamageVehicle;
	static ref array<ref JobGarageHitzoneDamage> s_PendingDamageHitzones;
	
	void ApplyVehicleHitzones(IEntity vehicle, array<ref JobGarageHitzoneDamage> hitzones)
	{
		if (!vehicle || !hitzones || hitzones.Count() == 0)
			return;
		s_PendingDamageVehicle = vehicle;
		s_PendingDamageHitzones = hitzones;
		GetGame().GetCallqueue().CallLater(DoApplyVehicleHitzones, 600, false);
	}
	
	static void DoApplyVehicleHitzones()
	{
		IEntity vehicle = s_PendingDamageVehicle;
		array<ref JobGarageHitzoneDamage> hitzones = s_PendingDamageHitzones;
		s_PendingDamageVehicle = null;
		s_PendingDamageHitzones = null;
		
		if (!vehicle || !hitzones)
			return;
		
		SCR_DamageManagerComponent dm = SCR_DamageManagerComponent.Cast(
			vehicle.FindComponent(SCR_DamageManagerComponent));
		if (!dm)
		{
			Print("[JobVirtualGarageManager] ApplyVehicleHitzones : pas de DamageManager sur le vehicule",
				LogLevel.WARNING);
			return;
		}
		
		// Construit une map cle(index#nom) -> damage souhaite
		// (voir ReadVehicleHitzones : la cle inclut l index pour disambigier les 4 roues
		// qui partagent le meme nom)
		map<string, float> targetDamage = new map<string, float>();
		foreach (JobGarageHitzoneDamage hd : hitzones)
		{
			if (!hd || hd.m_HitzoneName == "")
				continue;
			targetDamage.Set(hd.m_HitzoneName, hd.m_DamageValue);
		}

		// Itere les hitzones reelles (meme ordre que ReadVehicleHitzones) et applique le damage.
		// On construit la meme cle "index#nom" pour matcher.
		array<HitZone> realHitzones = new array<HitZone>();
		dm.GetAllHitZonesInHierarchy(realHitzones);
		int applied = 0;
		int rhCount = realHitzones.Count();
		for (int i = 0; i < rhCount; i++)
		{
			HitZone hz = realHitzones.Get(i);
			if (!hz)
				continue;
			string key = i.ToString() + "#" + hz.GetName();
			float target;
			if (!targetDamage.Find(key, target))
			{
				// Compat : essaie aussi l ancienne cle (juste le nom) pour les vehicules
				// stockes AVANT le fix. Peut appliquer a plusieurs hitzones de meme nom
				// (bug legacy) mais vaut mieux que de perdre completement l etat sauvegarde.
				if (!targetDamage.Find(hz.GetName(), target))
					continue;
			}
			float maxHealth = hz.GetMaxHealth();
			if (maxHealth <= 0)
				continue;

			// Deal les degats via le pipeline pour que l etat passe a DAMAGED/DESTROYED
			// et que UpdateWheelState soit appele sur les SCR_WheelHitZone.
			float currentHealth = hz.GetHealth();
			float targetHealth = (1.0 - target) * maxHealth;
			if (currentHealth > targetHealth)
			{
				float dmg = currentHealth - targetHealth;
				hz.HandleDamage(dmg, EDamageType.KINETIC, null);
			}
			else
			{
				hz.SetHealth(targetHealth);
			}

			SCR_WheelHitZone wheelHz = SCR_WheelHitZone.Cast(hz);
			if (wheelHz)
				wheelHz.UpdateWheelState();

			applied++;
		}

		// Apres toutes les hitzones, recalcule l etat global du vehicule pour que
		// la simulation (steering, drive, physique des roues) prenne en compte le damage.
		SCR_WheeledDamageManagerComponent wdm = SCR_WheeledDamageManagerComponent.Cast(dm);
		if (wdm)
		{
			wdm.UpdateVehicleState();
			wdm.UpdateMovementDamage();
		}

		Print(string.Format("[JobVirtualGarageManager] ApplyVehicleHitzones : %1 zones restaurees",
			applied), LogLevel.NORMAL);
	}
	
	//------------------------------------------------------------------------------------------------
	// Lit le carburant total du vehicule (litres) via SCR_FuelManagerComponent.
	//------------------------------------------------------------------------------------------------
	float ReadVehicleFuel(IEntity vehicle)
	{
		if (!vehicle)
			return -1;
		SCR_FuelManagerComponent fm = SCR_FuelManagerComponent.Cast(
			vehicle.FindComponent(SCR_FuelManagerComponent));
		if (!fm)
			return -1;
		return fm.GetTotalFuel();
	}
	
	// Buffer static pour l application differee du carburant (le FuelManager est pas pret
	// immediatement apres le spawn, meme pattern que ApplyVehicleHitzones)
	static IEntity s_PendingFuelVehicle;
	static float s_PendingFuel;

	void ApplyVehicleFuel(IEntity vehicle, float fuel)
	{
		if (!vehicle || fuel < 0) return;
		s_PendingFuelVehicle = vehicle;
		s_PendingFuel = fuel;
		GetGame().GetCallqueue().CallLater(DoApplyVehicleFuel, 800, false);
	}

	static void DoApplyVehicleFuel()
	{
		IEntity vehicle = s_PendingFuelVehicle;
		float fuel = s_PendingFuel;
		s_PendingFuelVehicle = null;
		s_PendingFuel = 0;
		if (!vehicle) return;

		SCR_FuelManagerComponent fm = SCR_FuelManagerComponent.Cast(
			vehicle.FindComponent(SCR_FuelManagerComponent));
		if (!fm)
		{
			Print("[JobVirtualGarageManager] ApplyVehicleFuel : pas de FuelManager",
				LogLevel.WARNING);
			return;
		}

		// Repartit le carburant proportionnellement sur tous les reservoirs (nodes).
		// Un vehicule peut avoir plusieurs tanks (ex: avion), on garde les ratios.
		array<BaseFuelNode> nodes = new array<BaseFuelNode>();
		fm.GetFuelNodesList(nodes);
		if (nodes.Count() == 0) return;

		float totalMaxSum = 0;
		foreach (BaseFuelNode n : nodes)
		{
			if (n) totalMaxSum = totalMaxSum + n.GetMaxFuel();
		}
		if (totalMaxSum <= 0) return;

		float ratio = fuel / totalMaxSum;
		if (ratio > 1.0) ratio = 1.0;
		if (ratio < 0) ratio = 0;

		foreach (BaseFuelNode n : nodes)
		{
			if (!n) continue;
			n.SetFuel(n.GetMaxFuel() * ratio);
		}

		Print(string.Format("[JobVirtualGarageManager] ApplyVehicleFuel : %1 L restaure (ratio %2)",
			fuel, ratio), LogLevel.NORMAL);
	}
	
	//------------------------------------------------------------------------------------------------
	// Lit le contenu de tous les storages du vehicule (coffre + sieges + autres).
	//------------------------------------------------------------------------------------------------
	//------------------------------------------------------------------------------------------------
	// Lit le contenu du COFFRE PRINCIPAL du vehicule.
	// Les vehicules utilisent SCR_VehicleInventoryStorageManagerComponent (different des perso
	// qui utilisent SCR_InventoryStorageManagerComponent).
	//
	// IMPORTANT : on lit uniquement les items au PREMIER NIVEAU du coffre.
	// Si une arme contient un chargeur, on ne lit QUE l arme - le chargeur est attache a l arme
	// et sera respawn avec elle. Sinon, on aurait des chargeurs dupliques au retrieve.
	//------------------------------------------------------------------------------------------------
	//------------------------------------------------------------------------------------------------
	// Lit le contenu de tous les storages du vehicule (coffre + sieges + autres) de facon RECURSIVE.
	//
	// Comportement :
	//   - Tous les items directs des storages du vehicule sont sauvegardes
	//   - Si un item est un CONTAINER (sac, gilet, boite), ses items sont AUSSI sauvegardes recursivement
	//   - Si un item est une ARME (BaseWeaponComponent detecte), on NE RECURSE PAS dedans
	//     (evite de sauvegarder chargeurs, viseurs, cannons attaches comme des items separes)
	//   - Depth max 5 pour eviter toute boucle infinie theorique
	//
	// Restauration : au retrait tous les items iront dans le coffre principal du nouveau vehicule
	// (les sacs eux-memes seront restaures, mais leur contenu sera "a plat" dans le coffre).
	//------------------------------------------------------------------------------------------------
	void ReadVehicleInventory(IEntity vehicle, out array<ref JobGarageItem> outItems)
	{
		if (!vehicle)
			return;
		
		// Recupere TOUS les storages du vehicule (coffre principal + sieges + secondaires)
		array<Managed> storages = new array<Managed>();
		vehicle.FindComponents(BaseInventoryStorageComponent, storages);
		if (storages.Count() == 0)
		{
			Print("[JobVirtualGarageManager] ReadVehicleInventory : aucun storage trouve",
				LogLevel.WARNING);
			return;
		}
		
		Print(string.Format("[JobVirtualGarageManager] ReadVehicleInventory : %1 storage(s) trouve(s) sur le vehicule",
			storages.Count()), LogLevel.NORMAL);
		
		// Scanne chaque storage du vehicule et descend recursivement dans les containers
		foreach (Managed sMgd : storages)
		{
			BaseInventoryStorageComponent storage = BaseInventoryStorageComponent.Cast(sMgd);
			if (!storage)
				continue;
			
			int slots = storage.GetSlotsCount();
			for (int s = 0; s < slots; s++)
			{
				InventoryStorageSlot slot = storage.GetSlot(s);
				if (!slot)
					continue;
				IEntity itemEnt = slot.GetAttachedEntity();
				if (!itemEnt)
					continue;
				RecursiveCollectItems(itemEnt, outItems, 0);
			}
		}
		
		Print(string.Format("[JobVirtualGarageManager] ReadVehicleInventory : %1 items sauvegardes (recursif)",
			outItems.Count()), LogLevel.NORMAL);
	}
	
	//------------------------------------------------------------------------------------------------
	// Helper recursif : sauvegarde l item, puis descend dans ses storages internes
	// (sauf pour les armes qui ne sont pas recursees).
	//------------------------------------------------------------------------------------------------
	void RecursiveCollectItems(IEntity itemEnt, out array<ref JobGarageItem> outItems, int depth)
	{
		if (!itemEnt || depth > 5)
			return;
		
		// 1. Sauvegarde l item lui-meme (par son prefab)
		EntityPrefabData pd = itemEnt.GetPrefabData();
		if (!pd)
			return;
		ResourceName rn = pd.GetPrefabName();
		if (rn == "" || rn == ResourceName.Empty)
			return;
		
		JobGarageItem gi = new JobGarageItem();
		gi.m_PrefabName = rn;
		gi.m_Quantity = 1;
		outItems.Insert(gi);
		
		// 2. Si c est une arme -> ne descend PAS dans ses attachements
		//    (evite de sauvegarder chargeurs / viseurs / cannons comme des items du coffre)
		BaseWeaponComponent weaponComp = BaseWeaponComponent.Cast(itemEnt.FindComponent(BaseWeaponComponent));
		if (weaponComp)
			return;
		
		// 3. Sinon, si c est un container (sac, gilet, boite) -> recurse dans son contenu
		array<Managed> innerStorages = new array<Managed>();
		itemEnt.FindComponents(BaseInventoryStorageComponent, innerStorages);
		if (innerStorages.Count() == 0)
			return;
		
		foreach (Managed sMgd : innerStorages)
		{
			BaseInventoryStorageComponent innerStorage = BaseInventoryStorageComponent.Cast(sMgd);
			if (!innerStorage)
				continue;
			int innerSlots = innerStorage.GetSlotsCount();
			for (int j = 0; j < innerSlots; j++)
			{
				InventoryStorageSlot innerSlot = innerStorage.GetSlot(j);
				if (!innerSlot)
					continue;
				IEntity childItem = innerSlot.GetAttachedEntity();
				if (!childItem)
					continue;
				RecursiveCollectItems(childItem, outItems, depth + 1);
			}
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Restaure l inventaire dans le COFFRE du vehicule fraichement spawne.
	// Asynchrone avec CallLater car les storages ne sont pas toujours prets immediatement.
	//------------------------------------------------------------------------------------------------
	void ApplyVehicleInventory(IEntity vehicle, array<ref JobGarageItem> items)
	{
		if (!vehicle || !items || items.Count() == 0)
			return;
		
		s_PendingApplyVehicle = vehicle;
		s_PendingApplyItems = items;
		GetGame().GetCallqueue().CallLater(DoApplyVehicleInventory, 500, false);
	}
	
	// Variables temporaires pour le CallLater (Enforce ne supporte pas les closures)
	static IEntity s_PendingApplyVehicle;
	static ref array<ref JobGarageItem> s_PendingApplyItems;
	
	static void DoApplyVehicleInventory()
	{
		IEntity vehicle = s_PendingApplyVehicle;
		array<ref JobGarageItem> items = s_PendingApplyItems;
		s_PendingApplyVehicle = null;
		s_PendingApplyItems = null;
		
		if (!vehicle || !items)
			return;
		
		// Utilise SCR_VehicleInventoryStorageManagerComponent en priorite (correct pour les vehicules)
		SCR_VehicleInventoryStorageManagerComponent vehInv = SCR_VehicleInventoryStorageManagerComponent.Cast(
			vehicle.FindComponent(SCR_VehicleInventoryStorageManagerComponent));
		
		int restored = 0;
		
		if (vehInv)
		{
			foreach (JobGarageItem gi : items)
			{
				if (!gi || gi.m_PrefabName == "")
					continue;
				ResourceName rn = gi.m_PrefabName;
				bool ok = vehInv.TrySpawnPrefabToStorage(rn);
				if (ok)
					restored++;
			}
		}
		else
		{
			// Fallback : utilise BaseInventoryStorageComponent du PREMIER storage (coffre)
			array<Managed> storages = new array<Managed>();
			vehicle.FindComponents(BaseInventoryStorageComponent, storages);
			if (storages.Count() == 0)
			{
				Print("[JobVirtualGarageManager] ApplyInventory : aucun storage trouve sur le vehicule",
					LogLevel.WARNING);
				return;
			}
			BaseInventoryStorageComponent storage = BaseInventoryStorageComponent.Cast(storages.Get(0));
			if (!storage)
				return;
			// Pour le fallback, on aurait besoin d un acces direct au storage. Si pas dispo,
			// on log juste un warning : l API fallback est limitee.
			Print("[JobVirtualGarageManager] ApplyInventory : fallback BaseStorage utilise (limite)",
				LogLevel.WARNING);
		}
		
		Print(string.Format("[JobVirtualGarageManager] ApplyInventory : %1 items restaures dans le coffre",
			restored), LogLevel.NORMAL);
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== PERSISTANCE JSON SHARDEE PAR UID =====
	// Chaque UID a son propre fichier dans SHARD_DIR/<UID_sanitized>.json. Un index liste les UIDs.
	// Avantage : un store/retrieve ne reecrit QUE le fichier du joueur concerne (~20-50 KB max)
	// au lieu du monolithique de 4 MB. Elimine les STALL reseau causees par les I/O bloquantes.
	//------------------------------------------------------------------------------------------------

	//------------------------------------------------------------------------------------------------
	// Nettoie un UID pour en faire un nom de fichier safe (remplace tout non-[A-Za-z0-9_-])
	//------------------------------------------------------------------------------------------------
	string SanitizeUIDForFilename(string uid)
	{
		string result = "";
		int len = uid.Length();
		for (int i = 0; i < len; i++)
		{
			string c = uid.Get(i);
			int ascii = c.ToAscii();
			bool safe = (ascii >= 48 && ascii <= 57)   // 0-9
			         || (ascii >= 65 && ascii <= 90)   // A-Z
			         || (ascii >= 97 && ascii <= 122)  // a-z
			         || ascii == 45                    // -
			         || ascii == 95;                   // _
			if (safe)
				result += c;
			else
				result += "_";
		}
		return result;
	}

	//------------------------------------------------------------------------------------------------
	// Construit le chemin du fichier shard pour un UID donne.
	//------------------------------------------------------------------------------------------------
	string BuildShardPath(string ownerUID)
	{
		return SHARD_DIR + SanitizeUIDForFilename(ownerUID) + ".json";
	}

	//------------------------------------------------------------------------------------------------
	// Ecrit le shard d UN SEUL UID (ses vehicules uniquement). ~20-50 KB max par write.
	// Si le UID n a plus aucun vehicule, ecrit un fichier avec 0 entree (compatible lecture).
	//------------------------------------------------------------------------------------------------
	void SaveOwnerToDisk(string ownerUID)
	{
		if (!m_Vehicles || ownerUID == "")
			return;

		SCR_JsonSaveContext ctx = new SCR_JsonSaveContext();
		// Collecte les vehicules de ce UID
		int ownerCount = 0;
		array<int> ownerIndexes = new array<int>();
		int totalCount = m_Vehicles.Count();
		for (int i = 0; i < totalCount; i++)
		{
			JobGarageVehicle v = m_Vehicles.Get(i);
			if (!v || v.m_OwnerUID != ownerUID)
				continue;
			ownerIndexes.Insert(i);
			ownerCount++;
		}
		ctx.WriteValue("owner_uid", ownerUID);
		ctx.WriteValue("entry_count", ownerCount);
		for (int j = 0; j < ownerIndexes.Count(); j++)
		{
			int idx = ownerIndexes.Get(j);
			JobGarageVehicle v = m_Vehicles.Get(idx);
			if (!v)
				continue;
			string ep = "entry_" + j.ToString() + "_";
			ctx.WriteValue(ep + "uid", v.m_OwnerUID);
			ctx.WriteValue(ep + "origUid", v.m_OriginalOwnerUID);
			ctx.WriteValue(ep + "prefab", v.m_PrefabName);
			ctx.WriteValue(ep + "insUUID", v.m_InstanceUUID);
			ctx.WriteValue(ep + "damage", v.m_Damage);
			ctx.WriteValue(ep + "fuel", v.m_Fuel);
			ctx.WriteValue(ep + "item_count", v.m_Items.Count());
			for (int k = 0; k < v.m_Items.Count(); k++)
			{
				JobGarageItem gi = v.m_Items.Get(k);
				if (!gi)
					continue;
				ctx.WriteValue(ep + "item_" + k.ToString() + "_prefab", gi.m_PrefabName);
				ctx.WriteValue(ep + "item_" + k.ToString() + "_quantity", gi.m_Quantity);
			}
			int hzCount = 0;
			if (v.m_HitzoneDamages)
				hzCount = v.m_HitzoneDamages.Count();
			ctx.WriteValue(ep + "hz_count", hzCount);
			for (int h = 0; h < hzCount; h++)
			{
				JobGarageHitzoneDamage hd = v.m_HitzoneDamages.Get(h);
				if (!hd)
					continue;
				ctx.WriteValue(ep + "hz_" + h.ToString() + "_name", hd.m_HitzoneName);
				ctx.WriteValue(ep + "hz_" + h.ToString() + "_dmg", hd.m_DamageValue);
			}
		}
		ctx.SaveToFile(BuildShardPath(ownerUID));
	}

	//------------------------------------------------------------------------------------------------
	// Ecrit l index des UIDs connus. Petit fichier (~1 KB meme avec 100 joueurs).
	//------------------------------------------------------------------------------------------------
	void SaveShardIndex()
	{
		if (!m_Vehicles)
			return;
		// Collecte les UIDs uniques
		ref set<string> uniqueUIDs = new set<string>();
		int totalCount = m_Vehicles.Count();
		for (int i = 0; i < totalCount; i++)
		{
			JobGarageVehicle v = m_Vehicles.Get(i);
			if (!v || v.m_OwnerUID == "")
				continue;
			uniqueUIDs.Insert(v.m_OwnerUID);
		}
		SCR_JsonSaveContext ctx = new SCR_JsonSaveContext();
		ctx.WriteValue("uid_count", uniqueUIDs.Count());
		for (int j = 0; j < uniqueUIDs.Count(); j++)
		{
			ctx.WriteValue("uid_" + j.ToString(), uniqueUIDs.Get(j));
		}
		ctx.SaveToFile(SHARD_INDEX_PATH);
	}

	//------------------------------------------------------------------------------------------------
	// Charge tous les shards depuis le disque via l index. Retourne true si l index existait.
	//------------------------------------------------------------------------------------------------
	bool LoadShardsFromDisk()
	{
		SCR_JsonLoadContext idxCtx = new SCR_JsonLoadContext();
		if (!idxCtx.LoadFromFile(SHARD_INDEX_PATH))
			return false; // pas d index : premier run ou migration necessaire

		int uidCount = 0;
		idxCtx.ReadValue("uid_count", uidCount);
		int totalLoaded = 0;
		for (int i = 0; i < uidCount; i++)
		{
			string uid = "";
			idxCtx.ReadValue("uid_" + i.ToString(), uid);
			if (uid == "")
				continue;
			totalLoaded += LoadOwnerShard(uid);
		}
		Print(string.Format("[JobVirtualGarageManager] %1 vehicules charges depuis %2 shards (format shardes)",
			totalLoaded, uidCount), LogLevel.NORMAL);
		return true;
	}

	//------------------------------------------------------------------------------------------------
	// Charge un shard pour un UID donne, insert dans m_Vehicles. Retourne le nb de vehicules charges.
	//------------------------------------------------------------------------------------------------
	int LoadOwnerShard(string ownerUID)
	{
		SCR_JsonLoadContext ctx = new SCR_JsonLoadContext();
		if (!ctx.LoadFromFile(BuildShardPath(ownerUID)))
			return 0;
		int count = 0;
		ctx.ReadValue("entry_count", count);
		int loaded = 0;
		for (int i = 0; i < count; i++)
		{
			string ep = "entry_" + i.ToString() + "_";
			JobGarageVehicle v = new JobGarageVehicle();
			ctx.ReadValue(ep + "uid", v.m_OwnerUID);
			ctx.ReadValue(ep + "origUid", v.m_OriginalOwnerUID);
			if (v.m_OriginalOwnerUID == "")
				v.m_OriginalOwnerUID = v.m_OwnerUID;
			ctx.ReadValue(ep + "prefab", v.m_PrefabName);
			ctx.ReadValue(ep + "insUUID", v.m_InstanceUUID);
			ctx.ReadValue(ep + "damage", v.m_Damage);
			ctx.ReadValue(ep + "fuel", v.m_Fuel);
			int itemCount = 0;
			ctx.ReadValue(ep + "item_count", itemCount);
			for (int k = 0; k < itemCount; k++)
			{
				JobGarageItem gi = new JobGarageItem();
				ctx.ReadValue(ep + "item_" + k.ToString() + "_prefab", gi.m_PrefabName);
				ctx.ReadValue(ep + "item_" + k.ToString() + "_quantity", gi.m_Quantity);
				if (gi.m_PrefabName != "")
					v.m_Items.Insert(gi);
			}
			int hzCount = 0;
			ctx.ReadValue(ep + "hz_count", hzCount);
			for (int h = 0; h < hzCount; h++)
			{
				JobGarageHitzoneDamage hd = new JobGarageHitzoneDamage();
				ctx.ReadValue(ep + "hz_" + h.ToString() + "_name", hd.m_HitzoneName);
				ctx.ReadValue(ep + "hz_" + h.ToString() + "_dmg", hd.m_DamageValue);
				if (hd.m_HitzoneName != "")
					v.m_HitzoneDamages.Insert(hd);
			}
			if (v.m_OwnerUID != "" && v.m_PrefabName != "")
			{
				m_Vehicles.Insert(v);
				loaded++;
			}
		}
		return loaded;
	}

	//------------------------------------------------------------------------------------------------
	// MIGRATION : lit l ancien virtual_garage.json monolithique, splitte par UID, ecrit shards.
	// Backup de l ancien en .bak pour securite. Retourne true si migration faite.
	//------------------------------------------------------------------------------------------------
	bool MigrateFromOldFormat()
	{
		if (!FileIO.FileExists(SAVE_PATH))
			return false;

		Print("[JobVirtualGarageManager] MIGRATION : ancien format detecte, conversion vers shards...",
			LogLevel.NORMAL);
		int t0 = System.GetTickCount();

		// Charge l ancien monolithique (meme logique que l ex-LoadFromDisk)
		SCR_JsonLoadContext ctx = new SCR_JsonLoadContext();
		if (!ctx.LoadFromFile(SAVE_PATH))
		{
			Print("[JobVirtualGarageManager] MIGRATION : impossible de lire l ancien fichier, abandon.",
				LogLevel.ERROR);
			return false;
		}
		int count = 0;
		ctx.ReadValue("entry_count", count);
		int loaded = 0;
		for (int i = 0; i < count; i++)
		{
			string ep = "entry_" + i.ToString() + "_";
			JobGarageVehicle v = new JobGarageVehicle();
			ctx.ReadValue(ep + "uid", v.m_OwnerUID);
			ctx.ReadValue(ep + "origUid", v.m_OriginalOwnerUID);
			if (v.m_OriginalOwnerUID == "")
				v.m_OriginalOwnerUID = v.m_OwnerUID;
			ctx.ReadValue(ep + "prefab", v.m_PrefabName);
			ctx.ReadValue(ep + "insUUID", v.m_InstanceUUID);
			ctx.ReadValue(ep + "damage", v.m_Damage);
			ctx.ReadValue(ep + "fuel", v.m_Fuel);
			int itemCount = 0;
			ctx.ReadValue(ep + "item_count", itemCount);
			for (int k = 0; k < itemCount; k++)
			{
				JobGarageItem gi = new JobGarageItem();
				ctx.ReadValue(ep + "item_" + k.ToString() + "_prefab", gi.m_PrefabName);
				ctx.ReadValue(ep + "item_" + k.ToString() + "_quantity", gi.m_Quantity);
				if (gi.m_PrefabName != "")
					v.m_Items.Insert(gi);
			}
			int hzCount = 0;
			ctx.ReadValue(ep + "hz_count", hzCount);
			for (int h = 0; h < hzCount; h++)
			{
				JobGarageHitzoneDamage hd = new JobGarageHitzoneDamage();
				ctx.ReadValue(ep + "hz_" + h.ToString() + "_name", hd.m_HitzoneName);
				ctx.ReadValue(ep + "hz_" + h.ToString() + "_dmg", hd.m_DamageValue);
				if (hd.m_HitzoneName != "")
					v.m_HitzoneDamages.Insert(hd);
			}
			if (v.m_OwnerUID != "" && v.m_PrefabName != "")
			{
				m_Vehicles.Insert(v);
				loaded++;
			}
		}

		// Collecte les UIDs uniques et ecrit un shard par UID
		ref set<string> uniqueUIDs = new set<string>();
		int totalCount = m_Vehicles.Count();
		for (int ii = 0; ii < totalCount; ii++)
		{
			JobGarageVehicle vv = m_Vehicles.Get(ii);
			if (vv && vv.m_OwnerUID != "")
				uniqueUIDs.Insert(vv.m_OwnerUID);
		}
		for (int ui = 0; ui < uniqueUIDs.Count(); ui++)
		{
			SaveOwnerToDisk(uniqueUIDs.Get(ui));
		}
		SaveShardIndex();

		// Note : on NE SUPPRIME PAS l ancien fichier virtual_garage.json.
		// Il reste comme backup naturel sur disque. Les prochains boots verront
		// SHARD_INDEX_PATH existe -> LoadShardsFromDisk reussit -> MigrateFromOldFormat
		// n est plus jamais appele. L ancien fichier peut etre supprime manuellement
		// par l admin apres verification que les shards sont bons.
		int elapsed = System.GetTickCount() - t0;
		Print(string.Format("[JobVirtualGarageManager] MIGRATION OK : %1 vehicules migres vers %2 shards en %3 ms. Ancien fichier conserve pour backup : %4",
			loaded, uniqueUIDs.Count(), elapsed, SAVE_PATH), LogLevel.NORMAL);
		return true;
	}

	//------------------------------------------------------------------------------------------------
	// S assure que le dossier SHARD_DIR existe. Essaie plusieurs methodes selon ce que
	// l API Enfusion expose. On ecrit un fichier marker : SCR_JsonSaveContext.SaveToFile
	// cree le dossier parent sur certaines versions d Enfusion.
	//------------------------------------------------------------------------------------------------
	void EnsureShardDirExists()
	{
		string markerPath = SHARD_DIR + ".dir_init";
		// Si marker existe deja, le dossier existe
		if (FileIO.FileExists(markerPath))
			return;
		// Ecrit un marker vide : si l API cree le dossier parent, ok. Sinon echec silencieux
		// mais au moins on aura essaye.
		SCR_JsonSaveContext ctx = new SCR_JsonSaveContext();
		ctx.WriteValue("init", 1);
		ctx.SaveToFile(markerPath);
		if (FileIO.FileExists(markerPath))
			Print("[JobVirtualGarageManager] Dossier des shards OK : " + SHARD_DIR, LogLevel.NORMAL);
		else
			Print("[JobVirtualGarageManager] ATTENTION : impossible de creer " + SHARD_DIR + " automatiquement. Cree-le manuellement : mkdir virtual_garage/", LogLevel.WARNING);
	}

	//------------------------------------------------------------------------------------------------
	// Verifie la coherence de l index : compte combien des UIDs listes dans l index
	// ont un shard reellement present sur disque. Retourne la proportion [0.0, 1.0].
	//------------------------------------------------------------------------------------------------
	float CheckShardIntegrity()
	{
		SCR_JsonLoadContext idxCtx = new SCR_JsonLoadContext();
		if (!idxCtx.LoadFromFile(SHARD_INDEX_PATH))
			return 0.0;
		int uidCount = 0;
		idxCtx.ReadValue("uid_count", uidCount);
		if (uidCount == 0)
			return 1.0;
		int present = 0;
		for (int i = 0; i < uidCount; i++)
		{
			string uid = "";
			idxCtx.ReadValue("uid_" + i.ToString(), uid);
			if (uid == "")
				continue;
			if (FileIO.FileExists(BuildShardPath(uid)))
				present++;
		}
		return present / Math.Max(1.0, uidCount);
	}

	//------------------------------------------------------------------------------------------------
	// Point d entree au boot : charge tous les shards OU migre depuis l ancien format OU rien.
	//
	// Logique de securite :
	// - Si l index existe ET que l ancien virtual_garage.json existe encore :
	//     verifie que la grande majorite des shards sont presents sur disque. Si <80% presents,
	//     c est une migration incomplete (ex: dossier manquant au premier boot) -> on REFAIT
	//     la migration depuis l ancien fichier qui est encore la source de verite.
	// - Sinon : usage normal des shards.
	//------------------------------------------------------------------------------------------------
	void LoadFromDisk()
	{
		if (FileIO.FileExists(SHARD_INDEX_PATH))
		{
			// Index present : verifie que les shards sont bien tous la
			if (FileIO.FileExists(SAVE_PATH))
			{
				float integrity = CheckShardIntegrity();
				if (integrity < 0.8)
				{
					Print(string.Format("[JobVirtualGarageManager] ALERTE : index listant des UIDs sans shard associe (integrity=%1). Migration incomplete detectee. Re-migration depuis l ancien fichier...",
						integrity), LogLevel.WARNING);
					// Re-migration : vide m_Vehicles pour ne pas doubler, puis migre
					m_Vehicles.Clear();
					if (MigrateFromOldFormat())
						return;
				}
			}
			// Shards OK, charge normalement
			if (LoadShardsFromDisk())
				return;
		}
		// Pas d index : tente migration depuis l ancien format
		if (MigrateFromOldFormat())
			return;
		Print("[JobVirtualGarageManager] Pas de save a charger (premier run)", LogLevel.NORMAL);
	}

	//------------------------------------------------------------------------------------------------
	// FALLBACK : reecrit TOUS les shards. A appeler seulement en cas d urgence ou commande admin.
	// Normalement MarkOwnerDirty + FlushGarageSave suffisent pour sauver incrementalement.
	//------------------------------------------------------------------------------------------------
	void SaveToDisk()
	{
		if (!m_Vehicles)
		{
			Print("[JobVirtualGarageManager] ATTENTION : m_Vehicles est null, SaveToDisk annule !",
				LogLevel.ERROR);
			return;
		}
		ref set<string> uniqueUIDs = new set<string>();
		int totalCount = m_Vehicles.Count();
		for (int i = 0; i < totalCount; i++)
		{
			JobGarageVehicle v = m_Vehicles.Get(i);
			if (v && v.m_OwnerUID != "")
				uniqueUIDs.Insert(v.m_OwnerUID);
		}
		for (int j = 0; j < uniqueUIDs.Count(); j++)
			SaveOwnerToDisk(uniqueUIDs.Get(j));
		SaveShardIndex();
	}
	
	//------------------------------------------------------------------------------------------------
	// ===== CLEF VIERGE =====
	// Verifie le cooldown 30 minutes. Si OK, marque le UID + retourne 0.
	// Sinon retourne le nombre de secondes restantes (toujours > 0).
	//
	// Retourne :
	//   0 = OK (le caller peut spawn la clef)
	//   > 0 = secondes restantes avant prochaine distribution autorisee
	//------------------------------------------------------------------------------------------------
	int RequestBlankKey(string playerUID)
	{
		if (playerUID == "")
			return 1;  // securite, traite comme cooldown 1s
		
		int now = System.GetUnixTime();
		int lastTime;
		if (m_BlankKeyCooldowns.Find(playerUID, lastTime))
		{
			int elapsed = now - lastTime;
			if (elapsed < BLANK_KEY_COOLDOWN_SECONDS)
				return BLANK_KEY_COOLDOWN_SECONDS - elapsed;  // secondes restantes
		}
		
		// OK : enregistre le timestamp et autorise
		m_BlankKeyCooldowns.Set(playerUID, now);
		Print(string.Format("[JobVirtualGarageManager] Clef vierge distribuee a %1", playerUID),
			LogLevel.NORMAL);
		return 0;
	}

	//============================================================================================
	// ===== SYSTEME UUID STABLE + REGISTRE DES VEHICULES ACTIFS =====
	// Permet aux vehicules sur la map de conserver leur proprietaire au reboot/crash.
	//============================================================================================

	//------------------------------------------------------------------------------------------------
	// Genere un UUID unique pour un nouveau vehicule. Appele UNIQUEMENT par RegisterNewPurchase
	// au moment de l achat chez le concessionnaire. Pas de regeneration ailleurs.
	//------------------------------------------------------------------------------------------------
	string GenerateVehicleUUID(string ownerUID)
	{
		int now = System.GetUnixTime();
		int rand = Math.RandomInt(0, 99999);
		string shortOwner = ownerUID;
		if (shortOwner.Length() > 8)
			shortOwner = shortOwner.Substring(0, 8);
		return string.Format("VEH-%1-%2-%3", now.ToString(), shortOwner, rand.ToString());
	}

	//------------------------------------------------------------------------------------------------
	// Serialise une position en format standard "x y z" (sans chevrons ni virgules), parsable
	// directement par string.ToVector() ET par notre parseur tolerant ci-dessous.
	//------------------------------------------------------------------------------------------------
	string SerializeVector(vector v)
	{
		return string.Format("%1 %2 %3", v[0], v[1], v[2]);
	}

	//------------------------------------------------------------------------------------------------
	// Parse une position depuis les differents formats possibles :
	//   - format standard "x y z"
	//   - format historique "<x, y, z>" (celui que vector.ToString() produit)
	// Retourne vector.Zero si le parse echoue.
	//------------------------------------------------------------------------------------------------
	vector ParseVectorString(string s)
	{
		if (s == "")
			return vector.Zero;

		// Decompose en nombres en traitant <, >, ' ' et ',' comme separateurs
		array<string> parts = new array<string>();
		string current = "";
		int len = s.Length();
		for (int i = 0; i < len; i++)
		{
			string ch = s.Get(i);
			if (ch == "<" || ch == ">" || ch == " " || ch == ",")
			{
				if (current.Length() > 0)
				{
					parts.Insert(current);
					current = "";
				}
			}
			else
			{
				current = current + ch;
			}
		}
		if (current.Length() > 0)
			parts.Insert(current);

		if (parts.Count() < 3)
			return vector.Zero;

		return Vector(parts[0].ToFloat(), parts[1].ToFloat(), parts[2].ToFloat());
	}

	//------------------------------------------------------------------------------------------------
	// Lit le composant persist d un vehicule. Retourne null si le prefab ne l a pas.
	//------------------------------------------------------------------------------------------------
	LP_VehiclePersistComponent GetPersistComponent(IEntity vehicle)
	{
		if (!vehicle)
			return null;
		return LP_VehiclePersistComponent.Cast(vehicle.FindComponent(LP_VehiclePersistComponent));
	}

	//------------------------------------------------------------------------------------------------
	// APPELE PAR LE SHOP CONCESSIONNAIRE apres chaque spawn d un vehicule achete.
	// Genere l UUID, l ecrit sur le composant, et enregistre l entree dans m_ActiveVehicles.
	//------------------------------------------------------------------------------------------------
	void RegisterNewPurchase(IEntity vehicle, string ownerUID, ResourceName prefabName)
	{
		if (!vehicle || ownerUID == "")
			return;

		LP_VehiclePersistComponent comp = GetPersistComponent(vehicle);
		if (!comp)
		{
			// Prefab sans composant persist : on tolere mais pas de tracking (vehicule libre apres reboot).
			Print(string.Format("[JobVirtualGarageManager] RegisterNewPurchase SKIP : prefab=%1 n a pas LP_VehiclePersistComponent",
				prefabName), LogLevel.WARNING);
			return;
		}

		string uuid = GenerateVehicleUUID(ownerUID);
		comp.SetVehicleUUID(uuid);
		comp.SetOwnerUID(ownerUID);

		JobActiveVehicleData data = new JobActiveVehicleData();
		data.m_VehicleUUID = uuid;
		data.m_OwnerUID = ownerUID;
		data.m_PrefabName = prefabName;
		data.m_PosStr = SerializeVector(vehicle.GetOrigin());
		data.m_RotStr = SerializeVector(vehicle.GetAngles());
		data.m_Fuel = ReadVehicleFuel(vehicle);
		data.m_LastUpdateUnix = System.GetUnixTime();
		m_ActiveVehicles.Set(uuid, data);
		m_UUIDToEntityCache.Set(uuid, vehicle); // cache direct pour eviter le scan monde au tick

		// Enregistre aussi dans la map runtime RplId -> owner (compat avec code existant)
		RplComponent rpl = RplComponent.Cast(vehicle.FindComponent(RplComponent));
		if (rpl)
			m_VehicleOwners.Set(rpl.Id().ToString(), ownerUID);

		MarkActiveSaveDirty();

		// === PLAQUE D IMMATRICULATION : genere + applique une plaque unique sur le vehicule ===
		JobLicensePlateManager.GetInstance().AssignPlateToVehicle(vehicle, uuid);

		Print(string.Format("[JobVirtualGarageManager] RegisterNewPurchase OK : uuid=%1 owner=%2 prefab=%3",
			uuid, ownerUID, prefabName), LogLevel.NORMAL);
	}

	//------------------------------------------------------------------------------------------------
	// Appele quand un vehicule actif change de proprietaire via le menu transfert (sur la map).
	//------------------------------------------------------------------------------------------------
	void UpdateActiveOwner(string uuid, string newOwnerUID)
	{
		if (uuid == "")
			return;
		JobActiveVehicleData data;
		if (!m_ActiveVehicles.Find(uuid, data) || !data)
			return;
		data.m_OwnerUID = newOwnerUID;
		MarkActiveSaveDirty();
	}

	//------------------------------------------------------------------------------------------------
	// Retire un vehicule du registre actif (appele au stockage garage, destruction definitive).
	//------------------------------------------------------------------------------------------------
	void UnregisterActiveVehicle(string uuid)
	{
		if (uuid == "")
			return;
		bool wasRegistered = m_ActiveVehicles.Contains(uuid);
		if (wasRegistered)
			m_ActiveVehicles.Remove(uuid);
		if (m_UUIDToEntityCache.Contains(uuid))
			m_UUIDToEntityCache.Remove(uuid);
		if (wasRegistered)
			MarkActiveSaveDirty();
	}

	//------------------------------------------------------------------------------------------------
	// Ajoute une entree active a partir d un vehicule qui vient de sortir du garage virtuel.
	//------------------------------------------------------------------------------------------------
	void RegisterRetrievedVehicle(IEntity vehicle, string uuid, string ownerUID, ResourceName prefabName, string insuranceUUID = "")
	{
		if (!vehicle || uuid == "")
			return;

		LP_VehiclePersistComponent comp = GetPersistComponent(vehicle);
		if (comp)
		{
			comp.SetVehicleUUID(uuid);
			comp.SetOwnerUID(ownerUID);
		}

		JobActiveVehicleData data = new JobActiveVehicleData();
		data.m_VehicleUUID = uuid;
		data.m_OwnerUID = ownerUID;
		data.m_PrefabName = prefabName;
		data.m_PosStr = SerializeVector(vehicle.GetOrigin());
		data.m_RotStr = SerializeVector(vehicle.GetAngles());
		data.m_InsuranceUUID = insuranceUUID; // propage l assurance depuis le StoredVehicle
		data.m_Fuel = ReadVehicleFuel(vehicle);
		data.m_LastUpdateUnix = System.GetUnixTime();
		m_ActiveVehicles.Set(uuid, data);
		m_UUIDToEntityCache.Set(uuid, vehicle); // cache direct
		MarkActiveSaveDirty();

		// === PLAQUE D IMMATRICULATION : recupere la plaque enregistree (ou genere si nouvelle UUID) ===
		JobLicensePlateManager.GetInstance().AssignPlateToVehicle(vehicle, uuid);
	}

	//------------------------------------------------------------------------------------------------
	// Tick 60s : met a jour position/rotation/fuel/damage de chaque vehicule actif encore spawn,
	// puis sauvegarde le JSON. Permet de survivre aux crashs non prevus.
	//------------------------------------------------------------------------------------------------
	void TickSnapshotActiveVehicles()
	{
		if (!m_ActiveVehicles || m_ActiveVehicles.Count() == 0)
			return;

		int count = m_ActiveVehicles.Count();
		int now = System.GetUnixTime();
		int updated = 0;
		int skippedStationary = 0;
		int skippedRoundRobin = 0;
		int notFound = 0;
		bool anyDirty = false;

		// Shard courant pour le round-robin : ce tick traite seulement les vehicules
		// dont (index % SNAPSHOT_SHARDS) == myShard. Prochain tick, myShard avance.
		int myShard = m_SnapshotCursor;
		m_SnapshotCursor = (m_SnapshotCursor + 1) % SNAPSHOT_SHARDS;

		// Seuils optim : au-dela de ces 2 limites, on resnapshot le vehicule meme s il n a pas bouge
		// MAX_STALE_SECONDS augmente a ~17 min pour couvrir le cycle round-robin (5 * 180s = 900s).
		const float MIN_MOVE_SQ = 1.0;          // 1m^2 (racine ~1m)
		const int MAX_STALE_SECONDS = 1000;     // ~17 minutes

		for (int i = 0; i < count; i++)
		{
			// ROUND-ROBIN : ce tick traite seulement 1/SNAPSHOT_SHARDS des vehicules.
			// Chaque vehicule a sa chance tous les SNAPSHOT_SHARDS ticks.
			if ((i % SNAPSHOT_SHARDS) != myShard)
			{
				skippedRoundRobin++;
				continue;
			}

			string uuid = m_ActiveVehicles.GetKey(i);
			JobActiveVehicleData data = m_ActiveVehicles.GetElement(i);
			if (!data)
				continue;

			IEntity vehicle = FindActiveVehicleByUUID(uuid);
			if (!vehicle)
			{
				notFound++;
				continue;
			}

			// OPTIM : skip si le vehicule n a pas bouge ET que son dernier snapshot est recent.
			vector curPos = vehicle.GetOrigin();
			vector lastPos = ParseVectorString(data.m_PosStr);
			float distSq = vector.DistanceSq(curPos, lastPos);
			int staleSec = now - data.m_LastUpdateUnix;
			if (distSq < MIN_MOVE_SQ && staleSec < MAX_STALE_SECONDS)
			{
				skippedStationary++;
				continue;
			}

			// Vehicule bouge ou snapshot vieux : rafraichit toutes les donnees
			data.m_PosStr = SerializeVector(curPos);
			data.m_RotStr = SerializeVector(vehicle.GetAngles());
			data.m_Fuel = ReadVehicleFuel(vehicle);
			data.m_InsuranceUUID = JobInsuranceManager.GetInstance().GetVehicleInstanceId(vehicle);
			data.m_LastUpdateUnix = now;
			anyDirty = true;
			updated++;
		}

		// OPTIM : ecriture disque differee (debounce) uniquement si au moins un vehicule a change.
		if (anyDirty)
			MarkActiveSaveDirty();

		// OPTIM : purge periodique des caches pour eviter le buildup de refs mortes
		// (previent le lag qui revient apres plusieurs heures).
		m_PurgeTickCounter++;
		int purgedCache = 0;
		int purgedOwners = 0;
		int purgedPhantoms = 0;
		if (m_PurgeTickCounter >= PURGE_EVERY_N_TICKS)
		{
			m_PurgeTickCounter = 0;
			purgedCache = PurgeDeadCacheEntries();
			purgedOwners = PurgeDeadVehicleOwners();
			purgedPhantoms = PurgePhantomActiveVehicles();
			if (purgedPhantoms > 0)
				MarkActiveSaveDirty(); // sauve le fichier allege
		}

		Print(string.Format("[JobVirtualGarageManager] TickSnapshot shard=%1/%2 : %3 maj, %4 stationnaires skip, %5 round-robin skip, %6 non trouves (total=%7, save=%8)",
			myShard, SNAPSHOT_SHARDS, updated, skippedStationary, skippedRoundRobin, notFound, count, anyDirty.ToString()), LogLevel.NORMAL);
		if (purgedCache > 0 || purgedOwners > 0 || purgedPhantoms > 0)
		{
			Print(string.Format("[JobVirtualGarageManager] TickSnapshot PURGE : purgedCache=%1 purgedOwners=%2 purgedPhantoms=%3",
				purgedCache, purgedOwners, purgedPhantoms), LogLevel.NORMAL);
		}
	}

	//------------------------------------------------------------------------------------------------
	// === DEBOUNCE DES SAUVEGARDES DISQUE ===
	// Au lieu d appeler SaveActiveVehiclesToDisk() sync a chaque Register/Unregister/Update,
	// on marque dirty et on planifie une ecriture dans SAVE_DEBOUNCE_MS ms.
	// Plusieurs operations consecutives sont ainsi regroupees en 1 seule I/O disque.
	//------------------------------------------------------------------------------------------------
	void MarkActiveSaveDirty()
	{
		m_ActiveSaveDirty = true;
		if (!m_ActiveSaveScheduled)
		{
			m_ActiveSaveScheduled = true;
			GetGame().GetCallqueue().CallLater(FlushActiveSave, SAVE_DEBOUNCE_MS, false);
		}
	}

	void FlushActiveSave()
	{
		m_ActiveSaveScheduled = false;
		if (!m_ActiveSaveDirty)
			return;
		m_ActiveSaveDirty = false;
		// Mesure le temps d ecriture : si > 100ms, c est un suspect pour les STALL reseau.
		int t0 = System.GetTickCount();
		SaveActiveVehiclesToDisk();
		int elapsed = System.GetTickCount() - t0;
		if (elapsed > 50)
			Print(string.Format("[JobVirtualGarageManager] FlushActiveSave : ecriture disque = %1 ms (%2 vehicules actifs)",
				elapsed, m_ActiveVehicles.Count()), LogLevel.WARNING);
	}

	//------------------------------------------------------------------------------------------------
	// Marque UN shard de UID dirty. Au prochain flush, SEUL ce shard sera reecrit (~20 KB).
	// Multiple MarkOwnerDirty avant le flush = tous les shards sont flushes en batch,
	// mais chaque write reste petit et rapide (jamais >50ms meme en pic).
	//------------------------------------------------------------------------------------------------
	void MarkOwnerDirty(string ownerUID)
	{
		if (ownerUID == "")
			return;
		m_DirtyOwnerUIDs.Insert(ownerUID);
		m_IndexDirty = true; // par securite, reecrit l index aussi
		if (!m_GarageSaveScheduled)
		{
			m_GarageSaveScheduled = true;
			GetGame().GetCallqueue().CallLater(FlushGarageSave, SAVE_DEBOUNCE_MS, false);
		}
	}

	//------------------------------------------------------------------------------------------------
	// Flush : ecrit chaque shard dirty + l index. Mesure le temps pour debug.
	//------------------------------------------------------------------------------------------------
	void FlushGarageSave()
	{
		m_GarageSaveScheduled = false;
		if (m_DirtyOwnerUIDs.IsEmpty() && !m_IndexDirty)
			return;

		int t0 = System.GetTickCount();
		int writtenShards = 0;
		for (int i = 0; i < m_DirtyOwnerUIDs.Count(); i++)
		{
			SaveOwnerToDisk(m_DirtyOwnerUIDs.Get(i));
			writtenShards++;
		}
		if (m_IndexDirty)
		{
			SaveShardIndex();
			m_IndexDirty = false;
		}
		m_DirtyOwnerUIDs.Clear();
		int elapsed = System.GetTickCount() - t0;
		if (elapsed > 50)
			Print(string.Format("[JobVirtualGarageManager] FlushGarageSave : %1 shards ecrits en %2 ms",
				writtenShards, elapsed), LogLevel.WARNING);
	}

	//------------------------------------------------------------------------------------------------
	// Purge les entries du cache UUID->IEntity dont l entite est deletee/nulle.
	// Previent le buildup de refs mortes apres plusieurs heures de serveur.
	// Retourne le nombre d entries supprimees.
	//------------------------------------------------------------------------------------------------
	int PurgeDeadCacheEntries()
	{
		if (!m_UUIDToEntityCache || m_UUIDToEntityCache.Count() == 0)
			return 0;
		array<string> toRemove = new array<string>();
		int cacheCount = m_UUIDToEntityCache.Count();
		for (int i = 0; i < cacheCount; i++)
		{
			string uuid = m_UUIDToEntityCache.GetKey(i);
			IEntity ent = m_UUIDToEntityCache.GetElement(i);
			if (!ent || ent.IsDeleted())
				toRemove.Insert(uuid);
		}
		foreach (string k : toRemove)
			m_UUIDToEntityCache.Remove(k);
		return toRemove.Count();
	}

	//------------------------------------------------------------------------------------------------
	// Purge les entries de m_VehicleOwners dont le RplId n a plus d entite associee.
	// Un vehicule peut mourir sans passer par le store (destruction en combat, despawn natif).
	// Sans purge, cette map grossit indefiniment et ralentit les lookups.
	//------------------------------------------------------------------------------------------------
	int PurgeDeadVehicleOwners()
	{
		if (!m_VehicleOwners || m_VehicleOwners.Count() == 0)
			return 0;
		array<string> toRemove = new array<string>();
		int ownersCount = m_VehicleOwners.Count();
		for (int i = 0; i < ownersCount; i++)
		{
			string rplKey = m_VehicleOwners.GetKey(i);
			int rplIdInt = rplKey.ToInt();
			if (rplIdInt == 0)
			{
				toRemove.Insert(rplKey);
				continue;
			}
			RplId rid = rplIdInt;
			RplComponent rplComp = RplComponent.Cast(Replication.FindItem(rid));
			if (!rplComp)
			{
				toRemove.Insert(rplKey);
				continue;
			}
			IEntity ent = rplComp.GetEntity();
			if (!ent || ent.IsDeleted())
				toRemove.Insert(rplKey);
		}
		foreach (string k : toRemove)
			m_VehicleOwners.Remove(k);
		return toRemove.Count();
	}

	//------------------------------------------------------------------------------------------------
	// Purge les entrees FANTOMES de m_ActiveVehicles : un vehicule enregistre comme actif
	// qui n existe plus dans le monde (detruit ou despawn sans passer par store/retrieve).
	// Sans ce nettoyage, le fichier active_vehicles.json grossit indefiniment avec des entrees
	// mortes, ce qui alourdit chaque SaveActiveVehiclesToDisk().
	// Les logs TickSnapshot avec "notFound=X" revelent exactement ces entrees.
	//------------------------------------------------------------------------------------------------
	int PurgePhantomActiveVehicles()
	{
		if (!m_ActiveVehicles || m_ActiveVehicles.Count() == 0)
			return 0;
		array<string> toRemove = new array<string>();
		int activeCount = m_ActiveVehicles.Count();
		int now = System.GetUnixTime();
		for (int i = 0; i < activeCount; i++)
		{
			string uuid = m_ActiveVehicles.GetKey(i);
			JobActiveVehicleData data = m_ActiveVehicles.GetElement(i);
			if (!data || uuid == "")
			{
				toRemove.Insert(uuid);
				continue;
			}
			// Ne purge que les vehicules introuvables depuis >= 20 min pour laisser le temps
			// a la reconciliation startup + eventuels respawn natifs Enfusion.
			int staleSec = now - data.m_LastUpdateUnix;
			if (staleSec < 1200)
				continue;
			// Verifie si le vehicule est toujours dans le monde (via cache ou scan)
			IEntity ent = FindActiveVehicleByUUID(uuid);
			if (!ent || ent.IsDeleted())
			{
				Print(string.Format("[JobVirtualGarageManager] Purge fantome : uuid=%1 owner=%2 prefab=%3 (stale=%4s)",
					uuid, data.m_OwnerUID, data.m_PrefabName, staleSec), LogLevel.NORMAL);
				toRemove.Insert(uuid);
			}
		}
		foreach (string k : toRemove)
		{
			m_ActiveVehicles.Remove(k);
			if (m_UUIDToEntityCache.Contains(k))
				m_UUIDToEntityCache.Remove(k);
		}
		return toRemove.Count();
	}

	//------------------------------------------------------------------------------------------------
	// Scan la map pour trouver l entite vehicule avec le composant portant cet UUID.
	//------------------------------------------------------------------------------------------------
	static string s_FindByUUIDTarget;
	static IEntity s_FindByUUIDResult;

	IEntity FindActiveVehicleByUUID(string uuid)
	{
		if (uuid == "")
			return null;

		// FAST PATH : cache direct UUID -> IEntity. Evite le scan complet du monde.
		IEntity cached;
		if (m_UUIDToEntityCache.Find(uuid, cached))
		{
			if (cached)
				return cached;
			// Reference nullifiee (vehicule detruit) : purge le cache et tombe en fallback
			m_UUIDToEntityCache.Remove(uuid);
		}

		// SLOW PATH : scan monde (uniquement pour reconciliation startup ou cache miss)
		s_FindByUUIDTarget = uuid;
		s_FindByUUIDResult = null;
		BaseWorld world = GetGame().GetWorld();
		if (!world)
			return null;
		world.QueryEntitiesByAABB("-50000 -500 -50000", "50000 2000 50000", FindByUUIDCallback, null, EQueryEntitiesFlags.ALL);

		// Si trouve, repeuple le cache pour les prochains ticks
		if (s_FindByUUIDResult)
			m_UUIDToEntityCache.Set(uuid, s_FindByUUIDResult);

		return s_FindByUUIDResult;
	}

	static bool FindByUUIDCallback(IEntity e)
	{
		if (!e || s_FindByUUIDResult)
			return true;
		LP_VehiclePersistComponent comp = LP_VehiclePersistComponent.Cast(e.FindComponent(LP_VehiclePersistComponent));
		if (!comp)
			return true;
		if (comp.GetVehicleUUID() == s_FindByUUIDTarget)
		{
			s_FindByUUIDResult = e;
			return false;
		}
		return true;
	}

	//------------------------------------------------------------------------------------------------
	// Fallback : trouve un vehicule par prefab + position proche (pour les cas ou le save-world
	// natif a bien respawn le vehicule mais sans preserver les attributs du composant persist).
	//------------------------------------------------------------------------------------------------
	static string s_FindByPrefabPrefab;
	static vector s_FindByPrefabPos;
	static float s_FindByPrefabBestDist;
	static IEntity s_FindByPrefabResult;

	IEntity FindVehicleByPrefabNearPos(string prefabName, vector pos, float maxDistance = 10.0)
	{
		s_FindByPrefabPrefab = prefabName;
		s_FindByPrefabPos = pos;
		s_FindByPrefabBestDist = maxDistance * maxDistance;
		s_FindByPrefabResult = null;
		BaseWorld world = GetGame().GetWorld();
		if (!world)
			return null;
		vector mins = pos - Vector(maxDistance, 50, maxDistance);
		vector maxs = pos + Vector(maxDistance, 50, maxDistance);
		world.QueryEntitiesByAABB(mins, maxs, FindByPrefabCallback, null, EQueryEntitiesFlags.ALL);
		return s_FindByPrefabResult;
	}

	static bool FindByPrefabCallback(IEntity e)
	{
		if (!e)
			return true;
		EntityPrefabData pd = e.GetPrefabData();
		if (!pd)
			return true;
		if (pd.GetPrefabName() != s_FindByPrefabPrefab)
			return true;
		float distSq = vector.DistanceSq(e.GetOrigin(), s_FindByPrefabPos);
		if (distSq > s_FindByPrefabBestDist)
			return true;
		s_FindByPrefabBestDist = distSq;
		s_FindByPrefabResult = e;
		return true;
	}

	//------------------------------------------------------------------------------------------------
	// Appele 10s apres l init du manager pour reconcilier les vehicules actifs avec le monde.
	// Pour chaque entree active : cherche le vehicule correspondant dans le monde par UUID.
	// Si trouve : parfait (le save-world natif a sauve/restaure le composant).
	// Si pas trouve : respawn au prefab/position memorises et re-fixe UUID+OwnerUID sur composant.
	//------------------------------------------------------------------------------------------------
	void ReconcileActiveVehiclesAtStartup()
	{
		if (!Replication.IsServer())
			return;
		if (!m_ActiveVehicles || m_ActiveVehicles.Count() == 0)
		{
			Print("[JobVirtualGarageManager] Reconciliation : aucun vehicule actif a reconcilier.", LogLevel.NORMAL);
			return;
		}

		int reconciled = 0;
		int reconciledByPos = 0;
		int notFound = 0;
		int count = m_ActiveVehicles.Count();

		Print(string.Format("[JobVirtualGarageManager] Reconciliation : debut (total=%1)", count), LogLevel.NORMAL);

		for (int i = 0; i < count; i++)
		{
			string uuid = m_ActiveVehicles.GetKey(i);
			JobActiveVehicleData data = m_ActiveVehicles.GetElement(i);
			if (!data)
				continue;

			Print(string.Format("[JobVirtualGarageManager] Reconcilie uuid=%1 owner=%2 prefab=%3 pos=%4",
				uuid, data.m_OwnerUID, data.m_PrefabName, data.m_PosStr), LogLevel.NORMAL);

			// Tentative 1 : trouver par UUID (si le save-world natif a preserve le composant)
			IEntity found = FindActiveVehicleByUUID(uuid);
			if (found)
			{
				LP_VehiclePersistComponent comp = GetPersistComponent(found);
				if (comp)
				{
					comp.SetVehicleUUID(data.m_VehicleUUID);
					comp.SetOwnerUID(data.m_OwnerUID);
				}
				RplComponent rpl = RplComponent.Cast(found.FindComponent(RplComponent));
				if (rpl)
					m_VehicleOwners.Set(rpl.Id().ToString(), data.m_OwnerUID);
				m_UUIDToEntityCache.Set(uuid, found);
				RestoreInsuranceOnVehicle(found, data);
				// Plaque d immatriculation
				JobLicensePlateManager.GetInstance().AssignPlateToVehicle(found, data.m_VehicleUUID);
				reconciled++;
				Print(string.Format("[JobVirtualGarageManager]   -> trouve par UUID"), LogLevel.NORMAL);
				continue;
			}

			// Tentative 2 : fallback - cherche par prefab + position proche
			// (cas ou le save-world natif a respawn le vehicule mais sans preserver le composant)
			vector pos = ParseVectorString(data.m_PosStr);
			if (data.m_PrefabName != "" && pos != vector.Zero)
			{
				IEntity foundByPos = FindVehicleByPrefabNearPos(data.m_PrefabName, pos, 15.0);
				if (foundByPos)
				{
					LP_VehiclePersistComponent comp2 = GetPersistComponent(foundByPos);
					if (comp2)
					{
						comp2.SetVehicleUUID(data.m_VehicleUUID);
						comp2.SetOwnerUID(data.m_OwnerUID);
					}
					RplComponent rpl2 = RplComponent.Cast(foundByPos.FindComponent(RplComponent));
					if (rpl2)
						m_VehicleOwners.Set(rpl2.Id().ToString(), data.m_OwnerUID);
					m_UUIDToEntityCache.Set(uuid, foundByPos);
					RestoreInsuranceOnVehicle(foundByPos, data);
					// Plaque d immatriculation
					JobLicensePlateManager.GetInstance().AssignPlateToVehicle(foundByPos, data.m_VehicleUUID);
					reconciledByPos++;
					Print(string.Format("[JobVirtualGarageManager]   -> trouve par prefab+pos (distance proche)"), LogLevel.NORMAL);
					continue;
				}
			}

			// Pas trouve ni par UUID ni par prefab+pos : NE PAS RESPAWN (evite les duplications
			// quand le save-world natif Enfusion fait un respawn tardif juste apres).
			// L entree reste dans m_ActiveVehicles. Si le vehicule reapparait plus tard (via
			// save-world natif tardif), une future reconciliation ou le tick snapshot pourra
			// le retrouver via FindVehicleByPrefabNearPos a l occasion d un futur retry.
			Print(string.Format("[JobVirtualGarageManager]   -> NOT FOUND (pas de respawn, l entree reste dans le JSON pour retry ulterieur)"),
				LogLevel.WARNING);
			notFound++;
		}

		Print(string.Format("[JobVirtualGarageManager] Reconciliation terminee : %1 par UUID, %2 par prefab+pos, %3 non trouves (total=%4)",
			reconciled, reconciledByPos, notFound, count), LogLevel.NORMAL);

		// Planifie une 2eme passe de reconciliation 60s plus tard, pour rattraper les vehicules
		// que le save-world natif Enfusion aurait respawnes tardivement. Toujours sans respawn
		// de notre cote, uniquement rematch.
		if (notFound > 0)
		{
			Print(string.Format("[JobVirtualGarageManager] %1 vehicules non trouves - 2eme passe de reconciliation dans 60s",
				notFound), LogLevel.NORMAL);
			GetGame().GetCallqueue().CallLater(RetryReconcileMissingVehicles, 60000, false);
		}
	}

	//------------------------------------------------------------------------------------------------
	// 2eme passe de reconciliation (declenchee 60s apres la 1ere si des vehicules manquaient).
	// Retente de retrouver les vehicules absents, uniquement par UUID + prefab+pos (jamais de respawn).
	// Un vehicule qui apparait apres plusieurs minutes finira par etre rattrape par un futur tick
	// snapshot si on l a enregistre dans le JSON.
	//------------------------------------------------------------------------------------------------
	void RetryReconcileMissingVehicles()
	{
		if (!Replication.IsServer())
			return;
		if (!m_ActiveVehicles || m_ActiveVehicles.Count() == 0)
			return;

		int rematched = 0;
		int stillMissing = 0;
		int count = m_ActiveVehicles.Count();

		for (int i = 0; i < count; i++)
		{
			string uuid = m_ActiveVehicles.GetKey(i);
			JobActiveVehicleData data = m_ActiveVehicles.GetElement(i);
			if (!data)
				continue;

			// Deja dans le cache (deja reconcilie) -> skip
			IEntity cached;
			if (m_UUIDToEntityCache.Find(uuid, cached) && cached)
				continue;

			// Retente UUID
			IEntity found = FindActiveVehicleByUUID(uuid);
			if (found)
			{
				LP_VehiclePersistComponent comp = GetPersistComponent(found);
				if (comp)
				{
					comp.SetVehicleUUID(data.m_VehicleUUID);
					comp.SetOwnerUID(data.m_OwnerUID);
				}
				RplComponent rpl = RplComponent.Cast(found.FindComponent(RplComponent));
				if (rpl)
					m_VehicleOwners.Set(rpl.Id().ToString(), data.m_OwnerUID);
				m_UUIDToEntityCache.Set(uuid, found);
				RestoreInsuranceOnVehicle(found, data);
				JobLicensePlateManager.GetInstance().AssignPlateToVehicle(found, data.m_VehicleUUID);
				rematched++;
				continue;
			}

			// Retente prefab+pos
			vector pos = ParseVectorString(data.m_PosStr);
			if (data.m_PrefabName != "" && pos != vector.Zero)
			{
				IEntity foundByPos = FindVehicleByPrefabNearPos(data.m_PrefabName, pos, 20.0);
				if (foundByPos)
				{
					LP_VehiclePersistComponent comp2 = GetPersistComponent(foundByPos);
					if (comp2)
					{
						comp2.SetVehicleUUID(data.m_VehicleUUID);
						comp2.SetOwnerUID(data.m_OwnerUID);
					}
					RplComponent rpl2 = RplComponent.Cast(foundByPos.FindComponent(RplComponent));
					if (rpl2)
						m_VehicleOwners.Set(rpl2.Id().ToString(), data.m_OwnerUID);
					m_UUIDToEntityCache.Set(uuid, foundByPos);
					RestoreInsuranceOnVehicle(foundByPos, data);
					JobLicensePlateManager.GetInstance().AssignPlateToVehicle(foundByPos, data.m_VehicleUUID);
					rematched++;
					continue;
				}
			}

			stillMissing++;
		}

		Print(string.Format("[JobVirtualGarageManager] 2eme passe reconciliation : %1 rematches, %2 toujours manquants",
			rematched, stillMissing), LogLevel.NORMAL);
	}

	//------------------------------------------------------------------------------------------------
	// Restaure le lien vehicule <-> assurance apres reconciliation ou respawn.
	// Verifie que l UUID d assurance existe toujours dans JobInsuranceManager (persistant sur disque),
	// re-attache le mapping runtime (rplId -> UUID) et reinstalle le damage watcher pour que
	// l auto-respawn au garage virtuel fonctionne si le vehicule est detruit.
	//------------------------------------------------------------------------------------------------
	void RestoreInsuranceOnVehicle(IEntity vehicle, JobActiveVehicleData data)
	{
		if (!vehicle || !data || data.m_InsuranceUUID == "")
			return;

		JobInsuranceManager insMgr = JobInsuranceManager.GetInstance();
		if (!insMgr)
			return;

		// Verifie que l assurance existe toujours (si l assurance a ete consommee avant le crash,
		// elle n est plus dans m_InsurancesByUUID et on ne doit pas la restaurer)
		if (!insMgr.IsUUIDInsured(data.m_InsuranceUUID))
		{
			Print(string.Format("[JobVirtualGarageManager]   -> assurance %1 non trouvee (consommee ou expiree), skip reattach",
				data.m_InsuranceUUID), LogLevel.NORMAL);
			return;
		}

		// Re-attache le mapping runtime rplId -> UUID (pour que GetVehicleInstanceId retrouve l UUID)
		insMgr.ReattachExistingUUID(vehicle, data.m_InsuranceUUID);

		// Reinstalle le damage watcher pour auto-respawn au garage si le vehicule est detruit
		InstallDamageWatcher(vehicle, data.m_InsuranceUUID, data.m_OwnerUID, data.m_PrefabName);

		Print(string.Format("[JobVirtualGarageManager]   -> assurance restauree uuid=%1",
			data.m_InsuranceUUID), LogLevel.NORMAL);
	}

	//------------------------------------------------------------------------------------------------
	// Serialisation JSON de m_ActiveVehicles
	//------------------------------------------------------------------------------------------------
	void SaveActiveVehiclesToDisk()
	{
		SCR_JsonSaveContext ctx = new SCR_JsonSaveContext();
		array<ref JobActiveVehicleData> list = new array<ref JobActiveVehicleData>();
		foreach (string k, JobActiveVehicleData v : m_ActiveVehicles)
		{
			if (v)
				list.Insert(v);
		}
		ctx.WriteValue("active_vehicles", list);
		ctx.SaveToFile(ACTIVE_SAVE_PATH);
	}

	void LoadActiveVehiclesFromDisk()
	{
		m_ActiveVehicles.Clear();
		SCR_JsonLoadContext ctx = new SCR_JsonLoadContext();
		if (!ctx.LoadFromFile(ACTIVE_SAVE_PATH))
		{
			Print(string.Format("[JobVirtualGarageManager] Pas de save active_vehicles (premier run) : %1",
				ACTIVE_SAVE_PATH), LogLevel.NORMAL);
			return;
		}
		array<ref JobActiveVehicleData> list = new array<ref JobActiveVehicleData>();
		ctx.ReadValue("active_vehicles", list);
		foreach (JobActiveVehicleData v : list)
		{
			if (v && v.m_VehicleUUID != "")
			{
				m_ActiveVehicles.Set(v.m_VehicleUUID, v);
				Print(string.Format("[JobVirtualGarageManager]   charge : uuid=%1 owner=%2 prefab=%3 pos='%4'",
					v.m_VehicleUUID, v.m_OwnerUID, v.m_PrefabName, v.m_PosStr), LogLevel.NORMAL);
			}
		}
		Print(string.Format("[JobVirtualGarageManager] %1 vehicules actifs charges depuis le disque",
			m_ActiveVehicles.Count()), LogLevel.NORMAL);
	}
}