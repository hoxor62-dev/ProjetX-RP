//------------------------------------------------------------------------------------------------
// JobCompanyOrderDetailMenu.c
// Detail d un bon de commande. Affiche :
//   - ID + statut + auteur
//   - Liste des items deposes
//   - Prix propose par l auteur
//   - Si bon EN ATTENTE et viewer = PATRON :
//      -> Editbox prix final (pre-rempli avec prix propose) + boutons Accepter/Refuser
//   - Sinon : juste lecture seule + bouton Retour
//------------------------------------------------------------------------------------------------

class JobCompanyOrderDetailMenu : ChimeraMenuBase
{
	Widget m_RootWidget;
	TextWidget m_TitleText;
	TextWidget m_HeaderText;
	TextWidget m_ItemsText;
	EditBoxWidget m_FinalPriceInput;
	ButtonWidget m_BtnAccept;
	ButtonWidget m_BtnRefuse;
	ButtonWidget m_BtnRecover;
	ButtonWidget m_BtnBack;
	
	// === Pagination items ===
	ButtonWidget m_BtnPrevPage;
	ButtonWidget m_BtnNextPage;
	TextWidget m_PageLabel;
	int m_CurrentPage = 0;
	const int ITEMS_PER_PAGE = 30;
	
	// Donnees pre-chargees
	static int s_OrderId;
	static int s_Status;
	static int s_ProposedPrice;
	static int s_FinalPrice;
	static string s_AuthorName;
	static ref array<string> s_ItemNames = new array<string>();
	static bool s_CanAct;             // viewer = patron ET bon en attente
	static bool s_CanRecover;         // viewer = auteur ET bon REFUSE ET items pas recuperes
	static bool s_ItemsRecovered;     // true si items deja recuperes (bouton grise)
	
	static JobCompanyOrderDetailMenu s_Instance;
	
	//------------------------------------------------------------------------------------------------
	static void SetPendingData(int orderId, int status, int proposedPrice, int finalPrice,
		string authorName, array<string> itemNames, bool canAct, bool canRecover, bool itemsRecovered)
	{
		s_OrderId = orderId;
		s_Status = status;
		s_ProposedPrice = proposedPrice;
		s_FinalPrice = finalPrice;
		s_AuthorName = authorName;
		s_ItemNames.Clear();
		foreach (string n : itemNames)
			s_ItemNames.Insert(n);
		s_CanAct = canAct;
		s_CanRecover = canRecover;
		s_ItemsRecovered = itemsRecovered;
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuOpen()
	{
		super.OnMenuOpen();
		s_Instance = this;
		JobFocusHandler.ClearRegistry();
		
		m_RootWidget = GetRootWidget();
		if (!m_RootWidget)
			return;
		
		m_TitleText = TextWidget.Cast(m_RootWidget.FindAnyWidget("TitleText"));
		m_HeaderText = TextWidget.Cast(m_RootWidget.FindAnyWidget("HeaderText"));
		m_ItemsText = TextWidget.Cast(m_RootWidget.FindAnyWidget("ItemsText"));
		m_FinalPriceInput = EditBoxWidget.Cast(m_RootWidget.FindAnyWidget("FinalPriceInput"));
		m_BtnAccept = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnAccept"));
		m_BtnRefuse = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnRefuse"));
		m_BtnRecover = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnRecover"));
		m_BtnBack = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnBack"));
		
		// Widgets pagination
		m_BtnPrevPage = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnPrevPage"));
		m_BtnNextPage = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("BtnNextPage"));
		m_PageLabel = TextWidget.Cast(m_RootWidget.FindAnyWidget("PageLabel"));
		m_CurrentPage = 0;
		
		BuildTexts();
		
		// Visibilite/Activation des boutons selon le role/statut
		SetVisible(m_BtnAccept, s_CanAct);
		SetVisible(m_BtnRefuse, s_CanAct);
		if (m_FinalPriceInput)
		{
			m_FinalPriceInput.SetVisible(s_CanAct);
			if (s_CanAct)
				m_FinalPriceInput.SetText(s_ProposedPrice.ToString());
		}
		
		// Bouton Recuperer mes items :
		// - Toujours visible si bon REFUSE et viewer = auteur
		// - Active uniquement si canRecover (pas deja recupere)
		bool isRefusedAndAuthor = (s_Status == 2);
		if (m_BtnRecover)
		{
			m_BtnRecover.SetVisible(isRefusedAndAuthor);
			m_BtnRecover.SetEnabled(s_CanRecover);
			// Couleur grise si grise, vert sinon
			if (s_CanRecover)
				m_BtnRecover.SetColor(Color.FromRGBA(46, 115, 51, 255));  // 0.18 0.45 0.20
			else
				m_BtnRecover.SetColor(Color.FromRGBA(89, 89, 102, 255));  // 0.35 0.35 0.40 (grise)
		}
		
		BindBtn(m_BtnAccept, "accept");
		BindBtn(m_BtnRefuse, "refuse");
		BindBtn(m_BtnRecover, "recover");
		BindBtn(m_BtnBack, "back");
		BindBtn(m_BtnPrevPage, "page_prev");
		BindBtn(m_BtnNextPage, "page_next");
		
		if (m_BtnBack)
			GetGame().GetWorkspace().SetFocusedWidget(m_BtnBack);
	}
	
	void BindBtn(ButtonWidget btn, string action)
	{
		if (!btn) return;
		OrderDetailHandler h = new OrderDetailHandler();
		h.m_Menu = this;
		h.m_Action = action;
		btn.AddHandler(h);
		JobFocusHandler.Attach(btn);
	}
	
	void SetVisible(ButtonWidget btn, bool visible)
	{
		if (!btn) return;
		btn.SetVisible(visible);
		btn.SetEnabled(visible);
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuClose()
	{
		if (s_Instance == this)
			s_Instance = null;
		super.OnMenuClose();
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuUpdate(float tDelta)
	{
		super.OnMenuUpdate(tDelta);
		if (GetGame().GetInputManager().GetActionValue("MenuBack") > 0.5)
			CloseMenuInternal();
	}
	
	//------------------------------------------------------------------------------------------------
	void BuildTexts()
	{
		if (m_TitleText)
			m_TitleText.SetText(string.Format("Bon de commande #%1", s_OrderId.ToString()));
		
		string statusLabel;
		switch (s_Status)
		{
			case 0: statusLabel = "EN ATTENTE"; break;
			case 1: statusLabel = "VALIDE"; break;
			case 2: statusLabel = "REFUSE"; break;
			default: statusLabel = "INCONNU";
		}
		
		if (m_HeaderText)
		{
			string h = string.Format("Auteur     : %1\n", s_AuthorName);
			h = h + string.Format("Statut     : %1\n", statusLabel);
			h = h + string.Format("Prix demande : %1 capsules", s_ProposedPrice.ToString());
			if (s_Status == 1)
				h = h + string.Format("\nPrix paye  : %1 capsules", s_FinalPrice.ToString());
			if (s_Status == 2)
			{
				if (s_ItemsRecovered)
					h = h + "\nItems      : recuperes";
				else
					h = h + "\nItems      : a recuperer";
			}
			m_HeaderText.SetText(h);
		}
		
		if (m_ItemsText)
		{
			int totalItems = s_ItemNames.Count();
			int totalPages = 1;
			if (totalItems > 0)
				totalPages = (totalItems + ITEMS_PER_PAGE - 1) / ITEMS_PER_PAGE;
			if (m_CurrentPage < 0) m_CurrentPage = 0;
			if (m_CurrentPage >= totalPages) m_CurrentPage = totalPages - 1;
			
			int pageStart = m_CurrentPage * ITEMS_PER_PAGE;
			int pageEnd = pageStart + ITEMS_PER_PAGE;
			if (pageEnd > totalItems) pageEnd = totalItems;
			
			string items = string.Format("Items (%1 au total) :\n", totalItems.ToString());
			for (int i = pageStart; i < pageEnd; i++)
				items = items + " - " + s_ItemNames.Get(i) + "\n";
			m_ItemsText.SetText(items);
			
			UpdatePagination(totalPages);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Met a jour l affichage des boutons Precedent/Suivant + label "Page X / Y"
	//------------------------------------------------------------------------------------------------
	void UpdatePagination(int totalPages)
	{
		bool needPagination = totalPages > 1;
		
		if (m_BtnPrevPage)
		{
			m_BtnPrevPage.SetVisible(needPagination);
			m_BtnPrevPage.SetEnabled(m_CurrentPage > 0);
			if (m_CurrentPage > 0)
				m_BtnPrevPage.SetColor(Color.FromRGBA(46, 128, 56, 255));
			else
				m_BtnPrevPage.SetColor(Color.FromRGBA(89, 89, 102, 255));
		}
		if (m_BtnNextPage)
		{
			m_BtnNextPage.SetVisible(needPagination);
			m_BtnNextPage.SetEnabled(m_CurrentPage < totalPages - 1);
			if (m_CurrentPage < totalPages - 1)
				m_BtnNextPage.SetColor(Color.FromRGBA(46, 128, 56, 255));
			else
				m_BtnNextPage.SetColor(Color.FromRGBA(89, 89, 102, 255));
		}
		if (m_PageLabel)
		{
			m_PageLabel.SetVisible(needPagination);
			if (needPagination)
				m_PageLabel.SetText(string.Format("Page %1 / %2", (m_CurrentPage + 1).ToString(), totalPages.ToString()));
			else
				m_PageLabel.SetText("");
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void GoToNextPage()
	{
		int totalItems = s_ItemNames.Count();
		int totalPages = 1;
		if (totalItems > 0)
			totalPages = (totalItems + ITEMS_PER_PAGE - 1) / ITEMS_PER_PAGE;
		if (m_CurrentPage < totalPages - 1)
		{
			m_CurrentPage = m_CurrentPage + 1;
			BuildTexts();
		}
	}
	
	void GoToPrevPage()
	{
		if (m_CurrentPage > 0)
		{
			m_CurrentPage = m_CurrentPage - 1;
			BuildTexts();
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void OnAction(string action)
	{
		if (action == "back")
		{
			CloseMenuInternal();
			return;
		}
		if (action == "page_prev")
		{
			GoToPrevPage();
			return;
		}
		if (action == "page_next")
		{
			GoToNextPage();
			return;
		}
		
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		
		if (action == "accept")
		{
			int finalPrice = s_ProposedPrice;
			if (m_FinalPriceInput)
				finalPrice = m_FinalPriceInput.GetText().ToInt();
			if (finalPrice <= 0)
				return;
			jpc.ClientAskAcceptOrder(s_OrderId, finalPrice);
			CloseMenuInternal();
			return;
		}
		if (action == "refuse")
		{
			jpc.ClientAskRefuseOrder(s_OrderId);
			CloseMenuInternal();
			return;
		}
		if (action == "recover")
		{
			if (!s_CanRecover)
				return;  // bouton grise = pas d action
			jpc.ClientAskRecoverItems(s_OrderId);
			CloseMenuInternal();
			return;
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void CloseMenuInternal()
	{
		GetGame().GetMenuManager().CloseMenu(this);
	}
	
	static JobCompanyOrderDetailMenu GetOpenMenu() { return s_Instance; }
}

//------------------------------------------------------------------------------------------------
class OrderDetailHandler : ScriptedWidgetEventHandler
{
	JobCompanyOrderDetailMenu m_Menu;
	string m_Action;
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.OnAction(m_Action);
		return true;
	}
	override bool OnMouseButtonDown(Widget w, int x, int y, int button)
	{
		if (m_Menu) m_Menu.OnAction(m_Action);
		return true;
	}
}
