//------------------------------------------------------------------------------------------------
// JobQuestMenu.c
// Menu des quetes disponibles pour le metier. Ouvert depuis JobActionMenu.
// Affiche:
//  - Section "Quete active" en haut avec bouton Abandonner (si une quete est en cours)
//  - Liste des quetes disponibles pour le metier avec bouton Accepter
//------------------------------------------------------------------------------------------------

class JobQuestMenu : ChimeraMenuBase
{
	const string LAYOUT_PATH = "{3D60D94789482441}UI/layouts/JobQuestMenu.layout";
	const string ENTRY_LAYOUT_PATH = "{0430C0C0D18141EB}UI/layouts/JobQuestEntry.layout";
	
	Widget m_RootWidget;
	Widget m_QuestsContainer;
	TextWidget m_TitleText;
	TextWidget m_ActiveQuestLabel;
	ButtonWidget m_AbandonButton;
	ButtonWidget m_CloseButton;
	
	EJobType m_Job;
	
	// Cache des boutons d'acceptation (button -> questType int)
	ref map<ButtonWidget, int> m_ButtonToQuestType = new map<ButtonWidget, int>();
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuOpen()
	{
		super.OnMenuOpen();
		m_RootWidget = GetRootWidget();
		if (!m_RootWidget)
			return;
		
		m_QuestsContainer = m_RootWidget.FindAnyWidget("QuestsContainer");
		m_TitleText = TextWidget.Cast(m_RootWidget.FindAnyWidget("TitleText"));
		m_ActiveQuestLabel = TextWidget.Cast(m_RootWidget.FindAnyWidget("ActiveQuestLabel"));
		m_AbandonButton = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("AbandonButton"));
		m_CloseButton = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("CloseButton"));
		
		if (m_CloseButton)
		{
			QuestClickHandler closeCh = new QuestClickHandler();
			closeCh.m_Menu = this;
			closeCh.m_Mode = "close";
			m_CloseButton.AddHandler(closeCh);
			JobFocusHandler.Attach(m_CloseButton);
		}
		
		ButtonWidget floatingClose = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("FloatingCloseButton"));
		if (floatingClose)
		{
			QuestClickHandler floatCh = new QuestClickHandler();
			floatCh.m_Menu = this;
			floatCh.m_Mode = "close";
			floatingClose.AddHandler(floatCh);
			JobFocusHandler.Attach(floatingClose);
		}
		
		if (m_AbandonButton)
		{
			QuestClickHandler abandonCh = new QuestClickHandler();
			abandonCh.m_Menu = this;
			abandonCh.m_Mode = "abandon";
			m_AbandonButton.AddHandler(abandonCh);
			JobFocusHandler.Attach(m_AbandonButton);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuUpdate(float tDelta)
	{
		super.OnMenuUpdate(tDelta);
		if (GetGame().GetInputManager().GetActionValue("MenuBack") > 0.5)
		{
			CloseMenuInternal();
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void Initialize(EJobType job)
	{
		m_Job = job;
		
		if (m_TitleText)
			m_TitleText.SetText(string.Format("Quetes - %1", JobData.GetJobLabel(job)));
		
		UpdateActiveQuestSection();
		BuildQuestList();
	}
	
	//------------------------------------------------------------------------------------------------
	// Met a jour la section "Quete active" + visibilite du bouton Abandonner
	//------------------------------------------------------------------------------------------------
	void UpdateActiveQuestSection()
	{
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc)
			return;
		
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc)
			return;
		
		int activeQuestInt = jpc.GetClientActiveQuestType();
		bool hasActive = (activeQuestInt != 0);
		
		if (m_AbandonButton)
		{
			m_AbandonButton.SetEnabled(hasActive);
			m_AbandonButton.SetVisible(hasActive);
		}
		
		if (m_ActiveQuestLabel)
		{
			if (hasActive)
			{
				EQuestType qt = activeQuestInt;
				JobQuest q = JobQuestData.GetQuest(qt);
				if (q)
					m_ActiveQuestLabel.SetText(string.Format("Quete active: %1", q.m_Label));
				else
					m_ActiveQuestLabel.SetText("Quete active en cours");
			}
			else
			{
				m_ActiveQuestLabel.SetText("Aucune quete active - Choisissez une quete ci-dessous");
			}
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void BuildQuestList()
	{
		if (!m_QuestsContainer)
			return;
		
		array<EQuestType> quests = JobQuestData.GetQuestsForJob(m_Job);
		if (!quests || quests.IsEmpty())
			return;
		
		WorkspaceWidget ws = GetGame().GetWorkspace();
		const int ENTRY_HEIGHT = 120;
		const int ENTRY_PADDING = 10;
		const int ENTRY_WIDTH = 660;
		
		for (int i = 0; i < quests.Count(); i++)
		{
			EQuestType questType = quests.Get(i);
			JobQuest q = JobQuestData.GetQuest(questType);
			if (!q)
				continue;
			
			Widget entry = ws.CreateWidgets(ENTRY_LAYOUT_PATH, m_QuestsContainer);
			if (!entry)
				continue;
			
			FrameSlot.SetPos(entry, 0, i * (ENTRY_HEIGHT + ENTRY_PADDING));
			FrameSlot.SetSize(entry, ENTRY_WIDTH, ENTRY_HEIGHT);
			
			TextWidget nameW = TextWidget.Cast(entry.FindAnyWidget("QuestName"));
			if (nameW)
				nameW.SetText(q.m_Label);
			
			// Description peut etre RichTextWidget ou TextWidget
			Widget descRoot = entry.FindAnyWidget("QuestDescription");
			string descText = string.Format("%1\nRecompense: %2-%3 capsules",
				q.m_Description, q.m_RewardMin, q.m_RewardMax);
			
			RichTextWidget richDesc = RichTextWidget.Cast(descRoot);
			if (richDesc)
			{
				richDesc.SetText(descText);
			}
			else
			{
				TextWidget simpleDesc = TextWidget.Cast(descRoot);
				if (simpleDesc)
					simpleDesc.SetText(descText);
			}
			
			ButtonWidget btn = ButtonWidget.Cast(entry.FindAnyWidget("AcceptButton"));
			if (btn)
			{
				m_ButtonToQuestType.Set(btn, questType);
				QuestClickHandler ch = new QuestClickHandler();
				ch.m_Menu = this;
				ch.m_Mode = "accept";
				btn.AddHandler(ch);
				JobFocusHandler.Attach(btn);
			}
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void OnAcceptClicked(ButtonWidget btn)
	{
		int questTypeInt;
		if (!m_ButtonToQuestType.Find(btn, questTypeInt))
			return;
		
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc)
			return;
		
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc)
			return;
		
		jpc.ClientAskAcceptQuest(questTypeInt);
		CloseMenuInternal();
	}
	
	//------------------------------------------------------------------------------------------------
	void OnAbandonClicked()
	{
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc)
			return;
		
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc)
			return;
		
		jpc.ClientAskAbandonQuest();
		CloseMenuInternal();
	}
	
	//------------------------------------------------------------------------------------------------
	void CloseMenuInternal()
	{
		GetGame().GetMenuManager().CloseMenu(this);
	}
}

//------------------------------------------------------------------------------------------------
class QuestClickHandler : ScriptedWidgetEventHandler
{
	JobQuestMenu m_Menu;
	string m_Mode;  // "close" | "accept" | "abandon"
	
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (!m_Menu)
			return false;
		
		if (m_Mode == "close")
		{
			m_Menu.CloseMenuInternal();
			return true;
		}
		
		if (m_Mode == "abandon")
		{
			m_Menu.OnAbandonClicked();
			return true;
		}
		
		if (m_Mode == "accept")
		{
			ButtonWidget btn = ButtonWidget.Cast(w);
			if (btn)
				m_Menu.OnAcceptClicked(btn);
			return true;
		}
		
		return false;
	}
}
