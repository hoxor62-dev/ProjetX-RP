//------------------------------------------------------------------------------------------------
// JobPochonNpcShopAction.c
// UserAction "Acheter marchandises" a placer sur le PNJ vendeur.
// Verifie que le joueur est VOYOU ou membre d un GANG cote client (verif finale cote serveur au clic Acheter).
// Ouvre le menu JobPochonShopMenu.
//------------------------------------------------------------------------------------------------

class JobPochonNpcShopAction : ScriptedUserAction
{
	override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
	{
		PlayerController pc = PlayerController.Cast(GetGame().GetPlayerController());
		if (!pc) return;
		if (pUserEntity != pc.GetControlledEntity()) return;
		
		// Ouvre le menu
		GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.JobPochonShopMenu);
	}
	
	override bool CanBePerformedScript(IEntity user)
	{
		return true;
	}
	
	override bool CanBeShownScript(IEntity user)
	{
		return true;
	}
}
