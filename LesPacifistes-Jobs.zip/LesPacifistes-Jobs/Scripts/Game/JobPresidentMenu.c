//------------------------------------------------------------------------------------------------
// JobPresidentMenu.c
// Menu d'interaction avec le PNJ President.
// Le President controle :
//  1) Le taux de taxe LeBonPoint (5% defaut, modifiable 0-20%)
//  2) Le taux de taxe entreprise (10% defaut, modifiable 0-50%)
//  3) La cagnotte municipale (peut retirer 10% par retrait, cooldown 1h)
//
// Securite : tous les controles sont serveur-side (le menu envoie une RPC, le serveur verifie
// que le joueur a bien le metier PRESIDENT avant d appliquer).
//------------------------------------------------------------------------------------------------

class JobPresidentMenu : ChimeraMenuBase
{
	Widget m_RootWidget;
	
	// Section LeBonPoint
	TextWidget m_LbpTaxText;
	ButtonWidget m_LbpMinus5;
	ButtonWidget m_LbpMinus1;
	ButtonWidget m_LbpPlus1;
	ButtonWidget m_LbpPlus5;
	
	// Section Entreprise
	TextWidget m_CompanyTaxText;
	ButtonWidget m_CompanyMinus5;
	ButtonWidget m_CompanyMinus1;
	ButtonWidget m_CompanyPlus1;
	ButtonWidget m_CompanyPlus5;
	
	// Section Cagnotte
	TextWidget m_TreasuryText;
	ButtonWidget m_WithdrawButton;
	TextWidget m_WithdrawCooldownText;
	
	ButtonWidget m_CloseButton;
	
	// Etat client (pre-rempli via RPC quand le menu s ouvre)
	int m_CurrentLbpTax = 5;
	int m_CurrentCompanyTax = 10;
	int m_CurrentTreasury = 0;
	int m_WithdrawCooldownRemaining = 0;
	
	// Instance statique pour acces depuis JobPlayerComponent (RPC server -> client)
	static JobPresidentMenu s_Instance;
	
	static JobPresidentMenu GetOpenMenu()
	{
		return s_Instance;
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuOpen()
	{
		super.OnMenuOpen();
		s_Instance = this;
		JobFocusHandler.ClearRegistry();
		m_RootWidget = GetRootWidget();
		if (!m_RootWidget)
			return;
		
		// LeBonPoint
		m_LbpTaxText = TextWidget.Cast(m_RootWidget.FindAnyWidget("LbpTaxText"));
		m_LbpMinus5 = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("LbpMinus5"));
		m_LbpMinus1 = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("LbpMinus1"));
		m_LbpPlus1 = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("LbpPlus1"));
		m_LbpPlus5 = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("LbpPlus5"));
		
		// Entreprise
		m_CompanyTaxText = TextWidget.Cast(m_RootWidget.FindAnyWidget("CompanyTaxText"));
		m_CompanyMinus5 = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("CompanyMinus5"));
		m_CompanyMinus1 = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("CompanyMinus1"));
		m_CompanyPlus1 = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("CompanyPlus1"));
		m_CompanyPlus5 = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("CompanyPlus5"));
		
		// Cagnotte
		m_TreasuryText = TextWidget.Cast(m_RootWidget.FindAnyWidget("TreasuryText"));
		m_WithdrawButton = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("WithdrawButton"));
		m_WithdrawCooldownText = TextWidget.Cast(m_RootWidget.FindAnyWidget("WithdrawCooldownText"));
		
		m_CloseButton = ButtonWidget.Cast(m_RootWidget.FindAnyWidget("CloseButton"));
		
		// Handlers LBP
		AttachHandler(m_LbpMinus5, "lbp", -5);
		AttachHandler(m_LbpMinus1, "lbp", -1);
		AttachHandler(m_LbpPlus1, "lbp", 1);
		AttachHandler(m_LbpPlus5, "lbp", 5);
		
		// Handlers Entreprise
		AttachHandler(m_CompanyMinus5, "company", -5);
		AttachHandler(m_CompanyMinus1, "company", -1);
		AttachHandler(m_CompanyPlus1, "company", 1);
		AttachHandler(m_CompanyPlus5, "company", 5);
		
		// Handler Retrait
		AttachHandler(m_WithdrawButton, "withdraw", 0);
		
		// Handler Close
		AttachHandler(m_CloseButton, "close", 0);
		
		// Focus initial : premier bouton interactif
		if (m_LbpMinus5)
			GetGame().GetWorkspace().SetFocusedWidget(m_LbpMinus5);
		else if (m_CloseButton)
			GetGame().GetWorkspace().SetFocusedWidget(m_CloseButton);
		
		// Demande l etat actuel au serveur
		RequestRefresh();
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuUpdate(float tDelta)
	{
		super.OnMenuUpdate(tDelta);
		if (GetGame().GetInputManager().GetActionValue("MenuBack") > 0.5)
			CloseMenuInternal();
	}
	
	//------------------------------------------------------------------------------------------------
	override void OnMenuClose()
	{
		if (s_Instance == this)
			s_Instance = null;
		super.OnMenuClose();
	}
	
	//------------------------------------------------------------------------------------------------
	void AttachHandler(ButtonWidget btn, string action, int delta)
	{
		if (!btn) return;
		PresidentMenuHandler h = new PresidentMenuHandler();
		h.m_Menu = this;
		h.m_Action = action;
		h.m_Delta = delta;
		btn.AddHandler(h);
		JobFocusHandler.Attach(btn);
	}
	
	//------------------------------------------------------------------------------------------------
	// Demande au serveur les valeurs actuelles (LBP tax, Company tax, Treasury, Cooldown)
	//------------------------------------------------------------------------------------------------
	void RequestRefresh()
	{
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		jpc.ClientAskPresidentInfo();
	}
	
	//------------------------------------------------------------------------------------------------
	// Mise a jour cote client - appelee par RPC quand le serveur push les donnees
	//------------------------------------------------------------------------------------------------
	void UpdateDisplay(int lbpTax, int companyTax, int treasury, int cooldownRemaining)
	{
		m_CurrentLbpTax = lbpTax;
		m_CurrentCompanyTax = companyTax;
		m_CurrentTreasury = treasury;
		m_WithdrawCooldownRemaining = cooldownRemaining;
		
		if (m_LbpTaxText)
			m_LbpTaxText.SetText(string.Format("Taxe LeBonPoint : %1%%", lbpTax.ToString()));
		if (m_CompanyTaxText)
			m_CompanyTaxText.SetText(string.Format("Taxe Entreprises : %1%%", companyTax.ToString()));
		if (m_TreasuryText)
			m_TreasuryText.SetText(string.Format("Cagnotte municipale : %1 capsules", treasury.ToString()));
		
		// Bouton retrait : montant retirable = 10% du tresor, sauf si cooldown
		int withdrawableAmount = treasury / 10;
		if (m_WithdrawButton)
		{
			if (cooldownRemaining > 0)
			{
				m_WithdrawButton.SetEnabled(false);
				if (m_WithdrawCooldownText)
				{
					int mins = cooldownRemaining / 60;
					int secs = cooldownRemaining - mins * 60;
					m_WithdrawCooldownText.SetText(string.Format("Cooldown : %1 min %2 s",
						mins.ToString(), secs.ToString()));
				}
			}
			else if (withdrawableAmount <= 0)
			{
				m_WithdrawButton.SetEnabled(false);
				if (m_WithdrawCooldownText)
					m_WithdrawCooldownText.SetText("Cagnotte vide");
			}
			else
			{
				m_WithdrawButton.SetEnabled(true);
				if (m_WithdrawCooldownText)
					m_WithdrawCooldownText.SetText(string.Format("Retirer 10%% = %1 capsules",
						withdrawableAmount.ToString()));
			}
		}
	}
	
	//------------------------------------------------------------------------------------------------
	// Clic sur un bouton - envoie au serveur via RPC
	//------------------------------------------------------------------------------------------------
	void OnButtonClicked(string action, int delta)
	{
		if (action == "close")
		{
			CloseMenuInternal();
			return;
		}
		
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc) return;
		
		if (action == "lbp")
		{
			int newTax = m_CurrentLbpTax + delta;
			jpc.ClientAskPresidentSetLbpTax(newTax);
			// Le serveur va renvoyer un push pour rafraichir l affichage
			GetGame().GetCallqueue().CallLater(RequestRefresh, 300, false);
		}
		else if (action == "company")
		{
			int newTax = m_CurrentCompanyTax + delta;
			jpc.ClientAskPresidentSetCompanyTax(newTax);
			GetGame().GetCallqueue().CallLater(RequestRefresh, 300, false);
		}
		else if (action == "withdraw")
		{
			jpc.ClientAskPresidentWithdraw();
			GetGame().GetCallqueue().CallLater(RequestRefresh, 500, false);
		}
	}
	
	//------------------------------------------------------------------------------------------------
	void CloseMenuInternal()
	{
		GetGame().GetMenuManager().CloseMenu(this);
	}
}

//------------------------------------------------------------------------------------------------
class PresidentMenuHandler : ScriptedWidgetEventHandler
{
	JobPresidentMenu m_Menu;
	string m_Action;
	int m_Delta;
	
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (m_Menu)
			m_Menu.OnButtonClicked(m_Action, m_Delta);
		return true;
	}
}
