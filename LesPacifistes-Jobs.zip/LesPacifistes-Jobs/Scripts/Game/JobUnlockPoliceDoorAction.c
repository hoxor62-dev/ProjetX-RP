//------------------------------------------------------------------------------------------------
// JobUnlockPoliceDoorAction.c
// Action UserAction "Deverrouiller" sur les portes du batiment de police.
// Symetrique de JobLockPoliceDoorAction : visible uniquement si porte deja VERROUILLEE
// et que le joueur local est POLICIER ou MILITAIRE.
//------------------------------------------------------------------------------------------------

class JobUnlockPoliceDoorAction : ScriptedUserAction
{
	//------------------------------------------------------------------------------------------------
	override bool CanBeShownScript(IEntity user)
	{
		if (!user)
			return false;
		
		// Verifie le metier
		JobCharacterJobComponent localJobComp = JobCharacterJobComponent.Cast(
			user.FindComponent(JobCharacterJobComponent));
		if (!localJobComp)
			return false;
		EJobType localJob = localJobComp.GetJob();
		if (localJob != EJobType.POLICIER && localJob != EJobType.MILITAIRE)
			return false;
		
		// Visible UNIQUEMENT si verrouillee
		IEntity door = GetOwner();
		if (!door)
			return false;
		JobPoliceDoorComponent doorComp = JobPoliceDoorComponent.Cast(
			door.FindComponent(JobPoliceDoorComponent));
		if (!doorComp)
			return false;
		return doorComp.IsLocked();
	}
	
	//------------------------------------------------------------------------------------------------
	override bool CanBePerformedScript(IEntity user)
	{
		return CanBeShownScript(user);
	}
	
	//------------------------------------------------------------------------------------------------
	override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
	{
		if (!pOwnerEntity)
			return;
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc)
			return;
		JobPlayerComponent jpc = JobPlayerComponent.Cast(pc.FindComponent(JobPlayerComponent));
		if (!jpc)
			return;
		RplComponent rpl = RplComponent.Cast(pOwnerEntity.FindComponent(RplComponent));
		if (!rpl)
			return;
		jpc.ClientAskTogglePoliceDoor(rpl.Id(), false);  // false = unlock
	}
	
	//------------------------------------------------------------------------------------------------
	override bool GetActionNameScript(out string outName)
	{
		outName = "Deverrouiller la porte";
		return true;
	}
}
