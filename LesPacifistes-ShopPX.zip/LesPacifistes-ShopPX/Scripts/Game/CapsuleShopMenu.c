/**
 * CapsuleShopMenu.c
 * 
 * Menu shop base sur MenuBase - la seule approche officielle Enfusion
 * pour recevoir les evenements souris (OnClick, OnMouseButtonDown).
 * 
 * Ouverture : GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.CapsuleShopMenu)
 * MenuBase gere automatiquement : modal, focus, inputs souris, fermeture ESC.
 */

class CapsuleShopMenuBase : ChimeraMenuBase
{
	// --- Donnees passees avant ouverture -------------------------------------
	static EVendorType       s_eType;
	static IEntity           s_pPlayer;
	static string            s_sPlayerId;
	static VendorNPCComponent s_Vendor;

	// --- Widgets -------------------------------------------------------------
	private TextWidget  m_wTitle;
	private TextWidget  m_wCapsules;
	private TextWidget  m_wFeedback;
	private Widget      m_wBuyList;
	private Widget      m_wSellList;

	// --- Donnees -------------------------------------------------------------
	private ref array<ref CapsuleItemDef> m_aBuyItems;
	private ref array<IEntity>            m_aSellItems;
	private ref array<Widget>             m_aBuyWidgets  = new array<Widget>();
	private ref array<Widget>             m_aSellWidgets = new array<Widget>();
	private ref array<ref CapsuleShopMenuHandler> m_aHandlers = new array<ref CapsuleShopMenuHandler>();
	private ref CapsuleShopKeyHandler m_KeyHandler;

	private int   m_iSelected      = 0;
	private int   m_iCategory      = 0;  // 0=Fusils 1=MG 2=Lanceurs 3=Mun556 4=Mun545 5=Mun762 6=Optiques 7=Accessoires
	private float m_fBuyCooldown   = 0.0;
	private float m_fFeedbackTimer = 0.0;

	// Navigation manette
	private bool  m_bInSellBlock   = false; // false = bloc achat, true = bloc vente
	private int   m_iBuySelected   = 0;     // item selectionne dans le bloc achat
	private int   m_iSellSelected  = 0;     // item selectionne dans le bloc vente
	private float m_fNavCooldown   = 0.0;   // anti-repeat navigation

	// Tooltip survol
	private Widget     m_wTooltip        = null;
	private TextWidget m_wTooltipName    = null;
	private TextWidget m_wTooltipType    = null;
	private TextWidget m_wTooltipBuy     = null;
	private TextWidget m_wTooltipSell    = null;

	// Labels categories affiches dans le menu
	static ref array<string> ARMS_CATEGORY_NAMES     = {"Fusils", "Mitrail.", "Lanceurs", "Mun.556", "Mun.545", "Mun.762", "Optiques", "Access."};
	static ref array<string> VEHICLE_CATEGORY_NAMES  = {"Mi-8", "UH-1H", "Roues US", "Roues Sov.", "Civils", "DLC"};
	static ref array<string> CLOTHING_CATEGORY_NAMES = {"Vestes", "Pantalons", "Hauts", "Gilets", "Couvre-chefs", "Sacs"};
	static ref array<string> MEDICAL_CATEGORY_NAMES  = {"Medical"};
	static ref array<string> FOOD_CATEGORY_NAMES     = {"Nourriture", "Eau"};
	static ref array<string> BM_CATEGORY_NAMES       = {"Armes", "Chargeurs", "Optiques", "Accessoires"};

	static const string ITEM_LAYOUT    = "{DEF4E45BE9C12809}UI/Layouts/CapsuleShopItem.layout";
	static const string TOOLTIP_LAYOUT = "UI/Layouts/CapsuleTooltip.layout";
	static const int    ITEM_H      = 38;
	static const int    ITEM_GAP    = 2;

	// --- Ouverture ------------------------------------------------------------
	override void OnMenuOpen()
	{
		super.OnMenuOpen();

		// S'assurer que le catalogue est initialise cote client
		CapsuleConfig.Init();

		Widget root = GetRootWidget();
		if (!root) return;

		// Forcer le focus sur le root pour recevoir OnController
		GetGame().GetWorkspace().SetFocusedWidget(root);

		m_wTitle    = TextWidget.Cast(root.FindAnyWidget("txt_Title"));
		m_wCapsules = TextWidget.Cast(root.FindAnyWidget("txt_Capsules"));
		m_wFeedback = TextWidget.Cast(root.FindAnyWidget("txt_Feedback"));
		m_wBuyList  = root.FindAnyWidget("BuyList");
		m_wSellList = root.FindAnyWidget("SellList");

		if (m_wTitle)
		{
			if (s_eType == EVendorType.VEHICLE)         m_wTitle.SetText("=== MARCHAND DE VEHICULES ===");
			else if (s_eType == EVendorType.CLOTHING)   m_wTitle.SetText("=== MARCHAND DE VETEMENTS ===");
			else if (s_eType == EVendorType.MEDICAL)    m_wTitle.SetText("=== MEDECIN ===");
			else if (s_eType == EVendorType.FOOD)       m_wTitle.SetText("=== EPICERIE ===");
			else if (s_eType == EVendorType.BLACKMARKET) m_wTitle.SetText("=== MARCHE NOIR ===");
			else                                       m_wTitle.SetText("=== MARCHAND D'ARMES ===");
		}

		// Afficher la categorie initiale
		TextWidget catLabel = TextWidget.Cast(root.FindAnyWidget("txt_Category"));
		if (catLabel) catLabel.SetText("[ " + GetCategoryNames()[0] + " ]  (Molette / LB-RB)");

		m_bInSellBlock  = false;
		m_iBuySelected  = 0;
		m_iSellSelected = 0;

		BuildBuyList();
		BuildSellList();
		UpdateCapsules();
		RefreshSelection();
		HighlightSelected();
		CreateTooltip();
	}

	// --- Update ---------------------------------------------------------------
	override void OnMenuUpdate(float tDelta)
	{
		super.OnMenuUpdate(tDelta);

		// Activer le contexte souris UI + notre contexte custom
		GetGame().GetInputManager().ActivateContext("ChimeraMenuContext");

		// Fermer sur Echap
		if (GetGame().GetInputManager().GetActionTriggered("MenuOpen"))
		{
			Close();
			return;
		}

		// Navigation categories : molette souris ET manette LB/RB (MenuLeft/MenuRight)
		if (GetGame().GetInputManager().GetActionTriggered("MenuLeft"))
			CategoryPrev();
		if (GetGame().GetInputManager().GetActionTriggered("MenuRight"))
			CategoryNext();

		// Navigation manette : haut/bas/switch bloc/confirmer
		m_fNavCooldown -= tDelta;
		if (m_fNavCooldown <= 0.0)
		{
			InputManager im = GetGame().GetInputManager();

			// Switcher entre bloc Achat et bloc Vente : MenuBack (B Xbox / Rond PS)
			if (im.GetActionTriggered("MenuBack"))
			{
				m_bInSellBlock = !m_bInSellBlock;
				HighlightSelected();
				m_fNavCooldown = 0.3;
			}

			// Navigation verticale : croix directionnelle / stick (MenuUp/MenuDown)
			// Fonctionne sur PC (clavier) ET console (manette)
			bool goUp   = im.GetActionTriggered("MenuUp");
			bool goDown = im.GetActionTriggered("MenuDown");

			// Fallback analogique stick gauche pour les consoles qui n'envoient pas MenuUp/Down
			float axisY = im.GetActionValue("CharacterMoveForward");
			if (!goUp   && axisY >  0.5) goUp   = true;
			if (!goDown && axisY < -0.5) goDown = true;

			if (goUp)
			{
				if (m_bInSellBlock)
				{
					int count = m_aSellWidgets.Count();
					if (count > 0)
					{
						m_iSellSelected = (m_iSellSelected - 1 + count) % count;
						HighlightSelected();
					}
				}
				else
				{
					int count = m_aBuyWidgets.Count();
					if (count > 0)
					{
						m_iBuySelected = (m_iBuySelected - 1 + count) % count;
						HighlightSelected();
					}
				}
				m_fNavCooldown = 0.15;
			}
			else if (goDown)
			{
				if (m_bInSellBlock)
				{
					int count = m_aSellWidgets.Count();
					if (count > 0)
					{
						m_iSellSelected = (m_iSellSelected + 1) % count;
						HighlightSelected();
					}
				}
				else
				{
					int count = m_aBuyWidgets.Count();
					if (count > 0)
					{
						m_iBuySelected = (m_iBuySelected + 1) % count;
						HighlightSelected();
					}
				}
				m_fNavCooldown = 0.15;
			}

			// Confirmer achat/vente : MenuSelect (A Xbox / Croix PS)
			if (im.GetActionTriggered("MenuSelect"))
			{
				if (m_bInSellBlock)
					OnSellItemClicked(m_iSellSelected);
				else
					OnBuyItemClicked(m_iBuySelected);
				m_fNavCooldown = 0.4;
			}
		}

		m_fBuyCooldown -= tDelta;

		if (m_fFeedbackTimer > 0.0)
		{
			m_fFeedbackTimer -= tDelta;
			if (m_fFeedbackTimer <= 0.0 && m_wFeedback)
				m_wFeedback.SetText("");
		}

		UpdateCapsules();
	}

	// --- Focus ---------------------------------------------------------------
	override void OnMenuFocusGained()
	{
		super.OnMenuFocusGained();
		// Attacher le handler molette/boutons sur le root
		Widget root = GetRootWidget();
		if (root)
		{
			m_KeyHandler = new CapsuleShopKeyHandler();
			m_KeyHandler.Init(this);
			root.AddHandler(m_KeyHandler);
		}
	}

	override void OnMenuFocusLost()
	{
		super.OnMenuFocusLost();
	}

	// --- Construction des listes ----------------------------------------------
	private void BuildBuyList()
	{
		if (!m_wBuyList) return;
		m_aBuyItems = GetCatalog();
		WorkspaceWidget ws = GetGame().GetWorkspace();
		if (!ws) return;

		// Recreer le tooltip s'il n'existe plus
		if (!m_wTooltip) CreateTooltip();

		for (int i = 0; i < m_aBuyItems.Count() && i < 25; i++)
		{
			CapsuleItemDef item = m_aBuyItems[i];
			Widget row = ws.CreateWidgets(ITEM_LAYOUT, m_wBuyList);
			if (!row) continue;

			FrameSlot.SetPos(row, 0, i * (ITEM_H + ITEM_GAP));
			FrameSlot.SetSize(row, 488, ITEM_H);

			TextWidget idx   = TextWidget.Cast(row.FindAnyWidget("txt_Index"));
			TextWidget name  = TextWidget.Cast(row.FindAnyWidget("txt_Name"));
			TextWidget price = TextWidget.Cast(row.FindAnyWidget("txt_Price"));

			if (idx)   idx.SetText((i + 1).ToString() + ".");
			if (name)  name.SetText(item.m_sDisplayName);
			if (price) price.SetText(item.m_iBuyPrice.ToString() + " caps");

			// Handler sur chaque item - OnClick natif MenuBase
			CapsuleShopMenuHandler h = new CapsuleShopMenuHandler();
			h.Init(this, i, true);
			row.AddHandler(h);
			m_aHandlers.Insert(h);

			// Propager les events souris aux enfants
			row.ClearFlags(WidgetFlags.IGNORE_CURSOR);
			m_aBuyWidgets.Insert(row);
		}
	}

	private void BuildSellList()
	{
		if (!m_wSellList || !s_pPlayer) return;

		m_aSellItems = new array<IEntity>();
		SCR_InventoryStorageManagerComponent inv =
			SCR_InventoryStorageManagerComponent.Cast(
				s_pPlayer.FindComponent(SCR_InventoryStorageManagerComponent));
		if (inv) inv.GetItems(m_aSellItems);

		WorkspaceWidget ws = GetGame().GetWorkspace();
		if (!ws || m_aSellItems.IsEmpty()) return;

		for (int i = 0; i < m_aSellItems.Count() && i < 25; i++)
		{
			IEntity item = m_aSellItems[i];
			Widget row = ws.CreateWidgets(ITEM_LAYOUT, m_wSellList);
			if (!row) continue;

			FrameSlot.SetPos(row, 0, i * (ITEM_H + ITEM_GAP));
			FrameSlot.SetSize(row, 488, ITEM_H);

			TextWidget idx     = TextWidget.Cast(row.FindAnyWidget("txt_Index"));
			TextWidget name    = TextWidget.Cast(row.FindAnyWidget("txt_Name"));
			TextWidget price_w = TextWidget.Cast(row.FindAnyWidget("txt_Price"));

			if (idx)     idx.SetText("S" + (i + 1).ToString() + ".");
			if (name)    name.SetText(GetItemName(item));
			string resName2 = GetItemResourceName(item);
			int sellPriceDisplay = GetSellPrice(resName2);
			if (price_w) price_w.SetText("+" + sellPriceDisplay.ToString() + " caps");

			CapsuleShopMenuHandler hs = new CapsuleShopMenuHandler();
			hs.Init(this, i, false);
			row.AddHandler(hs);
			m_aHandlers.Insert(hs);

			row.ClearFlags(WidgetFlags.IGNORE_CURSOR);
			m_aSellWidgets.Insert(row);
		}
	}

	// --- Callbacks handler ----------------------------------------------------
	void OnBuyItemClicked(int index)
	{
		if (m_fBuyCooldown > 0.0) return;
		if (!m_aBuyItems || index >= m_aBuyItems.Count()) return;

		m_fBuyCooldown = 0.5;
		m_iSelected = index;
		RefreshSelection();
		RequestBuy(m_aBuyItems[index]);
	}

	void OnSellItemClicked(int index)
	{
		if (m_fBuyCooldown > 0.0) return;
		if (!m_aSellItems || index >= m_aSellItems.Count()) return;

		m_fBuyCooldown = 0.5;
		RequestSell(m_aSellItems[index], index);
	}

	void OnBuyItemHover(int index)
	{
		m_iSelected = index;
		RefreshSelection();
	}

	// --- Selection visuelle ---------------------------------------------------
	private void RefreshSelection()
	{
		for (int i = 0; i < m_aBuyWidgets.Count(); i++)
		{
			Widget row = m_aBuyWidgets[i];
			if (!row) continue;

			bool sel = (i == m_iSelected);

			Widget border = row.FindAnyWidget("SelectBorder");
			if (border) border.SetVisible(sel);

			Widget selbg = row.FindAnyWidget("SelectBg");
			if (selbg) selbg.SetVisible(sel);

			TextWidget name = TextWidget.Cast(row.FindAnyWidget("txt_Name"));
			if (name)
			{
				Color c;
				if (sel)
					c = Color.FromRGBA(255, 240, 150, 255);
				else
					c = Color.FromRGBA(220, 220, 220, 255);
				name.SetColor(c);
			}
		}
	}

	// --- Achat / Vente --------------------------------------------------------
	private void RequestBuy(CapsuleItemDef item)
	{
		int caps = GetLocalCapsules();
		if (caps < item.m_iBuyPrice)
		{
			ShowFeedback("Capsules insuffisantes! (" + caps.ToString() + "/" + item.m_iBuyPrice.ToString() + ")", false);
			return;
		}

		VendorNPCComponent vendor = FindVendor();
		if (!vendor) { ShowFeedback("Erreur: vendeur introuvable.", false); return; }

		CapsulePlayerComponent playerComp = FindPlayerComp();
		if (!playerComp) { ShowFeedback("Erreur: composant joueur introuvable.", false); return; }

		if (s_eType == EVendorType.VEHICLE)
			playerComp.RequestVehicleBuy(item.m_sResourceName, item.m_iBuyPrice);
		else
			playerComp.RequestBuy(item.m_sResourceName, item.m_iBuyPrice);

		ShowFeedback("Achat: " + item.m_sDisplayName + " (-" + item.m_iBuyPrice.ToString() + " caps)", true);
	}

	// Cherche le prix de vente dans le catalogue armes (3-6 caps selon l'item)
	private int GetSellPrice(string resourceName)
	{
		for (int i = 0; i < CapsuleConfig.WEAPONS_RIFLES.Count(); i++)
		{
			CapsuleItemDef def = CapsuleConfig.WEAPONS_RIFLES[i];
			if (def && def.m_sResourceName == resourceName && def.m_iSellPrice > 0)
				return def.m_iSellPrice;
		}
		for (int i = 0; i < CapsuleConfig.WEAPONS_MG.Count(); i++)
		{
			CapsuleItemDef def = CapsuleConfig.WEAPONS_MG[i];
			if (def && def.m_sResourceName == resourceName && def.m_iSellPrice > 0)
				return def.m_iSellPrice;
		}
		for (int i = 0; i < CapsuleConfig.WEAPONS_LAUNCHERS.Count(); i++)
		{
			CapsuleItemDef def = CapsuleConfig.WEAPONS_LAUNCHERS[i];
			if (def && def.m_sResourceName == resourceName && def.m_iSellPrice > 0)
				return def.m_iSellPrice;
		}
		for (int i = 0; i < CapsuleConfig.OPTICS.Count(); i++)
		{
			CapsuleItemDef def = CapsuleConfig.OPTICS[i];
			if (def && def.m_sResourceName == resourceName && def.m_iSellPrice > 0)
				return def.m_iSellPrice;
		}
		for (int i = 0; i < CapsuleConfig.ATTACHMENTS.Count(); i++)
		{
			CapsuleItemDef def = CapsuleConfig.ATTACHMENTS[i];
			if (def && def.m_sResourceName == resourceName && def.m_iSellPrice > 0)
				return def.m_iSellPrice;
		}
		return CapsuleConfig.SELL_PRICE_WEAPON; // fallback minimum 3
	}

	private void RequestSell(IEntity item, int index)
	{
		CapsulePlayerComponent playerComp = FindPlayerComp();
		if (!playerComp) { ShowFeedback("Erreur: composant joueur introuvable.", false); return; }

		string resourceName = GetItemResourceName(item);
		int price = GetSellPrice(resourceName);
		Print("[CapsuleShop] RequestSell -> " + resourceName + " prix=" + price.ToString());
		playerComp.RequestSell(resourceName, price);
		ShowFeedback("Vendu: " + GetItemName(item) + " (+" + price.ToString() + " caps)", true);

		// Retirer le widget vendu et repositionner
		if (index < m_aSellWidgets.Count())
		{
			Widget w = m_aSellWidgets[index];
			if (w) w.RemoveFromHierarchy();
			m_aSellWidgets.Remove(index);
			m_aSellItems.Remove(index);
			for (int i = index; i < m_aSellWidgets.Count(); i++)
			{
				Widget rw = m_aSellWidgets[i];
				if (rw) FrameSlot.SetPos(rw, 0, i * (ITEM_H + ITEM_GAP));
			}
		}
	}

	// --- Utilitaires ---------------------------------------------------------
	private void ShowFeedback(string msg, bool success)
	{
		if (!m_wFeedback) return;
		m_wFeedback.SetText(msg);
		Color c;
		if (success)
			c = Color.FromRGBA(80, 255, 120, 255);
		else
			c = Color.FromRGBA(255, 80, 80, 255);
		m_wFeedback.SetColor(c);
		m_fFeedbackTimer = 3.0;
		Print("[CapsuleShop] " + msg);
	}

	private int GetLocalCapsules()
	{
		// Cote client : lire depuis CapsulePlayerComponent (synchronise par RPC)
		PlayerController pc = GetGame().GetPlayerController();
		if (pc)
		{
			CapsulePlayerComponent comp = CapsulePlayerComponent.Cast(pc.FindComponent(CapsulePlayerComponent));
			if (comp) return comp.GetLocalCapsules();
		}
		return 0;
	}

	private void UpdateCapsules()
	{
		if (!m_wCapsules) return;
		m_wCapsules.SetText("Capsules : " + GetLocalCapsules().ToString());
	}

	private VendorNPCComponent FindVendor()
	{
		return s_Vendor;
	}

	private CapsulePlayerComponent FindPlayerComp()
	{
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return null;
		return CapsulePlayerComponent.Cast(pc.FindComponent(CapsulePlayerComponent));
	}

	// =========================================================================
	// TOOLTIP AU SURVOL
	// =========================================================================

	// Cree le panneau tooltip (invisible au depart)
	private void CreateTooltip()
	{
		WorkspaceWidget ws = GetGame().GetWorkspace();
		if (!ws) return;

		// Creer le tooltip en enfant du root widget du menu (pas du Workspace)
		Widget root = GetRootWidget();
		if (!root) return;

		m_wTooltip = ws.CreateWidgets(TOOLTIP_LAYOUT, root);
		if (!m_wTooltip) return;
		m_wTooltip.SetVisible(false);

		// Log pour confirmer la creation
		Print("[CapsuleTooltip] CreateTooltip OK - widgets: " + m_wTooltip.ToString());

		m_wTooltipName = TextWidget.Cast(m_wTooltip.FindAnyWidget("Tooltip_Name"));
		m_wTooltipType = TextWidget.Cast(m_wTooltip.FindAnyWidget("Tooltip_Type"));
		m_wTooltipBuy  = TextWidget.Cast(m_wTooltip.FindAnyWidget("Tooltip_BuyPrice"));
		m_wTooltipSell = TextWidget.Cast(m_wTooltip.FindAnyWidget("Tooltip_SellPrice"));

		Print("[CapsuleTooltip] Name=" + m_wTooltipName.ToString()
			+ " Type=" + m_wTooltipType.ToString()
			+ " Buy=" + m_wTooltipBuy.ToString()
			+ " Sell=" + m_wTooltipSell.ToString());
	}

	// Retourne le libelle de categorie d'un item achat selon vendeur + categorie active
	private string GetCategoryLabel()
	{
		array<string> names = GetCategoryNames();
		if (m_iCategory >= 0 && m_iCategory < names.Count())
			return names[m_iCategory];
		return "";
	}

	// Retourne le libelle de type pour un item de vente (d'apres son resourceName)
	private string GetSellCategoryLabel(string resourceName)
	{
		// Cherche dans toutes les listes d'armes connues
		if (FindInCatalog(CapsuleConfig.WEAPONS_RIFLES, resourceName))    return "Fusil";
		if (FindInCatalog(CapsuleConfig.WEAPONS_MG, resourceName))        return "Mitrailleuse";
		if (FindInCatalog(CapsuleConfig.WEAPONS_LAUNCHERS, resourceName)) return "Lanceur";
		if (FindInCatalog(CapsuleConfig.OPTICS, resourceName))            return "Optique";
		if (FindInCatalog(CapsuleConfig.ATTACHMENTS, resourceName))       return "Accessoire";
		if (FindInCatalog(CapsuleConfig.BM_WEAPONS, resourceName))        return "Arme (marche noir)";
		if (FindInCatalog(CapsuleConfig.BM_OPTICS, resourceName))         return "Optique (marche noir)";
		if (FindInCatalog(CapsuleConfig.BM_ATTACHMENTS, resourceName))    return "Accessoire (marche noir)";
		return "Equipement";
	}

	private bool FindInCatalog(array<ref CapsuleItemDef> cat, string resourceName)
	{
		if (!cat) return false;
		for (int i = 0; i < cat.Count(); i++)
		{
			if (cat[i] && cat[i].m_sResourceName == resourceName)
				return true;
		}
		return false;
	}

	// Affiche le tooltip pour un item du bloc ACHAT
	void ShowTooltipBuy(int index, int screenX, int screenY)
	{
		Print("[CapsuleTooltip] ShowTooltipBuy idx=" + index.ToString() + " x=" + screenX.ToString() + " y=" + screenY.ToString());
		if (!m_wTooltip || !m_aBuyItems || index >= m_aBuyItems.Count())
		{
			Print("[CapsuleTooltip] ABORT - wTooltip=" + (!m_wTooltip).ToString() + " aBuyItems=" + (!m_aBuyItems).ToString());
			return;
		}
		CapsuleItemDef item = m_aBuyItems[index];
		if (!item) return;

		if (m_wTooltipName) m_wTooltipName.SetText(item.m_sDisplayName);
		if (m_wTooltipType) m_wTooltipType.SetText(GetCategoryLabel());
		if (m_wTooltipBuy)  m_wTooltipBuy.SetText("Achat : " + item.m_iBuyPrice.ToString() + " capsules");

		if (m_wTooltipSell)
		{
			if (item.m_iSellPrice > 0)
				m_wTooltipSell.SetText("Vente : " + item.m_iSellPrice.ToString() + " capsules");
			else
				m_wTooltipSell.SetText("Non revendable");
		}

		PositionTooltip(screenX, screenY);
		m_wTooltip.SetVisible(true);
	}

	// Affiche le tooltip pour un item du bloc VENTE (item de l'inventaire)
	void ShowTooltipSell(int index, int screenX, int screenY)
	{
		if (!m_wTooltip || !m_aSellItems || index >= m_aSellItems.Count()) return;
		IEntity item = m_aSellItems[index];
		if (!item) return;

		string resName = GetItemResourceName(item);
		int sellPrice  = GetSellPrice(resName);

		if (m_wTooltipName) m_wTooltipName.SetText(GetItemName(item));
		if (m_wTooltipType) m_wTooltipType.SetText(GetSellCategoryLabel(resName));
		if (m_wTooltipBuy)  m_wTooltipBuy.SetText("Non achetable ici");
		if (m_wTooltipSell) m_wTooltipSell.SetText("Vente : " + sellPrice.ToString() + " capsules");

		PositionTooltip(screenX, screenY);
		m_wTooltip.SetVisible(true);
	}

	// Cache le tooltip
	void HideTooltip()
	{
		if (m_wTooltip) m_wTooltip.SetVisible(false);
	}

	// Positionne le tooltip intelligemment (evite de sortir de l'ecran)
	private void PositionTooltip(int screenX, int screenY)
	{
		if (!m_wTooltip) return;

		WorkspaceWidget ws = GetGame().GetWorkspace();
		if (!ws) return;

		// screenX/screenY = coords locales du widget depuis OnMouseEnter
		int sw = ws.GetWidth();
		int sh = ws.GetHeight();

		int tw = 270;
		int th = 112;
		int ox = 16;
		int oy = 16;

		int tx = screenX + ox;
		int ty = screenY + oy;

		if (tx + tw > sw - 10) tx = screenX - tw - ox;
		if (ty + th > sh - 10) ty = screenY - th - oy;
		if (tx < 4) tx = 4;
		if (ty < 4) ty = 4;

		FrameSlot.SetPos(m_wTooltip, tx, ty);

		Print("[CapsuleTooltip] Position: " + tx.ToString() + "," + ty.ToString());
	}


	private ref array<string> GetCategoryNames()
	{
		if (s_eType == EVendorType.VEHICLE)      return VEHICLE_CATEGORY_NAMES;
		if (s_eType == EVendorType.CLOTHING)     return CLOTHING_CATEGORY_NAMES;
		if (s_eType == EVendorType.MEDICAL)      return MEDICAL_CATEGORY_NAMES;
		if (s_eType == EVendorType.FOOD)         return FOOD_CATEGORY_NAMES;
		if (s_eType == EVendorType.BLACKMARKET)  return BM_CATEGORY_NAMES;
		return ARMS_CATEGORY_NAMES;
	}

	private ref array<ref CapsuleItemDef> GetCatalog()
	{
		// VEHICULES
		if (s_eType == EVendorType.VEHICLE)
		{
			if (m_iCategory == 1) return CapsuleConfig.VEHICLES_HELI_UH1;
			if (m_iCategory == 2) return CapsuleConfig.VEHICLES_WHEELED_US;
			if (m_iCategory == 3) return CapsuleConfig.VEHICLES_WHEELED_SOV;
			if (m_iCategory == 4) return CapsuleConfig.VEHICLES_CIV;
			if (m_iCategory == 5) return CapsuleConfig.VEHICLES_DLC;
			return CapsuleConfig.VEHICLES_HELI_UH1;
		}

		// VETEMENTS
		if (s_eType == EVendorType.CLOTHING)
		{
			if (m_iCategory == 0) return CapsuleConfig.CLOTHING_JACKETS;
			if (m_iCategory == 1) return CapsuleConfig.CLOTHING_PANTS;
			if (m_iCategory == 2) return CapsuleConfig.CLOTHING_SHIRTS;
			if (m_iCategory == 3) return CapsuleConfig.CLOTHING_VESTS;
			if (m_iCategory == 4) return CapsuleConfig.CLOTHING_HEADGEAR;
			if (m_iCategory == 5) return CapsuleConfig.CLOTHING_BACKPACKS;
			return CapsuleConfig.CLOTHING_JACKETS;
		}

		// MEDICAL
		if (s_eType == EVendorType.MEDICAL)
		{
			return CapsuleConfig.MEDICAL_ITEMS;
		}

		// NOURRITURE / EAU
		if (s_eType == EVendorType.FOOD)
		{
			if (m_iCategory == 0) return CapsuleConfig.FOOD_ITEMS;
			if (m_iCategory == 1) return CapsuleConfig.WATER_ITEMS;
			return CapsuleConfig.FOOD_ITEMS;
		}

		// MARCHE NOIR
		if (s_eType == EVendorType.BLACKMARKET)
		{
			if (m_iCategory == 0) return CapsuleConfig.BM_WEAPONS;
			if (m_iCategory == 1) return CapsuleConfig.BM_MAGAZINES;
			if (m_iCategory == 2) return CapsuleConfig.BM_OPTICS;
			if (m_iCategory == 3) return CapsuleConfig.BM_ATTACHMENTS;
			return CapsuleConfig.BM_WEAPONS;
		}

		// ARMES (defaut)
		if (m_iCategory == 0) return CapsuleConfig.WEAPONS_RIFLES;
		if (m_iCategory == 1) return CapsuleConfig.WEAPONS_MG;
		if (m_iCategory == 2) return CapsuleConfig.WEAPONS_LAUNCHERS;
		if (m_iCategory == 3) return CapsuleConfig.AMMO_556;
		if (m_iCategory == 4) return CapsuleConfig.AMMO_545;
		if (m_iCategory == 5) return CapsuleConfig.AMMO_762;
		if (m_iCategory == 6) return CapsuleConfig.OPTICS;
		if (m_iCategory == 7) return CapsuleConfig.ATTACHMENTS;
		return CapsuleConfig.WEAPONS_RIFLES;
	}

	// Changer de categorie et reconstruire la liste
	// Met en evidence l'item selectionne (manette) - couleur differente pour le bloc actif
	private void HighlightSelected()
	{
		// Reset couleurs bloc achat
		for (int i = 0; i < m_aBuyWidgets.Count(); i++)
		{
			Widget row = m_aBuyWidgets[i];
			if (!row) continue;
			ImageWidget bg = ImageWidget.Cast(row.FindAnyWidget("ItemBg"));
			if (!bg) continue;
			if (!m_bInSellBlock && i == m_iBuySelected)
				bg.SetColor(new Color(0.2, 0.6, 1.0, 0.5)); // bleu = selectionne actif
			else
				bg.SetColor(new Color(1.0, 1.0, 1.0, 0.1)); // gris = normal
		}
		// Reset couleurs bloc vente
		for (int i = 0; i < m_aSellWidgets.Count(); i++)
		{
			Widget row = m_aSellWidgets[i];
			if (!row) continue;
			ImageWidget bg = ImageWidget.Cast(row.FindAnyWidget("ItemBg"));
			if (!bg) continue;
			if (m_bInSellBlock && i == m_iSellSelected)
				bg.SetColor(new Color(1.0, 0.6, 0.1, 0.5)); // orange = selectionne actif
			else
				bg.SetColor(new Color(1.0, 1.0, 1.0, 0.1)); // gris = normal
		}
	}

	void SetCategory(int cat)
	{
		m_iCategory = cat;
		m_iSelected = 0;
		m_iBuySelected = 0; // reset selection manette sur nouvelle categorie

		// Vider la liste existante
		foreach (Widget w : m_aBuyWidgets) { if (w) w.RemoveFromHierarchy(); }
		m_aBuyWidgets.Clear();
		m_aHandlers.Clear();
		// Cacher le tooltip sans le detruire (il sera reutilise)
		HideTooltip();

		BuildBuyList();
		RefreshSelection();
		HighlightSelected();

		// Mettre a jour le texte de categorie
		Widget root = GetRootWidget();
		if (root)
		{
			TextWidget catLabel = TextWidget.Cast(root.FindAnyWidget("txt_Category"));
			if (catLabel) catLabel.SetText("[ " + GetCategoryNames()[cat] + " ]");
		}
	}

	void CategoryNext()
	{
		SetCategory((m_iCategory + 1) % GetCategoryNames().Count());
	}

	void CategoryPrev()
	{
		int prev = m_iCategory - 1;
		if (prev < 0) prev = GetCategoryNames().Count() - 1;
		SetCategory(prev);
	}

	private string GetItemName(IEntity item)
	{
		if (!item) return "Inconnu";
		string name = item.GetName();
		if (name != string.Empty) return name;

		EntityPrefabData pd = item.GetPrefabData();
		if (!pd) return "Item";
		string path = pd.GetPrefabName();
		int lastSlash = 0;
		for (int i = 0; i < path.Length(); i++)
		{
			if (path.Get(i) == "/") lastSlash = i + 1;
		}
		string filename = path.Substring(lastSlash, path.Length() - lastSlash);
		int dotPos = filename.IndexOf(".");
		if (dotPos > 0) filename = filename.Substring(0, dotPos);

		string result = "";
		for (int j = 0; j < filename.Length(); j++)
		{
			string ch = filename.Get(j);
			if (ch == "_") result += " ";
			else result += ch;
		}
		return result;
	}

	private string GetItemResourceName(IEntity item)
	{
		if (!item) return "";
		EntityPrefabData pd = item.GetPrefabData();
		if (pd) return pd.GetPrefabName();
		return "";
	}
}