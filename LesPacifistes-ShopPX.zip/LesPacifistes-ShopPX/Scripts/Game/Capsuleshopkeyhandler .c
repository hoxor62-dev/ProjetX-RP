/**
 * CapsuleShopKeyHandler.c
 * 
 * - Molette souris vers le haut/bas = changer cat�gorie
 * - Clic droit = fermer le menu
 * - OnModalClickOut = fermer si clic hors du menu
 * 
 * Ces �v�nements fonctionnent sans aucun contexte input.
 */
class CapsuleShopKeyHandler : ScriptedWidgetEventHandler
{
	private CapsuleShopMenuBase m_Menu;

	void Init(CapsuleShopMenuBase menu)
	{
		m_Menu = menu;
	}

	// Molette souris � changer de cat�gorie
	override bool OnMouseWheel(Widget w, int x, int y, int wheel)
	{
		if (!m_Menu) return false;

		if (wheel > 0)
			m_Menu.CategoryPrev();
		else if (wheel < 0)
			m_Menu.CategoryNext();

		return true;
	}

	// Clic droit = fermer
	override bool OnMouseButtonDown(Widget w, int x, int y, int button)
	{
		if (!m_Menu) return false;

		if (button == 1) // bouton droit
		{
			m_Menu.Close();
			return true;
		}
		return false;
	}

	// Clic hors du menu = fermer
	override bool OnModalClickOut(Widget modalRoot, int x, int y, int button)
	{
		if (m_Menu) m_Menu.Close();
		return true;
	}
}