/**
 * CapsulePauseMenuButton.c
 * Injecte le bouton "Capsules Score" dans le menu Echap (PauseMenuUI).
 * Se positionne en lisant la position layout du bouton "Exit".
 */

modded class PauseMenuUI
{
	private Widget m_wCapsuleBtn = null;
	private ref CapsulePauseButtonHandler m_CapsuleClickHandler = null;

	override void OnMenuOpen()
	{
		super.OnMenuOpen();
		// Petit delai pour que tous les boutons vanilla soient initialises
		GetGame().GetCallqueue().CallLater(InjectButton, 100, false);
	}

	private void InjectButton()
	{
		Widget root = GetRootWidget();
		if (!root) return;

		// Trouver le bouton Exit pour recuperer sa position dans le layout
		SCR_ButtonTextComponent exitComp = SCR_ButtonTextComponent.GetButtonText("Exit", root);
		if (!exitComp) { Print("[CapsulePause] bouton Exit introuvable"); return; }

		Widget exitW = exitComp.GetRootWidget();
		if (!exitW) return;

		WorkspaceWidget ws = GetGame().GetWorkspace();
		if (!ws) return;

		// GetScreenPos retourne des valeurs normalisees 0..1
		float ex, ey, ew, eh;
		exitW.GetScreenPos(ex, ey);
		exitW.GetScreenSize(ew, eh);

		// Convertir en coordonnees workspace reelles
		float wsW = ws.GetWidth();
		float wsH = ws.GetHeight();
		float lx = ex * wsW;
		float ly = ey * wsH;
		float lw = ew * wsW;
		float lh = eh * wsH;

		// Parent du bouton Exit pour creer notre bouton au meme niveau
		Widget parent = exitW.GetParent();
		if (!parent) parent = root;

		// Bouton place juste au-dessus du bouton Exit
		m_wCapsuleBtn = ws.CreateWidget(WidgetType.ButtonWidgetTypeID,
			WidgetFlags.VISIBLE,
			Color.FromRGBA(0, 0, 0, 0), 0, parent);
		if (!m_wCapsuleBtn) return;

		FrameSlot.SetPos(m_wCapsuleBtn, lx, ly - lh - 8);
		FrameSlot.SetSize(m_wCapsuleBtn, lw, lh);

		// Texte style vanilla
		Widget lblW = ws.CreateWidget(WidgetType.TextWidgetTypeID,
			WidgetFlags.VISIBLE | WidgetFlags.NOFOCUS,
			Color.FromRGBA(0,0,0,0), 0, m_wCapsuleBtn);
		FrameSlot.SetPos(lblW, 0, 0);
		FrameSlot.SetSize(lblW, lw, lh);
		TextWidget lbl = TextWidget.Cast(lblW);
		if (lbl)
		{
			lbl.SetText("Capsules Score");
			lbl.SetColor(Color.FromRGBA(240, 210, 50, 255));
		}

		m_CapsuleClickHandler = new CapsulePauseButtonHandler();
		m_CapsuleClickHandler.Init(this);
		m_wCapsuleBtn.AddHandler(m_CapsuleClickHandler);

		Print("[CapsulePause] Bouton injecte a lx=" + lx.ToString() + " ly=" + (ly - lh - 8).ToString());
	}

	override void OnMenuClose()
	{
		if (m_wCapsuleBtn)
		{
			m_wCapsuleBtn.RemoveFromHierarchy();
			m_wCapsuleBtn = null;
		}
		super.OnMenuClose();
	}

	void OpenCapsuleLeaderboard()
	{
		if (m_wCapsuleBtn) { m_wCapsuleBtn.RemoveFromHierarchy(); m_wCapsuleBtn = null; }
		Close();
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return;
		CapsuleLeaderboardComponent comp = CapsuleLeaderboardComponent.Cast(
			pc.FindComponent(CapsuleLeaderboardComponent));
		if (comp)
			comp.ShowLeaderboard();
	}
}

class CapsulePauseButtonHandler : ScriptedWidgetEventHandler
{
	private PauseMenuUI m_Menu;
	void Init(PauseMenuUI menu) { m_Menu = menu; }

	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (button == 0 && m_Menu) { m_Menu.OpenCapsuleLeaderboard(); return true; }
		return false;
	}

	override bool OnMouseButtonDown(Widget w, int x, int y, int button)
	{
		if (button == 0 && m_Menu) { m_Menu.OpenCapsuleLeaderboard(); return true; }
		return false;
	}
}
