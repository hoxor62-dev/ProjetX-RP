/**
 * CapsuleEconomyManager.c
 * Gestionnaire economique cote serveur.
 * Note: "ref" OBLIGATOIRE sur les variables static en Enfusion.
 */

class CapsulePlayerData
{
	string m_sPlayerId;
	string m_sPlayerName;
	int    m_iCapsules;
	int    m_iTotalKills;
	int    m_iCurrentKillStreak;
	int    m_iDeaths;

	void CapsulePlayerData(string id, string name)
	{
		m_sPlayerId          = id;
		m_sPlayerName        = name;
		m_iCapsules          = 0;
		m_iTotalKills        = 0;
		m_iCurrentKillStreak = 0;
		m_iDeaths            = 0;
	}
}

class CapsuleEconomyManager
{
	private static ref CapsuleEconomyManager s_Instance;

	private ref map<string, ref CapsulePlayerData> m_mPlayerData;

	// -- Evenement double capsules -----------------------------------------
	private bool  m_bDoubleActive  = false;
	private float m_fDoubleTimer   = 0.0;

	//------------------------------------------------------------------------------------------------
	void CapsuleEconomyManager()
	{
		m_mPlayerData = new map<string, ref CapsulePlayerData>();
		// Creer le dossier de sauvegarde s'il n'existe pas
		if (!FileIO.FileExist("$profile:CapsuleEconomy"))
			FileIO.MakeDirectory("$profile:CapsuleEconomy");
		Print("[CapsuleEconomy] Manager cree. Dossier save: $profile:CapsuleEconomy");
	}

	//------------------------------------------------------------------------------------------------
	static CapsuleEconomyManager GetInstance()
	{
		if (!s_Instance)
			s_Instance = new CapsuleEconomyManager();
		return s_Instance;
	}

	//------------------------------------------------------------------------------------------------
	// -- Double capsules event ------------------------------------------------
	void StartDoubleEvent()
	{
		m_bDoubleActive = true;
		m_fDoubleTimer  = CapsuleConfig.DOUBLE_CAPS_DURATION;
		Print("[CapsuleEconomy] === EVENEMENT DOUBLE CAPSULES ACTIVE pour " + CapsuleConfig.DOUBLE_CAPS_DURATION.ToString() + "s ===");
	}

	bool IsDoubleActive() { return m_bDoubleActive; }
	float GetDoubleTimer() { return m_fDoubleTimer; }

	void TickDouble(float dt)
	{
		if (!m_bDoubleActive) return;
		m_fDoubleTimer -= dt;
		if (m_fDoubleTimer <= 0)
		{
			m_bDoubleActive = false;
			m_fDoubleTimer  = 0;
			Print("[CapsuleEconomy] === EVENEMENT DOUBLE CAPSULES TERMINE ===");
		}
	}

	// -- Primes ---------------------------------------------------------------
	bool HasBounty(string uid)
	{
		if (!m_mPlayerData.Contains(uid)) return false;
		return m_mPlayerData[uid].m_iTotalKills >= CapsuleConfig.BOUNTY_KILL_THRESHOLD;
	}

	//------------------------------------------------------------------------------------------------
	void OnPlayerConnected(string uid, string name)
	{
		if (!m_mPlayerData.Contains(uid))
			m_mPlayerData[uid] = new CapsulePlayerData(uid, name);
		else
			m_mPlayerData[uid].m_sPlayerName = name;
		Print("[CapsuleEconomy] Connecte: " + name + " | Capsules: " + m_mPlayerData[uid].m_iCapsules);
	}

	void OnPlayerDisconnected(string uid)
	{
		SavePlayerData(uid);
	}

	//------------------------------------------------------------------------------------------------
	void OnPlayerKill(string killerUid, string victimUid = "")
	{
		if (!m_mPlayerData.Contains(killerUid)) return;
		CapsulePlayerData d = m_mPlayerData[killerUid];

		int reward = CapsuleConfig.CAPSULES_PER_KILL;
		if (m_bDoubleActive) reward *= 2;

		// Bonus prime si la victime avait une prime
		if (victimUid != "" && HasBounty(victimUid))
			reward += CapsuleConfig.BOUNTY_REWARD;

		d.m_iCapsules          += reward;
		d.m_iTotalKills        += 1;
		d.m_iCurrentKillStreak += 1;

		if (d.m_iCurrentKillStreak >= CapsuleConfig.KILL_STREAK_THRESHOLD)
		{
			d.m_iCapsules         += CapsuleConfig.KILL_STREAK_BONUS;
			d.m_iCurrentKillStreak = 0;
		}
		string doubleStr = "";
		if (m_bDoubleActive) doubleStr = " [x2]";
		Print("[CapsuleEconomy] Kill: " + d.m_sPlayerName + " | Total: " + d.m_iCapsules.ToString() + doubleStr);
		NotifyPlayerCapsules(killerUid);
	}

	void OnPlayerDeath(string uid)
	{
		if (!m_mPlayerData.Contains(uid)) return;
		CapsulePlayerData d = m_mPlayerData[uid];
		d.m_iCurrentKillStreak = 0;
		d.m_iDeaths += 1;
		if (CapsuleConfig.DEATH_PENALTY > 0)
			d.m_iCapsules = Math.Max(0, d.m_iCapsules - CapsuleConfig.DEATH_PENALTY);
	}

	//------------------------------------------------------------------------------------------------
	bool TrySpendCapsules(string uid, int amount)
	{
		if (!m_mPlayerData.Contains(uid)) return false;
		CapsulePlayerData d = m_mPlayerData[uid];
		if (d.m_iCapsules < amount) return false;
		d.m_iCapsules -= amount;
		NotifyPlayerCapsules(uid);
		return true;
	}

	// Envoie les capsules au client proprietaire via RPC
	private void NotifyPlayerCapsules(string uid)
	{
		PlayerManager pm = GetGame().GetPlayerManager();
		if (!pm) { Print("[Economy] NotifyPlayer: PlayerManager null"); return; }
		PlayerController pc = pm.GetPlayerController(uid.ToInt());
		if (!pc) return;
		CapsulePlayerComponent comp = CapsulePlayerComponent.Cast(pc.FindComponent(CapsulePlayerComponent));
		if (!comp) return;
		comp.Svr_SendCapsules(m_mPlayerData[uid].m_iCapsules);
	}

	void AddCapsules(string uid, int amount)
	{
		if (!m_mPlayerData.Contains(uid)) return;
		m_mPlayerData[uid].m_iCapsules += amount;
		NotifyPlayerCapsules(uid);
	}

	int GetCapsules(string uid)
	{
		if (!m_mPlayerData.Contains(uid)) return 0;
		return m_mPlayerData[uid].m_iCapsules;
	}

	//------------------------------------------------------------------------------------------------
	// Retourne tous les joueurs (pour leaderboard complet avec stats)
	ref array<ref CapsulePlayerData> GetAllPlayers()
	{
		ref array<ref CapsulePlayerData> all = new array<ref CapsulePlayerData>();
		foreach (string id, CapsulePlayerData data : m_mPlayerData)
			all.Insert(data);
		// Tri par capsules decroissant
		int n = all.Count();
		for (int i = 0; i < n - 1; i++)
			for (int j = 0; j < n - i - 1; j++)
				if (all[j].m_iCapsules < all[j+1].m_iCapsules)
				{
					CapsulePlayerData tmp = all[j];
					all[j]   = all[j+1];
					all[j+1] = tmp;
				}
		return all;
	}

	//------------------------------------------------------------------------------------------------
	ref array<ref CapsulePlayerData> GetLeaderboard()
	{
		ref array<ref CapsulePlayerData> sorted = new array<ref CapsulePlayerData>();
		foreach (string id, CapsulePlayerData data : m_mPlayerData)
			sorted.Insert(data);

		int n = sorted.Count();
		for (int i = 0; i < n - 1; i++)
			for (int j = 0; j < n - i - 1; j++)
				if (sorted[j].m_iCapsules < sorted[j+1].m_iCapsules)
				{
					CapsulePlayerData tmp = sorted[j];
					sorted[j]   = sorted[j+1];
					sorted[j+1] = tmp;
				}
		while (sorted.Count() > 10)
			sorted.Remove(sorted.Count() - 1);
		return sorted;
	}

	//------------------------------------------------------------------------------------------------
	void SaveAllData()
	{
		foreach (string uid, CapsulePlayerData data : m_mPlayerData)
			SavePlayerData(uid);
		Print("[CapsuleEconomy] Sauvegarde complete.");
	}

	private void SavePlayerData(string uid)
	{
		if (!m_mPlayerData.Contains(uid)) return;
		CapsulePlayerData d = m_mPlayerData[uid];
		string json = "{\"playerId\":\"" + d.m_sPlayerId + "\",";
		json += "\"playerName\":\"" + d.m_sPlayerName + "\",";
		json += "\"capsules\":" + d.m_iCapsules.ToString() + ",";
		json += "\"totalKills\":" + d.m_iTotalKills.ToString() + ",";
		json += "\"deaths\":" + d.m_iDeaths.ToString() + "}";

		string path = "$profile:CapsuleEconomy/player_" + uid + ".json";
		FileHandle f = FileIO.OpenFile(path, FileMode.WRITE);
		if (f)
		{
			f.WriteLine(json);
			f.Close();
			Print("[CapsuleEconomy] Sauvegarde: " + d.m_sPlayerName + " | " + d.m_iCapsules.ToString() + " caps | path=" + path);
		}
		else
			Print("[CapsuleEconomy] ERREUR save: impossible d ecrire " + path, LogLevel.ERROR);
	}

	void LoadPlayerData(string uid, string name)
	{
		string path = "$profile:CapsuleEconomy/player_" + uid + ".json";
		FileHandle f = FileIO.OpenFile(path, FileMode.READ);
		if (!f) { m_mPlayerData[uid] = new CapsulePlayerData(uid, name); return; }

		string line, full = "";
		while (f.ReadLine(line) != -1) full += line;
		f.Close();

		CapsulePlayerData d = new CapsulePlayerData(uid, name);
		// Helper : extrait la valeur entiere apres une cle JSON, sans depasser la fin de chaine
		int ci = full.IndexOf("\"capsules\":");
		if (ci >= 0)
		{
			int start = ci + 11;
			int avail = full.Length() - start;
			if (avail > 0)
			{
				if (avail > 10) avail = 10;
				string s = full.Substring(start, avail);
				int c2 = s.IndexOf(","); if (c2 >= 0) s = s.Substring(0, c2);
				int c3 = s.IndexOf("}"); if (c3 >= 0) s = s.Substring(0, c3);
				d.m_iCapsules = s.ToInt();
			}
		}
		int ki = full.IndexOf("\"totalKills\":");
		if (ki >= 0)
		{
			int start = ki + 13;
			int avail = full.Length() - start;
			if (avail > 0)
			{
				if (avail > 10) avail = 10;
				string s = full.Substring(start, avail);
				int c2 = s.IndexOf("}"); if (c2 >= 0) s = s.Substring(0, c2);
				int c3 = s.IndexOf(","); if (c3 >= 0) s = s.Substring(0, c3);
				d.m_iTotalKills = s.ToInt();
			}
		}
		int di = full.IndexOf("\"deaths\":");
		if (di >= 0)
		{
			int start = di + 9;
			int avail = full.Length() - start;
			if (avail > 0)
			{
				if (avail > 10) avail = 10;
				string s = full.Substring(start, avail);
				int c2 = s.IndexOf("}"); if (c2 >= 0) s = s.Substring(0, c2);
				int c3 = s.IndexOf(","); if (c3 >= 0) s = s.Substring(0, c3);
				d.m_iDeaths = s.ToInt();
			}
		}
		m_mPlayerData[uid] = d;
		Print("[CapsuleEconomy] Charge: " + name + " | Capsules: " + d.m_iCapsules.ToString() + " | Kills: " + d.m_iTotalKills.ToString() + " | Deaths: " + d.m_iDeaths.ToString());
	}
}