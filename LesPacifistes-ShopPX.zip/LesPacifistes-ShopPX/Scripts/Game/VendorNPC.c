/**
 * VendorNPC.c
 * EOnFrame tourne sur TOUS les clients - la proximite est verifiee cote client local.
 * Le RplComponent sur le prefab vendeur assure la replication de l'entite.
 */

enum EVendorType
{
	ARMS        = 0,
	VEHICLE     = 1,
	CLOTHING    = 2,
	MEDICAL     = 3,
	FOOD        = 4,
	BLACKMARKET = 5
}

class VendorNPCComponentClass : ScriptComponentClass {}

class VendorNPCComponent : ScriptComponent
{
	[Attribute("0", UIWidgets.ComboBox, "Type de vendeur", "", ParamEnumArray.FromEnum(EVendorType))]
	EVendorType m_eVendorType;

	[Attribute("Vendeur", UIWidgets.EditBox, "Nom affiche")]
	string m_sVendorName;

	[Attribute("3.0", UIWidgets.Slider, "Distance interaction (m)", "1 10 0.5")]
	float m_fInteractionDistance;

	private bool    m_bPlayerNearby = false;
	private IEntity m_pNearbyPlayer = null;
	private bool    m_bMenuOpen = false;
	private IEntity m_Owner     = null;
	private vector  m_vVehicleSpawnPos;

	//------------------------------------------------------------------------------------------------
	override void OnPostInit(IEntity owner)
	{
		super.OnPostInit(owner);
		m_Owner = owner;
		m_vVehicleSpawnPos = owner.GetOrigin() + Vector(CapsuleConfig.VEHICLE_SPAWN_DISTANCE, 0, 0);

		// EOnFrame uniquement cote client - jamais sur le serveur dedie
		// Sur le serveur, GetPlayerController/GetMenuManager n'existent pas
		if (!Replication.IsServer())
			SetEventMask(owner, EntityEvent.FRAME);

		Print("[VendorNPC] OnPostInit - " + m_sVendorName
			+ " | Mode=" + RplSession.Mode().ToString());
	}

	//------------------------------------------------------------------------------------------------
	override void EOnFrame(IEntity owner, float timeSlice)
	{
		// Double securite - ne rien faire cote serveur
		if (Replication.IsServer()) return;

		CheckProximity(owner);

		// Surveiller la fermeture du menu
		if (m_bMenuOpen)
		{
			MenuBase menu = GetGame().GetMenuManager().FindMenuByPreset(ChimeraMenuPreset.CapsuleShopMenu);
			if (!menu) m_bMenuOpen = false;
		}
	}

	//------------------------------------------------------------------------------------------------
	private void CheckProximity(IEntity owner)
	{
		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return; // Joueur pas encore charge - silencieux

		IEntity localPlayer = pc.GetControlledEntity();
		if (!localPlayer) return;

		float dist   = vector.Distance(owner.GetOrigin(), localPlayer.GetOrigin());
		bool  nearby = (dist <= m_fInteractionDistance);

		if (nearby == m_bPlayerNearby) return;

		m_bPlayerNearby = nearby;
		if (nearby)
			m_pNearbyPlayer = localPlayer;
		else
			m_pNearbyPlayer = null;

		if (nearby)
		{
			Print("[VendorNPC] Joueur a portee de " + m_sVendorName + " dist=" + dist.ToString());
		}
		else
		{
			if (m_bMenuOpen)
			{
				MenuBase _m = GetGame().GetMenuManager().FindMenuByPreset(ChimeraMenuPreset.CapsuleShopMenu);
				if (_m) GetGame().GetMenuManager().CloseMenu(_m);
				m_bMenuOpen = false;
			}
		}
	}

	//------------------------------------------------------------------------------------------------
	// Appele par VendorUserAction - cote client uniquement
	void OnInteractAction(IEntity pUserEntity = null)
	{
		if (Replication.IsServer()) return;

		// Utiliser pUserEntity directement (plus fiable que m_pNearbyPlayer)
		if (pUserEntity)
			m_pNearbyPlayer = pUserEntity;

		if (m_bMenuOpen)
		{
			MenuBase _m = GetGame().GetMenuManager().FindMenuByPreset(ChimeraMenuPreset.CapsuleShopMenu);
			if (_m) GetGame().GetMenuManager().CloseMenu(_m);
			m_bMenuOpen = false;
		}
		else
		{
			Print("[VendorNPC] OnInteractAction -> ouverture menu " + m_sVendorName);
			OpenMenu();
		}
	}

	private float m_fInteractCooldown = 0.0;

	private void CheckInteract()
	{
		if (m_fInteractCooldown > 0.0)
		{
			m_fInteractCooldown -= 0.016;
			return;
		}

		// Tester plusieurs noms d'actions possibles pour trouver le bon
		InputManager im = GetGame().GetInputManager();
		if (!im) return;

		bool triggered = false;
		if (im.GetActionTriggered("CharacterUseItem")) triggered = true;
		if (im.GetActionTriggered("Interact")) triggered = true;
		if (im.GetActionTriggered("CharacterInteract")) triggered = true;
		if (im.GetActionTriggered("GetIn")) triggered = true;

		if (triggered)
		{
			m_fInteractCooldown = 0.5;
			if (m_bMenuOpen)
			{
				MenuBase _m = GetGame().GetMenuManager().FindMenuByPreset(ChimeraMenuPreset.CapsuleShopMenu);
				if (_m) GetGame().GetMenuManager().CloseMenu(_m);
				m_bMenuOpen = false;
			}
			else
			{
				Print("[VendorNPC] Action detectee -> ouverture menu " + m_sVendorName);
				OpenMenu();
			}
		}
	}

	//------------------------------------------------------------------------------------------------
	private void OpenMenu()
	{
		if (Replication.IsServer()) return;
		if (m_bMenuOpen) return;

		// Si m_pNearbyPlayer non defini, tenter via PlayerController local
		if (!m_pNearbyPlayer)
		{
			PlayerController pc2 = GetGame().GetPlayerController();
			if (pc2) m_pNearbyPlayer = pc2.GetControlledEntity();
		}
		if (!m_pNearbyPlayer) return;

		PlayerController pc = GetGame().GetPlayerController();
		if (!pc) return;

		// Passer les donnees statiques avant ouverture du menu
		CapsuleShopMenuBase.s_eType     = m_eVendorType;
		CapsuleShopMenuBase.s_pPlayer   = m_pNearbyPlayer;
		CapsuleShopMenuBase.s_sPlayerId = CapsuleBootstrap.SessionToUID(pc.GetPlayerId());
		CapsuleShopMenuBase.s_Vendor    = VendorNPCComponent.Cast(m_Owner.FindComponent(VendorNPCComponent));

		// Ouverture par layout direct - pas besoin de config preset
		GetGame().GetMenuManager().OpenMenu(ChimeraMenuPreset.CapsuleShopMenu);
		m_bMenuOpen = true;
	}

	//------------------------------------------------------------------------------------------------
	// -- Proxy RPC - appeles depuis le menu (cote client) -------------------
	void AskBuy(string playerId, string resourceName, int price)
	{
		Rpc(Server_ProcessBuy, playerId, resourceName, price);
	}

	void AskSell(string playerId, string resourceName, int sellPrice)
	{
		Rpc(Server_ProcessSell, playerId, resourceName, sellPrice);
	}

	void AskVehicleBuy(string playerId, string resourceName, int price)
	{
		Rpc(Server_ProcessVehicleBuy, playerId, resourceName, price);
	}

	// -- RPC serveur ---------------------------------------------------------
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void Server_ProcessBuy(string playerId, string resourceName, int price)
	{
		if (!Replication.IsServer()) return;
		if (!CapsuleEconomyManager.GetInstance().TrySpendCapsules(playerId, price))
		{
			NotifyClient(playerId, false, "Capsules insuffisantes!");
			return;
		}
		if (!SpawnItemForPlayer(playerId, resourceName))
		{
			CapsuleEconomyManager.GetInstance().AddCapsules(playerId, price);
			NotifyClient(playerId, false, "Erreur creation item.");
			return;
		}
		NotifyClient(playerId, true, "Achat OK! -" + price.ToString() + " Capsules");
	}

	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void Server_ProcessSell(string playerId, string resourceName, int sellPrice)
	{
		if (!Replication.IsServer()) return;
		Print("[VendorNPC] Server_ProcessSell RECU - joueur=" + playerId + " item=" + resourceName + " prix=" + sellPrice.ToString());

		IEntity playerEnt = FindPlayerEntity(playerId);
		if (!playerEnt)
		{
			Print("[VendorNPC] Server_ProcessSell: joueur introuvable id=" + playerId, LogLevel.ERROR);
			return;
		}

		Print("[VendorNPC] Server_ProcessSell: joueur trouve, tentative retrait inventaire...");
		if (!RemoveFromInventory(playerEnt, resourceName))
		{
			Print("[VendorNPC] Server_ProcessSell: RemoveFromInventory ECHEC pour " + resourceName, LogLevel.WARNING);
			NotifyClient(playerId, false, "Item introuvable.");
			return;
		}

		Print("[VendorNPC] Server_ProcessSell: item retire OK, ajout " + sellPrice.ToString() + " caps au joueur " + playerId);
		CapsuleEconomyManager.GetInstance().AddCapsules(playerId, sellPrice);
		Print("[VendorNPC] Server_ProcessSell: nouveau solde = " + CapsuleEconomyManager.GetInstance().GetCapsules(playerId).ToString());
		NotifyClient(playerId, true, "Vendu! +" + sellPrice.ToString() + " Capsules");
	}

	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	void Server_ProcessVehicleBuy(string playerId, string resourceName, int price)
	{
		if (!Replication.IsServer()) return;
		if (!CapsuleEconomyManager.GetInstance().TrySpendCapsules(playerId, price))
		{
			NotifyClient(playerId, false, "Capsules insuffisantes!");
			return;
		}
		if (!SpawnVehicleNearPlayer(playerId, resourceName))
		{
			CapsuleEconomyManager.GetInstance().AddCapsules(playerId, price);
			NotifyClient(playerId, false, "Impossible de spawner le vehicule.");
			return;
		}
		NotifyClient(playerId, true, "Vehicule livre! -" + price.ToString() + " Capsules");
	}

	//------------------------------------------------------------------------------------------------
	private bool SpawnItemForPlayer(string playerId, string resourceName)
	{
		IEntity playerEnt = FindPlayerEntity(playerId);
		if (!playerEnt)
		{
			Print("[VendorNPC] SpawnItem: joueur introuvable id=" + playerId, LogLevel.ERROR);
			return false;
		}

		Resource res = Resource.Load(resourceName);
		if (!res || !res.IsValid())
		{
			Print("[VendorNPC] SpawnItem: ressource invalide - " + resourceName, LogLevel.ERROR);
			return false;
		}

		// Spawner a la position du joueur
		vector playerPos = playerEnt.GetOrigin();
		EntitySpawnParams p = new EntitySpawnParams();
		p.TransformMode = ETransformMode.WORLD;
		Math3D.MatrixIdentity4(p.Transform);
		p.Transform[3] = playerPos + Vector(0, 1, 0);

		IEntity item = GetGame().SpawnEntityPrefab(res, GetGame().GetWorld(), p);
		if (!item)
		{
			Print("[VendorNPC] SpawnItem: echec spawn prefab", LogLevel.ERROR);
			return false;
		}

		// Tenter insertion inventaire
		SCR_InventoryStorageManagerComponent inv =
			SCR_InventoryStorageManagerComponent.Cast(
				playerEnt.FindComponent(SCR_InventoryStorageManagerComponent));

		if (inv)
		{
			inv.InsertItem(item);
			Print("[VendorNPC] Item insere dans l'inventaire du joueur " + playerId);
		}
		else
		{
			// Pas d'inventaire - poser par terre
			item.SetOrigin(playerPos + Vector(1.5, 0.5, 0));
			Print("[VendorNPC] Pas d'inventaire - item pose par terre.");
		}

		return true;
	}

	private bool SpawnVehicleNearPlayer(string playerId, string resourceName)
	{
		Resource res = Resource.Load(resourceName);
		if (!res || !res.IsValid()) return false;

		// Position du joueur + 10m devant lui
		IEntity playerEnt = FindPlayerEntity(playerId);
		vector spawnPos = m_vVehicleSpawnPos; // fallback: position fixe du vendeur
		if (playerEnt)
		{
			vector playerPos = playerEnt.GetOrigin();
			vector playerDir = playerEnt.GetYawPitchRoll();
			float yawRad = playerDir[0] * Math.DEG2RAD;
			spawnPos = playerPos + Vector(Math.Sin(yawRad) * 10, 0, Math.Cos(yawRad) * 10);
		}

		EntitySpawnParams p = new EntitySpawnParams();
		p.TransformMode = ETransformMode.WORLD;
		Math3D.MatrixIdentity4(p.Transform);
		p.Transform[3] = spawnPos;
		IEntity veh = GetGame().SpawnEntityPrefab(res, GetGame().GetWorld(), p);
		Print("[VendorNPC] Vehicule spawne a " + spawnPos.ToString() + " pour joueur " + playerId);
		return (veh != null);
	}

	private bool RemoveFromInventory(IEntity playerEnt, string resourceName)
	{
		SCR_InventoryStorageManagerComponent inv =
			SCR_InventoryStorageManagerComponent.Cast(
				playerEnt.FindComponent(SCR_InventoryStorageManagerComponent));
		if (!inv)
		{
			Print("[VendorNPC] RemoveFromInventory: pas d inventaire sur le joueur", LogLevel.WARNING);
			return false;
		}

		ref array<IEntity> items = new array<IEntity>();
		inv.GetItems(items);
		Print("[VendorNPC] RemoveFromInventory: " + items.Count() + " items, cherche: " + resourceName);

		foreach (IEntity item : items)
		{
			EntityPrefabData pd = item.GetPrefabData();
			if (!pd) continue;
			string prefabPath = pd.GetPrefabName();
			// Comparer en minuscules et dans les deux sens pour etre robuste
			string prefabLower    = prefabPath;
			string resourceLower  = resourceName;
			prefabLower.ToLower();
			resourceLower.ToLower();
			if (prefabLower.IndexOf(resourceLower) >= 0 || resourceLower.IndexOf(prefabLower) >= 0)
			{
				Print("[VendorNPC] Item trouve: " + prefabPath);
				inv.TryRemoveItemFromInventory(item);
				SCR_EntityHelper.DeleteEntityAndChildren(item);
				return true;
			}
		}
		Print("[VendorNPC] RemoveFromInventory: aucun item correspondant trouve", LogLevel.WARNING);
		return false;
	}

	private IEntity FindPlayerEntity(string playerId)
	{
		PlayerManager pm = GetGame().GetPlayerManager();
		if (!pm) return null;
		return pm.GetPlayerControlledEntity(playerId.ToInt());
	}

	private void NotifyClient(string playerId, bool success, string message)
	{
		// CapsulePlayerComponent est sur le PlayerController, pas sur le character
		PlayerController pc = GetGame().GetPlayerManager().GetPlayerController(playerId.ToInt());
		if (!pc) return;
		CapsulePlayerComponent comp =
			CapsulePlayerComponent.Cast(pc.FindComponent(CapsulePlayerComponent));
		if (comp) comp.Svr_SendNotification(success, message);
	}

	string GetVendorName() { return m_sVendorName; }

	override void OnDelete(IEntity owner)
	{
		if (m_bMenuOpen)
		{
			MenuBase menu = GetGame().GetMenuManager().FindMenuByPreset(ChimeraMenuPreset.CapsuleShopMenu);
			if (menu) GetGame().GetMenuManager().CloseMenu(menu);
		}
		super.OnDelete(owner);
	}
}