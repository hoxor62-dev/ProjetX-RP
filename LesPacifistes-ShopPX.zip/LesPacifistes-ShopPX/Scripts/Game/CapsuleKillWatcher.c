/**
 * CapsuleKillWatcher.c
 * 
 * Signature reelle de GetOnControllableDestroyed :
 * (SCR_InstigatorContextData data)
 * 
 * SCR_InstigatorContextData contient :
 * - GetVictimPlayerID()   -> ID joueur victime (0 = IA)
 * - GetKillerPlayerID()   -> ID joueur tueur (0 = IA)
 * - GetVictimEntity()     -> entite victime
 * - GetKillerEntity()     -> entite tueur
 * - DoesPlayerKillCountAsTeamKill() -> friendly fire
 */

class CapsuleKillWatcher
{
	private bool m_bStarted = false;

	void Start()
	{
		SCR_BaseGameMode gameMode = SCR_BaseGameMode.Cast(GetGame().GetGameMode());
		if (!gameMode)
		{
			Print("[CapsuleKillWatcher] ERREUR: SCR_BaseGameMode introuvable!", LogLevel.ERROR);
			return;
		}

		gameMode.GetOnControllableDestroyed().Insert(OnControllableDestroyed);
		m_bStarted = true;
		Print("[CapsuleKillWatcher] Demarre - hook sur GetOnControllableDestroyed()");
	}

	void Stop()
	{
		if (!m_bStarted) return;
		SCR_BaseGameMode gameMode = SCR_BaseGameMode.Cast(GetGame().GetGameMode());
		if (gameMode)
			gameMode.GetOnControllableDestroyed().Remove(OnControllableDestroyed);
		m_bStarted = false;
	}

	private void OnControllableDestroyed(SCR_InstigatorContextData data)
	{
		if (!data) return;

		CapsuleEconomyManager economy = CapsuleEconomyManager.GetInstance();
		if (!economy) return;

		int victimId = data.GetVictimPlayerID();
		int killerId = data.GetKillerPlayerID();

		// Joueur humain mort -> penalite
		if (victimId > 0)
		{
			string victimUid = CapsuleBootstrap.SessionToUID(victimId);
			Print("[CapsuleKill] Joueur " + victimId.ToString() + " mort. uid=" + victimUid);
			economy.OnPlayerDeath(victimUid);

			// Tuer par un autre joueur (PvP) - bloquer le suicide (killer == victim)
			if (killerId > 0 && killerId != victimId && !data.DoesPlayerKillCountAsTeamKill())
			{
				string killerUid = CapsuleBootstrap.SessionToUID(killerId);
				economy.OnPlayerKill(killerUid, victimUid);
				string bountyStr = "";
				if (economy.HasBounty(victimUid)) bountyStr = " [PRIME!]";
				Print("[CapsuleKill] PvP: " + killerUid + " tue " + victimUid
					+ " | Total: " + economy.GetCapsules(killerUid).ToString() + bountyStr);
			}
			return;
		}

		// IA morte - verifier que le tueur est un joueur humain
		if (killerId <= 0) return;

		// Ignorer le friendly fire
		if (data.DoesPlayerKillCountAsTeamKill()) return;

		// Verifier que l'IA est vraiment morte (pas juste despawn)
		IEntity victimEntity = data.GetVictimEntity();
		if (!victimEntity) return;

		SCR_CharacterDamageManagerComponent dmg = SCR_CharacterDamageManagerComponent.Cast(
			victimEntity.FindComponent(SCR_CharacterDamageManagerComponent));
		if (!dmg) return;

		if (dmg.GetState() != EDamageState.DESTROYED) return;

		string uid = CapsuleBootstrap.SessionToUID(killerId);
		economy.OnPlayerKill(uid);
		string x2Str = "";
		if (economy.IsDoubleActive()) x2Str = " [x2]";
		Print("[CapsuleKill] +caps -> joueur uid=" + uid
			+ " | Total: " + economy.GetCapsules(uid).ToString() + x2Str);
	}

	void Tick(float dt) {}
}