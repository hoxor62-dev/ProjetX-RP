/**
 * CapsuleBootstrap.c
 * Point d'entree unique du mod. Placer dans la SubScene de la mission.
 * S'auto-initialise via le constructeur + EOnInit.
 */

class CapsuleBootstrapClass : GenericEntityClass {}

class CapsuleBootstrap : GenericEntity
{
	private static CapsuleBootstrap s_Instance;

	private ref CapsuleEconomyManager	m_EconomyManager;
	private ref CapsuleKillWatcher		m_KillWatcher;

	private float m_fAutosaveTick	= 0.0;
	static const float AUTOSAVE_INTERVAL = 60.0;

	// Map playerId session -> uid persistant (GUID BackendApi)
	private ref map<int, string> m_mSessionToUID = new map<int, string>();

	//------------------------------------------------------------------------------------------------
	// Constructeur - SetEventMask doit etre ici selon la doc officielle Enfusion
	void CapsuleBootstrap(IEntitySource src, IEntity parent)
	{
		SetEventMask(EntityEvent.INIT | EntityEvent.FRAME);
	}

	//------------------------------------------------------------------------------------------------
	static CapsuleBootstrap GetInstance()
	{
		return s_Instance;
	}

	//------------------------------------------------------------------------------------------------
	override void EOnInit(IEntity owner)
	{
		CapsuleConfig.Init();

		super.EOnInit(owner);
		s_Instance = this;

		Print("[Capsule] ================================================");
		Print("[Capsule]  CapsuleEconomy Mod - Demarrage");
		Print("[Capsule] ================================================");

		if (RplSession.Mode() != RplMode.Client)
			InitServer();
	}

	//------------------------------------------------------------------------------------------------
	private void InitServer()
	{
		Print("[Capsule][Server] Initialisation...");

		m_EconomyManager = CapsuleEconomyManager.GetInstance();

		m_KillWatcher = new CapsuleKillWatcher();
		m_KillWatcher.Start();

		GetGame().GetCallqueue().CallLater(WatchPlayerConnections, 1000, true);

		Print("[Capsule][Server] OK");
	}


	//------------------------------------------------------------------------------------------------
	private ref array<int> m_aKnownPlayers = new array<int>();

	private void WatchPlayerConnections()
	{
		if (RplSession.Mode() == RplMode.Client)
			return; // OK - Local et Server passent

		PlayerManager pm = GetGame().GetPlayerManager();
		if (!pm)
			return;

		ref array<int> currentPlayers = new array<int>();
		pm.GetPlayers(currentPlayers);

		foreach (int pid : currentPlayers)
		{
			if (m_aKnownPlayers.Find(pid) == -1)
			{
				m_aKnownPlayers.Insert(pid);
				OnPlayerJoined(pid, pm);
			}
		}

		for (int i = m_aKnownPlayers.Count() - 1; i >= 0; i--)
		{
			int pid = m_aKnownPlayers[i];
			if (currentPlayers.Find(pid) == -1)
			{
				OnPlayerLeft(pid);
				m_aKnownPlayers.Remove(i);
			}
		}
	}

	// Retourne le GUID permanent du joueur (BackendApi) avec fallback sur playerId
	// Le GUID est stable entre redemarrages contrairement au playerId de session
	private string GetPersistentUID(int playerId)
	{
		BackendApi backend = GetGame().GetBackendApi();
		if (backend)
		{
			string guid = backend.GetPlayerIdentityId(playerId);
			if (guid != string.Empty)
				return guid;
		}
		// Fallback : utiliser le nom + playerId (moins ideal mais evite les crashs)
		PlayerManager pm = GetGame().GetPlayerManager();
		string name = "";
		if (pm) name = pm.GetPlayerName(playerId);
		Print("[Capsule] WARN: GUID indisponible pour playerId=" + playerId.ToString() + " name=" + name + ", fallback sur nom", LogLevel.WARNING);
		if (name != string.Empty) return "name_" + name;
		return playerId.ToString();
	}

	private void OnPlayerJoined(int playerId, PlayerManager pm)
	{
		string name = pm.GetPlayerName(playerId);
		// Delai 2s pour laisser le GUID BackendApi se charger
		GetGame().GetCallqueue().CallLater(InitPlayerUID, 2000, false, playerId, name);
		Print("[Capsule][Server] Joueur connecte: " + name + " (session id=" + playerId.ToString() + ")");
	}

	private void InitPlayerUID(int playerId, string name)
	{
		string uid = GetPersistentUID(playerId);

		// Stocker la correspondance session -> uid
		m_mSessionToUID[playerId] = uid;

		// Assigner l'uid au composant du joueur pour que toutes les RPCs l'utilisent
		PlayerManager pm = GetGame().GetPlayerManager();
		if (pm)
		{
			PlayerController pc = pm.GetPlayerController(playerId);
			if (pc)
			{
				CapsulePlayerComponent comp = CapsulePlayerComponent.Cast(pc.FindComponent(CapsulePlayerComponent));
				if (comp) comp.SetUID(uid);
			}
		}

		m_EconomyManager.LoadPlayerData(uid, name);
		m_EconomyManager.OnPlayerConnected(uid, name);
		GetGame().GetCallqueue().CallLater(SyncPlayerHUD, 3000, false, playerId);

		Print("[Capsule][Server] UID resolu: " + name + " -> " + uid);
	}

	private void OnPlayerLeft(int playerId)
	{
		string uid = GetPersistentUID(playerId);
		m_EconomyManager.OnPlayerDisconnected(uid);
		m_mSessionToUID.Remove(playerId);
		Print("[Capsule][Server] Deconnexion uid=" + uid);
	}

	// Convertit un playerId de session en uid persistant (pour KillWatcher)
	static string SessionToUID(int playerId)
	{
		if (!s_Instance) return playerId.ToString();
		if (s_Instance.m_mSessionToUID.Contains(playerId))
			return s_Instance.m_mSessionToUID[playerId];
		return s_Instance.GetPersistentUID(playerId);
	}

	private void SyncPlayerHUD(int playerId)
	{
		PlayerManager pm = GetGame().GetPlayerManager();
		if (!pm) return;

		// CapsulePlayerComponent est sur le PlayerController, pas sur le character
		PlayerController pc = pm.GetPlayerController(playerId);
		if (!pc) return;

		string uid  = GetPersistentUID(playerId);
		int    caps = m_EconomyManager.GetCapsules(uid);

		CapsulePlayerComponent comp =
			CapsulePlayerComponent.Cast(pc.FindComponent(CapsulePlayerComponent));
		if (comp)
		{
			Print("[Capsule][Server] SyncPlayerHUD: envoi " + caps.ToString() + " caps a uid=" + uid);
			comp.Svr_SendCapsules(caps);
		}
		else
			Print("[Capsule][Server] SyncPlayerHUD: CapsulePlayerComponent introuvable sur PlayerController uid=" + uid, LogLevel.WARNING);
	}

	//------------------------------------------------------------------------------------------------
	override void EOnFrame(IEntity owner, float timeSlice)
	{
		// RplMode.Client = client dedie uniquement - pas Local (solo) ni Server
		if (RplSession.Mode() == RplMode.Client)
			return;

		m_fAutosaveTick += timeSlice;
		if (m_fAutosaveTick >= AUTOSAVE_INTERVAL)
		{
			m_fAutosaveTick = 0.0;
			if (m_EconomyManager)
				m_EconomyManager.SaveAllData();
		}


		if (m_KillWatcher)
			m_KillWatcher.Tick(timeSlice);

		// Tick evenement double capsules
		if (m_EconomyManager)
			m_EconomyManager.TickDouble(timeSlice);
	}

	//------------------------------------------------------------------------------------------------
	CapsuleEconomyManager GetEconomy()  { return m_EconomyManager; }

	void ~CapsuleBootstrap()
	{
		if (m_EconomyManager && RplSession.Mode() != RplMode.Client)
			m_EconomyManager.SaveAllData();
		s_Instance = null;
	}
}