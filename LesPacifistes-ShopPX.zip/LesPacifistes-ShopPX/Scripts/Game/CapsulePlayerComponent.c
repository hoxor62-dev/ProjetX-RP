/**
 * CapsulePlayerComponent.c
 * Place sur le PlayerController.
 * m_sUID = GUID persistant initialise par CapsuleBootstrap.OnPlayerJoined
 */

class CapsulePlayerComponentClass : ScriptComponentClass {}

class CapsulePlayerComponent : ScriptComponent
{
	private int    m_iLocalCapsules = 0;
	private string m_sUID           = ""; // GUID persistant - assigne par Bootstrap

	override void OnPostInit(IEntity owner)
	{
		super.OnPostInit(owner);
		Print("[CapsulePlayerComponent] OnPostInit sur: " + owner.ClassName());

		if (!Replication.IsServer())
			GetGame().GetCallqueue().CallLater(Client_RequestCapsules, 2000, true);
	}

	// Appele par Bootstrap apres avoir resolu le GUID
	void SetUID(string uid)
	{
		m_sUID = uid;
		Print("[CapsulePlayerComponent] UID assigne: " + uid);
	}

	string GetUID() { return m_sUID; }

	// Retourne l'uid a utiliser cote serveur (m_sUID si disponible, sinon fallback)
	private string GetServerUID()
	{
		if (m_sUID != string.Empty) return m_sUID;
		// Fallback si SetUID pas encore appele
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (pc) return CapsuleBootstrap.SessionToUID(pc.GetPlayerId());
		return "";
	}

	int GetLocalCapsules()
	{
		if (m_iLocalCapsules == 0 && Replication.IsServer())
		{
			string uid = GetServerUID();
			CapsuleEconomyManager eco = CapsuleEconomyManager.GetInstance();
			if (eco && uid != string.Empty) return eco.GetCapsules(uid);
		}
		return m_iLocalCapsules;
	}

	// CLIENT - demande les capsules au serveur
	private void Client_RequestCapsules()
	{
		Rpc(Server_GetCapsules);
	}

	// SERVEUR - repond avec le vrai solde
	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	private void Server_GetCapsules()
	{
		string uid = GetServerUID();
		if (uid == string.Empty) return;
		int caps = CapsuleEconomyManager.GetInstance().GetCapsules(uid);
		Rpc(Client_ReceiveCapsules, caps);
	}

	// CLIENT - recoit et stocke
	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	private void Client_ReceiveCapsules(int capsules)
	{
		m_iLocalCapsules = capsules;
	}

	// Appele depuis le serveur (Bootstrap) pour pousser le solde initial
	void Svr_SendCapsules(int capsules)
	{
		Rpc(Client_ReceiveCapsules, capsules);
	}

	// Admin : declencher l'evenement double capsules
	void Admin_StartDoubleEvent()
	{
		Rpc(Server_StartDoubleEvent);
	}

	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	private void Server_StartDoubleEvent()
	{
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		CapsuleEconomyManager.GetInstance().StartDoubleEvent();
		NotifyAllPlayers_DoubleEvent();
	}

	private void NotifyAllPlayers_DoubleEvent()
	{
		PlayerManager pm = GetGame().GetPlayerManager();
		if (!pm) return;
		ref array<int> players = new array<int>();
		pm.GetPlayers(players);
		foreach (int pid : players)
		{
			PlayerController pc2 = pm.GetPlayerController(pid);
			if (!pc2) continue;
			CapsulePlayerComponent comp = CapsulePlayerComponent.Cast(pc2.FindComponent(CapsulePlayerComponent));
			if (comp) comp.Svr_SendNotification(true, "EVENEMENT: DOUBLE CAPSULES PENDANT 30 MINUTES!");
		}
	}

	// ---- ACHAT / VENTE ----

	void RequestBuy(string resourceName, int price)
	{
		Rpc(Server_DoBuy, resourceName, price);
	}

	void RequestSell(string resourceName, int sellPrice)
	{
		Print("[CapsulePlayerComponent] RequestSell envoi RPC -> " + resourceName);
		Rpc(Server_DoSell, resourceName, sellPrice);
	}

	void RequestVehicleBuy(string resourceName, int price)
	{
		Rpc(Server_DoVehicleBuy, resourceName, price);
	}

	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	private void Server_DoBuy(string resourceName, int price)
	{
		string uid = GetServerUID();
		if (uid == string.Empty) return;
		Print("[CapsulePlayerComponent] Server_DoBuy uid=" + uid + " item=" + resourceName);

		CapsuleEconomyManager eco = CapsuleEconomyManager.GetInstance();
		if (!eco.TrySpendCapsules(uid, price))
		{
			Rpc(RpcDo_ShowNotification, false, "Capsules insuffisantes!");
			return;
		}
		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc || !SpawnItemForPlayer(pc, resourceName))
		{
			eco.AddCapsules(uid, price);
			Rpc(RpcDo_ShowNotification, false, "Erreur creation item.");
			return;
		}
		Rpc(RpcDo_ShowNotification, true, "Achat OK! -" + price.ToString() + " Capsules");
		Rpc(Client_ReceiveCapsules, eco.GetCapsules(uid));
	}

	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	private void Server_DoSell(string resourceName, int sellPrice)
	{
		string uid = GetServerUID();
		if (uid == string.Empty) return;
		Print("[CapsulePlayerComponent] Server_DoSell uid=" + uid + " item=" + resourceName);

		PlayerController pc = PlayerController.Cast(GetOwner());
		if (!pc) return;
		IEntity playerEnt = pc.GetControlledEntity();
		if (!playerEnt)
		{
			Rpc(RpcDo_ShowNotification, false, "Entite joueur introuvable.");
			return;
		}
		if (!RemoveFromInventory(playerEnt, resourceName))
		{
			Rpc(RpcDo_ShowNotification, false, "Item introuvable.");
			return;
		}
		CapsuleEconomyManager eco = CapsuleEconomyManager.GetInstance();
		eco.AddCapsules(uid, sellPrice);
		Print("[CapsulePlayerComponent] Server_DoSell: +" + sellPrice.ToString() + " caps pour " + uid);
		Rpc(Client_ReceiveCapsules, eco.GetCapsules(uid));
		Rpc(RpcDo_ShowNotification, true, "Vendu! +" + sellPrice.ToString() + " Capsules");
	}

	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	private void Server_DoVehicleBuy(string resourceName, int price)
	{
		string uid = GetServerUID();
		if (uid == string.Empty) return;
		Print("[CapsulePlayerComponent] Server_DoVehicleBuy uid=" + uid);

		CapsuleEconomyManager eco = CapsuleEconomyManager.GetInstance();
		if (!eco.TrySpendCapsules(uid, price))
		{
			Rpc(RpcDo_ShowNotification, false, "Capsules insuffisantes!");
			return;
		}
		PlayerController pc = PlayerController.Cast(GetOwner());
		IEntity playerEnt = null;
		if (pc) playerEnt = pc.GetControlledEntity();
		if (!SpawnVehicleNearPlayer(playerEnt, resourceName))
		{
			eco.AddCapsules(uid, price);
			Rpc(RpcDo_ShowNotification, false, "Impossible de spawner le vehicule.");
			return;
		}
		Rpc(RpcDo_ShowNotification, true, "Vehicule livre! -" + price.ToString() + " Capsules");
	}

	// ---- Helpers spawn ----

	private bool SpawnItemForPlayer(PlayerController pc, string resourceName)
	{
		IEntity playerEnt = pc.GetControlledEntity();
		if (!playerEnt) return false;

		Resource res = Resource.Load(resourceName);
		if (!res || !res.IsValid()) return false;

		EntitySpawnParams p = new EntitySpawnParams();
		p.TransformMode = ETransformMode.WORLD;
		Math3D.MatrixIdentity4(p.Transform);
		p.Transform[3] = playerEnt.GetOrigin() + Vector(0, 1, 0);

		IEntity item = GetGame().SpawnEntityPrefab(res, GetGame().GetWorld(), p);
		if (!item) return false;

		SCR_InventoryStorageManagerComponent inv =
			SCR_InventoryStorageManagerComponent.Cast(
				playerEnt.FindComponent(SCR_InventoryStorageManagerComponent));
		if (inv)
			inv.InsertItem(item);
		else
			item.SetOrigin(playerEnt.GetOrigin() + Vector(1.5, 0.5, 0));

		return true;
	}

	private bool SpawnVehicleNearPlayer(IEntity playerEnt, string resourceName)
	{
		Resource res = Resource.Load(resourceName);
		if (!res || !res.IsValid()) return false;

		vector spawnPos;
		if (playerEnt)
		{
			vector playerDir = playerEnt.GetYawPitchRoll();
			float yawRad = playerDir[0] * Math.DEG2RAD;
			spawnPos = playerEnt.GetOrigin() + Vector(Math.Sin(yawRad) * 10, 0, Math.Cos(yawRad) * 10);
		}

		EntitySpawnParams p = new EntitySpawnParams();
		p.TransformMode = ETransformMode.WORLD;
		Math3D.MatrixIdentity4(p.Transform);
		p.Transform[3] = spawnPos;
		IEntity veh = GetGame().SpawnEntityPrefab(res, GetGame().GetWorld(), p);
		return (veh != null);
	}

	private bool RemoveFromInventory(IEntity playerEnt, string resourceName)
	{
		SCR_InventoryStorageManagerComponent inv =
			SCR_InventoryStorageManagerComponent.Cast(
				playerEnt.FindComponent(SCR_InventoryStorageManagerComponent));
		if (!inv) return false;

		ref array<IEntity> items = new array<IEntity>();
		inv.GetItems(items);

		foreach (IEntity item : items)
		{
			EntityPrefabData pd = item.GetPrefabData();
			if (!pd) continue;
			string prefabLower   = pd.GetPrefabName();
			string resourceLower = resourceName;
			prefabLower.ToLower();
			resourceLower.ToLower();
			if (prefabLower.IndexOf(resourceLower) >= 0 || resourceLower.IndexOf(prefabLower) >= 0)
			{
				inv.TryRemoveItemFromInventory(item);
				SCR_EntityHelper.DeleteEntityAndChildren(item);
				return true;
			}
		}
		return false;
	}

	// ---- Notifications / Zone ----

	void Svr_SendNotification(bool success, string message)
	{
		Rpc(RpcDo_ShowNotification, success, message);
	}

	void Svr_SendZoneMessage(bool entering)
	{
		Rpc(RpcDo_ShowZoneMessage, entering);
	}

	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	protected void RpcDo_ShowNotification(bool success, string message)
	{
		Print("[Capsule] Notification: " + message);
	}

	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	protected void RpcDo_ShowZoneMessage(bool entering)
	{
		if (entering)
			Print("[Capsule] Zone Securisee - PVP desactive");
		else
			Print("[Capsule] Hors zone securisee - PVP actif");
	}

	override void OnDelete(IEntity owner)
	{
		GetGame().GetCallqueue().Remove(Client_RequestCapsules);
		super.OnDelete(owner);
	}
	// ---- TELEPORT (pour systeme Prison / Jobs) ----

// Appele cote serveur - teleporte CE joueur vers les coordonnees
void Svr_TeleportToPosition(float x, float y, float z)
{
    if (!Replication.IsServer()) return;

    Print(string.Format("[TP-SERVER] Svr_TeleportToPosition pos=%1,%2,%3", x, y, z));

    // Teleport cote serveur d'abord (autorite reseau)
    PlayerController pc = PlayerController.Cast(GetOwner());
    if (pc)
    {
        IEntity ent = pc.GetControlledEntity();
        if (ent)
        {
            ent.SetOrigin(Vector(x, y, z));
            ent.Update();
            Print("[TP-SERVER] SetOrigin serveur applique");
        }
    }

    // Puis RPC vers le client owner pour forcer le rendu local
    Rpc(RpcDo_TeleportToPosition, x, y, z);
    Print("[TP-SERVER] RPC Owner envoye");
}

[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
protected void RpcDo_TeleportToPosition(float x, float y, float z)
{
    Print(string.Format("[TP-CLIENT] RPC recu pos=%1,%2,%3", x, y, z));

    IEntity player = SCR_PlayerController.GetLocalControlledEntity();
    if (!player)
    {
        Print("[TP-CLIENT] GetLocalControlledEntity NULL");
        return;
    }

    vector pos = Vector(x, y, z);
    float surfaceY = GetGame().GetWorld().GetSurfaceY(x, z);
    if (surfaceY > pos[1])
        pos[1] = surfaceY + 0.5;

    Print(string.Format("[TP-CLIENT] Pos avant=%1", player.GetOrigin()));
    player.SetOrigin(pos);
    player.Update();
    Print(string.Format("[TP-CLIENT] Pos apres=%1", player.GetOrigin()));
}

}