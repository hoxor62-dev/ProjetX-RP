/**
 * CapsuleLeaderboardComponent.c
 * Composant sur PlayerController.
 * - Affiche le leaderboard sur pression Tab via widgets proceduraux directs
 * - Pas de ChimeraMenuPreset requis - pas de fichier .layout necessaire
 * - Demande les donnees au serveur toutes les 5 secondes via RPC
 *
 * WORKBENCH : Ajouter sur le prefab PlayerController
 */

class CapsuleLeaderboardComponentClass : ScriptComponentClass {}

class CapsuleLeaderboardComponent : ScriptComponent
{
	// Donnees recues du serveur
	private ref array<string> m_aNames    = new array<string>();
	private ref array<int>    m_aCapsules = new array<int>();
	private ref array<int>    m_aKills    = new array<int>();
	private ref array<int>    m_aDeaths   = new array<int>();
	private ref array<bool>   m_aBounty   = new array<bool>();
	private bool  m_bDoubleActive = false;
	private float m_fDoubleTimer  = 0.0;

	// UI
	private Widget     m_wRoot      = null;
	private TextWidget m_wDoubleTw  = null;
	private bool       m_bVisible   = false;

	override void OnPostInit(IEntity owner)
	{
		super.OnPostInit(owner);

		if (!Replication.IsServer())
		{
			SetEventMask(owner, EntityEvent.FRAME);
			GetGame().GetCallqueue().CallLater(Client_RequestLeaderboard, 2000, true);
		}
	}

	override void EOnFrame(IEntity owner, float timeSlice)
	{
		if (Replication.IsServer()) return;

		// Toggle Tab
		if (GetGame().GetInputManager().GetActionTriggered("Scoreboard"))
		{
			if (m_bVisible)
				Hide();
			else
				Show();
		}

		// Fermer sur Echap si visible
		if (m_bVisible && GetGame().GetInputManager().GetActionTriggered("MenuOpen"))
			Hide();

		// Ticker double caps affiche
		if (m_bVisible && m_bDoubleActive)
		{
			m_fDoubleTimer -= timeSlice;
			if (m_fDoubleTimer < 0) m_fDoubleTimer = 0;
			UpdateDoubleText();
		}
	}

	// -- API publique -----------------------------------------------------------

	// Appele depuis CapsuleEscapeMenuButton pour ouvrir le leaderboard
	void ShowLeaderboard()
	{
		if (m_bVisible)
			Hide();
		else
			Show();
	}

	// -- Affichage --------------------------------------------------------------

	private void Show()
	{
		if (m_bVisible) return;
		m_bVisible = true;
		BuildUI();
	}

	private void Hide()
	{
		if (!m_bVisible) return;
		m_bVisible  = false;
		m_wDoubleTw = null;
		if (m_wRoot)
		{
			m_wRoot.RemoveFromHierarchy();
			m_wRoot = null;
		}
	}

	private void BuildUI()
	{
		WorkspaceWidget ws = GetGame().GetWorkspace();
		if (!ws) return;

		int SW = 1280;
		int SH = 720;

		// --- Overlay sombre plein ecran ---
		m_wRoot = ws.CreateWidget(WidgetType.FrameWidgetTypeID,
			WidgetFlags.VISIBLE | WidgetFlags.NOFOCUS,
			Color.FromRGBA(0, 0, 0, 0), 0);
		if (!m_wRoot) return;
		FrameSlot.SetPos(m_wRoot, 0, 0);
		FrameSlot.SetSize(m_wRoot, SW, SH);

		// Vignette semi-transparente
		Widget overlay = ws.CreateWidget(WidgetType.FrameWidgetTypeID,
			WidgetFlags.VISIBLE | WidgetFlags.NOFOCUS,
			Color.FromRGBA(0, 0, 8, 180), 0, m_wRoot);
		FrameSlot.SetPos(overlay, 0, 0);
		FrameSlot.SetSize(overlay, SW, SH);

		// --- Panneau principal centre ---
		int PW = 860;
		int PH = 560;
		int PX = (SW - PW) / 2;
		int PY = (SH - PH) / 2;

		// Ombre portee
		Widget shadow = ws.CreateWidget(WidgetType.FrameWidgetTypeID,
			WidgetFlags.VISIBLE | WidgetFlags.NOFOCUS,
			Color.FromRGBA(0, 0, 0, 160), 0, m_wRoot);
		FrameSlot.SetPos(shadow, PX + 6, PY + 6);
		FrameSlot.SetSize(shadow, PW, PH);

		// Corps du panneau
		Widget panel = ws.CreateWidget(WidgetType.FrameWidgetTypeID,
			WidgetFlags.VISIBLE | WidgetFlags.NOFOCUS,
			Color.FromRGBA(12, 14, 22, 245), 0, m_wRoot);
		FrameSlot.SetPos(panel, PX, PY);
		FrameSlot.SetSize(panel, PW, PH);

		// Bordure exterieure doree
		MakeBorder(ws, panel, PW, PH, Color.FromRGBA(180, 150, 40, 200), 2);

		// --- Bandeau titre ---
		Widget titleBg = ws.CreateWidget(WidgetType.FrameWidgetTypeID,
			WidgetFlags.VISIBLE | WidgetFlags.NOFOCUS,
			Color.FromRGBA(30, 25, 5, 255), 0, panel);
		FrameSlot.SetPos(titleBg, 2, 2);
		FrameSlot.SetSize(titleBg, PW - 4, 48);

		// Ligne accent doree sous le titre
		Widget titleAccent = ws.CreateWidget(WidgetType.FrameWidgetTypeID,
			WidgetFlags.VISIBLE | WidgetFlags.NOFOCUS,
			Color.FromRGBA(220, 180, 40, 255), 0, panel);
		FrameSlot.SetPos(titleAccent, 2, 50);
		FrameSlot.SetSize(titleAccent, PW - 4, 3);

		// Icone capsule + Titre
		MakeText(ws, panel, "C A P S U L E   E C O N O M Y", 0, 12, PW, 28,
			Color.FromRGBA(230, 195, 50, 255), true);

		// Sous-titre / date
		MakeText(ws, panel, "CLASSEMENT DES JOUEURS", 0, 32, PW, 16,
			Color.FromRGBA(140, 120, 60, 200), false);

		// --- En-tetes colonnes ---
		int HDR_Y = 62;
		int HDR_H = 20;
		Color hdrC = Color.FromRGBA(160, 160, 180, 220);

		Widget hdrBg = ws.CreateWidget(WidgetType.FrameWidgetTypeID,
			WidgetFlags.VISIBLE | WidgetFlags.NOFOCUS,
			Color.FromRGBA(20, 20, 35, 200), 0, panel);
		FrameSlot.SetPos(hdrBg, 2, 56);
		FrameSlot.SetSize(hdrBg, PW - 4, 28);

		MakeText(ws, panel, "#",        14,  HDR_Y, 30,  HDR_H, hdrC, false);
		MakeText(ws, panel, "JOUEUR",   52,  HDR_Y, 240, HDR_H, hdrC, false);
		MakeText(ws, panel, "CAPSULES", 310, HDR_Y, 130, HDR_H, hdrC, false);
		MakeText(ws, panel, "KILLS",    450, HDR_Y, 70,  HDR_H, hdrC, false);
		MakeText(ws, panel, "MORTS",    530, HDR_Y, 70,  HDR_H, hdrC, false);
		MakeText(ws, panel, "K/D",      610, HDR_Y, 60,  HDR_H, hdrC, false);
		MakeText(ws, panel, "PRIME",    680, HDR_Y, 80,  HDR_H, hdrC, false);

		// Ligne separatrice sous headers
		Widget sepHdr = ws.CreateWidget(WidgetType.FrameWidgetTypeID,
			WidgetFlags.VISIBLE | WidgetFlags.NOFOCUS,
			Color.FromRGBA(60, 55, 20, 255), 0, panel);
		FrameSlot.SetPos(sepHdr, 2, 84);
		FrameSlot.SetSize(sepHdr, PW - 4, 1);

		// --- Lignes joueurs ---
		int count = m_aNames.Count();
		int ROW_H = 38;
		int ROW_START_Y = 88;

		// Calculer le max de capsules pour la barre de progression
		int maxCaps = 1;
		for (int i = 0; i < count; i++)
		{
			if (i < m_aCapsules.Count() && m_aCapsules[i] > maxCaps)
				maxCaps = m_aCapsules[i];
		}

		if (count == 0)
		{
			MakeText(ws, panel, "Aucun joueur enregistre.", 0, ROW_START_Y + 20, PW, 26,
				Color.FromRGBA(120, 120, 130, 200), false);
		}

		for (int i = 0; i < count && i < 12; i++)
		{
			int rowY = ROW_START_Y + i * ROW_H;

			// Fond de ligne
			Color bgC;
			if (i == 0)      bgC = Color.FromRGBA(50, 40, 5,  200);
			else if (i == 1) bgC = Color.FromRGBA(35, 35, 40, 200);
			else if (i == 2) bgC = Color.FromRGBA(40, 25, 10, 200);
			else if (i % 2 == 0) bgC = Color.FromRGBA(18, 18, 28, 180);
			else             bgC = Color.FromRGBA(14, 14, 22, 180);

			Widget rowBg = ws.CreateWidget(WidgetType.FrameWidgetTypeID,
				WidgetFlags.VISIBLE | WidgetFlags.NOFOCUS, bgC, 0, panel);
			FrameSlot.SetPos(rowBg, 2, rowY);
			FrameSlot.SetSize(rowBg, PW - 4, ROW_H - 1);

			// Barre de progression capsules (fond)
			int caps = 0;
			if (i < m_aCapsules.Count()) caps = m_aCapsules[i];
			int barMaxW = 120;
			int barW = (caps * barMaxW) / maxCaps;
			if (barW < 2) barW = 2;

			Widget barBg = ws.CreateWidget(WidgetType.FrameWidgetTypeID,
				WidgetFlags.VISIBLE | WidgetFlags.NOFOCUS,
				Color.FromRGBA(20, 20, 30, 200), 0, panel);
			FrameSlot.SetPos(barBg, 310, rowY + ROW_H - 8);
			FrameSlot.SetSize(barBg, barMaxW, 4);

			Color barC;
			if (i == 0)      barC = Color.FromRGBA(255, 215, 0,   200);
			else if (i == 1) barC = Color.FromRGBA(192, 192, 192, 200);
			else if (i == 2) barC = Color.FromRGBA(205, 127, 50,  200);
			else             barC = Color.FromRGBA(60,  140, 220,  180);

			Widget barFill = ws.CreateWidget(WidgetType.FrameWidgetTypeID,
				WidgetFlags.VISIBLE | WidgetFlags.NOFOCUS, barC, 0, panel);
			FrameSlot.SetPos(barFill, 310, rowY + ROW_H - 8);
			FrameSlot.SetSize(barFill, barW, 4);

			// Couleur texte selon rang
			Color tc;
			bool hasBounty = (i < m_aBounty.Count()) && m_aBounty[i];
			if (hasBounty)   tc = Color.FromRGBA(255, 90,  90,  255);
			else if (i == 0) tc = Color.FromRGBA(255, 215, 0,   255);
			else if (i == 1) tc = Color.FromRGBA(210, 210, 220, 255);
			else if (i == 2) tc = Color.FromRGBA(220, 140, 60,  255);
			else             tc = Color.FromRGBA(200, 200, 210, 255);

			// Medaille rang
			string rankStr;
			if (i == 0)      rankStr = "[1]";
			else if (i == 1) rankStr = "[2]";
			else if (i == 2) rankStr = "[3]";
			else             rankStr = "#" + (i + 1).ToString();

			string nameStr = "-";
			if (i < m_aNames.Count()) nameStr = m_aNames[i];

			string capsStr = "0 C";
			if (i < m_aCapsules.Count()) capsStr = caps.ToString() + " C";

			string killsStr = "0";
			if (i < m_aKills.Count()) killsStr = m_aKills[i].ToString();

			string deathsStr = "0";
			if (i < m_aDeaths.Count()) deathsStr = m_aDeaths[i].ToString();

			int kills2 = 0;
			if (i < m_aKills.Count()) kills2 = m_aKills[i];

			int deaths2 = 0;
			if (i < m_aDeaths.Count()) deaths2 = m_aDeaths[i];
			string kdStr;
			if (deaths2 == 0)
			{
				kdStr = kills2.ToString() + ".00";
			}
			else
			{
				float kd    = kills2 / (float)deaths2;
				int kdInt   = kd;
				int kdFrac  = (kd - kdInt) * 100;
				if (kdFrac < 0) kdFrac = -kdFrac;
				string frac = kdFrac.ToString();
				if (kdFrac < 10) frac = "0" + frac;
				kdStr = kdInt.ToString() + "." + frac;
			}

			int ty = rowY + 9;
			MakeText(ws, panel, rankStr,   14,  ty, 36,  20, tc, false);
			MakeText(ws, panel, nameStr,   52,  ty, 240, 20, tc, false);
			MakeText(ws, panel, capsStr,   310, ty, 130, 20, tc, false);
			MakeText(ws, panel, killsStr,  450, ty, 70,  20, tc, false);
			MakeText(ws, panel, deathsStr, 530, ty, 70,  20, tc, false);
			MakeText(ws, panel, kdStr,     610, ty, 60,  20, tc, false);
			if (hasBounty)
				MakeText(ws, panel, "! PRIME !", 680, ty, 80, 20,
					Color.FromRGBA(255, 80, 80, 255), false);

			// Separateur leger entre lignes
			Widget sepRow = ws.CreateWidget(WidgetType.FrameWidgetTypeID,
				WidgetFlags.VISIBLE | WidgetFlags.NOFOCUS,
				Color.FromRGBA(35, 35, 50, 150), 0, panel);
			FrameSlot.SetPos(sepRow, 2, rowY + ROW_H - 1);
			FrameSlot.SetSize(sepRow, PW - 4, 1);
		}

		// --- Pied de panneau ---
		Widget footerBg = ws.CreateWidget(WidgetType.FrameWidgetTypeID,
			WidgetFlags.VISIBLE | WidgetFlags.NOFOCUS,
			Color.FromRGBA(10, 10, 16, 240), 0, panel);
		FrameSlot.SetPos(footerBg, 2, PH - 36);
		FrameSlot.SetSize(footerBg, PW - 4, 34);

		Widget footerLine = ws.CreateWidget(WidgetType.FrameWidgetTypeID,
			WidgetFlags.VISIBLE | WidgetFlags.NOFOCUS,
			Color.FromRGBA(60, 55, 20, 200), 0, panel);
		FrameSlot.SetPos(footerLine, 2, PH - 37);
		FrameSlot.SetSize(footerLine, PW - 4, 1);

		MakeText(ws, panel, "[Tab] Fermer  |  Mise a jour automatique toutes les 5s",
			0, PH - 26, PW, 18, Color.FromRGBA(90, 90, 100, 200), false);

		// Bandeau double caps (au dessus du footer)
		Widget dblW = ws.CreateWidget(WidgetType.TextWidgetTypeID,
			WidgetFlags.VISIBLE | WidgetFlags.NOFOCUS,
			Color.FromRGBA(0, 0, 0, 0), 0, panel);
		FrameSlot.SetPos(dblW, 0, PH - 56);
		FrameSlot.SetSize(dblW, PW, 20);
		m_wDoubleTw = TextWidget.Cast(dblW);
		UpdateDoubleText();
	}

	// Dessine un cadre (4 barres) autour d'un widget
	private void MakeBorder(WorkspaceWidget ws, Widget parent, int w, int h, Color c, int thick)
	{
		// haut
		Widget t = ws.CreateWidget(WidgetType.FrameWidgetTypeID, WidgetFlags.VISIBLE | WidgetFlags.NOFOCUS, c, 0, parent);
		FrameSlot.SetPos(t, 0, 0); FrameSlot.SetSize(t, w, thick);
		// bas
		Widget b = ws.CreateWidget(WidgetType.FrameWidgetTypeID, WidgetFlags.VISIBLE | WidgetFlags.NOFOCUS, c, 0, parent);
		FrameSlot.SetPos(b, 0, h - thick); FrameSlot.SetSize(b, w, thick);
		// gauche
		Widget l = ws.CreateWidget(WidgetType.FrameWidgetTypeID, WidgetFlags.VISIBLE | WidgetFlags.NOFOCUS, c, 0, parent);
		FrameSlot.SetPos(l, 0, 0); FrameSlot.SetSize(l, thick, h);
		// droite
		Widget r = ws.CreateWidget(WidgetType.FrameWidgetTypeID, WidgetFlags.VISIBLE | WidgetFlags.NOFOCUS, c, 0, parent);
		FrameSlot.SetPos(r, w - thick, 0); FrameSlot.SetSize(r, thick, h);
	}

	private void UpdateDoubleText()
	{
		if (!m_wDoubleTw) return;
		if (m_bDoubleActive)
		{
			int totalSecs = m_fDoubleTimer;
			int mins = totalSecs / 60;
			int secs = totalSecs - (mins * 60);
			string timeStr = mins.ToString() + "m " + secs.ToString() + "s";
			m_wDoubleTw.SetText("[!] DOUBLE CAPSULES ACTIF - " + timeStr + " restant [!]");
			m_wDoubleTw.SetColor(Color.FromRGBA(255, 220, 0, 255));
			m_wDoubleTw.SetVisible(true);
		}
		else
		{
			m_wDoubleTw.SetVisible(false);
		}
	}

	private void MakeText(WorkspaceWidget ws, Widget parent,
		string text, int x, int y, int w, int h, Color color, bool centered)
	{
		Widget wt = ws.CreateWidget(WidgetType.TextWidgetTypeID,
			WidgetFlags.VISIBLE | WidgetFlags.NOFOCUS,
			Color.FromRGBA(0,0,0,0), 0, parent);
		if (!wt) return;
		FrameSlot.SetPos(wt, x, y);
		FrameSlot.SetSize(wt, w, h);
		TextWidget tw = TextWidget.Cast(wt);
		if (!tw) return;
		tw.SetText(text);
		tw.SetColor(color);
	}

	// -- RPC polling ------------------------------------------------------------

	private void Client_RequestLeaderboard()
	{
		Rpc(Server_GetLeaderboard);
	}

	[RplRpc(RplChannel.Reliable, RplRcver.Server)]
	private void Server_GetLeaderboard()
	{
		CapsuleEconomyManager eco = CapsuleEconomyManager.GetInstance();
		if (!eco) return;

		ref array<ref CapsulePlayerData> players = eco.GetAllPlayers();

		string names    = "";
		string caps     = "";
		string kills    = "";
		string deaths   = "";
		string bounties = "";

		for (int i = 0; i < players.Count(); i++)
		{
			CapsulePlayerData d = players[i];
			if (i > 0)
			{
				names    += "|";
				caps     += "|";
				kills    += "|";
				deaths   += "|";
				bounties += "|";
			}
			names   += d.m_sPlayerName;
			caps    += d.m_iCapsules.ToString();
			kills   += d.m_iTotalKills.ToString();
			deaths  += d.m_iDeaths.ToString();
			string bountyVal = "0";
			if (eco.HasBounty(d.m_sPlayerId)) bountyVal = "1";
			bounties += bountyVal;
		}

		bool  dblActive = eco.IsDoubleActive();
		float dblTimer  = eco.GetDoubleTimer();

		Rpc(Client_ReceiveLeaderboard, names, caps, kills, deaths, bounties, dblActive, dblTimer);
	}

	[RplRpc(RplChannel.Reliable, RplRcver.Owner)]
	private void Client_ReceiveLeaderboard(
		string names, string caps, string kills, string deaths,
		string bounties, bool dblActive, float dblTimer)
	{
		m_aNames.Clear();
		m_aCapsules.Clear();
		m_aKills.Clear();
		m_aDeaths.Clear();
		m_aBounty.Clear();

		ParseStringArray(names,   m_aNames);
		ParseIntArray(caps,       m_aCapsules);
		ParseIntArray(kills,      m_aKills);
		ParseIntArray(deaths,     m_aDeaths);
		ParseBoolArray(bounties,  m_aBounty);

		m_bDoubleActive = dblActive;
		m_fDoubleTimer  = dblTimer;

		// Rafraichir si visible
		if (m_bVisible)
		{
			Hide();
			Show();
		}
	}

	// -- Helpers parsing --------------------------------------------------------

	private void ParseStringArray(string raw, array<string> result)
	{
		if (raw.IsEmpty()) return;
		array<string> parts = new array<string>();
		raw.Split("|", parts, true);
		foreach (string p : parts)
			result.Insert(p);
	}

	private void ParseIntArray(string raw, array<int> result)
	{
		if (raw.IsEmpty()) return;
		array<string> parts = new array<string>();
		raw.Split("|", parts, true);
		foreach (string p : parts)
			result.Insert(p.ToInt());
	}

	private void ParseBoolArray(string raw, array<bool> result)
	{
		if (raw.IsEmpty()) return;
		array<string> parts = new array<string>();
		raw.Split("|", parts, true);
		foreach (string p : parts)
			result.Insert(p == "1");
	}

	override void OnDelete(IEntity owner)
	{
		GetGame().GetCallqueue().Remove(Client_RequestLeaderboard);
		Hide();
		super.OnDelete(owner);
	}
}

// Handler de clic sur le bouton HUD
class CapsuleLbBtnHandler : ScriptedWidgetEventHandler
{
	private CapsuleLeaderboardComponent m_Comp;

	void Init(CapsuleLeaderboardComponent comp)
	{
		m_Comp = comp;
	}

	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (button == 0 && m_Comp)
		{
			m_Comp.ShowLeaderboard();
			return true;
		}
		return false;
	}

	override bool OnMouseButtonDown(Widget w, int x, int y, int button)
	{
		if (button == 0 && m_Comp)
		{
			m_Comp.ShowLeaderboard();
			return true;
		}
		return false;
	}
}