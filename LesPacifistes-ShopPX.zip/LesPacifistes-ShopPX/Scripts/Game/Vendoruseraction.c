/**
 * VendorUserAction.c
 * Prototype confirme par la doc officielle Bohemia :
 * https://community.bistudio.com/wiki/Arma_Reforger:Action_Context_Setup
 *
 * Herite de ScriptedUserAction directement - pas de classe separee.
 * Ajouter dans ActionsManagerComponent du prefab vendeur dans Workbench.
 */

class VendorUserAction : ScriptedUserAction
{
	override void PerformAction(IEntity pOwnerEntity, IEntity pUserEntity)
	{
		// PerformAction peut etre appele cote serveur ET cote tous les clients.
		// On verifie que pUserEntity est bien le joueur LOCAL avant d'ouvrir le menu.
		PlayerController localPC = GetGame().GetPlayerController();
		if (!localPC) return;
		IEntity localChar = localPC.GetControlledEntity();
		if (!localChar) return;

		// Si l'entite qui interagit n'est pas le joueur local, ignorer
		if (localChar != pUserEntity) return;

		VendorNPCComponent vendor =
			VendorNPCComponent.Cast(pOwnerEntity.FindComponent(VendorNPCComponent));
		if (vendor)
			vendor.OnInteractAction(pUserEntity);
	}

	override bool CanBePerformedScript(IEntity user)
	{
		return true;
	}

	override bool CanBeShownScript(IEntity user)
	{
		return true;
	}

	override bool GetActionNameScript(out string outName)
	{
		IEntity owner = GetOwner();
		if (owner)
		{
			VendorNPCComponent vendor =
				VendorNPCComponent.Cast(owner.FindComponent(VendorNPCComponent));
			if (vendor)
			{
				outName = "Parler a " + vendor.GetVendorName();
				return true;
			}
		}
		outName = "Parler au vendeur";
		return true;
	}
}