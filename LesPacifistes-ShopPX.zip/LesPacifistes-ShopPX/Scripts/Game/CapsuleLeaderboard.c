/**
 * CapsuleLeaderboard.c
 * Top 10 joueurs par capsules. Touche Tab, auto-masquage 10s.
 */

class CapsuleLeaderboard
{
	private Widget m_wRoot;
	private bool   m_bVisible   = false;
	private float  m_fHideTimer = 0.0;
	static const float AUTO_HIDE = 10.0;

	//------------------------------------------------------------------------------------------------
	void Toggle()
	{
		if (m_bVisible) Hide(); else Show();
	}

	//------------------------------------------------------------------------------------------------
	void Show()
	{
		if (m_bVisible) return;
		m_bVisible   = true;
		m_fHideTimer = AUTO_HIDE;
		BuildUI();
	}

	//------------------------------------------------------------------------------------------------
	void Hide()
	{
		if (!m_bVisible) return;
		m_bVisible = false;
		if (m_wRoot) { m_wRoot.RemoveFromHierarchy(); m_wRoot = null; }
	}

	//------------------------------------------------------------------------------------------------
	private void BuildUI()
	{
		WorkspaceWidget ws = GetGame().GetWorkspace();
		if (!ws) return;

		m_wRoot = ws.CreateWidget(WidgetType.FrameWidgetTypeID,
			WidgetFlags.VISIBLE | WidgetFlags.NOFOCUS,
			Color.FromRGBA(0, 0, 0, 210), 0);
		FrameSlot.SetPos(m_wRoot, 0.30, 0.08);
		FrameSlot.SetSize(m_wRoot, 0.40, 0.84);

		MakeText(ws, "CLASSEMENT — TOP CAPSULES",
			0.0, 0.0, 1.0, 0.09, Color.FromRGBA(240, 210, 50, 255), 18);

		// En-têtes
		float y = 0.11; float h = 0.08;
		MakeText(ws, "Rang",     0.01, y, 0.19, h-0.01, Color.FromRGBA(180,180,180,255), 12);
		MakeText(ws, "Joueur",   0.21, y, 0.49, h-0.01, Color.FromRGBA(180,180,180,255), 12);
		MakeText(ws, "Capsules", 0.71, y, 0.28, h-0.01, Color.FromRGBA(180,180,180,255), 12);
		y += h;

		ref array<ref CapsulePlayerData> top =
			CapsuleEconomyManager.GetInstance().GetLeaderboard();

		if (top.IsEmpty())
		{
			MakeText(ws, "Aucun joueur enregistré.",
				0.05, 0.45, 0.90, 0.08, Color.FromRGBA(130,130,130,255), 13);
		}

		for (int i = 0; i < top.Count(); i++)
		{
			CapsulePlayerData d = top[i];
			Color c;
			string rank;
			switch (i)
			{
				case 0: c = Color.FromRGBA(255,215,0,255);  rank = "#1"; break;
				case 1: c = Color.FromRGBA(192,192,192,255); rank = "#2"; break;
				case 2: c = Color.FromRGBA(205,127,50,255);  rank = "#3"; break;
				default: c = Color.FromRGBA(220,220,220,255); rank = "#" + (i+1); break;
			}

			MakeText(ws, rank,
				0.01, y, 0.19, h-0.01, c, 13);
			MakeText(ws, d.m_sPlayerName,
				0.21, y, 0.49, h-0.01, c, 12);
			MakeText(ws, d.m_iCapsules.ToString() + " (" + d.m_iTotalKills.ToString() + " kills)",
				0.71, y, 0.28, h-0.01, c, 12);
			y += h;
		}

		MakeText(ws, "Auto-fermeture " + AUTO_HIDE.ToString() + "s | [Tab] masquer",
			0.0, 0.93, 1.0, 0.07, Color.FromRGBA(120,120,120,255), 11);
	}

	//------------------------------------------------------------------------------------------------
	private TextWidget MakeText(WorkspaceWidget ws, string text,
		float x, float y, float sx, float sy, Color color, int size)
	{
		Widget w = ws.CreateWidget(WidgetType.TextWidgetTypeID,
			WidgetFlags.VISIBLE | WidgetFlags.NOFOCUS,
			Color.FromRGBA(0,0,0,0), 0, m_wRoot);
		if (!w) return null;
		FrameSlot.SetPos(w, x, y);
		FrameSlot.SetSize(w, sx, sy);
		TextWidget tw = TextWidget.Cast(w);
		if (!tw) return null;
		tw.SetText(text);
		tw.SetColor(color);
		return tw;
	}

	//------------------------------------------------------------------------------------------------
	void Update(float dt)
	{
		if (!m_bVisible) return;
		m_fHideTimer -= dt;
		if (m_fHideTimer <= 0) { Hide(); return; }
		if (GetGame().GetInputManager().GetActionTriggered("Scoreboard"))
			Hide();
	}
}
