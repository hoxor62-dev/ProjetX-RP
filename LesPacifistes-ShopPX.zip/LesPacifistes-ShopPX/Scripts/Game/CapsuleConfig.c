/**
 * CapsuleConfig.c
 * Catalogue complet - initialise via CapsuleConfig.Init() pour eviter
 * la limite "Too many instructions per function" du compilateur Enfusion.
 * Appeler CapsuleConfig.Init() dans CapsuleBootstrap avant toute utilisation.
 */

class CapsuleItemDef
{
	string m_sResourceName;
	string m_sDisplayName;
	int    m_iBuyPrice;
	int    m_iSellPrice;

	void CapsuleItemDef(string res, string name, int price, int sellPrice = 0)
	{
		m_sResourceName = res;
		m_sDisplayName  = name;
		m_iBuyPrice     = price;
		m_iSellPrice    = sellPrice;
	}
}

class CapsuleConfig
{
	// -- Economie ------------------------------------------------------------
	static const int KILL_REWARD            = 0;
	static const int CAPSULES_PER_KILL      = 0;
	static const int DEATH_PENALTY          = 0;
	static const int SELL_PRICE_WEAPON      = 3; // Minimum - les armes ont maintenant un prix individuel
	static const int KILL_STREAK_THRESHOLD  = 0;
	static const int KILL_STREAK_BONUS      = 0;
	static const float VEHICLE_SPAWN_DISTANCE = 10.0;

	// -- Evenement double capsules --------------------------------------------
	static const float DOUBLE_CAPS_DURATION  = 1800.0; // 30 minutes en secondes

	// -- Systeme de prime -----------------------------------------------------
	static const int BOUNTY_KILL_THRESHOLD   = 0;  // kills pour avoir une prime
	static const int BOUNTY_REWARD           = 0; // capsules bonus pour tuer un joueur avec prime

	// -- Vendeur medical ------------------------------------------------------
	static ref array<ref CapsuleItemDef> MEDICAL_ITEMS = new array<ref CapsuleItemDef>();

	// -- Vendeur nourriture/eau -----------------------------------------------
	static ref array<ref CapsuleItemDef> FOOD_ITEMS   = new array<ref CapsuleItemDef>();
	static ref array<ref CapsuleItemDef> WATER_ITEMS  = new array<ref CapsuleItemDef>();

	// -- Declarations (remplies par Init()) ----------------------------------

	static ref array<ref CapsuleItemDef> WEAPONS_RIFLES = new array<ref CapsuleItemDef>();
	static ref array<ref CapsuleItemDef> WEAPONS_MG = new array<ref CapsuleItemDef>();
	static ref array<ref CapsuleItemDef> WEAPONS_LAUNCHERS = new array<ref CapsuleItemDef>();
	static ref array<ref CapsuleItemDef> AMMO_556 = new array<ref CapsuleItemDef>();
	static ref array<ref CapsuleItemDef> AMMO_545 = new array<ref CapsuleItemDef>();
	static ref array<ref CapsuleItemDef> AMMO_762 = new array<ref CapsuleItemDef>();
	static ref array<ref CapsuleItemDef> OPTICS = new array<ref CapsuleItemDef>();
	static ref array<ref CapsuleItemDef> ATTACHMENTS = new array<ref CapsuleItemDef>();
	static ref array<ref CapsuleItemDef> CLOTHING_BACKPACKS = new array<ref CapsuleItemDef>();
	static ref array<ref CapsuleItemDef> CLOTHING_JACKETS = new array<ref CapsuleItemDef>();
	static ref array<ref CapsuleItemDef> CLOTHING_PANTS = new array<ref CapsuleItemDef>();
	static ref array<ref CapsuleItemDef> CLOTHING_SHIRTS = new array<ref CapsuleItemDef>();
	static ref array<ref CapsuleItemDef> CLOTHING_VESTS = new array<ref CapsuleItemDef>();
	static ref array<ref CapsuleItemDef> CLOTHING_HEADGEAR = new array<ref CapsuleItemDef>();
	static ref array<ref CapsuleItemDef> VEHICLES_HELI_UH1 = new array<ref CapsuleItemDef>();
	static ref array<ref CapsuleItemDef> VEHICLES_WHEELED_US = new array<ref CapsuleItemDef>();
	static ref array<ref CapsuleItemDef> VEHICLES_WHEELED_SOV = new array<ref CapsuleItemDef>();
	static ref array<ref CapsuleItemDef> VEHICLES_CIV = new array<ref CapsuleItemDef>();
	static ref array<ref CapsuleItemDef> VEHICLES_DLC = new array<ref CapsuleItemDef>();

	static ref array<ref CapsuleItemDef> BM_WEAPONS    = new array<ref CapsuleItemDef>();
	static ref array<ref CapsuleItemDef> BM_MAGAZINES  = new array<ref CapsuleItemDef>();
	static ref array<ref CapsuleItemDef> BM_OPTICS     = new array<ref CapsuleItemDef>();
	static ref array<ref CapsuleItemDef> BM_ATTACHMENTS = new array<ref CapsuleItemDef>();

	static bool s_bInitialized = false;

	private static void Init_WEAPONS_RIFLES_Part0(array<ref CapsuleItemDef> arr)
	{
		arr.Insert(new CapsuleItemDef("{FA5C25BF66A53DCF}Prefabs/Weapons/Rifles/AK74/Rifle_AK74.et",                  "AK-74",              32, 3));
		arr.Insert(new CapsuleItemDef("{96DFD2E7E63B3386}Prefabs/Weapons/Rifles/AK74/Rifle_AK74N.et",                 "AK-74N",            40, 3));
		arr.Insert(new CapsuleItemDef("{63E8322E2ADD4AA7}Prefabs/Weapons/Rifles/AK74/Rifle_AK74_GP25.et",             "AK-74 GP-25",       56, 3));
		arr.Insert(new CapsuleItemDef("{43D001A8797EA5C9}Prefabs/Weapons/Rifles/AK74/Variants/Rifle_AK74N_PBS4.et",   "AK-74N PBS-4",      52, 3));
		arr.Insert(new CapsuleItemDef("{3E413771E1834D2F}Prefabs/Weapons/Rifles/M16/Rifle_M16A2.et",                  "M16A2",              32, 3));
		arr.Insert(new CapsuleItemDef("{B1482FB64E3D2D45}Prefabs/Weapons/Rifles/M16/Rifle_M16A2_4x20.et",             "M16A2 4x20",        44, 3));
		arr.Insert(new CapsuleItemDef("{F97A4AC994231900}Prefabs/Weapons/Rifles/M16/Rifle_M16A2_carbine.et",          "M16A2 Carbine",      36, 3));
		arr.Insert(new CapsuleItemDef("{B31929F65F0D0279}Prefabs/Weapons/Rifles/M14/Rifle_M21.et",                    "M21",               48, 3));
		arr.Insert(new CapsuleItemDef("{3EB02CDAD5F23C82}Prefabs/Weapons/Rifles/SVD/Rifle_SVD.et",                    "SVD",               56, 3));
	}

	private static void Init_WEAPONS_RIFLES_Part1(array<ref CapsuleItemDef> arr)
	{
		arr.Insert(new CapsuleItemDef("{6415B7923DE28C1B}Prefabs/Weapons/Rifles/SVD/Rifle_SVD_PSO.et",                "SVD PSO-1",         64, 4));
		arr.Insert(new CapsuleItemDef("{9C948630078D154D}Prefabs/Weapons/Rifles/VZ58/Rifle_VZ58P.et",                 "VZ-58P",             32, 3));
		arr.Insert(new CapsuleItemDef("{443CEFF17E040B11}Prefabs/Weapons/Rifles/VZ58/Rifle_VZ58V.et",                 "VZ-58V",             32, 3));
	}

	private static void Init_WEAPONS_RIFLES(array<ref CapsuleItemDef> arr)
	{
		Init_WEAPONS_RIFLES_Part0(arr);
		Init_WEAPONS_RIFLES_Part1(arr);
	}

	private static void Init_WEAPONS_MG_Part0(array<ref CapsuleItemDef> arr)
	{
		arr.Insert(new CapsuleItemDef("{D2B48DEBEF38D7D7}Prefabs/Weapons/MachineGuns/M249/MG_M249.et",               "M249",              80, 5));
		arr.Insert(new CapsuleItemDef("{D182DCDD72BF7E34}Prefabs/Weapons/MachineGuns/M60/MG_M60.et",                 "M60",               80, 5));
		arr.Insert(new CapsuleItemDef("{A89BC9D55FFB4CD8}Prefabs/Weapons/MachineGuns/PKM/MG_PKM.et",                 "PKM",               80, 5));
		arr.Insert(new CapsuleItemDef("{80CBC9A8D95A8A7B}Prefabs/Weapons/MachineGuns/PKM/MG_PKMN.et",                "PKMN",              88, 5));
		arr.Insert(new CapsuleItemDef("{A7AF84C6C58BA3E8}Prefabs/Weapons/MachineGuns/RPK74/MG_RPK74.et",             "RPK-74",            64, 4));
		arr.Insert(new CapsuleItemDef("{5F365605E36597FB}Prefabs/Weapons/MachineGuns/RPK74/MG_RPK74N.et",            "RPK-74N",           72, 4));
		arr.Insert(new CapsuleItemDef("{026CE108BFB3EC03}Prefabs/Weapons/MachineGuns/UK59/MG_UK59.et",               "UK-59",             72, 4));
		arr.Insert(new CapsuleItemDef("{B5B2CD276A3BDB08}Prefabs/Weapons/MachineGuns/UK59/MG_UK59_4x8.et",           "UK-59 4x8",         80, 5));
	}

	private static void Init_WEAPONS_MG(array<ref CapsuleItemDef> arr)
	{
		Init_WEAPONS_MG_Part0(arr);
	}

	private static void Init_WEAPONS_LAUNCHERS_Part0(array<ref CapsuleItemDef> arr)
	{
		arr.Insert(new CapsuleItemDef("{9C5C20FB0E01E64F}Prefabs/Weapons/Launchers/M72/Launcher_M72A3.et",           "M72A3 LAW",         72, 4));
		arr.Insert(new CapsuleItemDef("{722CE6FEC39EE896}Prefabs/Weapons/Launchers/RPG22/Launcher_RPG22.et",         "RPG-22",            72, 4));
		arr.Insert(new CapsuleItemDef("{7A82FE978603F137}Prefabs/Weapons/Launchers/RPG7/Launcher_RPG7.et",           "RPG-7",             88, 5));
		arr.Insert(new CapsuleItemDef("{7C45EC94C698246B}Prefabs/Weapons/Launchers/RPG75/Launcher_RPG75.et",         "RPG-75",            72, 4));
	}

	private static void Init_WEAPONS_LAUNCHERS(array<ref CapsuleItemDef> arr)
	{
		Init_WEAPONS_LAUNCHERS_Part0(arr);
	}

	private static void Init_AMMO_556_Part0(array<ref CapsuleItemDef> arr)
	{
		arr.Insert(new CapsuleItemDef("{FB5EB0F6D447E858}Prefabs/Weapons/Magazines/Magazine_556x45_STANAG_30rnd_M193_Ball.et",    "STANAG 30rnd M193",  12));
		arr.Insert(new CapsuleItemDef("{2EBF60EF24B108FC}Prefabs/Weapons/Magazines/Magazine_556x45_STANAG_30rnd_M855_Ball.et",    "STANAG 30rnd M855",  12));
		arr.Insert(new CapsuleItemDef("{06D722FC2666EB83}Prefabs/Weapons/Magazines/Box_556x45_M249_200rnd_4Ball_1Tracer.et",      "M249 200rnd",        32));
	}

	private static void Init_AMMO_556(array<ref CapsuleItemDef> arr)
	{
		Init_AMMO_556_Part0(arr);
	}

	private static void Init_AMMO_545_Part0(array<ref CapsuleItemDef> arr)
	{
		arr.Insert(new CapsuleItemDef("{BBB50A815A2F916B}Prefabs/Weapons/Magazines/Magazine_545x39_AK_30rnd_Ball.et",             "AK 30rnd Ball",      12));
		arr.Insert(new CapsuleItemDef("{E5912E45754CD421}Prefabs/Weapons/Magazines/Magazine_545x39_AK_30rnd_Tracer.et",           "AK 30rnd Tracer",    12));
		arr.Insert(new CapsuleItemDef("{D78C667F59829717}Prefabs/Weapons/Magazines/Magazine_545x39_RPK_45rnd_4Ball_1Tracer.et",   "RPK 45rnd",          20));
		arr.Insert(new CapsuleItemDef("{BC74DAC891D48540}Prefabs/Weapons/Magazines/Magazine_545x39_RPK_45rnd_Ball.et",            "RPK 45rnd Ball",     20));
	}

	private static void Init_AMMO_545(array<ref CapsuleItemDef> arr)
	{
		Init_AMMO_545_Part0(arr);
	}

	private static void Init_AMMO_762_Part0(array<ref CapsuleItemDef> arr)
	{
		arr.Insert(new CapsuleItemDef("{BCB5E5C608ECFF50}Prefabs/Weapons/Magazines/Magazine_762x51_M14_20rnd_M80.et",             "M14 20rnd M80",      16));
		arr.Insert(new CapsuleItemDef("{C319540BC96AE9BB}Prefabs/Weapons/Magazines/Magazine_762x51_M14_20rnd_M61_AP.et",          "M14 20rnd AP",       20));
		arr.Insert(new CapsuleItemDef("{77595CB9F596E6AC}Prefabs/Weapons/Magazines/Magazine_762x54_SVD_10rnd_LPS.et",             "SVD 10rnd LPS",      16));
		arr.Insert(new CapsuleItemDef("{9CCB46C6EE632C1A}Prefabs/Weapons/Magazines/Magazine_762x54_SVD_10rnd_Sniper.et",          "SVD 10rnd Sniper",   24));
		arr.Insert(new CapsuleItemDef("{19600CCA33279D20}Prefabs/Weapons/Magazines/Magazine_762x54_SVD_10rnd_7BZ3API.et",         "SVD 10rnd API",      24));
		arr.Insert(new CapsuleItemDef("{48720FC416263FC1}Prefabs/Weapons/Magazines/Vz58/Magazine_762x39_Vz58_30rnd_Ball.et",      "VZ58 30rnd Ball",    12));
		arr.Insert(new CapsuleItemDef("{E5E9C5897CF47F44}Prefabs/Weapons/Magazines/Box_762x54_PK_100rnd_4Ball_1Tracer.et",        "PK 100rnd",          28));
		arr.Insert(new CapsuleItemDef("{1C260E65B7F290BA}Prefabs/Weapons/Magazines/Box_762x54_PK_250rnd_Ball.et",                 "PK 250rnd Ball",    56));
		arr.Insert(new CapsuleItemDef("{982F5BA41A3738CF}Prefabs/Weapons/Magazines/Box_762x51_M60_100rnd_Ball.et",                "M60 100rnd Ball",    28));
		arr.Insert(new CapsuleItemDef("{3D9AD4314FE34F5B}Prefabs/Weapons/Magazines/Box_762x51_M60_500rnd_Ball.et",                "M60 500rnd Ball",   100));
	}

	private static void Init_AMMO_762(array<ref CapsuleItemDef> arr)
	{
		Init_AMMO_762_Part0(arr);
	}

	private static void Init_OPTICS_Part0(array<ref CapsuleItemDef> arr)
	{
		arr.Insert(new CapsuleItemDef("{08286DDBB1F33FF1}Prefabs/Weapons/Attachments/Optics/Optic_AP2k/Collim_AP2k.et",           "Collim AP2k",        16));
		arr.Insert(new CapsuleItemDef("{BD496EE1B40DC510}Prefabs/Weapons/Attachments/Optics/Optic_4x20/Optic_4x20.et",            "Optic 4x20",         24));
		arr.Insert(new CapsuleItemDef("{C850A33226B8F9C1}Prefabs/Weapons/Attachments/Optics/Optic_PSO1/Optic_PSO1.et",            "PSO-1",              24));
		arr.Insert(new CapsuleItemDef("{D2018EDB1BBF4C88}Prefabs/Weapons/Attachments/Optics/Optic_ARTII/Optic_ARTII.et",          "ARTII Scope",        32));
		arr.Insert(new CapsuleItemDef("{ACDF49FACD0701A8}Prefabs/Weapons/Attachments/Optics/Optic_1P29/Optic_1P29.et",            "1P29",               24));
		arr.Insert(new CapsuleItemDef("{886A96EF3F14BCD2}Prefabs/Weapons/Attachments/Optics/UK59_4x8/Optic_UK59_4x8.et",          "UK59 4x8",           20));
	}

	private static void Init_OPTICS(array<ref CapsuleItemDef> arr)
	{
		Init_OPTICS_Part0(arr);
	}

	private static void Init_ATTACHMENTS_Part0(array<ref CapsuleItemDef> arr)
	{
		arr.Insert(new CapsuleItemDef("{3B96FAC169E27037}Prefabs/Weapons/Attachments/Muzzle/Suppressor_PBS4/Suppressor_PBS4.et",  "Silencieux PBS-4",   20));
		arr.Insert(new CapsuleItemDef("{E52C9791E1554A5F}Prefabs/Weapons/Attachments/Muzzle/Suppressor_M16/Suppressor_M16.et",   "Silencieux M16",     20));
		arr.Insert(new CapsuleItemDef("{1ABABE3551512B0A}Prefabs/Weapons/Attachments/Underbarrel/UGL_GP25.et",                    "GP-25",              24));
		arr.Insert(new CapsuleItemDef("{43FDAF3FA0FF2299}Prefabs/Weapons/Attachments/Underbarrel/UGL_M203_long.et",               "M203 Long",          24));
		arr.Insert(new CapsuleItemDef("{AB268D088F2D6291}Prefabs/Weapons/Attachments/Underbarrel/UGL_M203_short.et",              "M203 Short",         24));
		arr.Insert(new CapsuleItemDef("{98C79F5FAE12F9B6}Prefabs/Weapons/Attachments/Bayonets/Bayonet_6Kh4.et",                   "Baionnette 6Kh4",    8));
		arr.Insert(new CapsuleItemDef("{558117556F3880A8}Prefabs/Weapons/Attachments/Bayonets/Bayonet_M9.et",                     "Baionnette M9",      8));
	}

	private static void Init_ATTACHMENTS(array<ref CapsuleItemDef> arr)
	{
		Init_ATTACHMENTS_Part0(arr);
	}

	private static void Init_CLOTHING_BACKPACKS_Part0(array<ref CapsuleItemDef> arr)
	{
		arr.Insert(new CapsuleItemDef("{06B68C58B72EAAC6}Prefabs/Items/Equipment/Backpacks/Backpack_ALICE_Medium.et",             "Sac ALICE Medium",       16));
		arr.Insert(new CapsuleItemDef("{5C5C6EE05EE2FF1A}Prefabs/Items/Equipment/Backpacks/Backpack_ALICE_Medium_assembled.et",  "Sac ALICE Assemble",     20));
		arr.Insert(new CapsuleItemDef("{841162A79157C494}Prefabs/Items/Equipment/Backpacks/Backpack_ALICE_Medium_frame.et",      "Sac ALICE Frame",        12));
		arr.Insert(new CapsuleItemDef("{95D4766BBE46F23D}Prefabs/Items/Equipment/Backpacks/Backpack_IIFS_FieldPack.et",          "Sac IIFS FieldPack",     20));
		arr.Insert(new CapsuleItemDef("{41A9C55B61F375F0}Prefabs/Items/Equipment/Backpacks/Backpack_Kolobok.et",                 "Sac Kolobok",            12));
		arr.Insert(new CapsuleItemDef("{FDA7B6630DB87991}Prefabs/Items/Equipment/Backpacks/Backpack_M70_Swiss.et",               "Sac M70 Swiss",          16));
		arr.Insert(new CapsuleItemDef("{4805E67E2AE30F8D}Prefabs/Items/Equipment/Backpacks/Backpack_Medical_M5.et",              "Sac Medical M5",         20));
		arr.Insert(new CapsuleItemDef("{7AC107CA7AFC9B59}Prefabs/Items/Equipment/Backpacks/Backpack_Medical_Soviet.et",          "Sac Medical Soviet.",    20));
		arr.Insert(new CapsuleItemDef("{79015191C0E77E48}Prefabs/Items/Equipment/Backpacks/Backpack_Medical_Soviet_02.et",       "Sac Medical Sov. 02",   20));
		arr.Insert(new CapsuleItemDef("{AC298BA8A7D27007}Prefabs/Items/Equipment/Backpacks/Backpack_Medical_Soviet_NoCross_01.et","Sac Med. Sov. NC 01",  16));
		arr.Insert(new CapsuleItemDef("{E90F2EB67A9CF49A}Prefabs/Items/Equipment/Backpacks/Backpack_Medical_Soviet_NoCross_02.et","Sac Med. Sov. NC 02",  16));
		arr.Insert(new CapsuleItemDef("{6A39B5843B3F36DA}Prefabs/Items/Equipment/Backpacks/Backpack_RPG_Assistant.et",           "Sac RPG Assistant",      16));
		arr.Insert(new CapsuleItemDef("{26223738A07F8202}Prefabs/Items/Equipment/Backpacks/Backpack_RPG_Assistant_Black.et",     "Sac RPG Asst. Noir",    16));
		arr.Insert(new CapsuleItemDef("{0D39750E5695B9D8}Prefabs/Items/Equipment/Backpacks/Backpack_RPG_Gunner.et",              "Sac RPG Gunner",         16));
		arr.Insert(new CapsuleItemDef("{9A201604DEF3BAAC}Prefabs/Items/Equipment/Backpacks/Backpack_RPG_Gunner_Black.et",        "Sac RPG Gunner Noir",    16));
	}

	private static void Init_CLOTHING_BACKPACKS_Part1(array<ref CapsuleItemDef> arr)
	{
		arr.Insert(new CapsuleItemDef("{3DE0155EC9767B98}Prefabs/Items/Equipment/Backpacks/Backpack_Veshmeshok.et",              "Sac Veshmeshok",         12));
		arr.Insert(new CapsuleItemDef("{443304F1EC50BC27}Prefabs/Items/Equipment/Backpacks/Backpack_Veshmeshok_Black.et",        "Sac Veshmeshok Noir",    12));
	}

	private static void Init_CLOTHING_BACKPACKS(array<ref CapsuleItemDef> arr)
	{
		Init_CLOTHING_BACKPACKS_Part0(arr);
		Init_CLOTHING_BACKPACKS_Part1(arr);
	}

	private static void Init_CLOTHING_JACKETS_Part0(array<ref CapsuleItemDef> arr)
	{
		arr.Insert(new CapsuleItemDef("{43D84EA05C66258C}Prefabs/Characters/Uniforms/Jacket_Denim_01/Jacket_Denim_01_base.et",           "Veste Denim",              8));
		arr.Insert(new CapsuleItemDef("{27162F1F6EE6581A}Prefabs/Characters/Uniforms/Jacket_Denim_01/Jacket_Denim_01_brownShirt.et",     "Veste Denim Marron",       8));
		arr.Insert(new CapsuleItemDef("{EB0D74A43F74B522}Prefabs/Characters/Uniforms/Jacket_Denim_01/Jacket_Denim_01_strippedShirt.et",  "Veste Denim Rayee",        8));
		arr.Insert(new CapsuleItemDef("{23A15812C40D34C2}Prefabs/Characters/Uniforms/Jacket_Denim_01/Jacket_Denim_01_strippedShirt_dirty.et","Veste Denim Rayee Sale",8));
		arr.Insert(new CapsuleItemDef("{F1E29085C62F0D55}Prefabs/Characters/Uniforms/Jacket_KZS/Jacket_KZS.et",                          "Veste KZS",                12));
		arr.Insert(new CapsuleItemDef("{142C7FDCD70C3BC7}Prefabs/Characters/Uniforms/Jacket_KZS/Jacket_KZS_base.et",                     "Veste KZS Base",           12));
		arr.Insert(new CapsuleItemDef("{BBA08EC4EC40FA94}Prefabs/Characters/Uniforms/Jacket_M70.et",                                     "Veste M70",                12));
		arr.Insert(new CapsuleItemDef("{CA27CA71B3AF2FCF}Prefabs/Characters/Uniforms/Jacket_M70_base.et",                                "Veste M70 Base",           12));
		arr.Insert(new CapsuleItemDef("{9F546CCA2582D16F}Prefabs/Characters/Uniforms/Jacket_M88.et",                                     "Veste M88",                12));
		arr.Insert(new CapsuleItemDef("{E44990162EBC47B7}Prefabs/Characters/Uniforms/Jacket_M88_base.et",                                "Veste M88 Base",           12));
		arr.Insert(new CapsuleItemDef("{D262D2102B9931C6}Prefabs/Characters/Uniforms/Jacket_M88_rolledup.et",                            "Veste M88 Retroussee",     12));
		arr.Insert(new CapsuleItemDef("{F6C7806DBBF26C50}Prefabs/Characters/Uniforms/Jacket_M88_rolledup_TTsKO.et",                      "Veste M88 TTsKO Ret.",    12));
		arr.Insert(new CapsuleItemDef("{ED9FFC8C35C98B8B}Prefabs/Characters/Uniforms/Jacket_M88_TTsKO.et",                               "Veste M88 TTsKO",          12));
		arr.Insert(new CapsuleItemDef("{FD39B0B833BB927E}Prefabs/Characters/Uniforms/Jacket_Raincoat_01/Jacket_Raincoat_01_yellow.et",   "Impermeable Jaune",        8));
		arr.Insert(new CapsuleItemDef("{7F1451790F3D75BD}Prefabs/Characters/Uniforms/Jacket_Raincoat_01/Jacket_Raincoat_01_green.et",    "Impermeable Vert",         8));
	}

	private static void Init_CLOTHING_JACKETS_Part1(array<ref CapsuleItemDef> arr)
	{
		arr.Insert(new CapsuleItemDef("{690819A92A3A8D14}Prefabs/Characters/Uniforms/Jacket_Raincoat_01/Jacket_Raincoat_01_orange.et",   "Impermeable Orange",       8));
		arr.Insert(new CapsuleItemDef("{C472D4DFBF3652EB}Prefabs/Characters/Uniforms/Jacket_Raincoat_01/Jacket_Raincoat_01_base.et",     "Impermeable Base",         8));
		arr.Insert(new CapsuleItemDef("{702F013CB1492541}Prefabs/Characters/Uniforms/Jacket_Suit_01/Jacket_Suit_01_base.et",             "Veste Costume Base",       12));
		arr.Insert(new CapsuleItemDef("{AE93D885FDF713D4}Prefabs/Characters/Uniforms/Jacket_Suit_01/Jacket_Suit_01_black_V1.et",         "Veste Costume Noire",      12));
		arr.Insert(new CapsuleItemDef("{52AB6EC3FE535303}Prefabs/Characters/Uniforms/Jacket_Suit_01/Jacket_Suit_01_Brown_V1.et",         "Veste Costume Marron",     12));
		arr.Insert(new CapsuleItemDef("{E652D625A46A00FC}Prefabs/Characters/Uniforms/Jacket_Suit_01/Jacket_Suit_01_Grey_V1.et",          "Veste Costume Grise",      12));
		arr.Insert(new CapsuleItemDef("{C7861F11D5334C0E}Prefabs/Characters/Uniforms/Jacket_US_BDU.et",                                  "Veste US BDU",             12));
		arr.Insert(new CapsuleItemDef("{293F577C298061E3}Prefabs/Characters/Uniforms/Jacket_US_BDU_02.et",                               "Veste US BDU 02",          12));
		arr.Insert(new CapsuleItemDef("{8A5424D1A2AA6595}Prefabs/Characters/Uniforms/Jacket_US_BDU_base.et",                             "Veste US BDU Base",        12));
		arr.Insert(new CapsuleItemDef("{3CCA7A9BB4FD3197}Prefabs/Characters/Uniforms/Jacket_US_BDU_rolledup.et",                         "Veste US BDU Ret.",        12));
		arr.Insert(new CapsuleItemDef("{A080C1AEBF921DC4}Prefabs/Characters/Uniforms/Jacket_US_BDU_rolledup_02.et",                      "Veste US BDU Ret. 02",    12));
		arr.Insert(new CapsuleItemDef("{3D17E4FA8F819ECD}Prefabs/Characters/Uniforms/Jacket_US_BDU_TigerStripe.et",                      "Veste US BDU Tiger",       12));
		arr.Insert(new CapsuleItemDef("{86BBBEFE6A2F7B5A}Prefabs/Characters/Uniforms/Jacket_US_BDU_rolledup_TigerStripe.et",             "Veste US BDU Tiger Ret.", 12));
		arr.Insert(new CapsuleItemDef("{6835DAF42A09E23C}Prefabs/Characters/Uniforms/Jacket_Pilot_USSR_01/Jacket_Pilot_USSR_01.et",      "Veste Pilote URSS",        16));
		arr.Insert(new CapsuleItemDef("{2C65F4899E862CF8}Prefabs/Characters/Uniforms/Jacket_Pilot_USSR_01/Jacket_Pilot_USSR_01_base.et", "Veste Pilote URSS Base",   16));
	}

	private static void Init_CLOTHING_JACKETS_Part2(array<ref CapsuleItemDef> arr)
	{
		arr.Insert(new CapsuleItemDef("{78C9B02C0CBD594C}Prefabs/Characters/Uniforms/Jacket_Tanker_USSR_01/Jacket_Tanker_USSR_01.et",    "Veste Tankiste URSS",      16));
		arr.Insert(new CapsuleItemDef("{811F94F506F33434}Prefabs/Characters/Uniforms/Jacket_Tanker_USSR_01/Jacket_Tanker_USSR_01_base.et","Veste Tankiste URSS Base", 16));
		arr.Insert(new CapsuleItemDef("{CC2BAD4EACC9B2CA}Prefabs/Characters/Uniforms/Jacket_TAZ83/Jacket_TAZ83_01.et",                   "Veste TAZ-83",             12));
		arr.Insert(new CapsuleItemDef("{F35797681C868474}Prefabs/Characters/Uniforms/Jacket_TAZ83/Jacket_TAZ83_01_base.et",              "Veste TAZ-83 Base",        12));
		arr.Insert(new CapsuleItemDef("{CF221A167DE87E57}Prefabs/Characters/Uniforms/Suit_KLMK/Suit_KLMK.et",                            "Combinaison KLMK",         16));
		arr.Insert(new CapsuleItemDef("{C499775D8187F213}Prefabs/Characters/Uniforms/Suit_KLMK/Suit_KLMK_base.et",                       "Combinaison KLMK Base",    16));
		arr.Insert(new CapsuleItemDef("{B137B7CE988557D2}Prefabs/Characters/Uniforms/Suit_Pilot_US_01/Suit_Pilot_US_01.et",              "Combi Pilote US",          16));
		arr.Insert(new CapsuleItemDef("{E8F48DA5F61F0550}Prefabs/Characters/Uniforms/Suit_Pilot_US_01/Suit_Pilot_US_01_base.et",         "Combi Pilote US Base",     16));
		arr.Insert(new CapsuleItemDef("{1D99585CF8E34D91}Prefabs/Characters/Uniforms/Suit_Tanker_US_01/Suit_Tanker_US_01.et",            "Combi Tankiste US",        16));
		arr.Insert(new CapsuleItemDef("{80D4145C00839362}Prefabs/Characters/Uniforms/Suit_Tanker_US_01/Suit_Tanker_US_01_base.et",       "Combi Tankiste US Base",   16));
		arr.Insert(new CapsuleItemDef("{A4145024AE7084F6}Prefabs/Characters/Uniforms/Suit_Tanker_US_01/Suit_Tanker_US_01_tucked.et",     "Combi Tankiste US Ret.",  16));
	}

	private static void Init_CLOTHING_JACKETS(array<ref CapsuleItemDef> arr)
	{
		Init_CLOTHING_JACKETS_Part0(arr);
		Init_CLOTHING_JACKETS_Part1(arr);
		Init_CLOTHING_JACKETS_Part2(arr);
	}

	private static void Init_CLOTHING_PANTS_Part0(array<ref CapsuleItemDef> arr)
	{
		arr.Insert(new CapsuleItemDef("{5E17C1AE66A6FF00}Prefabs/Characters/Uniforms/Pants_KZS/Pants_KZS.et",                                "Pantalon KZS",            8));
		arr.Insert(new CapsuleItemDef("{35CD089B528BB7C5}Prefabs/Characters/Uniforms/Pants_KZS/Pants_KZS_base.et",                           "Pantalon KZS Base",       8));
		arr.Insert(new CapsuleItemDef("{7E45E8E203507300}Prefabs/Characters/Uniforms/Pants_M88_TTsKO.et",                                     "Pantalon M88 TTsKO",      8));
		arr.Insert(new CapsuleItemDef("{DCF980831E880F6A}Prefabs/Characters/Uniforms/Pants_M88.et",                                           "Pantalon M88",            8));
		arr.Insert(new CapsuleItemDef("{4EF74D1922997E84}Prefabs/Characters/Uniforms/Pants_M88_base.et",                                      "Pantalon M88 Base",       8));
		arr.Insert(new CapsuleItemDef("{06BC3F18B47799AE}Prefabs/Characters/Uniforms/Pants_M70.et",                                           "Pantalon M70",            8));
		arr.Insert(new CapsuleItemDef("{6099177EBF8A16FC}Prefabs/Characters/Uniforms/Pants_M70_base.et",                                      "Pantalon M70 Base",       8));
		arr.Insert(new CapsuleItemDef("{4DC4FD2F6D353B12}Prefabs/Characters/Uniforms/Pants_M70_Dirty.et",                                     "Pantalon M70 Sale",       4));
		arr.Insert(new CapsuleItemDef("{604BB72BE8E023C2}Prefabs/Characters/Uniforms/Pants_US_BDU.et",                                        "Pantalon US BDU",         8));
		arr.Insert(new CapsuleItemDef("{27DABFBB719485AA}Prefabs/Characters/Uniforms/Pants_US_BDU_base.et",                                   "Pantalon US BDU Base",    8));
		arr.Insert(new CapsuleItemDef("{C6BE0A871E7DE807}Prefabs/Characters/Uniforms/Pants_US_BDU_TigerStripe.et",                            "Pantalon US Tiger",       8));
		arr.Insert(new CapsuleItemDef("{86BB79B9A2233780}Prefabs/Characters/Uniforms/Pants_US_M65.et",                                        "Pantalon US M65",         8));
		arr.Insert(new CapsuleItemDef("{27364244288DA83B}Prefabs/Characters/Uniforms/Pants_TAZ83/Pants_TAZ83_01.et",                          "Pantalon TAZ-83",         8));
		arr.Insert(new CapsuleItemDef("{C65A53E8FCF6E57A}Prefabs/Characters/Uniforms/Pants_TAZ83/Pants_TAZ83_01_base.et",                     "Pantalon TAZ-83 Base",    8));
		arr.Insert(new CapsuleItemDef("{83DFA8F68CA40B10}Prefabs/Characters/Uniforms/Pants_Pilot_USSR_01/Pants_Pilot_USSR_01.et",             "Pantalon Pilote URSS",    12));
	}

	private static void Init_CLOTHING_PANTS_Part1(array<ref CapsuleItemDef> arr)
	{
		arr.Insert(new CapsuleItemDef("{D7CC1AF40F7A5A32}Prefabs/Characters/Uniforms/Pants_Pilot_USSR_01/Pants_Pilot_USSR_01_base.et",        "Pantalon Pilote Base",    12));
		arr.Insert(new CapsuleItemDef("{6B7F32F1F8A191B0}Prefabs/Characters/Uniforms/Pants_Pilot_USSR_01/Pants_Pilot_USSR_01_tucked.et",      "Pantalon Pilote Ret.",   12));
		arr.Insert(new CapsuleItemDef("{FB3E69073A42A7EC}Prefabs/Characters/Uniforms/Pants_Tanker_USSR_01/Pants_Tanker_USSR_01_base.et",      "Pantalon Tankiste Base",  12));
		arr.Insert(new CapsuleItemDef("{DC91A67E1074AAC0}Prefabs/Characters/Uniforms/Pants_Tanker_USSR_01/Pants_Tanker_USSR_01_tucked.et",    "Pantalon Tankiste Ret.", 12));
		arr.Insert(new CapsuleItemDef("{27494A16F172A97B}Prefabs/Characters/Uniforms/Pants_Tanker_USSR_01/Pants_Tanker_USSR_01.et",           "Pantalon Tankiste",       12));
		arr.Insert(new CapsuleItemDef("{1A65EADE4B08583E}Prefabs/Characters/Uniforms/Pants_Suit_01/Pants_Suit_01_black_V1.et",               "Pantalon Costume Noir",   8));
		arr.Insert(new CapsuleItemDef("{E65D5C9848AC18E9}Prefabs/Characters/Uniforms/Pants_Suit_01/Pants_Suit_01_brown_V1.et",               "Pantalon Costume Marron", 8));
		arr.Insert(new CapsuleItemDef("{401072A652DD9849}Prefabs/Characters/Uniforms/Pants_Suit_01/Pants_Suit_01_grey_V1.et",                "Pantalon Costume Gris",   8));
		arr.Insert(new CapsuleItemDef("{D8BD52A3138A0E62}Prefabs/Characters/Uniforms/Pants_Suit_01/Pants_Suit_01_base.et",                   "Pantalon Costume Base",   8));
		arr.Insert(new CapsuleItemDef("{5B29F970DC4022D5}Prefabs/Characters/Uniforms/Pants_Fisherman_01/Pants_Fisherman_01_orange.et",       "Pantalon Pecheur Org.",  8));
		arr.Insert(new CapsuleItemDef("{CF185061C5C13DBF}Prefabs/Characters/Uniforms/Pants_Fisherman_01/Pants_Fisherman_01_yellow.et",       "Pantalon Pecheur Jne.",  8));
		arr.Insert(new CapsuleItemDef("{0B1F0174869E0351}Prefabs/Characters/Uniforms/Pants_Fisherman_01/Pants_Fisherman_01_green.et",        "Pantalon Pecheur Vert",  8));
		arr.Insert(new CapsuleItemDef("{FE2CED49B0261E64}Prefabs/Characters/Uniforms/Pants_Fisherman_01/Pants_Fisherman_01_base.et",         "Pantalon Pecheur Base",  8));
		arr.Insert(new CapsuleItemDef("{6925E6C63EBCF623}Prefabs/Characters/Uniforms/Pants_Trousers_01/Pants_Trousers_01_DarkBrown.et",      "Pantalon Marron Fonce",  4));
		arr.Insert(new CapsuleItemDef("{5A8C9A020BD7ABA6}Prefabs/Characters/Uniforms/Pants_Trousers_01/Pants_Trousers_01_DarkGrey.et",       "Pantalon Gris Fonce",    4));
	}

	private static void Init_CLOTHING_PANTS_Part2(array<ref CapsuleItemDef> arr)
	{
		arr.Insert(new CapsuleItemDef("{537FD11C135757AC}Prefabs/Characters/Uniforms/Pants_Trousers_01/Pants_Trousers_01_DarkGrey_Dirty.et", "Pantalon Gris Sale",      4));
		arr.Insert(new CapsuleItemDef("{65B7093231FBF67E}Prefabs/Characters/Uniforms/Pants_Trousers_01/Pants_Trousers_01_LightBrown.et",     "Pantalon Beige",          4));
		arr.Insert(new CapsuleItemDef("{22CCB8F2BCCE29E6}Prefabs/Characters/Uniforms/Pants_Trousers_01/Pants_Trousers_01_base.et",           "Pantalon Basique",        4));
	}

	private static void Init_CLOTHING_PANTS(array<ref CapsuleItemDef> arr)
	{
		Init_CLOTHING_PANTS_Part0(arr);
		Init_CLOTHING_PANTS_Part1(arr);
		Init_CLOTHING_PANTS_Part2(arr);
	}

	private static void Init_CLOTHING_SHIRTS_Part0(array<ref CapsuleItemDef> arr)
	{
		arr.Insert(new CapsuleItemDef("{53AE7F8CBF654D12}Prefabs/Characters/Uniforms/Shirt_CottonShirt_01/Shirt_CottonShirt_01_base.et",      "Chemise Coton Base",      4));
		arr.Insert(new CapsuleItemDef("{D0C27D8DB0CC73D9}Prefabs/Characters/Uniforms/Shirt_CottonShirt_01/Shirt_CottonShirt_01_V1.et",       "Chemise Coton V1",        4));
		arr.Insert(new CapsuleItemDef("{BE1CB68B053279DC}Prefabs/Characters/Uniforms/Shirt_CottonShirt_01/Shirt_CottonShirt_01_V1_Dirty.et", "Chemise Coton V1 Sale",   4));
		arr.Insert(new CapsuleItemDef("{86E0117B630414B5}Prefabs/Characters/Uniforms/Shirt_CottonShirt_01/Shirt_CottonShirt_01_V2.et",       "Chemise Coton V2",        4));
		arr.Insert(new CapsuleItemDef("{FEEC97AEB32EFB9B}Prefabs/Characters/Uniforms/Shirt_CottonShirt_01/Shirt_CottonShirt_01_V2_Dirty.et", "Chemise Coton V2 Sale",  4));
		arr.Insert(new CapsuleItemDef("{637C5D826FE183DE}Prefabs/Characters/Uniforms/Shirt_CottonShirt_01/Shirt_CottonShirt_01_V3.et",       "Chemise Coton V3",        4));
		arr.Insert(new CapsuleItemDef("{00ECD7EB467C97D7}Prefabs/Characters/Uniforms/Shirt_CottonShirt_01/Shirt_CottonShirt_01_V3_Dirty.et", "Chemise Coton V3 Sale",  4));
		arr.Insert(new CapsuleItemDef("{5E4878BA1A8D0AE9}Prefabs/Characters/Uniforms/Shirt_CottonShirt_01/Shirt_CottonShirt_01_V4.et",       "Chemise Coton V4",        4));
		arr.Insert(new CapsuleItemDef("{7F0CD5E5DF17FF15}Prefabs/Characters/Uniforms/Shirt_CottonShirt_01/Shirt_CottonShirt_01_V4_Dirty.et", "Chemise Coton V4 Sale",  4));
		arr.Insert(new CapsuleItemDef("{BBD4344316689D82}Prefabs/Characters/Uniforms/Shirt_CottonShirt_01/Shirt_CottonShirt_01_V5.et",       "Chemise Coton V5",        4));
		arr.Insert(new CapsuleItemDef("{810C95A02A459359}Prefabs/Characters/Uniforms/Shirt_CottonShirt_01/Shirt_CottonShirt_01_V5_Dirty.et", "Chemise Coton V5 Sale",  4));
		arr.Insert(new CapsuleItemDef("{D78000A3AAAC12AC}Prefabs/Characters/Uniforms/Shirt_CottonShirt_01/Shirt_CottonShirt_01_V6.et",       "Chemise Coton V6",        4));
		arr.Insert(new CapsuleItemDef("{C1FCB4859C59111E}Prefabs/Characters/Uniforms/Shirt_CottonShirt_01/Shirt_CottonShirt_01_V6_Dirty.et", "Chemise Coton V6 Sale",  4));
		arr.Insert(new CapsuleItemDef("{F39929AB609C7943}Prefabs/Characters/Uniforms/Shirt_Turtleneck_01/Shirt_Turtleneck_01_base.et",       "Col Roule Base",          4));
		arr.Insert(new CapsuleItemDef("{50F8B1F928F93ABD}Prefabs/Characters/Uniforms/Shirt_Turtleneck_01/Shirt_Turtleneck_01_beige.et",      "Col Roule Beige",         4));
	}

	private static void Init_CLOTHING_SHIRTS_Part1(array<ref CapsuleItemDef> arr)
	{
		arr.Insert(new CapsuleItemDef("{3C44AF5729CA80AB}Prefabs/Characters/Uniforms/Shirt_Turtleneck_01/Shirt_Turtleneck_01_beige_Dirty.et","Col Roule Beige Sale",   4));
		arr.Insert(new CapsuleItemDef("{6A3F994EFFE22995}Prefabs/Characters/Uniforms/Shirt_Turtleneck_01/Shirt_Turtleneck_01_DarkBlue.et",   "Col Roule Bleu Fonce",   4));
		arr.Insert(new CapsuleItemDef("{5BEE8146EAA1893B}Prefabs/Characters/Uniforms/Shirt_Turtleneck_01/Shirt_Turtleneck_01_DarkBlue_Dirty.et","Col Roule Bleu Sale",4));
		arr.Insert(new CapsuleItemDef("{B0F4EAC29E9058EA}Prefabs/Characters/Uniforms/Shirt_Turtleneck_01/Shirt_Turtleneck_01_grey.et",       "Col Roule Gris",          4));
		arr.Insert(new CapsuleItemDef("{17DBD854BFF6CD8D}Prefabs/Characters/Uniforms/Shirt_Turtleneck_01/Shirt_Turtleneck_01_grey_Dirty.et", "Col Roule Gris Sale",    4));
	}

	private static void Init_CLOTHING_SHIRTS(array<ref CapsuleItemDef> arr)
	{
		Init_CLOTHING_SHIRTS_Part0(arr);
		Init_CLOTHING_SHIRTS_Part1(arr);
	}

	private static void Init_CLOTHING_VESTS_Part0(array<ref CapsuleItemDef> arr)
	{
		arr.Insert(new CapsuleItemDef("{ADE19B33DCBB9005}Prefabs/Characters/Vests/Vest_6B2/Vest_6B2.et",                                          "Gilet 6B2",              16));
		arr.Insert(new CapsuleItemDef("{1F816D1D2CF505B8}Prefabs/Characters/Vests/Vest_6B2/Vest_6B2_base.et",                                     "Gilet 6B2 Base",         16));
		arr.Insert(new CapsuleItemDef("{4CBDC206FEF9897C}Prefabs/Characters/Vests/Vest_6B3/Vest_6B3.et",                                          "Gilet 6B3",              16));
		arr.Insert(new CapsuleItemDef("{67AD477577B7BFF2}Prefabs/Characters/Vests/Vest_6B3/Vest_6B3_base.et",                                     "Gilet 6B3 Base",         16));
		arr.Insert(new CapsuleItemDef("{156DC7109CEE6F69}Prefabs/Characters/Vests/Vest_ALICE/Variants/Vest_ALICE_AR.et",                          "Gilet ALICE Fusil",      16));
		arr.Insert(new CapsuleItemDef("{2E8829632CBA7A9B}Prefabs/Characters/Vests/Vest_ALICE/Variants/Vest_ALICE_commander.et",                   "Gilet ALICE Cmdr",       16));
		arr.Insert(new CapsuleItemDef("{18B8B9316B590643}Prefabs/Characters/Vests/Vest_ALICE/Variants/Vest_ALICE_GL.et",                          "Gilet ALICE GL",         16));
		arr.Insert(new CapsuleItemDef("{477A190AF2A17B8A}Prefabs/Characters/Vests/Vest_ALICE/Variants/Vest_ALICE_MG.et",                          "Gilet ALICE MG",         16));
		arr.Insert(new CapsuleItemDef("{BD205C7B90BD399E}Prefabs/Characters/Vests/Vest_ALICE/Variants/Vest_ALICE_officer.et",                     "Gilet ALICE Officier",   16));
		arr.Insert(new CapsuleItemDef("{2835A0EA3B79E63E}Prefabs/Characters/Vests/Vest_ALICE/Variants/Vest_ALICE_rifleman.et",                    "Gilet ALICE Fantassin",  16));
		arr.Insert(new CapsuleItemDef("{9CEA24A1A9CC2675}Prefabs/Characters/Vests/Vest_ALICE/Variants/Vest_ALICE_sniper.et",                      "Gilet ALICE Sniper",     16));
		arr.Insert(new CapsuleItemDef("{9713FE6DDCC9510D}Prefabs/Characters/Vests/Vest_Lifchik/Vest_Lifchik.et",                                  "Lifchik",                16));
		arr.Insert(new CapsuleItemDef("{C8516078375CBE45}Prefabs/Characters/Vests/Vest_Lifchik/Vest_Lifchik_GL.et",                               "Lifchik GL",             16));
		arr.Insert(new CapsuleItemDef("{AB84E597273FAECA}Prefabs/Characters/Vests/Vest_Lifchik/Vest_Lifchik_GrenadeBelt.et",                      "Lifchik Grenades",       16));
		arr.Insert(new CapsuleItemDef("{4B57C11AA5161760}Prefabs/Characters/Vests/Vest_PASGT/Vest_PASGT.et",                                      "Gilet PASGT",            16));
	}

	private static void Init_CLOTHING_VESTS_Part1(array<ref CapsuleItemDef> arr)
	{
		arr.Insert(new CapsuleItemDef("{CCE569C5F2D46E3D}Prefabs/Characters/Vests/Vest_PASGT/Vest_PASGT_base.et",                                 "Gilet PASGT Base",       16));
		arr.Insert(new CapsuleItemDef("{4711A4CAF64C4CEE}Prefabs/Characters/Vests/Vest_SovietHarness/Variants/Vest_SovietHarness_AR.et",          "Harnais Sov. Fusil",     16));
		arr.Insert(new CapsuleItemDef("{0684998C1B890BEC}Prefabs/Characters/Vests/Vest_SovietHarness/Variants/Vest_SovietHarness_AR_Black.et",    "Harnais Sov. Fusil Noir",16));
		arr.Insert(new CapsuleItemDef("{D8DDD4941197A929}Prefabs/Characters/Vests/Vest_SovietHarness/Variants/Vest_SovietHarness_Commander.et",   "Harnais Sov. Cmdr",      16));
		arr.Insert(new CapsuleItemDef("{F4AC2175FE718ED4}Prefabs/Characters/Vests/Vest_SovietHarness/Variants/Vest_SovietHarness_Commander_Black.et","Harnais Sov. Cmdr Noir",16));
		arr.Insert(new CapsuleItemDef("{15067AD09803580D}Prefabs/Characters/Vests/Vest_SovietHarness/Variants/Vest_SovietHarness_MG.et",          "Harnais Sov. MG",        16));
		arr.Insert(new CapsuleItemDef("{9344E8C1A7CABF8D}Prefabs/Characters/Vests/Vest_SovietHarness/Variants/Vest_SovietHarness_MG_Black.et",    "Harnais Sov. MG Noir",   16));
		arr.Insert(new CapsuleItemDef("{6726C63F4F56F12F}Prefabs/Characters/Vests/Vest_SovietHarness/Variants/Vest_SovietHarness_medic.et",       "Harnais Sov. Medic",     16));
		arr.Insert(new CapsuleItemDef("{24D075FF9267099A}Prefabs/Characters/Vests/Vest_SovietHarness/Variants/Vest_SovietHarness_medic_Black.et", "Harnais Sov. Med. Noir", 16));
		arr.Insert(new CapsuleItemDef("{F2D03ED36FAC87FF}Prefabs/Characters/Vests/Vest_SovietHarness/Variants/Vest_SovietHarness_officer.et",     "Harnais Sov. Officier",  16));
		arr.Insert(new CapsuleItemDef("{6065A0A410E65A45}Prefabs/Characters/Vests/Vest_SovietHarness/Variants/Vest_SovietHarness_officer_Black.et","Harnais Sov. Off. Noir",16));
		arr.Insert(new CapsuleItemDef("{08155E701A949620}Prefabs/Characters/Vests/Vest_SovietHarness/Variants/Vest_SovietHarness_rifleman.et",    "Harnais Sov. Fant.",     16));
		arr.Insert(new CapsuleItemDef("{FD2EF7E70C8C0441}Prefabs/Characters/Vests/Vest_SovietHarness/Variants/Vest_SovietHarness_rifleman_Black.et","Harnais Sov. Fant. Noir",16));
		arr.Insert(new CapsuleItemDef("{12C8933903D18885}Prefabs/Characters/Vests/Vest_SovietHarness/Variants/Vest_SovietHarness_sharpshooter.et","Harnais Sov. Tireur",    16));
		arr.Insert(new CapsuleItemDef("{B2D127CB5D584A75}Prefabs/Characters/Vests/Vest_SovietHarness/Variants/Vest_SovietHarness_sharpshooter_Black.et","Harnais Sov. Tir. Noir",16));
	}

	private static void Init_CLOTHING_VESTS_Part2(array<ref CapsuleItemDef> arr)
	{
		arr.Insert(new CapsuleItemDef("{D562ED744D4BFB7E}Prefabs/Characters/Vests/Vest_SovietHarness/Variants/Vest_SovietHarness_assembled.et",   "Harnais Sov. Complet",   16));
		arr.Insert(new CapsuleItemDef("{725C5E1C75CADAF4}Prefabs/Characters/Vests/Vest_M69/Vest_M69_M81woodland.et",                             "Gilet M69 Woodland",     16));
		arr.Insert(new CapsuleItemDef("{F9ACDDE62D906D61}Prefabs/Characters/Vests/Vest_M69/Vest_M69_olive.et",                                    "Gilet M69 Olive",        16));
		arr.Insert(new CapsuleItemDef("{07B1F856943B7075}Prefabs/Characters/Vests/Vest_M69/Vest_M69_base.et",                                     "Gilet M69 Base",         16));
		arr.Insert(new CapsuleItemDef("{506EF3B2F0A69D34}Prefabs/Characters/Vests/Vest_NAZ/Vest_NAZ.et",                                          "Gilet NAZ",              16));
		arr.Insert(new CapsuleItemDef("{D7B8E52ADBAAAEA6}Prefabs/Characters/Vests/Vest_NAZ/Vest_NAZ_base.et",                                     "Gilet NAZ Base",         16));
		arr.Insert(new CapsuleItemDef("{9945D5435F12C370}Prefabs/Characters/Vests/Vest_M79GrenadeCarrier/Vest_M79GrenadeCarrier.et",              "Gilet Grenades M79",     16));
		arr.Insert(new CapsuleItemDef("{F396524995F06BFA}Prefabs/Characters/Vests/Vest_SRU21P/Vest_SRU21P.et",                                    "Gilet SRU21P",           16));
		arr.Insert(new CapsuleItemDef("{78BBA3155AB87F87}Prefabs/Characters/Vests/Vest_SRU21P/Vest_SRU21P_base.et",                               "Gilet SRU21P Base",      16));
		arr.Insert(new CapsuleItemDef("{ED5574EA7F63B457}Prefabs/Characters/Vests/Vest_Type56/Vest_Type56.et",                                    "Gilet Type 56",          16));
		arr.Insert(new CapsuleItemDef("{070711EC19FDF25E}Prefabs/Characters/Vests/Vest_Type56/Vest_Type56_base.et",                               "Gilet Type 56 Base",     16));
	}

	private static void Init_CLOTHING_VESTS(array<ref CapsuleItemDef> arr)
	{
		Init_CLOTHING_VESTS_Part0(arr);
		Init_CLOTHING_VESTS_Part1(arr);
		Init_CLOTHING_VESTS_Part2(arr);
	}

	private static void Init_CLOTHING_HEADGEAR_Part0(array<ref CapsuleItemDef> arr)
	{
		arr.Insert(new CapsuleItemDef("{E12126CDE731EED5}Prefabs/Characters/HeadGear/Hat_Boonie_US_01/Hat_Boonie_US_01.et",                  "Boonie US",               8));
		arr.Insert(new CapsuleItemDef("{D4BC1F7EC5C290A3}Prefabs/Characters/HeadGear/Hat_Boonie_US_01/Hat_Boonie_US_01_base.et",            "Boonie US Base",          8));
		arr.Insert(new CapsuleItemDef("{8D75122D5BF561FB}Prefabs/Characters/HeadGear/Hat_Boonie_US_01/Hat_Boonie_US_olive.et",              "Boonie Olive",            8));
		arr.Insert(new CapsuleItemDef("{19231774D1D67091}Prefabs/Characters/HeadGear/Hat_Boonie_US_01/Hat_Boonie_US_TigerStripe.et",        "Boonie Tiger",            8));
		arr.Insert(new CapsuleItemDef("{9F3A7D7943C278D1}Prefabs/Characters/HeadGear/Hat_FlatCap_01/Hat_FlatCap_01_base.et",                "Casquette Plate Base",    4));
		arr.Insert(new CapsuleItemDef("{DD565E2C7E00A5BB}Prefabs/Characters/HeadGear/Hat_FlatCap_01/Hat_FlatCap_01_blue.et",                "Casquette Plate Bleue",   4));
		arr.Insert(new CapsuleItemDef("{E97A86BB050ED6D1}Prefabs/Characters/HeadGear/Hat_FlatCap_01/Hat_FlatCap_01_blue_Dirty.et",          "Casquette Plate Bleue S.",4));
		arr.Insert(new CapsuleItemDef("{67662815EFF734DD}Prefabs/Characters/HeadGear/Hat_FlatCap_01/Hat_FlatCap_01_darkgrey.et",            "Casquette Plate Grise",   4));
		arr.Insert(new CapsuleItemDef("{F6F24096665C6279}Prefabs/Characters/HeadGear/Hat_FlatCap_01/Hat_FlatCap_01_darkgrey_Dirty.et",     "Casquette Plate Grise S.",4));
		arr.Insert(new CapsuleItemDef("{6FEB0D9130EC400E}Prefabs/Characters/HeadGear/Hat_FlatCap_01/Hat_FlatCap_01_lightgrey.et",           "Casquette Plate L.Grise", 4));
		arr.Insert(new CapsuleItemDef("{02B516B35A02FCE5}Prefabs/Characters/HeadGear/Hat_Hard_01/Hat_Hard_01_base.et",                      "Casque Chantier Base",    4));
		arr.Insert(new CapsuleItemDef("{024D6092DA006DD1}Prefabs/Characters/HeadGear/Hat_Hard_01/Hat_Hard_01_blue.et",                      "Casque Chantier Bleu",    4));
		arr.Insert(new CapsuleItemDef("{112EF132833109C8}Prefabs/Characters/HeadGear/Hat_Hard_01/Hat_Hard_01_green.et",                     "Casque Chantier Vert",    4));
		arr.Insert(new CapsuleItemDef("{DF26044449C06EAB}Prefabs/Characters/HeadGear/Hat_Hard_01/Hat_Hard_01_white.et",                     "Casque Chantier Blanc",   4));
		arr.Insert(new CapsuleItemDef("{8F5261C6B57B95C8}Prefabs/Characters/HeadGear/Hat_Hard_01/Hat_Hard_01_yellow.et",                    "Casque Chantier Jaune",   4));
	}

	private static void Init_CLOTHING_HEADGEAR_Part1(array<ref CapsuleItemDef> arr)
	{
		arr.Insert(new CapsuleItemDef("{BCCB7D5AB38BB3A7}Prefabs/Characters/HeadGear/Hat_Knitted_01/Hat_Knitted_01_base.et",                "Bonnet Base",             4));
		arr.Insert(new CapsuleItemDef("{B9687B8829272E14}Prefabs/Characters/HeadGear/Hat_Knitted_01/Hat_Knitted_01_brown.et",               "Bonnet Marron",           4));
		arr.Insert(new CapsuleItemDef("{D8D9EE7F3966589E}Prefabs/Characters/HeadGear/Hat_Knitted_01/Hat_Knitted_01_red.et",                 "Bonnet Rouge",            4));
		arr.Insert(new CapsuleItemDef("{BE19A15F1073E7BD}Prefabs/Characters/HeadGear/Hat_Knitted_01/Hat_Knitted_01_black.et",               "Bonnet Noir",             4));
		arr.Insert(new CapsuleItemDef("{6B2256EBB8E267DD}Prefabs/Characters/HeadGear/Hat_Knitted_01/Hat_Knitted_01_blue.et",                "Bonnet Bleu",             4));
		arr.Insert(new CapsuleItemDef("{B02281435AED8274}Prefabs/Characters/HeadGear/Hat_M70_01/Hat_M70_01.et",                             "Casquette M70",           8));
		arr.Insert(new CapsuleItemDef("{C09D8024295E1D09}Prefabs/Characters/HeadGear/Hat_M70_01/Hat_M70_01_base.et",                        "Casquette M70 Base",      8));
		arr.Insert(new CapsuleItemDef("{6ED66E4BF74756C0}Prefabs/Characters/HeadGear/Hat_M88_01/Hat_M88_01_base.et",                        "Casquette M88 Base",      8));
		arr.Insert(new CapsuleItemDef("{2B29B7E1C6BD1048}Prefabs/Characters/HeadGear/Hat_M88_01/Hat_M88_01_v1.et",                          "Casquette M88 v1",        8));
		arr.Insert(new CapsuleItemDef("{89FD00CB2909667D}Prefabs/Characters/HeadGear/Hat_M88_01/Hat_M88_01_v1_TTsKO.et",                    "Casquette M88 TTsKO",     8));
		arr.Insert(new CapsuleItemDef("{B54B78383E64268F}Prefabs/Characters/HeadGear/Hat_M88_01/Hat_M88_01_v2.et",                          "Casquette M88 v2",        8));
		arr.Insert(new CapsuleItemDef("{793EEE2C133176F9}Prefabs/Characters/HeadGear/Hat_Panama_Soviet/Hat_Panama_Soviet_01_v1.et",         "Panama Sovietique v1",    8));
		arr.Insert(new CapsuleItemDef("{6852E0D026AA8F79}Prefabs/Characters/HeadGear/Hat_Panama_Soviet/Hat_Panama_Soviet_01_v2.et",         "Panama Sovietique v2",    8));
		arr.Insert(new CapsuleItemDef("{CF15283AEC4EE934}Prefabs/Characters/HeadGear/Hat_Panama_Soviet/Hat_Panama_Soviet_01_base.et",       "Panama Sovietique Base",  8));
		arr.Insert(new CapsuleItemDef("{F545C1BE7C99954A}Prefabs/Characters/HeadGear/Hat_Patrol_US_01/Hat_Patrol_US_01.et",                 "Casquette Patrol US",     8));
	}

	private static void Init_CLOTHING_HEADGEAR_Part2(array<ref CapsuleItemDef> arr)
	{
		arr.Insert(new CapsuleItemDef("{F516AD5284661632}Prefabs/Characters/HeadGear/Hat_Patrol_US_01/Hat_Patrol_US_01_base.et",            "Casquette Patrol Base",   8));
		arr.Insert(new CapsuleItemDef("{56915D05E3190762}Prefabs/Characters/HeadGear/Hat_Patrol_US_01/Hat_Patrol_US_01_TigerStripe.et",     "Casquette Patrol Tiger",  8));
		arr.Insert(new CapsuleItemDef("{9911F55EC05D1A64}Prefabs/Characters/HeadGear/Hat_Patrol_US_01/Hat_Patrol_US_02.et",                 "Casquette Patrol US 02",  8));
		arr.Insert(new CapsuleItemDef("{C0B4276A1405ED14}Prefabs/Characters/HeadGear/Hat_RadiovkaBeret_01/Hat_RadiovkaBeret_01_beige.et",   "Beret Beige",             8));
		arr.Insert(new CapsuleItemDef("{200D967D2612147C}Prefabs/Characters/HeadGear/Hat_RadiovkaBeret_01/Hat_RadiovkaBeret_01_black.et",   "Beret Noir",              8));
		arr.Insert(new CapsuleItemDef("{5D7350496AEA24C8}Prefabs/Characters/HeadGear/Hat_RadiovkaBeret_01/Hat_RadiovkaBeret_01_black_Dirty.et","Beret Noir Sale",      8));
		arr.Insert(new CapsuleItemDef("{6E0EC7AC1F6D748F}Prefabs/Characters/HeadGear/Hat_RadiovkaBeret_01/Hat_RadiovkaBeret_01_brown.et",   "Beret Marron",            8));
		arr.Insert(new CapsuleItemDef("{75C92359E352391E}Prefabs/Characters/HeadGear/Hat_RadiovkaBeret_01/Hat_RadiovkaBeret_01_brown_Dirty.et","Beret Marron Sale",    8));
		arr.Insert(new CapsuleItemDef("{6E8633D9C5802A4A}Prefabs/Characters/HeadGear/Hat_RadiovkaBeret_01/Hat_RadiovkaBeret_01_base.et",    "Beret Base",              8));
		arr.Insert(new CapsuleItemDef("{3E2C2A050DE84A64}Prefabs/Characters/HeadGear/Hat_TruckerCap_01/Hat_TruckerCap_01_fkdynamo.et",     "Trucker FKDynamo",        4));
		arr.Insert(new CapsuleItemDef("{5977C0A606B65E6D}Prefabs/Characters/HeadGear/Hat_TruckerCap_01/Hat_TruckerCap_01_moto.et",          "Trucker Moto",            4));
		arr.Insert(new CapsuleItemDef("{477D52F01DC45C55}Prefabs/Characters/HeadGear/Hat_TruckerCap_01/Hat_TruckerCap_01_pohona.et",        "Trucker Pohona",          4));
		arr.Insert(new CapsuleItemDef("{554D761A11D3D7EC}Prefabs/Characters/HeadGear/Hat_TruckerCap_01/Hat_TruckerCap_01_sawmillregina.et", "Trucker Sawmill",         4));
		arr.Insert(new CapsuleItemDef("{17674905311133D7}Prefabs/Characters/HeadGear/Hat_TruckerCap_01/Hat_TruckerCap_01_alsworth.et",      "Trucker Alsworth",        4));
		arr.Insert(new CapsuleItemDef("{665EEF29CC2C672A}Prefabs/Characters/HeadGear/Hat_TruckerCap_01/Hat_TruckerCap_01_base.et",          "Trucker Base",            4));
	}

	private static void Init_CLOTHING_HEADGEAR_Part3(array<ref CapsuleItemDef> arr)
	{
		arr.Insert(new CapsuleItemDef("{C9886336AAD9F74C}Prefabs/Characters/HeadGear/Hat_TruckerCap_01/Hat_TruckerCap_01_enp.et",           "Trucker ENP",             4));
		arr.Insert(new CapsuleItemDef("{6D08415FD18F2775}Prefabs/Characters/HeadGear/Hat_TruckerCap_01/Hat_TruckerCap_01_everon.et",        "Trucker Everon",          4));
		arr.Insert(new CapsuleItemDef("{7A5128C8A77B9DAA}Prefabs/Characters/HeadGear/Hat_Ushanka_01/Hat_Ushanka_01_base.et",                "Ushanka Base",            8));
		arr.Insert(new CapsuleItemDef("{A22C976003AA5BA3}Prefabs/Characters/HeadGear/Hat_Ushanka_01/Hat_Ushanka_01_folded.et",              "Ushanka Repliee",         8));
		arr.Insert(new CapsuleItemDef("{323641C91965842E}Prefabs/Characters/HeadGear/Hat_Ushanka_01/Hat_Ushanka_01_unfolded.et",            "Ushanka Depliee",         8));
		arr.Insert(new CapsuleItemDef("{3523CB7D5961246B}Prefabs/Characters/HeadGear/Hat_PeakedCap_USSR_01/Hat_PeakedCap_USSR_01.et",       "Kepi URSS",               8));
		arr.Insert(new CapsuleItemDef("{F721E7D9C0C733D4}Prefabs/Characters/HeadGear/Hat_PeakedCap_USSR_01/Hat_PeakedCap_USSR_01_base.et",  "Kepi URSS Base",          8));
		arr.Insert(new CapsuleItemDef("{6D225E61B31D513A}Prefabs/Characters/HeadGear/Hat_ZmijovkaCap_01/Hat_ZmijovkaCap_01_green.et",       "Zmijovka Vert",           4));
		arr.Insert(new CapsuleItemDef("{1B568A254D1E519B}Prefabs/Characters/HeadGear/Hat_ZmijovkaCap_01/Hat_ZmijovkaCap_01_red.et",         "Zmijovka Rouge",          4));
		arr.Insert(new CapsuleItemDef("{6BCAA9E5BC957693}Prefabs/Characters/HeadGear/Hat_ZmijovkaCap_01/Hat_ZmijovkaCap_01_black.et",       "Zmijovka Noir",           4));
		arr.Insert(new CapsuleItemDef("{D21DCE2165F63FB3}Prefabs/Characters/HeadGear/Hat_ZmijovkaCap_01/Hat_ZmijovkaCap_01_base.et",        "Zmijovka Base",           4));
		arr.Insert(new CapsuleItemDef("{C8EAB0985B66824A}Prefabs/Characters/HeadGear/Helmet_DH132_01/Helmet_DH132A_01.et",                  "Casque DH132",            12));
		arr.Insert(new CapsuleItemDef("{5236EF0BB8D4BD29}Prefabs/Characters/HeadGear/Helmet_DH132_01/Helmet_DH132A_01_base.et",             "Casque DH132 Base",       12));
		arr.Insert(new CapsuleItemDef("{6E14F80C250F85FC}Prefabs/Characters/HeadGear/Helmet_M1_01/Helmet_M1_01.et",                         "Casque M1",               12));
		arr.Insert(new CapsuleItemDef("{24ADFCA3516E758B}Prefabs/Characters/HeadGear/Helmet_M1_01/Helmet_M1_01_base.et",                    "Casque M1 Base",          12));
	}

	private static void Init_CLOTHING_HEADGEAR_Part4(array<ref CapsuleItemDef> arr)
	{
		arr.Insert(new CapsuleItemDef("{40A02836B851AD5C}Prefabs/Characters/HeadGear/Helmet_M1_01/Helmet_M1_01_Cover_base.et",              "Casque M1 Cover",         12));
		arr.Insert(new CapsuleItemDef("{E456D2F5F718AEBE}Prefabs/Characters/HeadGear/Helmet_M1_01/Helmet_M1_01_Cover_Wineleaf.et",          "Casque M1 Wineleaf",      12));
		arr.Insert(new CapsuleItemDef("{E873B54F01D7C6D8}Prefabs/Characters/HeadGear/Helmet_M1_01/Helmet_M1_01_Cover_Woodland.et",          "Casque M1 Woodland",      12));
		arr.Insert(new CapsuleItemDef("{2E1199EFECE50F35}Prefabs/Characters/HeadGear/Helmet_M1_01/Helmet_M1_01_Cover_ERDL.et",              "Casque M1 ERDL",          12));
		arr.Insert(new CapsuleItemDef("{F31A715FFDB2BD8E}Prefabs/Characters/HeadGear/Helmet_M1_01/Helmet_M1_01_Cover_Frogskin.et",          "Casque M1 Frogskin",      12));
		arr.Insert(new CapsuleItemDef("{B74A4FF0DD8BB116}Prefabs/Characters/HeadGear/Helmet_PASGT_01/Helmet_PASGT_01.et",                   "Casque PASGT",            12));
		arr.Insert(new CapsuleItemDef("{8A2B2A544F3ED831}Prefabs/Characters/HeadGear/Helmet_PASGT_01/Helmet_PASGT_01_base.et",              "Casque PASGT Base",       12));
		arr.Insert(new CapsuleItemDef("{FE5C49069C2499D9}Prefabs/Characters/HeadGear/Helmet_PASGT_01/Helmet_PASGT_01_cover.et",             "Casque PASGT Cover",      12));
		arr.Insert(new CapsuleItemDef("{E685A8D337D36204}Prefabs/Characters/HeadGear/Helmet_PASGT_01/Helmet_PASGT_01_cover_w_goggles.et",   "Casque PASGT Lunettes",   12));
		arr.Insert(new CapsuleItemDef("{03C1F3DB6BB9796A}Prefabs/Characters/HeadGear/Helmet_PASGT_01/Helmet_PASGT_01_cover_w_scrim.et",     "Casque PASGT Scrim",      12));
		arr.Insert(new CapsuleItemDef("{79D240C0D2390F4A}Prefabs/Characters/HeadGear/Helmet_PASGT_01/Helmet_PASGT_01_goggles.et",           "Casque PASGT Goggles",    12));
		arr.Insert(new CapsuleItemDef("{483A80042765275F}Prefabs/Characters/HeadGear/Helmet_SPH4_01/Helmet_SPH4_01.et",                     "Casque SPH-4",            16));
		arr.Insert(new CapsuleItemDef("{BE176A2D8451669E}Prefabs/Characters/HeadGear/Helmet_SPH4_01/Helmet_SPH4_01_base.et",                "Casque SPH-4 Base",       16));
		arr.Insert(new CapsuleItemDef("{BD96E8EEBD78694C}Prefabs/Characters/HeadGear/Helmet_SPH4_01/Helmet_SPH4_Goose_01.et",               "Casque SPH-4 Goose",      16));
		arr.Insert(new CapsuleItemDef("{17D989D6B4A6F87B}Prefabs/Characters/HeadGear/Helmet_SPH4_01/Helmet_SPH4_USFlag_01.et",              "Casque SPH-4 US Flag 1",  16));
	}

	private static void Init_CLOTHING_HEADGEAR_Part5(array<ref CapsuleItemDef> arr)
	{
		arr.Insert(new CapsuleItemDef("{7B8DBD3608627755}Prefabs/Characters/HeadGear/Helmet_SPH4_01/Helmet_SPH4_USFlag_02.et",              "Casque SPH-4 US Flag 2",  16));
		arr.Insert(new CapsuleItemDef("{A7E6D7ECD5F684D7}Prefabs/Characters/HeadGear/Helmet_SSh68_01/Helmet_SSh68_01.et",                   "Casque SSh-68",           12));
		arr.Insert(new CapsuleItemDef("{BFCE7FE311985683}Prefabs/Characters/HeadGear/Helmet_SSh68_01/Helmet_SSh68_01_base.et",              "Casque SSh-68 Base",      12));
		arr.Insert(new CapsuleItemDef("{AE74155267C3D5BB}Prefabs/Characters/HeadGear/Helmet_SSh68_01/Helmet_SSh68_01_cover_base.et",        "Casque SSh-68 Cover",     12));
		arr.Insert(new CapsuleItemDef("{DD35D5EBA6364E77}Prefabs/Characters/HeadGear/Helmet_SSh68_01/Helmet_SSh68_01_cover_KLMK.et",        "Casque SSh-68 KLMK",      12));
		arr.Insert(new CapsuleItemDef("{12035A212B2BE371}Prefabs/Characters/HeadGear/Helmet_SSh68_01/Helmet_SSh68_01_cover_KLMK_net.et",    "Casque SSh-68 KLMK Net",  12));
		arr.Insert(new CapsuleItemDef("{5F8928B41FB86990}Prefabs/Characters/HeadGear/Helmet_SSh68_01/Helmet_SSh68_01_cover_KZS.et",         "Casque SSh-68 KZS",       12));
		arr.Insert(new CapsuleItemDef("{66196D85AB93D2BE}Prefabs/Characters/HeadGear/Helmet_SSh68_01/Helmet_SSh68_01_camo.et",              "Casque SSh-68 Camo",      12));
		arr.Insert(new CapsuleItemDef("{D4028ED16DEE99EE}Prefabs/Characters/HeadGear/Helmet_SSh68_01/Helmet_SSh68_01_camonet.et",           "Casque SSh-68 Camonet",   12));
		arr.Insert(new CapsuleItemDef("{3D74845B9D0867B0}Prefabs/Characters/HeadGear/Helmet_SSh68_01/Helmet_SSh68_01_cover.et",             "Casque SSh-68 Cover v2",  12));
		arr.Insert(new CapsuleItemDef("{22963D69CA50EB9E}Prefabs/Characters/HeadGear/Helmet_SSh68_01/Helmet_SSh68_01_net.et",               "Casque SSh-68 Net",       12));
		arr.Insert(new CapsuleItemDef("{EB2F05A3751B905A}Prefabs/Characters/HeadGear/Helmet_TSh4_01/Helmet_TSh4_01.et",                     "Casque TSh-4",            16));
		arr.Insert(new CapsuleItemDef("{371AC9B15D44B273}Prefabs/Characters/HeadGear/Helmet_TSh4_01/Helmet_TSh4_01_base.et",                "Casque TSh-4 Base",       16));
		arr.Insert(new CapsuleItemDef("{D6B1ACA46036E9CE}Prefabs/Characters/HeadGear/Helmet_TSh4_01/Helmet_TSh4_01_open.et",                "Casque TSh-4 Ouvert",     16));
		arr.Insert(new CapsuleItemDef("{E49D9EE7E2B3016C}Prefabs/Characters/HeadGear/Helmet_ZSh5_01/Helmet_ZSh5_01.et",                     "Casque ZSh-5",            16));
	}

	private static void Init_CLOTHING_HEADGEAR_Part6(array<ref CapsuleItemDef> arr)
	{
		arr.Insert(new CapsuleItemDef("{B95A67A78A9CAA28}Prefabs/Characters/HeadGear/Helmet_ZSh5_01/Helmet_ZSh5_01_base.et",                "Casque ZSh-5 Base",       16));
	}

	private static void Init_CLOTHING_HEADGEAR(array<ref CapsuleItemDef> arr)
	{
		Init_CLOTHING_HEADGEAR_Part0(arr);
		Init_CLOTHING_HEADGEAR_Part1(arr);
		Init_CLOTHING_HEADGEAR_Part2(arr);
		Init_CLOTHING_HEADGEAR_Part3(arr);
		Init_CLOTHING_HEADGEAR_Part4(arr);
		Init_CLOTHING_HEADGEAR_Part5(arr);
		Init_CLOTHING_HEADGEAR_Part6(arr);
	}


	private static void Init_VEHICLES_HELI_UH1_Part0(array<ref CapsuleItemDef> arr)
	{
		arr.Insert(new CapsuleItemDef("{CB6215B3B44EA463}Prefabs/Vehicles/Helicopters/UH1H/SP02_GUNSHIP.et",                       "SP02 Gunship",        600));
		arr.Insert(new CapsuleItemDef("{70BAEEFC2D3FEE64}Prefabs/Vehicles/Helicopters/UH1H/UH1H.et",                               "UH-1H",                320));
		arr.Insert(new CapsuleItemDef("{D03C0F6044DB5208}Prefabs/Vehicles/Helicopters/UH1H/UH1H_base.et",                          "UH-1H Base",           300));
		arr.Insert(new CapsuleItemDef("{EF4E5000BC4F6791}Prefabs/Vehicles/Helicopters/UH1H/UH1H_civ_base.et",                      "UH-1H Civil Base",     300));
		arr.Insert(new CapsuleItemDef("{7A29940A71EF5F5C}Prefabs/Vehicles/Helicopters/UH1H/UH1H_civ_livery_v1.et",                 "UH-1H Civil Livery",   320));
		arr.Insert(new CapsuleItemDef("{EEE291940A9DA42A}Prefabs/Vehicles/Helicopters/UH1H/UH1H_sharkNose.et",                     "UH-1H SharkNose",      340));
	}

	private static void Init_VEHICLES_HELI_UH1(array<ref CapsuleItemDef> arr)
	{
		Init_VEHICLES_HELI_UH1_Part0(arr);
	}

	private static void Init_VEHICLES_WHEELED_US_Part0(array<ref CapsuleItemDef> arr)
	{
		arr.Insert(new CapsuleItemDef("{0403FB7965F89864}Prefabs/Vehicles/Wheeled/M998/Humr_base.et",              "Humvee",               200));
		arr.Insert(new CapsuleItemDef("{33AB44A084BAA0CD}Prefabs/Vehicles/Wheeled/M998/M1025_base.et",             "M1025",                220));
		arr.Insert(new CapsuleItemDef("{4B05A6D73A56A5ED}Prefabs/Vehicles/Wheeled/M998/M998_base.et",              "M998",                 200));
		arr.Insert(new CapsuleItemDef("{6DC12F2E2E9F2525}Prefabs/Vehicles/Wheeled/M998/M998_covered_base.et",      "M998 Couvert",         208));
		arr.Insert(new CapsuleItemDef("{256CF92D598E7163}Prefabs/Vehicles/Wheeled/M998/M998_uncovered_base.et",    "M998 Decouvert",       200));
		arr.Insert(new CapsuleItemDef("{B1C4A3DA3987202E}Prefabs/Vehicles/Wheeled/M998/M997_maxi_ambulance_base.et","M997 Ambulance",      220));
	}

	private static void Init_VEHICLES_WHEELED_US(array<ref CapsuleItemDef> arr)
	{
		Init_VEHICLES_WHEELED_US_Part0(arr);
	}

	private static void Init_VEHICLES_WHEELED_SOV_Part0(array<ref CapsuleItemDef> arr)
	{
		arr.Insert(new CapsuleItemDef("{99F1610551D54D17}Prefabs/Vehicles/Wheeled/UAZ469/UAZ469_base.et",                             "UAZ-469",              180));
		arr.Insert(new CapsuleItemDef("{7524FB186D534ACA}Prefabs/Vehicles/Wheeled/UAZ469/UAZ469_covered_CIV_base.et",                "UAZ-469 Couvert",      188));
		arr.Insert(new CapsuleItemDef("{26AF1879FBDA37EB}Prefabs/Vehicles/Wheeled/UAZ469/UAZ469_uncovered_CIV_base.et",              "UAZ-469 Decouvert",    180));
		arr.Insert(new CapsuleItemDef("{988A61BA68420AFE}Prefabs/Vehicles/Wheeled/UAZ452/UAZ452_base.et",                             "UAZ-452",              180));
		arr.Insert(new CapsuleItemDef("{92AA1080824A3F7E}Prefabs/Vehicles/Wheeled/UAZ452/UAZ452_transport_base.et",                  "UAZ-452 Transport",    200));
		arr.Insert(new CapsuleItemDef("{82125D77729753BA}Prefabs/Vehicles/Wheeled/UAZ452/UAZ452_cargo_base.et",                       "UAZ-452 Cargo",        200));
		arr.Insert(new CapsuleItemDef("{1247D68D2A76907D}Prefabs/Vehicles/Wheeled/UAZ452/UAZ452_ambulance_base.et",                  "UAZ-452 Ambulance",    220));
		arr.Insert(new CapsuleItemDef("{A2E23CB8DDCFE82E}Prefabs/Vehicles/Wheeled/Ural4320/Ural4320_transport_CIV_base.et",          "Ural-4320 Transport",  240));
		arr.Insert(new CapsuleItemDef("{4BFB3CA9E83385D2}Prefabs/Vehicles/Wheeled/Ural4320/Ural4320_transport_covered_CIV_base.et",  "Ural-4320 Couvert",    248));
		arr.Insert(new CapsuleItemDef("{33BC05D02006BE44}Prefabs/Vehicles/Wheeled/Ural4320/Ural4320_tanker_CIV_base.et",             "Ural-4320 Citerne",    260));
	}

	private static void Init_VEHICLES_WHEELED_SOV(array<ref CapsuleItemDef> arr)
	{
		Init_VEHICLES_WHEELED_SOV_Part0(arr);
	}

	private static void Init_VEHICLES_CIV_Part0(array<ref CapsuleItemDef> arr)
	{
		arr.Insert(new CapsuleItemDef("{DA79E34823120087}Prefabs/Vehicles/Wheeled/S105/S105_base.et",                         "Skoda S105",           120));
		arr.Insert(new CapsuleItemDef("{4AE9D080927D3CB9}Prefabs/Vehicles/Wheeled/S1203/S1203_base.et",                       "S1203",                140));
		arr.Insert(new CapsuleItemDef("{D7663936ABF75FB1}Prefabs/Vehicles/Wheeled/S1203/S1203_cargo_base.et",                 "S1203 Cargo",          148));
		arr.Insert(new CapsuleItemDef("{D7663936ABF75FB0}Prefabs/Vehicles/Wheeled/S1203/S1203_transport_base.et",             "S1203 Transport",      148));
		arr.Insert(new CapsuleItemDef("{A003493D32140960}Prefabs/Vehicles/Wheeled/UAZ452/UAZ452_cargo_CIV_base.et",           "UAZ-452 Cargo Civ.",   160));
		arr.Insert(new CapsuleItemDef("{1F514A6916B34568}Prefabs/Vehicles/Wheeled/UAZ452/UAZ452_transport_CIV_base.et",       "UAZ-452 Transport Civ",160));
	}

	private static void Init_VEHICLES_CIV(array<ref CapsuleItemDef> arr)
	{
		Init_VEHICLES_CIV_Part0(arr);
	}

	private static void Init_VEHICLES_DLC_Part0(array<ref CapsuleItemDef> arr)
	{
		// Helicopteres DLC
		arr.Insert(new CapsuleItemDef("{6CA46BC65DE861A8}Prefabs/Vehicles/Helicopters/AH6M/AH6M_Armed_base.et",                       "Little Bird",           800));
		arr.Insert(new CapsuleItemDef("{1B386A874F4BA7A9}Prefabs/Vehicles/Helicopters/UH1H/UH1H_armed_armaments.et",                  "UH-1H Arme",            650));
		// Voitures DLC
		arr.Insert(new CapsuleItemDef("{1398A24AB596FFE1}Prefabs/Vehicles/Wheeled/SampleCar_01/SampleCar_01.et",                      "Golf Noire",            300));
		arr.Insert(new CapsuleItemDef("{EA4402E038B96F6C}Prefabs/Vehicles/Wheeled/SampleCar_01/SampleCar_01_white.et",                "Golf Blanche",          300));
		// Rzr / buggies
		arr.Insert(new CapsuleItemDef("{2426F7291A958BBC}Prefabs/Vehicles/Wheeled/UAZ469/MoneyGang scar.et",                          "Rzr MoneyGang",         275));
		arr.Insert(new CapsuleItemDef("{15CCD5CA859B15EF}Prefabs/Vehicles/Wheeled/UAZ469/Rzr Abueliza 2.et",                          "Rzr Abueliza 2",        275));
		arr.Insert(new CapsuleItemDef("{621EEFC84EDFD03A}Prefabs/Vehicles/Wheeled/UAZ469/Rzr MG 2.et",                                "Rzr MG 2",              275));
		arr.Insert(new CapsuleItemDef("{D0254C9AE60EC6F9}Prefabs/Vehicles/Wheeled/UAZ469/Rzr scar 2.et",                              "Rzr Scar 2",            275));
		// Bus et blindes DLC
		arr.Insert(new CapsuleItemDef("{28EAB17D6376D746}Prefabs/Vehicles/Wheeled/MB_Bus/MB_Bus.et",                                           "MB Bus",                500));
		arr.Insert(new CapsuleItemDef("{DD21CF1AB4A3BD86}Prefabs/Vehicles/Wheeled/VT4/VT4_CE.et",                                             "VT4 CE",                700));
		arr.Insert(new CapsuleItemDef("{D12135D4B184723B}Prefabs/Vehicles/Wheeled/VT4/WKI_VT4_BTDF.et",                                       "VT4 BTDF",              700));
		arr.Insert(new CapsuleItemDef("{43999291A40AE965}Prefabs/Vehicles/Wheeled/VT4/WKI_VT4_CE_Equipped.et",                                "VT4 WKI CE Equipe",     700));
		// Motos
		arr.Insert(new CapsuleItemDef("{6643589663041DEC}Prefabs/Vehicles/Wheeled/CAGIVA A8/Cagi SOF4 Amarilla.et",                                    "Moto Amarilla",         375));
		arr.Insert(new CapsuleItemDef("{9CFA5D2A1A014B1A}Prefabs/Vehicles/Wheeled/CAGIVA A8/Cagi SOF4 Roja.et",                                        "Moto Roja",             375));
		arr.Insert(new CapsuleItemDef("{8D1D51CB036CEA3D}Prefabs/Vehicles/Wheeled/CAGIVA A8/Cagi SOF4 Negra.et",                                       "Moto Negra",            375));
		arr.Insert(new CapsuleItemDef("{F22B338BFAC1FD68}Prefabs/Vehicles/Wheeled/Motorbike/motorbike.et",                                             "Moto",                  375));
		arr.Insert(new CapsuleItemDef("{E6E5E1E5DC66DD8C}Prefabs/Vehicles/Wheeled/Motorbike/motorbike_green.et",                                       "Moto Verte",            375));
		// MadMax
		arr.Insert(new CapsuleItemDef("{F70FB6122E594631}Prefabs/Vehicles/Wheeled/M998/TRX G.et",                                              "trx VERT",        400));
		arr.Insert(new CapsuleItemDef("{F07F109AA11368C6}Prefabs/Vehicles/Wheeled/M998/TRX W.et",                                 "trx Blanche", 400));
		arr.Insert(new CapsuleItemDef("{771F2C8276E5EF97}Prefabs/Vehicles/Wheeled/Trucks/Rover/Rover_purple.et",                                    "Rover Rose", 400));
		arr.Insert(new CapsuleItemDef("{7763D6EB5CBFBF74}Prefabs/Vehicles/Wheeled/Trucks/Tahoe/Tahoe_blue.et",                                    "Tahao Bleu", 400));
		arr.Insert(new CapsuleItemDef("{AFC0B09EE9880A98}Prefabs/Vehicles/Wheeled/Trucks/Van/Van_weed.et",                                    "Van Weed", 400));
		arr.Insert(new CapsuleItemDef("{4D73452CD3D4F0FF}Prefabs/Vehicles/Wheeled/Trucks/Wranger/Wrangler_limeGreen.et",                                    "Wrangler Vert", 400));
		arr.Insert(new CapsuleItemDef("{CCFD8AA837B9611A}Prefabs/Items/CarKey/CarKey.et",                                    "Cle de vehicule", 25));
	}

	private static void Init_VEHICLES_DLC(array<ref CapsuleItemDef> arr)
	{
		Init_VEHICLES_DLC_Part0(arr);
	}

	// -- Point d'entree unique - appeler depuis CapsuleBootstrap ------------
	private static void Init_MEDICAL()
	{
		MEDICAL_ITEMS.Insert(new CapsuleItemDef("{D511F5C330B1697E}Prefabs/Items/Medicine/FieldDressing_01/FieldDressing_USSR_01_Base.et",         "Bandage",          8));
		MEDICAL_ITEMS.Insert(new CapsuleItemDef("{3238FC0BDB67AA78}Prefabs/Items/Medicine/MorphineInjection_01/MorphineInjection_01_base.et",       "Morphine",         20));
		MEDICAL_ITEMS.Insert(new CapsuleItemDef("{D70216B1B2889129}Prefabs/Items/Medicine/Tourniquet_01/Tourniquet_US_01.et",   "Garrot",           12));
		MEDICAL_ITEMS.Insert(new CapsuleItemDef("{00E36F41CA310E2A}Prefabs/Items/Medicine/SalineBag_01/SalineBag_US_01.et",        "Poche de serum",   32));
	}

	private static void Init_FOOD_WATER()
	{
		FOOD_ITEMS.Insert(new CapsuleItemDef("{24CB3DC5D7B8B9ED}Prefabs/Items/Food/Can/FoodCan_01.et",        "Boite de conserve", 8));
		FOOD_ITEMS.Insert(new CapsuleItemDef("{5E5F67E6FB33A5DB}Prefabs/Items/Food/Can/FoodCan_02.et",        "Rations militaires",12));
		FOOD_ITEMS.Insert(new CapsuleItemDef("{B4F9FA4E21F7BAE3}Prefabs/Items/Food/Bread/Bread_01.et",        "Pain",              4));
		WATER_ITEMS.Insert(new CapsuleItemDef("{97C6AA0B4D47E9C2}Prefabs/Items/Containers/WaterBottle/WaterBottle_01.et", "Gourde",     8));
		WATER_ITEMS.Insert(new CapsuleItemDef("{3B80A7B4E9F2C1D0}Prefabs/Items/Containers/Canteen/Canteen_01.et",         "Gourde alu", 12));
	}


	// =====================================================================
	// MARCHE NOIR - armes de contrebande
	// =====================================================================
	private static void Init_BM_WEAPONS(array<ref CapsuleItemDef> arr)
	{
		// Pistolets / SMG
		arr.Insert(new CapsuleItemDef("{5E7AADDEC5A58EA5}Prefabs/Weapons/Handguns/Handgun_BaconDeagle.et",              "Desert Eagle",         48, 4));
		arr.Insert(new CapsuleItemDef("{EBB756E62EBF4EB4}Prefabs/Weapons/Rifles/AK74/Rifle_BaconKomrad12.et",           "Komrad-12",            56, 5));
		// M16 Carbines
		arr.Insert(new CapsuleItemDef("{8DD6BA060EAAF367}Prefabs/Weapons/Rifles/M16/carbine.et",                        "M4 Carbine",           52, 4));
		arr.Insert(new CapsuleItemDef("{A5CBA990416FB7CC}Prefabs/Weapons/Rifles/M16/Carbine camo.et",                   "M4 Camo",              54, 4));
		arr.Insert(new CapsuleItemDef("{BBCE4EE836E696D0}Prefabs/Weapons/Rifles/M16/Carbine d tan.et",                  "M4 D.Tan",             54, 4));
		arr.Insert(new CapsuleItemDef("{957A3E3DC3072D28}Prefabs/Weapons/Rifles/M16/Carbine t tone.et",                 "M4 Two-Tone",          54, 4));
		arr.Insert(new CapsuleItemDef("{E45563EAE5466B47}Prefabs/Weapons/Rifles/M16/Carbine tan.et",                    "M4 Tan",               54, 4));
		arr.Insert(new CapsuleItemDef("{8351199B644DE14A}Prefabs/Weapons/Rifles/M16/Carbine ucp.et",                    "M4 UCP",               54, 4));
		// M16 Carbines UBGL
		arr.Insert(new CapsuleItemDef("{BAEAA5EBC40E2F63}Prefabs/Weapons/Rifles/M16/ubgl/Carbine camo m320.et",         "M4 Camo M320",         64, 5));
		arr.Insert(new CapsuleItemDef("{DDF0EA502ED4EB0F}Prefabs/Weapons/Rifles/M16/ubgl/Carbine d tan ubgl.et",        "M4 D.Tan GL",          64, 5));
		arr.Insert(new CapsuleItemDef("{1DE7DA16C2AF8042}Prefabs/Weapons/Rifles/M16/ubgl/Carbine t tone ubgl.et",       "M4 Two-Tone GL",       64, 5));
		arr.Insert(new CapsuleItemDef("{6079508F79DFCDAB}Prefabs/Weapons/Rifles/M16/ubgl/Carbine tan ubgl.et",          "M4 Tan GL",            64, 5));
		arr.Insert(new CapsuleItemDef("{B4F700D2DFC8AA97}Prefabs/Weapons/Rifles/M16/ubgl/carbine ubgl.et",              "M4 GL",                64, 5));
		arr.Insert(new CapsuleItemDef("{6A0BD9069BC48D50}Prefabs/Weapons/Rifles/M16/ubgl/Carbine ucp ubgl.et",          "M4 UCP GL",            64, 5));
		// M16 CQC
		arr.Insert(new CapsuleItemDef("{5CAA3245AC5D050A}Prefabs/Weapons/Rifles/M16/CQC.et",                            "M4 CQC",               52, 4));
		arr.Insert(new CapsuleItemDef("{6901DD9E65A13BD4}Prefabs/Weapons/Rifles/M16/CQC black.et",                      "M4 CQC Noir",          52, 4));
		arr.Insert(new CapsuleItemDef("{A1AED4AEA34E1A60}Prefabs/Weapons/Rifles/M16/CQC camo.et",                       "M4 CQC Camo",          54, 4));
		arr.Insert(new CapsuleItemDef("{687CA9D8D4CBBFAB}Prefabs/Weapons/Rifles/M16/CQC tan.et",                        "M4 CQC Tan",           54, 4));
		arr.Insert(new CapsuleItemDef("{0F78D3A955C035A6}Prefabs/Weapons/Rifles/M16/CQC ucp.et",                        "M4 CQC UCP",           54, 4));
		arr.Insert(new CapsuleItemDef("{11E643A0B0AB3A99}Prefabs/Weapons/Rifles/M16/CQC  2 tone.et",                    "M4 CQC Two-Tone",      54, 4));
		// M16 DMR
		arr.Insert(new CapsuleItemDef("{9222C7B0A13F0726}Prefabs/Weapons/Rifles/M16/dmr b.et",                          "M16 DMR",              60, 5));
		arr.Insert(new CapsuleItemDef("{CA73CFB9E9ABDDE7}Prefabs/Weapons/Rifles/M16/DMR camo.et",                       "M16 DMR Camo",         60, 5));
		arr.Insert(new CapsuleItemDef("{20B8E33D2FA176D0}Prefabs/Weapons/Rifles/M16/dmr  d tan.et",                     "M16 DMR D.Tan",        60, 5));
		arr.Insert(new CapsuleItemDef("{F9444CC138C0C3BF}Prefabs/Weapons/Rifles/M16/dmr 2 ton.et",                      "M16 DMR Two-Tone",     60, 5));
		arr.Insert(new CapsuleItemDef("{36F5F8D031BAC490}Prefabs/Weapons/Rifles/M16/dmr tan.et",                        "M16 DMR Tan",          60, 5));
		arr.Insert(new CapsuleItemDef("{51F182A1B0B14E9D}Prefabs/Weapons/Rifles/M16/dmr ucp.et",                        "M16 DMR UCP",          60, 5));
		arr.Insert(new CapsuleItemDef("{CB14656C54028D62}Prefabs/Weapons/Rifles/M16/BaconRISAttachments_Rifle_M16A2.et", "M16A2 RIS",           68, 5));
		// SAW
		arr.Insert(new CapsuleItemDef("{A8FEB89061C28419}Prefabs/Weapons/Rifles/M16/SAW.et",                            "M249 SAW",             70, 6));
		arr.Insert(new CapsuleItemDef("{080403C4EDE40B7E}Prefabs/Weapons/Rifles/M16/saw camo.et",                       "M249 SAW Camo",        70, 6));
		arr.Insert(new CapsuleItemDef("{617DD03FA987E8F4}Prefabs/Weapons/Rifles/M16/SAW dtan.et",                       "M249 SAW D.Tan",       70, 6));
		arr.Insert(new CapsuleItemDef("{18A54184ABDE5B15}Prefabs/Weapons/Rifles/M16/SAW tan.et",                        "M249 SAW Tan",         70, 6));
		arr.Insert(new CapsuleItemDef("{20A6AC96E7A3906E}Prefabs/Weapons/Rifles/M16/saw 2t.et",                         "M249 SAW Two-Tone",    70, 6));
		arr.Insert(new CapsuleItemDef("{D24902FB50B4D418}Prefabs/Weapons/Rifles/M16/ucp saw.et",                        "M249 SAW UCP",         70, 6));
	}

	private static void Init_BM_MAGAZINES(array<ref CapsuleItemDef> arr)
	{
		// Desert Eagle
		arr.Insert(new CapsuleItemDef("{37A4298260831B13}Prefabs/Weapons/Magazines/BaconMagazine_AE50_Deagle_7rnd.et",  "Charg. Deagle .50",     6));


		// Komrad-12
		arr.Insert(new CapsuleItemDef("{280ECC90B847C47D}Prefabs/Weapons/Magazines/Magazine_12g_Komrad_Slug.et",        "Komrad Slug",           4));
		arr.Insert(new CapsuleItemDef("{248060BC4B0B6E61}Prefabs/Weapons/Magazines/Magazine_12g_Komrad_Drum_HE.et",     "Komrad Drum HE",        6));
		arr.Insert(new CapsuleItemDef("{9260A421BD1F746C}Prefabs/Weapons/Magazines/Magazine_12g_Komrad_Drum_Slug.et",   "Komrad Drum Slug",      6));
		arr.Insert(new CapsuleItemDef("{00ECA356A2DEE92C}Prefabs/Weapons/Magazines/Magazine_12g_Komrad_HE.et",          "Komrad HE",             4));
		arr.Insert(new CapsuleItemDef("{C66D7E1177EE19EC}Prefabs/Weapons/Magazines/Magazine_12g_Komrad_Drum_base.et",   "Komrad Drum Base",      6));
		arr.Insert(new CapsuleItemDef("{7C0316A072B6A9FD}Prefabs/Weapons/Magazines/Magazine_12g_Komrad_Base.et",        "Komrad Base",           4));
		// M16/M4 magazines
		arr.Insert(new CapsuleItemDef("{2EBF60EF24B108FD}Prefabs/Weapons/Magazines/Magazine_556x45_STANAG_30rnd_Ball.et","STANAG 30rnd",         4));
		arr.Insert(new CapsuleItemDef("{CCE11DB2B347A5B1}Prefabs/Weapons/Magazines/100 rndr1 camo.et",                  "100rnd Camo",           6));
		arr.Insert(new CapsuleItemDef("{5793B29160342E0C}Prefabs/Weapons/Magazines/100 rndr1 d tan.et",                 "100rnd D.Tan",          6));
		arr.Insert(new CapsuleItemDef("{D19DCD5069A2C901}Prefabs/Weapons/Magazines/100 rndr1 tan.et",                   "100rnd Tan",            6));
		arr.Insert(new CapsuleItemDef("{B699B721E8A9430C}Prefabs/Weapons/Magazines/100 rndr1 ucp.et",                   "100rnd UCP",            6));
		arr.Insert(new CapsuleItemDef("{693B8295734443C8}Prefabs/Weapons/Magazines/100 rndr1.et",                       "100rnd",                6));
		arr.Insert(new CapsuleItemDef("{B43A5F6DC656788B}Prefabs/Weapons/Magazines/20 rnd digi.et",                     "20rnd Digi",            4));
		arr.Insert(new CapsuleItemDef("{C03E90E0BF31752A}Prefabs/Weapons/Magazines/20 rndr black.et",                   "20rnd Noir",            4));
		arr.Insert(new CapsuleItemDef("{991ED7B1B2562E06}Prefabs/Weapons/Magazines/20 rndr2.et",                        "20rnd",                 4));
		arr.Insert(new CapsuleItemDef("{05BE75CC52290BB5}Prefabs/Weapons/Magazines/20 rndrcamo.et",                     "20rnd Camo",            4));
		arr.Insert(new CapsuleItemDef("{4EAF325652F05129}Prefabs/Weapons/Magazines/60 round2 camod.et",                 "60rnd Camo",            6));
		arr.Insert(new CapsuleItemDef("{58B4F55CA7BB32E1}Prefabs/Weapons/Magazines/60 round2.et",                       "60rnd",                 6));
		arr.Insert(new CapsuleItemDef("{48249131ECB9DC5A}Prefabs/Weapons/Magazines/60 tan dI.et",                       "60rnd Tan DI",          6));
		arr.Insert(new CapsuleItemDef("{9454B573A32FF08E}Prefabs/Weapons/Magazines/60 tan.et",                          "60rnd Tan",             6));
		arr.Insert(new CapsuleItemDef("{7EBB31B407B29AA3}Prefabs/Weapons/Magazines/60 ucp4.et",                         "60rnd UCP",             6));
		arr.Insert(new CapsuleItemDef("{88BD7CDC14524BB3}Prefabs/Weapons/Magazines/ucp 20.et",                          "20rnd UCP",             4));
	}

	private static void Init_BM_OPTICS(array<ref CapsuleItemDef> arr)
	{
		arr.Insert(new CapsuleItemDef("{1890057F82D25112}Prefabs/5ABD0CB57F7E9EB1/Optics/Optic_BaconCZScorpion_Irons.et","Irons Scorpion",       10));
		arr.Insert(new CapsuleItemDef("{B69AFD082A52A0EB}Prefabs/Weapons/Attachments/BaconOptics/Optic_Reflex.et",       "Reflex Sight",         12));
		arr.Insert(new CapsuleItemDef("{311393C82B783721}Prefabs/5ABD0CB57F7E9EB1/Optics/Optic_XPS3.et",                 "XPS3",                 14));
		arr.Insert(new CapsuleItemDef("{CC79E8009249049D}Prefabs/5ABD0CB57F7E9EB1/Optics/Optic_XPS3_Green.et",           "XPS3 Vert",            14));
		arr.Insert(new CapsuleItemDef("{2FF07CC34BCCA161}Prefabs/5ABD0CB57F7E9EB1/Optics/Optic_XPS3_Green_Tan.et",       "XPS3 Vert Tan",        14));
		arr.Insert(new CapsuleItemDef("{A4028669C4F516F6}Prefabs/5ABD0CB57F7E9EB1/Optics/Optic_XPS3_Tan.et",             "XPS3 Tan",             14));
		arr.Insert(new CapsuleItemDef("{FD75A60672D2755B}Prefabs/5ABD0CB57F7E9EB1/Optics/Optic_XPS3_Magnified.et",       "XPS3 Magnifie",        16));
		arr.Insert(new CapsuleItemDef("{E24DA10E344E4F9F}Prefabs/5ABD0CB57F7E9EB1/Optics/Optic_XPS3_Magnified_FDE.et",   "XPS3 Magnifie FDE",    16));
		arr.Insert(new CapsuleItemDef("{CBEB551860024355}Prefabs/5ABD0CB57F7E9EB1/Optics/Optic_XPS3_Magnified_Green.et", "XPS3 Magnifie Vert",   16));
		arr.Insert(new CapsuleItemDef("{D5CD8E60416F1D5D}Prefabs/5ABD0CB57F7E9EB1/Optics/Optic_XPS3_Magnified_Green_FDE.et","XPS3 Mag.Vert FDE",  16));
		arr.Insert(new CapsuleItemDef("{25E734CCFB586A0F}Prefabs/Weapons/Attachments/BaconOptics/Bacon_L3.5x10_Scope_M110.et","Scope 3.5-10x M110",18));
		arr.Insert(new CapsuleItemDef("{66EACA487953F313}Prefabs/Weapons/Attachments/BaconOptics/Bacon_L3.5x10_Scope_M110_Tan.et","Scope 3.5-10x Tan",18));
		arr.Insert(new CapsuleItemDef("{61ECD3C29600A4BC}Prefabs/Weapons/Attachments/BaconOptics/Bacon_Specter.et",      "Specter DR",           16));
		arr.Insert(new CapsuleItemDef("{9717E16AC6D59CC1}Prefabs/Weapons/Attachments/BaconOptics/Bacon_Specter_Brown.et","Specter DR Marron",    16));
		arr.Insert(new CapsuleItemDef("{D0EF24860024D32D}Prefabs/Weapons/Attachments/BaconOptics/BaconBarrett_L4.5x14_Scope_M82.et","Scope 4.5-14x M82", 18));
		arr.Insert(new CapsuleItemDef("{8EBF43C2831519BF}Prefabs/Weapons/Attachments/Rangefinder_Laser_RIS.et",          "Telemetre Laser",      14));
	}

	private static void Init_BM_ATTACHMENTS(array<ref CapsuleItemDef> arr)
	{
		// Silencieux
		arr.Insert(new CapsuleItemDef("{F7104825C77AB12F}Prefabs/Weapons/Core/Suppressor_556_SC.et",                     "Silencieux .556",      12));
		arr.Insert(new CapsuleItemDef("{7CB432CC4ED704E1}Prefabs/Weapons/Core/Suppressor_Generic_556.et",                "Silencieux .556 Gen.", 12));
		arr.Insert(new CapsuleItemDef("{64F4EE82C4865D72}Prefabs/Weapons/Core/Suppressor_556_SC_tan.et",                 "Silencieux .556 Tan",  12));
		arr.Insert(new CapsuleItemDef("{33C686F10D37ABA1}Prefabs/Weapons/Core/Suppressor_Generic_9mm.et",                "Silencieux 9mm",       10));
		arr.Insert(new CapsuleItemDef("{AD47C1629DAE47A3}Prefabs/Weapons/Core/Suppressor_Generic_9mm_tan.et",            "Silencieux 9mm Tan",   10));
		arr.Insert(new CapsuleItemDef("{904AF79F5926399A}Prefabs/Weapons/Core/Suppressor_Punky_NT4.et",                  "Silencieux NT4",       14));
		arr.Insert(new CapsuleItemDef("{D7C7D1ECF81503E3}Prefabs/Weapons/Core/Suppressor_Bacon12G.et",                   "Silencieux 12G",       12));
		// Lampes et lasers
		arr.Insert(new CapsuleItemDef("{899FF1A86CC5F716}Prefabs/Weapons/Attachments/Flashlight_M300V_White.et",         "Lampe M300V",          10));
		arr.Insert(new CapsuleItemDef("{A9A9C7512E415EE4}Prefabs/Weapons/Attachments/Flashlight_M300V_White_inherited.et","Lampe M300V Mk2",     10));
		arr.Insert(new CapsuleItemDef("{526B38BDD0555EAD}Prefabs/Weapons/Attachments/Laser_PEQ9_Green.et",               "PEQ-9 Vert",           12));
		arr.Insert(new CapsuleItemDef("{D5B7A93459176833}Prefabs/Weapons/Attachments/Laser_PEQ9_Red.et",                 "PEQ-9 Rouge",          12));
		// Divers
		arr.Insert(new CapsuleItemDef("{2C23C8A61A44F43D}Prefabs/Weapons/Attachments/Handguards/Handguard_M16A2/bipod.et","Bipied",              10));
		arr.Insert(new CapsuleItemDef("{268D95F3D0D8CC0C}Prefabs/Weapons/Core/BaconRISAttachments_SimpleSightsBase.et",  "Rail RIS",             10));
		arr.Insert(new CapsuleItemDef("{9D66DFE301BE0975}Prefabs/ubgl/GLsight.et",                                       "Viseur GL",            10));
		arr.Insert(new CapsuleItemDef("{87A3079D2D424A8E}Prefabs/ubgl/m203 v2.et",                                       "M203 v2",              16));
		arr.Insert(new CapsuleItemDef("{E1B3BB4F0A1C827D}Prefabs/ubgl/m302.et",                                          "M302 GL",              16));
	}

	static void Init()
	{
		if (s_bInitialized) return;
		s_bInitialized = true;

		Init_WEAPONS_RIFLES(WEAPONS_RIFLES);
		Init_WEAPONS_MG(WEAPONS_MG);
		Init_WEAPONS_LAUNCHERS(WEAPONS_LAUNCHERS);
		Init_AMMO_556(AMMO_556);
		Init_AMMO_545(AMMO_545);
		Init_AMMO_762(AMMO_762);
		Init_OPTICS(OPTICS);
		Init_ATTACHMENTS(ATTACHMENTS);
		Init_CLOTHING_BACKPACKS(CLOTHING_BACKPACKS);
		Init_CLOTHING_JACKETS(CLOTHING_JACKETS);
		Init_CLOTHING_PANTS(CLOTHING_PANTS);
		Init_CLOTHING_SHIRTS(CLOTHING_SHIRTS);
		Init_CLOTHING_VESTS(CLOTHING_VESTS);
		Init_CLOTHING_HEADGEAR(CLOTHING_HEADGEAR);
		Init_VEHICLES_HELI_UH1(VEHICLES_HELI_UH1);
		Init_VEHICLES_WHEELED_US(VEHICLES_WHEELED_US);
		Init_VEHICLES_WHEELED_SOV(VEHICLES_WHEELED_SOV);
		Init_VEHICLES_CIV(VEHICLES_CIV);
		Init_VEHICLES_DLC(VEHICLES_DLC);
		Init_MEDICAL();
		Init_FOOD_WATER();
		Init_BM_WEAPONS(BM_WEAPONS);
		Init_BM_MAGAZINES(BM_MAGAZINES);
		Init_BM_OPTICS(BM_OPTICS);
		Init_BM_ATTACHMENTS(BM_ATTACHMENTS);
	}
}