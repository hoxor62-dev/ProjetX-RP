/**
 * CapsuleHUD.c
 * HUD texte 100% script.
 * API correcte Enfusion :
 *   GetGame().GetWorkspace().CreateWidget(WidgetType.TextWidgetTypeID, flags, color, zorder, parent)
 *   TextWidget.Cast(widget)
 *   tw.SetText(), tw.SetColor()
 *   FrameSlot.SetPos(w, x, y) / FrameSlot.SetSize(w, sx, sy)  ← coordonnées 0.0-1.0
 */

class CapsuleHUD
{
	// Widgets persistants
	private Widget     m_wRoot;
	private TextWidget m_wCapsules;
	private TextWidget m_wNotif;
	private TextWidget m_wStreak;
	private TextWidget m_wZone;

	// Timers fade
	private float m_fNotifTimer  = 0.0;
	private float m_fStreakTimer = 0.0;
	private float m_fZoneTimer   = 0.0;

	static const float DUR_NOTIF  = 3.0;
	static const float DUR_STREAK = 4.0;
	static const float DUR_ZONE   = 5.0;

	//------------------------------------------------------------------------------------------------
	void CapsuleHUD()
	{
		CreateWidgets();
	}

	void ~CapsuleHUD()
	{
		if (m_wRoot)
			m_wRoot.RemoveFromHierarchy();
	}

	//------------------------------------------------------------------------------------------------
	private void CreateWidgets()
	{
		WorkspaceWidget ws = GetGame().GetWorkspace();
		if (!ws) return;

		// Conteneur racine (Frame plein écran)
		m_wRoot = ws.CreateWidget(WidgetType.FrameWidgetTypeID,
			WidgetFlags.VISIBLE | WidgetFlags.NOFOCUS,
			Color.FromRGBA(0,0,0,0), 0);
		if (!m_wRoot) return;

		// Positionner le root plein écran via FrameSlot
		FrameSlot.SetPos(m_wRoot, 0, 0);
		FrameSlot.SetSize(m_wRoot, 1, 1);

		// Capsules (haut droite) — pos relative 0..1
		m_wCapsules = MakeText(ws, m_wRoot, "Capsules : 0",
			0.75, 0.03, 0.24, 0.05,
			Color.FromRGBA(240, 210, 50, 255), 16);

		// Notification achat/vente (centre bas)
		m_wNotif = MakeText(ws, m_wRoot, "",
			0.25, 0.85, 0.50, 0.05,
			Color.FromRGBA(50, 230, 50, 255), 17);

		// Kill streak (centre milieu)
		m_wStreak = MakeText(ws, m_wRoot, "",
			0.20, 0.75, 0.60, 0.06,
			Color.FromRGBA(255, 140, 0, 255), 20);

		// Zone message (centre haut)
		m_wZone = MakeText(ws, m_wRoot, "",
			0.10, 0.10, 0.80, 0.06,
			Color.FromRGBA(50, 230, 100, 255), 18);
	}

	//------------------------------------------------------------------------------------------------
	// Crée un TextWidget enfant de parent avec pos/size en coordonnées normalisées (0..1)
	private TextWidget MakeText(WorkspaceWidget ws, Widget parent,
		string text, float x, float y, float sx, float sy,
		Color color, int fontSize)
	{
		Widget w = ws.CreateWidget(WidgetType.TextWidgetTypeID,
			WidgetFlags.VISIBLE | WidgetFlags.NOFOCUS,
			Color.FromRGBA(0,0,0,0), 0, parent);
		if (!w) return null;

		FrameSlot.SetPos(w, x, y);
		FrameSlot.SetSize(w, sx, sy);

		TextWidget tw = TextWidget.Cast(w);
		if (!tw) return null;

		tw.SetText(text);
		tw.SetColor(color);

		return tw;
	}

	//------------------------------------------------------------------------------------------------
	void UpdateDisplay(int capsules)
	{
		if (m_wCapsules) m_wCapsules.SetText("Capsules : " + capsules.ToString());
	}

	void ShowNotification(string msg, bool success)
	{
		m_fNotifTimer = DUR_NOTIF;
		if (!m_wNotif) return;
		m_wNotif.SetText(msg);
		if (success)
			m_wNotif.SetColor(Color.FromRGBA(50, 230, 50, 255));
		else
			m_wNotif.SetColor(Color.FromRGBA(230, 50, 50, 255));
		m_wNotif.SetOpacity(1.0);
	}

	void ShowKillStreakNotification(int bonus)
	{
		m_fStreakTimer = DUR_STREAK;
		if (!m_wStreak) return;
		m_wStreak.SetText("KILL STREAK! +" + bonus.ToString() + " Capsules Bonus!");
		m_wStreak.SetOpacity(1.0);
	}

	void ShowZoneEnter()
	{
		m_fZoneTimer = DUR_ZONE;
		if (!m_wZone) return;
		m_wZone.SetText("Zone Securisee - Lamentin | PVP desactive");
		m_wZone.SetColor(Color.FromRGBA(50, 230, 100, 255));
		m_wZone.SetOpacity(1.0);
	}

	void ShowZoneExit()
	{
		m_fZoneTimer = DUR_ZONE;
		if (!m_wZone) return;
		m_wZone.SetText("Vous quittez la Zone Securisee — PVP actif");
		m_wZone.SetColor(Color.FromRGBA(230, 130, 50, 255));
		m_wZone.SetOpacity(1.0);
	}

	//------------------------------------------------------------------------------------------------
	void Update(float dt)
	{
		if (m_fNotifTimer > 0)
		{
			m_fNotifTimer -= dt;
			if (m_wNotif) m_wNotif.SetOpacity(Math.Clamp(m_fNotifTimer / DUR_NOTIF, 0.0, 1.0));
		}
		if (m_fStreakTimer > 0)
		{
			m_fStreakTimer -= dt;
			if (m_wStreak) m_wStreak.SetOpacity(Math.Clamp(m_fStreakTimer / DUR_STREAK, 0.0, 1.0));
		}
		if (m_fZoneTimer > 0)
		{
			m_fZoneTimer -= dt;
			if (m_wZone) m_wZone.SetOpacity(Math.Clamp(m_fZoneTimer / DUR_ZONE, 0.0, 1.0));
		}
	}
}
