/**
 * CapsuleShopMenuHandler
 * Attache sur chaque widget item via AddHandler().
 * Dans ChimeraMenuBase, OnMouseButtonDown fonctionne nativement.
 */
class CapsuleShopMenuHandler : ScriptedWidgetEventHandler
{
	private CapsuleShopMenuBase m_Menu;
	private int                 m_iIndex;
	private bool                m_bIsBuy;

	void Init(CapsuleShopMenuBase menu, int index, bool isBuy)
	{
		m_Menu   = menu;
		m_iIndex = index;
		m_bIsBuy = isBuy;
	}

	// OnClick est declenche sur tout widget dans un MenuBase au clic gauche
	override bool OnClick(Widget w, int x, int y, int button)
	{
		if (button != 0 || !m_Menu) return false;
		if (m_bIsBuy)
			m_Menu.OnBuyItemClicked(m_iIndex);
		else
			m_Menu.OnSellItemClicked(m_iIndex);
		return true;
	}

	// OnMouseButtonDown en fallback
	override bool OnMouseButtonDown(Widget w, int x, int y, int button)
	{
		if (button != 0 || !m_Menu) return false;
		if (m_bIsBuy)
			m_Menu.OnBuyItemClicked(m_iIndex);
		else
			m_Menu.OnSellItemClicked(m_iIndex);
		return true;
	}

	override bool OnMouseEnter(Widget w, int x, int y)
	{
		Print("[CapsuleHandler] OnMouseEnter idx=" + m_iIndex.ToString() + " buy=" + m_bIsBuy.ToString());
		if (!m_Menu) return false;

		// Calculer la position ecran du widget pour placer le tooltip
		float wx, wy, ww, wh;
		w.GetScreenPos(wx, wy);
		w.GetScreenSize(ww, wh);
		int sx = wx + ww + 8;  // a droite du widget
		int sy = wy;

		if (m_bIsBuy)
		{
			m_Menu.OnBuyItemHover(m_iIndex);
			m_Menu.ShowTooltipBuy(m_iIndex, sx, sy);
		}
		else
		{
			m_Menu.ShowTooltipSell(m_iIndex, sx, sy);
		}

		Widget bg = w.FindAnyWidget("ItemBg");
		if (bg)
		{
			Color c = Color.FromRGBA(35, 35, 60, 255);
			ImageWidget ibg = ImageWidget.Cast(bg);
			if (ibg) ibg.SetColor(c);
		}
		return false;
	}

	override bool OnMouseLeave(Widget w, Widget enterW, int x, int y)
	{
		if (m_Menu) m_Menu.HideTooltip();

		Widget bg = w.FindAnyWidget("ItemBg");
		if (bg)
		{
			Color c = Color.FromRGBA(25, 25, 40, 255);
			ImageWidget ibg = ImageWidget.Cast(bg);
			if (ibg) ibg.SetColor(c);
		}
		return false;
	}
}