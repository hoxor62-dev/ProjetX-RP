modded enum ChimeraMenuPreset
{
	CapsuleShopMenu
}
